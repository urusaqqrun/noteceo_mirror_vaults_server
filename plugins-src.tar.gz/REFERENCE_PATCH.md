# 插件參考：加強功能型（Patch）

> 建立依賴現有插件、用猴子補丁擴展 UI/Store 的插件時閱讀此文件。

---

## Plugin 基類 API（與 Standalone 相同）

完整 API 見 REFERENCE_STANDALONE.md。以下只列出 Patch 型常用的：

```typescript
abstract class Plugin {
    // 註冊編輯器擴展（ProseMirror Extension）
    registerEditorExtension(id: string, ext: Extension | Extension[]): void;

    // 註冊全局 Overlay（Dialog、提示浮層）
    registerOverlay(id: string, Component: React.FC): void;

    // 為 itemType 追加字段
    registerItemFields(itemType: string, ext: SchemaExtension): void;

    // 註冊 AI Hints
    registerAIHints(itemType: string, hints: string[]): void;

    // 訂閱事件
    registerEvent(event: string, handler: Function): void;

    // 也可以有自己的 Sidebar section
    registerSidebarSection(desc: SidebarSectionDescriptor): void;
}
```

---

## 猴子補丁模式

Patch 型插件的核心模式：**在 onload() 中修改其他插件的 Store 或注入 UI 補丁。**

### 1. Store 補丁

```typescript
// 在 ClassifyPlugin.onload() 中（所有 import 從 @cubelv/sdk）
import { useNoteStore } from '@cubelv/sdk';

// 替換 Store 的某個方法
const originalLoadNotes = useNoteStore.getState().loadNotes;
useNoteStore.setState({
    loadNotes: async () => {
        await originalLoadNotes();
        // 額外：載入分類資料
        await loadClassifications();
    }
});

// 卸載時恢復
this.register(() => {
    useNoteStore.setState({ loadNotes: originalLoadNotes });
});
```

### 2. UI 補丁（Patch Component）

在 patches/ 子目錄放補丁元件，透過 eventBus 或 overlay 注入：

```typescript
// ClassifyPlugin.onload()
// 方法 1：透過 Overlay 注入全局浮層
this.registerOverlay('classifyHint', ClassifyHint);

// 方法 2：透過 eventBus 注入到特定 UI 位置
eventBus.on('noteItem:render', (props) => {
    // 在 NoteItem 渲染時插入分類裝飾
    return <ClassifyDecoration {...props} />;
});
```

### 3. 編輯器擴展

```typescript
// 註冊 ProseMirror Extension
this.registerEditorExtension('my-highlight', myHighlightExtension);
```

---

## 完整最小範例：文字計數補丁插件

在每個筆記編輯器上方顯示字數統計。

### WordCountPlugin.tsx

```tsx
import { Plugin, registerPluginClass, eventBus } from '@cubelv/sdk';
import './wordCount.css';

// Overlay 元件：顯示在編輯器頂部
const WordCountBar: React.FC = () => {
    const [count, setCount] = React.useState(0);

    React.useEffect(() => {
        const handler = (data: { text: string }) => {
            setCount(data.text.split(/\s+/).filter(Boolean).length);
        };
        eventBus.on('editor:content-changed', handler);
        return () => eventBus.off('editor:content-changed', handler);
    }, []);

    return (
        <div className="word-count-bar">
            字數：{count}
        </div>
    );
};

class WordCountPlugin extends Plugin {
    onload() {
        // 註冊 Overlay
        this.registerOverlay('wordCount', WordCountBar);
    }
}

registerPluginClass(WordCountPlugin, '字數統計', {
    optionalDependencies: ['EditorPlugin'],
});
```

### wordCount.css

```css
.word-count-bar {
    position: fixed;
    bottom: 8px;
    right: 8px;
    padding: 4px 12px;
    border-radius: 6px;
    background: color-mix(in srgb, var(--on) 8%, transparent);
    color: color-mix(in srgb, var(--on) 60%, transparent);
    font-size: 12px;
    z-index: 50;
}
```

---

## 檔案結構

```
plugins/{pluginDir}/
├── {CodeStem}Plugin.tsx       ← 主入口 + onload() 補丁邏輯
├── {codeStem}Store.ts         ← 自己的狀態（如果需要）
├── {codeStem}.css              ← 樣式
└── patches/                    ← 補丁元件（可選）
    ├── noteStore_patch.ts     ← Store 補丁
    ├── NoteItem_patch.tsx     ← UI 補丁
    └── Decoration.css
```

---

## 存取其他插件的 Store

一律從 `@cubelv/sdk` import：

```typescript
import { useNoteStore, useItemStore } from '@cubelv/sdk';

const notes = useNoteStore.getState().notes;
const items = useItemStore.getState().byType?.NOTE || [];
```

---

## 依賴宣告

```typescript
registerPluginClass(MyPatchPlugin, '我的補丁', {
    dependencies: ['SidebarPlugin'],           // 硬依賴：缺了就不載入
    optionalDependencies: ['NotePlugin'],       // 軟依賴：有就排後面
});
```

---

## CSS 主題變數

與 Standalone 相同，見 REFERENCE_STANDALONE.md。

---

## 交付前 Checklist

- [ ] 入口檔為 `*Plugin.tsx`
- [ ] 呼叫了 `registerPluginClass(MyPlugin, '名稱', { dependencies: [...] })`
- [ ] 補丁邏輯在 `onunload()` 或 `register()` 中正確恢復
- [ ] CSS 只使用 `var(--*)` 主題變數
- [ ] 不直接修改其他插件的原始碼（只透過 Store patch 或 eventBus）
