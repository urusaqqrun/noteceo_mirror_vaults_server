import React from 'react';
import { useTranslation } from 'react-i18next';
import './UpdateDialog.css';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

const UpdateDialog = () => {
  const { t } = useTranslation();
  const showUpdateDialog = useDialogStore(s => s.dialogs['update']?.show);
  const onClose = () => useDialogStore.getState().close('update');

  if (!showUpdateDialog) return null;

  const updateInfo = {
    version: '2.1.0',
    releaseDate: '2024年12月20日',
    features: [
      '新增 AI 智能筆記分類功能',
      '優化筆記搜尋演算法，提升搜尋速度 50%',
      '支援 Markdown 表格編輯',
      '新增夜間模式自動切換',
      '修復筆記同步偶發性失敗問題'
    ],
    bugFixes: [
      '修復在某些情況下筆記內容丟失的問題',
      '解決資料夾拖拽排序異常',
      '修復標籤搜尋結果不準確的問題'
    ]
  };

  return (
    <CustomDialog
      isOpen={true}
      onClose={onClose}
      onConfirm={onClose}
      showCancel={false}
      title={t('updateInfo')}
      className="update-dialog"
    >
      <div className="update-dialog-content">
        <div className="update-version-info">
          <div className="update-version">{t('version')} {updateInfo.version}</div>
          <div className="update-date">{updateInfo.releaseDate}</div>
        </div>

        <div className="update-section">
          <h3>{t('newFeatures')}</h3>
          <ul>
            {updateInfo.features.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
        </div>
        <div className="update-section">
          <h3>{t('bugFixes')}</h3>
          <ul>
            {updateInfo.bugFixes.map((fix, index) => (
              <li key={index}>{fix}</li>
            ))}
          </ul>
        </div>
      </div>
    </CustomDialog>
  );
};

export default UpdateDialog; 
