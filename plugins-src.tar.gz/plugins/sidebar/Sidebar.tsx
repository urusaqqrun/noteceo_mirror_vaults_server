import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import './Sidebar.css';
import './FolderList.css';
import UserAvatar from './UserAvatar';
import { PopupMenu, PopupMenuItem, PopupMenuDivider } from '../../common/PopupMenu';
import UpgradeIcon from '../../../assets/icon_upgrade_24.svg?react';
import SettingsIcon from '../../../assets/icon_setting_24.svg?react';
import LogoutIcon from '../../../assets/icon_signout_24.svg?react';
import SuggestionIcon from '../../../assets/icon_chat_add_24.svg?react';
import AboutIcon from '../../../assets/icon_info_24.svg?react';
import UsageIcon from '../../../assets/chart/icon_chart_barchart.svg?react';
import ModulesIcon from '../../../assets/icon_modules_24.svg?react';
import { isWeb } from '../../../utils/platform';
import { useCommandManager } from '../../../Store/commandManager';
import { SearchBar } from '../../common/BasicComponents';
import { useDialogStore } from '../../../Store/dialogStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import type { BaseItem } from '../../../types/item';
import { useCollapsedGroupsStore } from '../../../Store/uiStore';
import { eventBus } from '../../../Store/eventBus';
import ConnectionStatusDot from './ConnectionStatusDot';
import SidebarTopbar from './SidebarTopbar';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import CustomScrollbar from '../../common/CustomScrollbar';
import { useSidebarRegistry } from './sidebarStore';
import GenericSidebarSection from './GenericSidebarSection';

/**
 * Sidebar 空殼：純佈局 + 通用鍵盤導航 + 帳戶選單。
 * 不知道任何 item 類型，所有 section 由 Plugin 透過 useSidebarRegistry 註冊。
 */
interface SidebarProps {
  onLogout?: (() => void) | null;
  onMobileClose?: (() => void) | null;
}

const Sidebar = forwardRef<any, SidebarProps>(({
  onLogout = null,
  onMobileClose = null,
}, ref) => {
  const { t } = useTranslation();
  const isMobileView = useIsMobileView();
  const registrySections = useSidebarRegistry(s => [...s.sections.values()].sort((a, b) => a.orderAt - b.orderAt));

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const [accountMenu, setAccountMenu] = useState({
    visible: false,
    x: 0,
    y: 0
  });

  // 更新相關狀態
  const [updateAvailable, setUpdateAvailable] = useState(false);

  // 新增資料夾菜單狀態
  const [addFolderMenu, setAddFolderMenu] = useState({
    visible: false,
    x: 0,
    y: 0
  });

  // 用戶資料狀態
  const [userEmail, setUserEmail] = useState('');
  const [userAvatarUrl, setUserAvatarUrl] = useState('');
  const [userPlan, setUserPlan] = useState('free');
  const path = useSelectedItemsStore(state => state.path);
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const selectedItemIds = path.map(i => i.id);
  const toggleGroup = useCollapsedGroupsStore(state => state.toggleGroup);
  // 從 path.at(-1) 推導當前選中的 folder id
  const getActiveFolderId = (): string | null => {
    const lastItem = useSelectedItemsStore.getState().path.at(-1);
    if (!lastItem) return null;
    // 本身是 folder → 直接用
    if (lastItem.itemType?.endsWith('_FOLDER')) return lastItem.id;
    // 否則 path 最後一個的 id
    return lastItem.id ?? null;
  };

  // EventBus 導航 wrapper：setSelectedItems + 發事件讓 Plugin 訂閱
  const navigateAndEmit = (item: BaseItem | null, options: { scrollToFocusItem?: boolean } = {}) => {
    if (!item) {
      useSelectedItemsStore.getState().setSelectedItems([]);
      eventBus.emit('sidebar:folder-select', { folderId: null });
      return;
    }
    useSelectedItemsStore.getState().setSelectedItems([item], options.scrollToFocusItem ? { scrollToFocusItem: true } : {});
    eventBus.emit('sidebar:folder-select', { folderId: item.id });
  };

  // 處理帳戶菜單點擊
  const handleAccountClick = (e) => {
    e.stopPropagation(); // 阻止事件冒泡
    if (accountMenu.visible) {
      // 如果菜单已经显示，则关闭它
      closeAccountMenu();
    } else {
      // 如果菜单未显示，则打开它
      const rect = e.currentTarget.getBoundingClientRect();

      // 获取当前缩放比例
      const computedScale = getComputedStyle(document.documentElement)
        .getPropertyValue('--content-scale')
        .trim();
      const SCALE = parseFloat(computedScale) || 1;

      // 将位置转换为未缩放的坐标
      const unscaledX = 8 / SCALE;
      const unscaledY = (rect.bottom + 5) / SCALE;

      setAccountMenu({
        visible: true,
        x: unscaledX,
        y: unscaledY
      });
    }
  };

  // 關閉帳戶菜單
  const closeAccountMenu = () => {
    setAccountMenu({
      visible: false,
      x: 0,
      y: 0
    });
  };


  // 獲取用戶資料
  useEffect(() => {
    const getUserData = () => {
      try {
        const userData = localStorage.getItem('userData_local');
        if (userData) {

          const parsedData = JSON.parse(userData);
          setUserEmail(parsedData.email || '');
          setUserAvatarUrl(parsedData.photoUrl || '');
          setUserPlan(parsedData.plan || 'free');

        }
      } catch (error) {
        console.error('解析用戶資料失敗:', error);
      }
    };

    getUserData();

    // 監聽localStorage變化
    const handleStorageChange = () => {
      getUserData();
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  useEffect(() => {
    if (!accountMenu.visible) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'sidebar:close-account-menu',
        name: t('cmd.closeAccountMenu'),
        callback: () => closeAccountMenu(),
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [accountMenu.visible]);

  // Sidebar 導航快捷鍵 — commandManager 統一管理
  useEffect(() => {
    const cm = useCommandManager.getState();

    const isSidebarLevel = () => {
      const last = useSelectedItemsStore.getState().path.at(-1);
      return !last || last.itemType.endsWith('_FOLDER');
    };

    const checkBodyFocus = () => {
      const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
      const hasOpenMenu = document.querySelector('.add-menu.active') ||
        document.querySelector('.more-menu.active') ||
        document.querySelector('.right-click-menu') ||
        document.querySelector('.account-menu');
      if (hasOpenDialog || hasOpenMenu) return false;
      if (!isSidebarLevel()) return false;
      return document.activeElement === document.body;
    };

    // ---- FolderGroup 導航 helper ----

    /** 判斷 item 是否為 FolderGroup（在其 section 的 items 中有子 folder） */
    const isFolderGroup = (item: BaseItem): { is: boolean; sectionId: string | null } => {
      const sectionDataCache = useSidebarRegistry.getState().sectionDataCache;
      for (const [sectionId, data] of sectionDataCache) {
        const items = data.items || [];
        if (!items.some(i => i.id === item.id)) continue;
        const hasChildren = items.some(i => i.parentID === item.id);
        return { is: hasChildren, sectionId: hasChildren ? sectionId : null };
      }
      return { is: false, sectionId: null };
    };

    /** 判斷 item 是否為 ancestor 的（直接/間接）子孫 */
    const isDescendantOf = (item: BaseItem, ancestor: BaseItem, sectionId: string): boolean => {
      const sectionData = useSidebarRegistry.getState().sectionDataCache.get(sectionId);
      if (!sectionData) return false;
      const sectionItems = sectionData.items || [];
      let current = item;
      const visited = new Set<string>();
      while (current && !visited.has(current.id)) {
        visited.add(current.id);
        if (current.parentID === ancestor.id) return true;
        current = sectionItems.find(i => i.id === current.parentID) as any;
      }
      return false;
    };

    /**
     * 從 flat nav list 的 startIndex 開始，往 direction 方向找到第一個葉子 folder。
     * 遇到 FolderGroup 時自動展開，然後：
     *   - 'down'：取展開後的下一項（第一個子項）
     *   - 'up'  ：先跳過自身路徑的祖先 FolderGroup，
     *             遇到非祖先的 FolderGroup 再展開取最後一個子孫
     * @param originItem 上鍵時傳入起始項，用於判斷祖先關係
     */
    const findLeafFolder = (startIndex: number, direction: 'down' | 'up', originItem?: BaseItem): BaseItem | null => {
      let navList = getFlatNavigationList();
      let idx = startIndex;
      let iterations = 0;

      while ((direction === 'down' ? idx < navList.length : idx >= 0) && iterations < 50) {
        iterations++;
        const target = navList[idx];
        const fg = isFolderGroup(target);

        if (!fg.is) return target; // 葉子 folder

        if (direction === 'down') {
          // 下鍵：展開 FolderGroup，往下一項（第一個子項）
          if (fg.sectionId) {
            const groupKey = `${fg.sectionId}-${target.id}`;
            if (useCollapsedGroupsStore.getState().collapsedGroups.has(groupKey)) {
              toggleGroup(groupKey);
              navList = getFlatNavigationList();
            }
          }
          idx++;
        } else {
          // 上鍵：先檢查是否為自身路徑的祖先
          const isAncestor = originItem && fg.sectionId && isDescendantOf(originItem, target, fg.sectionId);

          if (isAncestor) {
            // 自身祖先 → 跳過，繼續往上
            idx--;
          } else {
            // 非祖先的 FolderGroup → 展開，取最後一個子孫
            if (fg.sectionId) {
              const groupKey = `${fg.sectionId}-${target.id}`;
              if (useCollapsedGroupsStore.getState().collapsedGroups.has(groupKey)) {
                toggleGroup(groupKey);
                navList = getFlatNavigationList();
              }
            }
            // 找到此 FolderGroup 在 flat list 中的最後一個子孫
            let lastDescendantIdx = idx;
            for (let j = idx + 1; j < navList.length; j++) {
              if (fg.sectionId && isDescendantOf(navList[j], target, fg.sectionId)) {
                lastDescendantIdx = j;
              } else {
                break;
              }
            }
            idx = lastDescendantIdx;
            // idx 現在指向最後一個子孫，若它仍是 FolderGroup 則下次迴圈繼續展開
          }
        }
      }

      return null;
    };

    const unsubs = [
      cm.register({
        command: {
          id: 'sidebar:arrow-up',
          name: t('cmd.sidebarArrowUp'),
          checkCallback: (checking: boolean) => {
            if (!checkBodyFocus()) return false;
            const navList = getFlatNavigationList();
            const lastId = lastSelected?.id;
            const currentIndex = lastId ? navList.findIndex(i => i.id === lastId) : -1;
            if (currentIndex === -1 || currentIndex === 0) return false;
            if (checking) return true;
            const target = findLeafFolder(currentIndex - 1, 'up', navList[currentIndex]);
            if (target) {
              navigateAndEmit(target, { scrollToFocusItem: true });
              onMobileClose?.();
            }
            return true;
          },
        },
        hotkeys: [{ modifiers: [], key: 'ArrowUp' }],
        enabled: isSidebarLevel,
      }),
      cm.register({
        command: {
          id: 'sidebar:arrow-down',
          name: t('cmd.sidebarArrowDown'),
          checkCallback: (checking: boolean) => {
            if (!checkBodyFocus()) return false;
            const navList = getFlatNavigationList();
            const lastId = lastSelected?.id;
            const currentIndex = lastId ? navList.findIndex(i => i.id === lastId) : -1;
            if (currentIndex === -1 || currentIndex >= navList.length - 1) return false;
            if (checking) return true;
            const target = findLeafFolder(currentIndex + 1, 'down');
            if (target) {
              navigateAndEmit(target, { scrollToFocusItem: true });
              onMobileClose?.();
            }
            return true;
          },
        },
        hotkeys: [{ modifiers: [], key: 'ArrowDown' }],
        enabled: isSidebarLevel,
      }),
      cm.register({
        command: {
          id: 'sidebar:delete-folder',
          name: t('cmd.sidebarDeleteFolder'),
          checkCallback: (checking: boolean) => {
            if (!checkBodyFocus()) return false;
            const activeFolderId = getActiveFolderId();
            if (!activeFolderId) return false;
            if (!checking) {
              eventBus.emit('sidebar:delete-folder', { folderId: activeFolderId });
            }
            return true;
          },
        },
        hotkeys: [
          { modifiers: ['Mod'], key: 'Delete' },
          { modifiers: ['Mod'], key: 'Backspace' },
        ],
        enabled: isSidebarLevel,
      }),
      cm.register({
        command: {
          id: 'sidebar:arrow-left',
          name: t('cmd.sidebarArrowLeft'),
          checkCallback: (checking: boolean) => {
            if (!checkBodyFocus()) return false;
            if (!checking) useSelectedItemsStore.getState().navigateOut();
            return true;
          },
        },
        hotkeys: [{ modifiers: [], key: 'ArrowLeft' }],
        enabled: isSidebarLevel,
      }),
      cm.register({
        command: {
          id: 'sidebar:arrow-right',
          name: t('cmd.sidebarArrowRight'),
          checkCallback: (checking: boolean) => {
            if (!checkBodyFocus()) return false;
            if (!checking) useSelectedItemsStore.getState().navigateInto();
            return true;
          },
        },
        hotkeys: [{ modifiers: [], key: 'ArrowRight' }],
        enabled: isSidebarLevel,
      }),
    ];
    return () => unsubs.forEach(u => u());
  }, [lastSelected, selectedItemIds]);

  const getFlatNavigationList = () => useSidebarRegistry.getState().getFlatNavItems();

  // 通用自動捲動
  const scrollToItem = (itemId: string) => {
    safeSetTimeout(() => {
      const targetEl = document.querySelector(`[data-item-id="${itemId}"]`);
      const listContainer = document.querySelector('.sidebar .custom-scrollbar-content');
      if (targetEl && listContainer) {
        const containerRect = listContainer.getBoundingClientRect();
        const elemRect = targetEl.getBoundingClientRect();
        const isAboveView = elemRect.top < containerRect.top;
        const isBelowView = elemRect.bottom > containerRect.bottom;
        if (isAboveView || isBelowView) {
          const relativeTop = elemRect.top - containerRect.top;
          const containerCenter = containerRect.height / 2;
          const scrollTop = listContainer.scrollTop + relativeTop - containerCenter + elemRect.height / 2;
          listContainer.scrollTo({ top: scrollTop, behavior: 'smooth' });
        }
      }
    }, 50);
  };

  // 當選中項目變化，自動捲動到對應的 sidebar 項目
  useEffect(() => {
    const needScroll = useSelectedItemsStore.getState().navParams?.scrollToFocusItem;
    if (!needScroll || !lastSelected) return;
    scrollToItem(lastSelected.id);
  }, [selectedItemIds, lastSelected]);

  // 處理更新重啟按鈕點擊
  const handleUpdateRestart = () => {

    if (window.electronAPI && window.electronAPI.restartAndUpdate) {

      window.electronAPI.restartAndUpdate();
    } else {
      console.error('window.electronAPI.restartAndUpdate 不存在');
    }
  };


  // 監聽更新可用事件
  useEffect(() => {
    if (window.electronAPI && window.electronAPI.onUpdateAvailable) {
      const unsubscribe = window.electronAPI.onUpdateAvailable(() => {
        setUpdateAvailable(true);
      });

      return () => {
        if (typeof unsubscribe === 'function') {
          unsubscribe();
        }
      };
    }
  }, []);

  // 監聽更新錯誤事件
  useEffect(() => {
    if (window.electronAPI && window.electronAPI.onUpdateError) {
      const unsubscribe = window.electronAPI.onUpdateError((errorInfo) => {
        console.error('更新錯誤:', errorInfo);
        console.error('錯誤詳情:', {
          message: errorInfo.message,
          code: errorInfo.code,
          domain: errorInfo.domain
        });
      });

      return () => {
        if (typeof unsubscribe === 'function') {
          unsubscribe();
        }
      };
    }
  }, []);


  // 暴露方法給父組件
  useImperativeHandle(ref, () => ({
    openSearchWithText: (text) => {
      // 移動端先打開鍵盤（若調用方是點擊事件）
      if (isMobileView && window.focusHiddenInput) {
        window.focusHiddenInput();
      }
      useDialogStore.getState().open('search', { isFromTag: true });
      // 將搜尋文字保存起來，等 SearchDialog 打開時使用
      window.localStorage.setItem('searchInitialText', text);
    }
  }));

  return (
    <aside
      className="sidebar"
    >
      <SidebarTopbar
        onAddFolder={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          setAddFolderMenu({
            visible: true,
            x: rect.left,
            y: rect.bottom + 8
          });
        }}
        avatarUrl={userAvatarUrl}
        onAvatarClick={(e) => {
          handleAccountClick(e);
          onMobileClose?.();
        }}
      />

      <div
        className="search-container-sidebar"
        style={(isWeb || isMobileView) ? { padding: '4px 10px 8px 10px' } : undefined}
      >
        <div className="search-with-avatar">
          {!isWeb && !isMobileView && (
            <div className="sidebar-avatar-container"
              onClick={(e) => {
                handleAccountClick(e);
                onMobileClose?.();
              }}>
              <UserAvatar
                avatarUrl={userAvatarUrl}
                className="user-avatar-button"
              />
              <ConnectionStatusDot />
            </div>
          )}
          <div onClick={() => {
            if (isMobileView && window.focusHiddenInput) {
              window.focusHiddenInput();
            }
            useDialogStore.getState().open('search');
            onMobileClose?.();
          }} style={{ flex: 1, cursor: 'pointer' }}>
            <SearchBar
              placeholder={t('searchPlaceholder')}
              readOnly
            />
          </div>
        </div>
      </div>


      <CustomScrollbar offsetRight={4}>
        {/* 插件化 section（由各 Plugin 透過 registry 註冊） */}
        {registrySections.length > 0 && registrySections.map(section => (
          <GenericSidebarSection key={`${section.id}-${section._version ?? 0}`} descriptor={section} showHeader={registrySections.length > 1 && !section.hideHeader} />
        ))}

      </CustomScrollbar>

      <div className="sidebar-debug">
        {updateAvailable && (
          <div className="sidebar-update-container">
            <div className="sidebar-update-text">
              {t('updateReady')}
            </div>
            <button
              className="sidebar-update-button"
              onClick={handleUpdateRestart}
            >
              {t('clickToRestart')}
            </button>
          </div>
        )}

        {/* <button 
          onClick={resetDatabase}
          className="reset-database-button"
          style={{ 
            marginTop: '10px',
            backgroundColor: '#ff4d4f',
            color: 'white'
          }}
        >
          重置數據庫
        </button> */}
      </div>
      {/* DEBUG 區塊結束 */}

      {/* 新增資料夾菜單（動態從 registrySections 生成） */}
      {addFolderMenu.visible && (
        <PopupMenu x={addFolderMenu.x} y={addFolderMenu.y} onClose={() => setAddFolderMenu({ visible: false, x: 0, y: 0 })}>
          {useSidebarRegistry.getState().getAddFolderItems().map(item => (
            <PopupMenuItem key={item.actionText} icon={item.icon} onClick={() => {
              if (isMobileView && window.focusHiddenInput) {
                window.focusHiddenInput();
              }
              item.onClick();
              setAddFolderMenu({ visible: false, x: 0, y: 0 });
              onMobileClose?.();
            }}>
              {item.actionText}
            </PopupMenuItem>
          ))}
        </PopupMenu>
      )}

      {accountMenu.visible && (
        <PopupMenu x={accountMenu.x} y={accountMenu.y} onClose={closeAccountMenu}>
          <div className="popup-menu-user" onClick={() => { useDialogStore.getState().open('settings', { tab: 'personal' }); closeAccountMenu(); }}>
            <UserAvatar avatarUrl={userAvatarUrl} className="popup-menu-avatar" />
            <span className="popup-menu-email">{userEmail}</span>
          </div>
          <PopupMenuDivider />
          {userPlan === 'free' && (
            <PopupMenuItem icon={UpgradeIcon} onClick={() => { useDialogStore.getState().open('settings', { tab: 'subscribe' }); closeAccountMenu(); }}>
              {t('upgradePlan')}
            </PopupMenuItem>
          )}
          <PopupMenuItem icon={SettingsIcon} onClick={() => { useDialogStore.getState().open('settings'); closeAccountMenu(); }}>
            {t('settings')}
          </PopupMenuItem>
          <PopupMenuItem icon={ModulesIcon} onClick={() => { useDialogStore.getState().open('settings', { tab: 'modules' }); closeAccountMenu(); }}>
            {t('moduleManagement')}
          </PopupMenuItem>
          <PopupMenuItem icon={UsageIcon} onClick={() => { useDialogStore.getState().open('settings', { tab: 'usage' }); closeAccountMenu(); }}>
            {t('usage')}
          </PopupMenuItem>
          <PopupMenuItem icon={SuggestionIcon} onClick={() => { useDialogStore.getState().open('suggestion'); closeAccountMenu(); }}>
            {t('giveSuggestion')}
          </PopupMenuItem>
          {isWeb && (
            <PopupMenuItem icon={AboutIcon} onClick={() => { useDialogStore.getState().open('about'); closeAccountMenu(); }}>
              {t('aboutCubeLV')}
            </PopupMenuItem>
          )}
          <PopupMenuDivider />
          <PopupMenuItem icon={LogoutIcon} danger onClick={() => { (onLogout ?? window.handleLogout)?.(); closeAccountMenu(); }}>
            {t('logout')}
          </PopupMenuItem>
        </PopupMenu>
      )}


    </aside>
  );
});

export default Sidebar;
