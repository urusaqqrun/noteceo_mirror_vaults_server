import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './SuggestionDialog.css';
import { uploadFile } from '../../../utils/fileUpload';
import { getDatabase, ref, set } from 'firebase/database';
import { app } from '../../login/FirebaseConfig';
import { useTempHintStore } from '../../../Store/uiStore';
import ImageIcon from '../../../assets/icon_photo_add_24.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

// 初始化 Realtime Database
const database = getDatabase(app);

/**
 * 生成 UUID
 * @returns {string}
 */
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16).toUpperCase();
  });
}

function SuggestionDialog() {
  const { t } = useTranslation();
  const showSuggestionDialog = useDialogStore(s => s.dialogs['suggestion']?.show);
  const onClose = () => useDialogStore.getState().close('suggestion');
  const setTempHint = useTempHintStore(state => state.setTempHint);

  const [message, setMessage] = useState('');
  const [images, setImages] = useState([]); // 存儲上傳的圖片 URLs
  const [localImages, setLocalImages] = useState([]); // 存儲本地預覽的圖片
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  if (!showSuggestionDialog) return null;

  // 處理圖片選擇
  const handleImageSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setIsUploading(true);

    try {
      // 獲取用戶資料
      const userData = JSON.parse(localStorage.getItem('userData_local'));
      if (!userData?.ID) {
        console.error('無法獲取用戶資料');
        return;
      }

      // 上傳所有圖片
      const uploadPromises = files.map(async (file) => {
        try {
          // 圖片壓縮選項
          const imageCompressOptions = {
            maxWidth: 1920,
            maxHeight: 1920,
            quality: 0.8,
            maxSizeKB: 2048,
            outputFormat: 'image/jpeg'
          };

          const uploadResult = await uploadFile(file, userData.ID, 'temp', imageCompressOptions);

          if (uploadResult?.downloadURL) {
            return {
              url: uploadResult.downloadURL,
              preview: URL.createObjectURL(file as Blob)
            };
          }
          return null;
        } catch (error) {
          console.error('上傳圖片失敗:', error);
          return null;
        }
      });

      const uploadedImages = await Promise.all(uploadPromises);
      const successfulUploads = uploadedImages.filter(img => img !== null);

      if (successfulUploads.length > 0) {
        setImages(prev => [...prev, ...successfulUploads.map(img => img.url)]);
        setLocalImages(prev => [...prev, ...successfulUploads.map(img => img.preview)]);
      }
    } catch (error) {
      console.error('處理圖片上傳錯誤:', error);
    } finally {
      setIsUploading(false);
      // 清空 input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // 刪除圖片
  const handleRemoveImage = (index) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    setLocalImages(prev => {
      const newImages = prev.filter((_, i) => i !== index);
      // 釋放 URL
      URL.revokeObjectURL(prev[index]);
      return newImages;
    });
  };

  // 提交建議
  const handleSubmit = async () => {
    if (!message.trim() && images.length === 0) {
      return;
    }

    setIsSubmitting(true);

    try {
      const uuid = generateUUID();
      const suggestionData = {
        images: images,
        message: message.trim()
      };

      // 寫入到 Firebase Realtime Database
      // 路徑: Electron/Suggestion/{UUID}
      const suggestionRef = ref(database, `Electron/Suggestion/${uuid}`);
      await set(suggestionRef, suggestionData);

      // 顯示成功提示
      setTempHint(t('suggestionSubmitSuccess'));

      // 清理本地預覽 URLs
      localImages.forEach(url => URL.revokeObjectURL(url));

      // 關閉對話框
      onClose();
    } catch (error) {
      console.error('提交建議失敗:', error);
      setTempHint(t('suggestionSubmitFailed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <CustomDialog
      isOpen={true}
      onClose={onClose}
      title={t('giveSuggestion')}
      className="suggestion-dialog-container"
    >
      {/* 內容區 */}
      <div className="suggestion-dialog-content">
        {/* 說明文字 */}
        <p className="suggestion-dialog-description">{t('suggestionDescription')}</p>

        {/* 訊息輸入區 */}
        <textarea
          className="suggestion-dialog-textarea"
          placeholder={t('suggestionPlaceholder')}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          disabled={isSubmitting}
        />

        {/* 圖片預覽區 */}
        {localImages.length > 0 && (
          <div className={`suggestion-dialog-images ${isSubmitting ? 'disabled' : ''}`}>
            {localImages.map((preview, index) => (
              <div key={index} className="suggestion-dialog-image-item">
                <img src={preview} alt={`preview-${index}`} />
                {!isSubmitting && (
                  <button
                    className="suggestion-dialog-image-remove"
                    onClick={() => handleRemoveImage(index)}
                    disabled={isSubmitting}
                  >
                    <DeleteIcon />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 底部操作列 */}
      <div className="suggestion-dialog-footer">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          multiple
          style={{ display: 'none' }}
          onChange={handleImageSelect}
          disabled={isSubmitting || isUploading}
        />

        <button
          className="suggestion-dialog-image-button"
          onClick={() => fileInputRef.current?.click()}
          disabled={isSubmitting || isUploading}
        >
          <ImageIcon />
          <span>{isUploading ? t('uploading') : t('addImage')}</span>
        </button>

        <button
          className="suggestion-dialog-submit-button"
          onClick={handleSubmit}
          disabled={isSubmitting || isUploading || (!message.trim() && images.length === 0)}
        >
          {isSubmitting ? t('submitting') : t('submit')}
        </button>
      </div>
    </CustomDialog>
  );
}

export default SuggestionDialog;
