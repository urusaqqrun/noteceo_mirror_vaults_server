// ===== SidebarRegistry — Sidebar 插件化註冊中心 =====
//
// 各 Plugin 在 onload() 呼叫 registerSection / registerSearchProvider，
// Sidebar 空殼讀取 registry 決定渲染哪些 section 和 AddMenu items。
// section 順序由 orderAt 欄位決定（數值越小越靠上，差值 100）。

import { create } from 'zustand';
import type React from 'react';
import type { BaseItem } from '../../../types/item';
import { useCollapsedGroupsStore } from '../../../Store/uiStore';

// ---------- 型別定義 ----------

/**
 * ⚠️ Sidebar item 規範：
 * 所有 item（items / prefixItems / suffixItems）的 itemType 必須以 _FOLDER 結尾，否則不會在 sidebar 顯示。
 * 例如：NOTE_FOLDER、TODO_FOLDER、TODO_VIRTUAL_FOLDER、CARD_FOLDER、CHART_FOLDER、AI_ADMIN_FOLDER
 */
export interface SidebarSectionData {
  /** 可拖曳；renderer 自己用 parentID 建樹 */
  items: BaseItem[];
  /** 不可拖曳；tree 前面的固定項目（如 inbox、today/preview/completed/todoInbox） */
  prefixItems?: BaseItem[];
  /** 不可拖曳；tree 後面的固定項目（如 trash） */
  suffixItems?: BaseItem[];
  /** null → 不顯示 count；{ value } → hover/selected 才顯示；{ value, pinned: true } → 永遠顯示 */
  getCount?: (item: BaseItem) => { value: number; pinned?: boolean } | null;
  renderIcon?: (item: BaseItem) => React.ReactNode;
  /** 將 item.name 轉為顯示文字（如翻譯 inbox → 未分類） */
  getDisplayName?: (item: BaseItem) => React.ReactNode;
  /** prefixItems 與 items 之間是否顯示分隔線 */
  separatePrefix?: boolean;
  /** items 與 suffixItems 之間是否顯示分隔線 */
  separateSuffix?: boolean;
  /** 插入在 tree 上方的自定義 view（由 plugin 自行提供） */
  topView?: React.ReactNode;
  /** 插入在 tree 下方的自定義 view（由 plugin 自行提供） */
  bottomView?: React.ReactNode;
}

export interface FolderAction {
  /** 顯示文字（已翻譯） */
  actionText: string;
  icon?: React.ReactNode;
  onClick: () => void;
}

export interface SidebarSectionDescriptor {
  /** 穩定唯一識別，不隨 i18n 變動 */
  id: string;
  /** section header 顯示文字（已翻譯） */
  title: string;
  /** 排序權重，數值越小越靠上（差值 100：AUTOTASK=100, TODO=200, NOTE=300, CARD=400, CHART=500, SHARE=600） */
  orderAt: number;
  /** hook：回傳該 section 的資料與 adapter */
  useData: () => SidebarSectionData;
  /** section header + 按鈕 / Topbar + 選單項目 */
  addFolder?: FolderAction;
  /** 是否隱藏 section header（預設 false） */
  hideHeader?: boolean;
  /** 內部版本號，useData 被替換時自動遞增，用於強制 React remount */
  _version?: number;
}

/** @deprecated 無人使用，後續版本可能移除 */
export interface SidebarSearchProvider {
  id: string;
  search: (query: string) => BaseItem[];
  renderResult?: (item: BaseItem) => React.ReactNode;
}

// ---------- Store ----------

interface SidebarRegistryState {
  sections: Map<string, SidebarSectionDescriptor>;
  searchProviders: Map<string, SidebarSearchProvider>;
  /** 各 section 最新的 data 快取（由 GenericSidebarSection render 時寫入，鍵盤導航讀取） */
  sectionDataCache: Map<string, SidebarSectionData>;

  registerSection: (desc: SidebarSectionDescriptor) => void;
  unregisterSection: (id: string) => void;
  /** @deprecated 無人使用，後續版本可能移除 */
  registerSearchProvider: (provider: SidebarSearchProvider) => void;
  /** @deprecated 無人使用，後續版本可能移除 */
  unregisterSearchProvider: (id: string) => void;
  /** GenericSidebarSection 每次 render 呼叫，快取最新 data */
  updateSectionData: (id: string, data: SidebarSectionData) => void;

  /** 按 orderAt 升序的 section 陣列 */
  getSections: () => SidebarSectionDescriptor[];
  /** 按插入順序收集所有 addFolder 項目 */
  getAddFolderItems: () => FolderAction[];
  /** 展平所有已快取 section 的可導航項目 */
  getFlatNavItems: () => BaseItem[];
}

export const useSidebarRegistry = create<SidebarRegistryState>((set, get) => ({
  sections: new Map(),
  searchProviders: new Map(),
  sectionDataCache: new Map(),

  registerSection: (desc) => {
    set((state) => {
      const next = new Map(state.sections);
      const existing = next.get(desc.id);
      const version = (existing?._version ?? 0) + 1;
      next.set(desc.id, { ...desc, _version: version });
      return { sections: next };
    });
  },

  unregisterSection: (id) => {
    set((state) => {
      const next = new Map(state.sections);
      next.delete(id);
      const nextCache = new Map(state.sectionDataCache);
      nextCache.delete(id);
      return { sections: next, sectionDataCache: nextCache };
    });
  },

  registerSearchProvider: (provider) => {
    set((state) => {
      const next = new Map(state.searchProviders);
      next.set(provider.id, provider);
      return { searchProviders: next };
    });
  },

  unregisterSearchProvider: (id) => {
    set((state) => {
      const next = new Map(state.searchProviders);
      next.delete(id);
      return { searchProviders: next };
    });
  },

  updateSectionData: (id, data) => {
    get().sectionDataCache.set(id, data);
  },

  getSections: () => [...get().sections.values()].sort((a, b) => a.orderAt - b.orderAt),

  getAddFolderItems: () => {
    const items: FolderAction[] = [];
    for (const section of get().getSections()) {
      if (section.addFolder) {
        items.push(section.addFolder);
      }
    }
    return items;
  },

  getFlatNavItems: () => {
    const list: BaseItem[] = [];
    const collapsedSections = JSON.parse(localStorage.getItem('sidebarCollapsedSections') || '{}');
    const collapsedGroups = useCollapsedGroupsStore.getState().collapsedGroups;

    const getOrder = (item: BaseItem) => {
      const order = Number((item as any).orderAt) || 0;
      if (order !== 0) return order;
      return Number((item as any).createdAt) || 0;
    };
    const sortByOrder = (a: BaseItem, b: BaseItem) => getOrder(a) - getOrder(b);

    for (const section of get().getSections()) {
      if (collapsedSections[section.id]) continue;
      const data = get().sectionDataCache.get(section.id);
      if (!data) continue;

      if (data.prefixItems) list.push(...data.prefixItems);

      const items = data.items;
      const itemMap = new Map(items.map(i => [i.id, i]));
      const roots = items.filter(i => !i.parentID || !itemMap.has(i.parentID)).sort(sortByOrder);
      const getChildren = (parent: BaseItem) => items.filter(i => i.parentID === parent.id).sort(sortByOrder);

      const dfs = (node: BaseItem) => {
        list.push(node);
        const groupKey = `${section.id}-${node.id}`;
        if (collapsedGroups.has(groupKey)) return;
        for (const child of getChildren(node)) dfs(child);
      };
      for (const root of roots) dfs(root);

      if (data.suffixItems) list.push(...data.suffixItems);
    }
    return list;
  },
}));
