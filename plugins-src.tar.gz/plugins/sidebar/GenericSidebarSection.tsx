// ===== GenericSidebarSection — 唯一的 section renderer =====
//
// 讀 SidebarSectionDescriptor 的 useData()，用 GenericFolderTreeSection 渲染。
// 所有 section 都走這一套，不分 note / todo / card / chart / share。

import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { GenericFolderTreeSection } from './FolderTree';

import { useSidebarRegistry, type SidebarSectionDescriptor } from './sidebarStore';
import ArrowIcon from '../../../assets/icon_arrowchevron_up_24.svg?react';
import AddIcon from '../../../assets/bk_icon_add_line_20_n.svg?react';

interface Props {
  descriptor: SidebarSectionDescriptor;
  showHeader: boolean;
}

const GenericSidebarSection: React.FC<Props> = ({ descriptor, showHeader }) => {
  const { t } = useTranslation();
  const data = descriptor.useData();

  useEffect(() => {
    useSidebarRegistry.getState().updateSectionData(descriptor.id, data);
  });

  const [collapsed, setCollapsed] = useState(() => {
    try {
      const saved = localStorage.getItem('sidebarCollapsedSections');
      if (saved) {
        const parsed = JSON.parse(saved);
        return !!parsed[descriptor.id];
      }
    } catch { /* ignore */ }
    return false;
  });

  const toggleCollapse = () => {
    setCollapsed(prev => {
      const next = !prev;
      try {
        const saved = JSON.parse(localStorage.getItem('sidebarCollapsedSections') || '{}');
        saved[descriptor.id] = next;
        localStorage.setItem('sidebarCollapsedSections', JSON.stringify(saved));
      } catch { /* ignore */ }
      return next;
    });
  };

  // 完全沒有任何項目時，隱藏整個 section
  const hasItems = data.items.length > 0
    || (data.prefixItems && data.prefixItems.length > 0)
    || (data.suffixItems && data.suffixItems.length > 0);
  if (!hasItems) return null;

  return (
    <div className={`sidebar-section ${collapsed ? 'collapsed' : ''}`}>
      {showHeader && (
        <div className="sidebar-section-header">
          <span className="sidebar-section-title">{descriptor.title}</span>
          {descriptor.addFolder && (
            <button
              className="section-add-button"
              onClick={descriptor.addFolder.onClick}
              title={descriptor.addFolder.actionText}
            >
              <AddIcon />
            </button>
          )}
          <button
            className="section-collapse-button"
            onClick={toggleCollapse}
            title={collapsed ? t('expand') : t('collapse')}
          >
            <ArrowIcon className="section-collapse-icon" />
          </button>
        </div>
      )}
      {!collapsed && (
        <>
          {data.topView}
          <GenericFolderTreeSection data={data} sectionId={descriptor.id} />
          {data.bottomView}
        </>
      )}
    </div>
  );
};

export default GenericSidebarSection;
