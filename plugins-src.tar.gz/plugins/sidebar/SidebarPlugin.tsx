// ===== SidebarPlugin — Sidebar 插件 =====

import React from 'react';
import { useTranslation } from 'react-i18next';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import sidebarEn from './locales/en.json';
import sidebarZhHant from './locales/zh-Hant.json';
import sidebarJa from './locales/ja.json';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useItemStore } from '../../../Store/itemStore';
import i18n from '../../../i18n/config';
import { useCommandManager } from '../../../Store/commandManager';
import { useDialogStore } from '../../../Store/dialogStore';
import type { BaseItem } from '../../../types/item';
import type { DropPosition } from './FolderTree/DragContext';
import { useSidebarRegistry } from './sidebarStore';
import Sidebar from './Sidebar';
import NameInputDialog from '../../common/NameInputDialog';
import { CustomDialog } from '../../common/CustomDialog';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';

/** 檢查 ancestorId 是否為 descendantId 的祖先（防止循環引用） */
function isAncestorOf(ancestorId: string, descendantId: string, allItems: BaseItem[]): boolean {
    let currentId: string | null | undefined = descendantId;
    while (currentId) {
        const item = allItems.find(f => f.id === currentId);
        if (!item || !(item as any).parentID) return false;
        if ((item as any).parentID === ancestorId) return true;
        currentId = (item as any).parentID;
    }
    return false;
}

// ===== CreateGroupDialog — Sidebar 自己的群組命名 Dialog =====
const DIALOG_KEY = 'sidebar:createGroup';

const CreateGroupDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs[DIALOG_KEY]?.show);
    const dialogData = useDialogStore(state => state.dialogs[DIALOG_KEY]?.data);

    const draggedFolder = dialogData?.draggedFolder as BaseItem | undefined;
    const targetFolder = dialogData?.targetFolder as BaseItem | undefined;
    const folderType = targetFolder?.itemType ?? 'NOTE_FOLDER';

    // 所有 hook 必須在 early return 之前
    const allFolders = useItemStore(s => s.byType[folderType] ?? []);

    if (!showDialog || !draggedFolder || !targetFolder) return null;

    const handleClose = () => useDialogStore.getState().close(DIALOG_KEY);

    const existingNames = allFolders.map(f => f.name || '').filter(Boolean);

    const handleConfirm = async (groupName: string) => {
        const newGroupId = generateObjectID();
        // 群組位置取兩者中較高的排序位置（較小的 orderAt 值）
        const minOrderAt = Math.min(
            parseInt(String((targetFolder as any).orderAt || '0')) || 0,
            parseInt(String((draggedFolder as any).orderAt || '0')) || 0,
        ).toString();
        const newGroup: Record<string, any> = {
            id: newGroupId,
            name: groupName,
            itemType: folderType,
            parentID: (targetFolder as any).parentID || null,
            orderAt: minOrderAt,
        };
        // 1. 建群組
        await useItemStore.getState().upsertItem(newGroup as BaseItem, { needSync: true });
        // 2. 移動 target 進群組
        await useItemStore.getState().upsertItem(
            { ...targetFolder, parentID: newGroupId } as BaseItem,
            { needSync: true },
        );
        // 3. 移動 dragged 進群組
        await useItemStore.getState().upsertItem(
            { ...draggedFolder, parentID: newGroupId } as BaseItem,
            { needSync: true },
        );
    };

    return (
        <NameInputDialog
            title={t('createGroupTitle')}
            initialName=""
            existingNames={existingNames}
            placeholder={t('groupNamePlaceholder')}
            onConfirm={handleConfirm}
            onClose={handleClose}
        />
    );
};

// ===== DeleteGroupDialog — 群組刪除確認 Dialog =====
const DELETE_GROUP_KEY = 'sidebar:deleteGroup';

const DeleteGroupDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs[DELETE_GROUP_KEY]?.show);
    const folder = useDialogStore(state => state.dialogs[DELETE_GROUP_KEY]?.data?.folder) as BaseItem | undefined;

    if (!showDialog || !folder) return null;

    const handleClose = () => useDialogStore.getState().close(DELETE_GROUP_KEY);

    const handleConfirm = async () => {
        try {
            const folderType = folder.itemType ?? 'NOTE_FOLDER';
            const allFolders = useItemStore.getState().getByType(folderType);
            const children = allFolders.filter((f: any) => f.parentID === folder.id);

            // 把子 folder 移到群組的父層（或根層）
            for (const child of children) {
                await useItemStore.getState().upsertItem(
                    { ...child, parentID: (folder as any).parentID || null } as BaseItem,
                    { needSync: true },
                );
            }

            // 軟刪除群組本身
            await useItemStore.getState().removeItems([folder.id], { needSync: true });

            const { useTempHintStore } = await import('../../../Store/uiStore');
            useTempHintStore.getState().setTempHint(t('deletedGroup', { name: folder.name }));
            handleClose();
        } catch (error) {
            console.error('刪除群組失敗:', error);
        }
    };

    return (
        <CustomDialog isOpen onClose={handleClose} title={t('deleteGroupTitle')} onConfirm={handleConfirm}>
            <p className="custom-dialog-description">
                {t('deleteGroupConfirm', { name: folder.name })}
            </p>
        </CustomDialog>
    );
};

class SidebarView extends ReactView {
    transparentSeparator = true;
    getViewType() { return 'sidebar'; }
    getDisplayText() { return '侧边栏'; }
    renderComponent() { return <Sidebar />; }
}

export class SidebarPlugin extends Plugin {
    onload() {
        this.registerView('sidebar', (leaf) => new SidebarView(leaf));
        this.registerOverlay('createGroupDialog', CreateGroupDialog);
        this.registerOverlay('deleteGroupDialog', DeleteGroupDialog);

        // Sidebar 永遠掛載
        this.ensureLeafInPane('leftPane', 'leaf-sidebar', 'sidebar', {
            size: 200, minSize: 160,
        });

        // 預註冊 command schemas（設定頁不依賴元件 mount；無 handler → 僅寫 schema）
        const cm = useCommandManager.getState();
        cm.register({ command: { id: 'sidebar:close-account-menu', name: i18n.t('cmd.closeAccountMenu') }, hotkeys: [{ modifiers: [], key: 'Escape' }] });
        cm.register({ command: { id: 'sidebar:enter', name: i18n.t('cmd.sidebarEnter') }, hotkeys: [{ modifiers: [], key: 'Enter' }] });
        cm.register({ command: { id: 'sidebar:arrow-up', name: i18n.t('cmd.sidebarArrowUp') }, hotkeys: [{ modifiers: [], key: 'ArrowUp' }] });
        cm.register({ command: { id: 'sidebar:arrow-down', name: i18n.t('cmd.sidebarArrowDown') }, hotkeys: [{ modifiers: [], key: 'ArrowDown' }] });
        cm.register({ command: { id: 'sidebar:delete-folder', name: i18n.t('cmd.sidebarDeleteFolder') }, hotkeys: [{ modifiers: ['Mod'], key: 'Delete' }, { modifiers: ['Mod'], key: 'Backspace' }] });
        cm.register({ command: { id: 'sidebar:toggle-group', name: i18n.t('cmd.sidebarToggleGroup') }, hotkeys: [{ modifiers: [], key: 'ArrowLeft' }, { modifiers: [], key: 'ArrowRight' }] });

        // 共用 sidebar:dragStart — 統一設 dataTransfer
        this.registerEvent('sidebar:dragStart', ({ item, event: e }: {
            item: BaseItem; sectionId: string; event: React.DragEvent;
            isGroup?: boolean; children?: BaseItem[];
        }) => {
            e.dataTransfer.setData('application/cubelv-item', JSON.stringify(item));
            e.dataTransfer.setData('sourceType', 'sidebar');
        });

        // EventBus: Sidebar項目拖曳到 AICommander 附加
        this.registerEvent('drop:ai-commander:sidebar', (e: any, addAttachment: any, attachedItems: any, inputAreaRef: any) => {
            const itemStr = e.dataTransfer.getData('application/cubelv-item');
            if (!itemStr) return;
            try {
                const item = JSON.parse(itemStr);
                // 排除已經附加的
                if (attachedItems.some((i: any) => i.id === item.id && i.type === 'folder')) return;
                
                // 附加到 AI Commander
                addAttachment(item);
                
                if (inputAreaRef?.current?.closeSaveMode) {
                    inputAreaRef.current.closeSaveMode();
                }
            } catch (err) {
                console.error('AI Commander drop failed for sidebar item:', err);
            }
        });

        // 共用 sidebar:drop — 排序演算法 + 結構規則驗證
        this.registerEvent('sidebar:drop', async ({ sectionId, draggedItem, targetItem, position, items }: {
            sectionId: string; draggedItem: BaseItem; targetItem: BaseItem;
            position: DropPosition; items: BaseItem[]; event: React.DragEvent;
        }) => {
            if (!draggedItem || !targetItem || !position || !items) return;

            // 防止自己拖到自己
            if (draggedItem.id === targetItem.id) return;

            // 防止循環引用：不能把父 folder 拖到自己的子孫裡
            if (isAncestorOf(draggedItem.id, targetItem.id, items)) return;

            if (position === 'inside') {
                // ===== 結構規則：folder 不能同時包含 folder 和 note =====
                // sidebar items 只有 folders，所以這裡是 folder → folder 拖曳
                const targetHasChildFolders = items.some(i => (i as any).parentID === targetItem.id);

                if (targetHasChildFolders) {
                    // 目標已是群組（已有子 folder）→ 直接加入群組
                    const oldParentID = (draggedItem as any).parentID || null;
                    const updated = { ...draggedItem, parentID: targetItem.id };
                    await useItemStore.getState().upsertItem(updated, { needSync: true });
                    // 移入新群組後，檢查原群組是否變空
                    if (oldParentID && oldParentID !== targetItem.id) {
                        const allSameType = useItemStore.getState().getByType(draggedItem.itemType);
                        const remaining = allSameType.filter((f: any) => f.parentID === oldParentID);
                        if (remaining.length === 0) {
                            await useItemStore.getState().removeItems([oldParentID], { needSync: true });
                        }
                    }
                } else {
                    // 目標是葉節點 folder → 開 Sidebar 自己的 dialog 讓用戶命名新群組
                    useDialogStore.getState().open(DIALOG_KEY, {
                        draggedFolder: draggedItem,
                        targetFolder: targetItem,
                    });
                }
                return;
            }

            const getOrder = (f: any) => {
                const o = Number(f.orderAt) || 0;
                return o !== 0 ? o : (Number(f.createdAt) || 0);
            };
            const newParentID = (targetItem as any).parentID || null;

            const siblings = items
                .filter((f: any) => f.id !== draggedItem.id && ((f as any).parentID || null) === (newParentID || null))
                .map((f: any) => ({ id: f.id, _orderAt: getOrder(f) }))
                .sort((a, b) => a._orderAt - b._orderAt);

            const idx = siblings.findIndex(s => s.id === targetItem.id);
            const targetOrder = siblings[idx]?._orderAt ?? 0;

            let newOrderAt: number;
            if (position === 'above') {
                // 要在 target 上方 → orderAt 要比 target 小
                newOrderAt = idx > 0 ? (siblings[idx - 1]._orderAt + targetOrder) / 2 : targetOrder - 1000;
            } else {
                // 要在 target 下方 → orderAt 要比 target 大
                newOrderAt = idx < siblings.length - 1 ? (targetOrder + siblings[idx + 1]._orderAt) / 2 : targetOrder + 1000;
            }

            const oldParentID = (draggedItem as any).parentID || null;
            const updated = { ...draggedItem, parentID: newParentID, orderAt: newOrderAt };
            await useItemStore.getState().upsertItem(updated, { needSync: true });
            // 移動完成後，檢查原群組是否變空
            if (oldParentID && oldParentID !== newParentID) {
                const allSameType = useItemStore.getState().getByType(draggedItem.itemType);
                const remaining = allSameType.filter((f: any) => f.parentID === oldParentID);
                if (remaining.length === 0) {
                    await useItemStore.getState().removeItems([oldParentID], { needSync: true });
                }
            }
        });

        // 監聽 folder 類型 item 變化，自動清理變空的 folderGroup
        // 動態從 sidebar registry 取得 folder types，不硬編碼任何 itemType
        let prevFolderSnapshots = new Map<string, BaseItem[]>();
        const getFolderTypes = (): string[] => {
            const types = new Set<string>();
            for (const data of useSidebarRegistry.getState().sectionDataCache.values()) {
                for (const item of data.items) {
                    if (item.itemType) types.add(item.itemType);
                }
            }
            return [...types];
        };
        this.register(useItemStore.subscribe((state) => {
            for (const ft of getFolderTypes()) {
                const current = state.getByType(ft);
                const prev = prevFolderSnapshots.get(ft);
                if (current === prev) continue;
                prevFolderSnapshots.set(ft, current);
                if (!prev) continue;
                // 找出被移除的 folder（舊有但新沒有的）
                const currentIds = new Set(current.map(i => i.id));
                const removed = prev.filter(i => !currentIds.has(i.id));
                if (removed.length === 0) continue;
                // 檢查被移除 folder 的原 parent 是否變成空群組
                const parentIds = new Set<string>();
                for (const r of removed) {
                    const pid = (r as any).parentID;
                    if (pid && !removed.some(rem => rem.id === pid)) {
                        parentIds.add(pid);
                    }
                }
                for (const pid of parentIds) {
                    const parent = current.find(f => f.id === pid);
                    if (!parent) continue;
                    const children = current.filter((f: any) => f.parentID === pid);
                    if (children.length === 0) {
                        // 延遲執行：確保 _inHandler 已重置，handler 能正確執行
                        // 連鎖效應：刪除此群組後會再觸發 subscribe，逐層清理
                        setTimeout(() => {
                            useItemStore.getState().removeItems([pid], { needSync: true });
                        }, 0);
                    }
                }
            }
        }));
    }
}

registerPluginClass(SidebarPlugin, '側邊欄', {
    alwaysLoaded: true,
    descriptionKey: 'modulesSidebarDesc',
    setupI18n: () => registerPluginLocales('SidebarPlugin', { 'en': sidebarEn, 'zh-Hant': sidebarZhHant, 'ja': sidebarJa }),
});
