import React from 'react';
import DefaultAvatar from '../../../assets/default_avatar.svg?react';
import { useTranslation } from 'react-i18next';

const UserAvatar = ({ avatarUrl, className, ...props }) => {
  const { t } = useTranslation();
  const [imageError, setImageError] = React.useState(false);

  // 當 avatarUrl 改變時，重置錯誤狀態
  React.useEffect(() => {
    setImageError(false);
  }, [avatarUrl]);

  if (avatarUrl && avatarUrl.trim() !== '' && !imageError) {
    return (
      <img
        key={avatarUrl}
        src={avatarUrl}
        className={className}
        alt={t('userAvatar')}
        onError={() => {
          // 如果圖片載入失敗，設置錯誤狀態
          setImageError(true);
        }}
        style={{
          borderRadius: '50%',
          objectFit: 'cover',
          display: 'block'
        }}
        {...props}
      />
    );
  }

  return <DefaultAvatar className={className} {...props} />;
};

export default UserAvatar; 
