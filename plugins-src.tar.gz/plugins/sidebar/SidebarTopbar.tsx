import React, { useCallback, useState } from 'react';
import ArrowLeftIcon from '../../../assets/icon_arrow_left_24.svg?react';
import ArrowRightIcon from '../../../assets/icon_arrow_right_24.svg?react';
import PlusIcon from '../../../assets/icon_plus_24.svg?react';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTranslation } from 'react-i18next';
import { isWeb } from '../../../utils/platform';
import { useSidebarRegistry } from './sidebarStore';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import { CustomToolbar, ToolbarButton } from '../../common/CustomToolbar';
import NotificationBell from '../../common/NotificationBell';
import UserAvatar from './UserAvatar';
import ConnectionStatusDot from './ConnectionStatusDot';
import { useIsMobileView } from '../../../hooks/useWindowSize';


interface SidebarTopbarProps {
  onAddFolder?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  avatarUrl?: string;
  onAvatarClick?: (e: React.MouseEvent) => void;
}

const SidebarTopbar = ({ onAddFolder, avatarUrl, onAvatarClick }: SidebarTopbarProps) => {
  const { t } = useTranslation();
  const addFolderItems = useSidebarRegistry(state => state.getAddFolderItems());
  const [addMenu, setAddMenu] = useState({ visible: false, x: 0, y: 0 });
  const isMobileView = useIsMobileView();

  const canGoBack = useSelectedItemsStore(state => state.canGoBack);
  const canGoForward = useSelectedItemsStore(state => state.canGoForward);
  const navigateHistoryBack = useSelectedItemsStore(state => state.navigateHistoryBack);
  const navigateHistoryForward = useSelectedItemsStore(state => state.navigateHistoryForward);

  const handleBack = useCallback(() => {
    navigateHistoryBack();
  }, [navigateHistoryBack]);

  const handleForward = useCallback(() => {
    navigateHistoryForward();
  }, [navigateHistoryForward]);

  const compactMode = isWeb || isMobileView;
  const hasAddItems = addFolderItems.length > 0;

  // web/mobile：按鈕放左邊，最左插入 avatar
  if (compactMode) {
    const leftButtons: ToolbarButton[] = [
      {
        node: (
          <div className="sidebar-topbar-avatar" onClick={onAvatarClick}>
            <UserAvatar avatarUrl={avatarUrl || ''} className="user-avatar-button" />
            <ConnectionStatusDot />
          </div>
        ),
      },
      { node: <NotificationBell /> },
    ];

    if (hasAddItems || onAddFolder) {
      leftButtons.push({
        node: (
          <button
            className="custom-toolbar-button"
            onClick={hasAddItems
              ? (e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  setAddMenu({ visible: true, x: rect.left, y: rect.bottom + 8 });
                }
              : onAddFolder
            }
            title={t('newFolder')}
            tabIndex={-1}
          >
            <PlusIcon />
          </button>
        ),
      });
    }

    return (
      <div className="sidebar-top">
        <CustomToolbar
          left={{ buttons: leftButtons }}
          height={50}
        />

        {addMenu.visible && (
          <PopupMenu
            x={addMenu.x}
            y={addMenu.y}
            onClose={() => setAddMenu({ visible: false, x: 0, y: 0 })}
          >
            {addFolderItems.map(item => (
              <PopupMenuItem
                key={item.actionText}
                icon={item.icon}
                onClick={() => {
                  item.onClick();
                  setAddMenu({ visible: false, x: 0, y: 0 });
                }}
              >
                {item.actionText}
              </PopupMenuItem>
            ))}
          </PopupMenu>
        )}
      </div>
    );
  }

  // Electron 桌面版：按鈕放右邊，含 < > 導航
  const rightButtons: ToolbarButton[] = [
    { node: <NotificationBell /> },
  ];

  if (hasAddItems || onAddFolder) {
    rightButtons.push({
      node: (
        <button
          className="custom-toolbar-button"
          onClick={hasAddItems
            ? (e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                setAddMenu({ visible: true, x: rect.left, y: rect.bottom + 8 });
              }
            : onAddFolder
          }
          title={t('newFolder')}
          tabIndex={-1}
        >
          <PlusIcon />
        </button>
      ),
    });
  }

  rightButtons.push(
    { icon: <ArrowLeftIcon />, onClick: handleBack, disabled: !canGoBack, title: t('previousPage') },
    { icon: <ArrowRightIcon />, onClick: handleForward, disabled: !canGoForward, title: t('nextPage') },
  );

  return (
    <div className="sidebar-top">
      <CustomToolbar
        right={{ buttons: rightButtons }}
      />

      {addMenu.visible && (
        <PopupMenu
          x={addMenu.x}
          y={addMenu.y}
          onClose={() => setAddMenu({ visible: false, x: 0, y: 0 })}
        >
          {addFolderItems.map(item => (
            <PopupMenuItem
              key={item.actionText}
              icon={item.icon}
              onClick={() => {
                item.onClick();
                setAddMenu({ visible: false, x: 0, y: 0 });
              }}
            >
              {item.actionText}
            </PopupMenuItem>
          ))}
        </PopupMenu>
      )}
    </div>
  );
};

export default SidebarTopbar;
