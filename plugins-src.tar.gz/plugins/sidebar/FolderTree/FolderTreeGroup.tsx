// ===== FolderTreeGroup — 可折疊資料夾群組渲染 =====

import React from 'react';
import ArrowIcon from '../../../../assets/icon_arrowchevron_up_24.svg?react';
import FolderTreeItem from './FolderTreeItem';
import type { FolderTreeConfig, FolderTreeNode } from './types';

interface FolderTreeGroupProps {
  node: FolderTreeNode;
  config: FolderTreeConfig;
  depth?: number;
  parentGroup?: FolderTreeNode | null;
  dataAttrKey?: string;
}

const FolderTreeGroup: React.FC<FolderTreeGroupProps> = ({
  node,
  config,
  depth = 0,
  parentGroup = null,
  dataAttrKey,
}) => {
  const {
    isSelected,
    onContextMenu,
    drag,
    getDisplayName,
    collapsedGroups,
    onToggleGroup,
    groupKeyPrefix = 'group',
  } = config;

  const groupKey = `${groupKeyPrefix}-${node.id}`;
  const isCollapsed = collapsedGroups.has(groupKey);

  const selected = isSelected(node);
  const displayName = getDisplayName ? getDisplayName(node.name) : node.name;

  const isDropTarget = drag?.dropTarget?.id === node.id;
  const dropIndicatorClass = isDropTarget ? `drop-${drag?.dropPosition}` : '';
  const depthStyle: React.CSSProperties = depth > 0 ? { paddingLeft: `${8 + depth * 16}px` } : {};

  const dragProps = drag
    ? {
        draggable: true,
        onDragStart: (e: React.DragEvent) => drag.onDragStart(e, node, parentGroup),
        onDragEnd: (e: React.DragEvent) => drag.onDragEnd(e),
        onDragOver: (e: React.DragEvent) => drag.onDragOver(e, node, parentGroup),
        onDrop: (e: React.DragEvent) => drag.onDrop(e),
      }
    : {};

  const dataAttr = dataAttrKey
    ? { [dataAttrKey]: node.id }
    : { 'data-folder-id': node.id };

  return (
    <div className="folder-group">
      <div
        className={`folder ${selected ? 'selected' : ''} ${dropIndicatorClass} ${isCollapsed ? 'collapsed' : ''}`.trim()}
        onClick={(e) => {
          e.stopPropagation();
          onToggleGroup(groupKey);
        }}
        onContextMenu={onContextMenu ? (e) => onContextMenu(e, node, true) : undefined}
        {...dragProps}
        {...dataAttr}
      >
        <span className="folder-name" style={depthStyle}>
          <ArrowIcon className="arrow-icon" />
          <div
            className={node.isTemp ? 'temp-folder-name' : ''}
            style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}
          >
            {displayName}
          </div>
        </span>
      </div>

      {!isCollapsed && (
        <div className="folder-group-content">
          {node.children?.map(child => {
            if (child.children && child.children.length > 0) {
              return (
                <FolderTreeGroup
                  key={child.id}
                  node={child}
                  config={config}
                  depth={depth + 1}
                  parentGroup={node}
                  dataAttrKey={dataAttrKey}
                />
              );
            }
            return (
              <FolderTreeItem
                key={child.id}
                node={child}
                config={config}
                depth={depth + 1}
                parentGroup={node}
                dataAttrKey={dataAttrKey}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

export default FolderTreeGroup;
