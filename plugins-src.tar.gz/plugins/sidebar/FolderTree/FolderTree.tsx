// ===== FolderTree — 通用資料夾樹容器 =====
//
// 接收已建構好的 tree nodes + config，渲染整棵資料夾樹。
// prefixItems / suffixItems 用於插入特殊項目（inbox、trash、todo虛擬項目等）。

import React from 'react';
import FolderTreeItem from './FolderTreeItem';
import FolderTreeGroup from './FolderTreeGroup';
import type { FolderTreeConfig, FolderTreeNode } from './types';

interface FolderTreeProps {
  nodes: FolderTreeNode[];
  config: FolderTreeConfig;
  /** tree 最前面插入的自訂節點（如 inbox、today/preview/completed 等） */
  prefixItems?: React.ReactNode;
  /** tree 最後面插入的自訂節點（如 trash） */
  suffixItems?: React.ReactNode;
  className?: string;
  /** 各節點的 data attribute key（如 'data-folder-id'、'data-sidebar-item'） */
  dataAttrKey?: string;
}

const FolderTree: React.FC<FolderTreeProps> = ({
  nodes,
  config,
  prefixItems,
  suffixItems,
  className = '',
  dataAttrKey,
}) => {
  return (
    <div className={`folders-container ${className}`.trim()}>
      {prefixItems}
      {nodes.map(node => {
        if (node.children && node.children.length > 0) {
          return (
            <FolderTreeGroup
              key={node.id}
              node={node}
              config={config}
              dataAttrKey={dataAttrKey}
            />
          );
        }
        return (
          <FolderTreeItem
            key={node.id}
            node={node}
            config={config}
            dataAttrKey={dataAttrKey}
          />
        );
      })}
      {suffixItems}
    </div>
  );
};

export default FolderTree;
