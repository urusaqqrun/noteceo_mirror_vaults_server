// ===== FolderGroup — 可折疊 BaseItem 群組渲染 =====

import React, { useContext } from 'react';
import ArrowIcon from '../../../../assets/icon_arrowchevron_up_24.svg?react';
import EditIcon from '../../../../assets/icon_edit_24.svg?react';
import i18n from '../../../../i18n/config';
import FolderItem from './FolderItem';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useCollapsedGroupsStore } from '../../../../Store/uiStore';
import { eventBus } from '../../../../Store/eventBus';
import { DragContext } from './DragContext';
import type { BaseItem } from '../../../../types/item';
import type { SidebarSectionData } from '../sidebarStore';
import { ShareMemberThumbnailList } from '../../../common/share/ShareMemberThumbnailList';
import { getEffectivePermission, isSharedItem } from '../../../../utils/shareUtils';


interface FolderGroupProps {
  item: BaseItem;
  children: BaseItem[];
  getChildren: (parent: BaseItem) => BaseItem[];
  adapters: Pick<SidebarSectionData, 'getCount' | 'renderIcon' | 'getDisplayName'>;
  sectionId: string;
  depth?: number;
  onItemSelect?: (id: string) => void;
  selectedId?: string;
  forceExpanded?: boolean;
}

const FolderGroup: React.FC<FolderGroupProps> = ({
  item,
  children,
  getChildren,
  adapters,
  sectionId,
  depth = 0,
  onItemSelect,
  selectedId,
  forceExpanded = false,
}) => {
  const path = useSelectedItemsStore(s => s.path);
  const lastFolder = [...path].reverse().find(p => p.itemType?.includes('FOLDER') || p.id === item.id);
  const selected = onItemSelect ? false : (lastFolder?.id === item.id); // group 不可選，不顯示 selected
  const drag = useContext(DragContext);

  const groupKey = `${sectionId}-${item.id}`;
  const storeCollapsed = useCollapsedGroupsStore(s => s.collapsedGroups.has(groupKey));
  const collapsed = forceExpanded ? false : storeCollapsed;
  const toggleGroup = useCollapsedGroupsStore(s => s.toggleGroup);

  const depthStyle: React.CSSProperties = depth > 0 ? { paddingLeft: `${8 + depth * 16}px` } : {};

  const handleContextMenu = (e: React.MouseEvent) => {
    if (onItemSelect) return;
    e.preventDefault();
    e.stopPropagation();
    eventBus.emit('contextMenu', { item, event: e });
  };

  const handleHeaderClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // group header 只負責展開/收合，不選中（selector 模式也一樣）
    toggleGroup(groupKey);
  };

  // ---- Drag handlers (group header) ----
  const handleDragStart = (e: React.DragEvent) => {
    if (!drag) return;
    // 非 owner 不可拖曳共享資料夾
    const perm = getEffectivePermission(item);
    if (perm && perm !== 'owner') return;
    e.stopPropagation();
    drag.setDraggedItem(item);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData(`sidebardropsection:${drag.sectionId}`, '');
    eventBus.emit('sidebar:dragStart', { item, sectionId: drag.sectionId, event: e, isGroup: true, children });
    eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: i18n.t('dragToAttach', '拖曳放置後附加') });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.stopPropagation();
    if (!drag) return;

    // 跨 section 守衛：有 sidebardropsection: 但不包含本 section → 拒絕
    const hasConstraint = e.dataTransfer.types.some(t => t.startsWith('sidebardropsection:'));
    if (hasConstraint && !e.dataTransfer.types.includes(`sidebardropsection:${drag.sectionId}`)) {
      return;
    }

    // 外部拖入（NoteList / TodoList / NoteEditor）
    if (!drag.draggedItem) {
      if (e.dataTransfer.types.includes('sourcetype')) {
        e.preventDefault();
        // 結構規則：如果目標 folder 已有子 folder，不允許外部 note drop inside
        const targetHasChildFolders = drag.items.some(i => i.parentID === item.id);
        if (!targetHasChildFolders) {
          drag.setDrop(item, 'inside');
        }
      }
      return;
    }

    e.preventDefault();

    // 共用資料夾不可被其他資料夾互動
    if (isSharedItem(item)) return;

    if (drag.draggedItem.id === item.id) {
      drag.setDrop(null, null);
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = ((e.clientY - rect.top) / rect.height) * 100;
    if (pct < 33) drag.setDrop(item, 'above');
    else if (pct > 66) drag.setDrop(item, 'below');
    else drag.setDrop(item, 'inside');
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!drag) return;

    // 外部拖入：從 dataTransfer 取 sourceType，發 drop:sidebar-folder:{sourceType} 事件
    const externalSourceType = e.dataTransfer.getData('sourceType');
    if (!drag.draggedItem && externalSourceType) {
      // 拖曳來源若有 sidebardropsection:{sectionId}，只允許對應 section 接收
      const hasConstraint = e.dataTransfer.types.some(t => t.startsWith('sidebardropsection:'));
      if (hasConstraint && !e.dataTransfer.types.includes(`sidebardropsection:${drag.sectionId}`)) {
        drag.clearDrag();
        return;
      }
      eventBus.emit(`drop:sidebar-folder:${externalSourceType}` as any, item.id, e);
      drag.clearDrag();
      return;
    }

    // sidebar 內部拖曳
    if (!drag.draggedItem || !drag.dropTarget || !drag.dropPosition) return;
    eventBus.emit('sidebar:drop', {
      sectionId: drag.sectionId,
      draggedItem: drag.draggedItem,
      targetItem: drag.dropTarget,
      position: drag.dropPosition,
      items: drag.items,
      event: e,
    });
    drag.clearDrag();
  };

  const handleDragLeave = (e: React.DragEvent) => {
    if (!drag || drag.dropTarget?.id !== item.id) return;
    if (e.currentTarget.contains(e.relatedTarget as Node)) return;
    drag.setDrop(null, null);
  };

  const handleDragEnd = () => {
    drag?.clearDrag();
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  };

  const isDropTarget = drag?.dropTarget?.id === item.id;
  const dropClass = isDropTarget && drag?.dropPosition ? `drop-${drag.dropPosition}` : '';

  return (
    <div className="folder-group">
      <div
        className={`folder ${selected ? 'selected' : ''} ${collapsed ? 'collapsed' : ''} ${dropClass}`.trim()}
        onClick={handleHeaderClick}
        onContextMenu={handleContextMenu}
        draggable={!onItemSelect && (() => { const perm = getEffectivePermission(item); return !perm || perm === 'owner'; })()}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onDragEnd={handleDragEnd}
        data-item-id={item.id}
      >
        <span className="folder-name" style={depthStyle}>
          <ArrowIcon className="arrow-icon" />
          <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto', minWidth: 0 }}>
            {adapters.getDisplayName ? adapters.getDisplayName(item) : item.name}
          </div>
          <ShareMemberThumbnailList itemId={item.id} permissions={item._permissions || []} size="small" maxDisplay={5} clickable={false} />
        </span>
      </div>

      {!collapsed && (
        <div className="folder-group-content">
          {children.map(child => {
            const grandChildren = getChildren(child);
            if (grandChildren.length > 0) {
              return (
                <FolderGroup
                  key={child.id}
                  item={child}
                  children={grandChildren}
                  getChildren={getChildren}
                  adapters={adapters}
                  sectionId={sectionId}
                  depth={depth + 1}
                  onItemSelect={onItemSelect}
                  selectedId={selectedId}
                  forceExpanded={forceExpanded}
                />
              );
            }
            return (
              <FolderItem
                key={child.id}
                item={child}
                adapters={adapters}
                depth={depth + 1}
                onItemSelect={onItemSelect}
                selectedId={selectedId}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

export default FolderGroup;
