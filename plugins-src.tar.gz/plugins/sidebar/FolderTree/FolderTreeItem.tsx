// ===== FolderTreeItem — 單個資料夾節點渲染 =====

import React from 'react';
import NotebookFolderIcon from '../../../../assets/icon_notebook_folder_24.svg?react';
import type { FolderTreeConfig, FolderTreeNode } from './types';

interface FolderTreeItemProps {
  node: FolderTreeNode;
  config: FolderTreeConfig;
  depth?: number;
  parentGroup?: FolderTreeNode | null;
  dataAttrKey?: string;
}

const FolderTreeItem: React.FC<FolderTreeItemProps> = ({
  node,
  config,
  depth = 0,
  parentGroup = null,
  dataAttrKey,
}) => {
  const {
    isSelected,
    onSelect,
    onContextMenu,
    drag,
    getCount,
    renderIcon,
    getDisplayName,
    showCount = true,
  } = config;

  const selected = isSelected(node);
  const displayName = getDisplayName ? getDisplayName(node.name) : node.name;
  const count = getCount?.(node);

  const isDropTarget = drag?.dropTarget?.id === node.id;
  const dropIndicatorClass = isDropTarget ? `drop-${drag?.dropPosition}` : '';
  const depthStyle: React.CSSProperties = depth > 0 ? { paddingLeft: `${8 + depth * 16}px` } : {};

  const dragProps = drag
    ? {
        draggable: true,
        onDragStart: (e: React.DragEvent) => drag.onDragStart(e, node, parentGroup),
        onDragEnd: (e: React.DragEvent) => drag.onDragEnd(e),
        onDragOver: (e: React.DragEvent) => drag.onDragOver(e, node, parentGroup),
        onDrop: (e: React.DragEvent) => drag.onDrop(e),
      }
    : {};

  const dataAttr = dataAttrKey
    ? { [dataAttrKey]: node.id }
    : { 'data-folder-id': node.id };

  const iconNode = renderIcon
    ? renderIcon(node)
    : <NotebookFolderIcon className="folder-icon" />;

  return (
    <div
      className={`folder ${selected ? 'selected' : ''} ${dropIndicatorClass}`.trim()}
      onClick={() => onSelect(node)}
      onContextMenu={onContextMenu ? (e) => onContextMenu(e, node, false) : undefined}
      {...dragProps}
      {...dataAttr}
    >
      <span className="folder-name" style={depthStyle}>
        {iconNode}
        <div
          className={node.isTemp ? 'temp-folder-name' : ''}
          style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}
        >
          {displayName}
        </div>
        {showCount && count !== null && count !== undefined && (
          <span>{count}</span>
        )}
      </span>
    </div>
  );
};

export default FolderTreeItem;
