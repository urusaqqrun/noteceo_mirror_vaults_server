import { createContext, useContext } from 'react';
import type { BaseItem } from '../../../../types/item';

export type DropPosition = 'above' | 'below' | 'inside';

export interface DragState {
  draggedItem: BaseItem | null;
  dropTarget: BaseItem | null;
  dropPosition: DropPosition | null;
  sectionId: string;
  items: BaseItem[];
}

export interface DragActions {
  setDraggedItem: (item: BaseItem | null) => void;
  setDrop: (target: BaseItem | null, position: DropPosition | null) => void;
  clearDrag: () => void;
}

export const DragContext = createContext<(DragState & DragActions) | null>(null);

export function useDrag() {
  const ctx = useContext(DragContext);
  if (!ctx) throw new Error('useDrag must be used within DragContext.Provider');
  return ctx;
}
