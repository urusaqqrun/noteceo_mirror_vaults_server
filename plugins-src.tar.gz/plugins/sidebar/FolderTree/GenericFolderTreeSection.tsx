// ===== GenericFolderTreeSection — 通用 tree renderer =====
//
// 從 SidebarSectionData 的 items 用 parentID 自動建樹。
// prefixItems / suffixItems 用 FolderItem 渲染（不可拖曳）。
// 管理拖曳狀態，透過 DragContext 共享給子元件。

import React, { useMemo, useState, useCallback } from 'react';
import FolderItem from './FolderItem';
import FolderGroup from './FolderGroup';
import { DragContext, type DragState, type DropPosition } from './DragContext';
import type { BaseItem } from '../../../../types/item';
import type { SidebarSectionData } from '../sidebarStore';
import { isSharedItem } from '../../../../utils/shareUtils';

interface GenericFolderTreeSectionProps {
  data: SidebarSectionData;
  sectionId: string;
  /** selector 模式：點擊回傳 id，不導航 */
  onItemSelect?: (id: string) => void;
  selectedId?: string;
  forceExpanded?: boolean;
}

const GenericFolderTreeSection: React.FC<GenericFolderTreeSectionProps> = ({ data, sectionId, onItemSelect, selectedId, forceExpanded }) => {
  const { items, prefixItems, suffixItems, separatePrefix, separateSuffix, ...adapters } = data;

  const { rootItems, getChildren } = useMemo(() => {
    // orderAt 為 0 或不存在時，用 createdAt 作為排序依據
    const getOrder = (item: BaseItem) => {
      const order = Number((item as any).orderAt) || 0;
      if (order !== 0) return order;
      return Number((item as any).createdAt) || 0;
    };
    const sortByOrder = (a: BaseItem, b: BaseItem) => getOrder(a) - getOrder(b);
    const itemMap = new Map(items.map(i => [i.id, i]));
    const sorted = items.filter(i => !i.parentID || !itemMap.has(i.parentID)).sort(sortByOrder);
    const mine = sorted.filter(i => !isSharedItem(i));
    const shared = sorted.filter(i => isSharedItem(i));
    const roots = [...mine, ...shared];
    const children = (parent: BaseItem) => items.filter(i => i.parentID === parent.id).sort(sortByOrder);
    return { rootItems: roots, getChildren: children };
  }, [items]);

  const [dragState, setDragState] = useState<DragState>({
    draggedItem: null,
    dropTarget: null,
    dropPosition: null,
    sectionId,
    items,
  });

  React.useEffect(() => {
    setDragState(prev => ({ ...prev, items }));
  }, [items]);

  const setDraggedItem = useCallback((item: BaseItem | null) => {
    setDragState(prev => ({ ...prev, draggedItem: item }));
  }, []);

  const setDrop = useCallback((target: BaseItem | null, position: DropPosition | null) => {
    setDragState(prev => ({ ...prev, dropTarget: target, dropPosition: position }));
  }, []);

  const clearDrag = useCallback(() => {
    setDragState(prev => ({ ...prev, draggedItem: null, dropTarget: null, dropPosition: null }));
  }, [sectionId]);

  const ctxValue = useMemo(() => ({
    ...dragState,
    setDraggedItem,
    setDrop,
    clearDrag,
  }), [dragState, setDraggedItem, setDrop, clearDrag]);

  const selectorMode = !!onItemSelect;
  const itemProps = { adapters, onItemSelect, selectedId, draggable: !selectorMode };

  return (
    <DragContext.Provider value={ctxValue}>
      <div className="folders-container">
        {prefixItems?.map(item => (
          <FolderItem key={item.id} item={item} {...itemProps} draggable={false} />
        ))}
        {separatePrefix && <div className="sidebar-separator" />}
        {rootItems.map(item => {
          const children = getChildren(item);
          if (children.length > 0) {
            return (
              <FolderGroup
                key={item.id}
                item={item}
                children={children}
                getChildren={getChildren}
                adapters={adapters}
                sectionId={sectionId}
                onItemSelect={onItemSelect}
                selectedId={selectedId}
                forceExpanded={forceExpanded}
              />
            );
          }
          return <FolderItem key={item.id} item={item} {...itemProps} />;
        })}
        {separateSuffix && <div className="sidebar-separator" />}
        {suffixItems?.map(item => (
          <FolderItem key={item.id} item={item} {...itemProps} draggable={false} />
        ))}
      </div>
    </DragContext.Provider>
  );
};

export default GenericFolderTreeSection;
