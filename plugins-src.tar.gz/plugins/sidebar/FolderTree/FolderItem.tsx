// ===== FolderItem — 單個 BaseItem 節點渲染 =====

import React, { useContext } from 'react';
import NotebookFolderIcon from '../../../../assets/icon_notebook_folder_24.svg?react';
import EditIcon from '../../../../assets/icon_edit_24.svg?react';
import i18n from '../../../../i18n/config';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { eventBus } from '../../../../Store/eventBus';
import { DragContext } from './DragContext';
import type { BaseItem } from '../../../../types/item';
import type { SidebarSectionData } from '../sidebarStore';
import { useItemStore } from '../../../../Store/itemStore';
import { getEffectivePermission, isSharedItem } from '../../../../utils/shareUtils';
import { ShareMemberThumbnailList } from '../../../common/share/ShareMemberThumbnailList';

interface FolderItemProps {
  item: BaseItem;
  adapters: Pick<SidebarSectionData, 'getCount' | 'renderIcon' | 'getDisplayName'>;
  depth?: number;
  draggable?: boolean;
  onItemSelect?: (id: string) => void;
  selectedId?: string;
}

function createDragPreview(text: string, e: React.DragEvent) {
  const el = document.createElement('div');
  el.textContent = text;
  const root = getComputedStyle(document.documentElement);
  const bg = root.getPropertyValue('--sidebarBackground').trim() || '#ffffff';
  const on = root.getPropertyValue('--on').trim() || '#000000';
  const mobile = window.innerWidth <= 768;
  Object.assign(el.style, {
    position: 'absolute', top: '-9999px', left: '-9999px',
    padding: '6px 12px', borderRadius: '99px',
    background: mobile ? 'transparent' : bg,
    border: mobile ? 'none' : `1px solid color-mix(in srgb, ${on} 16%, transparent)`,
    color: mobile ? 'gray' : `color-mix(in srgb, ${on} 60%, transparent)`,
    fontSize: '13px', fontFamily: 'inherit', whiteSpace: 'nowrap',
  });
  document.body.appendChild(el);
  const rect = (e.target as HTMLElement).closest('.folder')?.getBoundingClientRect();
  if (rect) {
    e.dataTransfer.setDragImage(el, e.clientX - rect.left, e.clientY - rect.top);
  }
  requestAnimationFrame(() => document.body.removeChild(el));
}

const FolderItem: React.FC<FolderItemProps> = ({
  item,
  adapters,
  depth = 0,
  draggable = true,
  onItemSelect,
  selectedId,
}) => {
  const path = useSelectedItemsStore(s => s.path);
  const lastFolder = [...path].reverse().find(p => p.itemType?.includes('FOLDER') || p.id === item.id);
  const selected = onItemSelect ? selectedId === item.id : (lastFolder?.id === item.id);
  const drag = useContext(DragContext);

  const countResult = adapters.getCount?.(item) ?? null;
  const depthStyle: React.CSSProperties = depth > 0 ? { paddingLeft: `${8 + depth * 16}px` } : {};

  const iconNode = adapters.renderIcon
    ? adapters.renderIcon(item)
    : <NotebookFolderIcon className="folder-icon" />;

  const handleClick = () => {
    if (onItemSelect) {
      onItemSelect(item.id);
      return;
    }
    useSelectedItemsStore.getState().setSelectedItems([item]);
    eventBus.emit('sidebar:folder-select', { folderId: item.id });
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    if (onItemSelect) return;
    e.preventDefault();
    e.stopPropagation();
    eventBus.emit('contextMenu', { item, event: e });
  };

  // ---- Drag handlers ----
  const handleDragStart = (e: React.DragEvent) => {
    if (!draggable || !drag) return;
    // 非 owner 不可拖曳共享資料夾
    const perm = getEffectivePermission(item);
    if (perm && perm !== 'owner') return;
    e.stopPropagation();
    drag.setDraggedItem(item);
    createDragPreview(item.name || 'Untitled', e);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData(`sidebardropsection:${drag.sectionId}`, '');
    eventBus.emit('sidebar:dragStart', { item, sectionId: drag.sectionId, event: e });
    eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: i18n.t('dragToAttach', '拖曳放置後附加') });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.stopPropagation();
    if (!drag) return;

    // 跨 section 守衛：有 sidebardropsection: 但不包含本 section → 拒絕
    const hasConstraint = e.dataTransfer.types.some(t => t.startsWith('sidebardropsection:'));
    if (hasConstraint && !e.dataTransfer.types.includes(`sidebardropsection:${drag.sectionId}`)) {
      return;
    }

    // 外部拖入（NoteList / TodoList / NoteEditor）
    if (!drag.draggedItem) {
      if (e.dataTransfer.types.includes('sourcetype')) {
        e.preventDefault();
        // 結構規則：如果目標 folder 已有子 folder，不允許外部 note drop inside
        const targetHasChildFolders = drag.items.some(i => i.parentID === item.id);
        if (!targetHasChildFolders) {
          drag.setDrop(item, 'inside');
        }
      }
      return;
    }

    e.preventDefault();

    // prefix/suffix 固定項目不參與 sidebar 內部拖曳排序
    if (!draggable) return;

    // 共用資料夾不可被其他資料夾互動
    if (isSharedItem(item)) return;

    if (drag.draggedItem.id === item.id) {
      drag.setDrop(null, null);
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = ((e.clientY - rect.top) / rect.height) * 100;
    if (pct < 33) drag.setDrop(item, 'above');
    else if (pct > 66) drag.setDrop(item, 'below');
    else drag.setDrop(item, 'inside');
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!drag) return;

    // 外部拖入：從 dataTransfer 取 sourceType，發 drop:sidebar-folder:{sourceType} 事件
    const externalSourceType = e.dataTransfer.getData('sourceType');
    if (!drag.draggedItem && externalSourceType) {
      // 拖曳來源若有 sidebardropsection:{sectionId}，只允許對應 section 接收
      const hasConstraint = e.dataTransfer.types.some(t => t.startsWith('sidebardropsection:'));
      if (hasConstraint && !e.dataTransfer.types.includes(`sidebardropsection:${drag.sectionId}`)) {
        drag.clearDrag();
        return;
      }
      eventBus.emit(`drop:sidebar-folder:${externalSourceType}` as any, item.id, e);
      drag.clearDrag();
      return;
    }

    // prefix/suffix 固定項目不參與 sidebar 內部拖曳排序
    if (!draggable) {
      drag.clearDrag();
      return;
    }

    // sidebar 內部拖曳
    if (!drag.draggedItem || !drag.dropTarget || !drag.dropPosition) return;
    eventBus.emit('sidebar:drop', {
      sectionId: drag.sectionId,
      draggedItem: drag.draggedItem,
      targetItem: drag.dropTarget,
      position: drag.dropPosition,
      items: drag.items,
      event: e,
    });
    drag.clearDrag();
  };

  const handleDragLeave = (e: React.DragEvent) => {
    if (!drag || drag.dropTarget?.id !== item.id) return;
    if (e.currentTarget.contains(e.relatedTarget as Node)) return;
    drag.setDrop(null, null);
  };

  const handleDragEnd = () => {
    drag?.clearDrag();
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  };

  // Drop indicator class
  const isDropTarget = drag?.dropTarget?.id === item.id;
  const dropClass = isDropTarget && drag?.dropPosition ? `drop-${drag.dropPosition}` : '';

  const dragProps = !onItemSelect && draggable && drag ? {
    draggable: true,
    onDragStart: handleDragStart,
    onDragOver: handleDragOver,
    onDragLeave: handleDragLeave,
    onDrop: handleDrop,
    onDragEnd: handleDragEnd,
  } : {
    onDragOver: handleDragOver,
    onDragLeave: handleDragLeave,
    onDrop: handleDrop,
  };

  return (
    <div
      className={`folder ${selected ? 'selected' : ''} ${dropClass}`.trim()}
      onClick={handleClick}
      onContextMenu={handleContextMenu}
      data-item-id={item.id}
      {...dragProps}
    >
      <span className="folder-name" style={depthStyle}>
        {iconNode}
        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto', minWidth: 0 }}>
          {adapters.getDisplayName ? adapters.getDisplayName(item) : item.name}
        </div>
        {item._permissions && item._permissions.length > 1
          ? <ShareMemberThumbnailList itemId={item.id} permissions={item._permissions} size="small" maxDisplay={5} clickable={false} />
          : countResult !== null && (
            <span className={countResult.pinned ? 'count-pinned' : ''}>
              {countResult.value}
            </span>
          )
        }
      </span>
    </div>
  );
};

export default FolderItem;
