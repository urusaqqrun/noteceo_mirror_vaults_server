import React from 'react';
import { useIsConnectedStore } from '../../../Store/uiStore';
import LottieAnimation from '../../Utils/LottieAnimation';
import avatarLoadingAnimation from '../../../assets/avatar_loading.json';

const ConnectionStatusDot = () => {
  const { isConnected, isSyncing, isAuthing } = useIsConnectedStore();

  // 顯示同步動畫：當正在同步或認證時
  const showSyncAnimation = isSyncing || isAuthing;

  if (showSyncAnimation) {
    return (
      <div className="connection-status-dot syncing-dot">
        <LottieAnimation
          animationData={avatarLoadingAnimation}
          width={14}
          height={14}
          loop={true}
          autoplay={true}
        />
      </div>
    );
  }

  return (
    <div className={`connection-status-dot ${isConnected ? 'online-dot' : 'offline-dot'}`}></div>
  );
};

export default ConnectionStatusDot; 