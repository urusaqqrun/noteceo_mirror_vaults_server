// ===== TodoPlugin — 待辦插件（含 TodoList + TodoEditor）=====
//
// 掛載條件：selectedItems 最後一項的 itemType 是 TODO_FOLDER 或 TODO
// 或者 selectedItems 中有 TODO_VIRTUAL_FOLDER 類型（today/preview/completed）
//
// 面板配置：
//   centerPane1 → leaf-todolist   (todo-list，flex:1，min:240)
//   centerPane2 → leaf-todoeditor (todo-editor，size:400，min:240)

import React from 'react';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import todoEn from './locales/en.json';
import todoZhHant from './locales/zh-Hant.json';
import todoJa from './locales/ja.json';
import { useTranslation } from 'react-i18next';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTodoStore, TodoFolder, Todo } from './todoStore';
import { useItemStore } from '../../../Store/itemStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { eventBus } from '../../../Store/eventBus';
import i18n from '../../../i18n/config';
import { useCommandManager } from '../../../Store/commandManager';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import type { BaseItem } from '../../../types/item';
import { processItemContent } from '../../../utils/textUtils';

import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import NameInputDialog from '../../common/NameInputDialog';
import { CustomDialog } from '../../common/CustomDialog';
import SharingDialog from '../../common/share/SharingDialog';
import ContributorsDialog from '../../common/share/ContributorsDialog';
import { updateItemShareSettings } from '../../../utils/shareAPI';
import syncService from '../../../utils/syncService';
import { canManageMembers, canAccessSharingDialog, isAlreadyShared, canEdit, canDelete, getEffectivePermission, hasDirectPermission } from '../../../utils/shareUtils';
import TodoList from './TodoList';
import NoteEditor from '../editor/NoteEditor';
import NotebookFolderIcon from '../../../assets/icon_notebook_folder_24.svg?react';
import TodoFolderIcon from '../../../assets/icon_correct.svg?react';
import TodoTodayIcon from '../../../assets/bk_navibar_calendar_fullmonuth_26.svg?react';
import TodoInboxIcon from '../../../assets/icon_inbox_24.svg?react';
import TodoCompletedIcon from '../../../assets/icon_correct.svg?react';
import DeleteIndexDialog from './DeleteIndexDialog';
import TodoEmbedView from './TodoEmbedView';
import { useEmbedRendererRegistry } from '../../../Store/embedRendererRegistry';

import Calendar01 from '../../../assets/calendar/01.calendar.svg?react';
import Calendar02 from '../../../assets/calendar/02.calendar.svg?react';
import Calendar03 from '../../../assets/calendar/03.calendar.svg?react';
import Calendar04 from '../../../assets/calendar/04.calendar.svg?react';
import Calendar05 from '../../../assets/calendar/05.calendar.svg?react';
import Calendar06 from '../../../assets/calendar/06.calendar.svg?react';
import Calendar07 from '../../../assets/calendar/07.calendar.svg?react';
import Calendar08 from '../../../assets/calendar/08.calendar.svg?react';
import Calendar09 from '../../../assets/calendar/09.calendar.svg?react';
import Calendar10 from '../../../assets/calendar/10.calendar.svg?react';
import Calendar11 from '../../../assets/calendar/11.calendar.svg?react';
import Calendar12 from '../../../assets/calendar/12.calendar.svg?react';
import Calendar13 from '../../../assets/calendar/13.calendar.svg?react';
import Calendar14 from '../../../assets/calendar/14.calendar.svg?react';
import Calendar15 from '../../../assets/calendar/15.calendar.svg?react';
import Calendar16 from '../../../assets/calendar/16.calendar.svg?react';
import Calendar17 from '../../../assets/calendar/17.calendar.svg?react';
import Calendar18 from '../../../assets/calendar/18.calendar.svg?react';
import Calendar19 from '../../../assets/calendar/19.calendar.svg?react';
import Calendar20 from '../../../assets/calendar/20.calendar.svg?react';
import Calendar21 from '../../../assets/calendar/21.calendar.svg?react';
import Calendar22 from '../../../assets/calendar/22.calendar.svg?react';
import Calendar23 from '../../../assets/calendar/23.calendar.svg?react';
import Calendar24 from '../../../assets/calendar/24.calendar.svg?react';
import Calendar25 from '../../../assets/calendar/25.calendar.svg?react';
import Calendar26 from '../../../assets/calendar/26.calendar.svg?react';
import Calendar27 from '../../../assets/calendar/27.calendar.svg?react';
import Calendar28 from '../../../assets/calendar/28.calendar.svg?react';
import Calendar29 from '../../../assets/calendar/29.calendar.svg?react';
import Calendar30 from '../../../assets/calendar/30.calendar.svg?react';
import Calendar31 from '../../../assets/calendar/31.calendar.svg?react';

const calendarIcons = [
    Calendar01, Calendar02, Calendar03, Calendar04, Calendar05,
    Calendar06, Calendar07, Calendar08, Calendar09, Calendar10,
    Calendar11, Calendar12, Calendar13, Calendar14, Calendar15,
    Calendar16, Calendar17, Calendar18, Calendar19, Calendar20,
    Calendar21, Calendar22, Calendar23, Calendar24, Calendar25,
    Calendar26, Calendar27, Calendar28, Calendar29, Calendar30,
    Calendar31,
];

const getTodayCalendarIcon = () => calendarIcons[new Date().getDate() - 1] || Calendar01;

// ⚠️ Sidebar item 規範：所有 item（items / prefixItems / suffixItems）的 itemType 必須以 _FOLDER 結尾，否則不會顯示
function useTodoSidebarData() {
    const { t } = useTranslation();
    const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
    const todos = useItemStore(s => s.byType['TODO'] ?? []) as Todo[];
    const getTodoCount = useTodoStore(s => s.getTodoCount);
    const myMemberID = React.useMemo(() => {
        try { return JSON.parse(localStorage.getItem('userData_local') || '{}').ID || ''; } catch { return ''; }
    }, []);

    const todoInbox = React.useMemo(
        () => todoFolders.find(f => f.name === 'todoInbox'),
        [todoFolders],
    );

    const items = React.useMemo(
        () => todoFolders.filter(f => f.name !== 'todoInbox'),
        [todoFolders],
    );

    const sharedTodoCount = React.useMemo(() => {
        return todos.filter(td => {
            if (td.isDeleted) return false;
            const todoFolders = useItemStore.getState().getByType('TODO_FOLDER');
            const folderIdSet = new Set(todoFolders.map(f => f.id));
            if (td.parentID && folderIdSet.has(td.parentID)) return false;
            const parent = td.parentID ? useItemStore.getState().getById(td.parentID) : null;
            if (parent && parent.itemType === 'TODO') return false;
            const myPerm = (td as any)._permissions?.find((p: any) => p.user_id === myMemberID);
            return myPerm && myPerm.permission !== 'owner';
        }).length;
    }, [todos, myMemberID]);

    const prefixItems = React.useMemo(() => {
        const virtualToday: BaseItem = {
            id: 'today', name: t('todoToday'), itemType: 'TODO_VIRTUAL_FOLDER',
            parentID: null, version: 0, createdAt: 0, updatedAt: 0,
        };
        const virtualPreview: BaseItem = {
            id: 'preview', name: t('todoPreview'), itemType: 'TODO_VIRTUAL_FOLDER',
            parentID: null, version: 0, createdAt: 0, updatedAt: 0,
        };
        const virtualCompleted: BaseItem = {
            id: 'completed', name: t('todoCompleted'), itemType: 'TODO_VIRTUAL_FOLDER',
            parentID: null, version: 0, createdAt: 0, updatedAt: 0,
        };
        return [virtualToday, virtualPreview, virtualCompleted, ...(todoInbox ? [todoInbox as BaseItem] : [])];
    }, [t, todoInbox]);

    const suffixItems = React.useMemo(() => {
        if (sharedTodoCount === 0) return undefined;
        return [{ id: '__shared_todos__', name: 'sharedTodos', itemType: 'TODO_SHARED_FOLDER' } as BaseItem];
    }, [sharedTodoCount]);

    const getCount = React.useCallback((item: BaseItem) => {
        if (item.id === 'preview' || item.id === 'completed') return null;
        if (item.id === 'today') return { value: getTodoCount('today', null), pinned: true };
        if (item.id === '__shared_todos__') return { value: sharedTodoCount, pinned: true };
        return { value: getTodoCount('TODO', item.id), pinned: true };
    }, [getTodoCount, sharedTodoCount]);

    const renderIcon = React.useCallback((item: BaseItem) => {
        if (item.id === 'today') {
            const TodayIcon = getTodayCalendarIcon();
            return <TodayIcon className="folder-icon" />;
        }
        if (item.id === 'preview') return <TodoTodayIcon className="folder-icon" />;
        if (item.id === 'completed') return <TodoCompletedIcon className="folder-icon" />;
        if (item.name === 'todoInbox') return <TodoInboxIcon className="folder-icon" />;
        if (item.id === '__shared_todos__') return <NotebookFolderIcon className="folder-icon" style={{ color: 'var(--primary)' }} />;
        return <NotebookFolderIcon className="folder-icon" />;
    }, []);

    const getDisplayName = React.useCallback((item: BaseItem) => {
        if (item.name === 'todoInbox') return t('todoInbox');
        if (item.id === '__shared_todos__') return t('sharedTodos');
        return item.name;
    }, [t]);

    return { items, prefixItems, suffixItems, separatePrefix: true, getCount, renderIcon, getDisplayName };
}

const TodoContextMenu: React.FC = () => {
    const menu = useMenuStore(state => state.menus['sidebarTodoFolder']);
    const { t } = useTranslation();
    if (!menu?.show) return null;

    const close = () => useMenuStore.getState().close('sidebarTodoFolder');
    const folder = menu.data?.folder;
    const isGroup = menu.data?.isGroup;
    const handleCreateIn = () => {
        useDialogStore.getState().open('addFolder', { targetFolder: folder, mode: 'todo' });
        close();
    };
    const handleEdit = () => {
        useDialogStore.getState().open('addFolder', { folder: { ...folder, isGroup: false }, mode: 'todo' });
        close();
    };
    const handleDelete = () => {
        useDialogStore.getState().open('deleteFolder', { folder: { ...folder, isTodoFolder: true } });
        close();
    };
    const handleShareFolder = () => {
        if (!folder) return;
        useDialogStore.getState().open('sharing', {
            item: { id: folder.id, name: folder.name, isPublic: folder.isPublic, itemType: folder.itemType },
            onSave: async (settings) => {
                await updateItemShareSettings({ ...settings, extra: {} });
                await syncService.syncChanges();
                useTempHintStore.getState().setTempHint(settings.isPublic ? i18n.t('shareEnabled') : i18n.t('shareDisabled'));
            },
        });
        close();
    };

    return (
        <PopupMenu x={menu.position.x} y={menu.position.y} onClose={close}>
            {isGroup && (
                <PopupMenuItem onClick={handleCreateIn}>
                    {t('createTodoFolderIn', { name: folder?.name })}
                </PopupMenuItem>
            )}
            {(canManageMembers(folder) || hasDirectPermission(folder)) && (
                <PopupMenuItem onClick={handleShareFolder}>
                    {canManageMembers(folder)
                        ? (isAlreadyShared(folder) ? t('editShareSettings') : t('shareThisFolder'))
                        : t('shareSettings')}
                </PopupMenuItem>
            )}
            {canEdit(folder) && (
                <PopupMenuItem onClick={handleEdit}>
                    {t('editTodoFolder')}
                </PopupMenuItem>
            )}
            {getEffectivePermission(folder) === 'owner' && (
                <PopupMenuItem onClick={handleDelete}>
                    {t('deleteTodoFolder')}
                </PopupMenuItem>
            )}
        </PopupMenu>
    );
};

const TodoAddFolderDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['addFolder']?.show);
    const dialogData = useDialogStore(state => state.dialogs['addFolder']?.data);
    const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];

    if (!showDialog || dialogData?.mode !== 'todo') return null;

    const editFolder = dialogData?.folder;
    const isEdit = !!editFolder;

    const handleClose = () => useDialogStore.getState().close('addFolder');

    const existingNames = todoFolders
        .filter(f => !(isEdit && f.name?.toLowerCase() === editFolder?.name?.toLowerCase()))
        .map(f => f.name || '')
        .filter(Boolean);

    const handleConfirm = async (folderName: string) => {
        if (editFolder) {
            await useTodoStore.getState().updateTodoFolder({
                ...editFolder,
                name: folderName,
            });
        } else {
            const newFolder = {
                id: generateObjectID(),
                name: folderName,
                itemType: 'TODO' as const,
            };
            await useTodoStore.getState().addTodoFolder(newFolder);

            const added = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.id === newFolder.id);
            if (added) {
                useSelectedItemsStore.getState().setSelectedItems([added as BaseItem]);
                eventBus.emit('sidebar:folder-select', { folderId: added.id });
            }
        }
    };

    return (
        <NameInputDialog
            title={isEdit ? t('editTodoFolder') : t('newTodoFolderTitle')}
            initialName={editFolder?.name || ''}
            existingNames={existingNames}
            placeholder={t('todoFolderNamePlaceholder')}
            onConfirm={handleConfirm}
            onClose={handleClose}
            tips={!isEdit ? [t('dragToMove'), t('rightClickToEdit')] : undefined}
        />
    );
};

const TodoDeleteFolderDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['deleteFolder']?.show);
    const folder = useDialogStore(state => state.dialogs['deleteFolder']?.data?.folder);

    if (!showDialog || !folder || (folder.itemType !== 'TODO_FOLDER' && !(folder as any).isTodoFolder)) return null;

    const hideDialog = () => useDialogStore.getState().close('deleteFolder');

    const handleConfirm = async () => {
        try {
            await useTodoStore.getState().deleteTodoFolder([folder.id]);
            const todoInboxFolder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.name === 'todoInbox');
            if (todoInboxFolder) useSelectedItemsStore.getState().setSelectedItems([todoInboxFolder], { scrollToFocusItem: true });
            useTempHintStore.getState().setTempHint(t('deletedTodoFolder', { name: folder.name }));
            hideDialog();
        } catch (error) {
            console.error('刪除失敗:', error);
            useTempHintStore.getState().setTempHint(t('deleteFailed'));
        }
    };

    return (
        <CustomDialog isOpen onClose={hideDialog} title={t('deleteTodoFolder')} onConfirm={handleConfirm}>
            <p className="custom-dialog-description">
                {t('deleteTodoFolderConfirm', { name: folder.name })}
            </p>
        </CustomDialog>
    );
};

class TodoListView extends ReactView {
    getViewType() { return 'todo-list'; }
    getDisplayText() { return '待辦列表'; }
    renderComponent() { return <TodoList />; }
}

class TodoEditorView extends ReactView {
    getViewType() { return 'todo-editor'; }
    getDisplayText() { return '待辦編輯器'; }
    renderComponent() { return <NoteEditor />; }
}

export class TodoPlugin extends Plugin {
    onload() {
        this.registerOverlay('todoContextMenu', TodoContextMenu);
        this.registerOverlay('todoAddFolderDialog', TodoAddFolderDialog);
        this.registerOverlay('todoDeleteFolderDialog', TodoDeleteFolderDialog);
        this.registerOverlay('sharingDialog', SharingDialog);
        this.registerOverlay('contributorsDialog', ContributorsDialog);
        this.registerOverlay('deleteIndexDialog', DeleteIndexDialog);

        // 註冊嵌入式預覽渲染器（給 ItemEmbedExtension 用）
        useEmbedRendererRegistry.getState().register('TODO', { component: TodoEmbedView });
        this.register(() => useEmbedRendererRegistry.getState().unregister('TODO'));

        this.registerSidebarWithView({
            sidebar: {
                id: 'todo',
                title: i18n.t('sidebarTodos'),
                orderAt: 200,
                useData: useTodoSidebarData,
                addFolder: {
                    actionText: i18n.t('addTodoFolder'),
                    icon: <TodoFolderIcon />,
                    onClick: () => useDialogStore.getState().open('addFolder', { mode: 'todo' }),
                },
            },
            views: [
                { type: 'todo-list', creator: (leaf) => new TodoListView(leaf) },
                { type: 'todo-editor', creator: (leaf) => new TodoEditorView(leaf) },
            ],
            activateOnItemTypes: ['TODO_FOLDER', 'TODO', 'TODO_VIRTUAL_FOLDER', 'TODO_SHARED_FOLDER'],
            panes: {
                centerPane1: { leafId: 'leaf-todolist', viewType: 'todo-list', flex: 1, minSize: 240 },
                centerPane2: { leafId: 'leaf-todoeditor', viewType: 'todo-editor', size: 400, minSize: 240 },
            },
        });

        // 預註冊 command schemas（設定頁不依賴元件 mount；無 handler → 僅寫 schema）
        const cm = useCommandManager.getState();
        cm.register({ command: { id: 'todo:create', name: i18n.t('cmd.createTodo') }, hotkeys: [{ modifiers: [], key: 'Enter' }] });
        cm.register({ command: { id: 'todo-list:delete', name: i18n.t('cmd.deleteSelectedTodos') }, hotkeys: [{ modifiers: ['Mod'], key: 'Delete' }, { modifiers: ['Mod'], key: 'Backspace' }] });
        cm.register({ command: { id: 'todo-list:escape', name: i18n.t('cmd.todoListBack') }, hotkeys: [{ modifiers: [], key: 'Escape' }] });
        cm.register({ command: { id: 'todo-list:arrow-up', name: i18n.t('cmd.todoListUp') }, hotkeys: [{ modifiers: [], key: 'ArrowUp' }] });
        cm.register({ command: { id: 'todo-list:arrow-down', name: i18n.t('cmd.todoListDown') }, hotkeys: [{ modifiers: [], key: 'ArrowDown' }] });
        cm.register({ command: { id: 'todo-list:shift-arrow-up', name: i18n.t('cmd.todoListShiftUp') }, hotkeys: [{ modifiers: ['Shift'], key: 'ArrowUp' }] });
        cm.register({ command: { id: 'todo-list:shift-arrow-down', name: i18n.t('cmd.todoListShiftDown') }, hotkeys: [{ modifiers: ['Shift'], key: 'ArrowDown' }] });
        cm.register({ command: { id: 'todo-list:arrow-right', name: i18n.t('cmd.todoListRight') }, hotkeys: [{ modifiers: [], key: 'ArrowRight' }] });
        cm.register({ command: { id: 'todo-list:arrow-left', name: i18n.t('cmd.todoListLeft') }, hotkeys: [{ modifiers: [], key: 'ArrowLeft' }] });

        // 註冊搜尋 provider
        this.registerSearchProvider('TODO', {
            renderIcon: () => <TodoFolderIcon />,
            search: (query) => {
                const todos = (useItemStore.getState().getByType('TODO') as Todo[]);
                const todoFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
                const trashId = todoFolders.find(f => f.name === 'trash')?.id;
                const q = query.toLowerCase();
                return todos.filter(t => {
                    const parent = t.parentID ? useItemStore.getState().getById(t.parentID) : null;
                    if (parent && parent.itemType === 'TODO') return false;
                    if (t.parentID === trashId) return false;
                    if (!query) return true;
                    if (t.name?.toLowerCase().includes(q)
                        || processItemContent(t as any, true).toLowerCase().includes(q)) return true;
                    const tags = t.tags;
                    if (!tags || !Array.isArray(tags)) return false;
                    return tags.some((tag: string) => tag.toLowerCase().includes(q));
                });
            },
        });
        this.registerSearchProvider('TODO_FOLDER', {
            renderIcon: (item) => item.name === 'todoInbox' ? <TodoInboxIcon /> : <NotebookFolderIcon />,
            search: (query) => {
                const todoFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
                const q = query.toLowerCase();
                return todoFolders.filter(f => {
                    if (f.name === 'todoInbox' || f.name === 'trash') return false;
                    return !query || f.name?.toLowerCase().includes(q);
                });
            },
        });

        // 鍵盤刪除資料夾（由 Sidebar 發 eventBus）
        this.registerEvent('sidebar:delete-folder', ({ folderId }: { folderId: string }) => {
            const folder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.id === folderId);
            if (!folder) return;
            if (folder.name === 'todoInbox') return;
            useDialogStore.getState().open('deleteFolder', { folder: { ...folder, isTodoFolder: true } });
        });

        // 右鍵選單
        this.registerEvent('contextMenu', ({ item, event }: { item: BaseItem; event: React.MouseEvent }) => {
            if (item.itemType === 'TODO_VIRTUAL_FOLDER') return;
            if (item.itemType !== 'TODO_FOLDER') return;
            if ((item as any).name === 'todoInbox') return;
            const scale = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim()) || 1;
            const todoFolders = useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[];
            const isGroup = todoFolders.some(f => f.parentID === item.id);
            useMenuStore.getState().openAt('sidebarTodoFolder', event.clientX / scale, event.clientY / scale, { folder: item, isGroup });
        });

    }
}

registerPluginClass(TodoPlugin, '待辦', {
    dependencies: ['SidebarPlugin'],
    descriptionKey: 'modulesTodoDesc',
    setupI18n: () => registerPluginLocales('TodoPlugin', { 'en': todoEn, 'zh-Hant': todoZhHant, 'ja': todoJa }),
});
