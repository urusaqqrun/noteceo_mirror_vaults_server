import React, { useRef, useCallback, useMemo, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout, useInterval } from '../../../hooks/useTimeout';
import './TodoList.css';
import { useCommandManager } from '../../../Store/commandManager';
import { useListKeyboardNav } from '../../../hooks/useListKeyboardNav';
import '../../common/CustomToolbar.css';
import '../sidebar/Sidebar.css';
import TodoItem from './TodoItem';
import CustomScrollbar from '../../common/CustomScrollbar';
import CustomHint from '../../common/CustomHint';
import DatePickerDropdown from '../../common/DatePickerDropdown';
import CheckedIcon from '../../../assets/icon_correct.svg?react';
import AddLineIcon from '../../../assets/bk_icon_add_line_20_n.svg?react';
import ArrowIcon from '../../../assets/icon_arrowchevron_up_24.svg?react';
import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';

import { useSelectedItemsStore } from '../../../Store/navigationStore';

import { useTodoStore, Todo, TodoFolder } from './todoStore';
import { useItemStore } from '../../../Store/itemStore';
import type { BaseItem } from '../../../types/item';
import { usePressedKeyStore, useTempHintStore, useMobileSidebarStore, useLiveInputStore } from '../../../Store/uiStore';

import { eventBus } from '../../../Store/eventBus';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { TodoRightClickMenu } from './TodoRightClickMenu';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import EditIcon from '../../../assets/icon_edit_24.svg?react';


import DeleteIcon from '../../../assets/bk_icon_delete_fill_20_n.svg?react';
import { CustomDialog } from '../../common/CustomDialog';
import MenuIcon from '../../../assets/icon_menu_24.svg?react';
import ShareCollabIcon from '../../../assets/icon_share_setting_24.svg?react';
import MobileTopbar from '../../common/MobileTopbar';
import { getDateFromReminderTime, getTimeFromReminderTime, createReminderTime, isDateOverdue } from '../../../utils/reminderTimeUtils';
import { updateItemShareSettings } from '../../../utils/shareAPI';
import { canAccessSharingDialog, canManageMembers, canEdit } from '../../../utils/shareUtils';
import { ShareMemberThumbnailList } from '../../common/share/ShareMemberThumbnailList';
import syncService from '../../../utils/syncService';

// 使用 window.textUtils
const { stripContent } = window.textUtils;

/**
 * TodoList 組件 - 顯示待辦列表
 * 複用 NoteItem 組件來顯示各個待辦項目
 */
function TodoList() {
  const { t } = useTranslation();

  // 待辦相關 store（從 useItemStore 讀取）
  const todos = useItemStore(s => s.byType['TODO'] ?? []) as Todo[];
  const addTodo = useTodoStore(state => state.addTodo);
  const updateTodo = useTodoStore(state => state.updateTodo);
  const createNewTodo = useTodoStore(state => state.createNewTodo);
  const getFilteredTodos = useTodoStore(state => state.getFilteredTodos);

  const { path: navPath, lastSelected, allSelected, extraItems, selectedFolderId } = useSelectedItemsStore(state => ({
    path: state.path,
    lastSelected: state.path.at(-1) ?? null,
    allSelected: [state.path.at(-1), ...state.extraItems].filter(Boolean) as any[],
    extraItems: state.extraItems,
    selectedFolderId: state.selectedFolderId,
  }));
  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
  const isMultiSelecting = extraItems.length > 0;

  // TodoList 用 selectedItemIds 做多選，從 allSelected 提取 TODO type IDs
  const selectedItemIds = useMemo(() => allSelected
    .filter(i => i.itemType === 'TODO')
    .map(i => i.id), [allSelected]);
  const setSelectedItemIds = useCallback((ids: string[]) => {
    const currentTodos = useItemStore.getState().getByType('TODO') as Todo[];
    const items = ids.map(id => currentTodos.find(t => t.id === id)).filter(Boolean) as BaseItem[];
    setSelectedItems(items);
  }, [setSelectedItems]);
  const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const updateTodoFolder = useTodoStore(state => state.updateTodoFolder);

  // 從 navPath 推導等效的 selectedFolderType
  // 往 path 中查找 TODO_VIRTUAL_FOLDER，這樣在虛擬視圖中點擊 todo 後仍保持正確視圖
  const selectedFolderType = useMemo(() => {
    const virtualItem = navPath.find(item => item.itemType === 'TODO_VIRTUAL_FOLDER');
    if (virtualItem?.id === 'today') return 'today';
    if (virtualItem?.id === 'preview') return 'preview';
    if (virtualItem?.id === 'completed') return 'completed';
    const sharedItem = navPath.find(item => item.itemType === 'TODO_SHARED_FOLDER');
    if (sharedItem?.id === '__shared_todos__') return 'SHARED_TODOS';
    if (selectedFolderId && todoFolders.some(f => f.id === selectedFolderId)) return 'TODO';
    return null;
  }, [navPath, selectedFolderId, todoFolders]);

  // todoInbox 資料夾
  const todoInboxFolder = todoFolders.find(f => f.name === 'todoInbox');

  const isSubTask = useCallback((todo: any) => {
    if (!todo.parentID) return false;
    const parent = useItemStore.getState().getById(todo.parentID);
    return parent?.itemType === 'TODO';
  }, []);

  // 按鍵狀態
  const isShiftPressed = usePressedKeyStore(state => state.isShiftPressed);
  const isCommandPressed = usePressedKeyStore(state => state.isCommandPressed);
  const setIsShiftPressed = usePressedKeyStore(state => state.setIsShiftPressed);
  const setIsCommandPressed = usePressedKeyStore(state => state.setIsCommandPressed);

  const [isEditing, setIsEditing] = useState(false);

  // 手機版相關
  const isMobileView = useIsMobileView();
  const setIsMobileSidebarOpen = useMobileSidebarStore(state => state.setIsMobileSidebarOpen);


  // 手機版更多選單狀態
  const moreMenu = useMenuStore(state => state.menus['todoListMore']);


  // Refs
  const todoListRef = useRef(null);
  const titleInputRefs = useRef({});
  const noteUpdateRefs = useRef({});
  const createSubtaskAfterRef = useRef(null);
  const createNewTodoRef = useRef(null);
  const savedDropStateRef = useRef(null); // 用於儲存拖曳狀態（參考 NoteList）
  const dropHandledRef = useRef(false); // handleDrop 已處理，防止 dragEnd 重複執行
  const draggedTodoIdsRef = useRef<string[]>([]); // 記錄當前被拖曳的 todo IDs
  const dragStartXRef = useRef<number | undefined>(undefined); // 記錄拖曳起始的 X 座標
  const blurTimeoutRef = useRef({}); // 用於取消 blur 時的刪除檢查（切換輸入法時需要），key 為 todo.id
  const updateNoteTimeoutRef = useRef({}); // 用於 debounce updateNote 調用，key 為 todo.id
  const userClickedInputRef = useRef(false); // 用戶點擊 input 時設 true，防止 auto-focus subscriber 覆蓋游標位置

  // 當前時間（用於判斷過期）
  const [currentTime, setCurrentTime] = useState(new Date());

  // 安全定時器 hooks - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();
  const { setInterval: safeSetInterval, clearInterval: safeClearInterval } = useInterval();

  // 拖拽狀態
  const [dropTarget, setDropTarget] = useState(null);
  const [dropPosition, setDropPosition] = useState(null);
  const [dropTargetDateSection, setDropTargetDateSection] = useState(null); // 拖曳到日期 section header 時的目標

  // EventBus: 待辦拖到 Sidebar 待辦資料夾的 drop handler
  // Sidebar 只傳 targetFolderId，IDs 由 TodoList 的 draggedTodoIdsRef 讀取
  useEffect(() => {
    const unsub = eventBus.on('drop:sidebar-folder:todolist-todoitem', async (targetFolderId: string) => {
      const todoIds = draggedTodoIdsRef.current;
      if (todoIds.length === 0) return;

      // 同步標記已處理，防止 dragend 透過 executeDrop 覆蓋 sidebar 移動
      dropHandledRef.current = true;
      savedDropStateRef.current = null;

      const todos = (useItemStore.getState().getByType('TODO') as Todo[]);
      const allFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
      const targetFolder = allFolders.find(f => f.id === targetFolderId);
      const todoIdsSet = new Set(todoIds);

      // 收集原資料夾 ID 並批量更新 indexes
      const sourceFolderIds = new Set<string>();
      for (const todoId of todoIds) {
        const todo = todos.find(n => n.id === todoId);
        if (todo?.parentID && todo.parentID !== targetFolderId) {
          sourceFolderIds.add(todo.parentID);
        }
      }

      const todosToUpdate: any[] = [];
      const latestTodos = (useItemStore.getState().getByType('TODO') as Todo[]);

      // 計算目標資料夾中現有 todo 的最小 orderAt，讓移入的 todo 排在最上方
      const existingInTarget = latestTodos.filter(t => !t.completed && t.parentID === targetFolderId);
      const minOrderAt = existingInTarget.length > 0
        ? Math.min(...existingInTarget.map(t => parseFloat(String(t.orderAt)) || 0))
        : Date.now();

      let idx = 0;
      for (const todoId of todoIds) {
        const todo = latestTodos.find(n => n.id === todoId);
        if (todo && todo.parentID !== targetFolderId) {
          const base = { ...todo, parentID: targetFolderId, updatedAt: Date.now(), orderAt: String(minOrderAt - 1000 * (idx + 1)) };
          todosToUpdate.push(base);
          idx++;
        }
      }

      if (todosToUpdate.length > 0) {
        await useTodoStore.getState().updateTodo(todosToUpdate);
        const fn = targetFolder?.name || '';
        const displayName = ['inbox', 'trash', 'todoInbox'].includes(fn) ? t(fn) : fn;
        useTempHintStore.getState().setTempHint(t('todosMovedToFolder', { count: todosToUpdate.length, folderName: displayName }));
      }
      draggedTodoIdsRef.current = [];
    });
    return unsub;
  }, [t]);

  // EventBus: 待辦拖到 AICommander 的 drop handler
  useEffect(() => {
    const unsub = eventBus.on('drop:ai-commander:todolist-todoitem', (e: any, addAttachment: any, attachedItems: any, inputAreaRef: any) => {
      const todoId = e.dataTransfer.getData('todoid');

      if (!todoId) return;

      // 同步標記已處理，防止 dragend 誤觸 executeDrop
      dropHandledRef.current = true;
      savedDropStateRef.current = null;

      const allTodos = (useItemStore.getState().getByType('TODO') as Todo[]);
      if (attachedItems.some((item: any) => item.id === todoId)) return;
      const todo = allTodos.find((n: any) => n.id === todoId);
      if (todo) {
        addAttachment(todo);
        if (inputAreaRef.current?.closeSaveMode) {
          inputAreaRef.current.closeSaveMode();
        }
      }
    });
    return unsub;
  }, []);

  // EventBus: NoteEditor 段落拖到 TodoList 建立新待辦（新功能）
  useEffect(() => {
    const unsub = eventBus.on('drop:todo-list:noteEditor', async (_items, metadata) => {
      const contentText = (metadata?.textContent || '').trim();
      if (contentText === '') return;
      try {
        await useTodoStore.getState().createNewTodo({
          name: contentText,
          completed: metadata?.isTaskCompleted || false
        }, false, false);
        if (metadata?.deleteOriginal) metadata.deleteOriginal();
      } catch (err) {
        console.error('NoteEditor段落拖到TodoList失敗:', err);
      }
    });
    return unsub;
  }, []);

  // EventBus: 待辦拖到 NoteEditor 的 drop handler（插入 taskList + 刪除原待辦）
  useEffect(() => {
    const unsub = eventBus.on('drop:markdown-editor', async (items, _metadata, editor, dropPos) => {
      const todoItems = items.filter((i: any) => i.itemType === 'TODO');
      if (todoItems.length === 0 || !editor || dropPos == null) return;

      // 同步標記已處理，防止 dragend 誤觸 executeDrop
      dropHandledRef.current = true;
      savedDropStateRef.current = null;
      try {
        for (const item of todoItems) {
          const taskText = item.name || item.aiTitle || t('untitledTodo');
          const isChecked = (item as any)?.completed === true;

          editor.chain().insertContentAt(dropPos, {
            type: 'taskList',
            content: [{
              type: 'taskItem',
              attrs: { checked: isChecked },
              content: [{ type: 'paragraph', content: [{ type: 'text', text: taskText }] }]
            }]
          }).run();

          // 若拖入的待辦不是當前編輯中的筆記 → 刪除原待辦
          const _lastId = useSelectedItemsStore.getState().path.at(-1)?.id;
          const currentItem = _lastId
            ? ((useItemStore.getState().getByType('TODO') as Todo[]).find((t: any) => t.id === _lastId) ?? null)
            : null;
          if (!currentItem || currentItem.id !== item.id) {
            try { await useItemStore.getState().removeItems([item.id], { needSync: true }); } catch (e) { }
          }
        }
      } catch (err) {
        console.error('待辦拖到MarkdownEditor失敗:', err);
      }
    });
    return unsub;
  }, [t]);

  // 過期 section 展開/收起狀態（從 localStorage 讀取，預設展開）
  const [isOverdueExpanded, setIsOverdueExpanded] = useState(() => {
    const saved = localStorage.getItem('todolist_overdue_expanded');
    return saved !== null ? saved === 'true' : true;
  });

  // 儲存過期 section 展開/收起狀態到 localStorage
  useEffect(() => {
    localStorage.setItem('todolist_overdue_expanded', String(isOverdueExpanded));
  }, [isOverdueExpanded]);

  // PREVIEW 視圖分頁加載狀態（避免一次渲染 730 天造成卡頓）
  const [previewLoadedDays, setPreviewLoadedDays] = useState(60); // 初始顯示 60 天
  const PREVIEW_LOAD_INCREMENT = 60; // 每次加載 60 天

  // PREVIEW 視圖當前可見的日期（用於周視圖高亮）
  const [previewVisibleDate, setPreviewVisibleDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });

  // 獲取當前待辦資料夾（僅在待辦資料夾視圖時有效）
  const currentTodoFolder = useMemo(() => {
    if (!(selectedFolderType === 'TODO' && selectedFolderId !== todoInboxFolder?.id)) return null;
    return todoFolders.find(f => f.id === selectedFolderId) || null;
  }, [selectedFolderType, selectedFolderId, todoInboxFolder?.id, todoFolders]);

  // VIEWER 權限：共享資料夾且無編輯權限時為唯讀
  const isViewerMode = useMemo(() => {
    if (selectedFolderType === 'SHARED_TODOS') return true;
    if (currentTodoFolder && !canEdit(currentTodoFolder)) return true;
    return false;
  }, [selectedFolderType, currentTodoFolder]);

  // 子任務展開/收起狀態（收起的父任務 ID 集合，從 localStorage 讀取）
  const [collapsedSubtasks, setCollapsedSubtasks] = useState(() => {
    try {
      const saved = localStorage.getItem('collapsedSubtasks');
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch {
      return new Set();
    }
  });



  // 定時更新當前時間
  useEffect(() => {
    const timer = safeSetInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // 每分鐘更新一次
    return () => safeClearInterval(timer);
  }, [safeSetInterval, safeClearInterval]);

  // 獲取本地日期字串（避免 toISOString 的 UTC 時區問題）
  // 不使用 useMemo 緩存，確保每次渲染都獲取最新日期（午夜時立即更新）
  const d = new Date();
  const localTodayStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

  // 切換到 PREVIEW 視圖時重置分頁和可見日期
  useEffect(() => {
    if (selectedFolderType === 'preview') {
      setPreviewLoadedDays(60);
      setPreviewVisibleDate(localTodayStr);
    }
  }, [selectedFolderType, localTodayStr]);

  // 獲取過濾後的待辦列表
  const filteredTodos = useMemo(() => {
    const baseTodos = getFilteredTodos(selectedFolderType, selectedFolderId);
    const baseTodoIds = new Set(baseTodos.map(t => t.id));
    // 收集所有母任務的 ID（parentID 指向 folder 的視為頂層）
    const topLevelIds = new Set(baseTodos.filter(t => !isSubTask(t)).map(t => t.id));
    // 載入這些母任務的子任務（parentID 指向母任務，且不在 baseTodos 中）
    const childTodos = todos.filter(n =>
      isSubTask(n) &&
      topLevelIds.has(n.parentID) &&
      !baseTodoIds.has(n.id)
    );
    const result = [...baseTodos, ...childTodos];
    return result;
  }, [getFilteredTodos, selectedFolderType, selectedFolderId, todos, todoFolders]);

  // 計算不含子任務的待辦數量（用於 topbar 顯示）
  const todoCountWithoutSubtasks = useMemo(() => {
    return filteredTodos.filter(t => !isSubTask(t)).length;
  }, [filteredTodos, isSubTask]);

  // 格式化日期標題（例：12月25日 ‧ 今天 ‧ 週四，超過今年顯示年份）
  const formatDateHeader = useCallback((dateStr) => {
    if (!dateStr) return t('noDate');

    const date = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // 格式化日期部分（例：12月25日，超過今年顯示 2026年1月13日）
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const isCurrentYear = year === today.getFullYear();
    const dateText = isCurrentYear
      ? t('dateFormat', { month, day })
      : t('dateFormatWithYear', { year, month, day });

    // 判斷相對日期
    let relativeDay = '';
    if (date.toDateString() === today.toDateString()) {
      relativeDay = t('relativeToday');
    } else if (date.toDateString() === yesterday.toDateString()) {
      relativeDay = t('relativeYesterday');
    } else if (date.toDateString() === tomorrow.toDateString()) {
      relativeDay = t('relativeTomorrow');
    }

    // 星期幾
    const weekdays = [
      t('weekdaySun'), t('weekdayMon'), t('weekdayTue'),
      t('weekdayWed'), t('weekdayThu'), t('weekdayFri'), t('weekdaySat')
    ];
    const weekday = weekdays[date.getDay()];

    // 組合標題
    if (relativeDay) {
      return `${dateText} ‧ ${relativeDay} ‧ ${weekday}`;
    }
    return `${dateText} ‧ ${weekday}`;
  }, [t]);

  // 按日期分組待辦（today/upcoming 視圖用 reminderTime，completed 視圖用 finishedAt）
  const groupedTodos = useMemo(() => {
    if (selectedFolderType !== 'today' && selectedFolderType !== 'completed' && selectedFolderType !== 'preview') {
      return null;
    }

    const groups = new Map();
    const overdueItems = []; // 過期待辦（today 和 upcoming 視圖使用）

    filteredTodos.forEach(todo => {
      // 子任務跳過分組（會在 buildTodoTree 中歸到父任務下）
      if (isSubTask(todo)) return;

      let dateKey;
      if (selectedFolderType === 'completed') {
        // 已完成視圖：用 finishedAt 時間戳轉為日期
        if (todo.finishedAt) {
          const d = new Date(parseInt(String(todo.finishedAt)));
          dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        } else {
          dateKey = 'no-date';
        }

        if (!groups.has(dateKey)) {
          groups.set(dateKey, []);
        }
        groups.get(dateKey).push(todo);
      } else {
        // today/upcoming 視圖：用 reminderTime 欄位，並分離過期項目
        dateKey = getDateFromReminderTime(todo.reminderTime) || 'no-date';

        // 檢查是否過期（日期小於今天）
        if (dateKey !== 'no-date' && isDateOverdue(dateKey, localTodayStr)) {
          overdueItems.push(todo);
        } else {
          if (!groups.has(dateKey)) {
            groups.set(dateKey, []);
          }
          groups.get(dateKey).push(todo);
        }
      }
    });

    // TODAY 視圖：確保今天的 section 存在（即使是空的）
    if (selectedFolderType === 'today') {
      if (!groups.has(localTodayStr)) {
        groups.set(localTodayStr, []);
      }
    }

    // PREVIEW 視圖：生成從今天到兩年後的每一天（即使沒有 TODO 也顯示）
    if (selectedFolderType === 'preview') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const twoYearsLater = new Date(today);
      twoYearsLater.setFullYear(twoYearsLater.getFullYear() + 2);

      // 生成每一天的日期 key
      const currentDate = new Date(today);
      while (currentDate <= twoYearsLater) {
        const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
        if (!groups.has(dateKey)) {
          groups.set(dateKey, []);
        }
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }

    // 排序：PREVIEW 用日期升序（今天在上面），其他用降序
    const sortedGroups = Array.from(groups.entries()).sort((a, b) => {
      if (a[0] === 'no-date') return 1;
      if (b[0] === 'no-date') return -1;
      if (selectedFolderType === 'preview') {
        return a[0].localeCompare(b[0]); // 升序：今天在上面
      }
      return b[0].localeCompare(a[0]); // 降序
    });

    // 在 today 和 upcoming 視圖中，如果有過期項目，在最前面添加過期 section
    if ((selectedFolderType === 'today' || selectedFolderType === 'preview') && overdueItems.length > 0) {
      // 過期項目按日期降序排序（最近的過期日期在上面）
      overdueItems.sort((a, b) => {
        const aDate = getDateFromReminderTime(a.reminderTime) || '';
        const bDate = getDateFromReminderTime(b.reminderTime) || '';
        return bDate.localeCompare(aDate);
      });
      sortedGroups.unshift(['overdue', overdueItems]);
    }

    return sortedGroups;
  }, [filteredTodos, selectedFolderType, localTodayStr, isSubTask]);

  // PREVIEW 視圖的分頁顯示列表
  const displayedGroupedTodos = useMemo(() => {
    if (!groupedTodos) return null;
    if (selectedFolderType !== 'preview') return groupedTodos;
    // PREVIEW 視圖：只顯示前 previewLoadedDays 個 section（包含 overdue）
    return groupedTodos.slice(0, previewLoadedDays + 1); // +1 因為可能有 overdue section
  }, [groupedTodos, selectedFolderType, previewLoadedDays]);

  // PREVIEW 視圖滾動加載更多 + 更新當前可見日期
  const handlePreviewScroll = useCallback((e) => {
    if (selectedFolderType !== 'preview' || !groupedTodos) return;

    const { scrollTop, scrollHeight, clientHeight } = e.target;
    // 當滾動到距離底部 500px 時，加載更多
    if (scrollHeight - scrollTop - clientHeight < 500) {
      setPreviewLoadedDays(prev => {
        const newValue = prev + PREVIEW_LOAD_INCREMENT;
        // 不超過總天數
        return Math.min(newValue, groupedTodos.length);
      });
    }

    // 檢測當前可見的日期 section
    const container = e.target;
    const sections = container.querySelectorAll('.todolist-date-section[data-date-key]');
    const containerRect = container.getBoundingClientRect();
    for (const section of sections) {
      const rect = section.getBoundingClientRect();
      // 找到第一個頂部在容器可見區域內的 section
      if (rect.top >= containerRect.top - 50 && rect.top < containerRect.top + 100) {
        const dateKey = section.getAttribute('data-date-key');
        if (dateKey && dateKey !== 'overdue') {
          setPreviewVisibleDate(dateKey);
        }
        break;
      }
    }
  }, [selectedFolderType, groupedTodos, PREVIEW_LOAD_INCREMENT]);

  // 建立待辦樹狀結構（將子任務歸類到父任務下，按 orderAt 降序排序）
  const buildTodoTree = useCallback((todos) => {
    const topLevel = [];
    const childrenMap = new Map();

    todos.forEach(todo => {
      if (!isSubTask(todo)) {
        topLevel.push(todo);
      } else {
        if (!childrenMap.has(todo.parentID)) {
          childrenMap.set(todo.parentID, []);
        }
        childrenMap.get(todo.parentID).push(todo);
      }
    });

    // 對每個父任務下的子任務按 orderAt 升序排序（由舊到新）
    childrenMap.forEach((children) => {
      children.sort((a, b) => {
        const aOrder = a.orderAt ? parseFloat(a.orderAt) : 0;
        const bOrder = b.orderAt ? parseFloat(b.orderAt) : 0;
        return aOrder - bOrder;
      });
    });

    return { topLevel, childrenMap };
  }, [isSubTask]);

  // 獲取過濾後的待辦 ID 列表（按視覺順序排列，包含子任務）
  const filteredNoteIds = useMemo(() => {
    // 輔助函數：將父任務和子任務按順序展開
    const flattenWithChildren = (todos, childrenMap) => {
      const result = [];
      todos.forEach(todo => {
        result.push(todo.id);
        const children = childrenMap.get(todo.id) || [];
        children.forEach(child => result.push(child.id));
      });
      return result;
    };

    // 今日/即將到來/已完成視圖：按 groupedTodos 視覺順序
    if (groupedTodos) {
      const ids = [];
      const globalChildrenMap = new Map();
      filteredTodos.forEach(todo => {
        if (isSubTask(todo)) {
          if (!globalChildrenMap.has(todo.parentID)) {
            globalChildrenMap.set(todo.parentID, []);
          }
          globalChildrenMap.get(todo.parentID).push(todo);
        }
      });
      // 對每個父任務下的子任務按 orderAt 升序排序（由舊到新）
      globalChildrenMap.forEach((children) => {
        children.sort((a, b) => {
          const aOrder = a.orderAt ? parseFloat(a.orderAt) : 0;
          const bOrder = b.orderAt ? parseFloat(b.orderAt) : 0;
          return aOrder - bOrder;
        });
      });

      groupedTodos.forEach(([, todosInGroup]) => {
        todosInGroup.forEach(todo => {
          ids.push(todo.id);
          // 使用 globalChildrenMap 來獲取子任務
          const children = globalChildrenMap.get(todo.id) || [];
          children.forEach(child => ids.push(child.id));
        });
      });
      return ids;
    }

    // 其他視圖：直接用 filteredTodos 順序，展開子任務
    const { topLevel, childrenMap } = buildTodoTree(filteredTodos);
    return flattenWithChildren(topLevel, childrenMap);
  }, [filteredTodos, groupedTodos, buildTodoTree]);

  // 建立 parentID -> children 的映射（供渲染使用，按 orderAt 降序排序）
  const childrenMap = useMemo(() => {
    const map = new Map();
    filteredTodos.forEach(todo => {
      if (isSubTask(todo)) {
        if (!map.has(todo.parentID)) {
          map.set(todo.parentID, []);
        }
        map.get(todo.parentID).push(todo);
      }
    });
    // 對每個父任務下的子任務按 orderAt 升序排序（由舊到新）
    map.forEach((children, parentId) => {
      children.sort((a, b) => {
        const aOrder = a.orderAt ? parseFloat(a.orderAt) : 0;
        const bOrder = b.orderAt ? parseFloat(b.orderAt) : 0;
        return aOrder - bOrder;
      });
    });
    return map;
  }, [filteredTodos, isSubTask]);

  const isTodoSelected = useCallback(
    () => useSelectedItemsStore.getState().path.at(-1)?.itemType === 'TODO',
    [],
  );

  useListKeyboardNav({
    prefix: 'todo-list',
    sortedIds: filteredNoteIds,
    isActive: isTodoSelected,
    onNavigateLeft: () => useSelectedItemsStore.getState().navigateOut(),
    onNavigateRight: () => {
      const el = document.querySelector('.ProseMirror') as HTMLElement;
      el?.focus();
    },
    labels: {
      up: t('cmd.todoListUp'),
      down: t('cmd.todoListDown'),
      shiftUp: t('cmd.todoListShiftUp'),
      shiftDown: t('cmd.todoListShiftDown'),
      left: t('cmd.todoListLeft'),
      right: t('cmd.todoListRight'),
    },
  });

  // 從 folder 層進入 TODO 層時（sidebar ArrowRight），自動 focus todo-title-input
  useEffect(() => {
    let prevLastType = useSelectedItemsStore.getState().path.at(-1)?.itemType;
    const unsub = useSelectedItemsStore.subscribe((state) => {
      const lastItem = state.path.at(-1);
      if (lastItem?.itemType === 'TODO' && prevLastType !== 'TODO') {
        requestAnimationFrame(() => {
          // 若是用戶點擊 input 觸發的 store 變化，跳過 auto-focus 避免覆蓋游標位置
          if (userClickedInputRef.current) {
            userClickedInputRef.current = false;
            return;
          }
          const el = document.querySelector(
            `[data-id="${lastItem.id}"] .todo-title-input`
          ) as HTMLInputElement;
          if (el) {
            el.focus();
            el.setSelectionRange(0, 0);
          }
        });
      }
      prevLastType = lastItem?.itemType;
    });
    return unsub;
  }, []);

  // Enter 新增待辦 — commandManager 統一管理（dialog 打開時自動不觸發）
  useEffect(() => {
    const isTodoListContext = () => {
      const last = useSelectedItemsStore.getState().path.at(-1);
      return !!(last && (last.itemType === 'TODO_FOLDER' || last.itemType === 'TODO' || last.itemType === 'TODO_VIRTUAL_FOLDER'));
    };
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'todo:create',
        name: t('cmd.createTodo'),
        checkCallback: (checking: boolean) => {
          // dialog/menu 打開時不可執行
          if (document.querySelector('.custom-dialog-overlay, .custom-dialog-mobile-overlay')) return false;
          if (document.querySelector('.add-menu.active, .more-menu.active, .right-click-menu, .account-menu')) return false;
          // 焦點在 input/textarea/contenteditable 時不可執行（讓 title input、editor 自行處理 Enter）
          const ae = document.activeElement;
          if (ae instanceof HTMLInputElement || ae instanceof HTMLTextAreaElement || (ae as HTMLElement)?.isContentEditable) return false;
          // 完成視圖不可新增
          if (selectedFolderType === 'completed') return false;
          if (!checking) {
            // 委託給 handleCreateNewTodo（與 AddTodoItem 按鈕邏輯一致）
            // 計算 reminderTime：today/preview 設為今天
            const reminderTime = (selectedFolderType === 'today' || selectedFolderType === 'preview')
              ? createReminderTime(localTodayStr, null) : undefined;
            createNewTodoRef.current?.(null, reminderTime);
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Enter' }],
      enabled: isTodoListContext,
    });
    return unsub;
  }, [selectedFolderType, localTodayStr, t]);

  // keydown/keyup — commandManager 統一管理（導航類命令已移至 useListKeyboardNav）
  useEffect(() => {
    const cm = useCommandManager.getState();

    const isTodoListContext = () => {
      const last = useSelectedItemsStore.getState().path.at(-1);
      return !!(last && (last.itemType === 'TODO_FOLDER' || last.itemType === 'TODO'));
    };

    const isTodoListActive = () => document.activeElement === document.body;

    // 修飾鍵追蹤（旁路觀察，不消費事件）
    const unsubShift = cm.registerKeyObserver({
      id: 'todo-list:shift',
      keys: ['Shift'],
      onDown: () => setIsShiftPressed(true),
      onUp: () => setIsShiftPressed(false),
    });
    const unsubMeta = cm.registerKeyObserver({
      id: 'todo-list:meta',
      keys: ['Meta', 'Control'],
      onDown: () => setIsCommandPressed(true),
      onUp: () => setIsCommandPressed(false),
    });

    // Cmd+Delete 刪除
    const unsubDelete = cm.register({
      command: {
        id: 'todo-list:delete',
        name: t('cmd.deleteSelectedTodos'),
        checkCallback: (checking: boolean) => {
          const ids = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems]
            .filter(Boolean).filter(i => i.itemType === 'TODO').map(i => i.id);
          if (ids.length === 0) return false;
          if (!checking) {
            (document.activeElement as HTMLElement)?.blur();
            useItemStore.getState().removeItems(ids, { needSync: true, navigateOut: true });
          }
          return true;
        },
      },
      hotkeys: [
        { modifiers: ['Mod'], key: 'Delete' },
        { modifiers: ['Mod'], key: 'Backspace' },
      ],
      enabled: isTodoListContext,
    });

    // Escape 返回
    const unsubEscape = cm.register({
      command: {
        id: 'todo-list:escape',
        name: t('cmd.todoListBack'),
        checkCallback: (checking: boolean) => {
          if (!isTodoListActive()) return false;
          const hasSelectedTodo = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean).some(i => i.itemType === 'TODO');
          if (!hasSelectedTodo) return false;
          if (!checking) useSelectedItemsStore.getState().navigateOut();
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
      enabled: isTodoListContext,
    });

    return () => {
      unsubShift();
      unsubMeta();
      unsubDelete();
      unsubEscape();
    };
  }, [filteredNoteIds, setSelectedItemIds, setIsShiftPressed, setIsCommandPressed, selectedFolderType, selectedFolderId, addTodo, localTodayStr, isMobileView, t]);

  // 獲取標題
  const getListTitle = useCallback(() => {
    if (selectedFolderType === 'today') return t('todoToday');
    if (selectedFolderType === 'preview') return t('todoPreview');
    if (selectedFolderType === 'TODO' && selectedFolderId === todoInboxFolder?.id) return t('todoInbox');
    if (selectedFolderType === 'completed') return t('todoCompleted');
    if (selectedFolderType === 'SHARED_TODOS') return t('sharedTodos');
    if (selectedFolderType === 'TODO' && selectedFolderId !== todoInboxFolder?.id) {
      const folder = todoFolders.find(f => f.id === selectedFolderId);
      return folder?.name || '';
    }
    return '';
  }, [selectedFolderType, selectedFolderId, todoInboxFolder?.id, t, todoFolders]);

  // 處理待辦點擊（參考 NoteList 的 handleNoteClick）
  const handleNoteClick = (e, todoId, status) => {
    e.stopPropagation();

    // 🔍 DEBUG: 打印點擊的待辦筆記
    const clickedTodo = todos.find(n => n.id === todoId);
    console.log('[TodoList] 點擊待辦筆記:', clickedTodo);

    // 從 store 獲取最新的 allSelected（關鍵！必須在清空前獲取）
    const currentSelectedTodoIds = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean).filter(i => i.itemType === 'TODO').map(i => i.id);

    // 檢查是否點擊了輸入框
    const isInputClicked = e.target.classList && (
      e.target.classList.contains('todo-title-input') ||
      e.target.classList.contains('todo-input')
    );

    // 點擊非輸入框區域時，主動 blur 目前正在編輯的 todo input
    // 讓 onBlur 的「空白自動刪除」一定會觸發
    if (!isInputClicked && document.activeElement?.classList?.contains('todo-title-input')) {
      (document.activeElement as HTMLElement).blur();
    }

    // 手機版：只聚焦輸入框，不設置 selectedItemIds（避免進入內頁）
    if (isMobileView) {
      if (!isInputClicked) {
        safeSetTimeout(() => {
          const inputRef = titleInputRefs.current[todoId];
          if (inputRef) {
            inputRef.focus();
          }
        }, 0);
      }
      return;
    }

    if ((e.metaKey || e.ctrlKey)) {
      // Command/Ctrl + 點擊：進行多選
      e.preventDefault();
      if (currentSelectedTodoIds.includes(todoId)) {
        useSelectedItemsStore.getState().removeExtraItem(todoId);
      } else {
        if (clickedTodo) {
          useSelectedItemsStore.getState().addExtraItem(clickedTodo);
        }
      }
    } else if (e.shiftKey && currentSelectedTodoIds.length > 0) {
      // Shift + 點擊：範圍選擇
      e.preventDefault();
      const lastSelectedId = currentSelectedTodoIds[currentSelectedTodoIds.length - 1];
      const currentIndex = filteredNoteIds.indexOf(lastSelectedId);
      const clickedIndex = filteredNoteIds.indexOf(todoId);

      if (currentIndex !== -1 && clickedIndex !== -1) {
        const startIndex = Math.min(currentIndex, clickedIndex);
        const endIndex = Math.max(currentIndex, clickedIndex);
        const rangeIds = filteredNoteIds.slice(startIndex, endIndex + 1);
        setSelectedItemIds([...rangeIds]);
      }
    } else {
      // 普通點擊：單選
      if (clickedTodo) {
        setSelectedItems([clickedTodo], { preservePath: true });
        // 清除 isNew 標記（消除呼吸紅點）
        useTodoStore.getState().clearTodoIsNew(todoId);
      }
      // 如果不是點擊輸入框，則聚焦到輸入框
      if (!isInputClicked) {
        safeSetTimeout(() => {
          const inputRef = titleInputRefs.current[todoId];
          if (inputRef) {
            inputRef.focus();
          }
        }, 0);
      }
    }
  };

  // 計算下一個週期時間（基於原本的 reminderTime 日期或今天）
  const getNextPeriodicDate = useCallback((config, originalReminderDate) => {
    if (!config || !config.frequency) return null;

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // 如果原本的 reminderTime 日期超過今天，基於該日期計算
    let baseDate = today;
    if (originalReminderDate) {
      const [year, month, day] = originalReminderDate.split('-').map(Number);
      const origDate = new Date(year, month - 1, day);
      if (origDate >= today) {
        baseDate = origDate;
      }
    }

    switch (config.frequency) {
      case 'DAILY': {
        // 每天：下一個週期就是基準日期 + 1 天
        const nextDate = new Date(baseDate);
        nextDate.setDate(nextDate.getDate() + 1);
        return nextDate;
      }
      case 'WEEKLY': {
        // 每週：找到下一個符合的星期幾
        if (!config.daysOfWeek || config.daysOfWeek.length === 0) return null;
        const currentDay = baseDate.getDay();
        const sortedDays = [...config.daysOfWeek].sort((a, b) => a - b);

        // 找到下一個符合的日期（必須大於基準日期）
        for (const day of sortedDays) {
          if (day > currentDay) {
            const nextDate = new Date(baseDate);
            nextDate.setDate(nextDate.getDate() + (day - currentDay));
            return nextDate;
          }
        }
        // 如果本週沒有了，找下週的第一個
        const firstDay = sortedDays[0];
        const nextDate = new Date(baseDate);
        nextDate.setDate(nextDate.getDate() + (7 - currentDay + firstDay));
        return nextDate;
      }
      case 'MONTHLY': {
        // 每月：找到下一個符合的日期
        if (!config.daysOfMonth || config.daysOfMonth.length === 0) return null;
        const currentDate = baseDate.getDate();
        const sortedDates = [...config.daysOfMonth].sort((a, b) => a - b);

        // 找到本月下一個符合的日期（必須大於基準日期）
        for (const date of sortedDates) {
          if (date > currentDate) {
            const nextDate = new Date(baseDate.getFullYear(), baseDate.getMonth(), date);
            // 確保日期有效（例如 2月30日）
            if (nextDate.getMonth() === baseDate.getMonth()) {
              return nextDate;
            }
          }
        }
        // 如果本月沒有了，找下個月的第一個
        const firstDate = sortedDates[0];
        const nextDate = new Date(baseDate.getFullYear(), baseDate.getMonth() + 1, firstDate);
        return nextDate;
      }
      default:
        return null;
    }
  }, []);

  // 處理 checkbox 點擊（切換完成狀態）
  const handleCheckboxClick = useCallback((e, todo) => {
    e.stopPropagation();

    if (!todo) return;

    const willBeCompleted = !todo.completed;

    // 只有從未勾選變成已勾選時才觸發動畫（參考 NoteList）
    if (willBeCompleted) {
      const checkbox = e.currentTarget;
      checkbox.classList.add('todo-checkbox-clicked');
      // 動畫結束後移除 class
      safeSetTimeout(() => {
        checkbox.classList.remove('todo-checkbox-clicked');
      }, 250);
    }

    let waitTime = 0;
    if (willBeCompleted) {
      waitTime = 250;
    }

    safeSetTimeout(async () => {
      const willBeCompleted2 = !todo.completed;
      const updatePromise = updateTodo({
        ...todo,
        completed: willBeCompleted2,
        updatedAt: Date.now(),
        finishedAt: willBeCompleted2 ? Date.now().toString() : null
      });

      // 如果有週期設定且將要完成，同時創建下一個週期的待辦
      if (willBeCompleted && todo.periodicTaskConfig) {
        const originalReminderDate = getDateFromReminderTime(todo.reminderTime);
        const nextDate = getNextPeriodicDate(todo.periodicTaskConfig, originalReminderDate);
        if (nextDate) {
          const nextDateStr = `${nextDate.getFullYear()}-${String(nextDate.getMonth() + 1).padStart(2, '0')}-${String(nextDate.getDate()).padStart(2, '0')}`;
          const newTodoId = generateObjectID();

          // 取得原有時間或週期設定的時間
          const originalTime = getTimeFromReminderTime(todo.reminderTime);
          const newTime = todo.periodicTaskConfig.timeOfDay || originalTime;

          const newTodo = {
            ...todo,
            id: newTodoId,
            completed: false,
            reminderTime: createReminderTime(nextDateStr, newTime),
            createdAt: Date.now(),
            updatedAt: Date.now(),
            orderAt: Date.now(),
          };

          // 同時執行兩個操作，避免 UI 抖動
          await Promise.all([updatePromise, addTodo(newTodo)]);
        } else {
          await updatePromise;
        }
      } else {
        await updatePromise;
      }
    }, waitTime);
  }, [updateTodo, addTodo, getNextPeriodicDate]);

  const handleContextMenu = useCallback((e, todo) => {
    e.preventDefault();
    e.stopPropagation();

    // 如果右鍵的項目不在選中列表中，先選中它
    if (!selectedItemIds.includes(todo.id)) {
      setSelectedItemIds([todo.id]);
    }

    // 顯示右鍵選單
    useMenuStore.getState().openAt('todoListMenu', e.clientX, e.clientY, { noteId: todo.id });
  }, [selectedItemIds, setSelectedItemIds]);

  // 處理標題輸入（參考 NoteList 的實作）
  // 使用 debounce 避免快速輸入時多個異步 updateNote 交錯完成導致的"行為重播"bug
  const handleInputChange = useCallback((e, todo, field) => {
    if (!todo) return;

    const value = e.target.value;

    // 創建更新後的待辦對象
    const updatedTodo = {
      ...todo,
      [field]: value
    };

    // 先更新 NoteItem 裡面暫存的 note（立即更新 UI）
    const setNoteFunc = noteUpdateRefs.current[todo.id];
    if (setNoteFunc) {
      setNoteFunc(updatedTodo);
    }

    // 若是 name 欄位，立即同步到 liveTitleInput（即時同步到 NoteEditor）
    if (field === 'name') {
      useLiveInputStore.getState().setLiveTitleInput(todo.id, value);
    }

    // 使用 debounce 更新數據庫，避免異步競爭條件
    // 清除之前的 timeout（如果有的話）
    if (updateNoteTimeoutRef.current[todo.id]) {
      clearTimeout(updateNoteTimeoutRef.current[todo.id]);
    }

    // 設置新的 timeout（300ms 後才真正更新數據庫）
    updateNoteTimeoutRef.current[todo.id] = setTimeout(() => {
      delete updateNoteTimeoutRef.current[todo.id];
      updateTodo(updatedTodo);
    }, 300);
  }, [updateTodo]);

  // 處理標題輸入按鍵（參考 NoteList 的實作）
  const handleInputKeyDown = useCallback((e, todo) => {
    // 檢查是否在輸入法組字狀態
    if (e.isComposing || e.nativeEvent?.isComposing) return;

    // 游標在最前面按左方向鍵 → 退出到 list 層（跟 NoteEditor 一致）
    if (e.key === 'ArrowLeft') {
      const input = e.target as HTMLInputElement;
      if (input.selectionStart === 0 && input.selectionEnd === 0) {
        e.preventDefault();
        input.blur();
        useSelectedItemsStore.getState().navigateOut();
        return;
      }
    }

    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      e.stopPropagation();

      const currentSelectedTodoIds = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean).filter(i => i.itemType === 'TODO').map(i => i.id);

      // 手機版：Shift 多選功能不可用，只支持普通上下切換
      if (e.shiftKey && !isMobileView) {
        const selectedNoteId = currentSelectedTodoIds[currentSelectedTodoIds.length - 1];
        const selectedIndex = filteredNoteIds.indexOf(selectedNoteId);

        // 獲取最後一個多選的待辦索引，不包含主選中待辦
        let lastIndex = selectedIndex;
        let nextToLastIndex;

        if (currentSelectedTodoIds.length > 1) {
          const otherSelectedIds = currentSelectedTodoIds.filter(id => id !== selectedNoteId);
          const lastSelectedId = otherSelectedIds[otherSelectedIds.length - 1];
          if (lastSelectedId) {
            nextToLastIndex = filteredNoteIds.indexOf(lastSelectedId);
          }
        }

        // 判斷當前移動方向
        const isMovingUp = e.key === 'ArrowUp';
        // 判斷之前的選擇方向
        const wasSelectingUp = nextToLastIndex > lastIndex;

        if ((wasSelectingUp === isMovingUp) || (currentSelectedTodoIds.length <= 1)) {
          // 方向一致，添加下一個未選擇的待辦
          const targetIndex = isMovingUp ?
            Math.max(0, lastIndex - 1) :
            Math.min(filteredNoteIds.length - 1, lastIndex + 1);

          const targetId = filteredNoteIds[targetIndex];
          if (targetId && targetId !== selectedNoteId && !currentSelectedTodoIds.includes(targetId)) {
            const _t = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === targetId);
            if (_t) useSelectedItemsStore.getState().addExtraItem(_t);
          }
        } else {
          // 方向相反，刪除最後選擇的待辦
          if (currentSelectedTodoIds.length > 1) {
            const lastId = currentSelectedTodoIds[currentSelectedTodoIds.length - 1];
            if (lastId) useSelectedItemsStore.getState().removeExtraItem(lastId);
          }
        }
      } else {
        // 獲取當前待辦在列表中的位置
        const currentIndex = filteredNoteIds.indexOf(todo.id);

        // 計算目標索引
        let targetIndex;
        if (e.key === 'ArrowUp') {
          targetIndex = currentIndex > 0 ? currentIndex - 1 : currentIndex;
        } else {
          targetIndex = currentIndex < filteredNoteIds.length - 1 ? currentIndex + 1 : currentIndex;
        }

        // 如果目標索引有效且不等於當前索引
        if (targetIndex !== currentIndex) {
          const targetNoteId = filteredNoteIds[targetIndex];
          // 手機版不設置 selectedItemIds（避免進入內頁），只聚焦輸入框
          if (!isMobileView) {
            setSelectedItemIds([targetNoteId]);
          }

          // 使用 setTimeout 確保在 DOM 更新後聚焦
          safeSetTimeout(() => {
            const targetInput = titleInputRefs.current[targetNoteId];
            if (targetInput) {
              targetInput.focus();
              targetInput.selectionStart = targetInput.selectionEnd = targetInput.value.length;
            }
          }, 0);
        } else if (e.key === 'ArrowUp' && currentIndex === 0) {
          // 第一個 todo 按上方向鍵 → 游標移到最前面
          const input = e.target as HTMLInputElement;
          input.selectionStart = input.selectionEnd = 0;
        }
      }
    } else if ((e.key === 'Delete' || e.key === 'Backspace') &&
      (todo.name?.trim() === '' || !todo.name) &&
      (!todo.content || todo.content.trim() === '')) {
      // 刪除空待辦
      e.preventDefault();
      e.stopPropagation();

      // 獲取當前待辦在列表中的位置
      const currentIndex = filteredNoteIds.indexOf(todo.id);

      if (currentIndex > 0) {
        // 獲取上一個待辦的 ID
        const prevNoteId = filteredNoteIds[currentIndex - 1];

        // 先聚焦到上一個輸入框（保持鍵盤打開）
        const prevInput = document.querySelector(`[data-id="${prevNoteId}"] .todo-title-input`) as HTMLInputElement;
        if (prevInput) {
          prevInput.focus();
          prevInput.selectionStart = prevInput.selectionEnd = prevInput.value.length;
        }

        // 同步替換 path 末端為上一個待辦，避免 deleteTodo 內部清空 selection 導致閃爍
        if (!isMobileView) {
          const prevTodo = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === prevNoteId);
          if (prevTodo) {
            useSelectedItemsStore.setState(state => ({
              path: [...state.path.slice(0, -1), prevTodo],
              extraItems: [],
            }));
          }
        }

        useItemStore.getState().removeItems([todo.id], { needSync: true });
      } else if (filteredNoteIds.length > 1) {
        // 如果是第一個但不是唯一一個，選取下一個
        const nextNoteId = filteredNoteIds[1];

        // 先聚焦到下一個輸入框（保持鍵盤打開）
        const nextInput = document.querySelector(`[data-id="${nextNoteId}"] .todo-title-input`) as HTMLInputElement;
        if (nextInput) {
          nextInput.focus();
          nextInput.selectionStart = nextInput.selectionEnd = nextInput.value.length;
        }

        // 同步替換 path 末端為下一個待辦，避免 deleteTodo 內部清空 selection 導致閃爍
        if (!isMobileView) {
          const nextTodo = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === nextNoteId);
          if (nextTodo) {
            useSelectedItemsStore.setState(state => ({
              path: [...state.path.slice(0, -1), nextTodo],
              extraItems: [],
            }));
          }
        }

        useItemStore.getState().removeItems([todo.id], { needSync: true });
      } else {
        // 刪除唯一的待辦（直接刪除，不移到垃圾桶）
        useItemStore.getState().removeItems([todo.id], { needSync: true });
        setSelectedItemIds([]);
      }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      // 如果是子任務，在同一父任務下創建新子任務
      if (isSubTask(todo)) {
        createSubtaskAfterRef.current?.(todo);
      } else {
        // 創建新的待辦，傳入當前待辦以便在其下方插入
        // 預覽模式下繼承當前待辦的 reminderTime
        const reminderTimeForNew = selectedFolderType === 'preview' ? todo.reminderTime : undefined;
        createNewTodoRef.current?.(todo, reminderTimeForNew);
      }
    } else if (e.key === 'Escape') {
      if (titleInputRefs.current[todo.id]) {
        titleInputRefs.current[todo.id].blur();
      }
      useSelectedItemsStore.getState().navigateOut();
    } else if (e.key === 'ArrowRight' || e.key === 'Tab') {
      // 處理右箭頭或 Tab 鍵跳到 Editor
      const input = e.target;
      // 如果是 Tab 鍵，或者是右箭頭且光標在文本末尾
      if (e.key === 'Tab' || input.selectionStart === input.value.length) {
        e.preventDefault();
        e.stopPropagation();
        const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
        editorContent?.focus();
      }
    }
  }, [filteredNoteIds, setSelectedItemIds, selectedFolderType, isMobileView]);

  // 處理標題輸入焦點（參考 NoteList 的實作）
  const handleInputFocus = useCallback((e, todo) => {
    // 標記：用戶點擊 input 觸發，防止 auto-focus subscriber 覆蓋游標位置
    userClickedInputRef.current = true;

    // 焦點回來時取消 blur 的刪除檢查（例如切換輸入法時）
    // 只清除同一個 todo 的 blur timeout（切換輸入法時焦點會回到同一個 todo）
    if (blurTimeoutRef.current[todo.id]) {
      clearTimeout(blurTimeoutRef.current[todo.id]);
      delete blurTimeoutRef.current[todo.id];
    }

    const currentIsShiftPressed = usePressedKeyStore.getState().isShiftPressed;
    const currentIsCommandPressed = usePressedKeyStore.getState().isCommandPressed;

    // 使用最新的 allSelected (共用 useSelectedItemsStore)
    const currentSelected = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean).filter(i => i.itemType === 'TODO').map(i => i.id);

    // 手機版：用 JS class 控制 hover-only 元素顯示（取代 CSS :focus-within）
    if (isMobileView) {
      document.querySelectorAll('.todo-item.is-focused').forEach(el => el.classList.remove('is-focused'));
      e.target.closest('.todo-item')?.classList.add('is-focused');
      return;
    }

    // 1) Cmd/Ctrl 多選切換
    if (currentIsCommandPressed) {

      e.preventDefault();
      if (currentSelected.includes(todo.id)) {
        useSelectedItemsStore.getState().removeExtraItem(todo.id);
      } else {
        // 從單選變成複選的那一瞬間，取消文字選取
        if (currentSelected.length === 1) {
          window.getSelection().removeAllRanges();
        }
        const _t = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === todo.id);
        if (_t) useSelectedItemsStore.getState().addExtraItem(_t);
      }
      e.target.blur();
      return;
    }

    // 2) Shift 範圍選取
    if (currentIsShiftPressed && currentSelected.length > 0) {

      e.preventDefault();
      const lastSelectedId = currentSelected[currentSelected.length - 1];
      const currentIndex = filteredNoteIds.indexOf(lastSelectedId);
      const clickedIndex = filteredNoteIds.indexOf(todo.id);

      if (currentIndex !== -1 && clickedIndex !== -1) {
        const start = Math.min(currentIndex, clickedIndex);
        const end = Math.max(currentIndex, clickedIndex);
        const rangeIds = filteredNoteIds.slice(start, end + 1);
        // 從單選變成複選的那一瞬間，取消文字選取
        if (currentSelected.length === 1 && rangeIds.length > 1) {
          window.getSelection().removeAllRanges();
        }
        setSelectedItemIds([...rangeIds]);
      }
      e.target.blur();
      return;
    }

    // 點擊 input 時，保留 path 不重建祖先鏈
    const clickedTodo = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === todo.id);
    if (clickedTodo) {
      setSelectedItems([clickedTodo], { preservePath: true });
      return;
    }
    setSelectedItemIds([todo.id]);
  }, [filteredNoteIds, setSelectedItemIds]);

  // 失去焦點：若沒有任何文字，切換到別的地方就自動刪除
  // 但如果是點擊日期選擇器、資料夾選擇器等互動元件，則不刪除
  const handleTodoTitleBlur = useCallback((e, todo) => {
    if (!todo) return;

    // 🔴 重要：blur 時立即執行 pending 的 updateNote（flush debounce）
    // 這確保用戶看到的最終值會被保存，而不是被之前的異步調用覆蓋
    if (updateNoteTimeoutRef.current[todo.id]) {
      clearTimeout(updateNoteTimeoutRef.current[todo.id]);
      delete updateNoteTimeoutRef.current[todo.id];
      // 使用當前 NoteItem 的狀態來更新（這是用戶看到的最終值）
      const setNoteFunc = noteUpdateRefs.current[todo.id];
      if (setNoteFunc) {
        // 從 DOM 獲取當前輸入的值
        const inputElement = e.target;
        if (inputElement && inputElement.value !== undefined) {
          const currentTodo = { ...todo, name: inputElement.value };
          updateTodo(currentTodo);
        }
      }
    }

    // 手機版：移除 is-focused class
    if (isMobileView) {
      e.target.closest('.todo-item')?.classList.remove('is-focused');
    }

    // 延遲清理即時標題輸入狀態，讓數據庫同步先完成
    safeSetTimeout(() => {
      useLiveInputStore.getState().clearLiveTitleInput(todo.id);
    }, 100);

    // 使用 setTimeout 延遲執行，讓互動元件有時間打開
    // 將 timeout id 存到 ref[todo.id]，這樣焦點回到同一個 todo 時可以取消（例如切換輸入法）
    blurTimeoutRef.current[todo.id] = safeSetTimeout(() => {
      delete blurTimeoutRef.current[todo.id];
      // 重新從 store 獲取最新的 note 狀態（避免使用過時的閉包數據）
      const currentNote = (useItemStore.getState().getByType('TODO') as Todo[]).find(n => n.id === todo.id);
      if (!currentNote) return; // 已經被刪除了

      // 檢查焦點是否仍在同一個待辦項目內
      const todoItemElement = document.querySelector(`[data-id="${todo.id}"]`);
      if (todoItemElement && todoItemElement.contains(document.activeElement)) {
        return;
      }

      // 檢查是否有打開的互動元件（日期選擇器、資料夾選擇器、對話框等）
      const hasOpenInteraction =
        document.querySelector('.date-picker-dropdown') ||
        document.querySelector('.date-picker-overlay') ||
        document.querySelector('.todo-item-folder-dropdown') ||
        document.querySelector('.custom-dialog-overlay');

      if (hasOpenInteraction) {
        return;
      }

      // 如果已設定優先度（priority !== 3），則不刪除空白待辦
      const priority = currentNote.priority || 3;
      if (priority !== 3) {
        return;
      }

      const title = (currentNote.name || '').trim();
      const contentText = (stripContent(currentNote.content || '', true) || '').trim();
      if (title === '' && contentText === '') {
        // 直接刪除，不移到垃圾桶；navigateOut: false 避免自動跳出資料夾
        useItemStore.getState().removeItems([todo.id], { needSync: true, navigateOut: false });

        // 若剛好選中，回到上一層（資料夾）而非清空選擇
        const currentSelections = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean) as any[];
        if (currentSelections.some(i => i.id === todo.id)) {
          const remainingItems = currentSelections.filter(i => i.id !== todo.id);
          if (remainingItems.length > 0) {
            useSelectedItemsStore.getState().setSelectedItems(remainingItems);
          } else {
            useSelectedItemsStore.getState().navigateOut();
          }
        }
      }
    }, 300);
  }, [isMobileView]);

  // 處理提醒點擊
  const handleReminderClick = useCallback((e, todo) => {
    e.stopPropagation();
    useDialogStore.getState().open('reminder', {
      item: todo,
      onConfirm: (itemId, reminderTime, offsetMinutes) => {
        updateTodo({
          ...todo,
          reminderTime,
          offsetMinutes,
          updatedAt: Date.now(),
        });
      },
      onCancel: (itemId) => {
        updateTodo({
          ...todo,
          reminderTime: null,
          offsetMinutes: null,
          updatedAt: Date.now(),
        });
      },
    });
  }, [updateTodo]);

  // 處理刪除提醒
  const handleDeleteReminder = useCallback((e, todo) => {
    e.stopPropagation();
    updateTodo({
      ...todo,
      reminderTime: null,
      updatedAt: Date.now()
    });
  }, [updateTodo]);

  // 拖拽相關處理（參考 NoteList 的實作）
  const handleDragStart = useCallback((todo, e) => {
    const currentSelectedTodoIds = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean).filter(i => i.itemType === 'TODO').map(i => i.id);
    const isMultiSelecting = currentSelectedTodoIds.length > 1 && currentSelectedTodoIds.includes(todo.id);
    const allNotes = (useItemStore.getState().getByType('TODO') as Todo[]);
    const selectedTodos = isMultiSelecting ?
      allNotes.filter(n => currentSelectedTodoIds.includes(n.id)) :
      [todo];

    // 創建拖曳預覽（關鍵：必須使用 setDragImage 覆蓋瀏覽器預設的文字拖曳行為）
    const dragPreview = document.createElement('div');

    // 複選時顯示 "已選擇 N 個項目"
    const titleText = isMultiSelecting
      ? t('selectedItems', { count: selectedTodos.length })
      : (todo.name || stripContent(todo.content, true) || t('untitledTodo'));
    dragPreview.textContent = titleText;

    // 從計算樣式中獲取實際顏色值（避免 setDragImage 時 CSS 變量未解析導致背景異常）
    const rootStyles = getComputedStyle(document.documentElement);
    const editorBgColor = rootStyles.getPropertyValue('--editorBackground').trim() || '#ffffff';
    const onColor = rootStyles.getPropertyValue('--on').trim() || '#000000';

    // mobile 版本簡化樣式（Safari setDragImage 會有白色背景問題）
    const isMobile = window.innerWidth <= 768;
    Object.assign(dragPreview.style, {
      position: 'absolute',
      top: '-9999px',
      left: '-9999px',
      padding: '6px 12px',
      borderRadius: '99px',
      background: isMobile ? 'transparent' : editorBgColor,
      border: isMobile ? 'none' : `1px solid color-mix(in srgb, ${onColor} 16%, transparent)`,
      color: isMobile ? 'gray' : `color-mix(in srgb, ${onColor} 75%, transparent)`,
      fontSize: '13px',
      fontFamily: 'inherit',
      whiteSpace: 'nowrap',
    });

    document.body.appendChild(dragPreview);

    const rect = e.currentTarget.getBoundingClientRect();
    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;

    e.dataTransfer.setDragImage(dragPreview, offsetX, offsetY);

    // 設置拖曳數據（使用 todoid 供待辦區域識別，不要用 noteid 避免被筆記區域接收）
    e.dataTransfer.setData('todoid', todo.id);
    e.dataTransfer.setData('selectedTodos', JSON.stringify(selectedTodos.map(n => n.id)));
    e.dataTransfer.setData('sourceType', 'todolist-todoitem');
    e.dataTransfer.setData('sidebardropsection:todo', '');
    e.dataTransfer.setData('dragItems', JSON.stringify(selectedTodos));
    e.dataTransfer.effectAllowed = 'move';

    // 設定拖曳數據供 dragover/drop 使用
    draggedTodoIdsRef.current = selectedTodos.map(n => n.id);
    dragStartXRef.current = e.clientX;
    dropHandledRef.current = false;

    eventBus.emit('drag:note-editor-drag-overlay', { icon: EditIcon, text: t('insertLink') });
    eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: t('dragToAttach', '拖曳放置後附加') });

    // 拖曳結束後移除預覽元素
    requestAnimationFrame(() => {
      document.body.removeChild(dragPreview);
    });
  }, [t]);

  const handleDragOver = useCallback((e, todo) => {
    e.preventDefault();

    // 檢查是否為待辦內部拖曳
    const draggedIds = draggedTodoIdsRef.current;
    if (draggedIds.length === 0) {

      return;
    }

    // 不能拖到自己身上或複選中的任何項目上
    if (draggedIds.includes(todo.id)) {
      return;
    }

    // 在今日/即將到來視圖中，不允許拖到過期的待辦上
    if (selectedFolderType === 'today' || selectedFolderType === 'preview') {
      const todoDate = getDateFromReminderTime(todo.reminderTime);
      if (todoDate && isDateOverdue(todoDate, localTodayStr)) {
        // 目標是過期的待辦，不允許拖放
        return;
      }
    }

    setDropTargetDateSection(null);

    const todoElement = e.currentTarget;
    const rect = todoElement.getBoundingClientRect();
    const y = e.clientY - rect.top;

    // 如果在上半部分，顯示上方指示器
    if (y < rect.height / 2) {
      if (dropPosition !== 'above' || dropTarget?.id !== todo.id) {

        setDropPosition('above');
        savedDropStateRef.current = { target: todo, position: 'above' };
      }
    } else {
      // 如果在下半部分，判斷是 below 還是 below-subtask
      // 只有目標是一般任務（沒有 parentID）時才能變成子任務
      // 需要右移超過 24px 才算
      const canBeSubtask = !isSubTask(todo);
      const dragStartX = dragStartXRef.current;
      const isMovingRight = dragStartX !== undefined && e.clientX > dragStartX + 24;
      const newPosition = (canBeSubtask && isMovingRight) ? 'below-subtask' : 'below';

      if (dropPosition !== newPosition || dropTarget?.id !== todo.id) {

        setDropPosition(newPosition);
        savedDropStateRef.current = { target: todo, position: newPosition };
      }
    }

    setDropTarget(todo);
  }, [dropPosition, dropTarget, selectedFolderType, localTodayStr]);

  // 執行拖放操作（從 savedDropStateRef 讀取目標位置）- 統一的移動邏輯入口
  const executeDrop = useCallback(async () => {
    // 檢查是否有儲存的拖曳狀態
    if (!savedDropStateRef.current?.target || !savedDropStateRef.current?.position) {
      return false;
    }

    const draggedIds = draggedTodoIdsRef.current;
    if (draggedIds.length === 0) {
      return false;
    }
    const draggedId = draggedIds[0];

    const savedTarget = savedDropStateRef.current.target;
    const actualDropPosition = savedDropStateRef.current.position;

    // 從 store 獲取最新的待辦列表（用 store 已推導好的 selectedFolderId）
    const latestFilteredTodos = (() => {
      const navState = useSelectedItemsStore.getState();
      const latestFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
      const latestFolderId = navState.selectedFolderId;
      const latestPath = navState.path;
      const virtualItem = latestPath.find(i => (i as any).itemType === 'TODO_VIRTUAL_FOLDER');
      const vf = (virtualItem as any)?.id ?? null;
      const latestType = vf === 'today' ? 'today' : vf === 'preview' ? 'preview' : vf === 'completed' ? 'completed'
        : (latestFolderId && latestFolders.some(f => f.id === latestFolderId)) ? 'TODO' : null;
      return useTodoStore.getState().getFilteredTodos(latestType, latestFolderId);
    })();

    // 從最新列表中獲取 draggedTodos 和 actualTargetTodo（關鍵！避免使用過時的 orderAt）
    const allNotes = (useItemStore.getState().getByType('TODO') as Todo[]);
    const draggedTodos = draggedIds.map(id => allNotes.find(t => t.id === id)).filter(Boolean);
    // 從 allNotes 查找目標待辦，以支援子任務拖曳
    const actualTargetTodo = allNotes.find(t => t.id === savedTarget?.id);

    if (draggedTodos.length === 0 || !actualTargetTodo || draggedIds.includes(actualTargetTodo.id)) {

      return false;
    }

    // 獲取目標位置的前後待辦（按照 orderAt 降序排序），排除正在拖曳的項目
    const targetIsSubtask = isSubTask(actualTargetTodo);
    const isBecomingSubtask = actualDropPosition === 'below-subtask';

    let sortedTodos;
    if (isBecomingSubtask) {
      sortedTodos = allNotes.filter(t => t.parentID === actualTargetTodo.id);
    } else if (targetIsSubtask) {
      sortedTodos = allNotes.filter(t => t.parentID === actualTargetTodo.parentID);
    } else {
      sortedTodos = latestFilteredTodos;
    }

    sortedTodos = sortedTodos
      .filter(t => !draggedIds.includes(t.id))
      .sort((a, b) => {
        const aOrder = a.orderAt ? parseFloat(a.orderAt) : 0;
        const bOrder = b.orderAt ? parseFloat(b.orderAt) : 0;
        return aOrder - bOrder;
      });

    const targetIndex = sortedTodos.findIndex(t => t.id === actualTargetTodo.id);

    let baseOrderAt;
    let orderAtStep;

    if (actualDropPosition === 'above') {
      // 放在目標項目上方（升序：需要更小的 orderAt）
      const prevTodo = sortedTodos[targetIndex - 1];

      if (!prevTodo) {
        // 放在最上面（升序：最上面 orderAt 最小）
        const orderAts = sortedTodos.map(t => parseFloat(t.orderAt) || Date.now());
        const minOrderAt = orderAts.length > 0 ? Math.min(...orderAts) : Date.now();
        baseOrderAt = minOrderAt - 1000 * draggedTodos.length;
        orderAtStep = 1000;
      } else {
        const prevOrderAt = parseFloat(prevTodo.orderAt) || Date.now();
        const targetOrderAt = parseFloat(String(actualTargetTodo.orderAt)) || Date.now();
        const gap = targetOrderAt - prevOrderAt;
        orderAtStep = gap / (draggedTodos.length + 1);
        baseOrderAt = prevOrderAt + orderAtStep;
      }
    } else if (isBecomingSubtask) {
      // 變成子任務：放在目標任務的子任務列表最下方（升序：最大 orderAt）
      if (sortedTodos.length === 0) {
        baseOrderAt = Date.now();
        orderAtStep = 1000;
      } else {
        const maxOrderAt = Math.max(...sortedTodos.map(t => parseFloat(t.orderAt) || Date.now()));
        baseOrderAt = maxOrderAt + 1000;
        orderAtStep = 1000;
      }
    } else {
      // 放在目標項目下方（升序：需要更大的 orderAt）
      const nextTodo = sortedTodos[targetIndex + 1];

      if (!nextTodo) {
        // 放在最下面（升序：最大 orderAt）
        const maxOrderAt = Math.max(...sortedTodos.map(t => parseFloat(t.orderAt) || Date.now()));
        baseOrderAt = maxOrderAt + 1000;
        orderAtStep = 1000;
      } else {
        const targetOrderAt = parseFloat(String(actualTargetTodo.orderAt)) || Date.now();
        const nextOrderAt = parseFloat(String(nextTodo.orderAt)) || Date.now();
        const gap = nextOrderAt - targetOrderAt;
        orderAtStep = gap / (draggedTodos.length + 1);
        baseOrderAt = targetOrderAt + orderAtStep;
      }
    }

    // 在今日/即將到來視圖中，獲取目標 reminderTime
    const currentType = (() => {
      const fi = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean) as any[];
      if (fi.some(i => i.itemType === 'TODO_FOLDER' && i.id === 'today')) return 'today';
      if (fi.some(i => i.itemType === 'TODO_FOLDER' && i.id === 'preview')) return 'preview';
      if (fi.some(i => i.itemType === 'TODO_FOLDER' && i.id === 'completed')) return 'completed';
      return null;
    })();
    const targetReminderTime = actualTargetTodo.reminderTime || null;

    // 批次更新所有拖曳的待辦
    let updatedTodos = draggedTodos.map((draggedTodo, i) => {
      const newOrderAt = baseOrderAt + (i * Math.abs(orderAtStep));

      let updatedTodo: Todo = {
        ...draggedTodo,
        orderAt: String(newOrderAt)
      };

      // 統一邏輯：根據目標類型決定被拖曳待辦的歸屬
      if (isBecomingSubtask) {
        // below-subtask → 被拖曳的變成目標任務的子任務
        updatedTodo = { ...updatedTodo, parentID: actualTargetTodo.id, updatedAt: Date.now() };

      } else if (targetIsSubtask) {
        // 目標是子任務 → 被拖曳的變成同一父任務下的子任務
        updatedTodo = { ...updatedTodo, parentID: actualTargetTodo.parentID, updatedAt: Date.now() };

      } else {
        // 目標是一般任務 → 被拖曳的變成一般任務（清除 parentID 使子任務脫離父任務）
        updatedTodo = { ...updatedTodo, parentID: actualTargetTodo.parentID, updatedAt: Date.now() };

      }

      // 在今日/即將到來視圖中，如果目標待辦的 reminderTime 與被拖曳的不同，更新 reminderTime
      if (currentType === 'today' || currentType === 'preview') {
        const draggedReminderTime = draggedTodo.reminderTime || null;

        if (targetReminderTime !== draggedReminderTime) {
          updatedTodo = { ...updatedTodo, reminderTime: targetReminderTime, updatedAt: Date.now() };
        }
      }

      return updatedTodo;
    });

    // 在自定義資料夾中，準備更新 indexes
    const currentFolder = (() => {
      const navState = useSelectedItemsStore.getState();
      const latestFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
      const latestFolderId = navState.selectedFolderId;
      const latestPath = navState.path;
      const isViewFilter = latestPath.some(i => (i as any).itemType === 'TODO_VIRTUAL_FOLDER');
      if (isViewFilter || !latestFolderId) return null;
      return latestFolders.find(f => f.id === latestFolderId) ?? null;
    })();

    await updateTodo(updatedTodos);

    return true;
  }, [updateTodo, updateTodoFolder]);

  // 處理 drop 事件（調用 executeDrop）
  const handleDrop = useCallback(async (e) => {
    e.preventDefault();
    e.stopPropagation();

    // 同步標記「已由 handleDrop 處理」，防止 dragEnd 在 await 期間觸發雙重執行
    dropHandledRef.current = true;

    await executeDrop();

    savedDropStateRef.current = null;
    setDropTarget(null);
    setDropPosition(null);
    draggedTodoIdsRef.current = [];
    dragStartXRef.current = undefined;
    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  }, [executeDrop]);

  // 處理拖曳結束（關鍵：在清除狀態前執行移動操作）
  const handleDragEnd = useCallback(async () => {
    if (!dropHandledRef.current && savedDropStateRef.current?.target && savedDropStateRef.current?.position) {
      await executeDrop();
    }

    // 清除所有拖曳狀態
    setDropTarget(null);
    setDropPosition(null);
    setDropTargetDateSection(null);
    savedDropStateRef.current = null;
    draggedTodoIdsRef.current = [];
    dragStartXRef.current = undefined;
    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  }, [executeDrop]);

  const handleDragLeave = useCallback(() => {
    // 不要立即清除，讓 drop 時可以使用儲存的狀態
  }, []);

  // 處理整個容器的 dragover（確保有接收器，避免拖曳預覽回原點）
  const handleWrapperDragOver = useCallback((e) => {
    if (draggedTodoIdsRef.current.length > 0) {
      e.preventDefault();
    }
  }, []);

  // 處理整個容器的 drop（兜底：當事件沒被子元素處理時執行）
  const handleWrapperDrop = useCallback(async (e) => {
    e.preventDefault();

    // 如果有儲存的拖曳狀態，執行移動操作
    if (savedDropStateRef.current?.target && savedDropStateRef.current?.position) {
      await executeDrop();
    }

    // 清除狀態
    savedDropStateRef.current = null;
    setDropTarget(null);
    setDropPosition(null);
    draggedTodoIdsRef.current = [];
    dragStartXRef.current = undefined;
    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  }, [executeDrop]);

  // 處理日期 section header 的拖曳經過（今日/即將到來視圖）
  const handleDateSectionDragOver = useCallback((e, dateKey) => {
    e.preventDefault();
    e.stopPropagation();

    // 不允許拖曳到過期區域
    if (dateKey === 'overdue') {
      return;
    }

    // 清除其他 drop target
    setDropTarget(null);
    setDropPosition(null);

    setDropTargetDateSection(dateKey);
  }, []);

  // 處理日期 section header 的拖曳離開
  const handleDateSectionDragLeave = useCallback((e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX;
    const y = e.clientY;

    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
      setDropTargetDateSection(null);
    }
  }, []);

  // 處理日期 section header 的 drop（今日/即將到來視圖）
  const handleDateSectionDrop = useCallback(async (e, dateKey) => {
    e.preventDefault();
    e.stopPropagation();

    //立即清除拖曳狀態，避免 handleDragEnd 重複執行
    savedDropStateRef.current = null;

    // 不允許拖曳到過期區域
    if (dateKey === 'overdue') {
      setDropTargetDateSection(null);
      return;
    }

    const draggedId = e.dataTransfer.getData('todoid');
    if (!draggedId) {
      setDropTargetDateSection(null);
      return;
    }

    const draggedTodo = (useItemStore.getState().getByType('TODO') as Todo[]).find(n => n.id === draggedId);
    if (!draggedTodo) {
      setDropTargetDateSection(null);
      return;
    }

    try {
      // 根據 dateKey 決定新的 reminderTime
      let newReminderTime;
      if (dateKey === 'no-date') {
        newReminderTime = null;
      } else {
        // dateKey 是日期字串 (YYYY-MM-DD)，轉換為 reminderTime
        newReminderTime = createReminderTime(dateKey, null);
      }

      // 統一邏輯：拖到 section 時變成一般任務
      const currentState = useSelectedItemsStore.getState();
      const currentFolder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f =>
        f.id === selectedFolderId && f.itemType === 'TODO_FOLDER'
      );
      const todoInboxFolder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.name === 'todoInbox');

      const updatedTodo = {
        ...draggedTodo,
        reminderTime: newReminderTime,
        parentID: currentFolder?.id || todoInboxFolder?.id || '',
        updatedAt: Date.now()
      };

      await updateTodo(updatedTodo);

    } catch (error) {
      console.error('[TodoList] handleDateSectionDrop 錯誤:', error);
    }

    setDropTargetDateSection(null);
    draggedTodoIdsRef.current = [];
    dragStartXRef.current = undefined;
    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  }, [updateTodo]);

  // 點擊列表空白處取消選擇
  const handleListClick = useCallback((e) => {
    if (e.target === todoListRef.current) {
      if (document.activeElement?.classList?.contains('todo-title-input')) {
        (document.activeElement as HTMLElement).blur();
      }
      setSelectedItemIds([]);
    }
  }, [setSelectedItemIds]);

  // 創建子任務
  const createSubtask = useCallback(async (parentTodo) => {
    if (!parentTodo) return;

    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const myMemberID = userData.ID || '';
    const now = Date.now();

    // 計算子任務的 orderAt（放在該父任務的子任務列表最後）
    const existingChildren = childrenMap.get(parentTodo.id) || [];
    let newOrderAt;
    if (existingChildren.length > 0) {
      const minOrderAt = Math.min(...existingChildren.map(c => parseFloat(String(c.orderAt)) || now));
      newOrderAt = String(minOrderAt - 1000);
    } else {
      newOrderAt = String(now);
    }

    const newNoteId = generateObjectID();
    const newSubtask: Todo = {
      id: newNoteId,
      itemType: 'TODO',
      name: '',
      content: '',
      tags: [],
      completed: false,
      createdAt: now,
      updatedAt: now,
      orderAt: newOrderAt,
      reminderTime: parentTodo.reminderTime,
      finishedAPIs: [],
      isNew: false,
      offsetMinutes: 0,
      parentID: parentTodo.id,
      priority: 3,
      version: 0
    };

    await addTodo(newSubtask);

    // 手機版不自動選中（不進入內頁），只聚焦輸入框就地編輯
    if (!isMobileView) {
      // 保留當前資料夾/虛擬視圖上下文
      setSelectedItems([newSubtask as any], { preservePath: true });
    }

    // 聚焦到新子任務的輸入框
    const focusNewInput = () => {
      const newInput = document.querySelector(`[data-id="${newSubtask.id}"] .todo-title-input`) as HTMLElement;
      if (newInput) {
        newInput.focus();
      } else {
        requestAnimationFrame(focusNewInput);
      }
    };
    requestAnimationFrame(focusNewInput);
  }, [addTodo, setSelectedItemIds, childrenMap, isMobileView]);

  // 在某個子任務下方創建新子任務（子任務按 Enter 時調用）
  const createSubtaskAfter = useCallback(async (currentSubtask) => {
    if (!currentSubtask || !isSubTask(currentSubtask)) return;

    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const myMemberID = userData.ID || '';
    const now = Date.now();

    // 計算新子任務的 orderAt（在當前子任務下方）
    const siblings = childrenMap.get(currentSubtask.parentID) || [];
    const currentOrderAt = parseFloat(String(currentSubtask.orderAt)) || now;

    // 找到當前子任務在 siblings 中的位置，以及下一個子任務
    // 升序排序（orderAt 小的在上面，大的在下面）
    const sortedSiblings = [...siblings].sort((a, b) => {
      const aOrder = parseFloat(String(a.orderAt)) || 0;
      const bOrder = parseFloat(String(b.orderAt)) || 0;
      return aOrder - bOrder;
    });

    const currentIndex = sortedSiblings.findIndex(s => s.id === currentSubtask.id);
    const nextSibling = currentIndex !== -1 ? sortedSiblings[currentIndex + 1] : null;

    let newOrderAt;
    if (nextSibling && nextSibling.orderAt) {
      // 有下一個子任務，取中間值
      const nextOrderAt = parseFloat(String(nextSibling.orderAt));
      newOrderAt = String((currentOrderAt + nextOrderAt) / 2);
    } else {
      // 沒有下一個子任務，用 Date.now() 確保排在最後
      newOrderAt = String(Date.now());
    }

    const newNoteId = generateObjectID();
    const newSubtask: Todo = {
      id: newNoteId,
      itemType: 'TODO',
      name: '',
      content: '',
      tags: [],
      completed: false,
      createdAt: now,
      updatedAt: now,
      orderAt: newOrderAt,
      reminderTime: currentSubtask.reminderTime,
      finishedAPIs: [],
      isNew: false,
      offsetMinutes: 0,
      parentID: currentSubtask.parentID,
      priority: 3,
      version: 0
    };

    await addTodo(newSubtask);

    // 手機版不自動選中（不進入內頁），只聯焦輸入框就地編輯
    if (!isMobileView) {
      // 保留當前資料夾/虛擬視圖上下文
      setSelectedItems([newSubtask as any], { preservePath: true });
    }

    // 聚焦到新子任務的輸入框
    const focusNewInput = () => {
      const newInput = document.querySelector(`[data-id="${newSubtask.id}"] .todo-title-input`) as HTMLElement;
      if (newInput) {
        newInput.focus();
      } else {
        requestAnimationFrame(focusNewInput);
      }
    };
    requestAnimationFrame(focusNewInput);
  }, [addTodo, setSelectedItemIds, childrenMap, isMobileView]);

  // 更新 ref
  createSubtaskAfterRef.current = createSubtaskAfter;

  // 創建新待辦（按 Enter 或點擊「+ 新增待辦」時調用）
  const handleCreateNewTodo = useCallback(async (currentTodo = null, reminderTimeOverride = undefined) => {
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const myMemberID = userData.ID || '';
    const now = Date.now();

    // 在 today/preview 視圖下，自動設置當日 reminderTime（使用本地時間）
    const todayReminderTime = (selectedFolderType === 'today' || selectedFolderType === 'preview') ? createReminderTime(localTodayStr, null) : null;
    const reminderTime = reminderTimeOverride !== undefined ? reminderTimeOverride : todayReminderTime;

    let newOrderAt = String(now);

    if (currentTodo) {
      // 沒有 indexName 但有 currentTodo，在其下方插入
      // 獲取當前篩選列表中的所有待辦
      const latestFilteredTodos = (() => {
        const navState = useSelectedItemsStore.getState();
        const latestFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
        const latestFolderId = navState.selectedFolderId;
        const latestPath = navState.path;
        const virtualItem = latestPath.find(i => (i as any).itemType === 'TODO_VIRTUAL_FOLDER');
        const vf = (virtualItem as any)?.id ?? null;
        const latestType = vf === 'today' ? 'today' : vf === 'preview' ? 'preview' : vf === 'completed' ? 'completed'
          : (latestFolderId && latestFolders.some(f => f.id === latestFolderId)) ? 'TODO' : null;
        return useTodoStore.getState().getFilteredTodos(latestType, latestFolderId);
      })();

      // 因為新建的是頂層待辦（parentID = null），只考慮其他頂層待辦的 orderAt
      // 如果 currentTodo 是子任務，找到它的父任務來計算位置
      let referenceParentTodo = currentTodo;
      if (isSubTask(currentTodo)) {
        referenceParentTodo = latestFilteredTodos.find(t => t.id === currentTodo.parentID);
        if (!referenceParentTodo) {
          referenceParentTodo = currentTodo;
        }
      }

      const topLevelTodos = latestFilteredTodos.filter(t => !isSubTask(t));
      // 升序排序（orderAt 小的在上面，大的在下面）
      const sortedTopLevelTodos = [...topLevelTodos].sort((a, b) => {
        const aOrder = a.orderAt ? parseFloat(String(a.orderAt)) : 0;
        const bOrder = b.orderAt ? parseFloat(String(b.orderAt)) : 0;
        return aOrder - bOrder;
      });

      const referenceOrderAt = referenceParentTodo.orderAt ? parseFloat(String(referenceParentTodo.orderAt)) : now;

      // 找到參考待辦的位置和下一個頂層待辦
      const currentIndex = sortedTopLevelTodos.findIndex(t => t.id === referenceParentTodo.id);
      const nextTodo = currentIndex !== -1 ? sortedTopLevelTodos[currentIndex + 1] : null;

      if (nextTodo && nextTodo.orderAt) {
        // 有下一個頂層待辦，取中間值
        const nextOrderAt = parseFloat(String(nextTodo.orderAt));
        newOrderAt = String((referenceOrderAt + nextOrderAt) / 2);
      } else {
        // 沒有下一個頂層待辦，用 Date.now() 確保排在最後
        newOrderAt = String(Date.now());
      }
    }

    // 取得目標資料夾 ID（folderName="todoInbox"，舊資料 type 可能是 null）
    const folders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
    const todoInboxFolderId = folders.find(f => f.name === 'todoInbox')?.id || '';
    let targetFolderId = todoInboxFolderId; // 預設放入 todoInbox
    if (selectedFolderType === 'TODO' && selectedFolderId !== todoInboxFolder?.id) {
      targetFolderId = selectedFolderId;
    }
    // inbox、today、upcoming 等視圖，放入 todoInbox 資料夾

    const newNoteId = generateObjectID();
    const newNote: Todo = {
      id: newNoteId,
      itemType: 'TODO',
      parentID: targetFolderId,
      name: '',
      content: '',
      tags: [],
      completed: false,
      createdAt: now,
      updatedAt: now,
      orderAt: newOrderAt,
      reminderTime: reminderTime,
      finishedAPIs: [],
      isNew: false,
      offsetMinutes: 0,
      priority: 3,
      version: 0
    };

    // 創建待辦
    await addTodo(newNote);

    // 手機版不自動選中（不進入內頁），只聚焦輸入框就地編輯
    if (!isMobileView) {
      // 保留當前資料夾/虛擬視圖上下文
      setSelectedItems([newNote as any], { preservePath: true });
    }

    // 聚焦到新待辦的輸入框
    const focusNewInput = () => {
      const newInput = document.querySelector(`[data-id="${newNote.id}"] .todo-title-input`) as HTMLElement;
      if (newInput) {
        newInput.focus();
      } else {
        requestAnimationFrame(focusNewInput);
      }
    };
    requestAnimationFrame(focusNewInput);
  }, [selectedFolderType, selectedFolderId, todoInboxFolder?.id, addTodo, setSelectedItemIds, filteredNoteIds, currentTodoFolder, updateTodoFolder, localTodayStr, isMobileView]);

  // 更新 ref
  createNewTodoRef.current = handleCreateNewTodo;

  // 切換子任務展開/收起
  const toggleSubtasksCollapse = useCallback((parentId) => {
    setCollapsedSubtasks(prev => {
      const next = new Set(prev);
      if (next.has(parentId)) {
        next.delete(parentId);
      } else {
        next.add(parentId);
      }
      // 保存到 localStorage
      try {
        localStorage.setItem('collapsedSubtasks', JSON.stringify([...next]));
      } catch { }
      return next;
    });
  }, []);

  const AddTodoItem = ({ reminderTime, afterTodoId }) => {
    if (selectedFolderType === 'completed' || selectedFolderType === 'SHARED_TODOS') return null;
    return (
      <div
        className="section-add-item"
        onMouseDown={(e) => e.preventDefault()}
        onClick={() => {
          if (isMobileView && window.focusHiddenInput) {
            window.focusHiddenInput();
          }
          const afterTodo = afterTodoId ? (useItemStore.getState().getByType('TODO') as Todo[]).find(n => n.id === afterTodoId) : null;
          handleCreateNewTodo(afterTodo || null, reminderTime);
        }}
      >
        <AddLineIcon className="section-add-item-plus" />
        <span className="section-add-item-text">{t('addTodo')}</span>
      </div>
    );
  };

  // 組合 handlers 供 TodoItem 使用
  const handlers = useMemo(() => ({
    handleDragStart,
    handleDragOver,
    handleDrop,
    handleDragEnd,
    handleDragLeave,
    handleNoteClick,
    handleContextMenu,
    handleCheckboxClick,
    handleInputChange,
    handleInputKeyDown,
    handleInputFocus,
    handleTodoTitleBlur,
    handleReminderClick,
    handleDeleteReminder,
    createSubtask,
    toggleSubtasksCollapse,
    collapsedSubtasks,
    isViewerMode
  }), [
    handleDragStart,
    handleDragOver,
    handleDrop,
    handleDragEnd,
    handleDragLeave,
    handleNoteClick,
    handleContextMenu,
    handleCheckboxClick,
    handleInputChange,
    handleInputKeyDown,
    handleInputFocus,
    handleTodoTitleBlur,
    handleReminderClick,
    handleDeleteReminder,
    createSubtask,
    toggleSubtasksCollapse,
    collapsedSubtasks,
    isViewerMode
  ]);

  // 渲染 topbar 右側按鈕（手機版和桌面版共用）
  const renderTopbarRight = () => (
    <>
      {/* 手機版更多選單按鈕 - 只在自定義待辦資料夾顯示 */}
      {isMobileView && currentTodoFolder && (
        <button
          className="custom-toolbar-button"
          tabIndex={-1}
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            useMenuStore.getState().openAt('todoListMore', rect.right, rect.bottom + 4);
          }}
        >
          <MoreIcon />
        </button>
      )}
    </>
  );

  // 群組資料夾：如果選中的待辦資料夾有子資料夾，顯示「請先選擇一個資料夾」
  if (selectedFolderId && selectedFolderType === 'TODO') {
    const hasChildFolders = todoFolders.some(f => f.parentID === selectedFolderId);
    if (hasChildFolders) {
      return (
        <div className="select-folder-message">{t('selectFolderFirst')}</div>
      );
    }
  }

  return (
    <div
      className="todo-list-wrapper"
      onDragOver={handleWrapperDragOver}
      onDrop={handleWrapperDrop}
    >
      {/* 手機版頂部標題列 */}
      {isMobileView && (
        <MobileTopbar
          leftIcon="menu"
          onLeftClick={() => setIsMobileSidebarOpen(true)}
          title={getListTitle()}
          titleSuffix={currentTodoFolder && (
            <ShareMemberThumbnailList itemId={currentTodoFolder.id} permissions={currentTodoFolder._permissions || []} size="small" maxDisplay={5} />
          )}
          rightContent={renderTopbarRight()}
        />
      )}

      {/* 桌面版頂部標題列 */}
      {!isMobileView && (
        <div className="todolist-topbar">
          <div className="todolist-topbar-left">
            <div className="todolist-topbar-title-row">
              <span className="todolist-topbar-title">{getListTitle()}</span>
              {currentTodoFolder && (
                <ShareMemberThumbnailList itemId={currentTodoFolder.id} permissions={currentTodoFolder._permissions || []} maxDisplay={10} />
              )}
            </div>
            {selectedFolderType === 'preview' ? (
              // PREVIEW 視圖：顯示月份選擇器
              <DatePickerDropdown
                value={previewVisibleDate}
                onChange={(dateStr) => {
                  if (dateStr) {
                    setPreviewVisibleDate(dateStr);
                    // 計算選擇的日期距離今天多少天
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    const targetDate = new Date(dateStr);
                    const diffDays = Math.ceil((targetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)) + 1;
                    // 確保已加載足夠的天數
                    if (diffDays > previewLoadedDays) {
                      setPreviewLoadedDays(diffDays + 30); // 額外加載 30 天
                    }
                    safeSetTimeout(() => {
                      const section = document.querySelector(`.todolist-date-section[data-date-key="${dateStr}"]`);
                      if (section) {
                        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    }, 100);
                  }
                }}
                className="todolist-preview-calendar"
                closeOnSelect={true}
                trigger={
                  <div className="todolist-topbar-month-picker">
                    <span className="todolist-topbar-month">{new Date(previewVisibleDate).getMonth() + 1}月</span>
                    <span className="todolist-topbar-year">{new Date(previewVisibleDate).getFullYear()}</span>
                    <ArrowIcon className="todolist-topbar-month-arrow" />
                  </div>
                }
              />
            ) : selectedFolderType !== 'completed' && (
              // 其他視圖：顯示任務數量（不含子任務）
              <div className={`todolist-topbar-task-count ${todoCountWithoutSubtasks === 0 ? 'hidden' : ''}`}>
                <CheckedIcon className="todolist-topbar-task-count-icon" />
                <span>{t('taskCount', { count: todoCountWithoutSubtasks })}</span>
              </div>
            )}
          </div>
          <div className="todolist-topbar-right">
            {currentTodoFolder && canAccessSharingDialog(currentTodoFolder) && (
              <button
                className="custom-toolbar-button"
                tabIndex={-1}
                onClick={() => {
                  useDialogStore.getState().open('sharing', {
                    item: { id: currentTodoFolder.id, name: currentTodoFolder.name, isPublic: (currentTodoFolder as any).isPublic, itemType: currentTodoFolder.itemType },
                    onSave: async (settings) => {
                      await updateItemShareSettings({ ...settings, extra: {} });
                      await syncService.syncChanges();
                      useTempHintStore.getState().setTempHint(settings.isPublic ? t('shareEnabled') : t('shareDisabled'));
                    },
                  });
                }}
                title={t('shareSettings')}
              >
                <ShareCollabIcon />
              </button>
            )}
          </div>
        </div>
      )}

      {/* PREVIEW 視圖的周視圖導航 */}
      {selectedFolderType === 'preview' && (
        <div className="todolist-week-nav">
          {(() => {
            // 根據當前可見日期生成一週的日期
            const visibleDate = new Date(previewVisibleDate);
            const dayOfWeek = visibleDate.getDay(); // 0=週日, 1=週一, ...
            const weekStart = new Date(visibleDate);
            // 計算週一：週日(0)要減6天，週一(1)減0天，週二(2)減1天...
            const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
            weekStart.setDate(visibleDate.getDate() - daysToMonday);

            const weekDays = [];
            // 簡化的星期名稱：一、二、三、四、五、六、日
            const weekdayShort = ['一', '二', '三', '四', '五', '六', '日'];

            for (let i = 0; i < 7; i++) {
              const date = new Date(weekStart);
              date.setDate(weekStart.getDate() + i);
              const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
              const isActive = dateStr === previewVisibleDate;
              const isToday = dateStr === localTodayStr;
              const isPast = dateStr < localTodayStr;
              weekDays.push(
                <div
                  key={dateStr}
                  className={`todolist-week-nav-day ${isPast ? 'disabled' : ''} ${isActive ? 'active' : ''}`}
                  onClick={() => {
                    // 過去的日期不能點擊
                    if (isPast) return;
                    // 點擊跳轉到該日期
                    const section = document.querySelector(`.todolist-date-section[data-date-key="${dateStr}"]`);
                    if (section) {
                      section.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }
                  }}
                >
                  <span className="todolist-week-nav-weekday">{weekdayShort[i]}</span>
                  <span className="todolist-week-nav-date">{date.getDate()}</span>
                </div>
              );
            }
            return weekDays;
          })()}
        </div>
      )}

      {/* 待辦列表 */}
      <CustomScrollbar offsetRight={4} onScroll={handlePreviewScroll}>
        <div
          className={`todos-list ${selectedFolderType === 'preview' ? 'preview-mode' : ''}`}
          ref={todoListRef}
          onClick={handleListClick}
        >
          {filteredNoteIds.length === 0 && selectedFolderType !== 'preview' ? (
            <>
              <AddTodoItem
                reminderTime={selectedFolderType === 'today' ? createReminderTime(localTodayStr, null) : null}
                afterTodoId={null}
              />
              <div className="todolist-empty-message">
                {t('noTodos')}
              </div>
            </>
          ) : (selectedFolderType === 'today' || selectedFolderType === 'completed' || selectedFolderType === 'preview') && displayedGroupedTodos ? (
            // 今天視圖/預覽視圖/已完成視圖：按日期分組顯示
            displayedGroupedTodos.map(([dateKey, todosInGroup]) => (
              <div key={dateKey} className="todolist-date-section todolist-date-section-spaced" data-date-key={dateKey}>
                <div
                  className={`todolist-date-header ${dateKey === 'overdue' ? 'todolist-header-collapsible' : ''} ${dateKey === 'overdue' && !isOverdueExpanded ? 'collapsed' : ''} ${dropTargetDateSection === dateKey ? 'drop-target' : ''}`}
                  onDragOver={(selectedFolderType === 'today' || selectedFolderType === 'preview') && dateKey !== 'overdue' ? (e) => handleDateSectionDragOver(e, dateKey) : undefined}
                  onDragLeave={(selectedFolderType === 'today' || selectedFolderType === 'preview') && dateKey !== 'overdue' ? handleDateSectionDragLeave : undefined}
                  onDrop={(selectedFolderType === 'today' || selectedFolderType === 'preview') && dateKey !== 'overdue' ? (e) => handleDateSectionDrop(e, dateKey) : undefined}
                >
                  <div className="todolist-date-header-left">
                    {dateKey === 'overdue' && (
                      <ArrowIcon
                        className="arrow-icon"
                        onClick={() => setIsOverdueExpanded(!isOverdueExpanded)}
                      />
                    )}
                    <span className="todolist-date-header-text">
                      {dateKey === 'no-date' ? t('noDate') : dateKey === 'overdue' ? t('overdue') : formatDateHeader(dateKey)}
                    </span>
                  </div>
                  {dateKey === 'overdue' && (
                    <DatePickerDropdown
                      value={null}
                      onChange={async (dateStr) => {
                        // 批量更新所有過期待辦的日期
                        const updatePromises = todosInGroup.map(todo => {
                          const originalTime = getTimeFromReminderTime(todo.reminderTime);
                          return updateTodo({
                            ...todo,
                            reminderTime: createReminderTime(dateStr, originalTime),
                            updatedAt: Date.now()
                          });
                        });
                        await Promise.all(updatePromises);
                      }}
                      onTimeChange={async (timeStr) => {
                        // 批量更新所有過期待辦的時間
                        const updatePromises = todosInGroup.map(todo => {
                          const originalDate = getDateFromReminderTime(todo.reminderTime);
                          return updateTodo({
                            ...todo,
                            reminderTime: createReminderTime(originalDate, timeStr),
                            updatedAt: Date.now()
                          });
                        });
                        await Promise.all(updatePromises);
                      }}
                      trigger={
                        <span className="todolist-reschedule-btn">
                          {t('reschedule')}
                        </span>
                      }
                    />
                  )}
                </div>
                {dropTargetDateSection === dateKey && (
                  <div className="todolist-section-drop-indicator" />
                )}
                <div className="todolist-date-separator" />
                {(dateKey !== 'overdue' || isOverdueExpanded) && (
                  <div className="todolist-date-items">
                    {todosInGroup.filter(note => !isSubTask(note)).map(note => (
                      <React.Fragment key={note.id}>
                        <TodoItem
                          noteId={note.id}
                          selectedItemIds={selectedItemIds}
                          isMultiSelecting={isMultiSelecting}
                          dropTarget={dropTarget}
                          dropPosition={dropPosition}
                          isShiftPressed={isShiftPressed}
                          isCommandPressed={isCommandPressed}
                          currentTime={currentTime}
                          titleInputRefs={titleInputRefs}
                          noteUpdateRefs={noteUpdateRefs}
                          handlers={handlers}

                          childrenMap={childrenMap}
                        />
                        {/* 渲染子任務（根據展開狀態） */}
                        {!collapsedSubtasks.has(note.id) && (childrenMap.get(note.id) || []).map(subtask => (
                          <TodoItem
                            key={subtask.id}
                            noteId={subtask.id}
                            selectedItemIds={selectedItemIds}
                            dropTarget={dropTarget}
                            dropPosition={dropPosition}
                            isShiftPressed={isShiftPressed}
                            isCommandPressed={isCommandPressed}
                            currentTime={currentTime}
                            titleInputRefs={titleInputRefs}
                            noteUpdateRefs={noteUpdateRefs}
                            handlers={handlers}

                            isSubtask={true}
                          />
                        ))}
                      </React.Fragment>
                    ))}
                    {selectedFolderType !== 'completed' && dateKey !== 'overdue' && (
                      <AddTodoItem
                        reminderTime={dateKey === 'no-date' ? null : createReminderTime(dateKey, null)}
                        afterTodoId={todosInGroup[todosInGroup.length - 1]?.id || null}
                      />
                    )}
                  </div>
                )}
              </div>
            ))
          ) : (
            // 其他視圖：普通列表（todoInbox 等）
            <>
              {filteredTodos.filter(note => !isSubTask(note)).map(note => (
                <React.Fragment key={note.id}>
                  <TodoItem
                    noteId={note.id}
                    selectedItemIds={selectedItemIds}
                    isMultiSelecting={isMultiSelecting}
                    dropTarget={dropTarget}
                    dropPosition={dropPosition}
                    isShiftPressed={isShiftPressed}
                    isCommandPressed={isCommandPressed}
                    currentTime={currentTime}
                    titleInputRefs={titleInputRefs}
                    noteUpdateRefs={noteUpdateRefs}
                    handlers={handlers}

                    childrenMap={childrenMap}
                  />
                  {/* 渲染子任務（根據展開狀態） */}
                  {!collapsedSubtasks.has(note.id) && (childrenMap.get(note.id) || []).map(subtask => (
                    <TodoItem
                      key={subtask.id}
                      noteId={subtask.id}
                      selectedItemIds={selectedItemIds}
                      dropTarget={dropTarget}
                      dropPosition={dropPosition}
                      isShiftPressed={isShiftPressed}
                      isCommandPressed={isCommandPressed}
                      currentTime={currentTime}
                      titleInputRefs={titleInputRefs}
                      noteUpdateRefs={noteUpdateRefs}
                      handlers={handlers}

                      isSubtask={true}
                    />
                  ))}
                </React.Fragment>
              ))}
              <AddTodoItem
                reminderTime={selectedFolderType === 'today' ? createReminderTime(localTodayStr, null) : null}
                afterTodoId={filteredNoteIds[filteredNoteIds.length - 1] || null}
              />
            </>
          )}
        </div>
      </CustomScrollbar>

      {/* 待辦右鍵選單 */}
      <TodoRightClickMenu />

      {/* 複選操作提示 */}
      <CustomHint
        show={isMultiSelecting}
        buttons={[
          {
            text: t('delete'),
            type: 'error',
            onClick: () => {
              useItemStore.getState().removeItems(selectedItemIds, { needSync: true, navigateOut: true });
            }
          }
        ]}
      >
        {t('selectedTodosHint', { count: selectedItemIds.length })}
      </CustomHint>


      {/* 手機版更多選單 */}
      {moreMenu?.show && (
        <PopupMenu
          x={moreMenu.position.x}
          y={moreMenu.position.y}
          onClose={() => useMenuStore.getState().close('todoListMore')}
        >
          <PopupMenuItem
            icon={EditIcon}
            onClick={() => {
              useMenuStore.getState().close('todoListMore');
              if (currentTodoFolder) {
                useDialogStore.getState().open('editFolder', {
                  title: t('editTodoFolder'),
                  initialName: currentTodoFolder.name,
                  existingNames: (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[])
                    .filter(f => f.name?.toLowerCase() !== currentTodoFolder.name?.toLowerCase())
                    .map(f => f.name || '').filter(Boolean),
                  placeholder: t('todoFolderNamePlaceholder'),
                  onConfirm: async (newName: string) => {
                    await updateTodoFolder({ ...currentTodoFolder, name: newName });
                  },
                });
              }
            }}
          >
            {t('editTodoFolder')}
          </PopupMenuItem>
          <PopupMenuItem
            icon={DeleteIcon}
            danger
            onClick={() => {
              useMenuStore.getState().close('todoListMore');
              if (currentTodoFolder) {
                useDialogStore.getState().open('deleteFolder', {
                  folder: {
                    ...currentTodoFolder,
                    isTodoFolder: true
                  }
                });
              }
            }}
          >
            {t('deleteTodoFolder')}
          </PopupMenuItem>
        </PopupMenu>
      )}

      {/* EditFolderNameDialog 已改為 NotePlugin overlay 掛載 */}
    </div>
  );
}

export default TodoList;

