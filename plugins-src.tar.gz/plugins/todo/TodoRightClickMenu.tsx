import React, { useEffect, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';

import CopyNoteIcon from '../../../assets/copy_note.svg?react';
import LinkIcon from '../../../assets/icon_link_24.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';

import { useMenuStore } from '../../../Store/menuStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTodoStore, type Todo } from './todoStore';
import { useItemStore } from '../../../Store/itemStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { useTheme } from '../../setting/ThemeProvider';
import { canDelete as canDeleteItem } from '../../../utils/shareUtils';

/**
 * TodoRightClickMenu — 待辦列表的右鍵選單
 * 使用 menuStore key: 'todoListMenu'
 * 只包含待辦相關的選項（複製待辦、複製連結、刪除）
 */
export function TodoRightClickMenu() {
  const { t } = useTranslation();
  const menuState = useMenuStore(state => state.menus['todoListMenu']);
  const showMenu = menuState?.show;
  const position = menuState?.position || { x: 0, y: 0 };
  const noteId = menuState?.data?.noteId;
  const hideRightClickMenu = () => useMenuStore.getState().close('todoListMenu');
  const theme = useTheme();
  const setTempHint = useTempHintStore(state => state.setTempHint);
  const allSelected = useSelectedItemsStore(state => [state.path.at(-1), ...state.extraItems].filter(Boolean) as any[]);
  const menuRef = useRef(null);

  const handleEscKey = useCallback((event) => {
    if (event.detail.key === 'Escape' && showMenu) {
      hideRightClickMenu();
    }
  }, [showMenu]);

  const handleOutsideClick = useCallback((event) => {
    if (showMenu) {
      const menuElement = document.querySelector('.right-click-menu');
      if (menuElement && !menuElement.contains(event.target)) {
        hideRightClickMenu();
      }
    }
  }, [showMenu]);

  useEffect(() => {
    if (showMenu) {
      document.addEventListener('menu-key', handleEscKey);
      document.addEventListener('click', handleOutsideClick);

      // 檢查是否在螢幕下二分之一
      if (menuRef.current) {
        const menuHeight = menuRef.current.offsetHeight;
        const screenHeight = window.innerHeight;
        const isBottomHalf = position.y > screenHeight / 2;

        if (isBottomHalf) {
          menuRef.current.style.top = `${position.y - menuHeight}px`;
        }
      }
    }

    return () => {
      document.removeEventListener('menu-key', handleEscKey);
      document.removeEventListener('click', handleOutsideClick);
    };
  }, [showMenu, handleEscKey, handleOutsideClick, position.y]);

  // 取得待辦資料
  const todoNote = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === noteId);

  if (!showMenu || !noteId) return null;

  // 複製待辦
  const handleCopyTodo = async () => {
    try {
      const { generateObjectID } = await import('../../../../../services/utils/objectIDUtil.mjs');
      const newTodoId = generateObjectID();

      const sourceTodo = (useItemStore.getState().getByType('TODO') as Todo[]).find(t => t.id === noteId);
      if (!sourceTodo) {
        setTempHint(t('copyTodoFailed'));
        hideRightClickMenu();
        return;
      }

      const newTodo = {
        ...sourceTodo,
        id: newTodoId,
        name: `${sourceTodo.name || t('untitledTodo')} ${t('copySuffix')}`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        orderAt: Date.now()
      };

      await useTodoStore.getState().addTodo(newTodo, true);
      setTempHint(t('todoCopied'));
    } catch (error) {
      console.error('複製待辦失敗:', error);
      setTempHint(t('copyTodoFailed'));
    }
    hideRightClickMenu();
  };

  // 複製待辦連結
  const handleCopyTodoLink = () => {
    if (noteId) {
      const isDone = (todoNote as any)?.completed === true;
      const link = isDone
        ? `CubeLV://todo/${noteId}?done=1`
        : `CubeLV://todo/${noteId}`;
      navigator.clipboard.writeText(link)
        .then(() => {
          setTempHint(t('todoLinkCopied'));
        })
        .catch(err => {
          console.error('複製連結失敗:', err);
        });
    } else {
      console.error('無法複製連結：待辦 ID 未定義');
    }
    hideRightClickMenu();
  };

  // 刪除待辦
  const handleDeleteTodo = () => {
    if (allSelected.some(i => i.id === noteId)) {
      useTodoStore.getState().deleteTodo(allSelected.filter(i => i.itemType === 'TODO').map(i => i.id), true, true);
    } else {
      useTodoStore.getState().deleteTodo(noteId, true, true);
    }
    hideRightClickMenu();
  };

  return (
    <>
      {showMenu && (
        <>
          {/* 透明滿版遮罩層，點擊關閉菜單 */}
          <div
            className="right-click-menu-overlay"
            onClick={hideRightClickMenu}
          />
          <div
            ref={menuRef}
            className="right-click-menu"
            style={{
              position: 'fixed',
              top: position.y,
              left: position.x,
            }}
          >
            <button
              className="right-click-menu-item"
              onClick={handleCopyTodo}
              onMouseDown={(e) => e.preventDefault()}
            >
              <CopyNoteIcon />
              <span>{t('copyTodo')}</span>
            </button>

            <button
              className="right-click-menu-item"
              onClick={handleCopyTodoLink}
              onMouseDown={(e) => e.preventDefault()}
            >
              <LinkIcon />
              <span>{t('copyTodoLink')}</span>
            </button>

            {(!todoNote || canDeleteItem(todoNote)) && (
            <button
              className={`right-click-menu-item ${theme.mode === 'dark' ? 'error-dark' : 'error-light'}`}
              onClick={handleDeleteTodo}
              onMouseDown={(e) => e.preventDefault()}
            >
              <DeleteIcon />
              <span>{t('deleteTodo')}</span>
            </button>
            )}
          </div>
        </>
      )}
    </>
  );
}
