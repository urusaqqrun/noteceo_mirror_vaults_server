import React from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

/**
 * DeleteIndexDialog — 刪除板塊確認 Dialog
 * 
 * 透過 dialogStore.open('deleteIndex', data) 開啟
 */

interface DeleteIndexDialogData {
    indexName: string;
    onConfirm: () => void;
}

function DeleteIndexDialog() {
    const { t } = useTranslation();
    const isOpen = useDialogStore(s => s.dialogs['deleteIndex']?.show);
    const data = useDialogStore(s => s.dialogs['deleteIndex']?.data) as DeleteIndexDialogData | null;
    const close = () => useDialogStore.getState().close('deleteIndex');

    const indexName = data?.indexName ?? '';
    const onConfirm = data?.onConfirm ?? null;

    if (!isOpen || !data) return null;

    return (
        <CustomDialog
            isOpen={true}
            onClose={close}
            title={t('deleteSubCategory')}
            onConfirm={() => { onConfirm?.(); close(); }}
        >
            <p className="custom-dialog-description">
                {t('deleteSectionConfirm', { name: indexName })}
            </p>
        </CustomDialog>
    );
}

export default DeleteIndexDialog;
