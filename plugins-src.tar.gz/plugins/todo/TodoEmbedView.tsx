// TodoEmbedView — Todo 插件的嵌入式預覽渲染器
//
// 由 TodoPlugin 註冊到 EmbedRendererRegistry，
// 被 ItemEmbedExtension（editor 基礎設施）委派渲染。
// 使用 TodoItem 組件（非 NoteItem），含子任務渲染。

import React, { useMemo } from 'react';
import TodoItem from './TodoItem';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTodoStore } from './todoStore';
import { useItemStore } from '../../../Store/itemStore';
import { getWorkspace } from '../../../workspace/Workspace';
import type { EmbedRendererProps } from '../../../Store/embedRendererRegistry';

const createTodoHandlers = (todoId: string, updateTodo) => ({
  handleDragStart: () => { },
  handleDragOver: () => { },
  handleDrop: () => { },
  handleDragEnd: () => { },
  handleDragLeave: () => { },
  handleNoteClick: (e) => {
    const todos = useItemStore.getState().getByType('TODO') as import('./todoStore').Todo[];
    const todo = todos.find(t => t.id === todoId);
    if (!todo) return;

    if (e?.currentTarget?.closest('.ai-admin-room')) {
      getWorkspace()?.openWindow({ id: todoId, itemType: 'TODO' });
      return;
    }

    let targetFolderId = todo.parentID;
    if (todo.parentID && !targetFolderId) {
      const parent = todos.find(t => t.id === todo.parentID);
      if (parent) targetFolderId = parent.parentID;
    }
    useSelectedItemsStore.getState().setSelectedItems(
      [todo],
      { scrollToFocusItem: !!targetFolderId, scrollToNote: true, highlightItemId: todoId }
    );
  },
  handleContextMenu: () => { },
  handleCheckboxClick: (e, todo) => {
    e.stopPropagation();
    if (!todo) return;

    const willBeCompleted = !todo.completed;

    if (willBeCompleted) {
      const checkbox = e.currentTarget;
      checkbox.classList.add('todo-checkbox-clicked');
      setTimeout(() => {
        checkbox.classList.remove('todo-checkbox-clicked');
      }, 250);
    }

    const waitTime = willBeCompleted ? 250 : 0;

    setTimeout(async () => {
      await updateTodo({
        ...todo,
        completed: willBeCompleted,
        updatedAt: Date.now(),
        finishedAt: willBeCompleted ? Date.now().toString() : null
      });
    }, waitTime);
  },
  handleInputChange: () => { },
  handleInputKeyDown: () => { },
  handleInputFocus: () => { },
  handleTodoTitleBlur: () => { },
  createSubtask: () => { },
  toggleSubtasksCollapse: () => { },
  collapsedSubtasks: new Set(),
});

const TodoEmbedView: React.FC<EmbedRendererProps> = ({ itemId }) => {
  const selectedItemIds = useSelectedItemsStore(state =>
    [state.path.at(-1)?.id, ...state.extraItems.map(i => i.id)].filter(Boolean) as string[]
  );
  const todos = useItemStore(s => s.byType['TODO'] ?? []) as import('./todoStore').Todo[];
  const updateTodo = useTodoStore(state => state.updateTodo);

  // 建立子任務映射
  const childrenMap = useMemo(() => {
    const map = new Map<string, any[]>();
    const subtasks = todos
      .filter(t => t.parentID === itemId)
      .sort((a, b) => {
        const aOrder = a.orderAt ? parseFloat(String(a.orderAt)) : 0;
        const bOrder = b.orderAt ? parseFloat(String(b.orderAt)) : 0;
        return bOrder - aOrder;
      });
    if (subtasks.length > 0) {
      map.set(itemId, subtasks);
    }
    return map;
  }, [itemId, todos]);

  const handlers = useMemo(() => createTodoHandlers(itemId, updateTodo), [itemId, updateTodo]);

  return (
    <>
      {/* 渲染主待辦項目 */}
      <TodoItem
        noteId={itemId}
        selectedItemIds={selectedItemIds}
        dropTarget={null}
        dropPosition={null}
        isShiftPressed={false}
        isCommandPressed={false}
        currentTime={new Date()}
        titleInputRefs={null}
        handlers={handlers}
        noteUpdateRefs={null}
        childrenMap={childrenMap}
      />
      {/* 渲染子任務 */}
      {(childrenMap.get(itemId) || []).map(subtask => (
        <TodoItem
          key={subtask.id}
          noteId={subtask.id}
          selectedItemIds={selectedItemIds}
          dropTarget={null}
          dropPosition={null}
          isShiftPressed={false}
          isCommandPressed={false}
          currentTime={new Date()}
          titleInputRefs={null}
          handlers={createTodoHandlers(subtask.id, updateTodo)}
          noteUpdateRefs={null}
          isSubtask={true}
        />
      ))}
    </>
  );
};

export default TodoEmbedView;
