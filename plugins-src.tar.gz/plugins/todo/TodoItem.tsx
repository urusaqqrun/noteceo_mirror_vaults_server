import React, { useCallback, useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './TodoItem.css';
import PinIcon from '../../../assets/icon_pin_24.svg?react';
import EmptyCheckIcon from '../../../assets/icon_round_empty_24.svg?react';
import CheckedIcon from '../../../assets/icon_round_checked_24.svg?react';
import FolderIcon from '../../../assets/icon_folder_outline_24.svg?react';
import BreathingDot from '../../common/BreathingDot';
import TodoDragHandleIcon from '../../../assets/icon_drag_handle_blocks_24.svg?react';
import CalendarIcon from '../../../assets/icon_calendar_outline_24.svg?react';
import FlagIcon from '../../../assets/category/flag.svg?react';
import RepeatIcon from '../../../assets/icon_repeat_arrow_16_n.svg?react';
import PhotoIcon from '../../../assets/icon_photo_24.svg?react';
import SubtaskArrowIcon from '../../../assets/icon_arrowchevron_up_24.svg?react';
import FolderTreeSelect from '../../common/FolderTreeSelect';
import DatePickerDropdown from '../../common/DatePickerDropdown';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';
import AudioPlayer from '../../common/AudioPlayer';
import { formatTimestamp, formatStartDateTime } from '../../Utils/dateFormat';
import { useTodoStore, Todo } from './todoStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';

import { getDateFromReminderTime, getTimeFromReminderTime, createReminderTime } from '../../../utils/reminderTimeUtils';
import { useIsMobileView } from '../../../hooks/useWindowSize';

// 使用 window.textUtils
const { stripContent } = window.textUtils;

function TodoItem({
    noteId,
    selectedItemIds,
    isMultiSelecting = false,
    dropTarget,
    dropPosition,
    isShiftPressed,
    isCommandPressed,
    currentTime,
    titleInputRefs,
    handlers,
    noteUpdateRefs,
    isSubtask = false,    // 是否為子任務
    childrenMap = null    // 父任務 -> 子任務列表映射
}) {
    const { t } = useTranslation();

    // 處理特殊資料夾名稱的翻譯
    const getDisplayName = (folderName) => {
        if (folderName === 'inbox') return t('inbox');
        if (folderName === 'todoInbox') return t('todoInbox');
        if (folderName === 'trash') return t('trash');
        return folderName;
    };

    const {
        handleDragStart,
        handleDragOver,
        handleDrop,
        handleDragEnd,
        handleDragLeave,
        handleNoteClick,
        handleContextMenu,
        handleCheckboxClick,
        handleInputChange,
        handleInputKeyDown,
        handleInputFocus,
        createSubtask,
        toggleSubtasksCollapse,
        collapsedSubtasks,
        isViewerMode = false
    } = handlers;

    // 透過 selector 取得最新 todo 物件
    const noteState = useItemStore(useCallback(state => (state.byType['TODO'] ?? []).find(n => n.id === noteId) as Todo | undefined, [noteId]));
    const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as import('./todoStore').TodoFolder[];
    const { path: navPath, lastSelected } = useSelectedItemsStore(state => ({
        path: state.path,
        lastSelected: state.path.at(-1) ?? null
    }));
    const isCompletedView = lastSelected?.itemType === 'TODO_FOLDER' && lastSelected?.id === 'completed';
    const isVirtualTodoView = lastSelected?.itemType === 'TODO_FOLDER' && ['today', 'preview', 'completed'].includes(lastSelected?.id);
    const storeSelectedItemIds = navPath.map(i => i.id);
    // 統一使用 store 的 selectedFolderId
    const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
    const updateTodoWithoutUpdateAt = useTodoStore(state => state.updateTodoWithoutUpdateAt);
    const todoInboxId = todoFolders.find(f => f.name === 'todoInbox')?.id;
    const isMobileView = useIsMobileView();

    const [note, setNote] = useState(noteState);



    const [isEditorActive] = useState(false);

    // 資料夾選擇 dropdown 狀態
    const [showFolderDropdown, setShowFolderDropdown] = useState(false);
    const [folderDropdownDirection, setFolderDropdownDirection] = useState('down');
    const folderDropdownRef = useRef(null);

    // 點擊外部關閉資料夾選擇 dropdown
    useEffect(() => {
        if (!showFolderDropdown) return;
        const handleClickOutside = (e) => {
            if (folderDropdownRef.current && !folderDropdownRef.current.contains(e.target)) {
                setShowFolderDropdown(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [showFolderDropdown]);

    // 將 setNote 暴露給父組件
    useEffect(() => {
        if (noteUpdateRefs) {
            noteUpdateRefs.current[noteId] = setNote;
        }
    }, [noteId, setNote, noteUpdateRefs]);

    useEffect(() => {
        if (!document.activeElement?.classList.contains('todo-title-input')) {
            setNote(noteState);
        } else {
            // 強制更新以顯示 pin 圖標改變
            if (note && noteState && (
                note.pinnedAt !== noteState.pinnedAt ||
                note.completed !== noteState.completed ||
                note.reminderTime !== noteState.reminderTime ||
                note.parentID !== noteState.parentID ||
                note.priority !== noteState.priority ||
                note.isNew !== noteState.isNew
            )) {
                setNote(noteState);
            }
        }
    }, [noteState]);

    // 初始化 textarea 高度
    useEffect(() => {
        const textarea = titleInputRefs?.current?.[noteId];
        if (textarea && textarea.tagName === 'TEXTAREA') {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        }
    }, [noteId, note?.name]);

    const isSelected = selectedItemIds.includes(noteId);
    const isMainSelected = isSelected && noteId === selectedItemIds[selectedItemIds.length - 1];

    // 防護：如果 note 不存在，不渲染任何內容
    if (!note) return null;

    // todoDragProps：waiting 模式可拖曳
    const todoDragProps = !isCompletedView ? {
        draggable: true,
        onDragStart: (e) => handleDragStart(note, e),
    } : {};

    // 整個 todo-item 可拖曳
    const canDragTodo = !isCompletedView;

    return (
        <div
            draggable={canDragTodo}
            onDragStart={(e) => canDragTodo && handleDragStart(note, e)}
            onDragOver={(e) => handleDragOver(e, note)}
            onDrop={(e) => handleDrop(e, note)}
            onDragEnd={(e) => handleDragEnd(e, note)}
            onDragLeave={(e) => handleDragLeave(e)}
            onClick={(e) => handleNoteClick(e, noteId)}
            onContextMenu={(e) => handleContextMenu(e, note)}
            data-id={noteId}
        >
            <div
                className={`todo-item ${isSelected
                    ? isEditorActive && isMainSelected
                        ? 'selected'
                        : 'selecting'
                    : ''
                    } ${dropTarget?.id === noteId ? `drop-${dropPosition}` : ''} ${isSelected && isMultiSelecting ? 'multi-selecting' : ''
                    } ${isCompletedView ? 'completed-view' : ''} ${(isShiftPressed || isCommandPressed) && !isMainSelected ? 'no-hover' : ''
                    } ${isSubtask ? 'is-subtask' : ''
                    } ${isSubtask ? 'has-parent' : ''} ${''
                    }`}
            >
                {/* 複選時覆蓋層 */}
                {isMultiSelecting && (
                    <div
                        className="todo-item-overlay"
                        draggable={true}
                        onDragStart={(e) => handleDragStart(note, e)}
                    />
                )}

                {/* isNew 紅點指示器 */}
                {!!note.isNew && (
                    <BreathingDot className="note-item-new-indicator" />
                )}

                {/* 左容器 */}
                <div className="note-item-left-container">
                    <div className={`todo-item-layout ${note.priority === 1 ? 'priority-1' : note.priority === 2 ? 'priority-2' : ''}`}>
                        {/* 拖曳握把 + checkbox */}
                        <div className="todo-item-controls" {...todoDragProps}>
                            <div className={`todo-drag-handle ${(isCompletedView || isViewerMode) ? 'disabled' : ''} ${(isShiftPressed || isCommandPressed) && !isMainSelected ? 'shift-pressed' : ''}`}>
                                <TodoDragHandleIcon />
                            </div>
                            <div
                                className={`todo-checkbox ${note.priority === 1 ? 'priority-1' : note.priority === 2 ? 'priority-2' : ''} ${(isShiftPressed || isCommandPressed) && !isMainSelected ? 'shift-pressed' : ''}`}
                                onClick={(e) => !isViewerMode && handleCheckboxClick(e, note)}
                            >
                                {note.completed ? <CheckedIcon /> : <EmptyCheckIcon />}
                                {!note.completed && (
                                    <div className="todo-checkbox-hover-check">
                                        <CheckedIcon />
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* 右側內容 */}
                        <div className="todo-item-content">
                            <div className="todo-item-title">
                                <div className="note-title-container">
                                    <div className="title-left-container">
                                        {/* 語音播放器 */}
                                        {(note.audioURLs?.length > 0 || note.audioUrl_local?.length > 0) && (
                                            <AudioPlayer
                                                audioURLs={note.audioURLs}
                                                audioUrl_local={note.audioUrl_local}
                                            />
                                        )}

                                        {note.pinnedAt && (
                                            <div className="note-pin-icon">
                                                <PinIcon />
                                            </div>
                                        )}

                                        {/* 待辦標題輸入框 */}
                                        <textarea
                                            ref={(el) => { if (titleInputRefs) titleInputRefs.current[noteId] = el; }}
                                            className={`note-title todo-title-input ${note.completed ? 'completed-todo' : ''} ${(isShiftPressed || isCommandPressed) && !isMainSelected ? 'shift-pressed' : ''}`}
                                            value={note.name || ''}
                                            onChange={(e) => !isCompletedView && handleInputChange(e, note, 'name')}
                                            onKeyDown={(e) => !isCompletedView && handleInputKeyDown(e, note)}
                                            onBlur={(e) => !isCompletedView && handlers?.handleTodoTitleBlur?.(e, note)}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (isCompletedView) {
                                                    handleNoteClick(e, noteId);
                                                } else {
                                                    handleInputFocus(e, note);
                                                }
                                            }}
                                            placeholder={t('untitledTodo')}
                                            readOnly={isCompletedView || isViewerMode}
                                            rows={1}
                                        />
                                    </div>

                                </div>
                            </div>

                            {/* 待辦描述（有 content 時顯示） */}
                            {note.content && stripContent(note.content)?.trim() && (
                                <div className="todo-item-description" {...todoDragProps}>{stripContent(note.content)}</div>
                            )}

                            {/* 待辦 meta row：日期時間、標籤、資料夾、優先度 */}
                            {(() => {
                                const hasTags = note.tags && note.tags.length > 0;
                                const priority = note.priority || 3;

                                // 計算圖片數量
                                const countImagesInContent = () => {
                                    let count = 0;
                                    if (note.imgURLs && Array.isArray(note.imgURLs)) {
                                        for (const url of note.imgURLs) {
                                            if (note.content && note.content.includes(url)) count++;
                                        }
                                    }
                                    if (note.imageUrl_local && Array.isArray(note.imageUrl_local)) {
                                        for (const url of note.imageUrl_local) {
                                            if (note.content && note.content.includes(url)) count++;
                                        }
                                    }
                                    return count;
                                };
                                const imgCount = countImagesInContent();

                                // 日期時間顯示狀態
                                const noteDate = getDateFromReminderTime(note.reminderTime);
                                const isOverdue = (() => {
                                    if (!noteDate) return false;
                                    const today = new Date();
                                    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
                                    return noteDate < todayStr;
                                })();
                                let datetimeState = 'hide';
                                if (lastSelected?.itemType === 'TODO_FOLDER' && (lastSelected?.id === 'today' || lastSelected?.id === 'preview')) {
                                    datetimeState = (isOverdue || note.periodicTaskConfig) ? 'show' : 'hover';
                                } else {
                                    datetimeState = 'show';
                                }

                                // 資料夾顯示狀態
                                const folder = note.parentID ? todoFolders.find(f => f.id === note.parentID) : null;
                                let folderState = 'hide';
                                if (folder) {
                                    if (isVirtualTodoView) {
                                        folderState = 'show';
                                    } else {
                                        folderState = 'hover';
                                    }
                                }

                                const imagesState = imgCount > 0 ? 'show' : 'hide';

                                // 優先度點擊處理
                                const handlePriorityClick = async (e) => {
                                    e.stopPropagation();
                                    const newPriority = priority === 3 ? 2 : priority === 2 ? 1 : 3;
                                    await updateTodoWithoutUpdateAt({ ...note, priority: newPriority });
                                };

                                // 日期顏色類
                                const getDateColorClass = () => {
                                    if (!noteDate) return 'date-color-gray';
                                    const today = new Date();
                                    today.setHours(0, 0, 0, 0);
                                    const noteDateObj = new Date(noteDate + 'T00:00:00');
                                    const tomorrow = new Date(today);
                                    tomorrow.setDate(tomorrow.getDate() + 1);
                                    if (noteDateObj < today) return 'date-color-error';
                                    if (noteDateObj.getTime() === today.getTime()) return 'date-color-green';
                                    if (noteDateObj.getTime() === tomorrow.getTime()) return 'date-color-orange';
                                    return 'date-color-purple';
                                };

                                // 重複顯示文字
                                const getRepeatDisplayText = () => {
                                    if (!note.periodicTaskConfig) return null;
                                    let config: { frequency?: string; daysOfWeek?: number[]; daysOfMonth?: number[] };
                                    try {
                                        config = typeof note.periodicTaskConfig === 'string'
                                            ? JSON.parse(note.periodicTaskConfig)
                                            : note.periodicTaskConfig;
                                    } catch {
                                        return null;
                                    }
                                    const weekdays = [t('sunday'), t('monday'), t('tuesday'), t('wednesday'), t('thursday'), t('friday'), t('saturday')];
                                    const isWeekdays = config.frequency === 'WEEKLY' &&
                                        config.daysOfWeek?.length === 5 &&
                                        [1, 2, 3, 4, 5].every(d => config.daysOfWeek.includes(d));
                                    switch (config.frequency) {
                                        case 'DAILY': return t('repeatDaily');
                                        case 'WEEKLY':
                                            if (isWeekdays) return t('repeatWeekdaysHint');
                                            return t('repeatEveryWeekday', { weekday: weekdays[config.daysOfWeek?.[0] ?? 0] });
                                        case 'MONTHLY': return t('repeatEveryMonthDay', { day: config.daysOfMonth?.[0] });
                                        default: return null;
                                    }
                                };

                                // 日期時間元素
                                const datetimeElement = (state) => {
                                    if (state === 'hide') return null;

                                    if (isCompletedView) {
                                        return (
                                            <div key="finishedAt" className={`todo-item-finishedAt ${state === 'hover' ? 'hover-only' : ''}`}>
                                                <span>{note.finishedAt ? formatTimestamp(note.finishedAt) : ''}</span>
                                            </div>
                                        );
                                    }

                                    const noteTime = getTimeFromReminderTime(note.reminderTime);
                                    const handleDateChange = async (dateStr) => {
                                        await updateTodoWithoutUpdateAt({ ...note, reminderTime: createReminderTime(dateStr, noteTime) });
                                    };
                                    const handleTimeChange = async (timeStr) => {
                                        await updateTodoWithoutUpdateAt({ ...note, reminderTime: createReminderTime(noteDate, timeStr) });
                                    };
                                    const handleRepeatChange = async (repeatObj) => {
                                        await updateTodoWithoutUpdateAt({ ...note, periodicTaskConfig: repeatObj });
                                    };
                                    const repeatText = getRepeatDisplayText();
                                    return (
                                        <DatePickerDropdown
                                            key="datetime"
                                            value={noteDate}
                                            timeValue={noteTime}
                                            repeatValue={note.periodicTaskConfig}
                                            onChange={handleDateChange}
                                            onTimeChange={handleTimeChange}
                                            onRepeatChange={handleRepeatChange}
                                            className={state === 'hover' ? 'hover-only' : ''}
                                            trigger={
                                                <div className="todo-item-datetime">
                                                    <div className={`todo-item-datetime-left ${getDateColorClass()}`}>
                                                        <CalendarIcon className="todo-item-datetime-icon" />
                                                        <span>{noteDate ? formatStartDateTime(noteDate, noteTime) : t('noDate')}</span>
                                                    </div>
                                                    {repeatText && (
                                                        <div className="todo-item-datetime-right">
                                                            <RepeatIcon className="todo-item-repeat-icon" />
                                                            <span>{repeatText}</span>
                                                        </div>
                                                    )}
                                                </div>
                                            }
                                        />
                                    );
                                };

                                // 資料夾元素
                                const folderElement = (state) => {
                                    if (state === 'hide' || !folder) return null;
                                    const FolderIconComponent = FolderIcon;

                                    const handleFolderClick = (e) => {
                                        e.stopPropagation();
                                        if (isCompletedView) return;
                                        const rect = e.currentTarget.getBoundingClientRect();
                                        setFolderDropdownDirection(rect.top < window.innerHeight / 2 ? 'down' : 'up');
                                        setShowFolderDropdown(!showFolderDropdown);
                                    };
                                    const handleFolderSelect = async (folderId) => {
                                        await updateTodoWithoutUpdateAt({ ...note, parentID: folderId });
                                        setShowFolderDropdown(false);
                                    };

                                    return (
                                        <div key="folder" className={`todo-item-folder-wrapper ${state === 'hover' ? 'hover-only' : ''} ${showFolderDropdown ? 'active' : ''}`} ref={folderDropdownRef}>
                                            <div className={`todo-item-folder ${isCompletedView ? 'disabled' : ''}`} onClick={handleFolderClick}>
                                                <FolderIconComponent className="todo-item-folder-icon" />
                                                <span className="todo-item-folder-name">{getDisplayName(folder.name)}</span>
                                            </div>
                                            {!isCompletedView && showFolderDropdown && (
                                                <div className={`todo-item-folder-dropdown ${folderDropdownDirection}`}>
                                                    <FolderTreeSelect
                                                        mode="selector"
                                                        types={['TODO']}
                                                        value={note.parentID}
                                                        onChange={(val) => handleFolderSelect(val)}
                                                        showCount={false}
                                                        showInbox={true}
                                                        showTrash={false}
                                                    />
                                                    <div className="todo-item-folder-dropdown-divider" />
                                                    <div
                                                        className="folder todo-item-folder-dropdown-delete"
                                                        onClick={async (e) => {
                                                            e.stopPropagation();
                                                            setShowFolderDropdown(false);
                                                            await useTodoStore.getState().deleteTodo([note.id], true, true);
                                                        }}
                                                    >
                                                        <span className="folder-name">
                                                            <DeleteIcon className="folder-icon" />
                                                            <div>{t('deleteTodo')}</div>
                                                        </span>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    );
                                };

                                // 圖片元素
                                const imagesElement = (state) => {
                                    if (state === 'hide') return null;
                                    return (
                                        <div key="images" className={`todo-item-images ${state === 'hover' ? 'hover-only' : ''}`}>
                                            <PhotoIcon className="todo-item-images-icon" />
                                            <span className="todo-item-images-badge">{Math.min(imgCount, 9)}</span>
                                        </div>
                                    );
                                };

                                // 優先度元素
                                const priorityElement = (state) => {
                                    if (state === 'hide') return null;
                                    return (
                                        <div
                                            key="priority"
                                            className={`todo-item-priority ${state === 'hover' ? 'hover-only' : ''} ${priority === 1 ? 'priority-1' : priority === 2 ? 'priority-2' : ''}`}
                                            onClick={handlePriorityClick}
                                        >
                                            <FlagIcon className="todo-item-priority-icon" />
                                        </div>
                                    );
                                };

                                // 子任務資訊
                                const children = childrenMap?.get(note.id) || [];
                                const hasChildren = children.length > 0;
                                const completedCount = children.filter(c => c.completed === true).length;
                                const totalCount = children.length;
                                const isCollapsed = collapsedSubtasks?.has(note.id);

                                // 子任務進度元素
                                const subtaskProgressElement = () => {
                                    if (isSubtask) return null;
                                    if (!hasChildren) return null;
                                    return (
                                        <div
                                            key="subtask-progress"
                                            className="todo-item-subtask-toggle"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                toggleSubtasksCollapse?.(note.id);
                                            }}
                                        >
                                            <SubtaskArrowIcon className={`todo-item-subtask-arrow ${isCollapsed ? 'collapsed' : ''}`} />
                                            <span className="todo-item-subtask-count">{completedCount}/{totalCount}</span>
                                        </div>
                                    );
                                };

                                // 添加子待辦按鈕元素
                                const addSubtaskElement = () => {
                                    if (isSubtask) return null;
                                    if (isCompletedView || isViewerMode) return null;
                                    return (
                                        <div
                                            key="add-subtask"
                                            className="todo-item-add-subtask hover-only"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                createSubtask?.(note);
                                            }}
                                        >
                                            <span>+ {t('addSubtask')}</span>
                                        </div>
                                    );
                                };

                                // 收集並排序元素
                                const normalItems = [];
                                const hoverItems = [];

                                if (datetimeState === 'show') normalItems.push(datetimeElement('show'));
                                else if (datetimeState === 'hover') hoverItems.push(datetimeElement('hover'));

                                if (folderState === 'show') normalItems.push(folderElement('show'));
                                else if (folderState === 'hover') hoverItems.push(folderElement('hover'));

                                if (imagesState === 'show') normalItems.push(imagesElement('show'));

                                const subtaskProgress = subtaskProgressElement();
                                if (subtaskProgress) normalItems.push(subtaskProgress);

                                const subtaskBtn = addSubtaskElement();
                                if (subtaskBtn) hoverItems.push(subtaskBtn);

                                if (!isCompletedView) {
                                    hoverItems.push(priorityElement('hover'));
                                }

                                // 子任務隱藏 meta-row
                                if (isSubtask) return null;

                                return (
                                    <div className="todo-item-meta-row" {...todoDragProps}>
                                        <div className="todo-item-meta-left">
                                            {normalItems}
                                            {hoverItems}
                                        </div>
                                        <div className="todo-item-meta-right">
                                            {hasTags && (
                                                <span className="todo-item-tags">
                                                    {note.tags.map(tag => `#${tag}`).join(' ')}
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                );
                            })()}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default React.memo(TodoItem, (prev, next) => {
    const sameNoteId = prev.noteId === next.noteId;
    const selectedPrev = prev.selectedItemIds.includes(prev.noteId);
    const selectedNext = next.selectedItemIds.includes(next.noteId);
    const multiSelectPrev = selectedPrev && prev.isMultiSelecting;
    const multiSelectNext = selectedNext && next.isMultiSelecting;

    return (
        sameNoteId &&
        selectedPrev === selectedNext &&
        multiSelectPrev === multiSelectNext &&
        prev.dropTarget === next.dropTarget &&
        prev.dropPosition === next.dropPosition &&
        prev.isShiftPressed === next.isShiftPressed &&
        prev.isCommandPressed === next.isCommandPressed &&
        prev.handlers === next.handlers &&
        prev.childrenMap === next.childrenMap
    );
});
