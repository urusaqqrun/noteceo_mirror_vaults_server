import { create } from 'zustand';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import i18n from '../../../i18n/config';
import { getDateFromReminderTime } from '../../../utils/reminderTimeUtils';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore } from '../../../Store/uiStore';


import { useItemStore, registerOnDelete } from '../../../Store/itemStore';
import { BaseItem, itemType } from '../../../types/item';

@itemType('TODO_FOLDER', '待辦資料夾')
export class TodoFolder extends BaseItem {
    folderSummary?: string = '';
    isGroup?: boolean = false;
}

@itemType('TODO', '待辦事項，Markdown 內容')
export class Todo extends BaseItem {
    content?: string = '';
    pinnedAt?: string | number | null = null;
    tags?: string[] = [];
    aiTags?: string[] = [];
    audioURLs?: string[] = [];
    audioUrl_local?: string = '';
    imgURLs?: string[] = [];
    imageUrl_local?: string = '';
    completed?: boolean = false;
    reminderTime?: string | null = null;
    offsetMinutes?: number = 0;
    priority?: number | string = 0;
    finishedAt?: string | number | null = null;
    finishedAPIs?: string[] = [];
    isNew?: boolean = false;
    group?: string = '';
    subGroup?: string = '';
    purpose?: string = '';
    periodicTaskConfig?: unknown = undefined;
}

interface TodosState {
    loadTodoFolders: () => Promise<void>;
    addTodoFolder: (newFolder: any, needSync?: boolean) => Promise<void>;
    updateTodoFolder: (updatedFolder: any, needSync?: boolean) => Promise<void>;
    deleteTodoFolder: (folderIds: string | string[], needSync?: boolean) => Promise<void>;
    getFolderType: (folderId: string) => { found: boolean; hasChildren: boolean; isGroup: boolean; isChild: boolean; isNormal: boolean };
    isAncestorOf: (ancestorId: string, descendantId: string) => boolean;
    // ===== Todos =====
    filteredTodos: Todo[];
    filteredTodoIds: string[];

    loadTodos: () => Promise<void>;
    addTodo: (todo?: any, needSync?: boolean) => Promise<void>;
    createNewTodo: (options?: any, needFocusOnTodoInput?: boolean, needSync?: boolean) => Promise<Todo>;
    updateTodo: (updatedTodo: any, needSync?: boolean) => Promise<void>;
    updateTodoWithoutUpdateAt: (updatedTodo: any, needSync?: boolean) => Promise<void>;
    deleteTodo: (todoIds: string | string[], needSync?: boolean, showHint?: boolean) => Promise<void>;
    clearTodoIsNew: (todoId: string) => void;

    getFilteredTodos: (type: string, folderId: string | null) => Todo[];
    getTodoCount: (type: string, folderId: string | null) => number;

}

export const useTodoStore = create<TodosState>((set, get) => ({
    loadTodoFolders: async () => {
        await useItemStore.getState().loadByType('TODO_FOLDER');
    },
    addTodoFolder: async (newFolder, needSync = true) => {
        try {
            const now = Date.now();

            // 計算 orderAt：新資料夾排在同層最後面（比現有最大 orderAt 更大）
            let orderAt = newFolder.orderAt;
            if (orderAt === undefined || orderAt === null) {
                const allFolders = useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[];
                const parentID = newFolder.parentID || null;
                const siblings = allFolders.filter(f =>
                    f.name !== 'todoInbox' &&
                    ((f.parentID || null) === parentID)
                );
                const getOrder = (f: any) => {
                    const o = Number(f.orderAt) || 0;
                    return o !== 0 ? o : (Number(f.createdAt) || 0);
                };
                const maxOrder = siblings.length > 0
                    ? Math.max(...siblings.map(getOrder))
                    : now;
                orderAt = maxOrder + 1000;
            }

            const folderWithMeta: TodoFolder = {
                ...newFolder,
                id: newFolder.id || generateObjectID(),
                itemType: 'TODO_FOLDER',
                createdAt: newFolder.createdAt || now,
                updatedAt: newFolder.updatedAt || now,
                orderAt,
            };
            await useItemStore.getState().upsertItem({ ...folderWithMeta, itemType: 'TODO_FOLDER' }, { needSync });
        } catch (error) {
            console.error('新增待辦資料夾錯誤：', error);
        }
    },
    updateTodoFolder: async (updatedFolder, needSync = true) => {
        if (Array.isArray(updatedFolder)) {
            try {
                for (const f of updatedFolder) {
                    const folderToUpdate = {
                        ...f,
                        itemType: 'TODO_FOLDER',
                    };
                    await useItemStore.getState().upsertItem(folderToUpdate, { needSync });
                }
            } catch (error) {
                console.error('批次更新待辦資料夾錯誤：', error);
            }
            return;
        }
        try {
            const folderToUpdate = {
                ...updatedFolder,
                itemType: 'TODO_FOLDER',
            };
            await useItemStore.getState().upsertItem(folderToUpdate, { needSync });
        } catch (error) {
            console.error('更新待辦資料夾錯誤：', error);
        }
    },
    deleteTodoFolder: async (folderIds, needSync = true) => {
        try {
            const ids = Array.isArray(folderIds) ? folderIds : [folderIds];
            const folders = useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[];
            // 保護 todoInbox
            const specialIds = folders.filter(f => f.name === 'todoInbox').map(f => f.id);
            const filteredIds = ids.filter(id => !specialIds.includes(id));
            if (filteredIds.length === 0) return;

            // 刪除 folder 下的 todos
            const todos = useItemStore.getState().getByType('TODO') as Todo[];
            const todoIdsToDelete = todos.filter(t => filteredIds.includes(t.parentID || '')).map(t => t.id);
            if (todoIdsToDelete.length > 0) await get().deleteTodo(todoIdsToDelete, needSync, false);

            await useItemStore.getState().removeItems(filteredIds, { needSync });

            const selectedId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
            if (selectedId && filteredIds.includes(selectedId)) {
                const todoInbox = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.name === 'todoInbox');
                if (todoInbox) useSelectedItemsStore.getState().setSelectedItems([todoInbox], { scrollToFocusItem: true });
            }
        } catch (error) {
            console.error('刪除待辦資料夾失敗:', error);
        }
    },
    getFolderType: (folderId) => {
        const folders = useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[];
        const folder = folders.find(f => f.id === folderId);
        if (!folder) return { found: false, hasChildren: false, isGroup: false, isChild: false, isNormal: true };
        const hasChildren = folders.some(f => f.parentID === folderId);
        const isChild = !!folder.parentID;
        return { found: true, hasChildren, isGroup: hasChildren, isChild, isNormal: !hasChildren && !isChild };
    },
    isAncestorOf: (ancestorId, descendantId) => {
        const folders = useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[];
        let currentId: string | null | undefined = descendantId;
        while (currentId) {
            const folder = folders.find(f => f.id === currentId);
            if (!folder || !folder.parentID) return false;
            if (folder.parentID === ancestorId) return true;
            currentId = folder.parentID;
        }
        return false;
    },
    // ===== Todos（從 useItemStore 讀取，保留介面相容）=====
    filteredTodos: [],
    filteredTodoIds: [],
    loadTodos: async () => {
        await useItemStore.getState().loadByType('TODO');
    },

    addTodo: async (todo = {}, needSync = true) => {
        if (Array.isArray(todo)) {
            for (const t of todo) {
                await useItemStore.getState().upsertItem({ ...t, itemType: 'TODO' }, { needSync });
            }
            return;
        }
        await useItemStore.getState().upsertItem({ ...todo, itemType: 'TODO' }, { needSync });
    },

    createNewTodo: async (options = {}, needFocusOnTodoInput = false, needSync = true) => {
        const now = Date.now();
        const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
        const currentUser = (window as any).auth?.currentUser;
        const myMemberID = userData?.ID || (currentUser ? currentUser.uid : 'DataProviderDefault');

        const filteredOptions: any = {};
        Object.keys(options).forEach(key => {
            if (options[key] !== null && options[key] !== undefined) filteredOptions[key] = options[key];
        });

        const targetFolderID = options.parentID || (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.name === 'todoInbox')?.id || null;
        const folder = targetFolderID ? useItemStore.getState().getById(targetFolderID) : null;

        // 判斷是否為協作建立：folder 有 _permissions 且我不是 owner
        const folderMyPerm = folder?._permissions?.find((p: any) => p.user_id === myMemberID);
        const isCollaborativeCreate = folder && folderMyPerm && folderMyPerm.permission !== 'owner';

        const newTodo: Todo = {
            ...filteredOptions,
            id: options.id || generateObjectID(),
            itemType: 'TODO',
            parentID: targetFolderID,
            completed: options.completed ?? false,
            name: options.name || '',
            content: options.content || '',
            createdAt: options.createdAt || now,
            updatedAt: options.updatedAt || now,
        };

        // 協作建立時繼承 folder 的 _permissions
        if (isCollaborativeCreate && folder._permissions) {
            (newTodo as any)._permissions = folder._permissions;
        }

        await useItemStore.getState().upsertItem(newTodo, { needSync });
        useSelectedItemsStore.getState().setSelectedItems([newTodo], { scrollToFocusItem: true, highlightItemId: newTodo.id });
        return newTodo;
    },

    updateTodo: async (updatedTodo, needSync = true) => {
        if (Array.isArray(updatedTodo)) {
            try {
                const now = Date.now();
                const updatedIds = new Set(updatedTodo.map(t => t.id));
                const todos = useItemStore.getState().getByType('TODO') as Todo[];
                const updatedTodos = todos.map(t => {
                    if (updatedIds.has(t.id)) {
                        const u = updatedTodo.find(ut => ut.id === t.id);
                        return { ...t, ...u, itemType: 'TODO' as const, updatedAt: now };
                    }
                    return t;
                });
                for (const t of updatedTodos.filter(x => updatedIds.has(x.id))) {
                    await useItemStore.getState().upsertItem(t, { needSync });
                }
            } catch (error) {
                console.error('Failed to update todos:', error);
            }
            return;
        }

        try {
            const now = Date.now();
            const todoWithUpdatedAt: Todo = { ...updatedTodo, updatedAt: now };
            await useItemStore.getState().upsertItem({ ...todoWithUpdatedAt, itemType: 'TODO' }, { needSync });
        } catch (error) {
            console.error('Failed to update todo:', error);
        }
    },

    updateTodoWithoutUpdateAt: async (updatedTodo, needSync = false) => {
        if (Array.isArray(updatedTodo)) {
            for (const t of updatedTodo) {
                await useItemStore.getState().upsertItem({ ...t, itemType: 'TODO' }, { needSync });
            }
            return;
        }

        await useItemStore.getState().upsertItem({ ...updatedTodo, itemType: 'TODO' }, { needSync });
    },

    deleteTodo: async (todoIds, needSync = true, showHint = true) => {
        try {
            const ids = Array.isArray(todoIds) ? todoIds : [todoIds];

            // TODO 永遠直接刪除，沒有垃圾桶；removeItems 會一併刪除子任務
            // navigateOut: true → 刪除後若當前選中項被刪除，自動回退到資料夾
            await useItemStore.getState().removeItems(ids, { needSync, navigateOut: true });

            if (showHint && ids.length > 0) {
                useTempHintStore.getState().setTempHint(i18n.t('todosDeleted', { count: ids.length }));
            }
        } catch (error) {
            console.error('Failed to delete todos:', error);
            useTempHintStore.getState().setTempHint(i18n.t('deleteNotesFailed'));
        }
    },


    // ===== 篩選 =====
    getFilteredTodos: (type, folderId) => {
        const todos = useItemStore.getState().getByType('TODO') as Todo[];
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;
        const todayStart = new Date(year, now.getMonth(), now.getDate()).getTime();

        let filtered: Todo[];
        switch (type) {
            case 'today':
                filtered = todos.filter(t => {
                    if (t.completed) return false;
                    const noteDate = getDateFromReminderTime(t.reminderTime);
                    if (!noteDate) return false;
                    return noteDate <= todayStr;
                });
                break;

            case 'preview': {
                const twoYearsLaterDate = new Date(todayStart + 730 * 24 * 60 * 60 * 1000);
                const twoYearsLater = `${twoYearsLaterDate.getFullYear()}-${String(twoYearsLaterDate.getMonth() + 1).padStart(2, '0')}-${String(twoYearsLaterDate.getDate()).padStart(2, '0')}`;
                filtered = todos.filter(t => {
                    if (t.completed) return false;
                    const noteDate = getDateFromReminderTime(t.reminderTime);
                    if (!noteDate) return false;
                    return noteDate <= twoYearsLater;
                });
                break;
            }

            case 'completed':
                filtered = todos.filter(t => t.completed);
                return filtered.sort((a, b) => {
                    const aFinished = a.finishedAt ? parseFloat(String(a.finishedAt)) : 0;
                    const bFinished = b.finishedAt ? parseFloat(String(b.finishedAt)) : 0;
                    return bFinished - aFinished;
                });

            case 'TODO':
                filtered = todos.filter(t => {
                    if (t.completed) return false;
                    return t.parentID === folderId;
                });
                break;

            case 'SHARED_TODOS': {
                const myMemberID = (() => { try { return JSON.parse(localStorage.getItem('userData_local') || '{}').ID || ''; } catch { return ''; } })();
                filtered = todos.filter(t => {
                    if (t.completed) return false;
                    const todoFolders = useItemStore.getState().getByType('TODO_FOLDER');
                    const folderIdSet = new Set(todoFolders.map(f => f.id));
                    if (t.parentID && folderIdSet.has(t.parentID)) return false;
                    const parent = t.parentID ? useItemStore.getState().getById(t.parentID) : null;
                    if (parent && parent.itemType === 'TODO') return false;
                    // 從 _permissions 判斷：有權限但不是 owner
                    const myPerm = t._permissions?.find((p: any) => p.user_id === myMemberID);
                    return myPerm && myPerm.permission !== 'owner';
                });
                break;
            }

            default:
                return [];
        }

        return filtered.sort((a, b) => {
            const aOrder = a.orderAt ? parseFloat(String(a.orderAt)) : 0;
            const bOrder = b.orderAt ? parseFloat(String(b.orderAt)) : 0;
            if (bOrder !== aOrder) return aOrder - bOrder;
            const aCreate = a.createdAt ? parseFloat(String(a.createdAt)) : 0;
            const bCreate = b.createdAt ? parseFloat(String(b.createdAt)) : 0;
            return aCreate - bCreate;
        });
    },

    getTodoCount: (type, folderId) => {
        const todos = get().getFilteredTodos(type, folderId);
        const todoFolders = useItemStore.getState().getByType('TODO_FOLDER');
        const folderIdSet = new Set(todoFolders.map(f => f.id));
        return todos.filter(t => t.parentID && folderIdSet.has(t.parentID)).length;
    },

    clearTodoIsNew: (todoId) => {
        const todo = useItemStore.getState().getById(todoId) as Todo | undefined;
        if (todo?.isNew) {
            const updated = { ...todo, isNew: false };
            void useItemStore.getState().upsertItem({ ...updated, itemType: 'TODO' }, { needSync: true });
        }
    },

}));

export function registerTodoHandlers() {
  registerOnDelete('TODO', async (ids, options) => {
    const { removeItems, getByType } = useItemStore.getState();
    const allIds = new Set(ids);
    let current = [...ids];
    while (current.length > 0) {
      const next: string[] = [];
      for (const id of current) {
        for (const child of getByType('TODO', true).filter((c: any) => c.parentID === id)) {
          if (!allIds.has(child.id)) {
            allIds.add(child.id);
            next.push(child.id);
          }
        }
      }
      current = next;
    }
    await removeItems(Array.from(allIds), options);
  });

  registerOnDelete('TODO_FOLDER', async (ids, options) => {
    const { removeItems, getByType } = useItemStore.getState();
    const allIds = new Set<string>(ids);
    for (const folderId of ids) {
      for (const todo of getByType('TODO', true).filter((t: any) => t.parentID === folderId)) {
        allIds.add(todo.id);
      }
    }
    await removeItems(Array.from(allIds), options);
  });


}
