import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import './ClassifyHint.css';
import { useClassifyHintStore, useTodoClassifyHintStore, useAISortStore, useTodoSortStore } from './classifyStore';
import PauseIcon from '../../../assets/bk_icon_pause_26_n.svg?react';
import PlayIcon from '../../../assets/bk_icon_play_26_n.svg?react';
import StopIcon from '../../../assets/icon_stop_round_26.svg?react';

const ClassifyHint = () => {
  const { t } = useTranslation();
  const [isVisible, setIsVisible] = useState(false);
  const [dotCount, setDotCount] = useState(2);

  // 筆記分類相關
  const { showClassifyHint, isPaused, setIsPaused, hideClassifyHint } = useClassifyHintStore();
  const { isAISortEnabled, toggleAISort, setAISortEnabled } = useAISortStore();

  // 待辦分類相關
  const { showTodoClassifyHint, isTodoPaused, setIsTodoPaused, hideTodoClassifyHint } = useTodoClassifyHintStore();
  const { isTodoSortEnabled, toggleTodoSort, setTodoSortEnabled } = useTodoSortStore();

  // 判斷當前是筆記還是待辦分類
  const isNoteMode = showClassifyHint;
  const isTodoMode = showTodoClassifyHint;
  const showHint = isNoteMode || isTodoMode;
  const currentPaused = isNoteMode ? isPaused : isTodoPaused;

  // 文字動畫效果：正在分類.. -> .... -> ...... -> ..
  useEffect(() => {
    if (!showHint) {
      setIsVisible(false);
      setDotCount(2);
      return;
    }

    setIsVisible(true);

    const interval = setInterval(() => {
      setDotCount((prev) => {
        if (prev === 2) return 4;
        if (prev === 4) return 6;
        return 2;
      });
    }, 500);

    return () => clearInterval(interval);
  }, [showHint]);

  // 監聽筆記 AI Sort 狀態，當關閉時自動隱藏提示（除非被暫停）
  useEffect(() => {
    if (!isAISortEnabled && !isPaused && showClassifyHint) {
      hideClassifyHint();
    }
  }, [isAISortEnabled, isPaused, showClassifyHint, hideClassifyHint]);

  // 監聽待辦 Todo Sort 狀態，當關閉時自動隱藏提示（除非被暫停）
  useEffect(() => {
    if (!isTodoSortEnabled && !isTodoPaused && showTodoClassifyHint) {
      hideTodoClassifyHint();
    }
  }, [isTodoSortEnabled, isTodoPaused, showTodoClassifyHint, hideTodoClassifyHint]);

  // 處理暫停按鈕
  const handlePause = () => {
    if (isNoteMode) {
      setIsPaused(true);
      if (isAISortEnabled) {
        toggleAISort(); // 關閉筆記 AI Sort
      }
    } else if (isTodoMode) {
      setIsTodoPaused(true);
      if (isTodoSortEnabled) {
        toggleTodoSort(); // 關閉待辦 Todo Sort
      }
    }
  };

  // 處理播放（恢復）按鈕
  const handlePlay = () => {
    if (isNoteMode) {
      setIsPaused(false);
      if (!isAISortEnabled) {
        toggleAISort(); // 開啟筆記 AI Sort
      }
    } else if (isTodoMode) {
      setIsTodoPaused(false);
      if (!isTodoSortEnabled) {
        toggleTodoSort(); // 開啟待辦 Todo Sort
      }
    }
  };

  // 處理停止按鈕
  const handleStop = () => {
    if (isNoteMode) {
      if (isAISortEnabled) {
        toggleAISort(); // 關閉筆記 AI Sort
      }
      hideClassifyHint();
    } else if (isTodoMode) {
      if (isTodoSortEnabled) {
        toggleTodoSort(); // 關閉待辦 Todo Sort
      }
      hideTodoClassifyHint();
    }
  };

  if (!showHint) {
    return null;
  }

  // 根據模式顯示不同文字
  const getHintText = () => {
    if (currentPaused) {
      return t('classifyPaused');
    }
    if (isNoteMode) {
      return `${t('classifyingNotes')}${'.'.repeat(dotCount)}`;
    }
    return `${t('classifyingTodos')}${'.'.repeat(dotCount)}`;
  };

  return createPortal(
    <div className={`classify-hint ${isVisible ? 'classify-hint-visible' : 'classify-hint-hidden'}`}>
      <div className="classify-hint-content">
        <span className="classify-hint-text">
          {getHintText()}
        </span>
        <div className="classify-hint-buttons">
          {currentPaused ? (
            <button
              className="classify-hint-button"
              onClick={handlePlay}
              title={t('resume')}
            >
              <PlayIcon />
            </button>
          ) : (
            <button
              className="classify-hint-button"
              onClick={handlePause}
              title={t('pause')}
            >
              <PauseIcon />
            </button>
          )}
          <button
            className="classify-hint-button"
            onClick={handleStop}
            title={t('stop')}
          >
            <StopIcon />
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};

export default ClassifyHint;

