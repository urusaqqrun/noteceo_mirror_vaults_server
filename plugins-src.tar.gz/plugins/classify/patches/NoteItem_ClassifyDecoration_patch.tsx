/**
 * @patch NoteItem_ClassifyDecoration
 * @target [data-id] .note-title-container (beforeend)
 * @method createPortal + MutationObserver + zustand subscribe
 * @description 為 NoteItem 注入分類相關的 UI 裝飾：
 *   1. 分類狀態圖標（loading / pause）
 *   2. 「前往XX」右滑動畫標示
 *   3. 確認/拒絕分類建議按鈕
 *   4. slide-out-right CSS 動畫
 *   5. has-ai-folder-suggest CSS class
 */

import React, { useEffect, useState, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useAIGOStore } from '../classifyStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useNoteStore } from '../../note/noteStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import CloseIcon from '../../../../assets/icon_close.svg?react';
import CorrectIcon from '../../../../assets/icon_correct.svg?react';
import PauseIcon from '../../../../assets/bk_icon_pause_26_n.svg?react';

// 單一筆記的 classify 裝飾
function NoteClassifyDecoration({ noteId, container }: { noteId: string; container: HTMLElement }) {
    const { t } = useTranslation();

    const isAiClassifying = useAIGOStore(useCallback(state =>
        state.aiClassifyNoteIds.includes(noteId), [noteId]));
    const isSlideRight = useAIGOStore(useCallback(state =>
        state.slideRightNoteIds.includes(noteId), [noteId]));

    const note = useItemStore(useCallback(state =>
        (state.byType['NOTE'] ?? []).find((n: any) => n.id === noteId), [noteId])) as import('../../note/noteStore').Note | undefined;
    const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('../note/noteStore').NoteFolder[];

    const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
    const currentFolder = noteFolders.find(f => f.id === selectedFolderId);
    const currentFolderName = currentFolder?.name || '';

    const targetFolder = note?.aiFolderID ? noteFolders.find(f => f.id === note.aiFolderID) : null;
    const targetFolderName = targetFolder?.name || '';

    // slide-out-right 動畫
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const innerElement = noteEl.querySelector(':scope > div');

        if (!note || currentFolderName !== 'inbox' || !isSlideRight || !targetFolderName || note.aiFolderID === selectedFolderId) {
            innerElement?.classList.remove('slide-out-right');
            return;
        }

        const timer = setTimeout(() => {
            innerElement?.classList.add('slide-out-right');
        }, 400);

        return () => {
            clearTimeout(timer);
            innerElement?.classList.remove('slide-out-right');
        };
    }, [currentFolderName, isSlideRight, targetFolderName, note?.aiFolderID, selectedFolderId, noteId]);

    // has-ai-folder-suggest CSS class
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const innerDiv = noteEl.querySelector(':scope > div');
        if (!innerDiv) return;

        if (note?.aiFolderID && note.aiFolderID === selectedFolderId) {
            innerDiv.classList.add('has-ai-folder-suggest');
        } else {
            innerDiv.classList.remove('has-ai-folder-suggest');
        }

        return () => {
            innerDiv.classList.remove('has-ai-folder-suggest');
        };
    }, [note?.aiFolderID, selectedFolderId]);

    // 有 aiFolderID 時隱藏提醒和縮圖
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const reminder = noteEl.querySelector('.note-reminder');
        const thumbnail = noteEl.querySelector('.note-item-right-container');
        if (note?.aiFolderID) {
            reminder?.classList.add('classify-hidden');
            thumbnail?.classList.add('classify-hidden');
        } else {
            reminder?.classList.remove('classify-hidden');
            thumbnail?.classList.remove('classify-hidden');
        }
        return () => {
            reminder?.classList.remove('classify-hidden');
            thumbnail?.classList.remove('classify-hidden');
        };
    }, [note?.aiFolderID]);

    // 分類資料夾路徑注入到 .note-info
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const noteInfo = noteEl.querySelector('.note-info');
        if (!noteInfo) return;
        const timestamp = noteInfo.querySelector('.note-timestamp');

        const getDisplayName = (folderName: string | undefined) => {
            if (folderName === 'inbox') return t('inbox');
            if (folderName === 'todoInbox') return t('todoInbox');
            if (folderName === 'trash') return t('trash');
            return folderName;
        };

        if (note?.aiFolderID && currentFolderName !== 'inbox') {
            if (timestamp) (timestamp as HTMLElement).style.display = 'none';
            let pathEl = noteInfo.querySelector('.classify-folder-path') as HTMLElement;
            if (!pathEl) {
                pathEl = document.createElement('div');
                pathEl.className = 'classify-folder-path note-folder-path';
                noteInfo.prepend(pathEl);
            }
            const fromFolder = noteFolders.find(f => f.id === note.parentID);
            const toFolder = noteFolders.find(f => f.id === note.aiFolderID);
            pathEl.innerHTML = `<span class="folder-name-from">${getDisplayName(fromFolder?.name) || ''}</span> → <span class="folder-name-to">${getDisplayName(toFolder?.name) || ''}</span>`;
        } else {
            if (timestamp) (timestamp as HTMLElement).style.display = '';
            const pathEl = noteInfo.querySelector('.classify-folder-path');
            if (pathEl) pathEl.remove();
        }

        return () => {
            if (timestamp) (timestamp as HTMLElement).style.display = '';
            const pathEl = noteInfo?.querySelector('.classify-folder-path');
            if (pathEl) pathEl.remove();
        };
    }, [note?.aiFolderID, note?.parentID, currentFolderName, noteFolders, t]);

    // 計算 statusIcon
    let statusIcon: string | null = null;
    if (note) {
        if (note.aiFolderID) {
            statusIcon = null;
        } else if (isAiClassifying) {
            statusIcon = 'loading';
        } else if (note.classificationStatus === 'UNCLASSIFIABLE' || note.classificationStatus === 'PAUSE') {
            statusIcon = 'pause';
        }
    }

    // 只在 inbox 和有分類相關狀態時才渲染
    const showStatusIcon = currentFolderName === 'inbox' && statusIcon;
    const showSlideRight = currentFolderName === 'inbox' && note?.aiFolderID && targetFolderName && isSlideRight;
    const showSuggestion = note?.aiFolderID === selectedFolderId && note?.aiFolderID;

    if (!showStatusIcon && !showSlideRight && !showSuggestion) return null;

    return createPortal(
        <>
            {/* 分類狀態圖標 */}
            {showStatusIcon && (
                <div className={`classification-status show ${currentFolderName === 'inbox' ? 'in-unclassified' : ''}`}>
                    <div
                        className="status-touch-block"
                        onClick={async (e) => {
                            e.stopPropagation();
                            if (!note) return;
                            const setForceRefreshClassify = useAIGOStore.getState().setForceRefreshClassify;
                            if (note.classificationStatus === 'PAUSE' || note.classificationStatus === 'UNCLASSIFIABLE') {
                                await useNoteStore.getState().updateNoteWithoutUpdateAt({ ...note, classificationStatus: 'TODO' });
                            }
                            setForceRefreshClassify((prev: any) => !prev);
                        }}
                    >
                        <div className="status-icon">
                            {statusIcon === 'loading' && <div className="notelist-loading-spinner" />}
                            {statusIcon === 'pause' && <PauseIcon />}
                        </div>
                    </div>
                </div>
            )}

            {/* 前往 XX 動畫 */}
            {showSlideRight && (
                <div className="classification-status moving-animation fade-out-after">
                    <div className="status-text">{t('goTo', { folderName: targetFolderName })}</div>
                </div>
            )}

            {/* 確認/拒絕分類建議 */}
            {showSuggestion && (
                <div className={`classification-status-container${isSlideRight ? ' delayed-fade-in' : ''}`}>
                    <div className="classification-status reduced-height show" />
                    <div className="status-actions">
                        <div
                            className="status-actions-top-touch-block"
                            onClick={async (e) => {
                                e.stopPropagation();
                                await (useNoteStore.getState() as any).rejectSuggestions(note, selectedFolderId);
                            }}
                        >
                            <div className="status-icon action-icon error-icon">
                                <CloseIcon />
                            </div>
                        </div>
                        <div
                            className="status-actions-bottom-touch-block"
                            onClick={async (e) => {
                                e.stopPropagation();
                                await (useNoteStore.getState() as any).acceptSuggestions(note, selectedFolderId);
                            }}
                        >
                            <div className="status-icon action-icon primary-icon">
                                <CorrectIcon />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>,
        container
    );
}

// 主 patch 元件：觀察 DOM 變化，為每個 NoteItem 注入裝飾
function NoteItem_ClassifyDecoration_patch() {
    const [noteAnchors, setNoteAnchors] = useState<Map<string, HTMLElement>>(new Map());

    useEffect(() => {
        const containerSelector = '.note-list-container, .ai-index-indexes-list';

        const scanAndInject = () => {
            const newAnchors = new Map<string, HTMLElement>();
            const noteItems = document.querySelectorAll('[data-id]');

            noteItems.forEach(item => {
                const noteId = item.getAttribute('data-id');
                if (!noteId) return;

                // 注入到 .note-item（有 position: relative 的元素）而非 .note-title-container
                // 因為 .note-title-container 有 overflow: hidden，會裁切絕對定位的按鈕
                const noteItem = item.querySelector('.note-item');
                if (!noteItem) return;

                // 檢查是否已有錨點
                let anchor = noteItem.querySelector('[data-classify-anchor]') as HTMLElement;
                if (!anchor) {
                    anchor = document.createElement('div');
                    anchor.setAttribute('data-classify-anchor', 'true');
                    anchor.style.display = 'contents';
                    noteItem.appendChild(anchor);
                }

                newAnchors.set(noteId, anchor);
            });

            setNoteAnchors(prev => {
                // 只在有變化時更新
                if (prev.size !== newAnchors.size) return newAnchors;
                for (const [key, val] of newAnchors) {
                    if (prev.get(key) !== val) return newAnchors;
                }
                return prev;
            });
        };

        // 初始掃描
        scanAndInject();

        // MutationObserver 監聽 DOM 變化
        const observer = new MutationObserver(() => {
            scanAndInject();
        });

        // 觀察所有可能包含 NoteItem 的容器
        const containers = document.querySelectorAll(containerSelector);
        containers.forEach(container => {
            observer.observe(container, { childList: true, subtree: true });
        });

        // 也觀察 body，以捕獲容器本身的建立
        observer.observe(document.body, { childList: true, subtree: true });

        return () => {
            observer.disconnect();
            document.querySelectorAll('[data-classify-anchor]').forEach(el => el.remove());
        };
    }, []);

    return (
        <>
            {Array.from(noteAnchors.entries()).map(([noteId, anchor]) => (
                <NoteClassifyDecoration key={noteId} noteId={noteId} container={anchor} />
            ))}
        </>
    );
}

export default NoteItem_ClassifyDecoration_patch;
