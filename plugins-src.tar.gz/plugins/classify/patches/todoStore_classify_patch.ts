/**
 * todoStore 分類猴子補丁
 *
 * 注入 aiFolderID 相關邏輯到 todoStore：
 * - getFilteredTodos：todoInbox 排除 + 目標資料夾合併 + slideRight 增強
 * - acceptSuggestions / rejectSuggestions：分類建議操作
 *
 * 返回 cleanup 函數以還原所有修改。
 */

import { useTodoStore, type Todo, type TodoFolder } from '../../todo/todoStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useTodoClassifyActivityStore } from '../classifyStore';
import { timerManager } from '../../../../Store/uiStore';

export function patchTodoStoreClassify(): () => void {
    const origMethod = useTodoStore.getState().getFilteredTodos;

    // 注入分類方法到 todoStore
    useTodoStore.setState({
        _classifyCleanupSlideRight: (todoIdsToRemove: string[]) => {
            const currentSlideRightTodoIds = useTodoClassifyActivityStore.getState().slideRightTodoIds;
            const filtered = currentSlideRightTodoIds.filter(
                (id: string) => !todoIdsToRemove.includes(id)
            );
            if (filtered.length !== currentSlideRightTodoIds.length) {
                useTodoClassifyActivityStore.getState().setSlideRightTodoIds(filtered);
            }
        },
        acceptSuggestions: (todos: any, currentViewFolderId: string | null) => {
            const todosToUpdate = Array.isArray(todos) ? todos : [todos];
            if (todosToUpdate.length === 0) return Promise.resolve();

            const todosNeedAnimation = todosToUpdate.filter((t: any) => t.aiFolderID !== currentViewFolderId);
            todosNeedAnimation.forEach((t: any) => {
                const el = document.querySelector(`[data-id="${t.id}"]`);
                if (el) el.classList.add('todo-item', 'slide-out-right');
            });

            const delay = todosNeedAnimation.length > 0 ? 400 : 0;
            const timerKey = `acceptSuggestions_${Date.now()}`;
            return new Promise<void>((resolve) => {
                timerManager.set(timerKey, async () => {
                    const updated = todosToUpdate.map((t: any) => ({ ...t, parentID: t.aiFolderID, aiFolderID: null }));
                    await useTodoStore.getState().updateTodo(updated);
                    await (useTodoStore.getState() as any).handleTempFolders?.();
                    resolve();
                }, delay);
            });
        },
        rejectSuggestions: (todos: any, currentViewFolderId: string | null) => {
            const todosToUpdate = Array.isArray(todos) ? todos : [todos];
            if (todosToUpdate.length === 0) return Promise.resolve();

            const allFolders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
            const todoInboxId = allFolders.find((f: any) => f.name === 'todoInbox')?.id;

            const todosNeedAnimation = todosToUpdate.filter((t: any) => t.aiFolderID === currentViewFolderId);
            todosNeedAnimation.forEach((t: any) => {
                const el = document.querySelector(`[data-id="${t.id}"]`);
                if (el) el.classList.add('todo-item', 'slide-out-left');
            });

            const delay = todosNeedAnimation.length > 0 ? 400 : 0;
            const timerKey = `rejectSuggestions_${Date.now()}`;
            return new Promise<void>((resolve) => {
                timerManager.set(timerKey, async () => {
                    const updated = todosToUpdate.map((t: any) => {
                        let classificationStatus = t.classificationStatus;
                        if (t.parentID === todoInboxId) classificationStatus = 'UNCLASSIFIABLE';

                        const targetFolderName = allFolders.find((f: any) => f.id === t.aiFolderID)?.name;
                        const currentRejectedFolders = Array.isArray(t.rejectedFolderNames) ? [...t.rejectedFolderNames] : [];
                        if (targetFolderName && !currentRejectedFolders.includes(targetFolderName)) {
                            currentRejectedFolders.push(targetFolderName);
                        }

                        return { ...t, classificationStatus, aiFolderID: null, rejectedFolderNames: currentRejectedFolders };
                    });

                    const todoIdsToRemove = todosToUpdate.map((t: any) => t.id);
                    if ((useTodoStore.getState() as any)._classifyCleanupSlideRight) {
                        (useTodoStore.getState() as any)._classifyCleanupSlideRight(todoIdsToRemove);
                    }

                    await useTodoStore.getState().updateTodoWithoutUpdateAt(updated);
                    await (useTodoStore.getState() as any).handleTempFolders?.();
                    resolve();
                }, delay);
            });
        },
    } as any);

    // 猴子補丁 handleTempFolders — 保留被 aiFolderID 引用的臨時資料夾
    useTodoStore.setState({
        handleTempFolders: async () => {
            try {
                const todos = (useItemStore.getState().getByType('TODO') as Todo[]);
                const folders = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]);
                const tempFolders = folders.filter((folder: any) => folder.isTemp);
                const foldersNeedUpdate: any[] = [];
                const foldersNeedDelete: string[] = [];
                tempFolders.forEach((folder: any) => {
                    const hasTodos = todos.some((t: any) => t.parentID === folder.id);
                    const isTargeted = todos.some((t: any) => t.aiFolderID === folder.id);
                    if (hasTodos) {
                        foldersNeedUpdate.push({ ...folder, isTemp: false });
                    } else if (!isTargeted) {
                        foldersNeedDelete.push(folder.id);
                    }
                });
                if (foldersNeedUpdate.length > 0) {
                    for (const f of foldersNeedUpdate) {
                        await useItemStore.getState().upsertItem({ ...f, itemType: 'TODO_FOLDER' }, { needSync: true });
                    }
                }
                if (foldersNeedDelete.length > 0) {
                    await useTodoStore.getState().deleteTodoFolder(foldersNeedDelete);
                }
            } catch (error) {
                console.error('處理臨時待辦資料夾失敗:', error);
            }
        },
    } as any);

    // 穩定的 getFilteredTodos 實作（不變的邏輯）
    const patchedImpl = (type: string, folderId?: string) => {
        const baseResult = origMethod(type, folderId);

        if (type === 'TODO' && folderId) {
            const todos = (useItemStore.getState().getByType('TODO') as Todo[]);
            const todoInboxFolder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find((f: any) => f.name === 'todoInbox');

            // todoInbox 過濾：隱藏有 aiFolderID 的待辦，但 slideRight 動畫中的暫時保留
            if (todoInboxFolder && folderId === todoInboxFolder.id) {
                const slideRightTodoIds = useTodoClassifyActivityStore.getState().slideRightTodoIds;
                const filtered = baseResult.filter((t: any) =>
                    !t.aiFolderID || slideRightTodoIds.includes(t.id)
                );
                return filtered;
            }

            // 把 aiFolderID === folderId 的待辦合併進來（不重複）
            const baseIds = new Set(baseResult.map((t: any) => t.id));
            const aiClassifiedTodos = todos.filter((t: any) =>
                t.aiFolderID === folderId && !baseIds.has(t.id) && !t.completed
            );
            const merged = aiClassifiedTodos.length > 0
                ? [...baseResult, ...aiClassifiedTodos]
                : baseResult;

            // aiFolderID 排序增強
            const slideRightTodoIds = useTodoClassifyActivityStore.getState().slideRightTodoIds;
            const sorted = [...merged].sort((a: any, b: any) => {
                const aHas = a.aiFolderID && !slideRightTodoIds.includes(a.id);
                const bHas = b.aiFolderID && !slideRightTodoIds.includes(b.id);
                if (aHas && !bHas) return -1;
                if (!aHas && bHas) return 1;
                return 0;
            });
            return sorted;
        }

        return baseResult;
    };

    useTodoStore.setState({ getFilteredTodos: patchedImpl } as any);

    // slideRightTodoIds 變化時替換 getFilteredTodos 函數引用，
    // 讓 TodoList 的 useMemo（依賴 getFilteredTodos）重新計算
    const unsubSlideRight = useTodoClassifyActivityStore.subscribe(
        (state, prev) => {
            if (state.slideRightTodoIds !== prev.slideRightTodoIds) {
                useTodoStore.setState({
                    getFilteredTodos: (...args: [string, string?]) => patchedImpl(...args),
                } as any);
            }
        }
    );

    // 返回 cleanup 函數
    return () => {
        unsubSlideRight();
        useTodoStore.setState({
            getFilteredTodos: origMethod,
            _classifyCleanupSlideRight: undefined,
            handleTempFolders: undefined,
            acceptSuggestions: undefined,
            rejectSuggestions: undefined,
        } as any);
    };
}
