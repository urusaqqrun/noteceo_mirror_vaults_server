/**
 * @patch NoteListToolBar + TodoList topbar 分類按鈕
 * @target .note-list-wrapper .custom-toolbar-right | .todo-list-wrapper .todolist-topbar-right
 * @method createPortal + MutationObserver（猴子補丁，僅改 classify 插件）
 */

import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../../../setting/ThemeProvider';
import LottieAnimation from '../../../Utils/LottieAnimation';
import AI_loading_sort_light from '../../../../assets/AI_loading_sort_Light.json';
import AI_loading_sort_dark from '../../../../assets/AI_loading_sort_Dark.json';
import AI_sort_disable from '../../../../assets/icon_toggle_AI_sort_normal_24.svg?react';
import CloseIcon from '../../../../assets/icon_close.svg?react';
import CorrectIcon from '../../../../assets/icon_correct.svg?react';
import PauseIcon from '../../../../assets/bk_icon_pause_26_n.svg?react';

import { useAISortStore, useClassifyHintStore, useTodoClassifyHintStore, useTodoSortStore, useAIGOStore, useTodoClassifyActivityStore } from '../classifyStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useNoteStore } from '../../note/noteStore';
import { useTodoStore } from '../../todo/todoStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useTempHintStore } from '../../../../Store/uiStore';
import type { Note, NoteFolder } from '../../note/noteStore';
import type { Todo, TodoFolder } from '../../todo/todoStore';

const ANCHOR_ATTR = 'data-classify-toolbar-anchor';

// ─── NoteList 工具列補丁 ───

function findNoteListToolbarRight(): HTMLElement | null {
  const wrapper = document.querySelector('.note-list-wrapper');
  if (!wrapper) return null;
  const allRight = wrapper.querySelectorAll('.custom-toolbar-right');
  return allRight.length > 1 ? (allRight[allRight.length - 1] as HTMLElement) : (allRight[0] as HTMLElement) ?? null;
}

function NoteListToolBar_ClassifyButtons_patch() {
  const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);

  useEffect(() => {
    const findOrCreateAnchor = () => {
      const right = findNoteListToolbarRight();
      if (!right) {
        setPortalTarget(null);
        return;
      }
      let anchor = right.querySelector(`[${ANCHOR_ATTR}]`) as HTMLElement | null;
      if (!anchor) {
        anchor = document.createElement('div');
        anchor.setAttribute(ANCHOR_ATTR, 'true');
        anchor.style.display = 'flex';
        anchor.style.alignItems = 'center';
        anchor.style.gap = '12px';
        right.prepend(anchor);
      }
      setPortalTarget(anchor);
    };

    findOrCreateAnchor();
    const observer = new MutationObserver(findOrCreateAnchor);
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      document.querySelector(`[${ANCHOR_ATTR}]`)?.remove();
    };
  }, []);

  if (!portalTarget) return null;

  return createPortal(
    <>
      <PausedNotesTag />
      <NoteListClassifyButtons />
    </>,
    portalTarget
  );
}

function PausedNotesTag() {
  const { t } = useTranslation();
  const setTempHint = useTempHintStore((s) => s.setTempHint);
  const selectedFolderId = useSelectedItemsStore((s) => s.selectedFolderId);
  const noteFolders = useItemStore((s) => s.byType['NOTE_FOLDER'] ?? []) as NoteFolder[];
  const notes = useItemStore((s) => s.byType['NOTE'] ?? []) as Note[];
  const inboxFolder = noteFolders.find((f: any) => f.name === 'inbox');
  const updateNoteWithoutUpdateAt = useNoteStore((s) => s.updateNoteWithoutUpdateAt);
  const setForceRefreshClassify = useAIGOStore((s) => s.setForceRefreshClassify);

  const pausedNotesCount = notes.filter(
    (n: any) =>
      n.parentID === inboxFolder?.id &&
      (n.classificationStatus === 'PAUSE' || n.classificationStatus === 'UNCLASSIFIABLE')
  ).length;

  const handleClick = async () => {
    const pausedNotes = notes.filter(
      (n: any) =>
        n.parentID === inboxFolder?.id &&
        (n.classificationStatus === 'PAUSE' || n.classificationStatus === 'UNCLASSIFIABLE')
    );
    for (const note of pausedNotes) {
      await updateNoteWithoutUpdateAt({ ...note, classificationStatus: 'TODO' });
    }
    setForceRefreshClassify((prev: boolean) => !prev);
    setTempHint(`已恢復 ${pausedNotes.length} 則筆記的分類狀態`);
  };

  if (selectedFolderId !== inboxFolder?.id || pausedNotesCount === 0) return null;

  return (
    <span
      className="paused-notes-tag"
      onClick={handleClick}
      onMouseEnter={() => setTempHint(t('clickToResume'))}
      onMouseLeave={() => setTempHint(null)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
    >
      {t('pausedCount', { count: pausedNotesCount })}
      <PauseIcon />
    </span>
  );
}

function NoteListClassifyButtons() {
  const { t } = useTranslation();
  const { mode } = useTheme();
  const selectedFolderId = useSelectedItemsStore((s) => s.selectedFolderId);
  const noteFolders = useItemStore((s) => s.byType['NOTE_FOLDER'] ?? []) as NoteFolder[];
  const notes = useItemStore((s) => s.byType['NOTE'] ?? []) as Note[];
  const { isAISortEnabled, toggleAISort } = useAISortStore();
  const { setShowClassifyHint, hideClassifyHint } = useClassifyHintStore();
  const { hideTodoClassifyHint } = useTodoClassifyHintStore();
  const { isTodoSortEnabled, setTodoSortEnabled } = useTodoSortStore();
  const { isClassifingNote } = useAIGOStore();

  const trashFolder = noteFolders.find((f: any) => f.name === 'trash');
  if (selectedFolderId === '__shared_notes__' || (trashFolder && selectedFolderId === trashFolder.id)) return null;

  const inboxFolder = noteFolders.find((f: any) => f.name === 'inbox');
  const filteredNotes = notes.filter((n: any) => n.parentID === inboxFolder?.id);
  const remainingUnclassified = filteredNotes.filter(
    (n: any) =>
      !n.aiFolderID &&
      n.classificationStatus !== 'UNCLASSIFIABLE' &&
      n.classificationStatus !== 'PAUSE'
  ).length;
  const hasNotesToClassify = remainingUnclassified > 0;
  const currentFolder = noteFolders.find((f: any) => f.id === selectedFolderId);
  const currentFolderName = currentFolder?.name ?? 'inbox';

  const unconfirmedNotesForFolder = notes.filter((n: any) => n.aiFolderID === selectedFolderId && !n.isDeleted).length;

  const buttons: React.ReactNode[] = [];

  // 全部確認/全部拒絕（筆記資料夾，非 inbox/trash/isTemp）
  if (
    unconfirmedNotesForFolder > 0 &&
    currentFolderName !== 'inbox' &&
    currentFolderName !== 'trash' &&
    !currentFolder?.isTemp &&
    selectedFolderId
  ) {
    const getActiveFolderId = (): string | null => {
      const lastItem = useSelectedItemsStore.getState().path.at(-1);
      if (!lastItem) return null;
      if ((lastItem as any).itemType?.endsWith('_FOLDER')) return lastItem.id;
      return lastItem.id ?? null;
    };
    buttons.push(
      <div key="unconfirmed" className="unconfirmed-notes-container notelist-mode">
        <div className="unconfirmed-notes-text">
          {unconfirmedNotesForFolder} {unconfirmedNotesForFolder === 1 ? t('suggestion') : t('suggestions')}
        </div>
        <div className="unconfirmed-notes-actions">
          <button
            className="unconfirmed-notes-button reject"
            tabIndex={-1}
            onClick={async () => {
              const toUpdate = notes.filter((n: any) => n.aiFolderID === selectedFolderId && !n.isDeleted);
              if (toUpdate.length === 0) return;
              await (useNoteStore.getState() as any).rejectSuggestions(toUpdate, getActiveFolderId());
              setTimeout(() => {
                const state = useSelectedItemsStore.getState();
                if (state.path.length === 0 && state.extraItems.length === 0 && inboxFolder) {
                  state.setSelectedItems([inboxFolder], { scrollToFocusItem: true });
                }
              }, 500);
            }}
          >
            <CloseIcon />
          </button>
          <button
            className="unconfirmed-notes-button accept"
            tabIndex={-1}
            onClick={async () => {
              const toUpdate = notes.filter((n: any) => n.aiFolderID === selectedFolderId && !n.isDeleted);
              if (toUpdate.length === 0) return;
              await (useNoteStore.getState() as any).acceptSuggestions(toUpdate, getActiveFolderId());
            }}
          >
            <CorrectIcon />
          </button>
        </div>
      </div>
    );
  }

  // 快速分類按鈕（inbox）
  if (currentFolderName === 'inbox') {
    const hintMessage = hasNotesToClassify ? t('quickClassify') : t('noNotesToClassify');
    buttons.push(
      <button
        key="quick-classify"
        className={`custom-toolbar-button ${isAISortEnabled ? 'active' : ''}`}
        tabIndex={-1}
        disabled={!hasNotesToClassify}
        style={!hasNotesToClassify ? { opacity: 0.4, cursor: 'not-allowed' } : undefined}
        title={hintMessage}
        onClick={(e) => {
          if (hasNotesToClassify) {
            if (!isAISortEnabled) {
              if (isTodoSortEnabled) setTodoSortEnabled(false);
              hideTodoClassifyHint();
              setShowClassifyHint(true);
            } else {
              hideClassifyHint();
            }
            toggleAISort();
          }
          (e.target as HTMLElement).blur();
        }}
      >
        {isAISortEnabled ? (
          <LottieAnimation
            animationData={mode === 'dark' ? AI_loading_sort_dark : AI_loading_sort_light}
            width={24}
            height={24}
            loop={true}
            autoplay={isClassifingNote}
          />
        ) : (
          <AI_sort_disable />
        )}
      </button>
    );
  }

  return <>{buttons}</>;
}

// ─── TodoList topbar 補丁 ───

function findTodoListTopbarRight(): HTMLElement | null {
  const wrapper = document.querySelector('.todo-list-wrapper');
  if (!wrapper) return null;
  const right = wrapper.querySelector('.todolist-topbar-right') as HTMLElement;
  return right ?? null;
}

function TodoListTopbar_ClassifyButtons_patch() {
  const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);

  useEffect(() => {
    const findOrCreateAnchor = () => {
      const right = findTodoListTopbarRight();
      if (!right) {
        setPortalTarget(null);
        return;
      }
      let anchor = right.querySelector(`[${ANCHOR_ATTR}-todo]`) as HTMLElement | null;
      if (!anchor) {
        anchor = document.createElement('div');
        anchor.setAttribute(`${ANCHOR_ATTR}-todo`, 'true');
        anchor.style.display = 'flex';
        anchor.style.alignItems = 'center';
        anchor.style.gap = '8px';
        right.appendChild(anchor);
      }
      setPortalTarget(anchor);
    };

    findOrCreateAnchor();
    const observer = new MutationObserver(findOrCreateAnchor);
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      document.querySelector(`[${ANCHOR_ATTR}-todo]`)?.remove();
    };
  }, []);

  if (!portalTarget) return null;

  return createPortal(
    <>
      <PausedTodosTag />
      <TodoListClassifyButtons />
    </>,
    portalTarget
  );
}

function PausedTodosTag() {
  const { t } = useTranslation();
  const setTempHint = useTempHintStore((s) => s.setTempHint);
  const selectedFolderId = useSelectedItemsStore((s) => s.selectedFolderId);
  const todoFolders = useItemStore((s) => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const todos = useItemStore((s) => s.byType['TODO'] ?? []) as Todo[];
  const todoInboxFolder = todoFolders.find((f: any) => f.name === 'todoInbox');
  const updateTodoWithoutUpdateAt = useTodoStore((s) => s.updateTodoWithoutUpdateAt);
  const setForceRefreshTodoClassify = useTodoClassifyActivityStore((s) => s.setForceRefreshTodoClassify);

  const pausedTodosCount = todos.filter(
    (t: any) =>
      t.parentID === todoInboxFolder?.id &&
      (t.classificationStatus === 'PAUSE' || t.classificationStatus === 'UNCLASSIFIABLE')
  ).length;

  const handleClick = async () => {
    const pausedTodos = todos.filter(
      (t: any) =>
        t.parentID === todoInboxFolder?.id &&
        (t.classificationStatus === 'PAUSE' || t.classificationStatus === 'UNCLASSIFIABLE')
    );
    for (const todo of pausedTodos) {
      await updateTodoWithoutUpdateAt({ ...todo, classificationStatus: 'TODO' });
    }
    setForceRefreshTodoClassify((prev: boolean) => !prev);
    setTempHint(`已恢復 ${pausedTodos.length} 則待辦的分類狀態`);
  };

  if (selectedFolderId !== todoInboxFolder?.id || pausedTodosCount === 0) return null;

  return (
    <span
      className="paused-notes-tag"
      onClick={handleClick}
      onMouseEnter={() => setTempHint(t('clickToResume'))}
      onMouseLeave={() => setTempHint(null)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
    >
      {t('pausedCount', { count: pausedTodosCount })}
      <PauseIcon />
    </span>
  );
}

function TodoListClassifyButtons() {
  const { t } = useTranslation();
  const { mode } = useTheme();
  const { path: navPath, selectedFolderId } = useSelectedItemsStore((s) => ({
    path: s.path,
    selectedFolderId: s.selectedFolderId,
  }));
  const todoFoldersForType = useItemStore((s) => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const selectedFolderType = React.useMemo(() => {
    const virtualItem = navPath.find((item: any) => item.itemType === 'TODO_VIRTUAL_FOLDER');
    if (virtualItem?.id === 'today') return 'today';
    if (virtualItem?.id === 'preview') return 'preview';
    if (virtualItem?.id === 'completed') return 'completed';
    if (selectedFolderId && todoFoldersForType.some((f: any) => f.id === selectedFolderId)) return 'TODO';
    return null;
  }, [navPath, selectedFolderId, todoFoldersForType]);

  const todos = useItemStore((s) => s.byType['TODO'] ?? []) as Todo[];
  const todoFolders = useItemStore((s) => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const todoInboxFolder = todoFolders.find((f: any) => f.name === 'todoInbox');
  const isTodoInbox = selectedFolderId === todoInboxFolder?.id;

  const todoFolderIds = new Set(todoFolders.map(f => f.id));
  const unconfirmedTodos = todos.filter((t: any) => t.parentID && todoFolderIds.has(t.parentID) && t.aiFolderID && t.aiFolderID !== '' && t.aiFolderID === selectedFolderId && !t.completed && !t.isDeleted).length;
  const inboxTodos = todos.filter((t: any) => t.parentID === todoInboxFolder?.id);
  const remainingUnclassified = inboxTodos.filter(
    (t: any) =>
      !t.aiFolderID &&
      t.classificationStatus !== 'UNCLASSIFIABLE' &&
      t.classificationStatus !== 'PAUSE'
  ).length;
  const hasTodos = inboxTodos.length > 0;

  const { isTodoSortEnabled, toggleTodoSort } = useTodoSortStore();
  const { setShowTodoClassifyHint, hideTodoClassifyHint } = useTodoClassifyHintStore();
  const { isAISortEnabled, setAISortEnabled } = useAISortStore();
  const isClassifingTodo = useTodoClassifyActivityStore((s) => s.isClassifingTodo);

  const getActiveFolderId = (): string | null => {
    const item = useSelectedItemsStore.getState().path.at(-1);
    if (!item) return null;
    if ((item as any).itemType?.endsWith('_FOLDER') || (item as any).itemType === 'TODO_VIRTUAL_FOLDER') return item.id;
    return item.id ?? null;
  };

  const currentTodoFolder = todoFolders.find((f: any) => f.id === selectedFolderId);

  const content: React.ReactNode[] = [];

  // 全部確認/全部拒絕（自訂待辦資料夾，排除 isTemp）
  if (unconfirmedTodos > 0 && !isTodoInbox && selectedFolderType === 'TODO' && !currentTodoFolder?.isTemp) {
    content.push(
      <div key="unconfirmed" className="unconfirmed-notes-container todolist-mode">
        <div className="unconfirmed-notes-text">
          {unconfirmedTodos} {unconfirmedTodos === 1 ? t('suggestion') : t('suggestions')}
        </div>
        <div className="unconfirmed-notes-actions">
          <button
            className="unconfirmed-notes-button reject"
            tabIndex={-1}
            onClick={async () => {
              const toUpdate = todos.filter((t: any) => t.aiFolderID && t.aiFolderID === selectedFolderId && !t.completed && !t.isDeleted);
              if (toUpdate.length === 0) return;
              await (useTodoStore.getState() as any).rejectSuggestions(toUpdate, getActiveFolderId());
              setTimeout(() => {
                const state = useSelectedItemsStore.getState();
                if (state.path.length === 0 && state.extraItems.length === 0 && todoInboxFolder) {
                  state.setSelectedItems([todoInboxFolder], { scrollToFocusItem: true });
                }
              }, 500);
            }}
          >
            <CloseIcon />
          </button>
          <button
            className="unconfirmed-notes-button accept"
            tabIndex={-1}
            onClick={async () => {
              const toUpdate = todos.filter((t: any) => t.aiFolderID && t.aiFolderID === selectedFolderId && !t.completed && !t.isDeleted);
              if (toUpdate.length === 0) return;
              await (useTodoStore.getState() as any).acceptSuggestions(toUpdate, getActiveFolderId());
            }}
          >
            <CorrectIcon />
          </button>
        </div>
      </div>
    );
  }

  // 快速分類按鈕（todoInbox）
  if (isTodoInbox && hasTodos) {
    const hasTodosToClassify = remainingUnclassified > 0;
    const hintMessage = hasTodosToClassify ? t('quickClassify') : t('noTodosToClassify');
    content.push(
      <button
        key="quick-classify"
        className={`todolist-topbar-button ${isTodoSortEnabled ? 'active' : ''} ${!hasTodosToClassify ? 'todolist-topbar-button-disabled' : ''}`}
        tabIndex={-1}
        disabled={!hasTodosToClassify}
        title={hintMessage}
        onClick={(e) => {
          if (hasTodosToClassify) {
            if (!isTodoSortEnabled) {
              if (isAISortEnabled) setAISortEnabled(false);
              useClassifyHintStore.getState().hideClassifyHint();
              setShowTodoClassifyHint(true);
            }
            toggleTodoSort();
          }
          (e.target as HTMLElement).blur();
        }}
      >
        {isTodoSortEnabled ? (
          <LottieAnimation
            animationData={mode === 'dark' ? AI_loading_sort_dark : AI_loading_sort_light}
            width={24}
            height={24}
            loop={true}
            autoplay={isClassifingTodo}
          />
        ) : (
          <AI_sort_disable />
        )}
      </button>
    );
  }

  return <>{content}</>;
}

// ─── 導出（供 ClassifyPlugin 註冊 overlay） ───

export { NoteListToolBar_ClassifyButtons_patch, TodoListTopbar_ClassifyButtons_patch };
