/**
 * @patch TodoList 臨時資料夾 UI
 * @target .todo-list-wrapper 內的 .todolist-topbar
 * @method createPortal + MutationObserver（猴子補丁，僅 classify 插件）
 *
 * 當 TODO_FOLDER.isTemp === true 時：
 *   - 隱藏 .todolist-topbar
 *   - 以 Portal 注入名稱/描述輸入區域
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useItemStore } from '../../../../Store/itemStore';
import type { TodoFolder } from '../../todo/todoStore';

const ANCHOR_ATTR = 'data-todo-temp-folder-anchor';

function TodoList_TempFolder_patch() {
  const { t } = useTranslation();
  const selectedFolderId = useSelectedItemsStore(s => s.selectedFolderId);
  const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const currentFolder = todoFolders.find(f => f.id === selectedFolderId);
  const isTempFolder = !!currentFolder?.isTemp;

  const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);
  const hiddenElementsRef = useRef<HTMLElement[]>([]);

  const [folderNameInput, setFolderNameInput] = useState('');
  const [descriptionInput, setDescriptionInput] = useState('');
  const [folderNameError, setFolderNameError] = useState('');
  const [isComposing, setIsComposing] = useState(false);

  useEffect(() => {
    if (isTempFolder && currentFolder) {
      setFolderNameInput(currentFolder.name || '');
      setFolderNameError('');
      setDescriptionInput((currentFolder as any).folderSummary || '');
    }
  }, [isTempFolder, selectedFolderId]);

  useEffect(() => {
    const setup = () => {
      const wrapper = document.querySelector('.todo-list-wrapper');
      if (!wrapper) {
        setPortalTarget(null);
        return;
      }

      if (isTempFolder) {
        const topbar = wrapper.querySelector('.todolist-topbar') as HTMLElement | null;
        if (topbar && !hiddenElementsRef.current.includes(topbar)) {
          topbar.style.display = 'none';
          hiddenElementsRef.current.push(topbar);
        }
        const topbarRight = wrapper.querySelector('.todolist-topbar-right') as HTMLElement | null;
        if (topbarRight && !hiddenElementsRef.current.includes(topbarRight)) {
          topbarRight.style.display = 'none';
          hiddenElementsRef.current.push(topbarRight);
        }

        let anchor = wrapper.querySelector(`[${ANCHOR_ATTR}]`) as HTMLElement | null;
        if (!anchor) {
          anchor = document.createElement('div');
          anchor.setAttribute(ANCHOR_ATTR, 'true');
          const mobileTopbar = wrapper.querySelector('.mobile-topbar');
          if (mobileTopbar) {
            mobileTopbar.after(anchor);
          } else {
            wrapper.prepend(anchor);
          }
        }
        setPortalTarget(anchor);
      } else {
        hiddenElementsRef.current.forEach(el => { el.style.display = ''; });
        hiddenElementsRef.current = [];
        wrapper.querySelector(`[${ANCHOR_ATTR}]`)?.remove();
        setPortalTarget(null);
      }
    };

    setup();
    const observer = new MutationObserver(setup);
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      hiddenElementsRef.current.forEach(el => { el.style.display = ''; });
      hiddenElementsRef.current = [];
      document.querySelector(`[${ANCHOR_ATTR}]`)?.remove();
    };
  }, [isTempFolder]);

  const handleNameChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFolderNameError('');
    const isDuplicate = value.trim() && (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).some(
      f => f.name?.toLowerCase() === value.trim().toLowerCase() && f.id !== selectedFolderId
    );
    if (isDuplicate) setFolderNameError(t('duplicateName'));
    setFolderNameInput(value);
  }, [selectedFolderId, t]);

  const handleNameKeyDown = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !isComposing) {
      e.preventDefault();
      (e.target as HTMLElement).blur();
    }
  }, [isComposing]);

  const handleNameBlur = useCallback(async () => {
    if (!isTempFolder || folderNameInput.trim() === '' || folderNameError) return;
    const folder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.id === selectedFolderId);
    if (folder && folder.name !== folderNameInput.trim()) {
      await useItemStore.getState().upsertItem(
        { ...folder, name: folderNameInput.trim(), itemType: 'TODO_FOLDER' },
        { needSync: true }
      );
    }
  }, [isTempFolder, folderNameInput, folderNameError, selectedFolderId]);

  const handleDescBlur = useCallback(async () => {
    if (!isTempFolder) return;
    const folder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.id === selectedFolderId);
    if (folder && (folder as any).folderSummary !== descriptionInput) {
      await useItemStore.getState().upsertItem(
        { ...folder, folderSummary: descriptionInput, itemType: 'TODO_FOLDER' } as any,
        { needSync: true }
      );
    }
  }, [isTempFolder, descriptionInput, selectedFolderId]);

  const handleDescKeyDown = useCallback(async (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && e.shiftKey && !isComposing) {
      e.preventDefault();
      const folder = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.id === selectedFolderId);
      if (folder && (folder as any).folderSummary !== descriptionInput) {
        await useItemStore.getState().upsertItem(
          { ...folder, folderSummary: descriptionInput, itemType: 'TODO_FOLDER' } as any,
          { needSync: true }
        );
      }
    }
  }, [isComposing, descriptionInput, selectedFolderId]);

  if (!portalTarget) return null;

  return createPortal(
    <div className="temp-folder-inputs-container">
      <div className="temp-folder-inputs">
        <div className="input-group">
          <div className="subtitle-container">
            <div className="input-subtitle">{t('newFolderNameLabel')}</div>
          </div>
          <input
            type="text"
            className={`temp-folder-name-input ${folderNameError ? 'input-error' : ''}`}
            value={folderNameInput}
            onChange={handleNameChange}
            onKeyDown={handleNameKeyDown}
            onBlur={handleNameBlur}
            placeholder={t('enterFolderName')}
            onCompositionStart={() => setIsComposing(true)}
            onCompositionEnd={() => setIsComposing(false)}
          />
          {folderNameError && <div className="input-error-message">{folderNameError}</div>}
        </div>
        <div className="input-group">
          <div className="subtitle-container">
            <div className="input-subtitle">{t('description')}</div>
          </div>
          <textarea
            className="temp-folder-description-input"
            value={descriptionInput}
            onChange={e => setDescriptionInput(e.target.value)}
            onBlur={handleDescBlur}
            onKeyDown={handleDescKeyDown}
            placeholder={t('descriptionOptional')}
            onCompositionStart={() => setIsComposing(true)}
            onCompositionEnd={() => setIsComposing(false)}
            rows={4}
          />
        </div>
      </div>
    </div>,
    portalTarget
  );
}

export { TodoList_TempFolder_patch };
