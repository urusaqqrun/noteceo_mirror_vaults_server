/**
 * sidebar 分類猴子補丁
 *
 * 注入分類相關 UI 增強到 sidebar section：
 * - Note sidebar：getCount（inbox 排除 / 普通資料夾加入 aiFolderID 計數）、renderIcon（badge）、topView（未確認建議 bar）
 * - Todo sidebar：renderIcon（badge）、topView（未確認建議 bar）
 *
 * 返回 cleanup 函數以還原所有修改。
 */

import React from 'react';
import { useTranslation } from 'react-i18next';
import { useNoteStore } from '../../note/noteStore';
import type { Note, NoteFolder } from '../../note/noteStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useTodoStore, type Todo, type TodoFolder } from '../../todo/todoStore';
import { useAIGOStore } from '../classifyStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useSidebarRegistry } from '../../sidebar/sidebarStore';
import type { BaseItem } from '../../../../types/item';
import CloseIcon from '../../../../assets/icon_close.svg?react';
import CorrectIcon from '../../../../assets/icon_correct.svg?react';

// 未確認建議 bar — 筆記
const NoteUnconfirmedBar: React.FC = () => {
    const { t } = useTranslation();
    const notes = (useItemStore(s => s.byType['NOTE'] ?? []) as Note[]);
    const activeNotes = React.useMemo(() =>
        notes.filter((n: any) => n.aiFolderID && n.aiFolderID !== '' && !n.isDeleted)
        , [notes]);
    const unconfirmedCount = activeNotes.length;

    if (unconfirmedCount === 0) return null;

    const getActiveFolderId = (): string | null => {
        const lastItem = useSelectedItemsStore.getState().path.at(-1);
        if (!lastItem) return null;
        if (lastItem.itemType?.endsWith('_FOLDER')) return lastItem.id;
        return lastItem.id ?? null;
    };

    return (
        <div className="unconfirmed-notes-container">
            <div className="unconfirmed-notes-text">
                {unconfirmedCount} {unconfirmedCount === 1 ? t('suggestion') : t('suggestions')}
            </div>
            <div className="unconfirmed-notes-actions">
                <button className="unconfirmed-notes-button reject" tabIndex={-1} onClick={async () => {
                    if (activeNotes.length === 0) return;
                    await (useNoteStore.getState() as any).rejectSuggestions(activeNotes, getActiveFolderId());
                    setTimeout(() => {
                        const state = useSelectedItemsStore.getState();
                        if (state.path.length === 0 && state.extraItems.length === 0) {
                            const inboxFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.name === 'inbox');
                            if (inboxFolder) state.setSelectedItems([inboxFolder], { scrollToFocusItem: true });
                        }
                    }, 500);
                }}>
                    <CloseIcon />
                </button>
                <button className="unconfirmed-notes-button accept" tabIndex={-1} onClick={async () => {
                    if (activeNotes.length === 0) return;
                    await (useNoteStore.getState() as any).acceptSuggestions(activeNotes, getActiveFolderId());
                }}>
                    <CorrectIcon />
                </button>
            </div>
        </div>
    );
};

// 未確認建議 bar — 待辦
const TodoUnconfirmedBar: React.FC = () => {
    const { t } = useTranslation();
    const todos = useItemStore(s => s.byType['TODO'] ?? []) as Todo[];
    const activeTodos = React.useMemo(() =>
        todos.filter((todo: any) => todo.aiFolderID && todo.aiFolderID !== '' && !todo.completed && !todo.isDeleted)
        , [todos]);
    const unconfirmedCount = activeTodos.length;

    if (unconfirmedCount === 0) return null;

    const getActiveFolderId = (): string | null => {
        const lastItem = useSelectedItemsStore.getState().path.at(-1);
        if (!lastItem) return null;
        if (lastItem.itemType?.endsWith('_FOLDER') || lastItem.itemType === 'TODO_VIRTUAL_FOLDER') return lastItem.id;
        return lastItem.id ?? null;
    };

    return (
        <div className="unconfirmed-notes-container">
            <div className="unconfirmed-notes-text">
                {unconfirmedCount} {unconfirmedCount === 1 ? t('suggestion') : t('suggestions')}
            </div>
            <div className="unconfirmed-notes-actions">
                <button className="unconfirmed-notes-button reject" tabIndex={-1} onClick={async () => {
                    if (activeTodos.length === 0) return;
                    await (useTodoStore.getState() as any).rejectSuggestions(activeTodos, getActiveFolderId());
                    setTimeout(() => {
                        const state = useSelectedItemsStore.getState();
                        if (state.path.length === 0 && state.extraItems.length === 0) {
                            const todoInbox = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[]).find(f => f.name === 'todoInbox');
                            if (todoInbox) state.setSelectedItems([todoInbox], { scrollToFocusItem: true });
                        }
                    }, 500);
                }}>
                    <CloseIcon />
                </button>
                <button className="unconfirmed-notes-button accept" tabIndex={-1} onClick={async () => {
                    if (activeTodos.length === 0) return;
                    await (useTodoStore.getState() as any).acceptSuggestions(activeTodos, getActiveFolderId());
                }}>
                    <CorrectIcon />
                </button>
            </div>
        </div>
    );
};

export function patchSidebarClassify(): () => void {
    const registry = useSidebarRegistry.getState();
    let origNoteUseData: any = null;
    let origTodoUseData: any = null;

    // ---- Note sidebar ----
    const noteSection = registry.sections.get('note');
    if (noteSection) {
        origNoteUseData = noteSection.useData;
        const origUseData = noteSection.useData;
        const enhancedUseData = () => {
            const data = origUseData();
            const classifiedNotes: any[] = useNoteStore((s: any) => s.classifiedNotes ?? []);
            const notes = (useItemStore(s => s.byType['NOTE'] ?? []) as Note[]);
            const refreshingFolderNameIds = useAIGOStore(s => s.refreshingFolderNameIds);
            const generatingSummaryFolderIds = useAIGOStore(s => s.generatingSummaryFolderIds);

            const origGetCount = data.getCount;
            const enhancedGetCount = (item: BaseItem) => {
                const base = origGetCount?.(item);
                if (!base) return base;
                // inbox：排除有 aiFolderID 的筆記
                if (item.name === 'inbox') {
                    const inboxCount = notes.filter((n: any) => n.parentID === item.id && !n.aiFolderID && !n.isDeleted).length;
                    return { ...base, value: inboxCount };
                }
                // 普通資料夾：加上 aiFolderID 指向此資料夾的筆記
                const aiCount = notes.filter((n: any) =>
                    n.parentID !== item.id && n.aiFolderID === item.id && !n.isDeleted
                ).length;
                if (aiCount > 0) return { ...base, value: base.value + aiCount };
                return base;
            };

            const origRenderIcon = data.renderIcon;
            const enhancedRenderIcon = (item: BaseItem) => {
                const isProcessing = refreshingFolderNameIds.includes(item.id) || generatingSummaryFolderIds.includes(item.id);
                if (isProcessing) return React.createElement('div', { className: 'folder-icon-loader' });
                const count = classifiedNotes.filter((n: any) => n.aiFolderID === item.id).length;
                if (count > 0) return React.createElement('div', { className: 'folder-count-badge' }, count);
                return origRenderIcon?.(item);
            };

            const origGetDisplayName = data.getDisplayName;
            const enhancedGetDisplayName = (item: BaseItem) => {
                const name = origGetDisplayName?.(item) ?? item.name;
                if ((item as any).isTemp) {
                    return React.createElement('span', { className: 'temp-folder-name' }, name);
                }
                return name;
            };

            return { ...data, getCount: enhancedGetCount, renderIcon: enhancedRenderIcon, getDisplayName: enhancedGetDisplayName, topView: React.createElement(NoteUnconfirmedBar) };
        };
        registry.registerSection({ ...noteSection, useData: enhancedUseData });
    }

    // ---- Todo sidebar ----
    const todoSection = registry.sections.get('todo');
    if (todoSection) {
        origTodoUseData = todoSection.useData;
        const origUseData = todoSection.useData;
        const enhancedUseData = () => {
            const data = origUseData();
            const todos = useItemStore(s => s.byType['TODO'] ?? []) as Todo[];
            const classifiedTodos = React.useMemo(
                () => todos.filter((t: any) => t.aiFolderID && t.aiFolderID !== '' && !t.completed && !t.isDeleted),
                [todos]
            );

            const origRenderIcon = data.renderIcon;
            const enhancedRenderIcon = (item: BaseItem) => {
                const count = classifiedTodos.filter((t: any) => t.aiFolderID === item.id).length;
                if (count > 0) return React.createElement('div', { className: 'folder-count-badge' }, count);
                return origRenderIcon?.(item);
            };

            const origGetDisplayName = data.getDisplayName;
            const enhancedGetDisplayName = (item: BaseItem) => {
                const name = origGetDisplayName?.(item) ?? item.name;
                if ((item as any).isTemp) {
                    return React.createElement('span', { className: 'temp-folder-name' }, name);
                }
                return name;
            };

            return { ...data, renderIcon: enhancedRenderIcon, getDisplayName: enhancedGetDisplayName, topView: React.createElement(TodoUnconfirmedBar) };
        };
        registry.registerSection({ ...todoSection, useData: enhancedUseData });
    }

    // 返回 cleanup 函數
    return () => {
        const reg = useSidebarRegistry.getState();
        if (origNoteUseData) {
            const ns = reg.sections.get('note');
            if (ns) reg.registerSection({ ...ns, useData: origNoteUseData });
        }
        if (origTodoUseData) {
            const ts = reg.sections.get('todo');
            if (ts) reg.registerSection({ ...ts, useData: origTodoUseData });
        }
    };
}
