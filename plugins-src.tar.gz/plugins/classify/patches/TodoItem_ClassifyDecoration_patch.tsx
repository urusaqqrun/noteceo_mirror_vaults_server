/**
 * @patch TodoItem_ClassifyDecoration
 * @target [data-id] .note-title-container (beforeend)
 * @method createPortal + MutationObserver + zustand subscribe
 * @description 為 TodoItem 注入分類相關的 UI 裝飾：
 *   1. 分類狀態圖標（loading / pause）
 *   2. 「前往XX」右滑動畫標示
 *   3. 確認/拒絕分類建議按鈕
 *   4. slide-out-right CSS 動畫
 *   5. has-ai-folder-suggest CSS class
 *   6. meta row AI 資料夾建議（from → to）
 */

import React, { useEffect, useState, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useTodoClassifyActivityStore } from '../classifyStore';
import { useTodoStore, type Todo, type TodoFolder } from '../../todo/todoStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import CloseIcon from '../../../../assets/icon_close.svg?react';
import CorrectIcon from '../../../../assets/icon_correct.svg?react';
import PauseIcon from '../../../../assets/bk_icon_pause_26_n.svg?react';

function TodoClassifyDecoration({ noteId, container }: { noteId: string; container: HTMLElement }) {
    const { t } = useTranslation();

    const isAiClassifying = useTodoClassifyActivityStore(useCallback(state =>
        state.aiClassifyTodoIds.includes(noteId), [noteId]));
    const isSlideRight = useTodoClassifyActivityStore(useCallback(state =>
        state.slideRightTodoIds.includes(noteId), [noteId]));

    const todo = (useItemStore(useCallback(s =>
        (s.byType['TODO'] ?? []).find((n: any) => n.id === noteId), [noteId]))) as Todo | undefined;
    const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];

    const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
    const todoInboxId = todoFolders.find(f => f.name === 'todoInbox')?.id;
    const isInbox = selectedFolderId === todoInboxId;

    const targetFolder = todo?.aiFolderID ? todoFolders.find(f => f.id === todo.aiFolderID) : null;
    const targetFolderName = targetFolder?.name || '';

    const getDisplayName = useCallback((folderName: string | undefined) => {
        if (folderName === 'inbox') return t('inbox');
        if (folderName === 'todoInbox') return t('todoInbox');
        if (folderName === 'trash') return t('trash');
        return folderName;
    }, [t]);

    // slide-out-right 動畫（母任務 + 子任務都在 slideRightTodoIds 中）
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const innerElement = noteEl.querySelector(':scope > div');

        if (!todo || !isInbox || !isSlideRight) return;

        const timer = setTimeout(() => {
            innerElement?.classList.add('slide-out-right');
        }, 400);

        return () => clearTimeout(timer);
    }, [isInbox, isSlideRight, noteId]);

    // has-ai-folder-suggest CSS class
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const innerDiv = noteEl.querySelector(':scope > div');
        if (!innerDiv) return;

        if (todo?.aiFolderID && todo.aiFolderID === selectedFolderId) {
            innerDiv.classList.add('has-ai-folder-suggest');
        } else {
            innerDiv.classList.remove('has-ai-folder-suggest');
        }

        return () => {
            innerDiv.classList.remove('has-ai-folder-suggest');
        };
    }, [todo?.aiFolderID, selectedFolderId]);

    // meta row AI folder suggestion 注入
    useEffect(() => {
        const noteEl = container.closest('[data-id]');
        if (!noteEl) return;
        const folderWrapper = noteEl.querySelector('.todo-item-folder-wrapper');

        if (todo?.aiFolderID && !isInbox && selectedFolderId !== todoInboxId) {
            const aiFolder = todoFolders.find(f => f.id === todo.aiFolderID);
            if (aiFolder && folderWrapper) {
                folderWrapper.classList.add('todo-item-folder-ai-suggest');
            }
        } else {
            if (folderWrapper) folderWrapper.classList.remove('todo-item-folder-ai-suggest');
        }

        return () => {
            if (folderWrapper) folderWrapper.classList.remove('todo-item-folder-ai-suggest');
        };
    }, [todo?.aiFolderID, isInbox, selectedFolderId, todoInboxId, todoFolders]);

    // statusIcon 計算
    let statusIcon: string | null = null;
    if (todo) {
        if (todo.aiFolderID) {
            statusIcon = null;
        } else if (isAiClassifying) {
            statusIcon = 'loading';
        } else if (todo.classificationStatus === 'UNCLASSIFIABLE' || todo.classificationStatus === 'PAUSE') {
            statusIcon = 'pause';
        }
    }

    const showStatusIcon = isInbox && statusIcon;
    const showSlideRight = isInbox && todo?.aiFolderID && targetFolderName && isSlideRight;
    const showSuggestion = todo?.aiFolderID === selectedFolderId && todo?.aiFolderID;

    if (!showStatusIcon && !showSlideRight && !showSuggestion) return null;

    return createPortal(
        <>
            {showStatusIcon && (
                <div className={`classification-status show ${isInbox ? 'in-unclassified' : ''}`}>
                    <div
                        className="status-touch-block"
                        onClick={async (e) => {
                            e.stopPropagation();
                            if (!todo) return;
                            if (todo.classificationStatus === 'PAUSE' || todo.classificationStatus === 'UNCLASSIFIABLE') {
                                await useTodoStore.getState().updateTodoWithoutUpdateAt({ ...todo, classificationStatus: 'TODO' });
                            }
                            useTodoClassifyActivityStore.getState().setForceRefreshTodoClassify(
                                (prev: boolean) => !prev
                            );
                        }}
                    >
                        <div className="status-icon">
                            {statusIcon === 'loading' && <div className="notelist-loading-spinner" />}
                            {statusIcon === 'pause' && <PauseIcon />}
                        </div>
                    </div>
                </div>
            )}

            {showSlideRight && (
                <div className="classification-status moving-animation fade-out-after">
                    <div className="status-text">{t('goTo', { folderName: getDisplayName(targetFolderName) })}</div>
                </div>
            )}

            {showSuggestion && (
                <div className={`classification-status-container${isSlideRight ? ' delayed-fade-in' : ''}`}>
                    <div className="classification-status reduced-height show" />
                    <div className="status-actions">
                        <div
                            className="status-actions-top-touch-block"
                            onClick={async (e) => {
                                e.stopPropagation();
                                await (useTodoStore.getState() as any).rejectSuggestions(todo, selectedFolderId);
                            }}
                        >
                            <div className="status-icon action-icon error-icon">
                                <CloseIcon />
                            </div>
                        </div>
                        <div
                            className="status-actions-bottom-touch-block"
                            onClick={async (e) => {
                                e.stopPropagation();
                                await (useTodoStore.getState() as any).acceptSuggestions(todo, selectedFolderId);
                            }}
                        >
                            <div className="status-icon action-icon primary-icon">
                                <CorrectIcon />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>,
        container
    );
}

function TodoItem_ClassifyDecoration_patch() {
    const [todoAnchors, setTodoAnchors] = useState<Map<string, HTMLElement>>(new Map());

    useEffect(() => {
        const containerSelector = '.todo-list-wrapper';

        const scanAndInject = () => {
            const newAnchors = new Map<string, HTMLElement>();
            const todoItems = document.querySelectorAll('.todo-list-wrapper [data-id]');

            todoItems.forEach(item => {
                const todoId = item.getAttribute('data-id');
                if (!todoId) return;

                const todoItem = item.querySelector('.todo-item');
                if (!todoItem) return;

                let anchor = todoItem.querySelector('[data-classify-todo-anchor]') as HTMLElement;
                if (!anchor) {
                    anchor = document.createElement('div');
                    anchor.setAttribute('data-classify-todo-anchor', 'true');
                    anchor.style.display = 'contents';
                    todoItem.appendChild(anchor);
                }

                newAnchors.set(todoId, anchor);
            });

            setTodoAnchors(prev => {
                if (prev.size !== newAnchors.size) return newAnchors;
                for (const [key, val] of newAnchors) {
                    if (prev.get(key) !== val) return newAnchors;
                }
                return prev;
            });
        };

        scanAndInject();

        const observer = new MutationObserver(() => {
            scanAndInject();
        });

        const containers = document.querySelectorAll(containerSelector);
        containers.forEach(container => {
            observer.observe(container, { childList: true, subtree: true });
        });
        observer.observe(document.body, { childList: true, subtree: true });

        return () => {
            observer.disconnect();
            document.querySelectorAll('[data-classify-todo-anchor]').forEach(el => el.remove());
        };
    }, []);

    return (
        <>
            {Array.from(todoAnchors.entries()).map(([todoId, anchor]) => (
                <TodoClassifyDecoration key={todoId} noteId={todoId} container={anchor} />
            ))}
        </>
    );
}

export default TodoItem_ClassifyDecoration_patch;
