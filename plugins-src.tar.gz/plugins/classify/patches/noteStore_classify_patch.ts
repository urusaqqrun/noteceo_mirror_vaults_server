/**
 * noteStore 分類猴子補丁
 *
 * 注入 aiFolderID 相關邏輯到 noteStore：
 * - getFilteredAndSortedItems：inbox 排除 + 目標資料夾合併 + slideRight + aiFolderID 排序
 * - handleTempFolders：保留被 aiFolderID 引用的臨時資料夾
 * - acceptSuggestions / rejectSuggestions：分類建議操作
 *
 * 返回 cleanup 函數以還原所有修改。
 */

import { useNoteStore } from '../../note/noteStore';
import type { Note, NoteFolder } from '../../note/noteStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useAIGOStore } from '../classifyStore';
import { timerManager } from '../../../../Store/uiStore';

export function patchNoteStoreClassify(): () => void {
    const origMethod = useNoteStore.getState().getFilteredAndSortedItems;
    const origMoveNoteToFolder = useNoteStore.getState().moveNoteToFolder;

    // 訂閱 slideRightNoteIds 變化 → 觸發 NoteList 重新過濾
    let prevSlideRight = useAIGOStore.getState().slideRightNoteIds;
    const unsubSlideRight = useAIGOStore.subscribe((state) => {
        if (state.slideRightNoteIds !== prevSlideRight) {
            prevSlideRight = state.slideRightNoteIds;
            useNoteStore.getState().bumpFilterVersion();
        }
    });

    // 訂閱 notes 變化 → 更新 classifiedNotes
    let prevNotes = (useItemStore.getState().getByType('NOTE') as Note[]);
    const initialClassified = prevNotes.filter((note: any) => note.aiFolderID);
    const unsubNotes = useItemStore.subscribe((state) => {
        const notes = (state.byType['NOTE'] ?? []) as Note[];
        if (notes !== prevNotes) {
            prevNotes = notes;
            const classified = notes.filter((note: any) => note.aiFolderID);
            useNoteStore.setState({ classifiedNotes: classified } as any);
        }
    });

    // 注入分類方法到 noteStore（classifiedNotes 用當前已計算的值，避免覆蓋為空）
    useNoteStore.setState({
        _classifyCleanupSlideRight: (noteIdsToRemove: string[]) => {
            const currentSlideRightNoteIds = useAIGOStore.getState().slideRightNoteIds;
            const filteredSlideRightNoteIds = currentSlideRightNoteIds.filter(
                (id: string) => !noteIdsToRemove.includes(id)
            );
            if (filteredSlideRightNoteIds.length !== currentSlideRightNoteIds.length) {
                useAIGOStore.getState().setSlideRightNoteIds(filteredSlideRightNoteIds);
            }
        },
        classifiedNotes: initialClassified,
        updateClassifiedNotes: (notes: any[]) => {
            const classified = notes.filter((note: any) => note.aiFolderID);
            useNoteStore.setState({ classifiedNotes: classified } as any);
        },
        cleanInvalidaiFolderIDs: async (notes: any[]) => {
            const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
            const notesToClean = notes.filter((note: any) => {
                if (!note.aiFolderID) return false;
                const targetFolder = folders.find((f: any) => f.id === note.aiFolderID);
                return !targetFolder;
            });
            if (notesToClean.length > 0) {
                for (const note of notesToClean) {
                    const updatedNote = { ...note, aiFolderID: null };
                    await useItemStore.getState().upsertItem({ ...updatedNote, itemType: 'NOTE' }, { needSync: true });
                }
            }
        },
        acceptSuggestions: (notes: any, currentViewFolderId: string | null) => {
            const notesToUpdate = Array.isArray(notes) ? notes : [notes];
            if (notesToUpdate.length === 0) return Promise.resolve();

            const notesNeedAnimation = notesToUpdate.filter((note: any) =>
                note.aiFolderID !== currentViewFolderId
            );
            notesNeedAnimation.forEach((note: any) => {
                const noteElement = document.querySelector(`[data-id="${note.id}"]`);
                if (noteElement) {
                    noteElement.classList.add('note-item', 'slide-out-right');
                }
            });

            const delay = notesNeedAnimation.length > 0 ? 400 : 0;
            const timerKey = `acceptSuggestions_${Date.now()}`;
            return new Promise<void>((resolve) => {
                timerManager.set(timerKey, async () => {
                    const updatedNotes = notesToUpdate.map((note: any) => ({
                        ...note,
                        parentID: note.aiFolderID,
                        aiFolderID: null,
                    }));
                    await useNoteStore.getState().updateNote(updatedNotes);
                    await (useNoteStore.getState() as any).handleTempFolders?.();
                    resolve();
                }, delay);
            });
        },
        rejectSuggestions: (notes: any, currentViewFolderId: string | null) => {
            const notesToUpdate = Array.isArray(notes) ? notes : [notes];
            if (notesToUpdate.length === 0) return Promise.resolve();

            const allFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
            const inboxId = allFolders.find((f: any) => f.name === 'inbox')?.id;

            const notesNeedAnimation = notesToUpdate.filter((note: any) =>
                note.aiFolderID === currentViewFolderId
            );
            notesNeedAnimation.forEach((note: any) => {
                const noteElement = document.querySelector(`[data-id="${note.id}"]`);
                if (noteElement) {
                    noteElement.classList.add('note-item', 'slide-out-left');
                }
            });

            const delay = notesNeedAnimation.length > 0 ? 400 : 0;
            const timerKey = `rejectSuggestions_${Date.now()}`;
            return new Promise<void>((resolve) => {
                timerManager.set(timerKey, async () => {
                    const updatedNotes = notesToUpdate.map((note: any) => {
                        let classificationStatus = note.classificationStatus;
                        if (note.parentID === inboxId) {
                            classificationStatus = 'UNCLASSIFIABLE';
                        }
                        const targetFolderName = allFolders.find((f: any) => f.id === note.aiFolderID)?.name;
                        const currentRejectedFolders = Array.isArray(note.rejectedFolderNames)
                            ? [...note.rejectedFolderNames]
                            : (note.rejectedFolderNames ? [...note.rejectedFolderNames] : []);
                        if (targetFolderName && !currentRejectedFolders.includes(targetFolderName)) {
                            currentRejectedFolders.push(targetFolderName);
                        }
                        return {
                            ...note,
                            classificationStatus,
                            aiFolderID: null,
                            rejectedFolderNames: currentRejectedFolders,
                        };
                    });

                    const noteIdsToRemove = notesToUpdate.map((note: any) => note.id);
                    if ((useNoteStore.getState() as any)._classifyCleanupSlideRight) {
                        (useNoteStore.getState() as any)._classifyCleanupSlideRight(noteIdsToRemove);
                    }

                    await useNoteStore.getState().updateNoteWithoutUpdateAt(updatedNotes);
                    await (useNoteStore.getState() as any).handleTempFolders?.();
                    resolve();
                }, delay);
            });
        },
    } as any);

    // 猴子補丁 handleTempFolders — 保留被 aiFolderID 引用的臨時資料夾
    useNoteStore.setState({
        handleTempFolders: async () => {
            try {
                const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
                const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
                const tempFolders = folders.filter((folder: any) => folder.isTemp);
                const foldersNeedUpdate: any[] = [];
                const foldersNeedDelete: string[] = [];
                tempFolders.forEach((folder: any) => {
                    const hasNotes = notes.some((note: any) => note.parentID === folder.id);
                    const isTargeted = notes.some((note: any) => note.aiFolderID === folder.id);
                    if (hasNotes) {
                        foldersNeedUpdate.push({ ...folder, isTemp: false });
                    } else if (!isTargeted) {
                        foldersNeedDelete.push(folder.id);
                    }
                });
                if (foldersNeedUpdate.length > 0) {
                    for (const f of foldersNeedUpdate) {
                      await useItemStore.getState().upsertItem({ ...f, itemType: 'NOTE_FOLDER' }, { needSync: true });
                    }
                }
                if (foldersNeedDelete.length > 0) {
                    await useNoteStore.getState().deleteNoteFolder(foldersNeedDelete);
                }
            } catch (error) {
                console.error('處理臨時資料夾失敗:', error);
            }
        },
    } as any);

    // 覆寫 moveNoteToFolder — 搬移時清除 aiFolderID + 觸發 handleTempFolders
    useNoteStore.setState({
        moveNoteToFolder: async (noteId: string, targetFolderId: string) => {
            await origMoveNoteToFolder(noteId, targetFolderId);
            const notes = useItemStore.getState().getByType('NOTE') as Note[];
            const movedNotes = notes.filter((n: any) => n.parentID === targetFolderId && n.aiFolderID);
            for (const note of movedNotes) {
                await useItemStore.getState().upsertItem(
                    { ...note, aiFolderID: null, itemType: 'NOTE' } as any,
                    { needSync: true },
                );
            }
            await (useNoteStore.getState() as any).handleTempFolders?.();
        },
    } as any);

    // 覆寫 getFilteredAndSortedItems — 合併 aiFolderID 筆記 + inbox 排除 + slideRight + aiFolderID 排序
    useNoteStore.setState({
        getFilteredAndSortedItems: (allNotes: any[], folderId: string) => {
            const baseResult = origMethod(allNotes, folderId);

            const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
            const folderName = folders.find((f: any) => f.id === folderId)?.name;

            // ==== inbox 過濾：隱藏有 aiFolderID 的筆記，但 slideRight 動畫中的暫時保留 ====
            if (folderName === 'inbox') {
                const slideRightNoteIds = useAIGOStore.getState().slideRightNoteIds;
                const filtered = baseResult.filter((note: any) =>
                    !note.aiFolderID || slideRightNoteIds.includes(note.id)
                );
                return filtered;
            }

            // 把 aiFolderID === folderId 的筆記合併進來（不重複）
            const baseIds = new Set(baseResult.map((n: any) => n.id));
            const aiClassifiedNotes = allNotes.filter((n: any) =>
                n.aiFolderID === folderId && !baseIds.has(n.id)
            );
            const merged = aiClassifiedNotes.length > 0
                ? [...baseResult, ...aiClassifiedNotes]
                : baseResult;

            // ==== aiFolderID 排序增強 ====
            if (folderName !== 'inbox') {
                const slideRightNoteIds = useAIGOStore.getState().slideRightNoteIds;
                const sorted = [...merged].sort((a: any, b: any) => {
                    const aHas = a.aiFolderID && !slideRightNoteIds.includes(a.id);
                    const bHas = b.aiFolderID && !slideRightNoteIds.includes(b.id);
                    if (aHas && !bHas) return -1;
                    if (!aHas && bHas) return 1;
                    return 0;
                });
                return sorted;
            }

            return merged;
        },
    } as any);

    // 返回 cleanup 函數
    return () => {
        unsubNotes();
        unsubSlideRight();
        useNoteStore.setState({
            getFilteredAndSortedItems: origMethod,
            moveNoteToFolder: origMoveNoteToFolder,
            handleTempFolders: undefined,
            _classifyCleanupSlideRight: undefined,
            classifiedNotes: undefined,
            updateClassifiedNotes: undefined,
            cleanInvalidaiFolderIDs: undefined,
            acceptSuggestions: undefined,
            rejectSuggestions: undefined,
        } as any);
    };
}
