/**
 * @patch NoteRightClickMenu 分類選項
 * @target .right-click-menu[data-menu-id="noteListMenu"] 第一個按鈕之後
 * @method createPortal + MutationObserver（猴子補丁，僅改 classify 插件）
 */

import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../../../setting/ThemeProvider';
import AIToggleDarkIcon from '../../../../assets/icon_toggle_AI_sort_active_dark_24.svg?react';
import AIToggleLightIcon from '../../../../assets/icon_toggle_AI_sort_active_light_24.svg?react';

import PlayIcon from '../../../../assets/bk_icon_play_26_n.svg?react';
import PauseIcon from '../../../../assets/bk_icon_pause_26_n.svg?react';

import { useMenuStore } from '../../../../Store/menuStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useNoteStore, type NoteFolder } from '../../note/noteStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useAISortStore, useAIGOStore } from '../classifyStore';
import { classificationService } from '../ClassificationService';

const ANCHOR_ATTR = 'data-classify-menu-anchor';

function findNoteMenuAnchor(): HTMLElement | null {
  const menu = document.querySelector('.right-click-menu[data-menu-id="noteListMenu"]');
  if (!menu) return null;
  let anchor = menu.querySelector(`[${ANCHOR_ATTR}]`) as HTMLElement | null;
  if (!anchor) {
    const pinBtn = menu.firstElementChild;
    if (!pinBtn) return null;
    anchor = document.createElement('div');
    anchor.setAttribute(ANCHOR_ATTR, 'true');
    pinBtn.after(anchor);
  }
  return anchor;
}

function NoteMenuClassifyButtons() {
  const { t } = useTranslation();
  const theme = useTheme();
  const menuState = useMenuStore(state => state.menus['noteListMenu']);
  const showMenu = menuState?.show;
  const noteId = menuState?.data?.noteId;
  const hideRightClickMenu = () => useMenuStore.getState().close('noteListMenu');

  const isAISortEnabled = useAISortStore(state => state.isAISortEnabled);
  const updateNoteWithoutUpdateAt = useNoteStore(state => state.updateNoteWithoutUpdateAt);

  const [note, setNote] = useState<any>(null);
  const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (!noteId) { setNote(null); return; }
    (window as any).electronAPI?.getItem?.(noteId).then((item: any) => setNote(item ?? null));
  }, [noteId]);

  useEffect(() => {
    if (!showMenu || !noteId) {
      setPortalTarget(null);
      return;
    }
    const tryFind = () => {
      const anchor = findNoteMenuAnchor();
      if (anchor) setPortalTarget(anchor);
    };
    tryFind();
    const observer = new MutationObserver(tryFind);
    observer.observe(document.body, { childList: true, subtree: true });
    return () => {
      observer.disconnect();
      document.querySelectorAll(`[${ANCHOR_ATTR}]`).forEach(el => el.remove());
    };
  }, [showMenu, noteId]);

  if (!portalTarget || !note) return null;

  const _folderId = useSelectedItemsStore.getState().selectedFolderId;
  const _noteFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
  const _folder = _noteFolders.find(f => f.id === _folderId);
  const folderName = _folder?.name ?? 'inbox';
  const isUnclassified = folderName === 'inbox';

  const status = note?.classificationStatus;
  const isPauseOrDisable = status === 'PAUSE' || status === 'UNCLASSIFIABLE' || status?.startsWith('前往');
  const AIToggleIcon = theme.mode === 'dark' ? AIToggleDarkIcon : AIToggleLightIcon;

  const refreshClassify = () => useAIGOStore.getState().setForceRefreshClassify((prev: any) => !prev);



  const handleTogglePause = async () => {
    if (status === 'PAUSE' || status === 'UNCLASSIFIABLE') {
      await updateNoteWithoutUpdateAt({ ...note, classificationStatus: 'TODO' });
    } else {
      await updateNoteWithoutUpdateAt({ ...note, classificationStatus: 'PAUSE' });
    }
    refreshClassify();
    hideRightClickMenu();
  };

  const handleExecuteAISort = async () => {
    if (!isAISortEnabled) {
      await updateNoteWithoutUpdateAt({ ...note, classificationStatus: 'TODO' });
      classificationService.classifyNotes([note]);
    }
    hideRightClickMenu();
  };

  return createPortal(
    <>

      {isUnclassified && (
        <>
          {!isAISortEnabled && (
            <button
              className="right-click-menu-item"
              onClick={handleExecuteAISort}
              onMouseDown={(e) => e.preventDefault()}
            >
              <AIToggleIcon />
              <span>{t('executeAIClassification')}</span>
            </button>
          )}

          <button
            className="right-click-menu-item"
            onClick={handleTogglePause}
            onMouseDown={(e) => e.preventDefault()}
          >
            {isPauseOrDisable ? (
              <>
                <PlayIcon />
                <span>{t('continueClassification')}</span>
              </>
            ) : (
              <>
                <PauseIcon />
                <span>{t('pauseClassification')}</span>
              </>
            )}
          </button>
        </>
      )}
    </>,
    portalTarget
  );
}

export default NoteMenuClassifyButtons;
