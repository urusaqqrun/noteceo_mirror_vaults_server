/**
 * classify 插件共用工具函數
 */

import i18n from '../../../i18n/config';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import {
  singleClassifyInExistingFolder,
  autoClassifyMulti,
  noteSubClassify,
} from './ai/classifyAI';
import { processItemContent } from '../../../utils/textUtils';

// ─── 資料夾層級分類管線（inbox → 資料夾）───

/** 差異化 config — Note / Todo 各建構一份 */
export interface ClassifyPipelineConfig {
  label: string;
  folderType: string;
  inboxName: string;
  excludedFolderNames: string[];

  getFilteredItems: () => any[];
  getFolderType: (id: string) => { isGroup: boolean };
  filterItem: (item: any, selectedId: string | null, isEditing: boolean) => boolean;
  filterRemaining: (item: any) => boolean;
  buildContent: (item: any) => string;

  setIsClassifying: (v: boolean) => void;
  setClassifyIds: (ids: string[]) => void;
  getSlideRightIds: () => string[];
  setSlideRightIds: (ids: string[]) => void;
  updateWithoutUpdateAt: (item: any) => Promise<void>;
  addFolder: (data: any) => Promise<void>;

  isSortEnabled: () => boolean;
  setSortEnabled: (v: boolean) => void;
  onAllClassified: () => void;
  onError: (error: any) => void;
  onFinally: (signal: AbortSignal) => void;

  handleGroupNameCollision?: (name: string, description: string, signal: AbortSignal) => Promise<string>;
}

function buildItemContent(item: any): string {
  const name = item.name || item.aiTitle || '';
  const body = processItemContent(item, false, false);
  return `${name} ${body}`.trim().substring(0, 200);
}

/** 設置分類建議（滑動動畫 + 寫入 aiFolderID） */
export async function setClassificationSuggestion(
  item: any,
  targetFolder: any,
  config: Pick<ClassifyPipelineConfig, 'getSlideRightIds' | 'setSlideRightIds' | 'updateWithoutUpdateAt'>,
): Promise<boolean> {
  const current = await (window as any).electronAPI.getItem(item.id);
  if (!current || current.classificationStatus === 'PAUSE') return false;

  const updated = { ...current, classificationStatus: 'TODO', aiFolderID: targetFolder.id };

  // 子任務也一起滑動
  const childIds = (useItemStore.getState().byType['TODO'] ?? [])
    .filter((t: any) => t.parentID === item.id)
    .map((t: any) => t.id);
  const allSlideIds = [item.id, ...childIds];

  const slideIds = config.getSlideRightIds();
  config.setSlideRightIds([...slideIds, ...allSlideIds]);
  await config.updateWithoutUpdateAt(updated);

  const idsToRemove = new Set(allSlideIds);
  setTimeout(() => {
    const ids = config.getSlideRightIds();
    config.setSlideRightIds(ids.filter((id: string) => !idsToRemove.has(id)));
  }, 800);

  return true;
}

/**
 * 從 inbox 篩選未分類項目，交給 classifyItemsPipeline 處理。
 * 全部分類完成後自動關閉排序開關。
 */
export async function findAndClassifyItems(
  config: ClassifyPipelineConfig,
  batchSize: number,
  runPipeline: (items: any[]) => Promise<void>,
): Promise<void> {
  try {
    const filteredItems = config.getFilteredItems();
    const selectedId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
    const isEditing = document.activeElement?.closest('.ProseMirror') !== null;

    const unclassified = filteredItems
      .filter((item: any) => config.filterItem(item, selectedId, isEditing))
      .slice(0, batchSize);

    if (unclassified.length > 0) {
      await runPipeline(unclassified);
    } else if (config.isSortEnabled()) {
      const remaining = filteredItems.filter((item: any) => config.filterRemaining(item));
      if (remaining.length === 0) {
        config.setSortEnabled(false);
        config.onAllClassified();
      }
    }
  } catch (error) {
    console.error(`[${config.label}] 獲取 inbox 項目失敗:`, error);
  }
}

/**
 * 分類管線核心：singleClassify → yes/no split → multiClassify → createFolder
 *
 * 完全對應舊的 classifyNotes / classifyTodos，差異透過 config 注入。
 */
export async function classifyItemsPipeline(
  items: any[],
  signal: AbortSignal,
  config: ClassifyPipelineConfig,
): Promise<void> {
  const folders = useItemStore.getState().getByType(config.folderType) as any[];
  const validFolders = folders.filter((f: any) =>
    !config.excludedFolderNames.includes(f.name) &&
    !config.getFolderType(f.id).isGroup
  );

  config.setClassifyIds(items.map((it: any) => it.id));

  let tempClassifications: string[] = [];

  if (validFolders.length > 0) {
    const folderNames = validFolders.map((f: any) => f.name);
    const folderIntentions = validFolders.map((f: any) => f.folderSummary || f.name);

    for (const item of items) {
      const content = config.buildContent(item);

      const { classifications } = await singleClassifyInExistingFolder(
        content, folderNames, folderIntentions, signal, { isPassive: true },
      );

      const matched = folderNames.filter((_, idx) => classifications[idx] === '是');

      if (matched.length === 1) {
        const target = validFolders.find((f: any) => f.name === matched[0]);
        if (target) await setClassificationSuggestion(item, target, config);
        tempClassifications.push('已處理');
      } else if (matched.length > 1) {
        tempClassifications.push('是');
      } else {
        tempClassifications.push('否');
      }
    }
  } else {
    tempClassifications = items.map(() => '否');
  }

  const yesItems = items.filter((_, i) => tempClassifications[i] === '是');
  const noItems = items.filter((_, i) => tempClassifications[i] === '否');

  // 處理複數匹配
  if (yesItems.length > 0) {
    const folderNames = validFolders.map((f: any) => f.name);
    const folderIntentions = validFolders.map((f: any) => f.folderSummary || f.name);
    const contents = yesItems.map((item: any) => config.buildContent(item));

    const { classifications } = await autoClassifyMulti(
      contents, folderNames, folderIntentions, signal, { isPassive: true },
    );

    const currentFolders = useItemStore.getState().getByType(config.folderType) as any[];
    for (let i = 0; i < classifications.length; i++) {
      if (classifications[i] !== '無法分類') {
        const target = currentFolders.find((f: any) => f.name === classifications[i]);
        if (target) await setClassificationSuggestion(yesItems[i], target, config);
      } else {
        noItems.push(yesItems[i]);
      }
    }
  }

  // 處理無匹配（建立新資料夾）
  if (noItems.length > 0) {
    const noContents = noItems.map((item: any) => {
      const name = item.name || item.aiTitle || '';
      const body = processItemContent(item, false, false);
      return `${item.id}, ${`${name} ${body}`.trim().substring(0, 200)}`;
    });

    const userDemand = i18n.t('aiNewFolderPrompt');
    const { classifications: newClassifications, classification_noteIDs, classification_description } =
      await noteSubClassify(noContents, '', '', userDemand, signal, { isPassive: true });

    const processedIds = new Set<string>();
    const cleaned: { name: string; ids: string[]; description: string }[] = [];

    for (let i = 0; i < newClassifications.length; i++) {
      const ids = (classification_noteIDs[i] || []).filter((id: string) => {
        if (processedIds.has(id)) return false;
        processedIds.add(id);
        return true;
      });
      if (ids.length > 0) {
        cleaned.push({ name: newClassifications[i], ids, description: classification_description[i] });
      }
    }

    for (const group of cleaned) {
      let targetFolderName = group.name;

      // Note 專有：群組資料夾名稱衝突
      if (config.handleGroupNameCollision) {
        const existing = (useItemStore.getState().getByType(config.folderType) as any[])
          .find((f: any) => f.name === targetFolderName);
        if (existing && config.getFolderType(existing.id).isGroup) {
          targetFolderName = await config.handleGroupNameCollision(targetFolderName, group.description, signal);
        }
      }

      let targetFolder = (useItemStore.getState().getByType(config.folderType) as any[])
        .find((f: any) => f.name === targetFolderName);

      if (!targetFolder) {
        let groupFolderId: string | null = null;
        if (config.handleGroupNameCollision) {
          const existing = (useItemStore.getState().getByType(config.folderType) as any[])
            .find((f: any) => f.name === group.name);
          if (existing && config.getFolderType(existing.id).isGroup) {
            groupFolderId = existing.id;
          }
        }

        await config.addFolder({
          name: targetFolderName,
          folderSummary: group.description,
          parentID: groupFolderId,
          isTemp: true,
        });

        targetFolder = (useItemStore.getState().getByType(config.folderType) as any[])
          .find((f: any) => f.name === targetFolderName);
      }

      for (const itemId of group.ids) {
        const item = noItems.find((it: any) => it.id === itemId);
        if (item && targetFolder) {
          await setClassificationSuggestion(item, targetFolder, config);
        }
      }
    }
  }
}
