// classify plugin — AI functions
// Each function builds a prompt locally and calls the generic promptClient.

import {
  callPrompt,
  checkAndHandleCreditsError,
  getAILanguage,
} from '../../../../aiService/promptClient';

import {
  AUTO_CLASSIFY_MULTI_SYSTEM,
  AUTO_CLASSIFY_MULTI_PROMPT,
  SINGLE_CLASSIFY_SYSTEM,
  SINGLE_CLASSIFY_PROMPT,
  NOTE_SUB_CLASSIFY_PROMPT,
  FOLDER_NAME_REGEN_PROMPT,
} from './prompts';

// ─── singleClassifyInExistingFolder ─────────────────────────────────────────
// Determines, for a single note, which existing folders it fits into.
// Returns { classifications: string[] }  e.g. ['Yes','No','Yes',...]

export const singleClassifyInExistingFolder = async (
  context: string,
  folderNames: string[],
  folderIntentions: string[],
  signal: AbortSignal | null = null,
  options: { isPassive?: boolean } = {},
) => {
  const { isPassive = false } = options;
  try {
    // Format folders the same way the server does:
    // "1. FolderName - FolderIntention"
    const formattedFolders = folderNames
      .map((name, i) => `${i + 1}. ${name} - ${folderIntentions[i]}`)
      .join('\n');

    const prompt = SINGLE_CLASSIFY_PROMPT(formattedFolders, context);

    // Abort guard
    if (signal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    const result = await callPrompt({
      action: 'classify_singleClassifyInExistingFolder',
      system_prompt: SINGLE_CLASSIFY_SYSTEM,
      prompt,
      model: 'gpt-4o-mini',
      temperature: 0.3,
      max_tokens: 256,
    });

    // Post-call abort check (matches original behaviour)
    if (signal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    // Parse: the model returns comma-separated Yes/No values.
    // Server normalised Yes→是, No→否. The client code originally received
    // the server's metadata envelope: { content: ['是','否',...] }.
    // Replicate that structure.
    const raw = result.content.trim();
    let classifications = raw.split(',').map((s: string) => s.trim());

    // Ensure length matches folder count
    while (classifications.length < folderNames.length) {
      classifications.push('No');
    }
    classifications = classifications.slice(0, folderNames.length);

    // Normalise to 是/否 (same as server)
    classifications = classifications.map((c: string) => {
      if (c === '是' || c === 'Yes') return '是';
      if (c === '否' || c === 'No') return '否';
      return '否';
    });

    return { classifications };
  } catch (error: any) {
    if (error.name === 'AbortError') {
      throw error;
    }
    console.error('判斷單個筆記是否適合各個現有資料夾時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);

    const isCreditsError = checkAndHandleCreditsError(
      error,
      isPassive,
      'singleClassifyInExistingFolder',
    );
    if (isPassive && isCreditsError) {
      return { classifications: [] };
    }

    throw error;
  }
};

// ─── autoClassifyMulti ──────────────────────────────────────────────────────
// Batch-classifies multiple notes into existing folders.
// Returns { classifications: string[] }  e.g. ['Travel','ToDo','Stocks']

export const autoClassifyMulti = async (
  contexts: string[],
  folderNames: string[],
  folderIntentions: string[],
  signal: AbortSignal | null = null,
  options: { isPassive?: boolean } = {},
) => {
  const { isPassive = false } = options;
  try {
    // Format inputs the same way the server does
    const formattedContexts = contexts
      .map((ctx, i) => `${i + 1}. ${ctx}`)
      .join('\n');
    const formattedFolderNames = folderNames
      .map((name, i) => `${i + 1}. ${name}`)
      .join('\n');
    const formattedFolderIntentions = folderIntentions
      .map((intent, i) => `${i + 1}. ${intent}`)
      .join('\n');

    const prompt = AUTO_CLASSIFY_MULTI_PROMPT(
      formattedContexts,
      formattedFolderNames,
      formattedFolderIntentions,
    );

    if (signal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    const result = await callPrompt({
      action: 'classify_autoClassifyMulti',
      system_prompt: AUTO_CLASSIFY_MULTI_SYSTEM,
      prompt,
      model: 'gpt-4.1',
      temperature: 0.3,
      max_tokens: 512,
    });

    // Parse: comma-separated folder names
    const raw = result.content.trim();
    let classifications = raw.split(',').map((s: string) => s.trim());

    // Ensure length matches contexts count (server pads with '無法分類')
    while (classifications.length < contexts.length) {
      classifications.push('無法分類');
    }
    classifications = classifications.slice(0, contexts.length);

    // Validate each classification against known folder names
    classifications = classifications.map((c: string) =>
      folderNames.includes(c) ? c : '無法分類',
    );

    return { classifications };
  } catch (error: any) {
    if (error.name === 'AbortError') {
      throw error;
    }
    console.error('自動分類多筆記時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);

    const isCreditsError = checkAndHandleCreditsError(
      error,
      isPassive,
      'autoClassifyMulti',
    );
    if (isPassive && isCreditsError) {
      return { classifications: [] };
    }

    throw error;
  }
};

// ─── noteSubClassify ────────────────────────────────────────────────────────
// Sub-classifies notes within a folder into categories.
// Returns { classifications: string[], classification_noteIDs: string[][], classification_description: string[] }

export const noteSubClassify = async (
  contents: string[],
  folderName: string,
  folderIntention: string,
  userDemand = '',
  signal: AbortSignal | null = null,
  options: { isPassive?: boolean } = {},
) => {
  const { isPassive = false } = options;
  try {
    // Join contents with separator (same as server)
    const formattedContent = contents.join('\n---\n');

    const prompt = NOTE_SUB_CLASSIFY_PROMPT(
      folderName,
      folderIntention || folderName,
      formattedContent,
      userDemand || undefined,
    );

    if (signal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    const result = await callPrompt({
      action: 'classify_noteSubClassify',
      prompt,
      model: 'gpt-4.1',
      temperature: 0.5,
      max_tokens: 4096,
    });

    // Post-call abort check
    if (signal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    // Parse: the model returns a JSON array of category objects.
    // Server strips ```json markers; we do the same.
    let cleaned = result.content;
    if (typeof cleaned === 'string') {
      cleaned = cleaned.replace('```json', '').replace('```', '').trim();
    }
    const parsed = JSON.parse(cleaned);

    const contentArray = Array.isArray(parsed) ? parsed : [parsed];

    return {
      classifications: contentArray.map(
        (item: any) => item['category_name'],
      ),
      classification_noteIDs: contentArray.map(
        (item: any) => item['noteIDs'],
      ),
      classification_description: contentArray.map(
        (item: any) => item['description'],
      ),
    };
  } catch (error: any) {
    if (error.name === 'AbortError') {
      throw error;
    }
    console.error('筆記子分類時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);

    const isCreditsError = checkAndHandleCreditsError(
      error,
      isPassive,
      'noteSubClassify',
    );
    if (isPassive && isCreditsError) {
      return {
        classifications: [],
        classification_noteIDs: [],
        classification_description: [],
      };
    }

    throw error;
  }
};

// ─── folderNameRegen ────────────────────────────────────────────────────────
// Regenerates a folder name based on intention.
// Returns { name: string }

export const folderNameRegen = async (
  intention: string,
  folder_name: string,
  suggest: string,
) => {
  try {
    const prompt = FOLDER_NAME_REGEN_PROMPT(intention, folder_name, suggest);

    const result = await callPrompt({
      action: 'classify_folderNameRegen',
      prompt,
      model: 'gpt-4.1',
      temperature: 0.5,
    });

    return { name: result.content.trim() };
  } catch (error: any) {
    console.error('資料夾名稱再生成時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'folderNameRegen');
    throw error;
  }
};
