// classify plugin — prompt templates
// Mirrors the server-side prompt.yml entries for classify-related methods.

// ─── autoClassifyMulti ──────────────────────────────────────────────────────

export const AUTO_CLASSIFY_MULTI_SYSTEM = `You are an intelligent document classifier. You need to classify multiple documents into appropriate folders based on their content and folder intentions.`;

export const AUTO_CLASSIFY_MULTI_PROMPT = (
  formattedContexts: string,
  formattedFolderNames: string,
  formattedFolderIntentions: string,
) => `Classify each note into the most appropriate existing folder based on folder names and their intents.

Available folders:
${formattedFolderNames}

Corresponding folder intents:
${formattedFolderIntentions}

Notes to classify:
${formattedContexts}

Rules:
1. Read each note carefully.
2. Choose the folder that best matches the note's topic and intent.
3. Each note must be assigned to one of the provided folders.
4. Do not create new folder names.
5. Answer in the same order as the notes.
6. Output only the folder names, separated by commas, with no extra text.

Example: ToDo, Travel, Stocks

Classification result:`;

// ─── singleClassifyInExistingFolder ─────────────────────────────────────────

export const SINGLE_CLASSIFY_SYSTEM = `You are an intelligent document classifier. You need to determine which existing folders a single document can be classified into based on its content and folder intentions.`;

export const SINGLE_CLASSIFY_PROMPT = (
  formattedFolders: string,
  context: string,
) => `For the given note, evaluate whether it fits into each listed folder.

Existing folders and intents:
${formattedFolders}

Note:
${context}

Rules:
1. For each folder, answer "Yes" if the note matches that folder's intent, otherwise answer "No".
2. Output responses in the folder order, separated by commas. Only output "Yes" or "No".

Results:`;

// ─── noteSubClassify ────────────────────────────────────────────────────────

const NOTE_SUB_CLASSIFY_DEFAULT_USER_DEMAND = `Read the folder name and description, then analyze each note's intent report.

Topic identification:
Extract each report's main theme and key concepts.

Grouping:
Cluster reports into a reasonable number of categories based on their topics.

Category names:
For each category, choose a concise representative name (ideally within 4 characters) that reflects the group's common features. Avoid names identical to the folder name.`;

const NOTE_SUB_CLASSIFY_JSON_FORMAT = `{
"category_name":"<generated category name>",
"description":"<brief description of this category>",
"noteIDs":[
  "<list of report indices belonging to this category>",
  ...
]
}`;

export const NOTE_SUB_CLASSIFY_PROMPT = (
  folderName: string,
  folderIntention: string,
  formattedContent: string,
  userDemand?: string,
) => `You are a text analysis expert tasked with categorizing the intent reports of notes inside a folder. Follow these steps:

User classification requirements:
${userDemand || NOTE_SUB_CLASSIFY_DEFAULT_USER_DEMAND}

Structured output:
Output a JSON list with entries in the following format:

${NOTE_SUB_CLASSIFY_JSON_FORMAT}

Classify each note into exactly one category and output only the JSON structure.

Folder name:
${folderName}
Folder intent:
${folderIntention}
Note intent reports:
---
${formattedContent}`;

// ─── folderNameRegen ────────────────────────────────────────────────────────

export const FOLDER_NAME_REGEN_PROMPT = (
  intention: string,
  folderName: string,
  suggest: string,
) => `Based on the three inputs below, generate a new folder name that fits the user's needs.

Inputs:
User folder intent report: ${intention}
Current folder name: ${folderName}
User request: ${suggest || 'The name must be short and natural\u2014what a typical user would choose. Reply with only the name, no extra text or suffixes like "note" or "folder".'}

New folder name:`;
