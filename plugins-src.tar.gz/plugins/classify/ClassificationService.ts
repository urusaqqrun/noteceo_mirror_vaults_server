/**
 * ClassificationService - 獨立的自動分類服務
 * 
 * 負責筆記和待辦的自動分類，不依賴 React 生命週期
 * 使用 zustand subscribe 監聽狀態變化
 */

import i18n from '../../../i18n/config';
import { useAISortStore, useTodoSortStore, useTodoClassifyHintStore, useAIGOStore, useTodoClassifyActivityStore } from './classifyStore';

import { useItemStore } from '../../../Store/itemStore';
import { useNoteStore } from '../note/noteStore';
import type { Note } from '../note/noteStore';
import { useTodoStore, type TodoFolder } from '../todo/todoStore';
import { processItemContent } from '../../../utils/textUtils';
import { useTempHintStore, useIsConnectedStore } from '../../../Store/uiStore';
import { folderNameRegen } from './ai/classifyAI';
import {
  type ClassifyPipelineConfig,
  findAndClassifyItems,
  classifyItemsPipeline,
} from './classifyUtils';

// ===== Config 工廠 =====

function buildNoteConfig(): ClassifyPipelineConfig {
  return {
    label: 'AI分類',
    folderType: 'NOTE_FOLDER',
    inboxName: 'inbox',
    excludedFolderNames: ['trash', 'inbox', 'todoInbox'],

    getFilteredItems: () => {
      const allNotes = useItemStore.getState().getByType('NOTE') as Note[];
      return useNoteStore.getState().getFilteredAndSortedItemsByFolderName(allNotes, 'inbox');
    },
    getFolderType: (id) => useNoteStore.getState().getFolderType(id),
    filterItem: (item, selectedId, isEditing) => {
      const contentStr = processItemContent(item);
      const noAudio = !item.audioURLs || item.audioURLs.length === 0;
      if (contentStr === '' && noAudio) return false;
      if (item.classificationStatus === 'UNCLASSIFIABLE') return false;
      if (item.classificationStatus === 'PAUSE') return false;
      if (item.aiFolderID) return false;
      if (Number(item.createdAt) >= Date.now() - 500) return false;
      if (item.id === selectedId && isEditing) return false;
      if (item.pinnedAt) return false;
      return true;
    },
    filterRemaining: (item) =>
      !item.aiFolderID &&
      item.classificationStatus !== 'UNCLASSIFIABLE' &&
      item.classificationStatus !== 'PAUSE',
    buildContent: (item) => {
      const plain = processItemContent(item);
      return plain.substring(0, 100);
    },

    setIsClassifying: (v) => useAIGOStore.getState().setIsClassifingNote(v),
    setClassifyIds: (ids) => useAIGOStore.getState().setAIClassifyNoteIds(ids),
    getSlideRightIds: () => useAIGOStore.getState().slideRightNoteIds,
    setSlideRightIds: (ids) => useAIGOStore.getState().setSlideRightNoteIds(ids),
    updateWithoutUpdateAt: (item) => useNoteStore.getState().updateNoteWithoutUpdateAt(item),
    addFolder: (data) => useNoteStore.getState().addNoteFolder(data),

    isSortEnabled: () => useAISortStore.getState().isAISortEnabled,
    setSortEnabled: (v) => useAISortStore.getState().setAISortEnabled(v),
    onAllClassified: () => {
      classificationService.showCompletionNotification('已分類完筆記');
    },
    onError: (error) => {
      console.error('[AI分類] 批量筆記分類失敗:', error);
      useTempHintStore.getState().setTempHint('伺服器無回應，無法分類筆記');
      useAISortStore.getState().setAISortEnabled(false);
    },
    onFinally: (signal) => {
      useAIGOStore.getState().setIsClassifingNote(false);
      useAIGOStore.getState().setAIClassifyNoteIds([]);
      if (classificationService.noteAbortController?.signal === signal) {
        classificationService.noteAbortController = null;
      }
      useAIGOStore.getState().setForceRefreshClassify(!useAIGOStore.getState().forceRefreshClassify);
    },

    handleGroupNameCollision: async (name, description, signal) => {
      try {
        const regeneratePrompt = `不能叫「${name}」，因為已經有同樣的群組資料夾名稱，您可以創建一個適合放在其下的子資料夾名稱`;
        const result = await folderNameRegen(description, name, regeneratePrompt);
        if (result?.name && result.name !== name) return result.name;
        return `${name}_筆記`;
      } catch (error) {
        console.error('[AI分類] 重新生成資料夾名稱失敗:', error);
        return `${name}_筆記`;
      }
    },
  };
}

function buildTodoConfig(): ClassifyPipelineConfig {
  return {
    label: '待辦分類',
    folderType: 'TODO_FOLDER',
    inboxName: 'todoInbox',
    excludedFolderNames: ['todoInbox'],

    getFilteredItems: () => {
      const todoInboxId = (useItemStore.getState().getByType('TODO_FOLDER') as TodoFolder[])
        .find(f => f.name === 'todoInbox')?.id;
      return useTodoStore.getState().getFilteredTodos('TODO', todoInboxId);
    },
    getFolderType: (id) => useTodoStore.getState().getFolderType(id),
    filterItem: (item, selectedId, _isEditing) => {
      const contentStr = processItemContent(item);
      if (contentStr === '' && (!item.name || item.name.trim() === '')) return false;
      if (item.classificationStatus === 'UNCLASSIFIABLE') return false;
      if (item.classificationStatus === 'PAUSE') return false;
      if (item.aiFolderID) return false;
      if (Number(item.createdAt) >= Date.now() - 500) return false;
      if (item.id === selectedId) return false;
      return true;
    },
    filterRemaining: (item) =>
      !item.aiFolderID &&
      item.classificationStatus !== 'UNCLASSIFIABLE' &&
      item.classificationStatus !== 'PAUSE',
    buildContent: (item) => {
      const plain = processItemContent(item);
      return (item.name || '') + ' ' + plain.substring(0, 100);
    },

    setIsClassifying: (v) => useTodoClassifyActivityStore.getState().setIsClassifingTodo(v),
    setClassifyIds: (ids) => useTodoClassifyActivityStore.getState().setAIClassifyTodoIds(ids),
    getSlideRightIds: () => useTodoClassifyActivityStore.getState().slideRightTodoIds,
    setSlideRightIds: (ids) => useTodoClassifyActivityStore.getState().setSlideRightTodoIds(ids),
    updateWithoutUpdateAt: (item) => useTodoStore.getState().updateTodoWithoutUpdateAt(item),
    addFolder: (data) => useTodoStore.getState().addTodoFolder(data),

    isSortEnabled: () => useTodoSortStore.getState().isTodoSortEnabled,
    setSortEnabled: (v) => useTodoSortStore.getState().setTodoSortEnabled(v),
    onAllClassified: () => {
      useTodoClassifyHintStore.getState().hideTodoClassifyHint();
      classificationService.showCompletionNotification(i18n.t('classifiedAllTodos'));
    },
    onError: (error) => {
      console.error('[待辦分類] 批量待辦分類失敗:', error);
      useTempHintStore.getState().setTempHint(i18n.t('serverNotResponding'));
      useTodoSortStore.getState().setTodoSortEnabled(false);
    },
    onFinally: (signal) => {
      useTodoClassifyActivityStore.getState().setIsClassifingTodo(false);
      useTodoClassifyActivityStore.getState().setAIClassifyTodoIds([]);
      if (classificationService.todoAbortController?.signal === signal) {
        classificationService.todoAbortController = null;
      }
      useTodoClassifyActivityStore.getState().setForceRefreshTodoClassify(
        !useTodoClassifyActivityStore.getState().forceRefreshTodoClassify,
      );
    },
  };
}

// ===== Service =====

class ClassificationService {
  noteAbortController: AbortController | null;
  todoAbortController: AbortController | null;
  unsubscribers: (() => void)[];
  batchSize: number;
  initialized: boolean;

  constructor() {
    this.noteAbortController = null;
    this.todoAbortController = null;
    this.unsubscribers = [];
    this.batchSize = 3;
    this.initialized = false;
  }

  // ===== 生命週期 =====

  init() {
    if (this.initialized) return;
    this.initialized = true;

    let prevIsAISortEnabled = useAISortStore.getState().isAISortEnabled;
    let prevForceRefreshClassify = useAIGOStore.getState().forceRefreshClassify;
    let prevIsTodoSortEnabled = useTodoSortStore.getState().isTodoSortEnabled;
    let prevForceRefreshTodoClassify = useTodoClassifyActivityStore.getState().forceRefreshTodoClassify;
    let prevIsConnected = useIsConnectedStore.getState().isConnected;

    this.unsubscribers.push(
      useAISortStore.subscribe((state) => {
        if (state.isAISortEnabled !== prevIsAISortEnabled) {
          prevIsAISortEnabled = state.isAISortEnabled;
          if (state.isAISortEnabled) this.triggerNoteClassification();
          else this.abortNoteClassification();
        }
      })
    );

    this.unsubscribers.push(
      useAIGOStore.subscribe((state) => {
        if (state.forceRefreshClassify !== prevForceRefreshClassify) {
          prevForceRefreshClassify = state.forceRefreshClassify;
          this.triggerNoteClassification();
        }
      })
    );

    this.unsubscribers.push(
      useTodoClassifyActivityStore.subscribe((state) => {
        if (state.forceRefreshTodoClassify !== prevForceRefreshTodoClassify) {
          prevForceRefreshTodoClassify = state.forceRefreshTodoClassify;
          this.triggerTodoClassification();
        }
      })
    );

    this.unsubscribers.push(
      useTodoSortStore.subscribe((state) => {
        if (state.isTodoSortEnabled !== prevIsTodoSortEnabled) {
          prevIsTodoSortEnabled = state.isTodoSortEnabled;
          if (state.isTodoSortEnabled) this.triggerTodoClassification();
          else this.abortTodoClassification();
        }
      })
    );

    this.unsubscribers.push(
      useIsConnectedStore.subscribe((state) => {
        if (state.isConnected !== prevIsConnected) {
          prevIsConnected = state.isConnected;
          if (state.isConnected) {
            this.triggerNoteClassification();
            this.triggerTodoClassification();
          }
        }
      })
    );
  }

  destroy() {
    this.unsubscribers.forEach(unsub => unsub());
    this.unsubscribers = [];
    this.abortNoteClassification();
    this.abortTodoClassification();
    this.initialized = false;
  }

  // ===== 筆記分類 =====

  triggerNoteClassification() {
    if (!useIsConnectedStore.getState().isConnected) return;
    if (!useAISortStore.getState().isAISortEnabled) return;
    if (useAIGOStore.getState().isClassifingNote) return;
    this.runClassification('note');
  }

  async abortNoteClassification() {
    if (this.noteAbortController) {
      this.noteAbortController.abort();
      this.noteAbortController = null;
    }
    const ids = useAIGOStore.getState().aiClassifyNoteIds;
    if (ids.length > 0) useAIGOStore.getState().setAIClassifyNoteIds([]);
  }

  // ===== 待辦分類 =====

  triggerTodoClassification() {
    if (!useIsConnectedStore.getState().isConnected) return;
    if (!useTodoSortStore.getState().isTodoSortEnabled) return;
    if (useTodoClassifyActivityStore.getState().isClassifingTodo) return;
    this.runClassification('todo');
  }

  async abortTodoClassification() {
    if (this.todoAbortController) {
      this.todoAbortController.abort();
      this.todoAbortController = null;
    }
    const ids = useTodoClassifyActivityStore.getState().aiClassifyTodoIds;
    if (ids.length > 0) useTodoClassifyActivityStore.getState().setAIClassifyTodoIds([]);
  }

  // ===== 公開入口（供外部 patch 呼叫）=====

  async classifyNotes(notes: any[]) {
    await this.runPipelineForItems('note', notes);
  }

  async classifyTodos(todos: any[]) {
    await this.runPipelineForItems('todo', todos);
  }

  private async runPipelineForItems(type: 'note' | 'todo', items: any[]) {
    const config = type === 'note' ? buildNoteConfig() : buildTodoConfig();
    const getController = () => type === 'note' ? this.noteAbortController : this.todoAbortController;
    const setController = (c: AbortController | null) => {
      if (type === 'note') this.noteAbortController = c;
      else this.todoAbortController = c;
    };

    if (getController()) getController()!.abort();
    const controller = new AbortController();
    setController(controller);
    const signal = controller.signal;

    config.setIsClassifying(true);
    try {
      await classifyItemsPipeline(items, signal, config);
    } catch (error: any) {
      if (error.name !== 'AbortError') config.onError(error);
    } finally {
      config.onFinally(signal);
    }
  }

  // ===== 自動觸發入口 =====

  private async runClassification(type: 'note' | 'todo') {
    const config = type === 'note' ? buildNoteConfig() : buildTodoConfig();

    const getController = () => type === 'note' ? this.noteAbortController : this.todoAbortController;
    const setController = (c: AbortController | null) => {
      if (type === 'note') this.noteAbortController = c;
      else this.todoAbortController = c;
    };

    await findAndClassifyItems(config, this.batchSize, async (items) => {
      if (getController()) getController()!.abort();
      const controller = new AbortController();
      setController(controller);
      const signal = controller.signal;

      config.setIsClassifying(true);
      try {
        await classifyItemsPipeline(items, signal, config);
      } catch (error: any) {
        if (error.name !== 'AbortError') config.onError(error);
      } finally {
        config.onFinally(signal);
      }
    });
  }

  // ===== 工具函數 =====

  showCompletionNotification(message: string) {
    if (Notification.permission === 'granted') {
      new Notification('CubeLV', { body: message, silent: false });
    } else if (Notification.permission === 'default') {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          new Notification('CubeLV', { body: message, silent: false });
        } else {
          useTempHintStore.getState().setTempHint(message);
        }
      });
    } else {
      useTempHintStore.getState().setTempHint(message);
    }
  }
}

// 單例導出 — 由 ClassifyPlugin.onload() 呼叫 init()
export const classificationService = new ClassificationService();
