import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import classifyEn from './locales/en.json';
import classifyZhHant from './locales/zh-Hant.json';
import classifyJa from './locales/ja.json';
/**
 * ClassifyPlugin — AI 分類插件
 *
 * 掛上後提供：
 * 1. registerItemFields 動態擴展 classify 相關欄位到 NOTE / NOTE_FOLDER / TODO / TODO_FOLDER
 * 2. ClassificationService（自動分類引擎）的生命週期管理
 * 3. ClassifyHint overlay 註冊
 * 4. noteStore / todoStore / sidebar 猴子補丁注入分類邏輯（位於 patches/ 目錄）
 *
 * 依賴：SidebarPlugin（硬依賴）
 * 可選依賴：NotePlugin, TodoPlugin（有就注入，沒有也能跑）
 */

import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { excludeFieldsFromVault, includeFieldsInVault } from '../../../types/item';
import { classificationService } from './ClassificationService';
import ClassifyHint from './ClassifyHint';
import NoteItem_ClassifyDecoration_patch from './patches/NoteItem_ClassifyDecoration_patch';
import TodoItem_ClassifyDecoration_patch from './patches/TodoItem_ClassifyDecoration_patch';
import { patchNoteStoreClassify } from './patches/noteStore_classify_patch';
import { patchTodoStoreClassify } from './patches/todoStore_classify_patch';
import { patchSidebarClassify } from './patches/sidebar_classify_patch';
import NoteMenuClassifyButtons from './patches/note_menu_classify_patch';
import { NoteListToolBar_ClassifyButtons_patch, TodoListTopbar_ClassifyButtons_patch } from './patches/toolbar_classify_patch';
import { TodoList_TempFolder_patch } from './patches/todolist_temp_folder_patch';
import { useNoteStore } from '../note/noteStore';
import type { Note } from '../note/noteStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import './patches/ClassifyDecoration.css';

const CLASSIFY_EXCLUDED_FIELDS = [
    'aiFolderID', 'classificationStatus', 'rejectedFolderNames',
    'isTemp', 'aiInstruction', 'aiFolderName', 'aiFolderSummary',
];

class ClassifyPlugin extends Plugin {
    private _unpatchNoteStore: (() => void) | null = null;
    private _unpatchTodoStore: (() => void) | null = null;
    private _unpatchSidebar: (() => void) | null = null;
    onload() {
        // 0. 排除 classify 欄位不推送到 vault（同 isPublic 的排除邏輯）
        excludeFieldsFromVault(CLASSIFY_EXCLUDED_FIELDS);

        // 0b. 動態擴展 classify 欄位到各 itemType schema
        this.registerItemFields('NOTE', {
            fields: {
                aiFolderID: 'string',
                classificationStatus: 'string',
                rejectedFolderNames: 'array',
            },
            defaults: {
                aiFolderID: null,
                classificationStatus: '',
                rejectedFolderNames: [],
            },
        });
        this.registerItemFields('NOTE_FOLDER', {
            fields: {
                isTemp: 'boolean',
                aiInstruction: 'string',
                aiFolderName: 'string',
                aiFolderSummary: 'string',
            },
            defaults: {
                isTemp: false,
                aiInstruction: '',
                aiFolderName: '',
                aiFolderSummary: '',
            },
        });
        this.registerItemFields('TODO', {
            fields: {
                aiFolderID: 'string',
                classificationStatus: 'string',
                rejectedFolderNames: 'array',
            },
            defaults: {
                aiFolderID: null,
                classificationStatus: '',
                rejectedFolderNames: [],
            },
        });
        this.registerItemFields('TODO_FOLDER', {
            fields: {
                isTemp: 'boolean',
                aiInstruction: 'string',
            },
            defaults: {
                isTemp: false,
                aiInstruction: '',
            },
        });

        // 1. 初始化 ClassificationService（核心分類引擎）
        classificationService.init();
        this.register(() => classificationService.destroy());

        // 2. 註冊 overlay
        this.registerOverlay('classifyHint', ClassifyHint);

        // 3. 猴子補丁 → NoteItem / TodoItem
        this.registerOverlay('NoteItem_ClassifyDecoration', NoteItem_ClassifyDecoration_patch);
        this.registerOverlay('TodoItem_ClassifyDecoration', TodoItem_ClassifyDecoration_patch);
        this.registerOverlay('NoteListToolBar_ClassifyButtons', NoteListToolBar_ClassifyButtons_patch);
        this.registerOverlay('TodoListTopbar_ClassifyButtons', TodoListTopbar_ClassifyButtons_patch);
        this.registerOverlay('TodoList_TempFolder', TodoList_TempFolder_patch);

        // 4. 猴子補丁：noteStore + todoStore + sidebar（邏輯在 patches/ 目錄）
        this._unpatchNoteStore = patchNoteStoreClassify();
        this._unpatchTodoStore = patchTodoStoreClassify();
        this._unpatchSidebar = patchSidebarClassify();
        this.registerOverlay('NoteMenu_ClassifyButtons', NoteMenuClassifyButtons);

        // 5. 鍵盤快捷鍵
        this.registerDomEvent(window, 'keydown', this.handleCtrlS);

        console.log('[ClassifyPlugin] AI 分類插件已掛載');
    }

    onunload() {
        includeFieldsInVault(CLASSIFY_EXCLUDED_FIELDS);
        this._unpatchNoteStore?.();
        this._unpatchTodoStore?.();
        this._unpatchSidebar?.();
        this._unpatchNoteStore = null;
        this._unpatchTodoStore = null;
        this._unpatchSidebar = null;
        console.log('[ClassifyPlugin] AI 分類插件已卸載');
    }

    private handleCtrlS = (event: KeyboardEvent) => {
        if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 's') return;
        const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
        const unconfirmedCount = notes.filter((n: any) => n.aiFolderID && n.aiFolderID !== '').length;
        if (unconfirmedCount === 0) return;
        const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
        const hasOpenMenu = document.querySelector('.add-menu.active') ||
            document.querySelector('.more-menu.active') ||
            document.querySelector('.right-click-menu') ||
            document.querySelector('.account-menu');
        if (hasOpenDialog || hasOpenMenu) return;
        event.preventDefault();
        const notesToUpdate = notes.filter((n: any) => n.aiFolderID && n.aiFolderID !== '');
        if (notesToUpdate.length === 0) return;
        const lastItem = useSelectedItemsStore.getState().path.at(-1);
        const activeFolderId = lastItem?.itemType?.endsWith('_FOLDER') ? lastItem.id : (lastItem?.id ?? null);
        (useNoteStore.getState() as any).acceptSuggestions(notesToUpdate, activeFolderId);
    };
}

registerPluginClass(ClassifyPlugin, '分類', {
    dependencies: ['SidebarPlugin'],
    optionalDependencies: ['NotePlugin', 'TodoPlugin'],
    descriptionKey: 'modulesClassifyDesc',
    setupI18n: () => registerPluginLocales('ClassifyPlugin', { 'en': classifyEn, 'zh-Hant': classifyZhHant, 'ja': classifyJa }),
});
