import { create } from 'zustand';

// =====================================================
// 分類功能共用狀態
// 
// 此檔案只包含「純狀態」，不依賴任何 plugin store
// note/todo/classify 插件都可以 import 此檔案
// 副作用邏輯（如呼叫 noteStore）由 classify 插件負責
// =====================================================

// ===== 快速分類開關 =====

// 筆記快速分類（原 ai-commander/aiStore.ts → useAISortStore）
interface AISortState {
    isAISortEnabled: boolean;
    toggleAISort: () => Promise<void>;
    setAISortEnabled: (newValue: boolean) => void;
}

export const useAISortStore = create<AISortState>((set) => ({
    isAISortEnabled: false,
    toggleAISort: async () => {
        set((state) => {
            const newValue = !state.isAISortEnabled;
            return { isAISortEnabled: newValue };
        });
    },
    setAISortEnabled: (newValue) => {
        set({ isAISortEnabled: newValue });
    },
}));

// 待辦快速分類（原 ai-commander/aiStore.ts → useTodoSortStore）
interface TodoSortState {
    isTodoSortEnabled: boolean;
    toggleTodoSort: () => Promise<void>;
    setTodoSortEnabled: (newValue: boolean) => void;
}

export const useTodoSortStore = create<TodoSortState>((set) => ({
    isTodoSortEnabled: false,
    toggleTodoSort: async () => {
        set((state) => {
            const newValue = !state.isTodoSortEnabled;
            return { isTodoSortEnabled: newValue };
        });
    },
    setTodoSortEnabled: (newValue) => {
        set({ isTodoSortEnabled: newValue });
    },
}));

// ===== 分類提示 UI 狀態 =====

// 筆記分類提示（原 ai-commander/aiStore.ts → useClassifyHintStore）
interface ClassifyHintState {
    showClassifyHint: boolean;
    isPaused: boolean;
    setShowClassifyHint: (show: boolean) => void;
    setIsPaused: (paused: boolean) => void;
    hideClassifyHint: () => void;
}

export const useClassifyHintStore = create<ClassifyHintState>((set) => ({
    showClassifyHint: false,
    isPaused: false,
    setShowClassifyHint: (show) => set({ showClassifyHint: show }),
    setIsPaused: (paused) => set({ isPaused: paused }),
    hideClassifyHint: () => set({ showClassifyHint: false, isPaused: false })
}));

// 待辦分類提示（原 ai-commander/aiStore.ts → useTodoClassifyHintStore）
interface TodoClassifyHintState {
    showTodoClassifyHint: boolean;
    isTodoPaused: boolean;
    setShowTodoClassifyHint: (show: boolean) => void;
    setIsTodoPaused: (paused: boolean) => void;
    hideTodoClassifyHint: () => void;
}

export const useTodoClassifyHintStore = create<TodoClassifyHintState>((set) => ({
    showTodoClassifyHint: false,
    isTodoPaused: false,
    setShowTodoClassifyHint: (show) => set({ showTodoClassifyHint: show }),
    setIsTodoPaused: (paused) => set({ isTodoPaused: paused }),
    hideTodoClassifyHint: () => set({ showTodoClassifyHint: false, isTodoPaused: false })
}));

// ===== 筆記分類活動狀態 =====

// （原 note/noteClassifyStore.ts → useAIGOStore）
// 注意：setSlideRightNoteIds 的副作用（呼叫 noteStore.setFilteredNotes）
// 由 classify 插件的 subscription 負責處理
interface AIGOState {
    isClassifingNote: boolean;
    generatingSummaryFolderIds: string[];
    refreshingFolderNameIds: string[];
    aiClassifyNoteIds: string[];
    slideRightNoteIds: string[];
    forceRefreshClassify: boolean;
    setIsClassifingNote: (v: boolean) => void;
    addGeneratingSummaryFolder: (folderId: string) => void;
    removeGeneratingSummaryFolder: (folderId: string) => void;
    addRefreshingFolderName: (folderId: string) => void;
    removeRefreshingFolderName: (folderId: string) => void;
    setAIClassifyNoteIds: (ids: string[]) => void;
    setSlideRightNoteIds: (ids: string[]) => void;
    setForceRefreshClassify: (v: boolean | ((prev: boolean) => boolean)) => void;
}

export const useAIGOStore = create<AIGOState>((set) => ({
    isClassifingNote: false,
    generatingSummaryFolderIds: [],
    refreshingFolderNameIds: [],
    aiClassifyNoteIds: [],
    slideRightNoteIds: [],
    forceRefreshClassify: false,
    setIsClassifingNote: (isClassifingNote) => set({ isClassifingNote }),
    addGeneratingSummaryFolder: (folderId) => set((state) => {
        if (!folderId || state.generatingSummaryFolderIds.includes(folderId)) return {};
        return { generatingSummaryFolderIds: [...state.generatingSummaryFolderIds, folderId] };
    }),
    removeGeneratingSummaryFolder: (folderId) => set((state) => ({
        generatingSummaryFolderIds: state.generatingSummaryFolderIds.filter(id => id !== folderId)
    })),
    addRefreshingFolderName: (folderId) => set((state) => {
        if (!folderId || state.refreshingFolderNameIds.includes(folderId)) return {};
        return { refreshingFolderNameIds: [...state.refreshingFolderNameIds, folderId] };
    }),
    removeRefreshingFolderName: (folderId) => set((state) => ({
        refreshingFolderNameIds: state.refreshingFolderNameIds.filter(id => id !== folderId)
    })),
    setAIClassifyNoteIds: (aiClassifyNoteIds) => set({ aiClassifyNoteIds }),
    setSlideRightNoteIds: (slideRightNoteIds) => {
        set({ slideRightNoteIds });
        // 副作用（呼叫 noteStore.setFilteredNotes）由 classify 插件的 subscription 負責
    },
    setForceRefreshClassify: (value) => {
        if (typeof value === 'function') set((state: any) => ({ forceRefreshClassify: value(state.forceRefreshClassify) }));
        else set({ forceRefreshClassify: value });
    },
}));

// ===== 待辦分類活動狀態 =====

// （原 todo/todoClassifyStore.ts → useTodoClassifyActivityStore）
interface TodoClassifyActivityState {
    isClassifingTodo: boolean;
    aiClassifyTodoIds: string[];
    slideRightTodoIds: string[];
    forceRefreshTodoClassify: boolean;
    setIsClassifingTodo: (v: boolean) => void;
    setAIClassifyTodoIds: (ids: string[]) => void;
    setSlideRightTodoIds: (ids: string[]) => void;
    setForceRefreshTodoClassify: (v: boolean | ((prev: boolean) => boolean)) => void;
}

export const useTodoClassifyActivityStore = create<TodoClassifyActivityState>((set) => ({
    isClassifingTodo: false,
    aiClassifyTodoIds: [],
    slideRightTodoIds: [],
    forceRefreshTodoClassify: false,
    setIsClassifingTodo: (isClassifingTodo) => set({ isClassifingTodo }),
    setAIClassifyTodoIds: (aiClassifyTodoIds) => set({ aiClassifyTodoIds }),
    setSlideRightTodoIds: (slideRightTodoIds) => {
        set({ slideRightTodoIds });
    },
    setForceRefreshTodoClassify: (value) => {
        if (typeof value === 'function') set((state: any) => ({ forceRefreshTodoClassify: value(state.forceRefreshTodoClassify) }));
        else set({ forceRefreshTodoClassify: value });
    },
}));
