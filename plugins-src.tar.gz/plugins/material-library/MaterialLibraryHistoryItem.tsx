import React from 'react';
import { useTranslation } from 'react-i18next';
import './MaterialLibrary.css';

const MaterialLibraryHistoryItem = ({ text, isActive, onClick, onContextMenu, placeholder }) => {
  const { t } = useTranslation();
  // 去除 HTML 標籤的函數
  const stripHtmlTags = (html) => {
    if (!html) return '';
    // 創建一個臨時的 div 元素來解析 HTML
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    // 返回純文字內容
    return tempDiv.textContent || tempDiv.innerText || '';
  };

  // 去除標籤後的文字
  const cleanText = stripHtmlTags(text);
  const displayText = cleanText || placeholder || t('newItem');

  return (
    <div
      className={`material-item ${isActive ? 'active' : ''}`}
      onClick={onClick}
      onContextMenu={onContextMenu}
      title={cleanText} // 懸停時顯示完整的純文字
    >
      <span className="material-item-text">{displayText}</span>
    </div>
  );
};

export default MaterialLibraryHistoryItem; 
