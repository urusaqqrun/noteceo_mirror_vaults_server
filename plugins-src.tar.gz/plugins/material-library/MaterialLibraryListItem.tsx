import React, { useCallback, useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useMaterialModeStore } from '../editor/editorStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import type { Note } from '../note/noteStore';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';

const MaterialLibraryListItem = ({ noteId }) => {
  const { t } = useTranslation();
  const materialID = useMaterialModeStore(state => state.materialID);
  const setMaterialID = useMaterialModeStore(state => state.setMaterialID);
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);

  // 透過 selector 取得最新 note 物件，只有當 noteId 對應的物件內容改變時才重新渲染
  const noteState = useItemStore(useCallback(state => (state.byType['NOTE'] ?? []).find((n: any) => n.id === noteId), [noteId])) as Note | undefined;
  const [note, setNote] = useState(noteState);
  const [contextMenu, setContextMenu] = useState(null);

  useEffect(() => {
    setNote(noteState);
  }, [noteState]);

  useEffect(() => {
    if (contextMenu) {
      const handleClick = () => setContextMenu(null);
      window.addEventListener('click', handleClick);
      // 當其他素材開啟選單時，關閉本選單
      const handleExternalClose = () => setContextMenu(null);
      window.addEventListener('close-material-context-menu', handleExternalClose);
      return () => window.removeEventListener('click', handleClick);
    }
  }, [contextMenu]);

  // 監聽全域事件以關閉選單（在未開啟時仍需掛載監聽）
  useEffect(() => {
    const handleExternalClose = () => setContextMenu(null);
    window.addEventListener('close-material-context-menu', handleExternalClose);
    return () => window.removeEventListener('close-material-context-menu', handleExternalClose);
  }, []);

  // 解析圖片URLs - 優先顯示遠端圖片，如果沒有則顯示本地圖片，但必須確保URL在筆記內容中存在
  const getFirstImageUrl = () => {
    // 先檢查遠端圖片，遍歷所有URL直到找到存在於內容中的
    if ((note as any)?.imgURLs && Array.isArray((note as any).imgURLs) && (note as any).imgURLs.length > 0) {
      for (const url of (note as any).imgURLs) {
        if ((note as any)?.content && note.content.includes(url)) {
          return url;
        }
      }
    }

    // 如果遠端圖片都沒找到，檢查本地圖片，遍歷所有URL直到找到存在於內容中的
    if ((note as any)?.imageUrl_local && Array.isArray((note as any).imageUrl_local) && (note as any).imageUrl_local.length > 0) {
      for (const url of (note as any).imageUrl_local) {
        if ((note as any)?.content && note.content.includes(url)) {
          return url;
        }
      }
    }

    // 如果都沒有圖片，檢查 websiteContent 中的 imageUrl
    if ((note as any)?.websiteContent) {
      try {
        const websiteLinks = JSON.parse(note.websiteContent);
        if (websiteLinks.length > 0 && websiteLinks[0].imageUrl) {
          return websiteLinks[0].imageUrl;
        }
      } catch (error) {
        console.error('解析 websiteContent 失敗:', error);
      }
    }

    return null;
  };

  // 獲取要顯示的文字（優先順序：name > aiTitle > content > 顯示圖片 > '新素材'）
  const getDisplayContent = (note) => {
    if (note.name) return { type: 'text', content: note.name };
    if (note.aiTitle) return { type: 'text', content: note.aiTitle };
    if (note.content && note.content.trim().length > 0) {
      // 從 content 中移除 HTML 標籤，現在支援4行文字，可以顯示更多內容
      const plainContent = note.content.replace(/<[^>]+>/g, '').trim();

      if (plainContent.length > 0) {
        return { type: 'text', content: plainContent };
      }
    }
    const firstImageUrl = getFirstImageUrl();
    if (firstImageUrl) return { type: 'image', content: firstImageUrl };
    return { type: 'text', content: t('newMaterial') };
  };

  const handleContextMenu = (event) => {
    event.preventDefault();
    event.stopPropagation();

    // 先通知其他列表項關閉選單
    window.dispatchEvent(new Event('close-material-context-menu'));

    // 获取当前缩放比例
    const computedScale = getComputedStyle(document.documentElement)
      .getPropertyValue('--content-scale')
      .trim();
    const SCALE = parseFloat(computedScale) || 1;

    // 将点击位置转换为未缩放的坐标
    const unscaledX = event.pageX / SCALE;
    const unscaledY = event.pageY / SCALE;

    setContextMenu({
      x: unscaledX,
      y: unscaledY
    });
  };

  const handleDeleteMaterial = async () => {
    if (!lastSelected) return;

    const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
    const selectedNote = notes.find(note => note.id === lastSelected.id);

    if (!selectedNote) return;

    // 從 mergedMaterials 中移除
    selectedNote.mergedMaterials = selectedNote.mergedMaterials.filter(id => id !== noteId);
    await useItemStore.getState().upsertItem({ ...selectedNote, itemType: 'NOTE' }, { needSync: true });

    // 刪除筆記
    await useItemStore.getState().removeItems([noteId], { needSync: true });

    // 關閉素材模式
    useMaterialModeStore.getState().setisMaterialMode(false);
  };

  const handleCopyMaterial = async () => {
    if (!lastSelected) return;
    const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
    const selectedNote = notes.find(n => n.id === lastSelected.id);
    const materialNote = notes.find(n => n.id === noteId);
    if (!selectedNote || !materialNote) return;

    const now = Date.now();
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const currentUser = (window as any).auth?.currentUser;
    const memberID = userData?.ID || (currentUser ? currentUser.uid : 'DataProviderDefault');
    const parentID = useSelectedItemsStore.getState().selectedFolderId;

    const newNote = {
      ...materialNote,
      id: generateObjectID(),
      itemType: 'NOTE',
      memberID,
      parentID,
      updatedAt: now,
      createdAt: now,
      preFolderID: undefined,
      mergedMaterials: []
    };

    await useItemStore.getState().upsertItem(newNote, { needSync: true });
    useSelectedItemsStore.getState().setSelectedItems([newNote], { scrollToFocusItem: true, highlightItemId: newNote.id });

    // 關閉素材模式
    useMaterialModeStore.getState().setisMaterialMode(false);
  };

  if (!note) return null;

  const displayContent = getDisplayContent(note);

  return (
    <>
      <div
        className={`material-item ${materialID === noteId ? 'active' : ''}`}
        onClick={() => setMaterialID(noteId)}
        onContextMenu={handleContextMenu}
      >
        {displayContent.type === 'image' ? (
          <img src={displayContent.content} alt={t('materialPreview')} />
        ) : (
          <span className="material-item-text">{displayContent.content}</span>
        )}
      </div>

      {contextMenu && (
        <PopupMenu x={contextMenu.x} y={contextMenu.y} onClose={() => setContextMenu(null)}>
          <PopupMenuItem onClick={() => { handleCopyMaterial(); setContextMenu(null); }}>
            {t('copyToCurrentNotebook')}
          </PopupMenuItem>
          <PopupMenuItem onClick={() => { handleDeleteMaterial(); setContextMenu(null); }}>
            {t('deleteMaterial')}
          </PopupMenuItem>
        </PopupMenu>
      )}
    </>
  );
};

export default React.memo(MaterialLibraryListItem, (prev, next) => {
  return prev.noteId === next.noteId;
}); 
