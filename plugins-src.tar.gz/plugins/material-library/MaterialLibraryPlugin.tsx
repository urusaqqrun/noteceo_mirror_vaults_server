// ===== MaterialLibraryPlugin — MaterialLibrary 插件 =====
//
// 啟用時：隱藏 leftPane（sidebar）、替換 centerPane1（note-list → material-library）
// 關閉時：還原 leftPane（sidebar）、還原 centerPane1（note-list）

import React from 'react';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import materialLibraryEn from './locales/en.json';
import materialLibraryZhHant from './locales/zh-Hant.json';
import materialLibraryJa from './locales/ja.json';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import MaterialLibrary from './MaterialLibrary';
import { useMaterialModeStore } from '../editor/editorStore';

class MaterialLibraryView extends ReactView {
    getViewType() { return 'material-library'; }
    getDisplayText() { return '素材庫'; }
    renderComponent() { return <MaterialLibrary />; }
}

export class MaterialLibraryPlugin extends Plugin {
    private _wasOpen = false;
    private _savedSidebarSize = 200;
    private _savedNoteListSize = 350;

    onload() {
        this.registerView('material-library', (leaf) => new MaterialLibraryView(leaf));

        this.register(useMaterialModeStore.subscribe((state) => {
            const isOpen = state.showMaterialLibrary;
            if (isOpen === this._wasOpen) return;
            this._wasOpen = isOpen;

            if (isOpen) {
                this.mountMaterialLibrary();
            } else {
                this.unmountMaterialLibrary();
            }
        }));
    }

    private mountMaterialLibrary() {
        const ws = this.workspace;

        const sidebarLeaf = ws.getLeafById('leaf-sidebar') as any;
        const noteListLeaf = ws.getLeafById('leaf-notelist') as any;
        if (sidebarLeaf?.sizeValue) this._savedSidebarSize = sidebarLeaf.sizeValue;
        if (noteListLeaf?.sizeValue) this._savedNoteListSize = noteListLeaf.sizeValue;

        const combinedSize = this._savedSidebarSize + this._savedNoteListSize;

        ws.skipTransition = true;
        this.clearPane('leftPane');
        this.ensureLeafInPane('centerPane1', 'leaf-materiallibrary', 'material-library', {
            size: combinedSize, minSize: 300,
        });
        ws.trigger('layout-change');
        requestAnimationFrame(() => { ws.skipTransition = false; });
    }

    private unmountMaterialLibrary() {
        const ws = this.workspace;
        ws.skipTransition = true;
        this.ensureLeafInPane('centerPane1', 'leaf-notelist', 'note-list', {
            size: this._savedNoteListSize, minSize: 240,
        });
        this.ensureLeafInPane('leftPane', 'leaf-sidebar', 'sidebar', {
            size: this._savedSidebarSize, minSize: 160,
        });
        ws.trigger('layout-change');
        requestAnimationFrame(() => { ws.skipTransition = false; });
    }
}

registerPluginClass(MaterialLibraryPlugin, '素材庫', {
    dependencies: ['NotePlugin'],
    alwaysLoaded: true,
    descriptionKey: 'modulesMaterialLibraryDesc',
    setupI18n: () => registerPluginLocales('MaterialLibraryPlugin', { 'en': materialLibraryEn, 'zh-Hant': materialLibraryZhHant, 'ja': materialLibraryJa }),
});
