import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useEditor, EditorContent } from '@tiptap/react';
import { Extension } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import { Placeholder } from '@tiptap/extension-placeholder';
import { TaskList } from '@tiptap/extension-task-list';
import { TaskItem } from '@tiptap/extension-task-item';
import { Underline } from '@tiptap/extension-underline';
import { Highlight } from '@tiptap/extension-highlight';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import { MarkdownClipboard } from '../editor/extensions/MarkdownClipboard';
import { CodeBlockCopy } from '../editor/extensions/CodeBlockCopy';
import { ImageExtension } from '../editor/extensions/ImageExtension';
import { Dropcursor } from '@tiptap/extension-dropcursor';
import { Link } from '@tiptap/extension-link';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableHeader } from '@tiptap/extension-table-header';
import { TableCell } from '@tiptap/extension-table-cell';
import { IndentExtension } from '../editor/extensions/IndentExtension';
import { DragHandleExtension } from '../editor/extensions/DragHandleExtension';
import { TableDragHandleExtension } from '../editor/extensions/TableDragHandleExtension';
import { CustomKeyboardShortcuts } from '../editor/extensions/CustomKeyboardShortcuts';
import WebPreviewDecoration from '../editor/extensions/WebPreviewDecoration';
import '../editor/NoteEditor.css';

const MiniEditor = ({
  content = '',
  onChange,
  onBlur,
  disabled = false
}) => {
  const { t } = useTranslation();

  const editor = useEditor({
    extensions: [
      Extension.create({
        name: 'customAttributes',
        addGlobalAttributes() {
          return [
            {
              types: ['paragraph', 'listItem', 'taskItem'],
              attributes: {
                tempId: {
                  default: null,
                  parseHTML: element => element.getAttribute('data-temp-id'),
                  renderHTML: attributes => {
                    if (!attributes.tempId) return {};
                    return {
                      'data-temp-id': attributes.tempId,
                    };
                  },
                },
              },
            },
          ];
        },
      }),
      StarterKit.configure({
        paragraph: {
          draggable: false,
        },
        history: {
          depth: 100,
          newGroupDelay: 300
        },
        bulletList: {
          keepMarks: true,
          keepAttributes: true,
          HTMLAttributes: {
            class: 'bullet-list'
          }
        },
        orderedList: {
          keepMarks: true,
          keepAttributes: true,
          HTMLAttributes: {
            class: 'ordered-list'
          }
        },
        heading: {
          levels: [1, 2, 3]
        },
        dropcursor: false,
        gapcursor: false,
      } as any),
      Placeholder.configure({
        placeholder: t('resultPlaceholder')
      }),
      TaskList.configure({
        excludes: ['bulletList', 'orderedList'],
        HTMLAttributes: {
          class: 'task-list'
        }
      } as any),
      TaskItem.configure({
        nested: true,
      }),
      MarkdownClipboard.configure({
        // 如果需要的話可以添加配置選項
      }),
      CodeBlockCopy,
      CustomKeyboardShortcuts,
      Underline.configure({}),
      Highlight.configure({
        multicolor: false,
        HTMLAttributes: {
          class: 'highlight-text'
        }
      }),
      TextStyle,
      Color,
      DragHandleExtension,
      TableDragHandleExtension,
      ImageExtension.configure({
        isMaterialMode: true
      } as any),
      Dropcursor.configure({
        color: 'var(--primary)',
        width: 1.5,
      }),
      Link.configure({
        HTMLAttributes: {
          class: 'editor-link',
          rel: 'noopener noreferrer',
          target: '_blank',
        },
        validate: href => {
          return /^https?:\/\//.test(href) ||
            href.startsWith('CubeLV://note/') || href.startsWith('cubelv://note/') ||
            href.startsWith('CubeLV://todo/') || href.startsWith('cubelv://todo/') ||
            href.startsWith('CubeLV://card/') || href.startsWith('cubelv://card/') ||
            href.startsWith('CubeLV://chart/') || href.startsWith('cubelv://chart/');
        },
        protocols: ['http', 'https', 'mailto', 'tel', 'cubelv'],
        autolink: false,
        openOnClick: false,
        linkOnPaste: true,
      }),
      Table.configure({
        resizable: true,
      }),
      TableRow,
      TableHeader,
      TableCell,
      IndentExtension,
      WebPreviewDecoration.configure({ getWebsiteLinks: () => [] }),
    ],
    content: content || '',
    editable: !disabled,
    // 性能優化：不在每次事務時重渲染 React 組件
    shouldRerenderOnTransaction: false,
    onUpdate: ({ editor }) => {
      const html = editor.getHTML();
      if (onChange) {
        onChange(html);
      }
    },
    onBlur: ({ editor }) => {
      if (onBlur) {
        onBlur();
      }
    },
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none mini-editor'
      }
    }
  }, []);

  // 當 content 從外部改變時更新編輯器
  useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      // 如果內容為空字符串，清空編輯器
      if (content === '') {
        editor.commands.clearContent();
      } else {
        editor.commands.setContent(content);
      }
    }
  }, [content, editor]);

  // 當 disabled 狀態改變時更新編輯器
  useEffect(() => {
    if (editor) {
      editor.setEditable(!disabled);
    }
  }, [disabled, editor]);

  if (!editor) {
    return <div className="mini-editor-loading">{t('loadingEditor')}</div>;
  }

  return (
    <div className={`mini-editor-container ${disabled ? 'disabled' : ''}`}>
      <EditorContent editor={editor} />
    </div>
  );
};

export default MiniEditor; 
