import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import './MaterialLibrary.css';
import { useCommandManager } from '../../../Store/commandManager';
import { CustomToolbar } from '../../common/CustomToolbar';
import { useMaterialModeStore } from '../editor/editorStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import type { Note } from '../note/noteStore';
import { useItemStore } from '../../../Store/itemStore';
import { eventBus } from '../../../Store/eventBus';
import NoteEditor from '../editor/NoteEditor';
import MaterialLibraryListItem from './MaterialLibraryListItem';
import MaterialLibraryHistoryItem from './MaterialLibraryHistoryItem';
import AddIcon from '../../../assets/bk_icon_add_line_20_n.svg?react';
import MinifyIcon from '../../../assets/icon_minify_topleft_24.svg?react';
import CloseIcon from '../../../assets/icon_close_24.svg?react';
import ArrowDownIcon from '../../../assets/icon_arrow_top_to_bottom_24.svg?react';
import ArrowRightIcon from '../../../assets/icon_arrow_bottom_to_right_24.svg?react';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import { rewriteParagraph } from '../../../aiService/promptClient';
import MiniEditor from './MiniEditor';
import { useIsMobileView } from '../../../hooks/useWindowSize';

// context menu 初始狀態
const initHistoryMenu = { show: false, x: 0, y: 0, listType: '', index: -1 };

const AI_COMMANDER_ID = '__ai_commander__';

async function getAICommander() {
  const item = await window.electronAPI.getItem(AI_COMMANDER_ID);
  if (!item) return { id: '1', aiRewriteCommands: [], aiRewriteResults: [] };
  return item;
}

async function updateAICommander(data: any) {
  await window.electronAPI.updateItem({
    id: AI_COMMANDER_ID,
    itemType: 'AI_COMMANDER',
    ...data,
  });
}

const MaterialLibrary = () => {

  const { t } = useTranslation();
  const isMobileView = useIsMobileView();

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const [mergedMaterialNotes, setMergedMaterialNotes] = useState([]);
  const [mergedMaterialNotesLength, setMergedMaterialNotesLength] = useState(0);
  const [imageText, setImageText] = useState(''); // 圖片文字模式的文字內容
  const [contextMenu, setContextMenu] = useState({ show: false, x: 0, y: 0, hasSelection: false });
  const [aiCommands, setAiCommands] = useState([]); // AI重寫指令歷史
  const [aiResults, setAiResults] = useState([]); // AI重寫結果歷史
  const [isGenerating, setIsGenerating] = useState(false);
  const [historyMenu, setHistoryMenu] = useState(initHistoryMenu);
  const [selectedCommandIndex, setSelectedCommandIndex] = useState(-1); // 選中的指令索引
  const [selectedResultIndex, setSelectedResultIndex] = useState(-1); // 選中的結果索引
  const keepImageModeOpen = useMaterialModeStore(state => state.keepImageModeOpen);
  const isMaterialMode = useMaterialModeStore(state => state.isMaterialMode);
  const isImageTextMode = useMaterialModeStore(state => state.isImageTextMode);
  const isAIRewriteMode = useMaterialModeStore(state => state.isAIRewriteMode);
  const isViewSharedNoteMode = useMaterialModeStore(state => state.isViewSharedNoteMode);
  const viewSharedNoteId = useMaterialModeStore(state => state.viewSharedNoteId);
  const selectedImageSrc = useMaterialModeStore(state => state.selectedImageSrc);
  const setMaterialID = useMaterialModeStore(state => state.setMaterialID);
  const setisMaterialMode = useMaterialModeStore(state => state.setisMaterialMode);
  const setisImageTextMode = useMaterialModeStore(state => state.setisImageTextMode);
  const setisAIRewriteMode = useMaterialModeStore(state => state.setisAIRewriteMode);
  const setisViewSharedNoteMode = useMaterialModeStore(state => state.setisViewSharedNoteMode);
  const setKeepImageModeOpen = useMaterialModeStore(state => state.setKeepImageModeOpen);
  const materialID = useMaterialModeStore(state => state.materialID);
  const lastAISelectionRef = useRef(null);

  // 去除 HTML 標籤並回傳純文字
  const stripHtmlTags = (html) => {
    if (!html) return '';
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = html;
    return tempDiv.textContent || tempDiv.innerText || '';
  };

  const isHtmlEmpty = (html) => stripHtmlTags(html).trim() === '';


  // 使用 useEffect 處理 mergedMaterials
  useEffect(() => {
    const selectedNoteId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
    if (!selectedNoteId) {
      setMergedMaterialNotes([]);
      return;
    }
    const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
    const selectedNote = notes.find(note => note.id === selectedNoteId);
    if (!selectedNote?.mergedMaterials?.length) {
      setMergedMaterialNotes([]);
      setMaterialID(null);
      return;
    }

    // 只取沒有 mergedMaterials 的素材
    const materialNotes = selectedNote.mergedMaterials
      .map(id => notes.find(note => note.id === id))
      .filter(note => note && !(note as any)?.mergedMaterials?.length);
    setMergedMaterialNotes(materialNotes);
    if (materialNotes.length > 0) {
      safeSetTimeout(() => {
        setMaterialID(materialNotes[0].id);
      }, 0);
    } else {
      setMaterialID(null);
    }
  }, [isMaterialMode, mergedMaterialNotesLength]);

  useEffect(() => {
    if (mergedMaterialNotes?.length > 0) {
      setMergedMaterialNotesLength(mergedMaterialNotes.length);
    }
  }, [mergedMaterialNotes]);

  // 監聽選中的圖片變化，獲取對應的圖片文字
  useEffect(() => {
    if ((isImageTextMode || keepImageModeOpen) && selectedImageSrc) {
      const selectedNoteId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
      if (selectedNoteId) {
        const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
        const selectedNote = notes.find(note => note.id === selectedNoteId);

        if (selectedNote?.imgURLs && selectedNote?.imgTexts) {
          // 找到圖片 URL 在陣列中的索引
          const imageIndex = selectedNote.imgURLs.findIndex(url => url === selectedImageSrc);

          if (imageIndex >= 0 && imageIndex < selectedNote.imgTexts.length) {
            const imgText = selectedNote.imgTexts[imageIndex];

            // 如果是空字串或 'imgText'，代表沒有辨識出文字，顯示空白
            if (imgText === '' || imgText === 'imgText') {
              setImageText('');
            } else {
              setImageText(imgText);
            }
          } else {

            setImageText('');
          }
        } else {

          // setImageText('');
        }
      } else {

        // setImageText('');
      }
    } else if (!(isImageTextMode || keepImageModeOpen)) {
      // 關閉圖片文字模式時清空文字

      setImageText('');
    } else {
      // isImageTextMode 為 true 但沒有 selectedImageSrc

      // setImageText('');
    }
  }, [isImageTextMode, keepImageModeOpen, selectedImageSrc]);


  // 載入 AI 指令數據
  useEffect(() => {
    if (isAIRewriteMode) {
      const loadAICommander = async () => {
        try {
          const aiCommander = await getAICommander();
          let commands = aiCommander.aiRewriteCommands || [];
          let results = aiCommander.aiRewriteResults || [];

          // 如果沒有指令，自動新建一個空的和一個'翻譯成英文'
          if (commands.length === 0) {
            commands = ['', t('translateToEnglish')];
            // 同時更新到資料庫
            await updateAICommander({
              ...aiCommander,
              aiRewriteCommands: commands
            });
            // 標記 AI Commander 需要同步
            localStorage.setItem('aiCommanderNeedUpdate', 'true');
          }

          // 如果沒有結果，自動新建一個空的
          if (results.length === 0) {
            results = [''];
            await updateAICommander({
              ...aiCommander,
              aiRewriteResults: results
            });
            // 標記 AI Commander 需要同步
            localStorage.setItem('aiCommanderNeedUpdate', 'true');
          } else {
            // 如果第一筆不是空白（需判斷 HTML 是否為空），在最前面插入空白
            if (!isHtmlEmpty(results[0])) {
              results.unshift('');
              await updateAICommander({
                ...aiCommander,
                aiRewriteResults: results
              });
              // 標記 AI Commander 需要同步
              localStorage.setItem('aiCommanderNeedUpdate', 'true');
            }
          }

          setAiCommands(commands);
          setAiResults(results);

          // 預設選中第一個
          setSelectedCommandIndex(0);
          setSelectedResultIndex(0);
        } catch (error) {
          console.error('載入 AI 指令失敗:', error);
          // 錯誤時也創建空的項目和'翻譯成英文'
          setAiCommands(['', t('translateToEnglish')]);
          setAiResults(['']);
          setSelectedCommandIndex(0);
          setSelectedResultIndex(0);
        }
      };

      loadAICommander();
    }
  }, [isAIRewriteMode]);

  const handleAddMaterial = async () => {
    const selectedNoteId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
    if (!selectedNoteId) return;

    const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
    const selectedNote = notes.find(note => note.id === selectedNoteId);

    if (!selectedNote) return;

    // 創建新的空白素材
    const newNoteId = generateObjectID();
    const newNote = {
      id: newNoteId,
      title: '',
      content: '',
      parentID: selectedNoteId,
      offsetMinutes: 0
    };
    await useItemStore.getState().upsertItem({ ...newNote, itemType: 'NOTE' }, { needSync: true });

    if (!selectedNote.mergedMaterials) {
      selectedNote.mergedMaterials = [];
    }
    selectedNote.mergedMaterials.unshift(newNoteId);
    await useItemStore.getState().upsertItem({ ...selectedNote, itemType: 'NOTE' }, { needSync: true });

    // 將新素材添加到列表的開頭
    const updatedMaterials = [newNote, ...mergedMaterialNotes];
    setMergedMaterialNotes(updatedMaterials);
    setMaterialID(newNoteId);
    // 更新
  };

  const handleAddAICommand = async () => {
    // 直接添加空的指令，讓用戶在textarea中編輯
    let updatedCommands = ['', ...aiCommands];

    // 限制最多50個指令
    if (updatedCommands.length > 50) {
      updatedCommands = updatedCommands.slice(0, 50);
    }

    setAiCommands(updatedCommands);
    setSelectedCommandIndex(0); // 選中新添加的指令

    // 標記 AI Commander 需要同步
    localStorage.setItem('aiCommanderNeedUpdate', 'true');
  };

  const handleAddAIResult = async () => {
    // 直接添加空的結果，讓用戶在textarea中編輯
    let updatedResults = ['', ...aiResults];

    // 限制最多50個結果
    if (updatedResults.length > 50) {
      updatedResults = updatedResults.slice(0, 50);
    }

    setAiResults(updatedResults);
    setSelectedResultIndex(0); // 選中新添加的結果

    // 標記 AI Commander 需要同步
    localStorage.setItem('aiCommanderNeedUpdate', 'true');
  };

  // 處理套用按鈕點擊
  const handleApply = async () => {
    if (selectedResultIndex < 0 || isHtmlEmpty(aiResults[selectedResultIndex])) {

      return;
    }

    if (!window.lastAISelectionParagraphs || window.lastAISelectionParagraphs.length === 0) {

      return;
    }

    try {

      // 1. 獲取數據
      const oldHtml = window.lastAISelectionParagraphs
        .map(paragraph => paragraph.htmlContent)
        .join('');
      const newHtml = aiResults[selectedResultIndex];
      const selectedNoteId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;

      if (!selectedNoteId) {
        return;
      }

      const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
      const selectedNote = notes.find(note => note.id === selectedNoteId);

      if (!selectedNote) {
        return;
      }

      // 2. 根據選區位置直接替換段落
      if (!window.lastAISelectionParagraphs || window.lastAISelectionParagraphs.length === 0) {
        return;
      }

      // 計算選中段落的索引範圍
      const firstIndex = Math.min(...window.lastAISelectionParagraphs.map(p => p.index));
      const lastIndex = Math.max(...window.lastAISelectionParagraphs.map(p => p.index));

      // 解析當前內容為DOM
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = selectedNote.content;
      const children = Array.from(tempDiv.children);

      // 解析新的HTML內容
      const newTempDiv = document.createElement('div');
      newTempDiv.innerHTML = newHtml;
      const newChildren = Array.from(newTempDiv.children);

      // 移除選中範圍的所有段落（從後往前移除，避免索引變化）
      for (let i = lastIndex; i >= firstIndex; i--) {
        if (children[i]) {

          children[i].remove();
        }
      }

      // 在第一個索引位置插入新內容
      if (firstIndex < tempDiv.children.length) {
        // 在現有元素前插入
        const referenceNode = tempDiv.children[firstIndex];
        newChildren.reverse().forEach(newChild => {
          tempDiv.insertBefore(newChild.cloneNode(true), referenceNode);
        });

      } else {
        // 追加到末尾
        newChildren.forEach(newChild => {
          tempDiv.appendChild(newChild.cloneNode(true));
        });

      }

      const finalContent = tempDiv.innerHTML;

      // 5. 更新筆記
      const updatedNote = {
        ...selectedNote,
        content: finalContent
      };

      await useItemStore.getState().upsertItem({ ...updatedNote, itemType: 'NOTE', updatedAt: Date.now() }, { needSync: true });

      // 4. 通知主要編輯器更新
      safeSetTimeout(() => {
        eventBus.emit('editor:force-reload');
      }, 50);

      // 等待 DOM 更新後重新計算段落索引
      safeSetTimeout(() => {
        // 獲取更新後的編輯器狀態
        const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
        const currentNote = notes.find(note => note.id === selectedNoteId);

        if (!currentNote) return;

        // 解析新的 HTML 內容為段落
        const parseHtmlToParagraphs = (html) => {
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = html;
          const paragraphs = [];

          // 遍歷所有頂層子元素
          Array.from(tempDiv.children).forEach(child => {
            if (child.tagName) {
              paragraphs.push({
                htmlContent: child.outerHTML,
                content: child.textContent || (child as HTMLElement).innerText || ''
              });
            }
          });

          // 如果沒有找到子元素，將整個內容作為一個段落
          if (paragraphs.length === 0 && html.trim()) {
            paragraphs.push({
              htmlContent: html,
              content: html.replace(/<[^>]*>/g, '')
            });
          }

          return paragraphs;
        };

        const newParagraphs = parseHtmlToParagraphs(newHtml);

        if (newParagraphs.length === 0) return;

        // 找到替換後內容在整個文檔中的位置
        // 使用原始選區的第一個段落索引作為起始位置
        const originalFirstIndex = Math.min(...window.lastAISelectionParagraphs.map(p => p.index));

        // 重新構建選區信息，從原始位置開始計算新的段落索引
        const updatedParagraphs = newParagraphs.map((paragraph, i) => ({
          ...paragraph,
          index: originalFirstIndex + i
        }));

        // 更新全局變量
        window.lastAISelectionParagraphs = updatedParagraphs;

        // 發送高亮事件
        const event = new CustomEvent('materialLibraryClick', {
          detail: {
            paragraphs: updatedParagraphs
          }
        });
        document.dispatchEvent(event);

      }, 100);
    } catch (error) {
      console.error('handleApply 套用失敗:', error);
    }
  };

  // 處理生成按鈕點擊
  const handleGenerate = async () => {
    if (isGenerating) return;
    if (selectedCommandIndex < 0 || !aiCommands[selectedCommandIndex]?.trim()) {

      return;
    }

    if (!window.lastAISelectionParagraphs || window.lastAISelectionParagraphs.length === 0) {

      return;
    }

    try {
      setIsGenerating(true);
      // 取得使用者需求（上面的文字區塊）
      const userDemand = aiCommands[selectedCommandIndex].trim();

      // 組合選中段落的 HTML 內容
      const combinedHtmlContent = window.lastAISelectionParagraphs
        .map(paragraph => paragraph.htmlContent)
        .join('');

      // 調用 rewriteParagraph API
      const result = await rewriteParagraph(combinedHtmlContent, userDemand, undefined);

      // 檢查當前選中的結果是否為空
      let updatedResults;
      let newSelectedIndex;

      if (selectedResultIndex >= 0 && isHtmlEmpty(aiResults[selectedResultIndex])) {
        // 當前片段為空，直接替換
        updatedResults = [...aiResults];
        updatedResults[selectedResultIndex] = result.content;
        newSelectedIndex = selectedResultIndex; // 保持當前選中索引
      } else {
        // 當前片段不為空，添加到結果列表的開頭
        updatedResults = [result.content, ...aiResults];
        // 限制最多50個結果
        if (updatedResults.length > 50) {
          updatedResults = updatedResults.slice(0, 50);
        }
        newSelectedIndex = 0; // 選中新生成的結果
      }

      setAiResults(updatedResults);
      setSelectedResultIndex(newSelectedIndex);

      // 同時更新到資料庫
      const currentCommander = await getAICommander();
      await updateAICommander({
        ...currentCommander,
        aiRewriteResults: updatedResults
      });

      // 標記 AI Commander 需要同步
      localStorage.setItem('aiCommanderNeedUpdate', 'true');

    } catch (error) {
      console.error('生成失敗:', error);
      // 可以在這裡添加用戶友善的錯誤提示
    } finally {
      setIsGenerating(false);
    }
  };

  const handleButtonMouseDown = (e) => {
    e.preventDefault();
  };

  // 處理 textarea 的鍵盤事件
  const handleTextareaKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
      // 攔截 Ctrl+C / Cmd+C 複製事件
      e.preventDefault();
      e.stopPropagation();
      handleCopyWithKeyboard(e.target);
    }
  };

  // 處理鍵盤複製操作
  const handleCopyWithKeyboard = async (textarea) => {
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;

      let textToCopy;
      if (start !== end) {
        // 有選取部分，複製選取的文字
        textToCopy = imageText.substring(start, end);
      } else {
        // 沒有選取，複製全部文字
        textToCopy = imageText;
      }

      await performCopy(textToCopy);
    }
  };

  // 統一的複製執行函數
  const performCopy = async (textToCopy) => {
    try {
      // 方法1：嘗試使用現代 Clipboard API 同時寫入多種格式
      if (navigator.clipboard.write) {
        // 將每一行文字包成 <p> 標籤，確保貼上 Tiptap 時能分段
        const htmlParagraphs = textToCopy
          .split('\n')
          .map(line => line === ''
            ? '<br>'
            : line
              .replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
          );
        const htmlContent = '<p>' + htmlParagraphs.join('</p><p>') + '</p>';

        const clipboardItem = new ClipboardItem({
          'text/plain': new Blob([textToCopy], { type: 'text/plain' }),
          'text/html': new Blob([`<div style="white-space: pre-wrap;">${htmlContent}</div>`], { type: 'text/html' })
        });
        await navigator.clipboard.write([clipboardItem]);

      } else {
        throw new Error('ClipboardItem 不支援');
      }
    } catch (err) {

      try {
        // 方法2：降級使用純文字 API
        await navigator.clipboard.writeText(textToCopy);

      } catch (textErr) {
        console.error('純文字複製失敗:', textErr);
        // 方法3：最終降級處理：使用舊式 API
        try {
          const textArea = document.createElement('textarea');
          textArea.value = textToCopy;
          textArea.style.whiteSpace = 'pre-wrap'; // 保持換行符和空格
          textArea.style.position = 'fixed';
          textArea.style.top = '-9999px';
          document.body.appendChild(textArea);
          textArea.focus();
          textArea.select();
          const successful = document.execCommand('copy');
          document.body.removeChild(textArea);
          if (successful) {

          } else {
            throw new Error('execCommand copy 失敗');
          }
        } catch (fallbackErr) {
          console.error('所有複製方式都失敗:', fallbackErr);
        }
      }
    }
  };

  // 處理右鍵菜單
  const handleContextMenu = (e) => {

    e.preventDefault();
    e.stopPropagation();

    // 檢查是否有選區
    const textarea = e.target;
    const hasSelection = textarea.selectionStart !== textarea.selectionEnd;

    // 获取当前缩放比例
    const computedScale = getComputedStyle(document.documentElement)
      .getPropertyValue('--content-scale')
      .trim();
    const SCALE = parseFloat(computedScale) || 1;

    // 将点击位置转换为未缩放的坐标
    const unscaledX = e.clientX / SCALE;
    const unscaledY = e.clientY / SCALE;

    setContextMenu({
      show: true,
      x: unscaledX,
      y: unscaledY,
      hasSelection: hasSelection
    });

  };

  // 隱藏右鍵菜單
  const hideContextMenu = () => {
    setContextMenu({ show: false, x: 0, y: 0, hasSelection: false });
  };

  // 處理右鍵菜單複製操作
  const handleCopy = async () => {
    const textarea = document.querySelector('.image-text-textarea') as HTMLTextAreaElement;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;

      let textToCopy;
      if (start !== end) {
        // 有選取部分，複製選取的文字
        textToCopy = imageText.substring(start, end);
      } else {
        // 沒有選取，複製全部文字
        textToCopy = imageText;
      }

      await performCopy(textToCopy);
    }
    hideContextMenu();
  };

  // 處理 textarea blur 事件，儲存變更的文字
  const handleTextareaBlur = async () => {
    if (isImageTextMode && selectedImageSrc) {
      const selectedNoteId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
      if (selectedNoteId) {
        const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
        const selectedNote = notes.find(note => note.id === selectedNoteId);

        if (selectedNote?.imgURLs && selectedNote?.imgTexts) {
          // 找到圖片 URL 在陣列中的索引
          const imageIndex = selectedNote.imgURLs.findIndex(url => url === selectedImageSrc);
          if (imageIndex >= 0 && imageIndex < selectedNote.imgTexts.length) {
            const currentImgText = selectedNote.imgTexts[imageIndex];

            // 檢查文字是否有變動
            if (currentImgText !== imageText) {
              // 更新筆記的 imgTexts
              const updatedImgTexts = [...selectedNote.imgTexts];
              updatedImgTexts[imageIndex] = imageText;

              const updatedNote = {
                ...selectedNote,
                imgTexts: updatedImgTexts
              };

              // 儲存到 store
              await useItemStore.getState().upsertItem({ ...updatedNote, itemType: 'NOTE', updatedAt: Date.now() }, { needSync: true });

            }
          }
        }
      }
    }
  };

  // Escape 關閉素材庫 — commandManager 統一管理
  useEffect(() => {
    if (!(isMaterialMode || isImageTextMode || isAIRewriteMode || isViewSharedNoteMode)) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'material-library:escape',
        name: t('cmd.closeMaterialLibrary'),
        checkCallback: (checking: boolean) => {
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          const hasOpenMenu = document.querySelector('.add-menu.active') ||
            document.querySelector('.more-menu.active') ||
            document.querySelector('.right-click-menu') ||
            document.querySelector('.account-menu');
          if (hasOpenDialog || hasOpenMenu) return false;
          if (!checking) {
            setisMaterialMode(false);
            setisImageTextMode(false);
            setisAIRewriteMode(false);
            setisViewSharedNoteMode(false);
            setKeepImageModeOpen(false);
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [isMaterialMode, isImageTextMode, isAIRewriteMode, isViewSharedNoteMode, setisMaterialMode, setisImageTextMode, setisAIRewriteMode, setisViewSharedNoteMode]);

  // 處理點擊外部隱藏右鍵菜單
  useEffect(() => {
    const handleClickOutside = (e) => {
      // 檢查點擊是否在右鍵菜單內
      const menu = document.querySelector('.image-text-context-menu');

      if (contextMenu.show && !menu?.contains(e.target)) {

        hideContextMenu();
      }
    };

    if (contextMenu.show) {
      // 延遲添加事件監聽器，避免立即觸發隱藏
      safeSetTimeout(() => {
        document.addEventListener('click', handleClickOutside);
      }, 100);
    }

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [contextMenu.show]);

  // 添加點擊處理函數
  const handleMaterialLibraryClick = (e) => {
    if (e.target.closest('.material-library')) {

      if (!window.lastAISelectionParagraphs) {
        return;
      }

      // 將所有選中段落的 HTML 內容組合起來
      const combinedHtmlContent = window.lastAISelectionParagraphs
        .map(paragraph => paragraph.htmlContent)
        .join('');

      const event = new CustomEvent('materialLibraryClick', {
        detail: {
          paragraphs: window.lastAISelectionParagraphs
        }
      });
      document.dispatchEvent(event);

      // 發送後清空
      // window.lastAISelectionParagraphs = null;
    }
  };

  // 右鍵菜單：顯示刪除
  const handleHistoryItemContextMenu = (listType, idx, e) => {
    e.preventDefault();
    e.stopPropagation();

    // 获取当前缩放比例
    const computedScale = getComputedStyle(document.documentElement)
      .getPropertyValue('--content-scale')
      .trim();
    const SCALE = parseFloat(computedScale) || 1;

    // 将点击位置转换为未缩放的坐标
    const unscaledX = e.clientX / SCALE;
    const unscaledY = e.clientY / SCALE;

    setHistoryMenu({ show: true, x: unscaledX, y: unscaledY, listType, index: idx });
  };

  const handleDeleteHistoryItem = async () => {
    const { listType, index } = historyMenu;
    if (listType === 'command') {
      const newCommands = aiCommands.filter((_, i) => i !== index);
      setAiCommands(newCommands);
      // 調整選擇索引
      setSelectedCommandIndex(prev => prev >= newCommands.length ? newCommands.length - 1 : prev);
      // 更新 DB
      try {
        const commander = await getAICommander();
        await updateAICommander({ ...commander, aiRewriteCommands: newCommands });
        // 標記 AI Commander 需要同步
        localStorage.setItem('aiCommanderNeedUpdate', 'true');
      } catch (err) { console.error('更新指令失敗', err); }
    } else if (listType === 'result') {
      const newResults = aiResults.filter((_, i) => i !== index);
      setAiResults(newResults);
      setSelectedResultIndex(prev => prev >= newResults.length ? newResults.length - 1 : prev);
      try {
        const commander = await getAICommander();
        await updateAICommander({ ...commander, aiRewriteResults: newResults });
        // 標記 AI Commander 需要同步
        localStorage.setItem('aiCommanderNeedUpdate', 'true');
      } catch (err) { console.error('更新結果失敗', err); }
    }
    setHistoryMenu(initHistoryMenu);
  };

  // 點擊空白關閉菜單
  useEffect(() => {
    const handleClick = () => historyMenu.show && setHistoryMenu(initHistoryMenu);
    if (historyMenu.show) {
      document.addEventListener('click', handleClick);
    }
    return () => document.removeEventListener('click', handleClick);
  }, [historyMenu]);

  return (
    <div
      className="material-library"
      onClick={handleMaterialLibraryClick}
    >
      <CustomToolbar
        borderBottom
        center={
          isMaterialMode ? t('materialLibrary') :
            (isImageTextMode || keepImageModeOpen) ? t('imageText') :
              isViewSharedNoteMode ? t('newVersion') :
                  t('aiRewrite')
        }
        right={{
          buttons: [{
            icon: isMobileView ? <CloseIcon /> : <MinifyIcon />,
            onClick: () => {
              setisMaterialMode(false);
              setisImageTextMode(false);
              setisAIRewriteMode(false);
              setisViewSharedNoteMode(false);
              setKeepImageModeOpen(false);
            },
          }],
        }}
      />

      {/* 按照優先順序顯示：查看分享筆記模式 > 版本紀錄模式 > 素材模式 > 圖片模式 > Rewrite模式 */}
      {isViewSharedNoteMode && viewSharedNoteId && (
        // 查看分享筆記模式：最高優先級
        <div className="material-library-content">
          <NoteEditor
            mode={'viewShared'}
            noteId={viewSharedNoteId}
            editorId="view-shared-editor"
          />
        </div>
      )}

      {!isViewSharedNoteMode && isMaterialMode && (
        // 素材模式：第三優先級
        <>
          <div className="material-library-content">
            <NoteEditor
              mode={'material'}
              noteId={materialID}
              editorId="material-editor"
            />
          </div>
          <div className="material-library-bottombar">
            <div className="material-list">
              <div className="material-add-item" onClick={handleAddMaterial}>
                <AddIcon />
              </div>
              {mergedMaterialNotes.map((note) => (
                <MaterialLibraryListItem key={note.id} noteId={note.id} />
              ))}
            </div>
          </div>
        </>
      )}

      {!isViewSharedNoteMode && !isMaterialMode && (isImageTextMode || keepImageModeOpen) && (
        // 圖片文字模式：第四優先級
        <div className="image-text-container">
          <textarea
            className="image-text-textarea"
            value={imageText}
            onChange={(e) => setImageText(e.target.value)}
            onKeyDown={handleTextareaKeyDown}
            onBlur={handleTextareaBlur}
            onFocus={() => setKeepImageModeOpen(true)}
            onContextMenu={handleContextMenu}
            placeholder={t('noImageTextPlaceholder')}
          />
        </div>
      )}

      {!isViewSharedNoteMode && !isMaterialMode && !(isImageTextMode || keepImageModeOpen) && isAIRewriteMode && (
        // AI重寫模式：分為五個區域
        <div className="ai-rewrite-container">
          {/* 1. AI指令歷史 */}
          <div className="material-library-middlebar">
            <div className="material-list">
              <div className="material-add-item" onClick={handleAddAICommand}>
                <AddIcon />
              </div>
              {aiCommands.map((command, index) => (
                <MaterialLibraryHistoryItem
                  key={index}
                  text={command}
                  placeholder={t('newCommand')}
                  isActive={selectedCommandIndex === index}
                  onClick={() => setSelectedCommandIndex(index)}
                  onContextMenu={(e) => handleHistoryItemContextMenu('command', index, e)}
                />
              ))}
            </div>
          </div>

          {/* 2. TextArea (當前AI指令) */}
          <div className="ai-rewrite-textarea-container">
            <textarea
              className="ai-rewrite-textarea original-content"
              disabled={selectedCommandIndex < 0}
              placeholder={selectedCommandIndex < 0 ? t('selectOrAddCommand') : t('commandPlaceholder')}
              value={selectedCommandIndex >= 0 ? aiCommands[selectedCommandIndex] : ''}
              onChange={(e) => {
                if (selectedCommandIndex >= 0) {
                  const newValue = e.target.value;
                  let updatedCommands = [...aiCommands];

                  // 如果當前選中的不是第一個位置，先移到最前面
                  if (selectedCommandIndex !== 0) {
                    // 移除原位置的指令
                    updatedCommands.splice(selectedCommandIndex, 1);
                    // 添加到最前面
                    updatedCommands.unshift(aiCommands[selectedCommandIndex]);
                    // 更新選中索引為0
                    setSelectedCommandIndex(0);
                    setAiCommands(updatedCommands);

                    // 然後更新第一個位置的值
                    updatedCommands[0] = newValue;
                    setAiCommands([...updatedCommands]);

                    // 將滾動位置歸零（滾動到最左邊）
                    safeSetTimeout(() => {
                      const materialList = document.querySelector('.material-library .material-list');
                      if (materialList) {
                        materialList.scrollLeft = 0;
                      }
                    }, 0);
                  } else {
                    // 如果已經在第一個位置，直接更新值
                    updatedCommands[selectedCommandIndex] = newValue;
                    setAiCommands(updatedCommands);
                  }
                }
              }}
              onBlur={async () => {
                if (selectedCommandIndex >= 0) {
                  // 保存到資料庫
                  try {
                    const currentCommander = await getAICommander();
                    await updateAICommander({
                      ...currentCommander,
                      aiRewriteCommands: aiCommands
                    });
                    // 標記 AI Commander 需要同步
                    localStorage.setItem('aiCommanderNeedUpdate', 'true');
                  } catch (error) {
                    console.error('保存 AI 指令失敗:', error);
                  }
                }
              }}
            />
          </div>

          {/* 3. btn container (高度44) */}
          <div className="ai-rewrite-btn-container">
            {(() => {
              const commandEmpty = selectedCommandIndex < 0 || !aiCommands[selectedCommandIndex]?.trim();
              return (
                <button
                  className="ai-rewrite-btn generate-btn"
                  disabled={commandEmpty}
                  style={isGenerating ? { pointerEvents: 'none' } : {}}
                  onClick={handleGenerate}
                >
                  <span className="btn-icon">
                    {isGenerating ? <span className="cssloader"></span> : <ArrowDownIcon />}
                  </span>
                  {t('generate')}
                </button>
              );
            })()}
            <button
              className="ai-rewrite-btn apply-btn"
              disabled={selectedResultIndex < 0 || isHtmlEmpty(aiResults[selectedResultIndex])}
              onClick={handleApply}
            >
              {t('apply')}
              <ArrowRightIcon />
            </button>
          </div>

          {/* 4. TextArea (當前AI結果) */}
          <div className="ai-rewrite-textarea-container">
            <MiniEditor
              content={selectedResultIndex >= 0 ? aiResults[selectedResultIndex] : ''}
              onChange={(newValue) => {
                if (selectedResultIndex >= 0) {
                  const updatedResults = [...aiResults];
                  updatedResults[selectedResultIndex] = newValue;
                  setAiResults(updatedResults);
                }
              }}
              onBlur={async () => {
                if (selectedResultIndex >= 0) {
                  // 保存到資料庫
                  try {
                    const currentCommander = await getAICommander();
                    await updateAICommander({
                      ...currentCommander,
                      aiRewriteResults: aiResults
                    });
                    // 標記 AI Commander 需要同步
                    localStorage.setItem('aiCommanderNeedUpdate', 'true');
                  } catch (error) {
                    console.error('保存 AI 結果失敗:', error);
                  }
                }
              }}
            />
          </div>

          {/* 5. AI結果歷史 */}
          <div className="material-library-middlebar">
            <div className="material-list">
              <div className="material-add-item" onClick={handleAddAIResult}>
                <AddIcon />
              </div>
              {aiResults.map((result, index) => (
                <MaterialLibraryHistoryItem
                  key={index}
                  text={result}
                  placeholder={t('newFragment')}
                  isActive={selectedResultIndex === index}
                  onClick={() => setSelectedResultIndex(index)}
                  onContextMenu={(e) => handleHistoryItemContextMenu('result', index, e)}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 右鍵菜單 */}
      {contextMenu.show && (
        <div
          className="image-text-context-menu"
          style={{
            position: 'fixed',
            left: contextMenu.x,
            top: contextMenu.y,
            zIndex: 1001
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="context-menu-item" onClick={handleCopy}>
            {contextMenu.hasSelection ? t('copySelected') : t('copyAll')}
          </div>
        </div>
      )}

      {/* 歷史項目右鍵刪除菜單 */}
      {historyMenu.show && (() => {
        const onlyOne = historyMenu.listType === 'command' ? aiCommands.length <= 1 : aiResults.length <= 1;
        return (
          <div
            className="image-text-context-menu"
            style={{ position: 'fixed', left: historyMenu.x, top: historyMenu.y, zIndex: 1001 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className={`context-menu-item ${onlyOne ? 'disabled' : ''}`}
              onClick={!onlyOne ? handleDeleteHistoryItem : undefined}
            >
              {t('delete')}
            </div>
          </div>
        );
      })()}


    </div>
  );
};

export default MaterialLibrary; 