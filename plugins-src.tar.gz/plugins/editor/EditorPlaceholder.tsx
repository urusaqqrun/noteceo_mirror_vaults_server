import React, { useEffect, useState } from 'react';

import ThemeSelector from '../../setting/ThemeSelector';
import '../../common/BasicComponents.css';
import '../../setting/SettingDialog.css';

import './EditorPlaceholder.css';

export interface ShortcutHint {
  key: string;
  desc: string;
}

interface EditorPlaceholderProps {
  shortcuts?: ShortcutHint[];
  visible?: boolean;
}

const EditorPlaceholder = ({ shortcuts = [], visible = true }: EditorPlaceholderProps) => {

  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    if (!visible) {
      setShowContent(false);
    } else {
      setShowContent(false);
      const timer = setTimeout(() => {
        setShowContent(true);
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [visible]);

  return (
    <>
      <div className={`editor-placeholder ${showContent ? 'fade-in' : 'hide'}`}>
        <ThemeSelector />
        {shortcuts.length > 0 && (
          <div className="shortcuts-hint">
            {shortcuts.map((s, i) => (
              <div className="shortcut-item" key={i}>
                <span className="shortcut-key">{s.key}</span>
                <span className="shortcut-desc"> {s.desc}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default EditorPlaceholder;