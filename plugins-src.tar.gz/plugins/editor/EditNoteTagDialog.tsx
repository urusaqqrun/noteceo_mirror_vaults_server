import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './EditNoteTagDialog.css';
import { SearchBar } from '../../common/BasicComponents';
import '../../common/BasicComponents.css';
import { useDialogStore } from '../../../Store/dialogStore';
import { useCommandManager } from '../../../Store/commandManager';
import { CustomDialog } from '../../common/CustomDialog';

// ===== 純 UI 組件 =====
// 所有資料由呼叫方透過 dialogStore.open('tag', { item, allTags, onConfirm, onCancel }) 傳入
// Dialog 內部只負責：搜索過濾、已選/可選標籤增刪、鍵盤導航、IME 組字

interface TagInfo {
  tag: string;
  count: number;
}

interface EditNoteTagDialogData {
  item: { id: string; tags?: string[]; [key: string]: any };
  allTags: TagInfo[];
  onConfirm: (tags: string[]) => void;
  onCancel?: () => void;
}

function EditNoteTagDialog() {
  const { t } = useTranslation();
  // 從 store 獲取狀態
  const showTagDialog = useDialogStore(state => state.dialogs['tag']?.show);
  const dialogData = useDialogStore(state => state.dialogs['tag']?.data) as EditNoteTagDialogData | null;

  // 從 dialogData 讀取呼叫方傳入的資料
  const item = dialogData?.item ?? null;
  const allTagsFromCaller: TagInfo[] = dialogData?.allTags ?? [];
  const onConfirmCallback = dialogData?.onConfirm ?? null;
  const onCancelCallback = dialogData?.onCancel ?? null;

  // 1. UI 狀態
  const [searchText, setSearchText] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [availableTags, setAvailableTags] = useState<TagInfo[]>([]);
  const [allTagsMap, setAllTagsMap] = useState<Record<string, { count: number }>>({});
  const [suggestedTags, setSuggestedTags] = useState<TagInfo[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(-1);
  const [isComposing, setIsComposing] = useState(false);

  // 2. ref
  const searchInputRef = useRef<HTMLInputElement>(null);

  // 3. 輔助函數
  const removeTag = (tagToRemove: string) => {
    setSelectedTags(selectedTags.filter(tag => tag !== tagToRemove));
    if (allTagsMap[tagToRemove]) {
      const newTag = {
        tag: tagToRemove,
        count: allTagsMap[tagToRemove].count
      };
      setAvailableTags(prev =>
        [...prev, newTag].sort((a, b) => b.count - a.count)
      );
    }
  };

  const addAvailableTag = (tagToAdd: string) => {
    if (!selectedTags.includes(tagToAdd)) {
      setSelectedTags([...selectedTags, tagToAdd]);
      setAvailableTags(availableTags.filter(t => t.tag !== tagToAdd));
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchText(value);

    if (value.trim()) {
      const matchedTags = availableTags
        .filter(({ tag }) =>
          tag.toLowerCase().includes(value.toLowerCase()) &&
          !selectedTags.includes(tag)
        )
        .slice(0, 5);

      setSuggestedTags(matchedTags);
      setShowSuggestions(true);
      setSelectedSuggestionIndex(-1);
    } else {
      setSuggestedTags([]);
      setShowSuggestions(false);
      setSelectedSuggestionIndex(-1);
    }
  };

  const handleSuggestionClick = (tag: string) => {
    addAvailableTag(tag);
    setSearchText('');
    setShowSuggestions(false);
  };

  // 關閉對話框
  const handleClose = () => {
    onCancelCallback?.();
    useDialogStore.getState().close('tag');
  };

  const handleConfirm = () => {
    const trimmedText = searchText.trim();
    let finalTags = selectedTags;

    // 如果有新輸入的標籤，添加到列表中
    if (trimmedText && !selectedTags.includes(trimmedText)) {
      finalTags = [...selectedTags, trimmedText];
    }

    // 呼叫外部 callback，讓呼叫方處理儲存/刷新等業務邏輯
    onConfirmCallback?.(finalTags);

    // 關閉對話框
    useDialogStore.getState().close('tag');
  };

  const handleCompositionStart = () => {
    setIsComposing(true);
  };

  const handleCompositionEnd = () => {
    setIsComposing(false);
  };

  // 4. useEffect：當 dialog 開啟時，從呼叫方傳入的資料初始化 UI 狀態
  useEffect(() => {
    if (!showTagDialog || !item) return;

    // 解析當前筆記的標籤
    const currentNoteTags = item.tags ? (
      typeof item.tags === 'string'
        ? JSON.parse(item.tags)
        : item.tags
    ) : [];

    const currentTagNames: string[] = Array.isArray(currentNoteTags)
      ? currentNoteTags
      : [];
    setSelectedTags(currentTagNames);

    // 從呼叫方傳入的 allTags 建立 tagMap
    const tagInfo: Record<string, { count: number }> = {};
    allTagsFromCaller.forEach(({ tag, count }) => {
      tagInfo[tag] = { count };
    });
    setAllTagsMap(tagInfo);

    // 設置可用標籤（排除已選擇的標籤）
    const availableTagsWithCount = allTagsFromCaller
      .filter(({ tag }) => !currentTagNames.includes(tag))
      .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));

    setAvailableTags(availableTagsWithCount);

    // 重置搜尋狀態
    setSearchText('');
    setSuggestedTags([]);
    setShowSuggestions(false);
    setSelectedSuggestionIndex(-1);

    searchInputRef.current?.focus();
  }, [showTagDialog, item, allTagsFromCaller]);

  // 5. 鍵盤導航 — enabled 自動判斷 dialog 是否開啟
  const isTagDialogOpen = () => !!useDialogStore.getState().dialogs['tag']?.show;

  useEffect(() => {
    const unsubs: (() => void)[] = [];

    // Enter
    unsubs.push(useCommandManager.getState().register({
      command: {
        id: 'tag-dialog:enter',
        name: t('cmd.tagEnter'),
        checkCallback: (checking: boolean) => {
          if (isComposing) return false;
          if (!checking) {
            if (showSuggestions && suggestedTags.length > 0 && selectedSuggestionIndex >= 0) {
              const selectedTag = suggestedTags[selectedSuggestionIndex].tag;
              addAvailableTag(selectedTag);
              setSearchText('');
              setShowSuggestions(false);
              setSelectedSuggestionIndex(-1);
            } else {
              const trimmedText = searchText.trim();
              if (trimmedText) {
                if (!selectedTags.includes(trimmedText)) {
                  setSelectedTags([...selectedTags, trimmedText]);
                  setAvailableTags(availableTags.filter(t => t.tag !== trimmedText));
                }
                setTimeout(() => setSearchText(''), 0);
              } else {
                handleConfirm();
              }
            }
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Enter' }],
      enabled: isTagDialogOpen,
    }));

    // ArrowDown
    unsubs.push(useCommandManager.getState().register({
      command: {
        id: 'tag-dialog:arrow-down',
        name: t('cmd.tagArrowDown'),
        checkCallback: (checking: boolean) => {
          if (!showSuggestions || suggestedTags.length === 0) return false;
          if (isComposing) {
            if (!checking) {
              searchInputRef.current?.blur();
              searchInputRef.current?.focus();
            }
            return true;
          }
          if (!checking) {
            setSelectedSuggestionIndex(prev =>
              prev < suggestedTags.length - 1 ? prev + 1 : 0
            );
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'ArrowDown' }],
      enabled: isTagDialogOpen,
    }));

    // ArrowUp
    unsubs.push(useCommandManager.getState().register({
      command: {
        id: 'tag-dialog:arrow-up',
        name: t('cmd.tagArrowUp'),
        checkCallback: (checking: boolean) => {
          if (!showSuggestions || suggestedTags.length === 0) return false;
          if (isComposing) {
            if (!checking) {
              searchInputRef.current?.blur();
              searchInputRef.current?.focus();
            }
            return true;
          }
          if (!checking) {
            setSelectedSuggestionIndex(prev =>
              prev > 0 ? prev - 1 : suggestedTags.length - 1
            );
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'ArrowUp' }],
      enabled: isTagDialogOpen,
    }));

    return () => unsubs.forEach(fn => fn());
  }, [
    showSuggestions, suggestedTags, isComposing,
    selectedSuggestionIndex, searchText, selectedTags,
    availableTags, handleConfirm
  ]);

  // 6. 渲染
  return (
    <CustomDialog
      isOpen={showTagDialog}
      onClose={handleClose}
      title={t('tags')}
      className="tag-dialog"
      onEscapeOverride={() => {
        if (showSuggestions) {
          setShowSuggestions(false);
          setSelectedSuggestionIndex(-1);
          return true;
        }
        if (searchText.trim()) {
          setSearchText('');
          return true;
        }
        return false;
      }}
    >
      <SearchBar
        ref={searchInputRef}
        placeholder={t('enterTagName')}
        value={searchText}
        onChange={handleSearchChange}
        onCompositionStart={handleCompositionStart}
        onCompositionEnd={handleCompositionEnd}
      />
      <div className="search-container-edit-note-tag-dialog">
        {showSuggestions && suggestedTags.length > 0 && (
          <div className="tag-suggestions">
            {suggestedTags.map(({ tag, count }, index) => (
              <div
                key={tag}
                className={`suggestion-item ${index === selectedSuggestionIndex ? 'selected' : ''}`}
                onClick={() => handleSuggestionClick(tag)}
              >
                {tag} ({count})
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="edit-tag-section">
        <h3 className="tag-section-title">{t('addedTags')}({selectedTags.length})</h3>
        <div className="selected-tags-container">
          {selectedTags.map(tag => (
            <div key={tag} className="tag-item actived" onClick={() => removeTag(tag)}>
              <span>{tag}</span>
              <button
                className="tag-remove-button"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* 可選標籤區域 */}
      <div className="edit-tag-section">
        <h3 className="tag-section-title">{t('availableTags')}({availableTags.length})</h3>
        <div className="available-tags-container">
          {availableTags.map(({ tag, count }) => (
            <div
              key={tag}
              className="tag-item"
              onClick={() => addAvailableTag(tag)}
            >
              <span>{tag}({count})</span>
            </div>
          ))}
        </div>
      </div>

      {/* 按鈕區 */}
      <div className="tag-dialog-footer">
        <button className="custom-secondary-button" onClick={handleClose}>
          {t('cancel')}
        </button>
        <button
          className="custom-primary-button"
          onClick={handleConfirm}
        >
          {t('confirm')}
        </button>
      </div>
    </CustomDialog>
  );
}

export default EditNoteTagDialog;
