import { useEffect, useRef, useCallback } from 'react';
import { uploadFile, deleteFile } from '../../../../utils/fileUpload';
import { useIsConnectedStore, useTempHintStore } from '../../../../Store/uiStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useEditorRefStore } from '../editorStore';
import { autoTitle, processAudioSummary } from '../ai/editorAI';
import { audioToText } from '../../../../aiService/promptClient';
import { markdownToHtml } from '../../../../utils/mdConverter';
import { audioBufferToWav } from '../../../../utils/audioUtils';
import { isWeb } from '../../../../utils/platform';
import { useTranslation } from 'react-i18next';

interface UseAudioRecordingParams {
  selectedNote: any;
  setSelectedNote: React.Dispatch<React.SetStateAction<any>>;
  onFieldsChangeSilent: (fields: Record<string, any>) => void;
  resolvedNoteId: string | null;
  isConnected: boolean;
  safeSetTimeout: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
}

export function useAudioRecording({
  selectedNote,
  setSelectedNote,
  onFieldsChangeSilent,
  resolvedNoteId,
  isConnected,
  safeSetTimeout,
}: UseAudioRecordingParams) {
  const { t } = useTranslation();
  const isAudioTextProcessingRef = useRef(false);
  const audioRecorderRef = useRef<any>(null);

  const isRecording = useEditorRefStore(state => state.isRecording);
  const setIsRecording = useEditorRefStore(state => state.setIsRecording);

  // 上傳本地錄音
  const uploadLocalAudios = useCallback(async (currentNoteId: string) => {
    try {
      useEditorRefStore.getState().setIsUploading(true);

      const userData = JSON.parse(localStorage.getItem('userData_local')!);
      if (!userData?.ID) {
        throw new Error('找不到用戶資料，請重新登入');
      }

      const note = await (window as any).electronAPI.getItem(currentNoteId);
      if (!note || !note.audioUrl_local || note.audioUrl_local.length === 0) return;

      const audioUrl_local: string[] = Array.isArray(note.audioUrl_local) ? note.audioUrl_local : [];
      const audioFiles = await Promise.all(audioUrl_local.map(async (base64Data: string, index: number) => {
        const response = await fetch(base64Data);
        const blob = await response.blob();
        return new File([blob], `recording_${index}.m4a`, { type: 'audio/mp4' });
      }));

      const uploadResults = await Promise.all(
        audioFiles.map(file => uploadFile(file, userData.ID, 'audio'))
      );
      const successfulUploads = uploadResults.filter(result => result.downloadURL);

      if (successfulUploads.length > 0) {
        setSelectedNote((prevNote: any) => ({
          ...prevNote,
          audioURLs: [
            ...(prevNote.audioURLs || []),
            ...successfulUploads.map(result => result.downloadURL)
          ],
          audioUrl_local: null,
        }));
      }
    } catch (error) {
      console.error('上傳本地錄音失敗:', error);
      useTempHintStore.getState().setTempHint('上傳本地錄音失敗');
    } finally {
      useEditorRefStore.getState().setIsUploading(false);
    }
  }, [setSelectedNote]);

  // 處理開始錄音
  const handleStartRecording = useCallback(() => {
    useEditorRefStore.getState().setIsRecording(true);
  }, []);

  // 處理錄音完成
  const handleRecordingComplete = useCallback(async (audioData: any) => {
    useEditorRefStore.getState().setIsRecording(false);
    const connected = useIsConnectedStore.getState().isConnected;
    try {
      if (connected) {
        useEditorRefStore.getState().setIsUploading(true);
        const formData = new FormData();
        formData.append('file', audioData.file);

        const userData = JSON.parse(localStorage.getItem('userData_local')!);
        if (!userData?.ID) {
          throw new Error('找不到用戶資料，請重新登入');
        }

        try {
          const uploadResult = await uploadFile(audioData.file, userData.ID, 'audio');

          if (!uploadResult.downloadURL) {
            throw new Error('上傳失敗：未獲得下載URL');
          }

          setSelectedNote((prevNote: any) => ({
            ...prevNote,
            audioURLs: prevNote.audioURLs ? [...prevNote.audioURLs, uploadResult.downloadURL] : [uploadResult.downloadURL],
          }));
        } catch (uploadError) {
          console.error('上傳音頻失敗:', uploadError);
          useTempHintStore.getState().setTempHint(t('audioUploadFailed'));

          if (!isWeb) {
            setSelectedNote((prevNote: any) => ({
              ...prevNote,
              audioUrl_local: prevNote.audioUrl_local ? [...prevNote.audioUrl_local, audioData.base64] : [audioData.base64],
            }));
          }
        } finally {
          useEditorRefStore.getState().setIsUploading(false);
        }
      } else {
        if (isWeb) {
          useTempHintStore.getState().setTempHint(t('pleaseCheckNetwork'));
        } else {
          setSelectedNote((prevNote: any) => ({
            ...prevNote,
            audioUrl_local: prevNote.audioUrl_local ? [...prevNote.audioUrl_local, audioData.base64] : [audioData.base64],
          }));
        }
      }
    } catch (error) {
      console.error('處理錄音失敗:', error);
      useTempHintStore.getState().setTempHint(t('audioUploadFailed'));

      if (!isWeb) {
        setSelectedNote((prevNote: any) => ({
          ...prevNote,
          audioUrl_local: prevNote.audioUrl_local ? [...prevNote.audioUrl_local, audioData.base64] : [audioData.base64],
        }));
      }
    } finally {
      useEditorRefStore.getState().setIsUploading(false);
    }
  }, [setSelectedNote, t]);

  // 處理取消錄音
  const handleCancelRecording = useCallback(() => {
    useEditorRefStore.getState().setIsRecording(false);
  }, []);

  // 監聽來自 NoteListToolBar 的錄音事件
  useEffect(() => {
    const handleStartRecordingEvent = () => {
      if (selectedNote && !isRecording) {
        handleStartRecording();
      }
    };

    document.addEventListener('startRecordingFromToolbar', handleStartRecordingEvent);

    return () => {
      document.removeEventListener('startRecordingFromToolbar', handleStartRecordingEvent);
    };
  }, [selectedNote, isRecording, handleStartRecording]);

  // 監聽 selectedNote 變化，如果正在錄音就取消錄音
  useEffect(() => {
    if (isRecording && audioRecorderRef.current?.cancelRecording) {
      audioRecorderRef.current.cancelRecording();
      useEditorRefStore.getState().setIsRecording(false);
    }
  }, [selectedNote?.id]);

  // 當選中的筆記改變時，檢查是否需要語音辨識
  useEffect(() => {
    if (!isConnected) return;
    if (isAudioTextProcessingRef.current) return;
    isAudioTextProcessingRef.current = true;

    const processAudioRecognition = async () => {
      try {
        if (selectedNote && selectedNote.audioURLs) {
          if (selectedNote?.audioURLs &&
            selectedNote?.audioURLs.length > 0) {

            if (!selectedNote?.audioTexts) {
              selectedNote.audioTexts = new Array(selectedNote?.audioURLs.length).fill("");
            }

            const noteIdBeforeAIAPI = selectedNote?.id;
            for (let i = 0; i < selectedNote?.audioTexts.length; i++) {
              if (selectedNote?.audioTexts[i] === "") {
                try {
                  const arrayBuffer = await (window as any).electronAPI.downloadAudioFile(selectedNote.audioURLs[i]);

                  const AudioContextCtor: typeof AudioContext = (window as any).AudioContext || (window as any).webkitAudioContext || AudioContext;
                  const audioContext = new AudioContextCtor();
                  const bufferToDecode = arrayBuffer instanceof ArrayBuffer ? arrayBuffer : new Uint8Array(arrayBuffer).buffer;
                  const audioBuffer = await audioContext.decodeAudioData(bufferToDecode);

                  const targetSampleRate = 16000;
                  const numberOfChannels = 1;
                  const offlineContext = new OfflineAudioContext(numberOfChannels, audioBuffer.duration * targetSampleRate, targetSampleRate);
                  const source = offlineContext.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(offlineContext.destination);
                  source.start();
                  const renderedBuffer = await offlineContext.startRendering();

                  const wavBlob = audioBufferToWav(renderedBuffer);
                  const file = new File([wavBlob], selectedNote.audioURLs[i].split('/').pop().replace(/\.[^.]+$/, '.wav'), { type: 'audio/wav' });

                  useEditorRefStore.getState().setIsUploading(true);

                  const result = await audioToText(file, true, true);

                  const transcriptText = result?.transcript || result?.text || result?.content || '';

                  if (transcriptText) {
                    if (resolvedNoteId === noteIdBeforeAIAPI) {
                      setSelectedNote((prevNote: any) => {
                        const updatedAudioTexts = [...prevNote.audioTexts];
                        if (updatedAudioTexts.length > i) {
                          updatedAudioTexts[i] = transcriptText;
                        }
                        return {
                          ...prevNote,
                          audioTexts: updatedAudioTexts,
                        };
                      });

                      const hasTitle = !!(selectedNote.name && selectedNote.name.trim());
                      const hasAiTitle = !!(selectedNote.aiTitle && selectedNote.aiTitle.trim());
                      const needAutoTitle = !hasTitle && !hasAiTitle;

                      const summaryPromise = processAudioSummary(transcriptText, null);

                      let titlePromise: Promise<any> | null = null;
                      if (needAutoTitle) {
                        const { processItemContent } = await import('../../../../utils/textUtils');
                        const processedContent = processItemContent({
                          ...selectedNote,
                          audioTexts: [...selectedNote.audioTexts.slice(0, i), transcriptText, ...selectedNote.audioTexts.slice(i + 1)],
                        });
                        titlePromise = autoTitle(processedContent);
                      }

                      const allPromises = titlePromise ? [summaryPromise, titlePromise] : [summaryPromise];

                      Promise.allSettled(allPromises).finally(() => {
                        useEditorRefStore.getState().setIsUploading(false);
                      });

                      summaryPromise.then(async (summaryResult: any) => {
                        if (summaryResult?.content) {
                          if (resolvedNoteId === noteIdBeforeAIAPI) {
                            const currentNote = await (window as any).electronAPI.getItem(noteIdBeforeAIAPI);
                            const originalContent = currentNote?.content || '';
                            const hasOriginalContent = originalContent.trim() !== '';

                            let newContent = summaryResult.content;
                            if (hasOriginalContent) {
                              newContent += '\n\n---\n\n' + originalContent;
                            }

                            setSelectedNote((prevNote: any) => ({
                              ...prevNote,
                              content: newContent,
                            }));

                            if (currentNote) {
                              onFieldsChangeSilent({ content: newContent });
                            }

                            const editorRef = useEditorRefStore.getState().editorRef;
                            if (editorRef) {
                              safeSetTimeout(() => {
                                if (resolvedNoteId === noteIdBeforeAIAPI) {
                                  editorRef.commands.setContent(markdownToHtml(newContent));
                                }
                              }, 100);
                            }
                          } else {
                            (window as any).electronAPI.getItem(noteIdBeforeAIAPI).then((noteToUpdate: any) => {
                              if (noteToUpdate) {
                                const originalContent = noteToUpdate.content || '';
                                const hasOriginalContent = originalContent.trim() !== '';

                                let newContent = summaryResult.content;
                                if (hasOriginalContent) {
                                  newContent += '\n\n---\n\n' + originalContent;
                                }

                                void useItemStore.getState().upsertItem({ ...noteToUpdate, content: newContent, itemType: 'NOTE' }, { needSync: true });
                              }
                            });
                          }
                        }
                      }).catch((error: any) => {
                        console.error('processAudioSummary 調用失敗:', error);
                      });

                      if (titlePromise) {
                        titlePromise.then((titleResult: any) => {
                          if (titleResult?.title) {
                            if (resolvedNoteId === noteIdBeforeAIAPI) {
                              setSelectedNote((prevNote: any) => {
                                const updatedFinishedAPIs = prevNote.finishedAPIs || [];
                                if (!updatedFinishedAPIs.includes('auto_title')) {
                                  updatedFinishedAPIs.push('auto_title');
                                }
                                return {
                                  ...prevNote,
                                  name: titleResult.title,
                                  finishedAPIs: updatedFinishedAPIs,
                                };
                              });
                            } else {
                              (window as any).electronAPI.getItem(noteIdBeforeAIAPI).then((noteToUpdate: any) => {
                                if (noteToUpdate) {
                                  const updatedFinishedAPIs = noteToUpdate.finishedAPIs || [];
                                  if (!updatedFinishedAPIs.includes('auto_title')) {
                                    updatedFinishedAPIs.push('auto_title');
                                  }
                                  void useItemStore.getState().upsertItem({ ...noteToUpdate, name: titleResult.title, finishedAPIs: updatedFinishedAPIs, itemType: 'NOTE' }, { needSync: true });
                                }
                              });
                            }
                          }
                        }).catch((error: any) => {
                          console.error('autoTitle 調用失敗:', error);
                        });
                      }
                    } else {
                      const latestNote = await (window as any).electronAPI.getItem(noteIdBeforeAIAPI);
                      if (latestNote) {
                        const updatedAudioTexts = [...latestNote.audioTexts];
                        if (updatedAudioTexts.length > i) {
                          updatedAudioTexts[i] = transcriptText;
                        }

                        await useItemStore.getState().upsertItem({ ...latestNote, audioTexts: updatedAudioTexts, itemType: 'NOTE' }, { needSync: true });

                        const hasTitle = !!(latestNote.name && latestNote.name.trim());
                        const hasAiTitle = !!(latestNote.aiTitle && latestNote.aiTitle.trim());
                        const needAutoTitle = !hasTitle && !hasAiTitle;

                        const summaryPromise = processAudioSummary(transcriptText, null);

                        let titlePromise: Promise<any> | null = null;
                        if (needAutoTitle) {
                          const { processItemContent } = await import('../../../../utils/textUtils');
                          const processedContent = processItemContent({
                            ...latestNote,
                            audioTexts: updatedAudioTexts
                          });
                          titlePromise = autoTitle(processedContent);
                        }

                        const allPromises = titlePromise ? [summaryPromise, titlePromise] : [summaryPromise];

                        Promise.allSettled(allPromises).finally(() => {
                          useEditorRefStore.getState().setIsUploading(false);
                        });

                        summaryPromise.then((summaryResult: any) => {
                          if (summaryResult?.content) {
                            (window as any).electronAPI.getItem(noteIdBeforeAIAPI).then((noteToUpdate: any) => {
                              if (noteToUpdate) {
                                const originalContent = noteToUpdate.content || '';
                                const hasOriginalContent = originalContent.trim() !== '';

                                let newContent = summaryResult.content;
                                if (hasOriginalContent) {
                                  newContent += '\n\n---\n\n' + originalContent;
                                }

                                void useItemStore.getState().upsertItem({ ...noteToUpdate, content: newContent, itemType: 'NOTE' }, { needSync: true });
                              }
                            });
                          }
                        }).catch((error: any) => {
                          console.error('processAudioSummary 調用失敗:', error);
                        });

                        if (titlePromise) {
                          titlePromise.then((titleResult: any) => {
                            if (titleResult?.title) {
                              (window as any).electronAPI.getItem(noteIdBeforeAIAPI).then((noteToUpdate: any) => {
                                if (noteToUpdate) {
                                  const updatedFinishedAPIs = noteToUpdate.finishedAPIs || [];
                                  if (!updatedFinishedAPIs.includes('auto_title')) {
                                    updatedFinishedAPIs.push('auto_title');
                                  }
                                  void useItemStore.getState().upsertItem({ ...noteToUpdate, name: titleResult.title, finishedAPIs: updatedFinishedAPIs, itemType: 'NOTE' }, { needSync: true });
                                }
                              });
                            }
                          }).catch((error: any) => {
                            console.error('autoTitle 調用失敗:', error);
                          });
                        }
                      }
                    }
                  } else {
                    useEditorRefStore.getState().setIsUploading(false);
                  }
                } catch (error) {
                  console.error('語音辨識失敗:', error);
                  useEditorRefStore.getState().setIsUploading(false);
                }
              }
            }
          }
        }
      } catch (error) {
        console.error('語音辨識處理失敗:', error);
      } finally {
        isAudioTextProcessingRef.current = false;
      }
    };

    processAudioRecognition();
  }, [selectedNote?.id, selectedNote?.audioURLs, selectedNote?.audioTexts, isConnected]);

  // 當選中的筆記改變時，檢查是否需要上傳本地錄音
  useEffect(() => {
    if (selectedNote && selectedNote.audioUrl_local && isConnected) {
      uploadLocalAudios(selectedNote.id);
    }
  }, [selectedNote?.id, selectedNote?.audioUrl_local, isConnected]);

  return {
    isRecording,
    setIsRecording,
    audioRecorderRef,
    handleStartRecording,
    handleRecordingComplete,
    handleCancelRecording,
    uploadLocalAudios,
  };
}
