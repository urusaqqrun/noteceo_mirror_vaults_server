import { useRef, useEffect, useCallback } from 'react';

/**
 * 網頁連結抓取與預覽資料管理
 * 從 MarkdownEditor.tsx 提取（Phase 4.1）
 */

interface WebsiteTextResult {
  title: string | null;
  content: string | null;
  imageUrl: string | null;
}

export function useWebsitePreview(
  noteId: string | null,
  selectedNote: any,
  onFieldsChangeSilent: (fields: Record<string, any>) => void,
  setSelectedNote: (noteOrUpdater: any) => void,
) {
  const websiteLinksRef = useRef<any[]>([]);
  const noteIdRef = useRef<string | null>(null);
  noteIdRef.current = noteId;

  // 解析 selectedNote.websiteContent → 更新 websiteLinksRef
  useEffect(() => {
    let links: any[] = [];
    try {
      links = selectedNote?.websiteContent ? JSON.parse(selectedNote.websiteContent) : [];
    } catch (e) {
      links = [];
    }
    websiteLinksRef.current = links;
  }, [selectedNote?.websiteContent]);

  // 解析內容中的 URL，抓取網頁預覽資料
  const linkFetchText = useCallback(() => {
    let currentWebsiteLinks: any[] = [];
    try {
      currentWebsiteLinks = selectedNote?.websiteContent ? JSON.parse(selectedNote.websiteContent) : [];
    } catch (error) {
      console.error('解析 websiteContent 失敗:', error);
      currentWebsiteLinks = [];
    }

    const newUrls: string[] = [];
    const content = selectedNote?.content;
    const mdLinkRegex = /\[.*?\]\((https?:\/\/[^)]+)\)/g;
    const htmlLinkRegex = /<a[^>]*href=["'](https?:\/\/[^"']+)["'][^>]*>/g;
    let match: RegExpExecArray | null;

    while ((match = mdLinkRegex.exec(content)) !== null) {
      const url = match[1];
      if (!currentWebsiteLinks.some(link => link.originUrl === url)) {
        newUrls.push(url);
      }
    }
    while ((match = htmlLinkRegex.exec(content)) !== null) {
      const url = match[1];
      if (!currentWebsiteLinks.some(link => link.originUrl === url) && !newUrls.includes(url)) {
        newUrls.push(url);
      }
    }

    if (newUrls.length > 0) {
      const fetchWebsiteText = async (url: string) => {
        try {
          if (!/^https?:\/\//.test(url)) {
            return null;
          }
          const websiteText = await (window as any).electronAPI.fetchWebsiteText(url) as unknown as WebsiteTextResult | null;
          return {
            originUrl: url,
            title: websiteText?.title || null,
            content: websiteText?.content || null,
            imageUrl: websiteText?.imageUrl || null
          };
        } catch (error) {
          console.error('抓取網站內容失敗:', error);
          return {
            originUrl: url,
            title: null,
            content: null,
            imageUrl: null
          };
        }
      };

      Promise.all(newUrls.map(url => fetchWebsiteText(url)))
        .then(async (newWebsiteLinks) => {
          const updatedWebsiteLinks = [
            ...currentWebsiteLinks,
            ...newWebsiteLinks.filter(link =>
              link !== null &&
              !currentWebsiteLinks.some(existing => existing.originUrl === link.originUrl)
            )
          ];

          const noteIdBeforeUpdate = selectedNote?.id;
          const websiteContentJson = JSON.stringify(updatedWebsiteLinks);

          onFieldsChangeSilent({ websiteContent: websiteContentJson });

          if (noteIdRef.current === noteIdBeforeUpdate) {
            setSelectedNote((prevNote: any) => prevNote ? {
              ...prevNote,
              websiteContent: websiteContentJson,
            } : prevNote);
          }
        })
        .catch((error) => {
          console.error('批量抓取網站資訊失敗:', error);
        });
    }
  }, [selectedNote]);

  // 內容變更時觸發 linkFetchText
  useEffect(() => {
    const finishedAPIs = selectedNote?.finishedAPIs || [];
    if (finishedAPIs.includes('link_fetch_text')) {
      return;
    }
    linkFetchText();
  }, [selectedNote?.content, selectedNote?.websiteContent, selectedNote?.finishedAPIs]);

  return { websiteLinksRef, linkFetchText };
}
