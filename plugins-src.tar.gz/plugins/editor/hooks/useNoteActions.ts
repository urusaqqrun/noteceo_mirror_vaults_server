import { useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../../hooks/useTimeout';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useTempHintStore } from '../../../../Store/uiStore';
import { useItemStore } from '../../../../Store/itemStore';
import { eventBus } from '../../../../Store/eventBus';

/**
 * 筆記/待辦的 CRUD 操作（刪除、釘選、複製）+ 拖曳建新筆記
 * 從 MarkdownEditor.tsx 提取（Phase 4.1）
 */
export function useNoteActions(
  noteId: string | null,
  selectedNote: any,
  mode: string,
  editor: any,
  onFieldsChange: (fields: Record<string, any>) => void,
  setSelectedNote: (noteOrUpdater: any) => void,
) {
  const { t } = useTranslation();
  const { setTimeout: safeSetTimeout } = useTimeout();

  const handleDelete = useCallback(async () => {
    if (!selectedNote) return;
    const isInTrash = selectedNote?.isDeleted === true;
    await useItemStore.getState().removeItems([selectedNote.id], { needSync: true, softDelete: !isInTrash, navigateOut: true });
    if (mode === 'window') {
      safeSetTimeout(() => {
        (window as any).electronAPI.close();
      }, 100);
    }
  }, [selectedNote, mode, setSelectedNote, safeSetTimeout]);

  // ===== handlePinClick：切換釘選狀態 =====
  const handlePinClick = useCallback(async () => {
    if (!selectedNote) return;
    try {
      const newPinnedAt = selectedNote?.pinnedAt ? null : Date.now();
      onFieldsChange({ pinnedAt: newPinnedAt });
      setSelectedNote({
        ...selectedNote,
        pinnedAt: newPinnedAt,
      });
      if (document.activeElement?.classList.contains('todo-title-input')) {
        (document.activeElement as HTMLElement).blur();
      }
    } catch (error) {
      console.error('切換釘選狀態失敗:', error);
    }
  }, [selectedNote, onFieldsChange, setSelectedNote]);

  // ===== handleCopy：通用複製 =====
  const handleCopy = useCallback(async () => {
    if (!selectedNote) return;
    try {
      const { generateObjectID } = await import('../../../../../../services/utils/objectIDUtil.mjs');
      const newId = generateObjectID();
      const newItem = {
        ...selectedNote,
        id: newId,
        name: `${selectedNote.name || t('untitled')} ${t('copySuffix')}`,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        pinnedAt: null,
        reminderTime: null,
      };
      await useItemStore.getState().upsertItem({ ...newItem, itemType: selectedNote.itemType }, { needSync: true });
      useSelectedItemsStore.getState().setSelectedItems([newItem], { scrollToFocusItem: true, highlightItemId: newItem.id });
      useTempHintStore.getState().setTempHint(t('itemCopied'));
      if (mode === 'window') {
        safeSetTimeout(() => (window as any).electronAPI.close(), 100);
      }
    } catch (error) {
      console.error('複製失敗:', error);
      useTempHintStore.getState().setTempHint(t('copyFailed'));
    }
  }, [selectedNote, mode, t, safeSetTimeout]);

  // ===== EventBus：NoteEditor 段落拖到 Sidebar 資料夾 =====
  useEffect(() => {
    const unsub = eventBus.on('drop:sidebar-folder:noteEditor', async (_items: any, metadata: any, targetFolderId: string, targetFolder: any) => {
      const contentText = (metadata?.textContent || '').trim();
      if (contentText === '') return;
      try {
        const { generateObjectID } = await import('../../../../../../services/utils/objectIDUtil.mjs');
        const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
        const myMemberID = userData?.ID || (window as any).auth?.currentUser?.uid || 'DataProviderDefault';
        const now = Date.now();
        if (metadata?.isTaskItem) {
          const newTodo = {
            id: generateObjectID(),
            itemType: 'TODO' as const,
            parentID: targetFolderId,
            version: 0,
            completed: metadata?.isTaskCompleted ?? false,
            name: contentText,
            content: '',
            createdAt: now,
            updatedAt: now,
          };
          await useItemStore.getState().upsertItem(newTodo, { needSync: false });
        } else {
          const newNote = {
            id: generateObjectID(),
            itemType: 'NOTE' as const,
            parentID: targetFolderId,
            version: 0,
            name: contentText,
            content: '',
            createdAt: now,
            updatedAt: now,
          };
          await useItemStore.getState().upsertItem(newNote, { needSync: false });
        }
        if (metadata?.deleteOriginal) metadata.deleteOriginal();
        const folderName = targetFolder?.name || '';
        const displayFolderName = ['inbox', 'trash', 'todoInbox'].includes(folderName) ? t(folderName) : folderName;
        const noteTypeKey = metadata?.isTaskItem
          ? (metadata?.isTaskCompleted ? 'noteTypeCompletedTodo' : 'noteTypeTodo')
          : 'noteTypeNote';
        useTempHintStore.getState().setTempHint(t('noteCreatedInFolder', { noteType: t(noteTypeKey), folderName: displayFolderName }));
      } catch (err) {
        console.error('處理 NoteEditor 內容拖放到資料夾失敗:', err);
      }
    });
    return unsub;
  }, [t]);

  // ===== EventBus：NoteEditor 段落拖到 NoteList 建立新筆記 =====
  useEffect(() => {
    const unsub = eventBus.on('drop:note-list:noteEditor', async (_items: any, metadata: any) => {
      const contentText = (metadata?.textContent || '').trim();
      if (contentText === '') return;
      try {
        const { generateObjectID } = await import('../../../../../../services/utils/objectIDUtil.mjs');
        const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
        const myMemberID = userData?.ID || (window as any).auth?.currentUser?.uid || 'DataProviderDefault';
        const folderId = useSelectedItemsStore.getState().selectedFolderId;
        const now = Date.now();
        const newNote = {
          id: generateObjectID(),
          itemType: 'NOTE' as const,
          parentID: folderId,
          version: 0,
          name: contentText,
          content: '',
          createdAt: now,
          updatedAt: now,
        };
        await useItemStore.getState().upsertItem(newNote, { needSync: false });
        if (metadata?.deleteOriginal) metadata.deleteOriginal();
      } catch (err) {
        console.error('NoteEditor段落拖到NoteList失敗:', err);
      }
    });
    return unsub;
  }, []);

  return {
    handleDelete,
    handlePinClick,
    handleCopy,
  };
}
