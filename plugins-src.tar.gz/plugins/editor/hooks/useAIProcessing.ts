import { useEffect, useRef, useCallback } from 'react';
import { noteIntentionAnalysis } from '../ai/editorAI';
import { useMaterialModeStore } from '../editorStore';
import { useTempHintStore } from '../../../../Store/uiStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';

interface UseAIProcessingParams {
  editor: any;
  selectedNote: any;
  setSelectedNote: React.Dispatch<React.SetStateAction<any>>;
  onFieldsChangeSilent: (fields: Record<string, any>) => void;
  resolvedNoteId: string | null;
  isConnected: boolean;
  isReadOnlyMode: boolean;
  safeSetTimeout: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
  historyManager: any;
}

export function useAIProcessing({
  editor,
  selectedNote,
  setSelectedNote,
  onFieldsChangeSilent,
  resolvedNoteId,
  isConnected,
  isReadOnlyMode,
  safeSetTimeout,
  historyManager,
}: UseAIProcessingParams) {
  const aiserver404Ref = useRef(false);
  const isAIAPIProcessingRef = useRef(false);
  const lastAISelectionRef = useRef<Range | null>(null);

  // 切換筆記時，重置AI伺服器404狀態 — 由外部 useEffect 呼叫
  const resetAIServer404 = useCallback(() => {
    aiserver404Ref.current = false;
  }, []);

  // 處理筆記內容的函數 (noteIntentionAnalysis 等 AI batch)
  useEffect(() => {
    if (aiserver404Ref.current) {
      return;
    }

    const processAIAPI = async () => {
      if (isAIAPIProcessingRef.current) {
        return;
      } else {
      }

      if (selectedNote?.imageUrl_local && selectedNote?.imageUrl_local.length > 0) {
        return;
      }

      if (selectedNote?.imgURLs &&
        selectedNote?.imgTexts &&
        selectedNote?.imgURLs.length > 0) {
        if (selectedNote?.imgURLs.length > selectedNote?.imgTexts.length) {
          return;
        } else if (selectedNote?.imgTexts && selectedNote?.imgTexts.length > 0) {
          for (let i = 0; i < selectedNote?.imgTexts.length; i++) {
            if (selectedNote?.imgTexts[i] === "" || selectedNote?.imgTexts[i] === 'imgText') {
              return;
            }
          }
        }
      }

      const { processItemContent } = await import('../../../../utils/textUtils');
      const processedContent = processItemContent(selectedNote);

      const note = selectedNote;
      try {
        isAIAPIProcessingRef.current = true;
        const noteIdBeforeAIAPI = note?.id;
        if (!isConnected) {
          return;
        }
        if (note?.imageUrl_local && note?.imageUrl_local.length > 0) {
          return;
        }
        if (note?.purpose) {
          return;
        }
        const checkLength = (text: string) => {
          const chineseLength = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
          const englishLength = text.length - chineseLength;
          return chineseLength + englishLength / 2 <= 40;
        };

        if (checkLength(processedContent)) {
          return;
        }

        const apiRequests: Promise<void>[] = [];
        const apiResults: {
          title: string | null;
          tags: string | null;
          aiTags: string | null;
          purpose: string | null;
          classification: string | null;
          reminderTime: number | null;
          offsetMinutes: number | null;
        } = {
          title: null,
          tags: null,
          aiTags: null,
          purpose: null,
          classification: null,
          reminderTime: null,
          offsetMinutes: null
        };

        const finishedAPIs = note?.finishedAPIs || [];
        const newFinishedAPIs: string[] = [];

        // 1. 自動生成標題的請求 (暫時關閉)
        // if (!note?.title && !note?.aiTitle && !finishedAPIs.includes('auto_title')) {
        //   newFinishedAPIs.push('auto_title');
        //   apiRequests.push(
        //     autoTitle(processedContent)
        //       .then(result => {
        //         apiResults.title = result?.title;
        //       })
        //       .catch(error => {
        //         aiserver404Ref.current = true;
        //         console.error('自動生成標題發生錯誤:', error);
        //       })
        //   );
        // }

        // 2. 自動標籤的請求 (暫時關閉)
        // if(!note?.tags && !note?.aiTags && !finishedAPIs.includes('auto_tag')){
        //   newFinishedAPIs.push('auto_tag');
        //   apiRequests.push(
        //     window.electronAPI.getAllTags()
        //       .then(async allTags => {
        //         const tagResult = await autoTagging(processedContent, allTags);
        //         if (tagResult?.isAICreate) {
        //           // apiResults.aiTags = tagResult?.tags;
        //         } else {
        //           apiResults.aiTags = tagResult?.tags;
        //         }
        //       })
        //       .catch(error => {
        //         aiserver404Ref.current = true;
        //         console.error('自動標籤發生錯誤:', error);
        //       })
        //   );
        // }

        // 3. 筆記意圖分析的請求
        if (!note?.purpose && !finishedAPIs.includes('note_intention_analysis')) {
          newFinishedAPIs.push('note_intention_analysis');
          apiRequests.push(
            noteIntentionAnalysis(processedContent, undefined)
              .then((intentionResult: any) => {
                apiResults.purpose = intentionResult.intentionJudgment ?
                  intentionResult.intentionAnalysis :
                  "無明確目的";
              })
              .catch(error => {
                aiserver404Ref.current = true;
                console.error('筆記意圖分析發生錯誤:', error);
              })
          );
        }

        // 4. 文本時間提醒提取的請求（暫時停用）
        // ... (commented out block)

        await Promise.all(apiRequests);

        if (newFinishedAPIs.length === 0) {
          return;
        }
        const updatedFinishedAPIs = [...finishedAPIs, ...newFinishedAPIs];

        const _lastId3928 = useSelectedItemsStore.getState().path.at(-1)?.id;
        const currentSelectedNote = _lastId3928
          ? (await (window as any).electronAPI.getItem(_lastId3928) ?? null)
          : null;
        if (currentSelectedNote?.id === noteIdBeforeAIAPI) {
          const silentFields: Record<string, any> = {};
          if (apiResults.title) silentFields.aiTitle = apiResults.title;
          if (apiResults.tags) silentFields.tags = apiResults.tags;
          if (apiResults.aiTags) silentFields.aiTags = apiResults.aiTags;
          if (apiResults.purpose) silentFields.purpose = apiResults.purpose;
          if (newFinishedAPIs.length > 0) silentFields.finishedAPIs = updatedFinishedAPIs;
          onFieldsChangeSilent(silentFields);
        } else {
          const noteBeforeAIAPI = await (window as any).electronAPI.getItem(noteIdBeforeAIAPI);
          const updatedNote = {
            ...noteBeforeAIAPI,
            ...(apiResults.title && { aiTitle: apiResults.title }),
            ...(apiResults.tags && { tags: apiResults.tags }),
            ...(apiResults.aiTags && { aiTags: apiResults.aiTags }),
            ...(apiResults.purpose && { purpose: apiResults.purpose }),
            ...(newFinishedAPIs.length > 0 && { finishedAPIs: updatedFinishedAPIs }),
          };

          onFieldsChangeSilent(updatedNote);
        }

      } catch (error) {
        aiserver404Ref.current = true;
        console.error('筆記內頁呼叫AIAPI發生錯誤:', error);
      } finally {
        isAIAPIProcessingRef.current = false;
      }
    };

    if (!isReadOnlyMode) {
      processAIAPI();
    }

  }, [selectedNote, isConnected]);

  // 修改監聽選取變化的 useEffect
  useEffect(() => {
    if (!editor) return;

    const handleSelectionChange = () => {
      safeSetTimeout(() => {
        if (!editor || !editor.view || editor.isDestroyed) return;

        const selection = window.getSelection();

        if (!selection || selection.rangeCount === 0) {
          const materialLibraryElement = document.querySelector('.material-library');
          const isFocusInMaterialLibrary = materialLibraryElement && materialLibraryElement.contains(document.activeElement);

          if (!isFocusInMaterialLibrary) {
            if (useMaterialModeStore.getState().isAIRewriteMode) {
              useMaterialModeStore.getState().setisAIRewriteMode(false);
            }
          }
          return;
        }

        const range = selection.getRangeAt(0);
        const isSelectionInEditor = (
          range.commonAncestorContainer === editor.view.dom ||
          editor.view.dom.contains(range.commonAncestorContainer)
        );

        const { from, to } = editor.state.selection;

        historyManager.updateLastSelection(editor.state.selection);

        const $pos = editor.state.doc.resolve(from);
        let depth = $pos.depth;
        let isInListItem = false;
        let listItemNode: any = null;
        let listItemDepth = 0;

        while (depth > 0) {
          const node = $pos.node(depth);
          if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
            isInListItem = true;
            listItemNode = node;
            listItemDepth = depth;
            break;
          }
          depth--;
        }

        if (isInListItem && listItemNode) {
          const isEmpty = listItemNode.textContent.trim() === '';
          if (isEmpty) {
            const listItemPos = $pos.before(listItemDepth);

            let isFirstItem = true;
            let previousPos = listItemPos - 1;

            while (previousPos > 0) {
              const previousNode = editor.state.doc.nodeAt(previousPos);
              if (previousNode && (previousNode.type.name === 'listItem' || previousNode.type.name === 'taskItem')) {
                isFirstItem = false;
                break;
              }
              previousPos--;
            }

            if (listItemDepth === 2 && isFirstItem) {
              // useTempHintStore.getState().setTempHint('『Delete』刪除');
            } else {
              useTempHintStore.getState().setTempHint('『Tab』升階 『Enter』降階 『Delete』刪除');
            }
          }
        }

        const materialLibraryElement = document.querySelector('.material-library');
        const isFocusInMaterialLibrary = materialLibraryElement && materialLibraryElement.contains(document.activeElement);
        const isSelectionInMaterialLibrary = materialLibraryElement && (
          range.commonAncestorContainer === materialLibraryElement ||
          materialLibraryElement.contains(range.commonAncestorContainer)
        );

        if (!selection.isCollapsed && isSelectionInEditor && !isReadOnlyMode) {
          let containsImage = false;
          editor.state.doc.nodesBetween(from, to, (node: any) => {
            if (node.type.name === 'image') {
              containsImage = true;
              return false;
            }
            return true;
          });

          if (true) {
            (window as any).lastAISelectionRange = { from, to };

            const blocks: any[] = [];
            let topLevelIndex = 0;
            editor.state.doc.forEach((child: any, offset: number) => {
              const childFrom = offset;
              const childTo = offset + child.nodeSize;
              const isIntersect = !(childTo <= from || childFrom >= to);
              if (isIntersect) {
                blocks.push({
                  content: child.textContent,
                  index: topLevelIndex,
                  from: childFrom,
                  to: childTo,
                });
              }
              topLevelIndex += 1;
            });

            if (blocks.length > 0) {
              (window as any).lastAISelectionParagraphs = blocks;
            }
          }
        } else if (!isFocusInMaterialLibrary && !isSelectionInMaterialLibrary) {
          if (useMaterialModeStore.getState().isAIRewriteMode) {
            useMaterialModeStore.getState().setisAIRewriteMode(false);
          }
        }

        if (!selection.isCollapsed && isSelectionInEditor) {
          if (useMaterialModeStore.getState().isAIRewriteMode) {
            lastAISelectionRef.current = selection.getRangeAt(0).cloneRange();
          }
        }
      }, 0);
    };

    document.addEventListener('selectionchange', handleSelectionChange);

    return () => {
      document.removeEventListener('selectionchange', handleSelectionChange);
    };
  }, [editor]);

  return {
    aiserver404Ref,
    isAIAPIProcessingRef,
    lastAISelectionRef,
    resetAIServer404,
  };
}
