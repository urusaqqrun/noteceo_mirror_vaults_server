import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useTempHintStore } from '../../../../Store/uiStore';
import { useItemStore } from '../../../../Store/itemStore';

interface UseLinkHandlerParams {
  editor: any;
}

const CUBELV_LINK_RE = /^(?:CubeLV|cubelv):\/\/(\w+)\/([a-zA-Z0-9_-]+)/;

export function useLinkHandler({ editor }: UseLinkHandlerParams) {
  const { t } = useTranslation();

  useEffect(() => {
    const handleLinkClick = async (e: MouseEvent) => {
      const link = (e.target as HTMLElement).closest('a');
      if (!link || !link.classList.contains('editor-link')) return;

      e.preventDefault();
      const href = link.getAttribute('href');
      const match = href?.match(CUBELV_LINK_RE);

      if (match) {
        const [, , rawId] = match;
        const itemId = rawId.split('?')[0];

        try {
          const item = await (window as any).electronAPI.getItem(itemId);
          if (!item) {
            useTempHintStore.getState().setTempHint(t('itemNotFound'));
            return;
          }

          // TODO 連結的 icon 點擊：切換完成狀態
          if (item.itemType === 'TODO') {
            const isDone = href.includes('done=1');
            const linkRect = link.getBoundingClientRect();
            const isIconClick = (e.clientX - linkRect.left) <= 24;

            if (isIconClick) {
              const newCompleted = !isDone;
              const storeItem = useItemStore.getState().getById(item.id);
              if (storeItem) {
                await useItemStore.getState().upsertItem(
                  {
                    ...storeItem,
                    completed: newCompleted,
                    finishedAt: newCompleted ? Date.now().toString() : null,
                    aiFolderID: newCompleted ? null : (storeItem as any).aiFolderID,
                    updatedAt: Date.now(),
                  } as any,
                  { needSync: true }
                );
              }

              const newHref = isDone ? href.replace('?done=1', '') : `${href}?done=1`;
              if (editor) {
                const { from } = editor.state.selection;
                let linkPos: { from: number; to: number } | null = null;
                editor.state.doc.descendants((node: any, pos: number) => {
                  if (node.isText && node.marks.some((m: any) => m.type.name === 'link' && m.attrs.href === href)) {
                    linkPos = { from: pos, to: pos + node.nodeSize };
                    return false;
                  }
                });
                if (linkPos) {
                  editor.chain().setTextSelection(linkPos).extendMarkRange('link').setLink({ href: newHref }).setTextSelection(from).run();
                }
              }
              return;
            }
          }

          // 導航：直接使用 item.itemType
          const navParams: any = { scrollToFocusItem: true, highlightItemId: itemId };
          if (item.itemType === 'CARD') navParams.scrollToCard = true;

          useSelectedItemsStore.getState().setSelectedItems(
            [item],
            navParams,
          );
        } catch (error) {
          console.error('處理 CubeLV 連結時出錯:', error);
        }
      } else if (href) {
        try {
          new URL(href);
          (window as any).electronAPI.openExternalLink(href);
        } catch (error) {
          console.error('無效的外部連結:', href, error);
        }
      }
    };

    const editorContent = document.querySelector('.ProseMirror');
    if (editorContent) {
      editorContent.addEventListener('click', handleLinkClick as EventListener, true);
    }
    return () => {
      const editorContent = document.querySelector('.ProseMirror');
      if (editorContent) {
        editorContent.removeEventListener('click', handleLinkClick as EventListener, true);
      }
    };
  }, [editor]);
}
