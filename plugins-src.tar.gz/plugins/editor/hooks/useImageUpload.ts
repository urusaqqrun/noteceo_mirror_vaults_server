import { useEffect, useRef, useCallback } from 'react';
import { uploadFile, validateFile } from '../../../../utils/fileUpload';
import { useIsConnectedStore, useTempHintStore } from '../../../../Store/uiStore';
import { useItemStore } from '../../../../Store/itemStore';
import { useMaterialModeStore, useEditorRefStore } from '../editorStore';
import { imgUrlToTheme } from '../ai/editorAI';
import { imageToText } from '../../../../aiService/promptClient';
import { markdownToHtml } from '../../../../utils/mdConverter';
import { isWeb } from '../../../../utils/platform';
import { useTranslation } from 'react-i18next';

interface UseImageUploadParams {
  editor: any;
  ref: React.RefObject<any> | ((instance: any) => void) | null;
  selectedNote: any;
  setSelectedNote: React.Dispatch<React.SetStateAction<any>>;
  onFieldsChangeSilent: (fields: Record<string, any>) => void;
  resolvedNoteId: string | null;
  isConnected: boolean;
  safeSetTimeout: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
  setAddMenuState: React.Dispatch<React.SetStateAction<any>>;
}

export function useImageUpload({
  editor,
  ref,
  selectedNote,
  setSelectedNote,
  onFieldsChangeSilent,
  resolvedNoteId,
  isConnected,
  safeSetTimeout,
  setAddMenuState,
}: UseImageUploadParams) {
  const { t } = useTranslation();
  const isUploading = useEditorRefStore(state => state.isUploading);
  const setIsUploading = useEditorRefStore(state => state.setIsUploading);
  const isImageTextProcessingRef = useRef(false);

  // 保存圖片到本地（離線狀態）
  const saveImageLocally = async (file: File): Promise<string> => {
    try {
      const reader = new FileReader();
      return new Promise((resolve, reject) => {
        reader.onload = (event) => {
          const base64Data = event.target!.result as string;
          resolve(base64Data);
        };
        reader.onerror = (error) => {
          reject(error);
        };
        reader.readAsDataURL(file);
      });
    } catch (error) {
      console.error('保存圖片到本地失敗:', error);
      throw error;
    }
  };

  const updateNoteImages = useCallback((note: any, newImageUrl: string, isLocalImage = false) => {
    if (!note) return;

    if (selectedNote?.id === note.id) {
      setSelectedNote((prevNote: any) => {
        if (isLocalImage) {
          let currentImageUrlLocal = prevNote.imageUrl_local && Array.isArray(prevNote.imageUrl_local) ? prevNote.imageUrl_local : [];
          return {
            ...prevNote,
            imageUrl_local: [...currentImageUrlLocal, newImageUrl],
          };
        } else {
          let currentImgURLs = prevNote.imgURLs && Array.isArray(prevNote.imgURLs) ? prevNote.imgURLs : [];
          let currentImgTexts = prevNote.imgTexts && Array.isArray(prevNote.imgTexts) ? prevNote.imgTexts : [];
          return {
            ...prevNote,
            imgURLs: [...currentImgURLs, newImageUrl],
            imgTexts: [...currentImgTexts, ''],
          };
        }
      });
    }
  }, [selectedNote?.id, setSelectedNote]);

  // 取得安全的 editor 實例
  const getValidEditor = useCallback(() => {
    if (editor && !editor.isDestroyed) return editor;
    if (editor?.isDestroyed && typeof ref === 'object' && (ref?.current as any)?.getEditor) {
      const fallback = (ref!.current as any).getEditor();
      if (fallback && !fallback.isDestroyed) return fallback;
    }
    return null;
  }, [editor, ref]);

  // 處理離線圖片上傳
  const handleOfflineImageUpload = useCallback(async (file: File, position: number | null = null) => {
    try {
      const localImageData = await saveImageLocally(file);

      const currentEditor = getValidEditor();
      if (currentEditor) {
        if (typeof position === 'number') {
          currentEditor.chain()
            .focus()
            .setTextSelection(position)
            .setImage({ src: localImageData })
            .insertContent({ type: 'paragraph' })
            .run();
        } else {
          currentEditor.chain()
            .focus()
            .setImage({ src: localImageData })
            .insertContent({ type: 'paragraph' })
            .run();
        }
      } else {
        console.error('[handleOfflineImageUpload] 無法獲取有效的編輯器實例');
      }

      updateNoteImages(selectedNote, localImageData, true);

      useTempHintStore.getState().setTempHint('離線狀態，保存圖片到本地，連線後將自動上傳');
    } catch (error) {
      console.error('離線保存圖片失敗:', error);
      throw error;
    }
  }, [getValidEditor, selectedNote, updateNoteImages]);

  // 處理圖片上傳
  const handleImageUpload = useCallback(async (file: File, position: number | null = null) => {
    if (!file) return;

    try {
      const validation = validateFile(file, 'images', 10 * 1024 * 1024);
      if (!validation.isValid) {
        const errorMsg = validation.errors.join('，') || t('imageUploadFailed');
        useTempHintStore.getState().setTempHint(errorMsg);
        return;
      }

      const userData = JSON.parse(localStorage.getItem('userData_local')!);
      if (!userData?.ID) {
        useTempHintStore.getState().setTempHint(t('pleaseLoginFirst'));
        return;
      }

      setIsUploading(true);

      const connected = useIsConnectedStore.getState().isConnected;
      if (connected) {
        try {
          const imageCompressOptions = {
            maxWidth: 1920,
            maxHeight: 1920,
            quality: 0.8,
            maxSizeKB: 2048,
            outputFormat: 'image/jpeg'
          };

          const uploadResult = await uploadFile(file, userData.ID, 'images', imageCompressOptions);

          if (uploadResult.downloadURL && editor) {
            const currentEditor = getValidEditor();

            if (currentEditor) {
              if (typeof position === 'number') {
                currentEditor.chain()
                  .focus()
                  .setTextSelection(position)
                  .setImage({ src: uploadResult.downloadURL })
                  .insertContent({ type: 'paragraph' })
                  .run();
              } else {
                currentEditor.chain()
                  .focus()
                  .setImage({ src: uploadResult.downloadURL })
                  .insertContent({ type: 'paragraph' })
                  .run();
              }
            } else {
              console.error('[handleImageUpload] 無法獲取有效的編輯器實例');
            }

            updateNoteImages(selectedNote, uploadResult.downloadURL);
            setIsUploading(false);

            try {
              const hasTitle = !!(selectedNote?.name && selectedNote.name.trim());
              const hasAiTitle = !!(selectedNote?.aiTitle && selectedNote.aiTitle.trim());
              if (!hasTitle && !hasAiTitle) {
                const themeRes = await imgUrlToTheme(uploadResult.downloadURL);
                const themeText = themeRes?.theme?.trim();
                if (themeText) {
                  if (selectedNote.id === resolvedNoteId) {
                    setSelectedNote((prevNote: any) => ({ ...prevNote, aiTitle: themeText }));
                    onFieldsChangeSilent({ aiTitle: themeText });
                  } else {
                    const si = useItemStore.getState().getById(selectedNote.id);
                    if (si) {
                      await useItemStore.getState().upsertItem(
                        { ...si, aiTitle: themeText, updatedAt: Date.now() } as any,
                        { needSync: true }
                      );
                    }
                  }
                }
              }
            } catch (err) {
              console.error('圖像主題辨識失敗', err);
            }
          }
        } catch (uploadError) {
          if (isWeb) {
            useTempHintStore.getState().setTempHint(t('imageUploadFailed'));
          } else {
            await handleOfflineImageUpload(file, position);
          }
        }
      } else {
        if (isWeb) {
          useTempHintStore.getState().setTempHint(t('pleaseCheckNetwork'));
        } else {
          await handleOfflineImageUpload(file, position);
        }
      }
    } catch (error) {
      console.error('處理圖片失敗:', error);
      useTempHintStore.getState().setTempHint('處理失敗，請稍後再試');
    } finally {
      setIsUploading(false);
    }
  }, [editor, getValidEditor, selectedNote, resolvedNoteId, setSelectedNote, onFieldsChangeSilent, safeSetTimeout, updateNoteImages, handleOfflineImageUpload, t]);

  // 處理圖片選擇
  const handleImageSelect = useCallback(async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;

    input.onchange = async (event) => {
      const files = Array.from((event.target as HTMLInputElement).files!);
      for (const file of files) {
        if (file) {
          await handleImageUpload(file);
        }
      }
      setAddMenuState((prev: any) => ({ ...prev, show: false }));
    };

    input.click();
  }, [handleImageUpload, setAddMenuState]);

  // 自動上傳本地圖片
  const uploadLocalImages = useCallback(async (uploadLocalImagesNoteId: string) => {
    if (!selectedNote || !selectedNote.imageUrl_local || !isConnected) {
      return;
    }

    try {
      setIsUploading(true);

      const userData = JSON.parse(localStorage.getItem('userData_local')!);
      if (!userData?.ID) {
        console.error('找不到用戶資料，無法上傳本地圖片');
        return;
      }

      let localImages: string[] = [];
      localImages = selectedNote.imageUrl_local && Array.isArray(selectedNote.imageUrl_local) ?
        selectedNote.imageUrl_local : [];

      const uploadPromises = localImages.map(async (localImageUrl: string) => {
        try {
          const response = await fetch(localImageUrl);
          const blob = await response.blob();
          const file = new File([blob], 'local-image.jpg', { type: blob.type });

          const imageCompressOptions = {
            maxWidth: 1920,
            maxHeight: 1920,
            quality: 0.8,
            maxSizeKB: 2048,
            outputFormat: 'image/jpeg'
          };

          const uploadResult = await uploadFile(file, userData.ID, 'images', imageCompressOptions);
          return {
            localUrl: localImageUrl,
            cloudUrl: uploadResult.downloadURL
          };
        } catch (error) {
          console.error('上傳單個圖片失敗:', error);
          return null;
        }
      });

      const uploadResults = await Promise.all(uploadPromises);
      const successfulUploads = uploadResults.filter((result): result is { localUrl: string; cloudUrl: string } => result !== null);

      if (successfulUploads.length > 0) {
        if (resolvedNoteId === uploadLocalImagesNoteId) {
          let updatedContent = selectedNote.content;
          let updatedImgURLs: string[] = [];
          let updatedImgTexts: string[] = [];

          updatedImgURLs = selectedNote.imgURLs && Array.isArray(selectedNote.imgURLs) ? selectedNote.imgURLs : [];
          updatedImgTexts = selectedNote.imgTexts && Array.isArray(selectedNote.imgTexts) ? selectedNote.imgTexts : [];

          successfulUploads.forEach(({ localUrl, cloudUrl }) => {
            updatedContent = updatedContent.replace(localUrl, cloudUrl);
            updatedImgURLs.push(cloudUrl);
            updatedImgTexts.push("imgText");
          });

          editor.commands.setContent(markdownToHtml(updatedContent));

          setSelectedNote({
            ...selectedNote,
            content: updatedContent,
            imgURLs: updatedImgURLs,
            imgTexts: updatedImgTexts,
            imageUrl_local: null,
          });

          setIsUploading(false);
          try {
            const hasTitle = !!(selectedNote?.name && selectedNote.name.trim());
            const hasAiTitle = !!(selectedNote?.aiTitle && selectedNote.aiTitle.trim());
            if (!hasTitle && !hasAiTitle) {
              const themeRes = await imgUrlToTheme(updatedImgURLs[0]);
              const themeText = themeRes?.theme?.trim();
              if (themeText) {
                if (selectedNote.id === resolvedNoteId) {
                  const finishedAPIs = selectedNote.finishedAPIs || [];
                  if (!finishedAPIs.includes('imgurl_to_theme')) {
                    finishedAPIs.push('imgurl_to_theme');
                  }
                  setSelectedNote((prevNote: any) => ({ ...prevNote, aiTitle: themeText, finishedAPIs: finishedAPIs }));
                  onFieldsChangeSilent({ aiTitle: themeText, finishedAPIs: finishedAPIs });
                } else {
                  const savedFinishedAPIs: string[] = selectedNote.finishedAPIs || [];
                  if (!savedFinishedAPIs.includes('imgurl_to_theme')) {
                    savedFinishedAPIs.push('imgurl_to_theme');
                  }
                  const si2 = useItemStore.getState().getById(selectedNote.id);
                  if (si2) {
                    await useItemStore.getState().upsertItem(
                      { ...si2, aiTitle: themeText, finishedAPIs: savedFinishedAPIs } as any,
                      { needSync: false }
                    );
                  }
                }
              }
            }
          } catch (err) {
            console.error('本地圖片上傳後，圖像主題辨識失敗', err);
          }
        }
      }
    } catch (error) {
      console.error('自動上傳本地圖片失敗:', error);
    } finally {
      setIsUploading(false);
    }
  }, [editor, selectedNote, resolvedNoteId, isConnected, setSelectedNote, onFieldsChangeSilent, safeSetTimeout]);

  // 監聽 MarkdownClipboard 貼上圖片事件
  useEffect(() => {
    if (editor) {
      const handleSetIsUploading = (event: any) => {
        setIsUploading(event.detail.isUploading);
      };

      const handleImageUploaded = (event: any) => {
        const { imageUrl, isLocal = false } = event.detail;
        if (selectedNote && imageUrl && editor) {
          updateNoteImages(selectedNote, imageUrl, isLocal);
        }
      };

      const editorElement = document.querySelector('.note-editor');
      if (editorElement) {
        editorElement.addEventListener('setIsUploading', handleSetIsUploading);
        editorElement.addEventListener('imageUploaded', handleImageUploaded);
      }

      return () => {
        if (editorElement) {
          editorElement.removeEventListener('setIsUploading', handleSetIsUploading);
          editorElement.removeEventListener('imageUploaded', handleImageUploaded);
        }
      };
    }
  }, [editor, selectedNote, updateNoteImages]);

  // 當選中的筆記改變時，檢查是否需要上傳本地圖片
  useEffect(() => {
    if (selectedNote && selectedNote.imageUrl_local && isConnected) {
      uploadLocalImages(selectedNote.id);
    }
  }, [selectedNote?.id, selectedNote?.imageUrl_local, isConnected]);

  // 當選中的筆記改變時，檢查是否需要圖片辨識
  useEffect(() => {
    if (!isConnected) return;
    if (isImageTextProcessingRef.current) return;
    isImageTextProcessingRef.current = true;

    const processImageRecognition = async () => {
      try {
        if (selectedNote && selectedNote.imgURLs) {
          if (selectedNote?.imgURLs &&
            selectedNote?.imgTexts &&
            selectedNote?.imgURLs.length > 0) {
            if (selectedNote?.imgURLs.length > selectedNote?.imgTexts.length) {
              selectedNote.imgTexts = selectedNote.imgTexts.fill("imgText", selectedNote.imgURLs.length);
            }

            const noteIdBeforeAIAPI = selectedNote?.id;
            for (let i = 0; i < selectedNote?.imgTexts.length; i++) {
              if (selectedNote?.imgTexts[i] === "" || selectedNote?.imgTexts[i] === 'imgText') {
                try {
                  const response = await (window as any).electronAPI.fetchImage({
                    url: selectedNote.imgURLs[i]
                  });

                  if (!response.ok) {
                    throw new Error(`圖片獲取失敗: HTTP ${response.status}`);
                  }

                  const binaryString = atob(response.data);
                  const bytes = new Uint8Array(binaryString.length);
                  for (let j = 0; j < binaryString.length; j++) {
                    bytes[j] = binaryString.charCodeAt(j);
                  }
                  const blob = new Blob([bytes], { type: response.contentType });

                  const result = await imageToText(selectedNote.imgURLs[i], blob);

                  if (result && result.content) {
                    if (resolvedNoteId === noteIdBeforeAIAPI) {
                      onFieldsChangeSilent({
                        imgTexts: (() => {
                          const updatedImgTexts = [...(selectedNote?.imgTexts || [])];
                          if (updatedImgTexts.length > i) {
                            updatedImgTexts[i] = result.content;
                          }
                          return updatedImgTexts;
                        })()
                      });
                    } else {
                      const latestNote = await (window as any).electronAPI.getItem(noteIdBeforeAIAPI);
                      if (latestNote) {
                        const updatedImgTexts = [...(latestNote.imgTexts || [])];
                        if (updatedImgTexts.length > i) {
                          updatedImgTexts[i] = result.content;
                        }
                        await useItemStore.getState().upsertItem({ ...latestNote, imgTexts: updatedImgTexts, itemType: 'NOTE' }, { needSync: true });
                      }
                    }
                  }
                } catch (error) {
                  console.error('圖片辨識失敗:', error);
                }
              }
            }
          }
        }
      } catch (error) {
        console.error('圖片辨識處理失敗:', error);
      } finally {
        isImageTextProcessingRef.current = false;
      }
    };

    processImageRecognition();
  }, [selectedNote?.id, selectedNote?.imgURLs, selectedNote?.imgTexts, isConnected]);

  // 同步 imgURLs → imgTexts map 到 store
  useEffect(() => {
    const imgURLs = selectedNote?.imgURLs || [];
    const imgTexts = selectedNote?.imgTexts || [];

    const newMap: Record<string, string> = {};
    for (let i = 0; i < imgURLs.length; i++) {
      const url = imgURLs[i];
      const text = imgTexts[i] || '';
      if (text && text !== '' && text !== 'imgText') {
        newMap[url] = text;
      }
    }

    useMaterialModeStore.getState().setImageTextMap(newMap);
  }, [selectedNote?.id, selectedNote?.imgURLs, selectedNote?.imgTexts]);

  return {
    isUploading,
    setIsUploading,
    handleImageUpload,
    handleImageSelect,
    uploadLocalImages,
    updateNoteImages,
    isImageTextProcessingRef,
  };
}
