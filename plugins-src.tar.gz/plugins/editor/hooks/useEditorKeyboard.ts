import { useEffect } from 'react';
import i18n from '../../../../i18n/config';
import { useDialogStore } from '../../../../Store/dialogStore';
import { useMaterialModeStore } from '../editorStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { handleListTab } from '../extensions/ListUtils';
import { useCommandManager } from '../../../../Store/commandManager';

interface UseEditorKeyboardParams {
  editor: any;
  selectedNote: any;
  isReadOnlyMode: boolean;
  safeSetTimeout: (fn: () => void, ms: number) => void;
}

export function useEditorKeyboard({ editor, selectedNote, isReadOnlyMode, safeSetTimeout }: UseEditorKeyboardParams) {
  // 【移動端修復】監聽自定義事件來處理列表內的 Enter 換行
  useEffect(() => {
    if (!editor) return;

    const handleMobileSplitListItem = (event) => {
      const { listItemType } = event.detail;

      if (listItemType === 'taskItem') {
        editor.commands.splitListItem('taskItem');
      } else if (listItemType === 'listItem') {
        editor.commands.splitListItem('listItem');
      }
    };

    document.addEventListener('mobile-split-list-item', handleMobileSplitListItem);

    return () => {
      document.removeEventListener('mobile-split-list-item', handleMobileSplitListItem);
    };
  }, [editor]);

  // 編輯器快捷鍵 — commandManager 統一管理
  useEffect(() => {
    if (!editor) return;

    // 輔助函數：檢查光標是否在編輯器的第一個段落開頭
    const isAtFirstParagraphStart = (editorElement) => {
      if (!editorElement || !editor) return false;
      const domSelection = window.getSelection();
      if (domSelection && domSelection.rangeCount > 0) {
        const range = domSelection.getRangeAt(0);
        let node = range.startContainer;
        while (node && node !== editorElement) {
          if (node.nodeName === 'TABLE' || node.nodeName === 'TD' || node.nodeName === 'TH' ||
            (node as HTMLElement).classList?.contains('tableWrapper')) {
            return false;
          }
          node = node.parentNode;
        }
      }
      const { selection } = editor.state;
      const { from } = selection;
      if (from <= 1) return true;
      if (!domSelection || domSelection.rangeCount === 0) {
        return document.activeElement === editorElement && from <= 1;
      }
      const range = domSelection.getRangeAt(0);
      const paragraphs = Array.from(editorElement.childNodes).filter(
        (node: any) => node.nodeName === 'P' || node.nodeName === 'UL' || node.nodeName === 'OL' ||
          node.nodeName === 'H1' || node.nodeName === 'H2' || node.nodeName === 'H3' ||
          node.nodeName === 'TABLE' || node.classList?.contains('tableWrapper')
      );
      if (paragraphs.length === 0) return true;
      let currentNode = range.startContainer;
      if (currentNode.nodeType === Node.TEXT_NODE) currentNode = currentNode.parentNode;
      if (range.startOffset === 0) {
        let node = currentNode;
        while (node && node !== editorElement) {
          if (node.nodeName === 'LI') {
            const list = node.parentNode;
            if (node === list.firstElementChild) {
              const topLevelParagraph = (list as HTMLElement).closest('p, ul, ol, h1, h2, h3');
              if (topLevelParagraph === paragraphs[0]) return true;
            }
            return false;
          }
          if (node.nodeName === 'P' || node.nodeName === 'H1' || node.nodeName === 'H2' || node.nodeName === 'H3') {
            return node === paragraphs[0];
          }
          node = node.parentNode;
        }
      }
      const firstParagraph = paragraphs[0];
      return currentNode === firstParagraph && range.startOffset === 0;
    };

    // 輔助：忽略 MiniEditor 內的鍵盤事件，用於 checkCallback
    const isInMiniEditor = () => {
      const active = document.activeElement;
      return active && (active as HTMLElement).closest?.('.mini-editor-container');
    };

    const cm = useCommandManager.getState();

    // Tab
    const unsubTab = cm.register({
      command: {
        id: 'editor:tab',
        name: i18n.t('cmd.editorTab'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          const editorContent = document.querySelector('.ProseMirror');
          if (editorContent !== document.activeElement || !editor) return false;
          const { from, to } = editor.state.selection;
          if (from !== to) return false; // 有選區時不處理 Tab 縮排
          if (!checking) {
            if (handleListTab(editor, { shiftKey: false } as any, from)) return;
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Tab' }],
    });

    // Cmd+F 搜索
    const unsubSearch = cm.register({
      command: {
        id: 'editor:search',
        name: i18n.t('cmd.editorSearch'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          if (!checking) {
            let selectedText = '';
            if (editor) {
              const { from, to } = editor.state.selection;
              selectedText = editor.state.doc.textBetween(from, to).trim();
            }
            useDialogStore.getState().open('searchReplace', { searchText: selectedText, editor });
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: ['Mod'], key: 'f' }],
    });

    // Cmd+R AI改寫
    const unsubRewrite = cm.register({
      command: {
        id: 'editor:ai-rewrite',
        name: i18n.t('cmd.editorAiRewrite'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          if (!checking) {
            const currentAIRewriteMode = useMaterialModeStore.getState().isAIRewriteMode;
            useMaterialModeStore.getState().setisAIRewriteMode(!currentAIRewriteMode);
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: ['Mod'], key: 'r' }],
    });

    // Escape
    const unsubEscape = cm.register({
      command: {
        id: 'editor:escape',
        name: i18n.t('cmd.editorEscape'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          // 對話框 → 不處理
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          if (hasOpenDialog) return false;
          // 素材庫 → 關閉
          const showMaterialLibrary = useMaterialModeStore.getState().showMaterialLibrary;
          if (showMaterialLibrary) {
            if (!checking) {
              useMaterialModeStore.getState().setisMaterialMode(false);
              useMaterialModeStore.getState().setisImageTextMode(false);
              useMaterialModeStore.getState().setisAIRewriteMode(false);
              useMaterialModeStore.getState().setKeepImageModeOpen(false);
            }
            return true;
          }
          // 只讀模式 → 消費但不做事
          if (isReadOnlyMode) return true;
          // 素材模式 → 關閉
          const isMaterialModeFromStore = useMaterialModeStore.getState().isMaterialMode;
          if (isMaterialModeFromStore) {
            if (!checking) useMaterialModeStore.getState().setisMaterialMode(false);
            return true;
          }
          // 選區 → 不處理
          const isEditorActive = editor && !editor.state.selection.empty;
          if (isEditorActive) return false;
          // 退出編輯
          if (!checking) {
            if (document.activeElement !== document.body) {
              (document.activeElement as HTMLElement)?.blur();
            }
            useSelectedItemsStore.getState().navigateOut();
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });

    // ArrowUp — 從編輯器第一行到標題
    const unsubArrowUp = cm.register({
      command: {
        id: 'editor:arrow-up-to-title',
        name: i18n.t('cmd.editorArrowUpToTitle'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          const hasOpenToolbar = document.querySelector('.floating-toolbar');
          if (hasOpenDialog || hasOpenToolbar) return false;
          const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
          const titleInput = document.querySelector('.editor-title') as HTMLInputElement;
          if (!editorContent || document.activeElement !== editorContent) return false;
          if (!isAtFirstParagraphStart(editorContent)) return false;
          if (!checking && titleInput) {
            titleInput.focus();
            titleInput.selectionStart = titleInput.selectionEnd = titleInput.value.length;
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'ArrowUp' }],
    });

    // ArrowDown — 從標題到編輯器
    const unsubArrowDown = cm.register({
      command: {
        id: 'editor:arrow-down-to-editor',
        name: i18n.t('cmd.editorArrowDownToEditor'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          const hasOpenToolbar = document.querySelector('.floating-toolbar');
          if (hasOpenDialog || hasOpenToolbar) return false;
          const titleInput = document.querySelector('.editor-title') as HTMLInputElement;
          const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
          if (!titleInput || document.activeElement !== titleInput) return false;
          const isComposing = titleInput.getAttribute('data-composing') === 'true';
          if (isComposing) return false;
          if (!checking && editorContent) {
            editorContent.focus();
            const selection = window.getSelection();
            const range = document.createRange();
            range.setStart(editorContent.firstChild || editorContent, 0);
            range.collapse(true);
            selection.removeAllRanges();
            selection.addRange(range);
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'ArrowDown' }],
    });

    // Delete/Backspace — 從空內容編輯器跳到標題
    const unsubDelete = cm.register({
      command: {
        id: 'editor:delete-to-title',
        name: i18n.t('cmd.editorDeleteToTitle'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          const hasOpenToolbar = document.querySelector('.floating-toolbar');
          if (hasOpenDialog || hasOpenToolbar) return false;
          const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
          const titleInput = document.querySelector('.editor-title') as HTMLInputElement;
          if (!editorContent || document.activeElement !== editorContent) return false;
          if (!isAtFirstParagraphStart(editorContent)) return false;
          const editorHTML = editor.getHTML();
          const cleanedContent = editorHTML.replace(/<p><\/p>/g, '').replace(/<p>\s*<\/p>/g, '').trim();
          const isContentEmpty = cleanedContent === '' || cleanedContent === '<p></p>';
          if (!isContentEmpty) return false;
          if (!checking && titleInput) {
            titleInput.focus();
            titleInput.selectionStart = titleInput.selectionEnd = titleInput.value.length;
          }
          return true;
        },
      },
      hotkeys: [
        { modifiers: [], key: 'Delete' },
        { modifiers: [], key: 'Backspace' },
      ],
    });

    // ArrowLeft — 從編輯器開頭跳到列表/待辦
    const unsubArrowLeft = cm.register({
      command: {
        id: 'editor:arrow-left-exit',
        name: i18n.t('cmd.editorArrowLeftExit'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          const hasOpenToolbar = document.querySelector('.floating-toolbar');
          if (hasOpenDialog || hasOpenToolbar) return false;
          const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
          const titleInput = document.querySelector('.editor-title') as HTMLInputElement;
          // 編輯器最初位置 → blur
          if (editorContent && document.activeElement === editorContent) {
            if (!isAtFirstParagraphStart(editorContent)) return false;
            if (!checking) {
              (document.activeElement as HTMLElement)?.blur();
              const isTodo = selectedNote?.itemType === 'TODO';
              if (selectedNote && isTodo) {
                if (!document.activeElement?.classList.contains('todo-title-input')) {
                  safeSetTimeout(() => {
                    const todoInput = document.querySelector(`[data-id="${selectedNote.id}"] .todo-title-input`) as HTMLElement;
                    if (todoInput) todoInput.focus();
                  }, 50);
                } else {
                  useSelectedItemsStore.getState().setSelectedItems([]);
                }
              }
            }
            return true;
          }
          // 標題輸入框最前面 → blur
          if (titleInput && document.activeElement === titleInput) {
            if (titleInput.selectionStart !== 0 || titleInput.selectionEnd !== 0) return false;
            if (!checking) {
              (document.activeElement as HTMLElement)?.blur();
              const isTodo = selectedNote?.itemType === 'TODO';
              if (selectedNote && isTodo) {
                if (!document.activeElement?.classList.contains('todo-title-input')) {
                  safeSetTimeout(() => {
                    const todoInput = document.querySelector(`[data-id="${selectedNote.id}"] .todo-title-input`) as HTMLElement;
                    if (todoInput) todoInput.focus();
                  }, 50);
                } else {
                  useSelectedItemsStore.getState().setSelectedItems([]);
                }
              }
            }
            return true;
          }
          return false;
        },
      },
      hotkeys: [{ modifiers: [], key: 'ArrowLeft' }],
    });

    // ArrowRight — 從標題跳到編輯器
    const unsubArrowRight = cm.register({
      command: {
        id: 'editor:arrow-right-to-editor',
        name: i18n.t('cmd.editorArrowRightToEditor'),
        checkCallback: (checking: boolean) => {
          if (isInMiniEditor()) return false;
          const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
          const hasOpenToolbar = document.querySelector('.floating-toolbar');
          if (hasOpenDialog || hasOpenToolbar) return false;
          const titleInput = document.querySelector('.editor-title') as HTMLInputElement;
          const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
          if (!titleInput || document.activeElement !== titleInput) return false;
          if (titleInput.selectionStart !== titleInput.value.length || titleInput.selectionEnd !== titleInput.value.length) return false;
          if (!checking && editorContent) {
            editorContent.focus();
            const selection = window.getSelection();
            const range = document.createRange();
            const firstNode = editorContent.firstChild || editorContent;
            range.setStart(firstNode, 0);
            range.collapse(true);
            selection.removeAllRanges();
            selection.addRange(range);
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'ArrowRight' }],
    });

    // 標題 Enter/Tab → 聚焦編輯器（使用 keydown observer 不消費事件）
    const unsubTitleEnter = cm.registerKeyObserver({
      id: 'editor:title-enter',
      keys: ['Enter', 'Tab'],
      onDown: (key) => {
        const target = document.activeElement;
        if (!target || !(target as HTMLElement).classList.contains('editor-title')) return;
        const isComposing = (target as HTMLElement).getAttribute('data-composing') === 'true';
        if (!isComposing || key === 'Tab') {
          editor.commands.focus('start');
        }
      },
    });

    return () => {
      unsubTab();
      unsubSearch();
      unsubRewrite();
      unsubEscape();
      unsubArrowUp();
      unsubArrowDown();
      unsubDelete();
      unsubArrowLeft();
      unsubArrowRight();
      unsubTitleEnter();
    };
  }, [editor, selectedNote]);
}
