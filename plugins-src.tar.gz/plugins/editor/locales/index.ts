import i18n from '../../../../i18n/config';
import en from './en.json';
import zhHant from './zh-Hant.json';
import ja from './ja.json';

i18n.addResourceBundle('en', 'translation', en, true, true);
i18n.addResourceBundle('zh-Hant', 'translation', zhHant, true, true);
i18n.addResourceBundle('zh', 'translation', zhHant, true, true);
i18n.addResourceBundle('zh-TW', 'translation', zhHant, true, true);
i18n.addResourceBundle('ja', 'translation', ja, true, true);
