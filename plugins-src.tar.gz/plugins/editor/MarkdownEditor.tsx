import React, { useState, useEffect, useCallback, useRef, forwardRef, useImperativeHandle } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import { useEditor, EditorContent } from '@tiptap/react';
import { TextSelection } from '@tiptap/pm/state';
import StarterKit from '@tiptap/starter-kit';
import { Placeholder } from '@tiptap/extension-placeholder';
import { TaskList } from '@tiptap/extension-task-list';
import { TaskItem } from '@tiptap/extension-task-item';
import './NoteEditor.css';

import './NoteEditorToolbar.css';
import './NoteEditorTable.css';
import '../../common/BasicComponents.css';
import { Extension } from '@tiptap/core';
import { MarkdownClipboard } from './extensions/MarkdownClipboard';
import { CodeBlockCopy } from './extensions/CodeBlockCopy';

import { Highlight } from '@tiptap/extension-highlight';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import { NodeSelection } from 'prosemirror-state';
import { ImageExtension } from './extensions/ImageExtension';
import { Dropcursor } from '@tiptap/extension-dropcursor';

import ImagePreviewWindow from '../../common/ImagePreviewWindow';
import { useTheme } from '../../setting/ThemeProvider';


import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableHeader } from '@tiptap/extension-table-header';
import { TableCell } from '@tiptap/extension-table-cell';
import AddUrlDialog from './AddUrlDialog';
import { EditorRightClickMenu, TableDragHandleClickMenu } from './NoteEditorMenu';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMaterialModeStore, useEditorRefStore } from './editorStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useIsConnectedStore, useTempHintStore } from '../../../Store/uiStore';

import { eventBus } from '../../../Store/eventBus';
import { useItemStore } from '../../../Store/itemStore';
import DragOverlay from '../../common/DragOverlay';
import SearchReplaceDialog from './SearchReplaceDialog';
import TableSizeSelector from './TableSizeSelector';
import AddMenu from './AddMenu';
import WebPreviewDecoration from './extensions/WebPreviewDecoration';
import './WebPreviewCard.css';


import useWhyDidYouUpdate from '../../../utils/useWhyDidYouUpdate';
import { IndentExtension } from './extensions/IndentExtension';
import { DragHandleExtension } from './extensions/DragHandleExtension.jsx';
import { TableDragHandleExtension } from './extensions/TableDragHandleExtension.jsx';
import { CustomKeyboardShortcuts } from './extensions/CustomKeyboardShortcuts';
import { convertContentColors } from './extensions/NoteEditorColorUtils';
import { rewriteHighlightKey, RewriteHighlightExtension } from './extensions/RewriteHighlight';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { isWeb } from '../../../utils/platform';
import { handleListChange } from './extensions/ListUtils';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { HistoryManager } from './extensions/HistoryManager';
import './NoteLinkTag.css';
import { useEditorExtensionRegistry } from '../../../Store/editorExtensionRegistry';
import './TemplateLinkPreview.css';
import { htmlToMarkdown, markdownToHtml } from '../../../utils/mdConverter';
import { useWebsitePreview } from './hooks/useWebsitePreview';
import { useNoteActions } from './hooks/useNoteActions';
import { useImageUpload } from './hooks/useImageUpload';
import { useAIProcessing } from './hooks/useAIProcessing';
import { useLinkHandler } from './hooks/useLinkHandler';
import { useEditorKeyboard } from './hooks/useEditorKeyboard';
import { canEdit } from '../../../utils/shareUtils';

// ===== 輔助型別宣告 =====
interface WebsiteTextResult {
  title: string | null;
  content: string | null;
  imageUrl: string | null;
}

// ProseMirror EditorView 含私有 patch 屬性的擴展型別
interface PatchedEditorView {
  __scrollLogPatched?: boolean;
  scrollToSelection: () => void;
}

// editor 含動態函數屬性的擴展型別（用於 handleListChange 綁定）
interface EditorWithListChange {
  _handleListChange?: (listType: string) => void;
}

// 表格拖曳手把選單的資料型別
interface TableHandleMenuData {
  tablePos: number | null;
  tableElement?: HTMLElement | null;
}


const MarkdownEditor = forwardRef(function MarkdownEditor(
  { noteId, mode = 'normal', selectedNote, setSelectedNote, onFieldsChange, onFieldsChangeSilent }: {
    noteId: string | null;
    mode?: string;
    selectedNote: any;
    setSelectedNote: React.Dispatch<React.SetStateAction<any>>;
    onFieldsChange: (fields: Record<string, any>) => void;
    onFieldsChangeSilent: (fields: Record<string, any>) => void;
  },
  ref
) {
  const { t } = useTranslation();

  // ===== note 狀態：由 NoteEditor 管理，透過 props 傳入 =====
  const isReadOnlyMode = (mode !== 'normal' && mode !== 'window' && mode !== 'material')
    || (selectedNote && !canEdit(selectedNote));

  // 直接使用傳入的 noteId（由 NoteEditor 容器計算）
  const resolvedNoteId = noteId;

  // 為每個編輯器實例創建獨立的 historyManager
  const editorInstanceId = useRef(`editor_${Date.now()}_${Math.random()}`).current;
  const historyManagerRef = useRef(null);
  if (!historyManagerRef.current) {
    // 創建 HistoryManager 實例
    historyManagerRef.current = new HistoryManager(100, 300, editorInstanceId);
  }
  const historyManager = historyManagerRef.current;
  // 設置 historyManager 到 store，讓 Toolbar 等子元件可以讀取
  useEffect(() => {
    useEditorRefStore.getState().setHistoryManager(historyManager);
    // 注入 history 變更通知 callback，讓 Topbar 能響應式更新
    historyManager.onHistoryChange = () => {
      useEditorRefStore.getState().bumpHistoryVersion();
    };
  }, [historyManager]);

  // aiserver404Ref, isAIAPIProcessingRef, lastAISelectionRef → useAIProcessing hook
  const selectedNoteRef = useRef(null); // 【Tiptap 3.x 修復】用於在 onUpdate 閉包中獲取最新 selectedNote
  const editorJustCreatedRef = useRef(false);
  const lastEditorMdRef = useRef<string | null>(null);

  const theme = useTheme();
  const isMobileView = useIsMobileView();

  const isConnected = useIsConnectedStore(state => state.isConnected);

  // 添加圖片預覽相關狀態
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [previewImageSrc, setPreviewImageSrc] = useState('');
  // 添加表格相關狀態
  const [showTableSizeSelector, setShowTableSizeSelector] = useState(false);
  const [tableSelectorPosition, setTableSelectorPosition] = useState({ top: 0, left: 0 });
  const [showTableHandleMenu, setShowTableHandleMenu] = useState(false);
  const [tableHandleMenuPosition, setTableHandleMenuPosition] = useState<{ x?: number; y?: number; top?: number; left?: number }>({
    top: 0, left: 0
  });
  const [tableHandleMenuData, setTableHandleMenuData] = useState<TableHandleMenuData>({ tablePos: null });

  const [reloadTrigger, setReloadTrigger] = useState(0);
  useEffect(() => {
    const unsub = eventBus.on('editor:force-reload', () => setReloadTrigger(k => k + 1));
    return unsub;
  }, []);

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  // ------- AddMenu local state (replace global store) -------
  // DragOverlay 純 UI：由拖曳方推送 overlay 的 icon/text
  const [overlayProps, setOverlayProps] = useState<{ icon?: React.FC; text?: string } | null>(null);

  const [addMenuState, setAddMenuState] = useState({
    show: false,
    position: { top: 0, left: 0 },
    addButtonRef: null,
  });


  // 【Tiptap 3.x 修復】同步 selectedNote 到 ref，讓 onUpdate 閉包能獲取最新值
  useEffect(() => {
    selectedNoteRef.current = selectedNote;
  }, [selectedNote]);

  // ===== useWebsitePreview hook（Phase 4.1：網頁連結抓取與預覽）=====
  const { websiteLinksRef } = useWebsitePreview(
    resolvedNoteId, selectedNote, onFieldsChangeSilent, setSelectedNote,
  );
  // 保存 noteId 供卡片連結預覽使用（TemplateLinkPreviewExtension）
  const noteIdRef = useRef(null);
  noteIdRef.current = resolvedNoteId;


  // 當主題變化時，更新全局變量
  useEffect(() => {
    // 直接更新 root 元素的 data-theme 屬性
    document.documentElement.dataset.theme = theme.mode;
  }, [theme.mode]);


  const editor = useEditor({
    extensions: [
      Extension.create({
        name: 'customAttributes',
        addGlobalAttributes() {
          return [
            {
              types: ['paragraph', 'listItem', 'taskItem'],
              attributes: {
                tempId: {
                  default: null,
                  parseHTML: element => element.getAttribute('data-temp-id'),
                  renderHTML: attributes => {
                    if (!attributes.tempId) return {};
                    return {
                      'data-temp-id': attributes.tempId,
                    };
                  },
                },
              },
            },
          ];
        },
      }),
      StarterKit.configure({
        paragraph: {
          draggable: true,
        },
        history: false,
        hardBreak: true,
        bulletList: {
          keepMarks: true,
          keepAttributes: true,
          HTMLAttributes: {
            class: 'bullet-list'
          }
        },
        orderedList: {
          keepMarks: true,
          keepAttributes: true,
          HTMLAttributes: {
            class: 'ordered-list'
          }
        },
        heading: {
          levels: [1, 2, 3]
        },
        dropcursor: false,
        gapcursor: false,
        link: {
          HTMLAttributes: {
            class: 'editor-link',
            rel: 'noopener noreferrer',
            target: '_blank',
          },
          validate: href => {
            return /^https?:\/\//.test(href) ||
              /^(?:CubeLV|cubelv):\/\/\w+\//.test(href);
          },
          protocols: ['http', 'https', 'mailto', 'tel', 'cubelv'],
          autolink: false,
          openOnClick: false,
          linkOnPaste: true,
        },
        underline: {},
      } as any),
      Placeholder.configure({
        placeholder: t('startWriting')
      }),
      TaskList.configure({
        // @ts-expect-error: Tiptap TaskListOptions.excludes 型別定義不包含此選項
        excludes: ['bulletList', 'orderedList'],
        HTMLAttributes: {
          class: 'task-list'
        }
      }),
      // 用 CSS 偽元素替代真實 checkbox，避免瀏覽器自動填充擴展觸發無限循環
      // 原因：autofill.bundle.js 會掃描 <input> 元素並修改 DOM，觸發 MutationObserver 循環
      TaskItem.extend({
        addNodeView() {
          return ({ node, HTMLAttributes, getPos, editor }) => {
            const listItem = document.createElement('li');
            // 使用 span 而非 input，避免自動填充擴展干擾
            const checkboxWrapper = document.createElement('label');
            const fakeCheckbox = document.createElement('span');
            const content = document.createElement('div');

            checkboxWrapper.contentEditable = 'false';
            fakeCheckbox.className = 'task-fake-checkbox';

            fakeCheckbox.addEventListener('click', event => {
              event.preventDefault();
              if (typeof getPos !== 'function') return;
              editor.chain().focus().command(({ tr }) => {
                tr.setNodeMarkup(getPos(), undefined, {
                  checked: !node.attrs.checked,
                });
                return true;
              }).run();
            });

            Object.entries(HTMLAttributes).forEach(([key, value]) => {
              listItem.setAttribute(key, value);
            });

            listItem.dataset.checked = node.attrs.checked;
            if (node.attrs.checked) {
              listItem.setAttribute('data-checked', 'true');
            }

            checkboxWrapper.append(fakeCheckbox);
            listItem.append(checkboxWrapper, content);

            return {
              dom: listItem,
              contentDOM: content,
              update: updatedNode => {
                if (updatedNode.type !== node.type) return false;
                listItem.dataset.checked = updatedNode.attrs.checked;
                if (updatedNode.attrs.checked) {
                  listItem.setAttribute('data-checked', 'true');
                } else {
                  listItem.removeAttribute('data-checked');
                }
                node = updatedNode;
                return true;
              },
            };
          };
        },
      }).configure({
        nested: true,
      }),
      MarkdownClipboard.configure({
        // 如果需要的話可以添加配置選項
      }),
      CodeBlockCopy,
      CustomKeyboardShortcuts.configure({
        historyManager: historyManager
      }),

      Highlight.configure({
        multicolor: false, // 暫時不支援多色
        HTMLAttributes: {
          class: 'highlight-text'
        }
      }),
      TextStyle,
      Color,
      DragHandleExtension.configure({
        isReadOnlyMode: isReadOnlyMode
      }),
      TableDragHandleExtension.configure({
        isReadOnlyMode: isReadOnlyMode
      }),
      ImageExtension.configure({
        isReadOnlyMode: isReadOnlyMode
      } as any),
      Dropcursor.configure({
        color: 'var(--primary)',
        width: 1.5,
      }),

      Table.configure({
        resizable: true,
      }),
      TableRow,
      TableHeader,
      TableCell,
      IndentExtension,
      WebPreviewDecoration.configure({ getWebsiteLinks: () => websiteLinksRef.current }),
      RewriteHighlightExtension,
      // 從 registry 載入插件註冊的擴展（linkPreview 擴展需要 configure getNoteId）
      ...useEditorExtensionRegistry.getState().getAll().map(ext => {
        const name = (ext as any).name || '';
        if (name === 'cardLinkPreview' || name === 'chartLinkPreview') {
          return (ext as any).configure({ getNoteId: () => noteIdRef.current });
        }
        return ext;
      }),
    ],
    content: selectedNote?.content
      ? markdownToHtml(selectedNote.content)
      : '',
    // 性能優化：不在每次事務時重渲染 React 組件（ProseMirror 仍正常更新 DOM）
    shouldRerenderOnTransaction: false,
    onUpdate: ({ editor }) => {

      const newContent = editor.getHTML();
      // 處理連續空格問題：將連續空格轉換為 &nbsp; 實體
      let trimmedContent = newContent.replace(/ {2,}/g, match => {
        return Array(match.length).fill('&nbsp;').join('');
      });

      // undo/redo 觸發的 setContent 會再次觸發 onUpdate，
      // 此時不應 pushHistory，否則 redoStack 會被清空
      if (historyManager.isUndoRedoing) {
        historyManager.isUndoRedoing = false;
      } else {
        // 推入歷史記錄（同時儲存游標位置）
        historyManager.pushHistory(trimmedContent, editor.state.selection);
      }

      // 將 HTML 轉換為 Markdown 再儲存
      const mdContent = htmlToMarkdown(trimmedContent);
      lastEditorMdRef.current = mdContent;

      // 檢查 content 是否被完全清空
      const isContentEmpty = mdContent.trim() === '';

      // 【Tiptap 3.x 修復】使用 ref 獲取最新的 selectedNote，避免閉包捕獲舊值
      const currentNote = selectedNoteRef.current;

      // 如果內容被完全清空，同時清空 aiTitle 和 aiTags
      if (isContentEmpty && currentNote && (currentNote.aiTitle || currentNote.aiTags || currentNote.purpose)) {
        console.log('[MarkdownEditor onUpdate] calling setSelectedNote (empty content)', currentNote?.id);
        setSelectedNote({
          ...currentNote,
          content: mdContent,
          aiTitle: null,
          aiTags: [],
          purpose: null,
        });
      } else if (currentNote) {
        console.log('[MarkdownEditor onUpdate] calling setSelectedNote', currentNote?.id, 'content length:', mdContent?.length);
        setSelectedNote({
          ...currentNote,
          content: mdContent,
        });
      } else {
        console.log('[MarkdownEditor onUpdate] currentNote is null, NOT calling setSelectedNote');
      }
    },
    onBeforeCreate: ({ editor }) => {
    },
    onCreate: ({ editor }) => {
      editorJustCreatedRef.current = true;

      // 推入初始歷史記錄（游標位置為文檔開始）
      historyManager.pushHistory(editor.getHTML(), { from: 0, to: 0 });

      // 移動端禁用 ProseMirror 的 scrollToSelection
      // 原因：iOS Safari 有原生的頁面上推行為，ProseMirror 的滾動會干擾
      // 詳見：docs/NoteEditor 難解BUG/NoteEditor_滾動位置調整_程式碼整理.md
      const patchedView = editor.view as unknown as PatchedEditorView;
      if (editor.view && !patchedView.__scrollLogPatched) {
        const origScrollSel = patchedView.scrollToSelection.bind(editor.view);
        patchedView.scrollToSelection = function () {
          const isMobile = window.innerWidth <= 768;

          if (isMobile) {
            // 移動端：禁用 scrollToSelection，讓 iOS Safari 原生處理
            return;
          } else {
            // 桌面端：執行原始的 scrollToSelection
            return origScrollSel();
          }
        };
        patchedView.__scrollLogPatched = true;
      }

    },
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none'
      },
      handleDOMEvents: {
        // [CLICK_DEBUG] 觸摸事件監控
        touchstart: (view, event) => {
          return false;
        },
        touchend: (view, event) => {
          return false;
        },
        keydown: (view, event) => {
          // [ENTER_DEBUG] 監控 Enter 鍵事件
          if (event.key === 'Enter') {

            // 【移動端修復】在移動端直接處理 Enter 鍵
            // 因為 Tiptap 在移動端有時不觸發
            const isMobile = window.innerWidth <= 768;

            if (isMobile && !event.isComposing && !event.defaultPrevented) {
              // 檢查是否在列表內
              const { $from } = view.state.selection;
              let listItemType = null;
              for (let i = $from.depth; i > 0; i--) {
                const node = $from.node(i);
                if (node.type.name === 'taskItem') {
                  listItemType = 'taskItem';
                  break;
                } else if (node.type.name === 'listItem') {
                  listItemType = 'listItem';
                  break;
                }
              }

              // 檢查是否有打開的工具欄按鈕被聚焦
              const focusedToolbarBtn = document.querySelector('.toolbar-button.keyboard-focus');
              if (!focusedToolbarBtn) {
                // 同步執行 split，避免組字時選區閃爍
                if (listItemType) {
                  // 在列表內，發送自定義事件讓 editor 處理 splitListItem

                  const customEvent = new CustomEvent('mobile-split-list-item', {
                    detail: { listItemType }
                  });
                  document.dispatchEvent(customEvent);
                } else {
                  // 非列表，直接 dispatch 一個換行 transaction
                  const { tr } = view.state;
                  const newTr = tr.split(tr.selection.from);
                  view.dispatch(newTr);
                }
                event.preventDefault();
                return true;
              }
            }
          }

          // 检查工具栏是否显示
          const hasOpenToolbar = document.querySelector('.floating-toolbar');

          // 获取当前 focusedButtonIndex 状态
          const focusedButtonIndex = document.querySelector('.toolbar-button.keyboard-focus') ?
            Array.from(document.querySelectorAll('.toolbar-button')).findIndex(btn => btn.classList.contains('keyboard-focus')) : -1;

          if (hasOpenToolbar) {
            if (focusedButtonIndex === -1) {
              if (event.key === 'Tab') {
                return true;
              }
              if (event.key === "Escape") {
                event.preventDefault();
                // 取消圈選，將 focus 移到選區起始位置
                let { from } = view.state.selection;
                const $pos = view.state.doc.resolve(from);
                const SelectionCtor = view.state.selection.constructor as typeof TextSelection;
                const tr = view.state.tr.setSelection(
                  SelectionCtor.near($pos)
                );
                view.dispatch(tr);
                return true;
              }
            } else {
              // 当有按钮被聚焦时，锁定所有导航键
              if (event.key === 'ArrowUp' ||
                event.key === 'ArrowDown' ||
                event.key === 'ArrowLeft' ||
                event.key === 'ArrowRight' ||
                event.key === 'Enter' ||
                event.key === 'Escape' ||
                event.key === 'Tab') {

                event.preventDefault();
                return true;
              }
            }
          }

          // 移除Escape鍵處理邏輯，將其放在組件級別

          if (event.metaKey || event.ctrlKey) {
            return false;
          }
          return false;
        },
        mouseup: (view, event) => {
          const { state } = view;
          let { from, to } = state.selection;

          // 如果選區是空的，就不做任何事
          if (state.selection.empty) {
            return false;
          }

          let firstContentPos = null;
          let lastContentPos = null;
          let currentTextBlock = null;

          // 遍歷選中範圍內的所有節點
          state.doc.nodesBetween(from, to, (node, pos, parent) => {
            // 如果是文字節點且有內容
            if (node.type.name === 'text' && node.text.trim().length > 0) {
              // 如果還沒有找到第一個內容位置
              if (firstContentPos === null) {
                firstContentPos = pos;
                currentTextBlock = parent;
              }
              // 更新最後一個內容位置
              lastContentPos = pos + node.nodeSize;
            }
          });

          // 如果找到了有效的內容
          if (firstContentPos !== null && lastContentPos !== null) {
            // 確保選擇範圍在文字塊內
            if (currentTextBlock) {
              // 如果選擇開始位置在當前文字塊之前，調整到文字塊開始位置
              if (from < firstContentPos) {
                from = firstContentPos;
              }
              // 如果選擇結束位置超出最後一個內容，調整到內容結束位置
              if (to > lastContentPos) {
                to = lastContentPos;
              }
            }

            // 檢查選區是否在表格內
            let isInsideTable = false;
            const $from = state.doc.resolve(from);
            let depth = $from.depth;
            while (depth > 0) {
              const parent = $from.node(depth);
              if (parent.type.name === 'table') {
                isInsideTable = true;
                break;
              }
              depth--;
            }

            // 只有當選區不在表格內時，才更新選擇
            if (!isInsideTable && (from !== state.selection.from || to !== state.selection.to)) {
              const tr = state.tr.setSelection(TextSelection.create(state.doc, from, to));
              view.dispatch(tr);
            }
          }

          return false; // 不阻止預設行為
        },
        dblclick: (view, event) => {
          // 檢查雙擊的是否為圖片
          const target = event.target as HTMLElement;
          if (target.tagName === 'IMG' && target.classList.contains('editor-image')) {
            event.preventDefault();
            const src = target.getAttribute('src');

            // 打開圖片預覽
            setPreviewImageSrc(src);
            setShowImagePreview(true);
            return true;
          }
          return false;
        }
      },
      // 注意：attributes 已在上方定義，這裡的 class 已合併到上方
      handleClick: (view, pos, event) => {
        // 檢查點擊的是否為圖片
        const clickTarget = event.target as HTMLElement;
        if (clickTarget.tagName === 'IMG' && clickTarget.classList.contains('editor-image')) {
          event.preventDefault();

          // 找到圖片節點的實際位置
          const { state } = view;
          let imagePos = null;

          state.doc.nodesBetween(0, state.doc.content.size, (node, pos) => {
            if (node.type.name === 'image' && node.attrs.src === clickTarget.getAttribute('src')) {
              imagePos = pos;
              return false;
            }
            return true;
          });

          if (imagePos !== null) {
            // 創建圖片節點的選擇
            const tr = state.tr.setSelection(NodeSelection.create(state.doc, imagePos));
            view.dispatch(tr);
            return true;
          }
        }

        // 只在有選擇範圍時才允許轉換列表
        if (!view.state.selection.empty) {
          return false;
        }
        return true;
      },
      transformPastedText: (text) => {
        // 防止貼上時自動轉換列表
        return text;
      },
      handleDrop: (view, event, slice, moved) => {
        try {
          if (!moved && event.dataTransfer && event.dataTransfer.files) {
            const files = Array.from(event.dataTransfer.files);

            const imageFiles = files.filter(file => {
              // macOS Finder 拖曳時 file.type 可能為空字串，因此額外透過副檔名判斷
              if (file.type && file.type.startsWith('image')) return true; // MIME 類型為 image/*

              // 若無 MIME，改以副檔名比對常見圖片格式
              const ext = file.name.split('.').pop().toLowerCase();
              return ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'heic', 'heif', 'tiff', 'tif', 'svg'].includes(ext);
            });

            if (imageFiles.length > 0) {
              event.preventDefault();

              // 直接在 handleDrop 中用 view 計算位置（這個 view 是有效的）
              let calculatedPosition = null;
              try {
                const rect = view.dom.getBoundingClientRect();
                const dropCoords = {
                  left: event.clientX,
                  top: event.clientY
                };

                const pos = view.posAtCoords(dropCoords);
                if (pos) {
                  calculatedPosition = pos.pos;

                } else {

                }
              } catch (error) {

              }

              // 為了與其他圖片插入流程一致（壓縮、離線處理等），直接呼叫 handleImageUpload
              imageFiles.forEach(async (file) => {

                try {
                  await handleImageUpload(file, calculatedPosition);
                } catch (error) {
                  console.error('handleImageUpload 處理拖放圖片失敗:', error);
                }
              });

              return true;
            }
          }
        } catch (error) {
          console.error('处理拖放事件时出错:', error);
        }
        return false;
      },
    },
    editable: !isReadOnlyMode, // 只讀模式下不可編輯
  }, [selectedNote?.id]); //改回每次換id就創建，不然會有殘留bug

  // websiteContent 變化時，dispatch 空 transaction 觸發 decoration 重新計算
  useEffect(() => {
    if (editor && !editor.isDestroyed && selectedNote?.websiteContent) {
      editor.view.dispatch(editor.view.state.tr);
    }
  }, [selectedNote?.websiteContent, editor]);

  // ===== 跨視窗即時同步：偵測 selectedNote.content 外部變化，同步到 Tiptap editor =====
  useEffect(() => {
    if (!editor || editor.isDestroyed || !selectedNote?.content) return;
    // editor 剛建立時已帶有正確內容，跳過多餘的 setContent（避免 cursor 被推到結尾）
    if (editorJustCreatedRef.current) {
      lastEditorMdRef.current = selectedNote.content;
      return;
    }
    if (selectedNote.content === lastEditorMdRef.current) return;
    lastEditorMdRef.current = selectedNote.content;
    const isDarkMode = theme.mode === 'dark';
    const htmlContent = markdownToHtml(selectedNote.content);
    const convertedContent = convertContentColors(htmlContent, isDarkMode);
    editor.commands.setContent(convertedContent, { emitUpdate: false });
  }, [selectedNote?.content, selectedNote?.updatedAt, editor, theme.mode]);

  // ===== 圖片上傳 hook =====
  const {
    isUploading,
    handleImageUpload, handleImageSelect, uploadLocalImages,
    updateNoteImages, isImageTextProcessingRef,
  } = useImageUpload({
    editor, ref, selectedNote, setSelectedNote, onFieldsChangeSilent,
    resolvedNoteId, isConnected, safeSetTimeout, setAddMenuState,
  });

  // ===== AI 處理 hook =====
  const {
    resetAIServer404,
  } = useAIProcessing({
    editor, selectedNote, setSelectedNote, onFieldsChangeSilent,
    resolvedNoteId, isConnected, isReadOnlyMode, safeSetTimeout, historyManager,
  });

  useLinkHandler({ editor });
  useEditorKeyboard({ editor, selectedNote, isReadOnlyMode, safeSetTimeout });


  useWhyDidYouUpdate('NoteEditor editor', { editor });
  useWhyDidYouUpdate('NoteEditor renderer', {
    isConnected, isUploading, reloadTrigger,
    showImagePreview, previewImageSrc, showTableSizeSelector,
    tableSelectorPosition, resolvedNoteId, mode, theme,
  });

  // 修改 useEffect 來使用新的 selectedNote
  useEffect(() => {
    if (!selectedNote) {
      // 清空歷史記錄
      historyManager.clear();
      return;
    }

    // 切換筆記時清空歷史記錄
    historyManager.clear();

    // 切換筆記時關閉搜尋對話框
    const showSearchDialog = useDialogStore.getState().dialogs['searchReplace']?.show;
    if (showSearchDialog) {
      useDialogStore.getState().close('searchReplace');
    }

    //切換筆記時，重置AI伺服器404狀態
    resetAIServer404();


  }, [selectedNote?.id]);

  // linkFetchText 觸發 — 已搬入 useWebsitePreview hook


  // DragOverlay：監聽 overlay 事件，由拖曳方推送 icon/text
  useEffect(() => {
    const unsub = eventBus.on('drag:note-editor-drag-overlay', (props: { icon?: React.FC; text?: string } | null) => {
      setOverlayProps(props);
    });
    return unsub;
  }, []);

  // EventBus 拖曳建新筆記 — 已搬入 useNoteActions hook


  // 設置 editor 到 EditorRef store 中 - 包含 focus 事件監聽
  useEffect(() => {
    if (editor) {
      // 監聽編輯器的 focus 事件，當編輯器獲得焦點時更新 store
      const handleFocus = () => {

        useEditorRefStore.getState().setEditorRef(editor);
      };

      // 監聽編輯器的 blur 事件
      const handleBlur = () => {

        // 可以選擇是否在失去焦點時清除 editor 引用
        // useEditorRefStore.getState().setEditorRef(null);
      };

      // 添加事件監聽器
      editor.on('focus', handleFocus);
      editor.on('blur', handleBlur);

      // 清理函數
      return () => {
        editor.off('focus', handleFocus);
        editor.off('blur', handleBlur);
      };
    }
  }, [editor]);

  // handleMobileSplitListItem + handleKeyDown → useEditorKeyboard hook

  // ===== useNoteActions hook（Phase 4.1：刪除/釘選/複製/拖曳建新筆記）=====
  const { handleDelete, handlePinClick, handleCopy } = useNoteActions(
    resolvedNoteId, selectedNote, mode, editor, onFieldsChange, setSelectedNote,
  );

  const focusAtStart = () => {
    if (editor) {
      editor.commands.focus('start');
    }
  };

  useImperativeHandle(ref, () => ({
    focusAtStart,
    getEditor: () => editor
  }));

  // 修改 handleButtonClick 函數
  const handleButtonClick = (callback) => {
    return (e) => {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      callback(e);
    };
  };

  // handleSelectionChange + AI rewrite mode → useAIProcessing hook

  useEffect(() => {
    const editorBody = document.querySelector('.editor-body');

    const handleScroll = () => {
      if (editorBody) {
        editorBody.setAttribute('data-scroll-top', String(editorBody.scrollTop));
      }
    };

    if (editorBody) {
      editorBody.addEventListener('scroll', handleScroll);
    }

    return () => {
      if (editorBody) {
        editorBody.removeEventListener('scroll', handleScroll);
      }
    };
  }, []);

  // 添加处理 add 按钮点击的事件监听
  useEffect(() => {
    const handleAddButtonClick = (event) => {
      const { button, position } = event.detail;

      // 若按鈕不屬於當前編輯器，直接忽略
      const clickedNoteEditorElement = button.closest('.note-editor');
      const thisNoteEditorElement = editor?.view?.dom?.closest('.note-editor');
      if (!clickedNoteEditorElement || clickedNoteEditorElement !== thisNoteEditorElement) {
        return;
      }

      const buttonRect = button.getBoundingClientRect();

      // 動態獲取選單的實際寬度
      const menuElement = document.querySelector('.add-menu') as HTMLElement;
      const menuWidth = menuElement ? menuElement.offsetWidth : 150; // 如果找不到元素，使用預設最小寬度 150
      const menuHeight = 406;

      // 獲取內容縮放因子（從 CSS 變數）
      const computedScale = getComputedStyle(document.documentElement)
        .getPropertyValue('--content-scale')
        .trim();
      const SCALE = parseFloat(computedScale) || 1;

      // 判斷按鈕是在視窗的上半部還是下半部
      const isInUpperHalf = buttonRect.top < window.innerHeight / 2;

      // 根據按鈕位置決定菜單顯示位置
      let menuTop;
      if (isInUpperHalf) {
        // 在上半部，菜單顯示在按鈕下方
        menuTop = buttonRect.top;
      } else {
        // 在下半部，菜單顯示在按鈕上方
        menuTop = buttonRect.top - menuHeight + 24;
      }

      // 直接使用按鈕的絕對位置
      // window 模式或素材模式：選單顯示在右邊；一般模式：選單顯示在左邊
      const shouldGrowRight = mode !== 'normal';
      const menuPosition = {
        top: menuTop,
        left: shouldGrowRight
          ? buttonRect.left + (menuWidth * 0.5) // 素材模式/視窗模式：按鈕右邊 + 0.5菜單寬度
          : buttonRect.left - menuWidth - 16 // 一般模式：按鈕左邊 - 菜單寬度 - 16px 間距
      };

      // 設置編輯器焦點
      if (editor) {
        editor.commands.focus(position + 1);
      }

      // 顯示菜單（使用本地 state）
      setAddMenuState({ show: true, position: menuPosition, addButtonRef: button });
    };

    // 添加表格拖曳手把點擊事件監聽
    const handleTableDragHandleClick = (event) => {
      const { clientX, clientY, tablePos, tableElement } = event.detail;

      // 獲取內容縮放因子（從 CSS 變數）
      const computedScale = getComputedStyle(document.documentElement)
        .getPropertyValue('--content-scale')
        .trim();
      const SCALE = parseFloat(computedScale) || 1;

      // 選單尺寸
      const MENU_WIDTH = 160;
      const MENU_HEIGHT = 120;

      // 將點擊位置轉換為未縮放的座標
      const unscaledX = clientX / SCALE;
      const unscaledY = clientY / SCALE;

      // 計算 note-editor 容器的中點並以此判斷生長方向
      const editorElement = document.querySelector('.note-editor');
      const editorRect = editorElement ? editorElement.getBoundingClientRect() : {
        left: 0,
        right: window.innerWidth,
        top: 0,
        bottom: window.innerHeight
      };

      const editorMidX = ((editorRect.left + editorRect.right) / 2) / SCALE;
      const viewportMidY = (window.innerHeight / SCALE) / 2;

      const growRight = unscaledX < editorMidX;
      const growDown = unscaledY < viewportMidY;

      // 根據生長方向調整位置
      let adjustedX = unscaledX;
      let adjustedY = unscaledY;

      // 如果向左生長，需要減去選單寬度
      if (!growRight) {
        adjustedX = unscaledX - MENU_WIDTH;
      }

      // 如果向上生長，需要減去選單高度
      if (!growDown) {
        adjustedY = unscaledY - MENU_HEIGHT - 7;
      } else { // 向下
        adjustedY = unscaledY + 7;
      }

      // 設置選單位置和資料
      setTableHandleMenuPosition({ x: adjustedX, y: adjustedY });
      setTableHandleMenuData({ tablePos, tableElement });
      setShowTableHandleMenu(true);
    };

    document.addEventListener('add-button-clicked', handleAddButtonClick);
    document.addEventListener('table-drag-handle-clicked', handleTableDragHandleClick);

    return () => {
      document.removeEventListener('add-button-clicked', handleAddButtonClick);
      document.removeEventListener('table-drag-handle-clicked', handleTableDragHandleClick);
    };
  }, [editor]);

  // 添加点击外部关闭表格選單的处理
  useEffect(() => {
    const handleClickOutside = (event) => {
      // 處理表格選單的點擊外部關閉
      if (showTableSizeSelector) {
        const tableSizeSelectorElement = document.querySelector('.table-size-selector');
        if (!tableSizeSelectorElement || !tableSizeSelectorElement.contains(event.target)) {
          setShowTableSizeSelector(false);
        }
      }

      // 處理表格拖曳手把選單的點擊外部關閉
      if (showTableHandleMenu) {
        const tableHandleMenuElement = document.querySelector('.table-drag-handle-click-menu');
        if (!tableHandleMenuElement || !tableHandleMenuElement.contains(event.target)) {
          setShowTableHandleMenu(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showTableSizeSelector, showTableHandleMenu]);

  // handleLinkClick → useLinkHandler hook

  // 表格相關處理函數
  const handleCloseTableSizeSelector = () => {
    setShowTableSizeSelector(false);
  };

  // 在 useEffect 中綁定函數，確保 editor 初始化後立即執行
  useEffect(() => {
    const editorWithListChange = editor as unknown as EditorWithListChange;
    if (editor && !editorWithListChange._handleListChange) {
      // 直接綁定函數，快捷鍵使用時不需要關閉選單
      editorWithListChange._handleListChange = (listType: string) => {
        handleListChange(editor, listType, null);
      };
    }
  }, [editor]);

  useEffect(() => {
    if (editor) {

      const printDocStructure = (node, depth = 0, pos = 0) => {
        const indent = '  '.repeat(depth);
        const nodeInfo = {
          類型: node.type.name,
          內容: node.textContent || '(空)',
          位置: pos,
          大小: node.nodeSize,
        };

        if (node.content && node.content.content) {
          node.content.forEach((child, index) => {
            printDocStructure(child, depth + 1, pos + 1 + index);
          });
        }
      };
      // printDocStructure(editor.state.doc);
    }
  }, [editor]);

  // DEBUG用不要刪除
  // useEffect(() => {
  //   if (editor) {
  //     // 等待一個渲染週期，確保所有裝飾元素都已經被渲染
  //     safeSetTimeout(() => {
  //       const editorDOM = document.querySelector('.ProseMirror');
  //       if (editorDOM) {

  //         // 為了更好的可讀性，也打印格式化後的結構
  //         const printDOMStructure = (element, depth = 0) => {
  //           const indent = '  '.repeat(depth);
  //           const elementInfo = {
  //             標籤: element.tagName.toLowerCase(),
  //             類名: element.className,
  //             內容: element.childNodes.length === 0 ? element.textContent.trim() : ''
  //           };

  //           Array.from(element.children).forEach(child => {
  //             printDOMStructure(child, depth + 1);
  //           });
  //         };

  //         printDOMStructure(editorDOM);
  //       }
  //     }, 100);
  //   }
  // }, [editor]);



  // saveImageLocally, updateNoteImages → useImageUpload hook

  // handleImageUpload, handleOfflineImageUpload, handleImageSelect → useImageUpload hook

  // uploadLocalImages, clipboard event listeners → useImageUpload hook

  // 圖片上傳/辨識/imgTexts map useEffect → useImageUpload hook

  // processAIAPI (noteIntentionAnalysis 等 AI batch) → useAIProcessing hook

  // 強制重新渲染時，重新取得筆記
  useEffect(() => {
    if (!resolvedNoteId) {
      return;
    }

    // editor 剛建立時已帶有正確內容，跳過多餘的 setContent（避免 cursor 被推到結尾）
    if (editorJustCreatedRef.current) {
      editorJustCreatedRef.current = false;
      return;
    }

    const reload = async () => {
      let noteToUse = null;
      const materialState = useMaterialModeStore.getState();

      switch (mode) {
        case 'material':
        case 'normal':
        default:
          noteToUse = await window.electronAPI.getItem(resolvedNoteId) || null;
          break;
      }

      if (noteToUse) {
        onFieldsChange(noteToUse);
      }

      if (editor && noteToUse) {
        const isDarkMode = theme.mode === 'dark';
        const htmlContent = markdownToHtml(noteToUse.content || '');
        const convertedContent = convertContentColors(htmlContent, isDarkMode);
        editor.commands.setContent(convertedContent, { emitUpdate: false });
      } else if (editor) {
        editor.commands.setContent('', { emitUpdate: false });
      }
    };
    reload();
  }, [reloadTrigger, editor, theme.mode, mode]);


  // ---- AddMenu Table 選單處理函式（本編輯器） ----
  const handleAddMenuTableSelect = (e) => {
    if (!editor) return;

    const calculateTableSelectorPosition = () => {
      const buttonRect = e.target.getBoundingClientRect();
      const editorElement = document.querySelector('.note-editor');
      const editorRect = editorElement ? editorElement.getBoundingClientRect() : { top: 0, height: window.innerHeight };
      const buttonPositionInEditor = buttonRect.top - editorRect.top;
      const editorMidPoint = editorRect.height / 2;
      const isInUpperHalf = buttonPositionInEditor < editorMidPoint;
      const menuHeight = 152;
      const computedScale = getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim();
      const SCALE = parseFloat(computedScale) || 1;
      return {
        top: isInUpperHalf ? (buttonRect.bottom + 5) / SCALE : (buttonRect.top - menuHeight - 65) / SCALE,
        left: 12 / SCALE,
      };
    };

    setShowTableSizeSelector(true);
    setTableSelectorPosition(calculateTableSelectorPosition());
  };

  // 接收 toolbar 發出的新增圖片/表格事件（mobile 無 selection 時使用）
  useEffect(() => {
    const handleToolbarAddImage = () => {
      if (!editor) return;
      handleImageSelect();
    };

    const handleToolbarAddTable = (event) => {
      if (!editor) return;
      const anchor = event?.detail?.anchor;
      if (!anchor) return;
      handleAddMenuTableSelect({ target: anchor });
    };

    document.addEventListener('note-editor-add-image', handleToolbarAddImage);
    document.addEventListener('note-editor-add-table', handleToolbarAddTable);

    return () => {
      document.removeEventListener('note-editor-add-image', handleToolbarAddImage);
      document.removeEventListener('note-editor-add-table', handleToolbarAddTable);
    };
  }, [editor, handleImageSelect, handleAddMenuTableSelect]);

  // 監聽 MaterialLibrary 點擊事件
  useEffect(() => {
    if (!editor) return;

    const handleMaterialLibraryClick = (e) => {

      if (!useMaterialModeStore.getState().isAIRewriteMode) {
        return;
      }

      const { paragraphs } = e.detail;
      if (!paragraphs || !paragraphs.length) {
        return;
      }

      // 先清空舊的 decoration
      editor.view.dispatch(editor.state.tr.setMeta(rewriteHighlightKey, DecorationSet.empty));

      // 根據頂層子節點索引找位置並高亮
      const targetIndexes = paragraphs.map(p => p.index);
      const decos = [];

      let topLevelIndex = 0;
      editor.state.doc.forEach((child, offset) => {
        if (targetIndexes.includes(topLevelIndex)) {
          const childFrom = offset;
          const childTo = offset + child.nodeSize;
          decos.push(Decoration.node(childFrom, childTo, { class: 'ai-rewrite-highlight' }));
        }
        topLevelIndex += 1;
      });

      const decoSet = DecorationSet.create(editor.state.doc, decos);
      const trHigh = editor.state.tr.setMeta(rewriteHighlightKey, decoSet);
      editor.view.dispatch(trHigh);

      // 確認寫入後的 DecorationSet 內容
      const currentDecoState = rewriteHighlightKey.getState(editor.state);
      const size = currentDecoState ? currentDecoState.find().length : 0;
    };

    document.addEventListener('materialLibraryClick', handleMaterialLibraryClick);
    return () => {
      document.removeEventListener('materialLibraryClick', handleMaterialLibraryClick);
    };
  }, [editor]);

  // 添加歷史記錄事件監聽
  useEffect(() => {
    const handleHistoryUndo = (event) => {
      const { content, selection } = event.detail
      if (editor && content) {
        // 設置內容並恢復游標位置
        editor.commands.setContent(content)

        // 恢復游標位置
        if (selection && selection.from !== undefined && selection.to !== undefined) {
          // 確保位置在有效範圍內
          const docSize = editor.state.doc.content.size
          const from = Math.min(selection.from, docSize)
          const to = Math.min(selection.to, docSize)

          // 使用 setTimeout 確保內容更新後再設置游標
          safeSetTimeout(() => {
            try {
              editor.commands.setTextSelection({ from, to })
            } catch (error) {

              editor.commands.focus('start')
            }
          }, 0)
        }

        setSelectedNote(prevNote => {
          if (prevNote) {
            return {
              ...prevNote,
              content: htmlToMarkdown(content),
            }
          }
          return prevNote
        })
      }
    }

    const handleHistoryRedo = (event) => {
      const { content, selection } = event.detail
      if (editor && content) {
        // 設置內容並恢復游標位置
        editor.commands.setContent(content)

        // 恢復游標位置
        if (selection && selection.from !== undefined && selection.to !== undefined) {
          // 確保位置在有效範圍內
          const docSize = editor.state.doc.content.size
          const from = Math.min(selection.from, docSize)
          const to = Math.min(selection.to, docSize)

          // 使用 setTimeout 確保內容更新後再設置游標
          safeSetTimeout(() => {
            try {
              editor.commands.setTextSelection({ from, to })
            } catch (error) {

              editor.commands.focus('start')
            }
          }, 0)
        }

        setSelectedNote(prevNote => {
          if (prevNote) {
            return {
              ...prevNote,
              content: htmlToMarkdown(content),
            }
          }
          return prevNote
        })
      }
    }

    document.addEventListener(`historyUndo_${editorInstanceId}`, handleHistoryUndo)
    document.addEventListener(`historyRedo_${editorInstanceId}`, handleHistoryRedo)

    return () => {
      document.removeEventListener(`historyUndo_${editorInstanceId}`, handleHistoryUndo)
      document.removeEventListener(`historyRedo_${editorInstanceId}`, handleHistoryRedo)
    }
  }, [editor])

  // 設置 editor 到 EditorRef store 中 - 包含 focus 事件監聽
  useEffect(() => {
    if (editor) {
      // 監聽編輯器的 focus 事件，當編輯器獲得焦點時更新 store
      const handleFocus = () => {

        useEditorRefStore.getState().setEditorRef(editor);
      };

      // 監聽編輯器的 blur 事件
      const handleBlur = () => {

        // 可以選擇是否在失去焦點時清除 editor 引用
        // useEditorRefStore.getState().setEditorRef(null);
      };

      // 添加事件監聽器
      editor.on('focus', handleFocus);
      editor.on('blur', handleBlur);

      // 清理函數
      return () => {
        editor.off('focus', handleFocus);
        editor.off('blur', handleBlur);
      };
    }
  }, [editor]);

  return (
    <div
      className={`note-editor ${mode !== 'normal' && mode !== 'window' ? 'material-mode' : ''}`}
      style={{ height: '100%', display: 'flex', flexDirection: 'column' }}
    >
      {selectedNote && (
        <>
          {/* 上傳檔案遮罩 */}
          {isUploading &&
            <div className="upload-overlay">
              <div className="upload-spinner"></div>
            </div>
          }

          <EditorContent editor={editor} className="editor-body" />


          <AddUrlDialog />

          {/* AddMenu for this editor */}
          <AddMenu
            editor={editor}
            showAddMenu={addMenuState.show}
            position={addMenuState.position}
            addButtonRef={addMenuState.addButtonRef}
            hideMenu={() => setAddMenuState(prev => ({ ...prev, show: false }))}
            onAddImage={handleImageSelect}
            onAddTable={handleAddMenuTableSelect}
            isWindowMode={mode === 'window'}
          />

          {/* 添加编辑器右键菜单 */}
          <EditorRightClickMenu editor={editor} historyManager={historyManager} />
          <SearchReplaceDialog />

          <ImagePreviewWindow
            isOpen={showImagePreview}
            src={previewImageSrc}
            onClose={() => setShowImagePreview(false)}
          />

          {/* 表格大小選擇器 */}
          {showTableSizeSelector && (
            <div
              style={{
                position: 'absolute',
                top: `${tableSelectorPosition.top}px`,
                left: `${tableSelectorPosition.left}px`,
                zIndex: 1000
              }}
            >
              <TableSizeSelector
                onSelect={(rows, cols) => {
                  if (!editor) return;
                  // 插入表格
                  editor.chain().focus().insertTable({ rows, cols, withHeaderRow: true }).run();

                  // 獲取當前表格的位置並在表格後添加空行
                  const { $from } = editor.state.selection;
                  let depth = $from.depth;
                  let tableWrapperPos = -1;

                  // 向上尋找 table 節點
                  while (depth > 0) {
                    const node = $from.node(depth);
                    if (node.type.name === 'table') {
                      tableWrapperPos = $from.before(depth);
                      break;
                    }
                    depth--;
                  }

                  if (tableWrapperPos >= 0) {
                    const table = editor.state.doc.nodeAt(tableWrapperPos);
                    if (table) {
                      const tableEndPos = tableWrapperPos + table.nodeSize;

                      // 檢查表格後面是否還有內容
                      const $afterTable = editor.state.doc.resolve(tableEndPos);
                      const hasContentAfter = $afterTable.nodeAfter;

                      // 只有在後面沒有內容時才添加空行
                      if (!hasContentAfter) {
                        editor.commands.insertContentAt(tableEndPos, { type: 'paragraph' });
                      }
                    }
                  }

                  handleCloseTableSizeSelector();
                }}
                onClose={handleCloseTableSizeSelector}
              />
            </div>
          )}

          {/* 表格拖曳手把選單 */}
          <TableDragHandleClickMenu
            showMenu={showTableHandleMenu}
            position={tableHandleMenuPosition}
            tablePos={tableHandleMenuData.tablePos}
            tableElement={tableHandleMenuData.tableElement}
            editor={editor}
            onClose={() => setShowTableHandleMenu(false)}
          />
        </>
      )}

      {/* 統一拖曳遮罩 — 拖入時遮罩消失，讓 ProseMirror 原生 handleDrop 接管 */}
      {selectedNote && !isMobileView && overlayProps && (
        <DragOverlay
          icon={overlayProps.icon}
          text={overlayProps.text}
          onDragOver={(e) => {
            e.preventDefault();
            setOverlayProps(null);
          }}
          onDrop={(e) => {
            e.preventDefault();
            setOverlayProps(null);
          }}
          onDragLeave={() => setOverlayProps(null)}
        />
      )}
    </div>
  );
});

(MarkdownEditor as React.ComponentType & { whyDidYouRender?: object }).whyDidYouRender = {
  logOnDifferentValues: true,
  logOwnerReasons: true,
  trackAllPureComponents: true,
  trackHooks: true,
  customName: 'MarkdownEditor',
  diffNameColor: 'orange',
};

export default MarkdownEditor;