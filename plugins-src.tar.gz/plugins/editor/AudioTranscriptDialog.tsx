import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './AudioTranscriptDialog.css';
import CopyIcon from '../../../assets/icon_copy_16.svg?react';
import { useTempHintStore } from '../../../Store/uiStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { CustomDialog } from '../../common/CustomDialog';

// ===== 純 UI 組件 =====
// 所有資料由呼叫方透過 dialogStore.open('transcript', { audioTexts, onSave }) 傳入
// Dialog 內部只負責：逐字稿文字編輯、複製全部

interface AudioTranscriptDialogData {
  audioTexts: string[];
  onSave?: (updatedTexts: string[]) => void;
}

function AudioTranscriptDialog() {
  const { t } = useTranslation();
  // 從 store 獲取狀態
  const isOpen = useDialogStore(state => state.dialogs['transcript']?.show);
  const dialogData = useDialogStore(state => state.dialogs['transcript']?.data) as AudioTranscriptDialogData | null;

  // 從 dialogData 讀取呼叫方傳入的資料
  const audioTexts = dialogData?.audioTexts;
  const onSave = dialogData?.onSave;

  // UI 狀態
  const [editedTexts, setEditedTexts] = useState<string[]>([]);

  // 當對話框打開或 audioTexts 變化時，初始化編輯內容
  useEffect(() => {
    if (isOpen && audioTexts) {
      setEditedTexts([...audioTexts]);
    }
  }, [isOpen, audioTexts]);

  // 處理關閉（自動儲存）
  const handleClose = () => {
    if (onSave) {
      onSave(editedTexts);
    }
    useDialogStore.getState().close('transcript');
  };

  // 處理文本變更
  const handleTextChange = (index: number, value: string) => {
    const newTexts = [...editedTexts];
    newTexts[index] = value;
    setEditedTexts(newTexts);
  };

  // 處理複製全部逐字稿
  const handleCopyAll = () => {
    const allTexts = editedTexts.join('\n\n');
    navigator.clipboard.writeText(allTexts);
    useTempHintStore.getState().setTempHint(t('transcriptCopied'));
  };

  // Escape 由 CustomDialog 統一處理

  return (
    <CustomDialog
      isOpen={isOpen}
      onClose={handleClose}
      title={t('audioTranscript')}
      className="audio-transcript-dialog"
      headerActions={
        <button
          className="audio-transcript-dialog-copy"
          onClick={handleCopyAll}
          title={t('copyAllTranscript')}
        >
          <CopyIcon />
        </button>
      }
    >
      <div className="audio-transcript-dialog-content">
        {editedTexts.map((text, index) => (
          <div key={index} className="audio-transcript-item">
            <textarea
              className="audio-transcript-textarea"
              value={text}
              onChange={(e) => handleTextChange(index, e.target.value)}
              placeholder={text === '' ? t('audioRecognizing') : ''}
              rows={6}
            />
          </div>
        ))}

        {(!editedTexts || editedTexts.length === 0) && (
          <div className="audio-transcript-empty">
            {t('noAudioTranscript')}
          </div>
        )}
      </div>
    </CustomDialog>
  );
}

export default AudioTranscriptDialog;

