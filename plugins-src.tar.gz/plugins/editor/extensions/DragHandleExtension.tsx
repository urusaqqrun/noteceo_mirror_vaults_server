import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { eventBus } from '../../../../Store/eventBus';
import i18n from '../../../../i18n/config';

// 模組級變量：存放 DragHandle 拖曳段落的上下文（模組區域，避免 props drilling）
export let currentDragHandleData: {
  textContent: string;
  isTaskItem: boolean;
  isTaskCompleted: boolean;
  deleteOriginal: () => void;
} | null = null;

export function clearDragHandleData() {
  currentDragHandleData = null;
}

// 拖拽擴展
export const DragHandleExtension = Extension.create({
  name: 'dragHandle',

  addOptions() {
    return {
      isReadOnlyMode: false, // 只讀模式
    };
  },

  addProseMirrorPlugins() {
    const editor = this.editor;
    const isReadOnlyMode = this.options.isReadOnlyMode; // 保存 options
    let dragSourceNode = null;
    let dragTargetPos = null;
    let dragPreview = null;
    let isDragging = false;
    let dropCursor = null;
    let lastMousePos = null;

    // 清理空清單的通用函數
    const cleanupEmptyLists = (editor) => {
      setTimeout(() => {
        const newTr = editor.view.state.tr;
        let hasChanges = false;

        editor.view.state.doc.descendants((node, pos) => {
          // 檢查所有類型的清單
          if (['taskList', 'bulletList', 'orderedList'].includes(node.type.name)) {
            if (node.childCount === 0) {
              newTr.delete(pos, pos + node.nodeSize);
              hasChanges = true;
              return false; // 停止遍歷，因為位置會改變
            } else if (node.childCount === 1) {
              const listItem = node.firstChild;
              const expectedItemType = node.type.name === 'taskList' ? 'taskItem' : 'listItem';

              if (listItem && listItem.type.name === expectedItemType &&
                (!listItem.content || listItem.textContent.trim() === '')) {
                newTr.delete(pos, pos + node.nodeSize);
                hasChanges = true;
                return false;
              }
            }
          }
        });

        if (hasChanges) {
          // 通知組件不要更新時間戳記
          const event = new CustomEvent('skipUpdateTimestamp');
          document.dispatchEvent(event);

          editor.view.dispatch(newTr);
        }
      }, 10);
    };

    // 创建 dropcursor 元素
    const createDropCursor = () => {
      const cursor = document.createElement('div');
      cursor.className = 'editor-drop-cursor';
      cursor.style.position = 'absolute';
      cursor.style.height = '2px';
      cursor.style.backgroundColor = 'var(--primary)';
      cursor.style.pointerEvents = 'none';
      cursor.style.zIndex = '1000';
      cursor.style.transition = 'transform 0.1s ease';
      return cursor;
    };

    // 更新 dropcursor 位置
    const updateDropCursor = (e) => {
      if (!dropCursor || !editor.view.dom) return;

      try {
        const editorRect = editor.view.dom.getBoundingClientRect();

        // 檢測滑鼠是否在 checkbox 上
        const elementUnderMouse = document.elementFromPoint(e.clientX, e.clientY);

        let useOriginalCoords = true;
        let adjustedX = e.clientX;
        let adjustedY = e.clientY;

        // 檢查是否在需要特殊處理的元素上
        const needsAdjustment = elementUnderMouse && (
          // checkbox 相關元素
          (elementUnderMouse as HTMLInputElement).type === 'checkbox' ||
          (elementUnderMouse.tagName === 'LABEL' && elementUnderMouse.closest('.task-list')) ||
          (elementUnderMouse.tagName === 'SPAN' && elementUnderMouse.closest('label') && elementUnderMouse.closest('.task-list')) ||
          // taskList 的 UL 元素本身
          (elementUnderMouse.tagName === 'UL' && elementUnderMouse.classList.contains('task-list')) ||
          // 拖拽按鈕相關元素
          elementUnderMouse.classList.contains('drag-handle-container') ||
          elementUnderMouse.classList.contains('drag-handle-list') ||
          elementUnderMouse.closest('.drag-handle-container') ||
          // 加號按鈕相關元素
          elementUnderMouse.classList.contains('add-button-container-list') ||
          elementUnderMouse.classList.contains('add-button-list') ||
          elementUnderMouse.closest('.add-button-container-list') ||
          // ProseMirror widget 相關
          elementUnderMouse.classList.contains('ProseMirror-widget') ||
          elementUnderMouse.closest('.ProseMirror-widget')
        );

        if (needsAdjustment) {
          // 找到對應的 listItem
          const listItem = elementUnderMouse.closest('li');
          if (listItem) {
            const listItemRect = listItem.getBoundingClientRect();

            // 使用 listItem 的內容區域（避開 checkbox 區域）
            adjustedX = listItemRect.left + 40; // 避開 checkbox 區域
            adjustedY = e.clientY; // 保持 Y 座標不變
            useOriginalCoords = false;
          } else if (elementUnderMouse.tagName === 'UL' && elementUnderMouse.classList.contains('task-list')) {
            // 如果滑鼠在 taskList 的 UL 元素上，但不在任何 li 內

            // 找到 UL 內所有的 li 元素
            const allListItems = elementUnderMouse.querySelectorAll('li');
            let closestListItem = null;
            let minDistance = Infinity;

            // 找到最接近滑鼠位置的 li
            allListItems.forEach(li => {
              const liRect = li.getBoundingClientRect();
              const distance = Math.abs(liRect.top + liRect.height / 2 - e.clientY);
              if (distance < minDistance) {
                minDistance = distance;
                closestListItem = li;
              }
            });

            if (closestListItem) {
              const listItemRect = closestListItem.getBoundingClientRect();

              // 使用最近 listItem 的內容區域
              adjustedX = listItemRect.left + 40;
              adjustedY = e.clientY;
              useOriginalCoords = false;
            }
          }
        }

        const pos = editor.view.posAtCoords({
          left: useOriginalCoords ? e.clientX : adjustedX,
          top: useOriginalCoords ? e.clientY : adjustedY
        });

        if (!pos) return;

        const resolvedPos = editor.state.doc.resolve(pos.pos);

        // 查找列表项节点及其位置
        let listItemPos = null;
        let listItemNode = null;
        let depth = resolvedPos.depth;

        // 向上遍历节点树，寻找列表项节点
        while (depth > 0) {
          const node = resolvedPos.node(depth);
          if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
            listItemNode = node;
            listItemPos = resolvedPos.before(depth);
            break;
          }
          depth--;
        }

        // 如果找到了列表项节点，使用它的位置
        let nodeDOM, targetPos;
        const isInList = listItemNode !== null;

        if (isInList) {
          nodeDOM = editor.view.nodeDOM(listItemPos);
          if (!nodeDOM) return;

          const nodeRect = nodeDOM.getBoundingClientRect();
          const relativeToNode = e.clientY - nodeRect.top;
          const isTopHalf = relativeToNode < nodeRect.height / 2;

          // 设置 dropcursor 位置
          dropCursor.style.width = `${editorRect.width}px`;
          dropCursor.style.left = `${editorRect.left}px`;

          // 根据鼠标位置决定是在列表项前还是后插入
          targetPos = isTopHalf ? listItemPos : resolvedPos.after(depth);

          if (isTopHalf) {
            dropCursor.style.top = `${nodeRect.top}px`;
          } else {
            dropCursor.style.top = `${nodeRect.bottom}px`;
          }
        } else {
          // 非列表项的处理逻辑保持不变
          nodeDOM = editor.view.nodeDOM(resolvedPos.before());
          if (!nodeDOM) return;

          const nodeRect = nodeDOM.getBoundingClientRect();
          const relativeToNode = e.clientY - nodeRect.top;
          const isTopHalf = relativeToNode < nodeRect.height / 2;

          // 设置 dropcursor 位置
          dropCursor.style.width = `${editorRect.width}px`;
          dropCursor.style.left = `${editorRect.left}px`;

          targetPos = isTopHalf ? resolvedPos.before() : resolvedPos.after();

          if (isTopHalf) {
            dropCursor.style.top = `${nodeRect.top}px`;
          } else {
            dropCursor.style.top = `${nodeRect.bottom}px`;
          }
        }

        dragTargetPos = targetPos;

        // 將計算出的位置暴露給外部使用
        if (window.noteEditorDropPosition !== targetPos) {
          window.noteEditorDropPosition = targetPos;
        }
      } catch (error) {
        // 只记录错误，不改变任何逻辑
      }
    };

    const handleMouseMove = (e) => {
      if (!isDragging || !dragPreview) return;

      // 記錄滑鼠位置
      lastMousePos = { x: e.clientX, y: e.clientY };

      dragPreview.style.left = `${e.clientX + 10}px`;
      dragPreview.style.top = `${e.clientY + 10}px`;

      // 模擬拖曳事件，讓其他組件可以接收
      const elementUnderMouse = document.elementFromPoint(e.clientX, e.clientY);
      if (elementUnderMouse && currentDragHandleData) {
        // 創建模擬的 dragover 事件
        const dragEvent = new DragEvent('dragover', {
          bubbles: true,
          cancelable: true,
          clientX: e.clientX,
          clientY: e.clientY,
          dataTransfer: new DataTransfer()
        });

        // 設定 dataTransfer 資料
        dragEvent.dataTransfer.setData('text/plain', currentDragHandleData?.textContent || '');

        elementUnderMouse.dispatchEvent(dragEvent);
      }

      // 更新 dropcursor 位置
      updateDropCursor(e);
    };

    const handleMouseUp = (e) => {
      if (!isDragging) return;

      // 模擬 drop 事件
      const elementUnderMouse = document.elementFromPoint(e.clientX, e.clientY);
      if (elementUnderMouse && currentDragHandleData) {
        const dropEvent = new DragEvent('drop', {
          bubbles: true,
          cancelable: true,
          clientX: e.clientX,
          clientY: e.clientY,
          dataTransfer: new DataTransfer()
        });

        // 設定 dataTransfer 資料
        dropEvent.dataTransfer.setData('text/plain', currentDragHandleData?.textContent || '');

        elementUnderMouse.dispatchEvent(dropEvent);
      }

      isDragging = false;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);

      if (dragPreview) {
        dragPreview.remove();
        dragPreview = null;
      }

      if (dropCursor) {
        dropCursor.remove();
        dropCursor = null;
      }

      // 延遲清除跨區域拖曳數據，給 AIIndex 時間處理 drop 事件
      setTimeout(() => {
        currentDragHandleData = null;
        eventBus.emit('drag:note-list-drag-overlay', null);
        eventBus.emit('drag:ai-commander-drag-overlay', null);
      }, 100);

      // 檢查滑鼠是否還在編輯器內部
      // 使用正確的編輯器容器 - .note-editor 或 .editor-body
      const proseMirrorElement = editor.view.dom; // 這是 .ProseMirror 元素
      const editorBodyElement = proseMirrorElement.closest('.editor-body'); // 滾動容器
      const editorElement = editorBodyElement || proseMirrorElement; // 如果找不到 .editor-body 則使用 ProseMirror 元素
      const editorRect = editorElement.getBoundingClientRect();
      const isMouseInEditor = lastMousePos &&
        lastMousePos.x >= editorRect.left &&
        lastMousePos.x <= editorRect.right &&
        lastMousePos.y >= editorRect.top &&
        lastMousePos.y <= editorRect.bottom;

      if (dragSourceNode && dragTargetPos !== null && isMouseInEditor) {
        // 记录当前滚动位置
        const editorView = editor.view;
        const scrollTop = editorView.dom.scrollTop;

        // 使用 command 方式处理拖拽，但不调用 focus()
        this.editor.chain().command(({ tr, state, dispatch }) => {
          if (!dispatch) return false;

          // 获取源节点
          const sourcePos = dragSourceNode.pos;
          const sourceNode = state.doc.nodeAt(sourcePos);

          if (!sourceNode) {
            return false;
          }

          // 获取源节点的完整片段，包括所有子节点
          const sourceFrom = sourcePos;
          const sourceTo = sourcePos + sourceNode.nodeSize;
          const sourceSlice = state.doc.slice(sourceFrom, sourceTo);

          // 判斷拖曳方向：往前還是往後
          const isDraggingForward = dragTargetPos > dragSourceNode.pos;

          // 刪除源節點的函數
          const deleteSourceNode = (transaction) => {
            if (dragSourceNode.node._extraInfo?.isSingleItemList) {
              // 如果是单项列表，删除整个列表
              const extraInfo = dragSourceNode.node._extraInfo;
              const listPos = extraInfo.listPos;

              // 计算列表节点的大小
              const $listPos = editor.view.state.doc.resolve(listPos);
              const listNode = $listPos.nodeAfter;

              if (listNode) {
                const deleteFrom = listPos;
                const deleteTo = listPos + listNode.nodeSize;

                transaction.delete(deleteFrom, deleteTo);
              } else {
                // 回退到默认删除逻辑
                transaction.delete(dragSourceNode.pos, dragSourceNode.pos + sourceNode.nodeSize);
              }
            } else {
              // 默认删除逻辑
              transaction.delete(dragSourceNode.pos, dragSourceNode.pos + sourceNode.nodeSize);
            }
          };

          // 插入節點到目標位置的函數
          const insertNodeAtTarget = (transaction, targetPos) => {
            try {
              // 解析目标位置
              const $targetPos = state.doc.resolve(targetPos);

              // 检查目标位置是否在列表中
              let isTargetInList = false;
              let listType = null;
              let listDepth = 0;

              // 向上遍历节点树，查找列表
              for (let i = $targetPos.depth; i > 0; i--) {
                const node = $targetPos.node(i);
                if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
                  isTargetInList = true;
                  listType = node.type.name;
                  listDepth = i;
                  break;
                }
              }

              // 检查源节点是否为列表项
              const isSourceListItem = sourceNode.type.name === 'listItem' || sourceNode.type.name === 'taskItem';
              // 检查源节点是否为标题
              const isSourceHeading = sourceNode.type.name === 'heading';

              // 获取源节点的父节点类型
              let isSourceInList = false;
              let sourceListType = null;
              const $sourcePos = state.doc.resolve(dragSourceNode.pos);
              for (let i = $sourcePos.depth; i > 0; i--) {
                const node = $sourcePos.node(i);
                if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
                  isSourceInList = true;
                  sourceListType = node.type.name;
                  break;
                }
              }

              // 如果源节点有子节点（例如嵌套列表）
              const hasChildren = sourceNode.childCount > 0 && sourceNode.firstChild && sourceNode.firstChild.childCount > 0;

              // 如果目标位置在列表中
              if (isTargetInList && listType) {
                // 创建列表项节点
                const schema = state.schema;
                const itemType = listType === 'taskList' ? schema.nodes.taskItem : schema.nodes.listItem;

                if (itemType) {
                  let listItemContent;

                  // 如果源节点已经是列表项，则使用其内容
                  if (isSourceListItem) {
                    if (hasChildren) {
                      // 使用完整的源节点片段
                      transaction.insert(targetPos, sourceSlice.content);
                    } else {
                      // 获取列表项的内容（跳过列表项本身）
                      listItemContent = sourceNode.content.content[0];
                      const listItemNode = itemType.create({}, [listItemContent]);
                      transaction.insert(targetPos, listItemNode);
                    }
                  } else if (isSourceHeading) {
                    // 如果源节点是标题，将其转换为普通段落，然后作为列表项插入
                    const contentJSON = sourceNode.toJSON();
                    const headingText = sourceNode.textContent || '';

                    // 创建一个普通段落
                    const paragraphNode = schema.nodes.paragraph.create({}, schema.text(headingText));

                    // 创建一个包含此段落的列表项
                    const listItemNode = itemType.create({}, [paragraphNode]);

                    // 插入列表项
                    transaction.insert(targetPos, listItemNode);
                  } else {
                    // 创建列表项，包含源节点内容
                    listItemContent = sourceNode.isText ?
                      schema.nodes.paragraph.create({}, [sourceNode]) :
                      sourceNode;
                    const listItemNode = itemType.create({}, [listItemContent]);
                    transaction.insert(targetPos, listItemNode);
                  }
                }
              } else {
                // 如果不在列表中，执行普通的拖放操作
                let headingInserted = false;

                // 如果源节点是列表项，则只拖拽其内容
                if (isSourceListItem && sourceNode.content.content.length > 0) {
                  if (hasChildren) {
                    // 使用完整的源节点片段
                    transaction.insert(targetPos, sourceSlice.content);
                  } else {
                    const contentNode = sourceNode.content.content[0];
                    transaction.insert(targetPos, contentNode);
                  }
                } else {
                  // 普通节点的拖放
                  // 对于段落节点，确保我们删除的是整个段落
                  if (sourceNode.type.name === 'paragraph') {
                    // 直接插入源節點
                    transaction.insert(targetPos, sourceNode);
                  }
                  // 对于标题节点，确保我们正确处理标题的级别和属性
                  else if (sourceNode.type.name === 'heading') {
                    // 检查目标是否在列表中
                    if (isTargetInList) {
                      // 不需要在这里插入，因为前面的列表处理逻辑已经处理了
                      headingInserted = true;
                    } else {
                      // 不在列表中，保留标题格式
                      // 使用完整的slice插入到目标位置，保留所有格式和属性
                      transaction.insert(targetPos, sourceSlice.content);

                      // 标记为已处理
                      headingInserted = true;
                    }
                  }

                  // 如果有子节点，使用完整的片段，但不重复插入标题
                  if (hasChildren && !headingInserted) {
                    transaction.insert(targetPos, sourceSlice.content);
                  } else if (!headingInserted && sourceNode.type.name !== 'paragraph') {
                    transaction.insert(targetPos, sourceNode);
                  }
                }
              }

              return true;
            } catch (error) {
              return false;
            }
          };

          try {
            // 根據拖曳方向決定操作順序
            if (isDraggingForward) {
              // 往後拖曳：先插入後刪除
              if (!insertNodeAtTarget(tr, dragTargetPos)) {
                return false;
              }
              deleteSourceNode(tr);
            } else {
              // 往前拖曳：先刪除後插入
              deleteSourceNode(tr);
              if (!insertNodeAtTarget(tr, dragTargetPos)) {
                return false;
              }
            }

            dispatch(tr);
            return true;
          } catch (error) {
            // 添加更健壮的错误处理
            if (error.message.includes('no position before the top-level node')) {
              // 尝试在顶层节点前插入内容，改为插入到文档开始位置
            }

            // 如果出错，执行基本的拖放操作
            try {
              tr.delete(dragSourceNode.pos, dragSourceNode.pos + sourceNode.nodeSize);
              tr.insert(dragTargetPos, sourceSlice.content);
              dispatch(tr);
              return true;
            } catch (fallbackError) {
              return false;
            }
          }
        }).run();

        // 清理所有空的清單
        cleanupEmptyLists(editor);

        // 恢复滚动位置
        requestAnimationFrame(() => {
          editorView.dom.scrollTop = scrollTop;
        });
      }

      editor.setEditable(true);
      dragSourceNode = null;
      dragTargetPos = null;

      const selectedNode = document.querySelector('.ProseMirror-selectednode');
      if (selectedNode) {
        selectedNode.classList.remove('ProseMirror-selectednode');
      }

      // 取消编辑器焦点
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
    };

    const createDragPreview = (node, handleIcon, pos, state) => {
      const preview = document.createElement('div');
      preview.className = 'dragging-preview';

      const iconContainer = document.createElement('div');
      iconContainer.className = 'drag-handle-icon';
      iconContainer.innerHTML = handleIcon;
      preview.appendChild(iconContainer);

      const contentDiv = document.createElement('div');
      contentDiv.className = 'preview-content';

      const isListItem = node.type.name === 'listItem' || node.type.name === 'taskItem';
      if (isListItem) {
        const marker = node.type.name === 'taskItem' ? '☐ ' : '• ';
        contentDiv.textContent = marker + node.textContent;
      } else {
        contentDiv.textContent = node.textContent;
      }

      preview.appendChild(contentDiv);
      document.body.appendChild(preview);

      return preview;
    };

    // 構建 decorations 的函數
    const buildDecorations = (doc) => {
      const isMobile = window.innerWidth <= 768;

      if (isReadOnlyMode) {
        return DecorationSet.empty;
      }

      const decorations = [];

      doc.descendants((node, pos) => {
        if (node.type.name === 'table') {
          // 為表格添加裝飾器
          const decoration = Decoration.widget(
            pos + 1,
            () => {
              const handleContainer = document.createElement('div');
              handleContainer.className = 'table-drag-handle-container';
              handleContainer.innerHTML = `
                <div class="drag-handle-table">
                  <svg width="20" height="20" viewBox="0 0 20 20">
                    <path d="M7 0h2v2H7V0zM7 4h2v2H7V4zM7 8h2v2H7V8zM7 12h2v2H7v-2zM11 0h2v2h-2V0zM11 4h2v2h-2V4zM11 8h2v2h-2V8zM11 12h2v2h-2v-2z" fill="currentColor"/>
                  </svg>
                </div>
              `;

              handleContainer.addEventListener('mousedown', (e) => {
                e.preventDefault();
                e.stopPropagation();

                if (editor) {
                  const tableNode = editor.state.doc.nodeAt(pos);
                  if (tableNode) {
                    isDragging = true;
                    dragSourceNode = { pos, node: tableNode };
                    editor.setEditable(false);

                    dragPreview = createDragPreview(tableNode, handleContainer.innerHTML, pos, editor.state);
                    dragPreview.style.left = `${e.clientX + 10}px`;
                    dragPreview.style.top = `${e.clientY + 10}px`;

                    dropCursor = createDropCursor();
                    document.body.appendChild(dropCursor);

                    document.addEventListener('mousemove', handleMouseMove);
                    document.addEventListener('mouseup', handleMouseUp);
                  }
                }
              });

              return handleContainer;
            },
            {
              side: -1,
              key: `table-drag-handle-${pos}`,
              ignoreSelection: true,
            }
          );
          decorations.push(decoration);

          // 添加新增列按鈕
          const addColumnButton = Decoration.widget(
            pos + 1,
            () => {
              const button = document.createElement('div');
              button.className = 'table-add-column-button';
              button.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16">
                  <path d="M8 0a1 1 0 0 1 1 1v6h6a1 1 0 1 1 0 2H9v6a1 1 0 1 1-2 0V9H1a1 1 0 1 1 0-2h6V1a1 1 0 0 1 1-1z" fill="currentColor"/>
                </svg>
              `;

              const container = document.createElement('div');
              container.className = 'table-add-column-container';
              container.appendChild(button);

              button.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (editor) {
                  // 先將選擇移動到表格的最後一個儲存格，然後執行命令
                  const tableNode = editor.state.doc.nodeAt(pos);
                  if (tableNode && tableNode.type.name === 'table') {
                    // 計算表格的結束位置，然後往前找最後一個儲存格
                    const tableEndPos = pos + tableNode.nodeSize;

                    // 從表格結束位置往前搜尋，找到最後一個儲存格
                    for (let searchPos = tableEndPos - 1; searchPos > pos; searchPos--) {
                      try {
                        const $searchPos = editor.state.doc.resolve(searchPos);
                        // 檢查當前位置是否在儲存格內
                        for (let depth = $searchPos.depth; depth > 0; depth--) {
                          const node = $searchPos.node(depth);
                          if (node.type.name === 'tableCell' || node.type.name === 'tableHeader') {
                            // 找到最後一個儲存格，設置選擇到這裡
                            editor.chain()
                              .focus()
                              .setTextSelection(searchPos)
                              .addColumnAfter()
                              .run();
                            return;
                          }
                        }
                      } catch (e) {
                        // 忽略無效位置
                        continue;
                      }
                    }
                  }
                }
              });

              return container;
            },
            {
              key: `table-add-column-${pos}`,
              ignoreSelection: true,
            }
          );

          // 添加新增行按鈕
          const addRowButton = Decoration.widget(
            pos + 1,
            () => {
              const button = document.createElement('div');
              button.className = 'table-add-row-button';
              button.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 16 16">
                  <path d="M8 0a1 1 0 0 1 1 1v6h6a1 1 0 1 1 0 2H9v6a1 1 0 1 1-2 0V9H1a1 1 0 1 1 0-2h6V1a1 1 0 0 1 1-1z" fill="currentColor"/>
                </svg>
              `;

              const container = document.createElement('div');
              container.className = 'table-add-row-container';
              container.appendChild(button);

              button.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (editor) {
                  // 先將選擇移動到表格的最後一個儲存格，然後執行命令
                  const tableNode = editor.state.doc.nodeAt(pos);
                  if (tableNode && tableNode.type.name === 'table') {
                    // 計算表格的結束位置，然後往前找最後一個儲存格
                    const tableEndPos = pos + tableNode.nodeSize;

                    // 從表格結束位置往前搜尋，找到最後一個儲存格
                    for (let searchPos = tableEndPos - 1; searchPos > pos; searchPos--) {
                      try {
                        const $searchPos = editor.state.doc.resolve(searchPos);
                        // 檢查當前位置是否在儲存格內
                        for (let depth = $searchPos.depth; depth > 0; depth--) {
                          const node = $searchPos.node(depth);
                          if (node.type.name === 'tableCell' || node.type.name === 'tableHeader') {
                            // 找到最後一個儲存格，設置選擇到這裡
                            editor.chain()
                              .focus()
                              .setTextSelection(searchPos)
                              .addRowAfter()
                              .run();
                            return;
                          }
                        }
                      } catch (e) {
                        // 忽略無效位置
                        continue;
                      }
                    }
                  }
                }
              });

              return container;
            },
            {
              key: `table-add-row-${pos}`,
              ignoreSelection: true,
            }
          );

          decorations.push(addColumnButton);
          decorations.push(addRowButton);
        } else if (node.type.name === 'paragraph' || node.type.name === 'heading') {
          // 檢查是否在表格內
          let isInsideTable = false;
          let depth = doc.resolve(pos).depth;
          while (depth > 0) {
            const parent = doc.resolve(pos).node(depth);
            if (parent.type.name === 'table') {
              isInsideTable = true;
              break;
            }
            depth--;
          }

          // 只有不在表格內的元素才添加裝飾器
          if (!isInsideTable) {
            const $pos = doc.resolve(pos);
            const parent = $pos.parent;

            const handleIcon = `
              <svg width="20" height="20" viewBox="0 0 20 20">
                <path d="M7 0h2v2H7V0zM7 4h2v2H7V4zM7 8h2v2H7V8zM7 12h2v2H7v-2zM11 0h2v2h-2V0zM11 4h2v2h-2V4zM11 8h2v2h-2V8zM11 12h2v2h-2v-2z" fill="currentColor"/>
              </svg>
            `;

            const addIcon = `
              <svg width="20" height="20" viewBox="0 0 20 20">
                <path d="M10 1a1 1 0 0 1 1 1v4h4a1 1 0 1 1 0 2h-4v4a1 1 0 1 1-2 0v-4H5a1 1 0 1 1 0-2h4V2a1 1 0 0 1 1-1z" fill="currentColor"/>
              </svg>
            `;

            const isListItem = parent && (parent.type.name === 'listItem' || parent.type.name === 'taskItem');
            const dragClassName = isListItem ? 'drag-handle-list' : 'drag-handle';
            const addClassName = isListItem ? 'add-button-list' : 'add-button';

            // 添加拖曳把手裝飾
            const dragDecoration = Decoration.widget(
              pos + 1,
              () => {
                const handle = document.createElement('div');
                handle.className = dragClassName;
                handle.innerHTML = handleIcon;

                const container = document.createElement('div');
                container.className = 'drag-handle-container';
                container.appendChild(handle);

                // 存儲節點的唯一標識
                const nodeId = node.attrs.id || `node-${pos}`;

                container.addEventListener('mousedown', (e) => {
                  e.preventDefault();
                  e.stopPropagation();

                  const paragraph = (e.target as HTMLElement).closest('p, li, h1, h2, h3');
                  if (paragraph) {
                    // 获取当前编辑器状态
                    const currentState = editor.state;

                    // 查找当前节点的实际位置
                    let currentPos = -1;
                    let currentNode = null;

                    // 尝试直接通过DOM位置查找
                    try {
                      const domPos = editor.view.posAtDOM(paragraph, 0);

                      if (domPos !== null) {
                        const $domPos = currentState.doc.resolve(domPos);

                        // 查找最顶层的列表项
                        let foundListItem = false;
                        let listItemPos = -1;
                        let listItemNode = null;

                        // 从当前位置向上查找，找到第一个列表项
                        for (let i = $domPos.depth; i > 0; i--) {
                          const node = $domPos.node(i);
                          if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
                            foundListItem = true;
                            listItemPos = $domPos.before(i);
                            listItemNode = node;

                            // 检查该列表项是否是列表中唯一的项目
                            const listParentDepth = i - 1;
                            if (listParentDepth > 0) {
                              const listParentNode = $domPos.node(listParentDepth);
                              const isListParent = listParentNode.type.name === 'bulletList' ||
                                listParentNode.type.name === 'orderedList' ||
                                listParentNode.type.name === 'taskList';

                              if (isListParent && listParentNode.childCount === 1) {
                                // 列表中只有一个项目，记录列表信息用于删除

                                // 存储列表信息用于后续删除
                                listItemNode._extraInfo = {
                                  isSingleItemList: true,
                                  listType: listParentNode.type.name,
                                  listPos: $domPos.before(listParentDepth),
                                  listDepth: listParentDepth,
                                  parentOfListDepth: listParentDepth - 1,
                                  parentOfListPos: (listParentDepth - 1) > 0 ? $domPos.before(listParentDepth - 1) : 0,
                                  indexInParent: $domPos.index(listParentDepth - 1)
                                };
                              }
                            }

                            break;
                          }
                        }

                        if (foundListItem) {
                          currentPos = listItemPos;
                          currentNode = listItemNode;
                        } else {
                          // 如果不是列表项，使用当前节点
                          // 对于段落，我们需要找到确切的段落节点位置
                          if ($domPos.parent.type.name === 'paragraph') {
                            currentPos = $domPos.before($domPos.depth);
                            currentNode = $domPos.parent;
                          } else if ($domPos.parent.type.name === 'heading') {
                            currentPos = $domPos.before($domPos.depth);
                            currentNode = $domPos.parent;
                          } else {
                            // 向上查找段落或标题
                            for (let i = $domPos.depth; i > 0; i--) {
                              const node = $domPos.node(i);
                              if (node.type.name === 'paragraph' || node.type.name === 'heading') {
                                currentPos = $domPos.before(i);
                                currentNode = node;
                                break;
                              }
                            }
                          }
                        }
                      }
                    } catch (e) {
                      console.error('Error finding node position:', e);
                    }

                    // 如果仍然找不到，使用原始位置
                    if (currentPos === -1) {
                      currentPos = pos;
                      currentNode = node;
                    }

                    if (currentNode) {
                      isDragging = true;
                      dragSourceNode = { pos: currentPos, node: currentNode };
                      editor.setEditable(false);

                      dragPreview = createDragPreview(currentNode, handleIcon, currentPos, currentState);
                      dragPreview.style.left = `${e.clientX + 10}px`;
                      dragPreview.style.top = `${e.clientY + 10}px`;

                      // 寫入跨區域拖曳數據
                      currentDragHandleData = {
                        textContent: currentNode.textContent.trim(),
                        isTaskItem: currentNode.type.name === 'taskItem',
                        isTaskCompleted: currentNode.type.name === 'taskItem' ? currentNode.attrs?.checked === true : false,
                        deleteOriginal: () => {
                          // 刪除原段落

                          // 通知組件不要更新時間戳記
                          const event = new CustomEvent('skipUpdateTimestamp');
                          document.dispatchEvent(event);

                          try {
                            const docSize = editor.state.doc.content.size;

                            // 確保位置有效
                            if (currentPos < 0 || currentPos >= docSize) {
                              return;
                            }

                            // 檢查是否為清單項目
                            const isListItem = ['taskItem', 'listItem'].includes(currentNode.type.name);

                            if (isListItem) {
                              // 安全地 resolve 位置
                              let $pos;
                              try {
                                $pos = editor.state.doc.resolve(currentPos);
                              } catch (e) {
                                return;
                              }

                              // 向上查找清單
                              let listPos = null;
                              let listNode = null;
                              let listType = null;

                              // 向上查找任何類型的清單
                              for (let depth = $pos.depth; depth >= 0; depth--) {
                                const node = $pos.node(depth);
                                if (['taskList', 'bulletList', 'orderedList'].includes(node.type.name)) {
                                  // 使用 before 獲取清單的實際開始位置
                                  listPos = $pos.before(depth);
                                  listNode = node;
                                  listType = node.type.name;
                                  break;
                                }
                              }

                              if (listNode && listNode.childCount === 1) {
                                // 清單中只有一個項目，刪除整個清單
                                const listEndPos = listPos + listNode.nodeSize;

                                // 確保位置有效
                                if (listPos >= 0 && listEndPos <= editor.state.doc.content.size) {
                                  editor.chain()
                                    .focus()
                                    .deleteRange({ from: listPos, to: listEndPos })
                                    .run();
                                }
                              } else {
                                // 清單中有多個項目，只刪除當前項目
                                const itemEndPos = currentPos + currentNode.nodeSize;

                                // 確保位置有效
                                if (currentPos >= 0 && itemEndPos <= editor.state.doc.content.size) {
                                  editor.chain()
                                    .focus()
                                    .deleteRange({ from: currentPos, to: itemEndPos })
                                    .run();
                                }
                              }
                            } else {
                              // 非清單項目，直接刪除
                              const endPos = currentPos + currentNode.nodeSize;

                              // 確保位置有效
                              if (currentPos >= 0 && endPos <= editor.state.doc.content.size) {
                                editor.chain()
                                  .focus()
                                  .deleteRange({ from: currentPos, to: endPos })
                                  .run();
                              }
                            }
                          } catch (e) {
                            console.error('刪除原段落時發生錯誤:', e);
                          }
                        }
                      };

                      eventBus.emit('drag:note-list-drag-overlay', { icon: null, text: currentNode.type.name === 'taskItem' ? '建立待辦' : '建立筆記', sourceType: 'noteEditor', metadata: currentDragHandleData });

                      dropCursor = createDropCursor();
                      document.body.appendChild(dropCursor);

                      document.addEventListener('mousemove', handleMouseMove);
                      document.addEventListener('mouseup', handleMouseUp);
                    }
                  }
                });

                return container;
              },
              {
                side: -1,
                key: dragClassName + pos, // 使用位置作為鍵的一部分，確保唯一性
                ignoreSelection: true,
              }
            );
            decorations.push(dragDecoration);

            // 添加加號按鈕裝飾
            const addDecoration = Decoration.widget(
              pos + 1,
              () => {
                const addButton = document.createElement('div');
                addButton.className = addClassName;
                addButton.innerHTML = addIcon;

                const container = document.createElement('div');
                // 根據是否為列表項使用不同的容器類名
                container.className = isListItem ? 'add-button-container-list' : 'add-button-container';
                container.appendChild(addButton);

                // 修改加號按鈕點擊事件
                container.addEventListener('click', (e) => {
                  e.preventDefault();
                  e.stopPropagation();

                  // 觸發自定義事件，傳遞點擊位置信息
                  const event = new CustomEvent('add-button-clicked', {
                    detail: {
                      button: addButton,
                      position: pos
                    }
                  });
                  document.dispatchEvent(event);
                });

                return container;
              },
              {
                side: -1,
                key: addClassName + pos, // 使用位置作為鍵的一部分，確保唯一性
                ignoreSelection: true,
              }
            );
            decorations.push(addDecoration);
          }
        }
      });

      return DecorationSet.create(doc, decorations);
    };

    const pluginKey = new PluginKey('dragHandle');

    return [
      new Plugin({
        key: pluginKey,
        // 使用 state.init/apply 模式緩存 decorations，避免無限循環
        state: {
          init(_, state) {
            return buildDecorations(state.doc);
          },
          apply(tr, oldDecorations, oldState, newState) {
            if (tr.docChanged) {
              return buildDecorations(newState.doc);
            }
            return oldDecorations;
          }
        },
        props: {
          decorations(state) {
            return pluginKey.getState(state);
          },
          handleDOMEvents: {
            // 處理外部拖曳
            dragenter: (view, event) => {
              const isExternalDrag = !isDragging;

              if (isExternalDrag) {
                // 創建 dropcursor（復用內部拖曳的邏輯）
                if (!dropCursor) {
                  dropCursor = createDropCursor();
                  document.body.appendChild(dropCursor);
                }
              }
              return false;
            },
            dragover: (view, event) => {
              const isExternalDrag = !isDragging;

              if (isExternalDrag && dropCursor) {
                // 復用內部拖曳的 updateDropCursor 邏輯
                updateDropCursor(event);
              }
              return false;
            },
            dragleave: (view, event) => {
              const isExternalDrag = !isDragging;

              if (isExternalDrag) {
                // 檢查是否真的離開了編輯器
                const rect = view.dom.getBoundingClientRect();
                const isOutside = event.clientX < rect.left || event.clientX > rect.right ||
                  event.clientY < rect.top || event.clientY > rect.bottom;

                if (isOutside && dropCursor) {
                  dropCursor.remove();
                  dropCursor = null;
                }
              }
              return false;
            },
            drop: (view, event) => {
              const isExternalDrag = !isDragging;

              if (isExternalDrag && dropCursor) {
                dropCursor.remove();
                dropCursor = null;
              }
              return false;
            }
          }
        },
        view: () => ({
          destroy: () => {
            if (dropCursor) dropCursor.remove();
            if (dragPreview) dragPreview.remove();
          }
        })
      })
    ];
  }
}); 