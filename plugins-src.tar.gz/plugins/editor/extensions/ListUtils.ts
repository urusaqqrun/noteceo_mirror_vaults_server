// 統一的列表按鈕處理函數
export const handleListChange = (editor, listType, hideMenu = null) => {
  if (!editor) return;

  // 检查当前选区是否包含标题节点并先取消标题格式
  const hasHeading = editor.isActive('heading');
  if (hasHeading) {
    editor.chain().focus().setParagraph().run();
  }

  const { from, to } = editor.state.selection;

  // 检测标题区域内部的节点
  editor.state.doc.nodesBetween(from, to, (node, pos) => {
    if (node.type.name === 'heading') {
      // 在继续之前，确保将标题转换为段落
      // 注意：这里不直接修改，而是标记下来
      const headingPos = pos;
      // 在下一个事件循环中处理，避免状态混乱
      setTimeout(() => {
        editor.commands.setTextSelection(headingPos);
        editor.commands.setParagraph();
      }, 0);
    }
  });

  let itemType;
  if (listType === 'bulletList') {
    itemType = 'listItem';
  } else if (listType === 'orderedList') {
    itemType = 'listItem';
  } else if (listType === 'taskList') {
    itemType = 'taskItem';
  }

  //找到範圍內的grandParentsList
  let grandParentsList = {};
  editor.state.doc.nodesBetween(from, to, (node, pos) => {
    if (node.type.name === 'paragraph') {
      const $nodePos = editor.state.doc.resolve(pos);
      const nodeDepth = $nodePos.depth;
      if (nodeDepth > 1) {
        // 获取祖父节点
        const grandParentNode = $nodePos.node(nodeDepth - 1);
        const grandParentStart = $nodePos.start(nodeDepth - 1);
        const grandParentEnd = $nodePos.end(nodeDepth - 1);
        const grandParentPos = $nodePos.before(nodeDepth - 1);

        // 如果祖父节点是列表类型，则存储信息
        if (['bulletList', 'orderedList', 'taskList'].includes(grandParentNode.type.name)) {
          // 使用 pos 作为键来避免重复
          grandParentsList[grandParentPos] = {
            node: grandParentNode,
            type: grandParentNode.type.name,
            start: grandParentStart,
            end: grandParentEnd,
            pos: grandParentPos
          };

        }
      }
      return false; // 停止继续搜索
    }
    return true;
  });

  //找到doc所有node 如果在範圍內 深度為1 儲存起來 之後要包裹
  var nodeIndexOfDoc = 0;
  let paragraphNodesNeedToWrap = [];
  let paragraphNodesIndexForSelect = [];
  var firstParagraphNodeIndex = -1;
  editor.state.doc.descendants((node, pos, parent) => {
    if (node.type.name === 'paragraph') {
      // 检查段落节点是否与选区有交集
      const nodeEnd = pos + node.nodeSize;

      if ((pos <= to && nodeEnd >= from)) {
        paragraphNodesIndexForSelect.push(nodeIndexOfDoc.toString());

        const $nodePos = editor.state.doc.resolve(pos);
        const nodeDepth = $nodePos.depth;
        if (firstParagraphNodeIndex === -1) {
          firstParagraphNodeIndex = nodeIndexOfDoc;
        }
        // 深度為1的話 就儲存起來 將段落節點添加到數組中
        if (nodeDepth === 0) {
          paragraphNodesNeedToWrap.push({
            node,
            pos,
            nodeEnd,
            nodeIndexOfDoc: nodeIndexOfDoc.toString()
          });
        }
      }

      nodeIndexOfDoc++;
    }
    return true;  // 继续遍历
  });
  nodeIndexOfDoc = 0;

  let allListAreTargetType = true;

  if (paragraphNodesNeedToWrap.length > 0) {
    allListAreTargetType = false;
  } else {
    // 检查所有列表是否都是目标类型
    const listTypes = Object.values(grandParentsList).map(({ type }) => type);

    Object.values(grandParentsList).forEach(({ type }) => {
      if (type !== listType) {
        allListAreTargetType = false;
      }
    });

  }

  if (allListAreTargetType) {
    // 当所有列表都是目标类型时，将所有列表项转换为普通段落
    let paragraphNodes = [];
    let index = 0;

    // 先收集所有需要处理的段落节点
    editor.state.doc.descendants((node, pos) => {
      if (node.type.name === 'paragraph') {
        if (paragraphNodesIndexForSelect.includes(index.toString())) {
          paragraphNodes.push({ node, pos, index });

        }
        index++;
      }
    });

    // 反转数组，从后往前处理
    let firstParagraphPos = null;
    paragraphNodes.reverse().forEach(({ node, pos }, index) => {
      // 记录第一个段落的位置
      if (index === paragraphNodes.length - 1) {
        firstParagraphPos = pos;
      }

      // 设置节点选择
      editor.chain()
        .focus()
        .setNodeSelection(pos)
        .run();

      // 檢查當前是否為混合列表結構
      const $currentPos = editor.state.selection.$from;
      const currentDepth = $currentPos.depth;
      let isMixedListStructure = false;
      let grandParentListType = null;
      let currentListType = null;

      // 檢查父層和祖父層的列表類型
      if (currentDepth >= 3) {
        for (let d = currentDepth; d > 0; d--) {
          const node = $currentPos.node(d);
          if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
            if (!currentListType) {
              currentListType = node.type.name;
            } else if (!grandParentListType) {
              grandParentListType = node.type.name;
              break;
            }
          }
        }

        // 檢查是否為混合結構
        if (currentListType && grandParentListType && currentListType !== grandParentListType) {
          isMixedListStructure = true;

        }
      }

      if (isMixedListStructure) {

        handleMixedListBackspace(editor, pos);
      } else {

        // 持续降级直到不再是任何类型的列表
        while (
          editor.isActive('bulletList') ||
          editor.isActive('orderedList') ||
          editor.isActive('taskList')
        ) {
          // 根据当前列表类型选择正确的 item 类型
          if (editor.isActive('taskList')) {
            itemType = 'taskItem';
          } else {
            itemType = 'listItem';
          }

          // 执行降级操作
          editor.chain()
            .focus()
            .liftListItem(itemType)
            .run();
        }
      }
    });

    // 処理完成後，將焦點設置到第一個段落的最前面
    if (firstParagraphPos !== null) {
      // 將光標設置為文本選區，放在段落的開頭
      editor.chain()
        .focus()
        .setTextSelection(firstParagraphPos + 1)
        .run();
    }

    // 如果有 hideMenu 函數，調用它
    if (hideMenu) {
      hideMenu();
    }
    return;
  }

  // 1. 收集所有需要替换的列表项和列表节点
  let nodesToReplace = [];
  Object.values(grandParentsList).forEach(({ start, end, pos, node }) => {
    // 先收集列表項
    const listDepth = editor.state.doc.resolve(pos).depth;
    editor.state.doc.nodesBetween(start, end, (node, pos) => {
      if ((node.type.name === 'listItem' || node.type.name === 'taskItem')) {
        const currentDepth = editor.state.doc.resolve(pos).depth;
        // 只收集比列表深度大1的節點(直接子節點)
        if (currentDepth === listDepth + 1) {
          nodesToReplace.push({
            node,
            pos,
            depth: currentDepth,
            type: 'item',
          });
        }
      }
      return true;
    });

    // 收集列表節點
    nodesToReplace.push({
      node,
      pos,
      depth: listDepth,
      type: 'list'
    });
  });

  // 2. 从浅到深替换节点
  editor.chain().focus().command(({ tr, state }) => {

    // 按深度从浅到深排序
    nodesToReplace.sort((a, b) => a.depth - b.depth);

    // 只处理列表节点
    const listNodes = nodesToReplace.filter(n => n.type === 'list');

    // 替换每个列表
    listNodes.forEach(({ node, pos }) => {
      try {
        // 创建新的列表内容，处理所有子项
        const newItems = [];
        node.content.forEach(item => {
          if (item.type.name === 'listItem' || item.type.name === 'taskItem') {
            // 创建新的列表项，保持原有内容
            newItems.push(
              state.schema.nodes[itemType].create(
                item.attrs,
                item.content
              )
            );
          } else {
            newItems.push(item);
          }
        });

        // 创建新的列表节点，包含处理后的内容
        const newNode = state.schema.nodes[listType].create(
          node.attrs,
          newItems
        );

        // 一次性替换整个列表
        tr.replaceWith(pos, pos + node.nodeSize, newNode);
      } catch (error) {
        console.error('替換列表時出錯:', error);
      }
    });

    return true;
  }).run();

  //將paragraphNodesNeedToWrap包裹一層指定list
  if (paragraphNodesNeedToWrap.length > 0) {
    paragraphNodesNeedToWrap.forEach(({ nodeIndexOfDoc }) => {
      let currentIndex = 0;
      editor.state.doc.descendants((node, pos) => {
        if (node.type.name === 'paragraph') {
          if (currentIndex.toString() === nodeIndexOfDoc) {
            editor.chain()
              .focus()
              .setNodeSelection(pos)
              .toggleList(listType)
              .run();
          }
          currentIndex++;
        }
        return true;
      });
    });
  }

  if (firstParagraphNodeIndex !== -1) {
    let currentIndex = 0;
    editor.state.doc.descendants((node, pos) => {
      if (node.type.name === 'paragraph') {
        if (currentIndex === firstParagraphNodeIndex) {
          // 將光標移動到段落開頭
          const $nodePos = editor.state.doc.resolve(pos);
          const depth = $nodePos.depth;
          const start = $nodePos.start(depth);
          editor.chain().focus().setTextSelection(start + 1).run();
        }
        currentIndex++;
      }
      return true;
    });
  }

  // 如果有 hideMenu 函數，調用它
  if (hideMenu) {
    hideMenu();
  }
};

// 處理列表項的 backspace 升階邏輯
export const handleListBackspace = (editor) => {
  // 獲取當前選區
  const { from, to, empty } = editor.state.selection;

  if (!empty) {

    return false;
  }

  // 獲取當前位置的節點信息
  const $pos = editor.state.selection.$from;
  const parentOffset = $pos.parentOffset;
  const parent = $pos.parent;

  // 檢查是否在段落的最前面且該段落有縮排
  if (parentOffset === 0 && (parent.type.name === 'paragraph' || parent.type.name === 'heading') && parent.attrs.indent > 0) {

    return editor.commands.outdent();
  }

  // 获取当前选择的视图
  const editorView = editor.view;
  const { state } = editorView;
  const $from = state.selection.$from;

  // 當在editor的最前面 如果該行是空行並且按刪除 則刪除那一行遞補後面內容
  if ($from.pos === 1) {

    // 获取第一个段落
    const editorDom = editorView.dom;
    const paragraphs = Array.from(editorDom.childNodes).filter(
      (node): node is ChildNode => (node as ChildNode).nodeName === 'P' || (node as ChildNode).nodeName === 'UL' || (node as ChildNode).nodeName === 'OL'
    );

    if (paragraphs.length >= 2) {
      const firstParagraph = paragraphs[0];

      const isEmpty = (firstParagraph as ChildNode).textContent?.trim() === '';
      if (isEmpty) {

        // 创建事务删除第一个段落
        const tr = state.tr;
        const firstNodeSize = state.doc.firstChild.nodeSize;
        tr.delete(0, firstNodeSize);
        editorView.dispatch(tr);

        return true; // 阻止默认行为
      }
    }
  }

  // 獲取當前位置的節點
  const pos = from;
  // 檢查是否為最高層級
  const isTopLevel = $pos.node(-1)?.type.name === 'doc';

  // 檢查是否在列表項的開頭位置
  const isAtStart = parentOffset === 0;

  // 檢查當前節點是否為空（新增）
  const isEmptyNode = $pos.parent.textContent.trim() === '';


  // 如果是在列表項的開始位置且節點為空，直接刪除節點
  if (isAtStart && !isTopLevel && isEmptyNode && (
    editor.isActive('bulletList') ||
    editor.isActive('orderedList') ||
    editor.isActive('taskList')
  )) {

    // 尋找正確的列表項節點和層級
    let listItemDepth = -1;
    let listItemNode = null;
    let listItemPos = -1;
    let isFirstItem = true;

    // 從當前位置向上遍歷尋找列表項節點
    for (let d = $pos.depth; d > 0; d--) {
      const node = $pos.node(d);
      if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
        listItemDepth = d;
        listItemNode = node;
        listItemPos = $pos.before(d);

        // 檢查是否為第一個列表項
        const parentList = $pos.node(d - 1);
        isFirstItem = parentList.firstChild === node;
        break;
      }
    }

    // 如果是深度為2且是第一個項目，執行降階操作
    if (listItemDepth === 2 && isFirstItem) {
      if (editor.isActive('taskList')) {
        return editor.chain().focus().liftListItem('taskItem').run();
      } else {
        return editor.chain().focus().liftListItem('listItem').run();
      }
    }

    // 確保找到了有效的列表項節點
    if (listItemDepth > 0 && listItemNode && listItemPos >= 0) {

      // 找到包含該列表項的列表節點
      const listDepth = listItemDepth - 1;
      const listNode = $pos.node(listDepth);
      const listPos = $pos.before(listDepth);

      // 找到當前段落的上一個段落
      const doc = state.doc;
      let preParagraphPos = -1;
      let preParagraph = null;

      // 從當前位置向前遍歷尋找上一個段落
      doc.nodesBetween(0, listItemPos, (node, pos) => {
        if (node.type.name === 'paragraph') {
          preParagraphPos = pos;
          preParagraph = node;
        }
      });

      if (preParagraphPos >= 0 && preParagraph) {

        // 創建刪除事務
        const tr = state.tr;

        tr.delete(preParagraphPos + preParagraph.nodeSize - 1, listItemPos + 2);
        editorView.dispatch(tr);
        return true; // 阻止默認行為
      } else {

        const tr = state.tr;
        tr.delete(listItemPos, listItemPos + listItemNode.nodeSize);
        editorView.dispatch(tr);
        return true;
      }
    } else {

    }
  }

  // 如果是在最高層級的開始位置
  if (isAtStart && isTopLevel) {
    // 獲取 doc 層級的索引位置
    const docIndex = $pos.index(0); // 0 是 doc 層級
    const doc = $pos.node(0);

    // 檢查是否有前一個同層級節點，且是列表
    if (docIndex > 0) {
      const prevNode = doc.child(docIndex - 1);

      if (['bulletList', 'orderedList', 'taskList'].includes(prevNode.type.name)) {
        // 遞迴找到最深層的 text 節點和其深度
        const findDeepestLastText = (node, depth = 0) => {
          // 如果是 text 節點，直接返回
          if (node.isText) {
            return {
              node,
              text: node.text,
              depth: depth  // 返回累積的深度
            };
          }

          // 如果有子節點，繼續往下找，深度+1
          if (node.lastChild) {
            return findDeepestLastText(node.lastChild, depth + 1);
          }

          return null;
        };

        // 找到最深層的 text 節點和深度
        const lastText = findDeepestLastText(prevNode);
        const lastTextDepth = lastText?.depth || 0;  // 如果沒有找到，默認為0

        // 將當前節點的文本插入到最深層的 text 節點中

        editor.chain()
          .focus()
          .command(({ tr, state, dispatch }) => {
            const { $from } = state.selection;
            const currentNode = $from.parent;
            const currentText = currentNode.textContent;

            // 創建一個新的 transaction
            if (dispatch) {
              // 1. 先刪除當前節點
              const nodePos = $from.before();
              tr.delete(nodePos, nodePos + currentNode.nodeSize);

              // 2. 在正確的位置插入文本
              if (currentText) {
                const insertPos = from - 1 - lastTextDepth;
                const textNode = state.schema.text(currentText);
                tr.insert(insertPos, textNode);

                // 3. 設置游標位置到插入點
                tr.setSelection(state.selection.constructor.near(
                  tr.doc.resolve(insertPos)
                ));
              } else {
                // 當文本為空時，我們仍需要設置游標位置
                // 計算正確的插入位置：從當前位置減去深度偏移
                const insertPos = from - 1 - lastTextDepth;

                // 設置游標到插入位置
                tr.setSelection(state.selection.constructor.near(
                  tr.doc.resolve(insertPos)
                ));
              }

              dispatch(tr);
            }

            return true;
          })
          .run();

        return true;
      }

    }
  }

  // 如果在列表項的開始位置且不是最高層級，且不是空節點，則檢查是否為混合列表結構
  if (isAtStart && !isTopLevel && !isEmptyNode && (
    editor.isActive('bulletList') ||
    editor.isActive('orderedList') ||
    editor.isActive('taskList')
  )) {
    return handleMixedListBackspace(editor, from);
  }

  return false;
};

// 處理混合列表結構的 backspace 邏輯
const handleMixedListBackspace = (editor, from) => {
  const logKey = '[MixedListBackspace]';

  // 檢查當前是否為混合列表結構
  const $currentPos = editor.state.selection.$from;
  const currentDepth = $currentPos.depth;
  let isMixedListStructure = false;
  let grandParentListType = null;
  let currentListType = null;

  // 檢查父層和祖父層的列表類型
  if (currentDepth >= 3) {
    // 獲取當前列表類型（父層）
    for (let d = currentDepth; d > 0; d--) {
      const node = $currentPos.node(d);
      if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
        if (!currentListType) {
          currentListType = node.type.name;
        } else if (!grandParentListType) {
          grandParentListType = node.type.name;
          break;
        }
      }
    }

    // 檢查是否為混合結構
    if (currentListType && grandParentListType && currentListType !== grandParentListType) {
      isMixedListStructure = true;

    }
  }

  if (isMixedListStructure && grandParentListType) {

    // 記錄轉換前的原始結構
    const originalPos = editor.state.selection.$from;
    let originalParentDepth = -1;
    let originalCurrentIndex = -1;
    let originalSiblings = [];

    // 找到當前項目在其父列表中的位置
    for (let d = originalPos.depth; d > 0; d--) {
      const node = originalPos.node(d);
      if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
        originalParentDepth = d - 1;
        const parent = originalPos.node(originalParentDepth);
        originalCurrentIndex = originalPos.index(originalParentDepth);

        // 記錄所有同階層的兄弟節點
        for (let i = 0; i < parent.childCount; i++) {
          const sibling = parent.child(i);

          // 只取兄弟節點內第一個段落的內容
          let siblingContent = '';
          let siblingDepth = -1;
          let isFirstParagraph = true;  // 標記是否為第一個段落

          sibling.descendants((node, pos) => {
            if (node.type.name === 'paragraph' && isFirstParagraph) {
              siblingContent = node.textContent || '';  // 只取第一個段落的內容
              siblingDepth = originalParentDepth + 1;
              isFirstParagraph = false;  // 找到第一個段落後就不再收集
              return false; // 找到第一個段落就停止
            }
            // 如果遇到新的列表，就跳過這個分支
            if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
              return false;
            }
            return true;
          });

          // 只有當找到有效的段落內容時才添加到兄弟節點列表
          if (siblingContent && siblingDepth === originalParentDepth + 1) {
            originalSiblings.push({
              index: i,
              type: sibling.type.name,
              content: siblingContent,
              depth: siblingDepth,  // 記錄原始深度
              isCurrent: i === originalCurrentIndex
            });

          }
        }
        break;
      }
    }

    // 確定需要轉換的節點
    const needToConvert = [];
    if (originalCurrentIndex > 0) {
      needToConvert.push({
        originalIndex: originalCurrentIndex - 1,
        position: 'previous',
        sibling: originalSiblings[originalCurrentIndex - 1]
      });
    }
    if (originalCurrentIndex < originalSiblings.length - 1) {
      needToConvert.push({
        originalIndex: originalCurrentIndex + 1,
        position: 'next',
        sibling: originalSiblings[originalCurrentIndex + 1]
      });
    }

    // 步驟1: 使用 listButtonUtil 轉換當前項目為祖父列表類型
    handleListChange(editor, grandParentListType);

    // 步驟2: 執行列表項提升

    if (grandParentListType === 'taskList') {
      editor.chain().focus().liftListItem('taskItem').run();
    } else {
      editor.chain().focus().liftListItem('listItem').run();
    }

    // 步驟3: 轉換兄弟節點回原本的類別

    // 記錄已處理的節點位置，避免重複選擇
    const processedPositions = new Set();

    // 處理節點的通用函數
    const processNode = (nodeToProcess, nodeIndex) => {

      // 獲取當前節點位置
      const { from: currentPos } = editor.state.selection;

      let foundPos = -1;
      let bestDistance = Infinity;

      // 用內容匹配找到轉換後的對應節點，選擇最靠近當前位置且深度匹配的
      editor.state.doc.descendants((node, pos) => {
        if (node.type.name === 'paragraph' && node.textContent === nodeToProcess.sibling.content) {
          const $pos = editor.state.doc.resolve(pos);
          const currentDepth = $pos.depth;


          // 檢查是否已經處理過這個位置
          if (processedPositions.has(pos)) {

            return;
          }

          // 檢查深度是否匹配
          if (currentDepth !== nodeToProcess.sibling.depth) {

            return;
          }

          // 根據位置選擇方向
          if (nodeToProcess.position === 'next' && pos > currentPos) {
            const distance = pos - currentPos;
            if (distance < bestDistance) {
              bestDistance = distance;
              foundPos = pos;

            }
          }
          else if (nodeToProcess.position === 'previous' && pos < currentPos) {
            const distance = currentPos - pos;
            if (distance < bestDistance) {
              bestDistance = distance;
              foundPos = pos;

            }
          }
        }
      });

      if (foundPos >= 0) {
        // 記錄這個位置已被處理
        processedPositions.add(foundPos);

        // 移動 focus 到找到的節點
        const $foundPos = editor.state.doc.resolve(foundPos);
        const safeSelection = editor.state.selection.constructor.near($foundPos);
        const tr = editor.state.tr.setSelection(safeSelection);
        editor.view.dispatch(tr);

        // 轉換回原本的列表類型

        handleListChange(editor, currentListType);

        return true;
      } else {

        return false;
      }
    };

    // 先處理第二個節點（index 1）
    if (needToConvert.length > 1) {
      processNode(needToConvert[1], 2);
    }

    // 再處理第一個節點（index 0）
    if (needToConvert.length > 0) {
      processNode(needToConvert[0], 1);
    }

    // 回到原始位置並確保選區安全

    const $pos = editor.state.doc.resolve(from);
    const safeSelection = editor.state.selection.constructor.near($pos);
    const tr = editor.state.tr.setSelection(safeSelection);
    editor.view.dispatch(tr);

    return true;
  } else {

    // 根據列表類型選擇正確的 item 類型
    const $currentPos = editor.state.selection.$from;
    let currentListType = null;
    if (currentDepth >= 3) {
      for (let d = currentDepth; d > 0; d--) {
        const node = $currentPos.node(d);
        if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
          if (!currentListType) {
            currentListType = node.type.name;
          } else if (!grandParentListType) {
            grandParentListType = node.type.name;
            break;
          }
        }
      }
    }

    // 根據列表類型選擇正確的 item 類型

    if (currentListType === 'taskList') {

      return editor.chain().focus().liftListItem('taskItem').run();
    } else {

      return editor.chain().focus().liftListItem('listItem').run();
    }
  }
};

// 處理列表的Tab鍵邏輯
export const handleListTab = (editor, event, from) => {
  // 獲取當前光標位置
  const $pos = editor.state.doc.resolve(from);

  // 檢查是否在列表項中
  let depth = $pos.depth;
  let isInListItem = false;

  // 向上遍歷節點樹，查找列表項
  while (depth > 0) {
    const node = $pos.node(depth);
    if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
      isInListItem = true;
      break;
    }
    depth--;
  }

  // 如果在列表項中，處理列表項的縮進
  if (isInListItem) {
    // 檢查當前列表結構
    let currentListType = null;
    let parentListType = null;

    // 向上遍歷找出當前列表類型和父列表類型
    for (let d = depth; d > 0; d--) {
      const node = $pos.node(d);
      if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
        if (!currentListType) {
          currentListType = node.type.name;
        } else if (!parentListType) {
          parentListType = node.type.name;
          break;
        }
      }
    }

    const isMixedList = currentListType && parentListType && currentListType !== parentListType;

    // 根據是否按下Shift鍵決定是升階還是降階
    if (event.shiftKey) {
      // 使用 handleListBackspace 處理升階
      handleListBackspace(editor);
    } else {

      editor.chain().focus().sinkListItem(currentListType === 'taskList' ? 'taskItem' : 'listItem').run();
    }
    return true;
  }
  return false;
}; 