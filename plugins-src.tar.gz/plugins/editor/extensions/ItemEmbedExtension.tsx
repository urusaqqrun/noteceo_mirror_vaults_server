// ItemEmbedExtension — 通用嵌入式預覽（editor 基礎設施）
//
// 解析 <note-embed note-id="xxx"> HTML 標籤，透過 EmbedRendererRegistry
// 委派渲染給各插件註冊的 renderer。AI Commander 不需要知道 item 類型。
//
// 渲染流程：
//   1. 從 HTML 取得 note-id
//   2. electronAPI.getItem(id) 查詢 item 類型
//   3. EmbedRendererRegistry.getRenderer(itemType) 取得對應 renderer
//   4. 委派渲染

import { Node, mergeAttributes } from '@tiptap/core';
import { ReactNodeViewRenderer, NodeViewWrapper } from '@tiptap/react';
import React, { useState, useEffect } from 'react';
import { useEmbedRendererRegistry } from '../../../../Store/embedRendererRegistry';

const ItemEmbedComponent = ({ node }) => {
  const itemId = node.attrs.noteId;
  const [item, setItem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const renderers = useEmbedRendererRegistry(state => state.renderers);

  useEffect(() => {
    if (!itemId) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const result = await (window as any).electronAPI?.getItem(itemId);
        if (!cancelled) {
          setItem(result || null);
          setLoading(false);
        }
      } catch {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [itemId]);

  if (!itemId) return null;
  if (loading) return null;
  if (!item) return null;

  const itemType = item.itemType;
  const renderer = useEmbedRendererRegistry.getState().getRenderer(itemType);

  if (!renderer) {
    // 沒有插件註冊這個類型的 renderer，靜默跳過
    return null;
  }

  const RendererComponent = renderer.component;

  return (
    <NodeViewWrapper className="note-embed-wrapper" style={{ width: '100%' }}>
      <RendererComponent itemId={itemId} item={item} />
    </NodeViewWrapper>
  );
};

export const ItemEmbedExtension = Node.create({
  name: 'noteEmbed',
  group: 'block',
  selectable: false,
  atom: true,
  addAttributes() {
    return {
      noteId: {
        default: null,
        parseHTML: element => element.getAttribute('note-id'),
        renderHTML: attributes => {
          if (!attributes.noteId) return {};
          return {
            'note-id': attributes.noteId,
          };
        },
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'note-embed',
        getAttrs: element => ({
          noteId: element.getAttribute('note-id'),
        }),
      },
      // 向後相容：解析舊的 <note-chart chart-id="xxx"> 標籤
      {
        tag: 'note-chart',
        getAttrs: element => ({
          noteId: element.getAttribute('chart-id'),
        }),
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['note-embed', mergeAttributes(HTMLAttributes)];
  },

  addNodeView() {
    return ReactNodeViewRenderer(ItemEmbedComponent);
  },
});
