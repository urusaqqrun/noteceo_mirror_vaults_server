import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from 'prosemirror-state'
import { NodeSelection } from '@tiptap/pm/state'
import { DOMParser as ProseMirrorDOMParser, DOMSerializer } from 'prosemirror-model'
import { htmlToMarkdown, markdownToHtml } from '../../../../utils/mdConverter'

import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import { useTempHintStore } from '../../../../Store/uiStore';
import { isWeb } from '../../../../utils/platform'
import i18n from '../../../../i18n/config'
import { eventBus } from '../../../../Store/eventBus'

async function resolveClipboardLink(url: string): Promise<string | null> {
  const match = url.match(/^cubelv:\/\/[a-z]+\/([a-zA-Z0-9]+)/i);
  if (!match) return null;
  const item = await (window.electronAPI as any).getItem(match[1]);
  return item?.name || null;
}
// 檔案名稱暫存
let lastFileName = '';
let fileCounter = 1;

// 將外部圖片 URL 下載並轉成 base64
async function imageUrlToBase64(url) {
  try {
    // 使用 Electron IPC 處理器獲取圖片數據，繞過 CORS 限制
    const response = await window.electronAPI.fetchImage({ url });

    if (!response.ok) {
      throw new Error(`圖片獲取失敗: HTTP ${response.status}`);
    }

    // response.data 已經是 base64 格式，需要加上 data URI 前綴
    const base64Data = `data:${response.contentType};base64,${response.data}`;

    return base64Data;
  } catch (err) {
    console.error('下載圖片失敗:', err);
    return null;
  }
}

// 計算顏色的亮度 (0-1)
function calculateBrightness(color) {
  // 處理十六進制顏色
  if (color.startsWith('#')) {
    const hex = color.replace('#', '');
    let r, g, b;

    if (hex.length === 3) {
      // 簡寫格式 #RGB
      r = parseInt(hex[0] + hex[0], 16);
      g = parseInt(hex[1] + hex[1], 16);
      b = parseInt(hex[2] + hex[2], 16);
    } else {
      // 標準格式 #RRGGBB
      r = parseInt(hex.substr(0, 2), 16);
      g = parseInt(hex.substr(2, 2), 16);
      b = parseInt(hex.substr(4, 2), 16);
    }

    // 加權亮度計算 (人眼對綠色更敏感)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  }

  // 處理 RGB 格式
  if (color.toLowerCase().startsWith('rgb(')) {
    const rgbMatch = color.match(/rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1], 10);
      const g = parseInt(rgbMatch[2], 10);
      const b = parseInt(rgbMatch[3], 10);

      // 加權亮度計算
      return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    }
  }

  // 默認亮度 (中等)
  return 0.5;
}

// 將 RGB 轉換為 HSL
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0; // 灰階
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }

    h /= 6;
  }

  return [h, s, l];
}

// 將 HSL 轉換為 RGB
function hslToRgb(h, s, l) {
  let r, g, b;

  if (s === 0) {
    r = g = b = l; // 灰階
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;

    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }

  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

// 只反轉亮度，保持色相和飽和度
function invertBrightness(color) {
  // 處理十六進制顏色
  if (color.startsWith('#')) {
    const hex = color.replace('#', '');
    let r, g, b;

    if (hex.length === 3) {
      // 簡寫格式 #RGB
      r = parseInt(hex[0] + hex[0], 16);
      g = parseInt(hex[1] + hex[1], 16);
      b = parseInt(hex[2] + hex[2], 16);
    } else {
      // 標準格式 #RRGGBB
      r = parseInt(hex.substr(0, 2), 16);
      g = parseInt(hex.substr(2, 2), 16);
      b = parseInt(hex.substr(4, 2), 16);
    }

    // 轉換為 HSL，反轉亮度，再轉回 RGB
    const [h, s, l] = rgbToHsl(r, g, b);
    const newL = 1 - l; // 反轉亮度
    const [newR, newG, newB] = hslToRgb(h, s, newL);

    // 轉回十六進制
    return `#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`;
  }

  // 處理 RGB 格式
  if (color.toLowerCase().startsWith('rgb(')) {
    const rgbMatch = color.match(/rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1], 10);
      const g = parseInt(rgbMatch[2], 10);
      const b = parseInt(rgbMatch[3], 10);

      // 轉換為 HSL，反轉亮度，再轉回 RGB
      const [h, s, l] = rgbToHsl(r, g, b);
      const newL = 1 - l; // 反轉亮度
      const [newR, newG, newB] = hslToRgb(h, s, newL);

      return `rgb(${newR}, ${newG}, ${newB})`;
    }
  }

  // 如果不是支援的格式，返回原始顏色
  return color;
}

// 移除超連結中的顏色樣式
function removeLinkColors(html) {

  // 找出所有 <a> 標籤內的 <span> 標籤，並移除其中的顏色樣式
  let modifiedHtml = html;

  // 匹配 <a> 標籤內的內容
  const linkRegex = /<a\s[^>]*>(.*?)<\/a>/gi;
  let linkMatch;

  while ((linkMatch = linkRegex.exec(html)) !== null) {
    const fullLink = linkMatch[0];  // 完整的 <a> 標籤
    const linkContent = linkMatch[1]; // <a> 標籤內的內容

    // 在連結內容中移除所有顏色樣式
    let processedLinkContent = linkContent;

    // 移除 span 標籤中的 color 樣式
    processedLinkContent = processedLinkContent.replace(
      /<span\s+style\s*=\s*["']([^"']*?)["']\s*>/gi,
      (match, styleContent) => {
        // 移除 color 屬性，保留其他樣式
        const newStyleContent = styleContent.replace(/color:\s*[^;]+;?/gi, '').trim();

        // 如果移除顏色後還有其他樣式，保留 span 標籤
        if (newStyleContent && newStyleContent !== '') {
          // 清理多餘的分號
          const cleanedStyle = newStyleContent.replace(/;+$/, '').replace(/^;+/, '');
          return cleanedStyle ? `<span style="${cleanedStyle}">` : '<span>';
        } else {
          // 如果沒有其他樣式，移除 style 屬性
          return '<span>';
        }
      }
    );

    // 移除空的 style 屬性
    processedLinkContent = processedLinkContent.replace(/<span\s+style\s*=\s*["']\s*["']\s*>/gi, '<span>');

    // 創建新的連結標籤
    const newLink = fullLink.replace(linkContent, processedLinkContent);

    // 替換原始 HTML 中的連結
    modifiedHtml = modifiedHtml.replace(fullLink, newLink);

  }

  return modifiedHtml;
}

// 處理 HTML 中的顏色屬性
function processHtmlColors(html, currentTheme) {

  // 先移除超連結中的顏色樣式
  let modifiedHtml = removeLinkColors(html);

  // 使用更強大的方法處理複雜 HTML 結構中的顏色
  // 先找出所有帶 style 屬性的標籤
  const styleTagRegex = /style\s*=\s*["']([^"']*)["']/gi;
  let match;
  let colorReplacements = 0;

  // 遍歷所有 style 屬性
  while ((match = styleTagRegex.exec(modifiedHtml)) !== null) {
    const fullStyleAttr = match[0];  // style="..."
    const styleContent = match[1];   // 實際樣式內容

    // 找出樣式中的顏色屬性
    const colorMatch = /color:\s*(#[0-9a-f]{3,6}|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\))/i.exec(styleContent);

    if (colorMatch) {
      const originalColor = colorMatch[1]; // 原始顏色值

      // 計算顏色亮度
      const brightness = calculateBrightness(originalColor);

      // 根據主題和亮度決定是否需要反轉
      let needsInversion = false;

      if (currentTheme === 'dark' && brightness < 0.5) {
        // 深色主題下，亮度過低需要反轉
        needsInversion = true;

      } else if (currentTheme === 'light' && brightness > 0.5) {
        // 淺色主題下，亮度過高需要反轉
        needsInversion = true;

      }

      // 如果需要反轉，處理顏色
      if (needsInversion) {
        const invertedColor = invertBrightness(originalColor);

        // 創建新的 style 屬性內容
        const newStyleContent = styleContent.replace(
          /color:\s*(#[0-9a-f]{3,6}|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\))/i,
          `color: ${invertedColor}`
        );

        // 創建新的完整 style 屬性
        const newStyleAttr = fullStyleAttr.replace(styleContent, newStyleContent);

        // 將新的 style 屬性替換到 HTML 中
        modifiedHtml = modifiedHtml.replace(fullStyleAttr, newStyleAttr);
        colorReplacements++;
      } else {

      }
    }
  }

  return modifiedHtml;
}

// turndown / markdown-it 實例已統一在 mdConverter.js 中管理

// 檢查文字是否為 Markdown 格式
function isMarkdown(text) {
  // 檢查常見的 Markdown 語法特徵
  const markdownPatterns = [
    /^#{1,6}\s/, // 標題
    /^[*-]\s/, // 無序列表
    /^\d+\.\s/, // 有序列表
    /^>\s/, // 引用
    /^```/, // 程式碼區塊
    /\[.*?\]\(.*?\)/, // 連結
    /\*\*.*?\*\*/, // 粗體
    /\*.*?\*/, // 斜體
    /^---/, // 分隔線
    /^===/, // 另一種標題格式
    /^\|.*\|.*\|/, // 表格
    /^- \[ \]/, // 待辦事項
  ];

  // 將文字分行檢查
  const lines = text.split('\n');

  // 檢查是否至少有一行符合 Markdown 語法
  return lines.some(line =>
    markdownPatterns.some(pattern => pattern.test(line.trim()))
  );
}

// 添加圖片上傳處理函數
const handleImageUpload = async (blob, editor) => {
  try {
    // 設置上傳狀態
    editor.commands.setIsUploading(true);

    // 獲取用戶資料
    const userData = JSON.parse(localStorage.getItem('userData_local'));
    if (!userData?.ID) {
      throw new Error('找不到用戶資料，請重新登入');
    }

    // 將 blob 轉換為 File 對象
    const file = new File([blob], 'pasted-image.jpg', { type: blob.type });

    // 使用與一般上傳相同的函數
    const { uploadFile, validateFile } = await import('../../../../utils/fileUpload');

    // 驗證檔案（放寬到 10MB，因為之後會壓縮）
    const validation = validateFile(file, 'images', 10 * 1024 * 1024);
    if (!validation.isValid) {
      throw new Error(validation.errors.join('，'));
    }

    // 檢查網路狀態
    const isOnline = navigator.onLine;

    if (isOnline) {
      try {
        // 圖片壓縮選項
        const imageCompressOptions = {
          maxWidth: 1920,
          maxHeight: 1920,
          quality: 0.8,
          maxSizeKB: 2048, // 壓縮到2MB以下
          outputFormat: 'image/jpeg'
        };

        const uploadResult = await uploadFile(file, userData.ID, 'images', imageCompressOptions);

        // 觸發圖片上傳完成事件
        const editorElement = document.querySelector('.note-editor');
        if (editorElement) {
          const event = new CustomEvent('imageUploaded', {
            detail: { imageUrl: uploadResult.downloadURL, isLocal: false }
          });
          editorElement.dispatchEvent(event);
        }

        return uploadResult.downloadURL;

      } catch (uploadError) {
        // 網路上傳失敗

        if (isWeb) {
          // Web 版本不支援離線模式
          throw new Error(i18n.t('imageUploadFailed'));
        } else {
          // Electron 版本使用離線模式
          return await handleOfflineImageUpload(file, editor);
        }
      }
    } else {
      // 離線狀態
      if (isWeb) {
        // Web 版本不支援離線模式
        throw new Error(i18n.t('pleaseCheckNetwork'));
      } else {
        // Electron 版本，直接保存本地

        return await handleOfflineImageUpload(file, editor);
      }
    }

  } catch (error) {
    console.error('處理圖片失敗:', error);
    throw error;
  } finally {
    // 清除上傳狀態
    editor.commands.setIsUploading(false);
  }
};

// 處理離線圖片上傳
const handleOfflineImageUpload = async (file, editor) => {
  try {
    // 將文件轉換為 base64
    const reader = new FileReader();
    const localImageData = await new Promise((resolve, reject) => {
      reader.onload = (event) => {
        resolve(event.target.result);
      };
      reader.onerror = (error) => {
        reject(error);
      };
      reader.readAsDataURL(file);
    });

    // 觸發離線圖片保存事件
    const editorElement = document.querySelector('.note-editor');
    if (editorElement) {
      const event = new CustomEvent('imageUploaded', {
        detail: { imageUrl: localImageData, isLocal: true }
      });
      editorElement.dispatchEvent(event);
    }

    return localImageData;

  } catch (error) {
    console.error('離線保存圖片失敗:', error);
    throw error;
  }
};

export const MarkdownClipboard = Extension.create({
  name: 'markdownClipboard',

  addStorage() {
    return {
      copiedCode: null
    };
  },

  addCommands(): any {
    return {
      setIsUploading: (isUploading) => ({ commands }) => {
        // 找到編輯器實例並設置狀態
        const editorElement = document.querySelector('.note-editor');
        if (editorElement) {
          const event = new CustomEvent('setIsUploading', { detail: { isUploading } });
          editorElement.dispatchEvent(event);
        }
        return true;
      }
    }
  },

  onCreate() {

  },

  onTransaction() {
  },

  addProseMirrorPlugins() {

    return [
      new Plugin({
        key: new PluginKey('markdown-clipboard'),
        props: {
          handleDOMEvents: {
            copy: (async (view, event) => {
              event.preventDefault();

              const { state } = view;
              const { selection } = state;
              const { from, to } = selection;

              if (selection.empty) {
                return false;
              }

              try {
                // 重新判斷：檢查選取區是否「僅包含單一張圖片」
                const slice = state.doc.slice(from, to);
                const isImageOnly = slice.content.childCount === 1 && slice.content.firstChild?.type?.name === 'image';

                // 另一種檢查方式：檢查是否為 NodeSelection 且選中的是圖片
                const isImageNodeSelection = selection instanceof NodeSelection && selection.node.type.name === 'image';

                // 使用兩種檢查方式，只要其中一種成立就認為是選中圖片
                if (isImageOnly || isImageNodeSelection) {
                  const imageSrc = isImageNodeSelection ? selection.node.attrs.src : slice.content.firstChild.attrs.src;

                  let base64Image = imageSrc;

                  // 若圖片來源不是 base64，先下載並轉成 base64
                  if (!imageSrc.startsWith('data:image')) {

                    base64Image = await imageUrlToBase64(imageSrc);

                    if (!base64Image) return false;
                  }

                  // 先寫入 HTML
                  await window.electronClipboard.writeContent(`<img src="${imageSrc}">`, '');

                  // 取得當前筆記標題作為檔案名稱
                  let fileName = `clipboard-${Date.now()}.png`; // 預設名稱
                  try {
                    const currentItemId = useSelectedItemsStore.getState().path.at(-1)?.id;
                    if (currentItemId) {
                      const item = await (window.electronAPI as any).getItem(currentItemId);                      if (item) {
                        const itemName = item.name || i18n.t('untitled');
                        // 清理檔案名稱中的非法字符
                        const cleanTitle = itemName.replace(/[<>:"/\\|?*]/g, '').slice(0, 50);
                        const baseName = cleanTitle === i18n.t('untitled') ? `${cleanTitle}-${Date.now()}` : cleanTitle;
                        if (lastFileName === baseName) fileCounter++; else { lastFileName = baseName; fileCounter = 1; }
                        fileName = fileCounter === 1 ? `${baseName}.png` : `${baseName}${fileCounter}.png`;
                      }
                    }
                  } catch (error) {

                  }

                  // 再根據平台寫入圖片或檔案 URL
                  await (window.electron?.platform === 'darwin' && window.electronClipboard.writeImageFile
                    ? window.electronClipboard.writeImageFile(base64Image, fileName)
                    : window.electronClipboard.writeImage(base64Image));
                  return true;
                }

                // 使用一般的 HTML 複製邏輯
                const serializer = DOMSerializer.fromSchema(state.schema);
                const fragment = serializer.serializeFragment(state.doc.slice(selection.from, selection.to).content);
                const tempDiv = document.createElement('div');
                tempDiv.appendChild(fragment);
                const html = tempDiv.innerHTML;

                // 使用 turndown 將 HTML 轉換為 Markdown
                const markdown = htmlToMarkdown(html);
                this.storage.copiedCode = null;

                // 寫入 HTML 和 Markdown 到剪貼板
                await window.electronClipboard.writeContent(html, markdown);
                return true;

              } catch (error) {
                console.error('複製失敗:', error);
                return false;
              }
            }) as any,
            cut: (async (view, event) => {
              event.preventDefault();

              const { state } = view;
              const { selection } = state;
              const { from, to } = selection;

              if (selection.empty) {
                return false;
              }

              try {
                const sliceCut = state.doc.slice(from, to);
                const isImageOnly = sliceCut.content.childCount === 1 && sliceCut.content.firstChild?.type?.name === 'image';

                if (isImageOnly) {
                  const imageSrc = sliceCut.content.firstChild.attrs.src;

                  let base64Image = imageSrc;

                  if (!imageSrc.startsWith('data:image')) {
                    base64Image = await imageUrlToBase64(imageSrc);
                    if (!base64Image) return false;
                  }

                  await window.electronClipboard.writeContent(`<img src="${imageSrc}">`, '');

                  // 取得當前筆記標題作為檔案名稱
                  let fileName = `clipboard-${Date.now()}.png`; // 預設名稱
                  try {
                    const currentItemId = useSelectedItemsStore.getState().path.at(-1)?.id;
                    if (currentItemId) {
                      const item = await (window.electronAPI as any).getItem(currentItemId);                      if (item) {
                        const itemName = item.name || i18n.t('untitled');
                        // 清理檔案名稱中的非法字符
                        const cleanTitle = itemName.replace(/[<>:"/\\|?*]/g, '').slice(0, 50);
                        const baseName = cleanTitle === i18n.t('untitled') ? `${cleanTitle}-${Date.now()}` : cleanTitle;
                        if (lastFileName === baseName) fileCounter++; else { lastFileName = baseName; fileCounter = 1; }
                        fileName = fileCounter === 1 ? `${baseName}.png` : `${baseName}${fileCounter}.png`;
                      }
                    }
                  } catch (error) {

                  }

                  await (window.electron?.platform === 'darwin' && window.electronClipboard.writeImageFile
                    ? window.electronClipboard.writeImageFile(base64Image, fileName)
                    : window.electronClipboard.writeImage(base64Image));

                  // 刪除選中內容
                  view.dispatch(view.state.tr.deleteSelection());

                  return true;
                }

                // 使用一般的 HTML 複製邏輯
                const serializer = DOMSerializer.fromSchema(state.schema);
                const fragment = serializer.serializeFragment(state.doc.slice(selection.from, selection.to).content);
                const tempDiv = document.createElement('div');
                tempDiv.appendChild(fragment);
                const html = tempDiv.innerHTML;

                // 使用 turndown 將 HTML 轉換為 Markdown
                const markdown = htmlToMarkdown(html);

                // 寫入 HTML 和 Markdown 到剪貼板
                await window.electronClipboard.writeContent(html, markdown);

                // 刪除選中內容
                view.dispatch(view.state.tr.deleteSelection());

                return true;
              } catch (error) {
                console.error('剪下失敗:', error);
                return false;
              }
            }) as any
          },
          handlePaste: (async (view, event) => {
            try {

              // 檢查是否在 codeBlock 內，如果是則直接插入純文字
              const { $from } = view.state.selection;
              const isInCodeBlock = $from.parent.type.name === 'codeBlock';
              if (isInCodeBlock) {
                const clipboardText = event.clipboardData.getData('text/plain');
                if (clipboardText) {
                  event.preventDefault();
                  // 直接插入純文字，保留所有換行
                  const tr = view.state.tr.insertText(clipboardText);
                  view.dispatch(tr);
                  return true;
                }
              }

              // 先讀取剪貼板所有內容
              const clipboardHtmlData = event.clipboardData.getData('text/html');
              const clipboardTextData = event.clipboardData.getData('text/plain');
              const clipboardItems = Array.from(event.clipboardData?.items || []) as DataTransferItem[];

              // 從 document 屬性獲取主題
              const currentTheme = document.documentElement.dataset.theme || 'light';

              // 檢查貼上文本是否符合已註冊的 cubelv:// 連結格式
              try {
                const clipboardText = clipboardTextData;

                if (clipboardText) {
                  const linkText = await resolveClipboardLink(clipboardText.trim());
                  if (linkText !== null) {
                    event.preventDefault();
                    const link = view.state.schema.marks.link.create({
                      href: clipboardText,
                      class: 'editor-link',
                      target: '_blank'
                    });
                    const tr = view.state.tr;
                    tr.replaceSelectionWith(
                      view.state.schema.text(linkText, [link]),
                      false
                    );
                    view.dispatch(tr);
                    return true;
                  }
                }
              } catch (error) {
                console.error('處理 CubeLV 連結時出錯:', error);
                // 繼續正常的貼上流程
              }

              // 先处理剪贴板中的图片数据
              const imageItems = clipboardItems.filter(item => item.type.indexOf('image') === 0);

              if (imageItems.length > 0) {

                event.preventDefault();

                for (const item of imageItems) {
                  const blob = item.getAsFile();

                  try {
                    // 使用與一般上傳相同的處理流程，傳入 editor
                    const imageUrl = await handleImageUpload(blob, this.editor);

                    // 插入圖片到編輯器
                    view.dispatch(
                      view.state.tr.replaceSelectionWith(
                        view.state.schema.nodes.image.create({ src: imageUrl })
                      )
                    );

                  } catch (error) {
                    console.error('處理圖片失敗:', error);
                    useTempHintStore.getState().setTempHint(error.message || i18n.t('imageUploadFailed'));
                  }
                }
                return true;
              }

              // 如果 clipboardData 有實質的 HTML（不只是簡單包裝），使用 HTML 處理
              if (clipboardHtmlData && clipboardHtmlData.trim() && clipboardHtmlData !== clipboardTextData) {

                // 處理連續空格問題：將連續空格轉換為 &nbsp; 實體
                let processedHtml = clipboardHtmlData.replace(/ {2,}/g, match => {
                  return Array(match.length).fill('&nbsp;').join('');
                });

                // 處理 HTML 中的 base64 圖片
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = processedHtml;
                const images = tempDiv.getElementsByTagName('img');

                // 收集所有圖片處理的 Promise
                const imagePromises = [];

                // 處理所有圖片
                for (let i = 0; i < images.length; i++) {
                  const img = images[i];
                  // 處理 base64 圖片
                  if (img.src.startsWith('data:image')) {
                    imagePromises.push((async () => {
                      try {
                        // 將 base64 轉換為 blob
                        const response = await fetch(img.src);
                        const blob = await response.blob();

                        // 上傳圖片
                        const imageUrl = await handleImageUpload(blob, this.editor);

                        // 更新 HTML 中的圖片源
                        img.src = imageUrl;
                      } catch (error) {
                        console.error('處理 HTML 中的圖片失敗:', error);
                      }
                    })());
                  }
                  // 處理外部圖片 URL
                  else if (img.src.startsWith('http')) {
                    imagePromises.push((async () => {
                      try {

                        // 下載外部圖片
                        const response = await fetch(img.src);
                        const blob = await response.blob();

                        // 檢查是否真的是圖片
                        if (blob.type.startsWith('image/')) {
                          // 上傳圖片
                          const imageUrl = await handleImageUpload(blob, this.editor);

                          // 更新 HTML 中的圖片源
                          img.src = imageUrl;

                        } else {

                        }
                      } catch (error) {
                        console.error('處理外部圖片失敗:', error);
                      }
                    })());
                  }
                }

                // 等待所有圖片處理完成
                await Promise.all(imagePromises);

                // 處理 HTML 中的顏色屬性
                processedHtml = processHtmlColors(tempDiv.innerHTML, currentTheme);

                const parser = ProseMirrorDOMParser.fromSchema(view.state.schema);
                const dom = document.createElement('div');
                dom.innerHTML = processedHtml;
                const slice = parser.parseSlice(dom);

                view.dispatch(view.state.tr.replaceSelection(slice));
                return true;
              }

              if (clipboardTextData) {

                // 判斷是否為 Markdown
                if (isMarkdown(clipboardTextData)) {

                  const renderedHtml = markdownToHtml(clipboardTextData);

                  // 處理連續空格問題：將連續空格轉換為 &nbsp; 實體
                  let processedHtml = renderedHtml.replace(/ {2,}/g, match => {
                    return Array(match.length).fill('&nbsp;').join('');
                  });

                  // 處理 HTML 中的顏色屬性
                  processedHtml = processHtmlColors(processedHtml, currentTheme);

                  const parser = ProseMirrorDOMParser.fromSchema(view.state.schema);
                  const dom = document.createElement('div');
                  dom.innerHTML = processedHtml;
                  const slice = parser.parseSlice(dom);

                  view.dispatch(view.state.tr.replaceSelection(slice));
                } else {

                  // 按空行分割段落
                  const paragraphs = clipboardTextData.split(/\n\s*\n/);

                  const formattedHtml = paragraphs
                    .map(paragraph => {
                      const trimmedParagraph = paragraph.trim();
                      if (!trimmedParagraph) return '';

                      // 段落內的換行保留為 <br>，並處理連續空格
                      const processedParagraph = trimmedParagraph
                        .split('\n')
                        .map(line => {
                          return line.replace(/ {2,}/g, match => {
                            return Array(match.length).fill('&nbsp;').join('');
                          });
                        })
                        .join('<br>');

                      return `<p>${processedParagraph}</p>`;
                    })
                    .filter(p => p)
                    .join('');


                  const parser = ProseMirrorDOMParser.fromSchema(view.state.schema);
                  const dom = document.createElement('div');
                  dom.innerHTML = formattedHtml;
                  const slice = parser.parseSlice(dom);

                  view.dispatch(view.state.tr.replaceSelection(slice));
                }
                return true;
              }
            } catch (error) {
              console.error('貼上失敗:', error);
              console.error('错误堆栈:', error.stack);
            }

            return false;
          }) as any,
          // 跨區域拖曳 → eventBus（傳出 editor + pos，source 自己用 tiptap API 插內容）
          handleDrop: (async (view, event, slice, moved) => {
            if (moved) return false;

            const dragItemsStr = event.dataTransfer?.getData('dragItems');
            if (dragItemsStr) {
              event.preventDefault();

              let dropPos = null;
              try {
                const coords = view.posAtCoords({ left: event.clientX, top: event.clientY });
                if (coords) dropPos = coords.pos;
              } catch (e) { }

              const items: { id: string }[] = JSON.parse(dragItemsStr || '[]');

              await eventBus.emit(
                'drop:markdown-editor',
                items, {}, this.editor, dropPos
              );
              return true;
            }

            return false;
          }) as any
        }
      })
    ]
  }
})