import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { Extension } from '@tiptap/core';

export const rewriteHighlightKey = new PluginKey('aiRewriteHighlight');

const createRewritePlugin = () =>
  new Plugin({
    key: rewriteHighlightKey,
    state: {
      init: () => DecorationSet.empty,
      apply(tr, old) {
        const newDeco = tr.getMeta(rewriteHighlightKey);
        return newDeco ? newDeco : old.map(tr.mapping, tr.doc);
      },
    },
    props: {
      decorations(state) {
        return this.getState(state);
      },
    },
  });

export const RewriteHighlightExtension = Extension.create({
  name: 'rewriteHighlight',
  addProseMirrorPlugins() {
    return [createRewritePlugin()];
  },
}); 