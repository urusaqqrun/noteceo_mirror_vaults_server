import { DarkEditorColors, LightEditorColors } from '../../../setting/ThemeProvider';

// 建立顏色轉換表
const createColorMappings = () => {
  const darkToLight = new Map();
  const lightToDark = new Map();

  for (let i = 0; i < DarkEditorColors.length; i++) {
    const darkColor = DarkEditorColors[i].color;
    const lightColor = LightEditorColors[i].color;

    // 轉換為小寫並作為鍵儲存
    const darkKey = darkColor.toLowerCase();
    const lightKey = lightColor.toLowerCase();

    darkToLight.set(darkKey, lightColor);
    lightToDark.set(lightKey, darkColor);
  }


  return { darkToLight, lightToDark };
};

const { darkToLight, lightToDark } = createColorMappings();

// 計算顏色的亮度 (0-1)
function calculateBrightness(color) {
  // 處理十六進制顏色
  if (color.startsWith('#')) {
    const hex = color.replace('#', '');
    let r, g, b;

    if (hex.length === 3) {
      // 簡寫格式 #RGB
      r = parseInt(hex[0] + hex[0], 16);
      g = parseInt(hex[1] + hex[1], 16);
      b = parseInt(hex[2] + hex[2], 16);
    } else {
      // 標準格式 #RRGGBB
      r = parseInt(hex.substr(0, 2), 16);
      g = parseInt(hex.substr(2, 2), 16);
      b = parseInt(hex.substr(4, 2), 16);
    }

    // 加權亮度計算 (人眼對綠色更敏感)
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  }

  // 處理 RGB 格式
  if (color.toLowerCase().startsWith('rgb(')) {
    const rgbMatch = color.match(/rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1], 10);
      const g = parseInt(rgbMatch[2], 10);
      const b = parseInt(rgbMatch[3], 10);

      // 加權亮度計算
      return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    }
  }

  // 默認亮度 (中等)
  return 0.5;
}

// 將 RGB 轉換為 HSL
function rgbToHsl(r, g, b) {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h, s, l = (max + min) / 2;

  if (max === min) {
    h = s = 0; // 灰階
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }

    h /= 6;
  }

  return [h, s, l];
}

// 將 HSL 轉換為 RGB
function hslToRgb(h, s, l) {
  let r, g, b;

  if (s === 0) {
    r = g = b = l; // 灰階
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;

    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }

  return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
}

// 只反轉亮度，保持色相和飽和度
function invertBrightness(color) {
  // 處理十六進制顏色
  if (color.startsWith('#')) {
    const hex = color.replace('#', '');
    let r, g, b;

    if (hex.length === 3) {
      // 簡寫格式 #RGB
      r = parseInt(hex[0] + hex[0], 16);
      g = parseInt(hex[1] + hex[1], 16);
      b = parseInt(hex[2] + hex[2], 16);
    } else {
      // 標準格式 #RRGGBB
      r = parseInt(hex.substr(0, 2), 16);
      g = parseInt(hex.substr(2, 2), 16);
      b = parseInt(hex.substr(4, 2), 16);
    }

    // 轉換為 HSL，反轉亮度，再轉回 RGB
    const [h, s, l] = rgbToHsl(r, g, b);
    const newL = 1 - l; // 反轉亮度
    const [newR, newG, newB] = hslToRgb(h, s, newL);

    // 轉回十六進制
    return `#${newR.toString(16).padStart(2, '0')}${newG.toString(16).padStart(2, '0')}${newB.toString(16).padStart(2, '0')}`;
  }

  // 處理 RGB 格式
  if (color.toLowerCase().startsWith('rgb(')) {
    const rgbMatch = color.match(/rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1], 10);
      const g = parseInt(rgbMatch[2], 10);
      const b = parseInt(rgbMatch[3], 10);

      // 轉換為 HSL，反轉亮度，再轉回 RGB
      const [h, s, l] = rgbToHsl(r, g, b);
      const newL = 1 - l; // 反轉亮度
      const [newR, newG, newB] = hslToRgb(h, s, newL);

      return `rgb(${newR}, ${newG}, ${newB})`;
    }
  }

  // 如果不是支援的格式，返回原始顏色
  return color;
}

// 處理顏色轉換的通用函數
function processColor(colorValue, isDarkMode) {
  let processedColor = colorValue;

  // 如果已經是CSS變數格式，不做處理
  if (colorValue.startsWith('var(--on)') || colorValue.startsWith('color-mix(in srgb, var(--on)')) {
    return { color: colorValue, changed: false };
  }

  // 檢查是否為 RGB 格式，轉換為十六進制
  if (colorValue.toLowerCase().startsWith('rgb(')) {
    const rgbMatch = colorValue.match(/rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1], 10).toString(16).padStart(2, '0');
      const g = parseInt(rgbMatch[2], 10).toString(16).padStart(2, '0');
      const b = parseInt(rgbMatch[3], 10).toString(16).padStart(2, '0');

      processedColor = `#${r}${g}${b}`;
    }
  }

  const lowerColorValue = processedColor.toLowerCase();

  // 根據當前主題進行轉換
  if (!isDarkMode && darkToLight.has(lowerColorValue)) {
    const newColor = darkToLight.get(lowerColorValue);
    return { color: newColor, changed: true };
  } else if (isDarkMode && lightToDark.has(lowerColorValue)) {
    const newColor = lightToDark.get(lowerColorValue);
    return { color: newColor, changed: true };
  } else if (lightToDark.has(lowerColorValue) || darkToLight.has(lowerColorValue)) {
    // 代表顏色已經被換了，不做任何動作
  } else {
    // 如果在色表中找不到對應，檢查亮度是否足夠

    // 計算亮度
    const brightness = calculateBrightness(processedColor);

    // 根據主題和亮度決定是否需要反轉
    let needsInversion = false;

    if (isDarkMode && brightness < 0.5) {
      // 深色主題下，亮度過低需要反轉
      needsInversion = true;
    } else if (!isDarkMode && brightness > 0.5) {
      // 淺色主題下，亮度過高需要反轉
      needsInversion = true;
    }

    // 如果需要反轉，處理顏色
    if (needsInversion) {
      const invertedColor = invertBrightness(processedColor);
      return { color: invertedColor, changed: true };
    }
  }

  // 沒有對應的轉換，保持原樣
  return { color: processedColor, changed: false };
}

// 轉換筆記內容中的顏色值
export const convertContentColors = (content, isDarkMode) => {
  if (!content) return content;


  let convertedContent = content;
  let colorReplacements = 0;

  // 打印現有的映射表

  // 1. 處理 color="..." 屬性
  convertedContent = convertedContent.replace(/color="([^"]+)"/gi, (match, colorValue) => {
    const { color: newColor, changed } = processColor(colorValue, isDarkMode);

    if (changed) {
      colorReplacements++;
      return `color="${newColor}"`;
    }

    return match;
  });

  // 忽略超連結內的顏色
  const isInLink = (match, content) => {
    // 檢查這個 style 是否在 <a> 標籤內
    const beforeMatch = content.substring(0, content.indexOf(match));
    const openTags = beforeMatch.match(/<a[^>]*>/g) || [];
    const closeTags = beforeMatch.match(/<\/a>/g) || [];
    return openTags.length > closeTags.length;
  };

  // 重新構建更準確的正則表達式，包含處理 CSS 變數格式
  const styleColorRegex = /style="([^"]*)color:\s*(#[0-9a-f]{3,6}|rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)|var\(--on\)|color-mix\(in srgb, var\(--on\)[^)]+\))([^"]*)"/gi;

  // 2. 處理 style="color: ..." 屬性
  convertedContent = convertedContent.replace(styleColorRegex, (match, before, colorValue, after) => {
    // 如果這個顏色在超連結內，就不處理
    if (isInLink(match, convertedContent)) {
      return match;
    }

    const { color: newColor, changed } = processColor(colorValue, isDarkMode);

    if (changed) {
      colorReplacements++;
      return `style="${before}color: ${newColor}${after}"`;
    }

    return match;
  });

  return convertedContent;
}; 