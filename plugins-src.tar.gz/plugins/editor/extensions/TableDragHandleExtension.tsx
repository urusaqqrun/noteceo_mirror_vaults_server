import React from 'react';
import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { renderToStaticMarkup } from 'react-dom/server';
import HorizontalHandleIcon from '../../../../assets/icon_sheet_drag_handle_horizontal.svg?react';
import VerticalHandleIcon from '../../../../assets/icon_sheet_drag_handle_vertical.svg?react';

// 獲取翻譯函數（在組件外部）
const getTranslation = () => {
  // 從 localStorage 獲取當前語言
  const currentLang = localStorage.getItem('i18nextLng') || 'zh-Hant';

  const translations = {
    'zh-Hant': { table: '表格' },
    'en': { table: 'Table' },
    'ja': { table: 'テーブル' }
  };

  return translations[currentLang] || translations['zh-Hant'];
};

// 表格拖曳擴展
export const TableDragHandleExtension = Extension.create({
  name: 'tableDragHandle',

  addOptions() {
    return {
      isReadOnlyMode: false, // 只讀模式
    };
  },

  addProseMirrorPlugins() {
    const editor = this.editor;
    const isReadOnlyMode = this.options.isReadOnlyMode; // 保存 options
    let dragSourceNode = null;
    let dragTargetPos = null;
    let dragPreview = null;
    let isDragging = false;
    let dropCursor = null;
    let lastMousePos = null;
    let isColumnDragStarted = false; // 防止欄拖曳重複開始
    let isRowDragStarted = false; // 防止列拖曳重複開始

    // 檢查表格是否有首列的函數
    const checkTableHasHeaderRow = (tableNode) => {
      if (!tableNode || tableNode.childCount === 0) return false;
      const firstRow = tableNode.child(0);
      for (let i = 0; i < firstRow.childCount; i++) {
        const cell = firstRow.child(i);
        if (cell.type.name !== 'tableHeader') {
          return false;
        }
      }
      return firstRow.childCount > 0;
    };

    // 檢查表格是否有首欄的函數
    const checkTableHasHeaderColumn = (tableNode) => {
      if (!tableNode || tableNode.childCount === 0) return false;
      for (let rowIdx = 0; rowIdx < tableNode.childCount; rowIdx++) {
        const row = tableNode.child(rowIdx);
        if (row.childCount === 0) return false;
        const firstCell = row.child(0);
        if (firstCell.type.name !== 'tableHeader') {
          return false;
        }
      }
      return true;
    };

    // 將首列轉換為普通列的函數
    const convertHeaderRowToNormal = (tableNode, schema) => {
      const newRows = [];
      for (let rowIdx = 0; rowIdx < tableNode.childCount; rowIdx++) {
        const row = tableNode.child(rowIdx);
        const newCells = [];

        for (let colIdx = 0; colIdx < row.childCount; colIdx++) {
          const cell = row.child(colIdx);
          if (rowIdx === 0 && cell.type.name === 'tableHeader') {
            // 將首列的標題儲存格轉換為普通儲存格
            const cellType = schema.nodes.tableCell;
            const newCell = cellType.create(cell.attrs, cell.content, cell.marks);
            newCells.push(newCell);
          } else {
            newCells.push(cell);
          }
        }

        const newRow = row.type.create(row.attrs, newCells);
        newRows.push(newRow);
      }

      return tableNode.type.create(tableNode.attrs, newRows);
    };

    // 將首欄轉換為普通欄的函數
    const convertHeaderColumnToNormal = (tableNode, schema) => {
      const newRows = [];
      for (let rowIdx = 0; rowIdx < tableNode.childCount; rowIdx++) {
        const row = tableNode.child(rowIdx);
        const newCells = [];

        for (let colIdx = 0; colIdx < row.childCount; colIdx++) {
          const cell = row.child(colIdx);
          if (colIdx === 0 && cell.type.name === 'tableHeader') {
            // 將首欄的標題儲存格轉換為普通儲存格
            const cellType = schema.nodes.tableCell;
            const newCell = cellType.create(cell.attrs, cell.content, cell.marks);
            newCells.push(newCell);
          } else {
            newCells.push(cell);
          }
        }

        const newRow = row.type.create(row.attrs, newCells);
        newRows.push(newRow);
      }

      return tableNode.type.create(tableNode.attrs, newRows);
    };
    // 發送表格拖曳手把點擊事件
    const showTableDragHandleMenu = (event, tablePos, tableElement) => {

      // 發送自定義事件給 NoteEditor
      const customEvent = new CustomEvent('table-drag-handle-clicked', {
        detail: {
          clientX: event.clientX,
          clientY: event.clientY,
          tablePos: tablePos,
          tableElement: tableElement // 傳遞表格 DOM 元素
        }
      });
      document.dispatchEvent(customEvent);
    };

    // 创建 dropcursor 元素
    const createDropCursor = () => {
      const cursor = document.createElement('div');
      cursor.className = 'editor-drop-cursor';
      cursor.style.position = 'absolute';
      cursor.style.height = '2px';
      cursor.style.backgroundColor = 'var(--primary)';
      cursor.style.pointerEvents = 'none';
      cursor.style.zIndex = String(1000);
      cursor.style.transition = 'transform 0.1s ease';
      return cursor;
    };

    // 更新 dropcursor 位置
    const updateDropCursor = (e) => {
      if (!dropCursor || !editor.view.dom) return;

      try {
        const editorRect = editor.view.dom.getBoundingClientRect();

        const pos = editor.view.posAtCoords({
          left: e.clientX,
          top: e.clientY
        });

        if (!pos) return;

        const resolvedPos = editor.state.doc.resolve(pos.pos);
        const nodeDOM = editor.view.nodeDOM(resolvedPos.before());
        if (!nodeDOM) return;

        const nodeRect = (nodeDOM as HTMLElement).getBoundingClientRect();
        const relativeToNode = e.clientY - nodeRect.top;
        const isTopHalf = relativeToNode < nodeRect.height / 2;

        // 设置 dropcursor 位置
        dropCursor.style.width = `${editorRect.width}px`;
        dropCursor.style.left = `${editorRect.left}px`;

        const targetPos = isTopHalf ? resolvedPos.before() : resolvedPos.after();

        if (isTopHalf) {
          dropCursor.style.top = `${nodeRect.top}px`;
        } else {
          dropCursor.style.top = `${nodeRect.bottom}px`;
        }

        dragTargetPos = targetPos;
      } catch (error) {
      }
    };

    const handleMouseMove = (e) => {
      if (!isDragging || !dragPreview) return;

      lastMousePos = { x: e.clientX, y: e.clientY };
      dragPreview.style.left = `${e.clientX + 10}px`;
      dragPreview.style.top = `${e.clientY + 10}px`;

      updateDropCursor(e);
    };

    const handleMouseUp = (e) => {
      if (!isDragging) return;

      isDragging = false;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);

      if (dragPreview) {
        dragPreview.remove();
        dragPreview = null;
      }

      if (dropCursor) {
        dropCursor.remove();
        dropCursor = null;
      }

      // 檢查滑鼠是否還在編輯器內部
      const editorElement = editor.view.dom;
      const editorRect = editorElement.getBoundingClientRect();
      const isMouseInEditor = lastMousePos &&
        lastMousePos.x >= editorRect.left &&
        lastMousePos.x <= editorRect.right &&
        lastMousePos.y >= editorRect.top &&
        lastMousePos.y <= editorRect.bottom;

      if (dragSourceNode && dragTargetPos !== null && isMouseInEditor) {
        // 记录当前滚动位置
        const editorView = editor.view;
        const scrollTop = editorView.dom.scrollTop;

        // 使用 command 方式处理表格拖拽
        this.editor.chain().command(({ tr, state, dispatch }) => {
          if (!dispatch) return false;

          const sourcePos = dragSourceNode.pos;
          const sourceNode = state.doc.nodeAt(sourcePos);

          if (!sourceNode || sourceNode.type.name !== 'table') {
            return false;
          }

          const sourceFrom = sourcePos;
          const sourceTo = sourcePos + sourceNode.nodeSize;
          const sourceSlice = state.doc.slice(sourceFrom, sourceTo);

          const adjustedTargetPos = dragTargetPos > dragSourceNode.pos
            ? dragTargetPos - sourceNode.nodeSize
            : dragTargetPos;

          try {
            tr.delete(dragSourceNode.pos, dragSourceNode.pos + sourceNode.nodeSize);
            tr.insert(adjustedTargetPos, sourceSlice.content);
            dispatch(tr);
            return true;
          } catch (error) {
            console.error('表格拖放操作失败:', error);
            return false;
          }
        }).run();

        // 恢复滚动位置
        requestAnimationFrame(() => {
          editorView.dom.scrollTop = scrollTop;
        });
      }

      editor.setEditable(true);
      dragSourceNode = null;
      dragTargetPos = null;

      const selectedNode = document.querySelector('.ProseMirror-selectednode');
      if (selectedNode) {
        selectedNode.classList.remove('ProseMirror-selectednode');
      }

      // 取消编辑器焦点
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
    };

    const createDragPreview = (node, handleIcon, pos, state) => {
      const preview = document.createElement('div');
      preview.className = 'dragging-preview';

      const iconContainer = document.createElement('div');
      iconContainer.className = 'drag-handle-icon';
      iconContainer.innerHTML = handleIcon;
      preview.appendChild(iconContainer);

      const contentDiv = document.createElement('div');
      contentDiv.className = 'preview-content';
      const t = getTranslation();
      contentDiv.textContent = t.table;

      preview.appendChild(contentDiv);
      document.body.appendChild(preview);

      return preview;
    };

    // 分析表格結構
    const analyzeTableStructure = (tableNode) => {
      const rows = tableNode.childCount;
      let cols = 0;
      if (rows > 0) {
        const firstRow = tableNode.firstChild;
        cols = firstRow.childCount;
      }
      return { rows, cols };
    };

    return [
      new Plugin({
        props: {
          decorations(state) {
            // 只讀模式下不顯示表格拖拽把手
            if (isReadOnlyMode) {
              return DecorationSet.empty;
            }

            const decorations = [];
            const doc = state.doc;

            doc.descendants((node, pos) => {
              if (node.type.name === 'table') {
                // 分析表格結構
                const tableInfo = analyzeTableStructure(node);

                // 添加列拖曳握把
                for (let rowIndex = 0; rowIndex < tableInfo.rows; rowIndex++) {
                  const rowDragHandle = Decoration.widget(
                    pos + 1,
                    () => {
                      const handle = document.createElement('div');
                      handle.className = 'table-row-drag-handle';
                      handle.style.cssText = `
                        position: absolute;
                        left: -12px;
                        top: ${rowIndex * 32 + 16}px;
                        width: 16px;
                        height: 16px;
                        opacity: 0;
                        cursor: grab;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        background: var(--surface);
                        border: 1px solid color-mix(in srgb, var(--on) 16%, transparent);
                        border-radius: 4px;
                        transition: opacity 0.2s ease;
                        z-index: 10;
                      `;
                      handle.innerHTML = renderToStaticMarkup(<VerticalHandleIcon width={16} height={16} />);

                      let clickTimeout = null;
                      let isDragStarted = false;

                      handle.addEventListener('mousedown', (e) => {

                        e.preventDefault();
                        e.stopPropagation();

                        isDragStarted = false;

                        // 設置延遲來區分點擊和拖曳
                        clickTimeout = setTimeout(() => {

                          // 如果 150ms 後還沒有移動，則開始拖曳
                          if (!isDragStarted) {
                            startRowDrag();
                          }
                        }, 150);

                        const handleMouseMoveStart = (moveEvent) => {
                          // 如果滑鼠移動超過 5px，取消點擊並開始拖曳
                          const distance = Math.sqrt(
                            Math.pow(moveEvent.clientX - e.clientX, 2) +
                            Math.pow(moveEvent.clientY - e.clientY, 2)
                          );

                          if (distance > 5) {

                            isDragStarted = true;
                            clearTimeout(clickTimeout);
                            document.removeEventListener('mousemove', handleMouseMoveStart);
                            document.removeEventListener('mouseup', handleMouseUpStart);

                            // 立即開始拖曳
                            startRowDrag();
                          }
                        };

                        const handleMouseUpStart = () => {

                          clearTimeout(clickTimeout);
                          document.removeEventListener('mousemove', handleMouseMoveStart);
                          document.removeEventListener('mouseup', handleMouseUpStart);

                          // 如果沒有開始拖曳，則是點擊事件
                          if (!isDragStarted) {

                            // 找到對應的表格元素
                            const wrapper = handle.closest('.tableWrapper');
                            const tableElement = wrapper?.querySelector('table');
                            showTableDragHandleMenu(e, `列-${rowIndex}`, tableElement);
                          }
                        };

                        const startRowDrag = () => {
                          // 防止重複執行
                          if (isRowDragStarted) {

                            return;
                          }
                          isRowDragStarted = true;

                          let isDraggingRow = false;
                          let dragStartY = e.clientY;
                          let originalRowIndex = rowIndex;
                          let currentTargetRowIndex = rowIndex;
                          let rowDragPreview = null;
                          let rowInsertIndicator = null;
                          let insertAfterRow = false; // 記錄是插入在行前還是行後
                          let isRowMoveExecuted = false; // 防止重複執行

                          const handleRowMouseMove = (moveEvent) => {
                            if (!isDraggingRow) {
                              const distance = Math.abs(moveEvent.clientY - dragStartY);
                              if (distance > 5) {
                                isDraggingRow = true;
                                handle.style.cursor = 'grabbing';

                                // 創建列的截圖預覽和插入示意線
                                const wrapperEl = handle.closest('.tableWrapper');
                                const tableEl = wrapperEl?.querySelector('table');

                                // 創建列插入示意線
                                if (wrapperEl && tableEl) {
                                  rowInsertIndicator = document.createElement('div');
                                  rowInsertIndicator.className = 'row-insert-indicator';
                                  // 獲取實際的 primary 顏色值
                                  const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim();

                                  // 先計算正確的初始位置
                                  const initialRow = tableEl.rows[originalRowIndex];
                                  let initialTop = '0px';
                                  let initialLeft = '0px';
                                  let initialWidth = '100px';

                                  if (initialRow) {
                                    const initialRowRect = initialRow.getBoundingClientRect();
                                    initialTop = `${initialRowRect.top - 2}px`;
                                    initialLeft = `${initialRowRect.left}px`;
                                    initialWidth = `${initialRowRect.width}px`;
                                  }

                                  rowInsertIndicator.style.cssText = `
                                  position: fixed;
                                  left: ${initialLeft};
                                  top: ${initialTop};
                                  width: ${initialWidth};
                                  height: 4px;
                                  background-color: ${primaryColor || '#BE82FF'};
                                  pointer-events: none;
                                  z-index: 9999;
                                  opacity: 1;
                                  transition: top 0.1s ease;
                                  border-radius: 2px;
                                  box-shadow: 0 2px 8px rgba(190, 130, 255, 0.3);
                                `;
                                  // 直接添加到 body
                                  document.body.appendChild(rowInsertIndicator);

                                }
                                const sourceRow = tableEl?.rows[originalRowIndex];
                                if (sourceRow) {
                                  rowDragPreview = document.createElement('div');
                                  rowDragPreview.className = 'table-row-drag-preview';
                                  rowDragPreview.style.cssText = `
                                  position: fixed;
                                  pointer-events: none;
                                  z-index: 9999;
                                  opacity: 0.6;
                                  box-shadow: 0 8px 24px rgba(0,0,0,0.3);
                                  border-radius: 4px;
                                  background: var(--surface);
                                  border: 2px solid var(--primary);
                                `;

                                  // 複製列的所有儲存格
                                  Array.from(sourceRow.cells).forEach(cell => {
                                    const cellClone = cell.cloneNode(true);

                                    const computedStyle = window.getComputedStyle(cell);
                                    const width = cell.offsetWidth;
                                    const height = cell.offsetHeight;

                                    (cellClone as HTMLElement).style.cssText = `
                                    display: inline-flex;
                                    align-items: center;
                                    justify-content: flex-start;
                                    width: ${width}px;
                                    height: ${height}px;
                                    min-width: ${width}px;
                                    min-height: ${height}px;
                                    box-sizing: ${computedStyle.boxSizing};
                                    padding: 12px;
                                    margin: 0;
                                    border: ${computedStyle.border};
                                    background: ${computedStyle.backgroundColor};
                                    color: ${computedStyle.color};
                                    font-family: ${computedStyle.fontFamily};
                                    font-size: ${computedStyle.fontSize};
                                    font-weight: ${computedStyle.fontWeight};
                                    line-height: ${computedStyle.lineHeight};
                                    text-align: left;
                                    vertical-align: middle;
                                  `;

                                    rowDragPreview.appendChild(cellClone);
                                  });

                                  document.body.appendChild(rowDragPreview);
                                }

                              }
                              return;
                            }

                            // 更新預覽位置
                            if (rowDragPreview) {
                              rowDragPreview.style.left = `${moveEvent.clientX + 10}px`;
                              rowDragPreview.style.top = `${moveEvent.clientY + 10}px`;
                            }

                            // 計算當前應該插入到哪一列
                            const wrapper = handle.closest('.tableWrapper');
                            if (!wrapper) return;
                            const table = wrapper.querySelector('table');
                            if (!table) return;

                            const rows = Array.from(table.rows);

                            // 找到滑鼠位置對應的列和插入位置
                            let tempTargetRowIndex = originalRowIndex;
                            let tempInsertAfterRow = false;
                            for (let i = 0; i < rows.length; i++) {
                              const rowRect = rows[i].getBoundingClientRect();
                              const rowCenter = rowRect.top + rowRect.height / 2;
                              if (moveEvent.clientY < rowCenter) {
                                tempTargetRowIndex = i;
                                tempInsertAfterRow = false; // 插入在這列之前
                                break;
                              }
                              tempTargetRowIndex = i;
                              tempInsertAfterRow = true; // 插入在這列之後
                            }

                            // 如果拖曳到最後一列之後，tempTargetRowIndex 應該是最後一列，tempInsertAfterRow = true
                            if (moveEvent.clientY > rows[rows.length - 1].getBoundingClientRect().bottom) {
                              tempTargetRowIndex = rows.length - 1;
                              tempInsertAfterRow = true;
                            }

                            // 修正條件判斷，確保示意線能正確顯示
                            const rowPositionChanged = tempTargetRowIndex !== currentTargetRowIndex;
                            const rowDirectionChanged = tempInsertAfterRow !== insertAfterRow;

                            // 檢查是否需要強制更新示意線（處理邊界情況）
                            const isAtBottomEdge = moveEvent.clientY > rows[rows.length - 1].getBoundingClientRect().bottom;
                            const shouldForceUpdateRow = isAtBottomEdge && tempTargetRowIndex === rows.length - 1 && tempInsertAfterRow;

                            if (rowPositionChanged || rowDirectionChanged || shouldForceUpdateRow) {
                              currentTargetRowIndex = tempTargetRowIndex;
                              insertAfterRow = tempInsertAfterRow;

                              // 更新列插入示意線位置 - 直接根據插入位置顯示
                              if (rowInsertIndicator && table) {
                                const targetRow = table.rows[currentTargetRowIndex];
                                if (targetRow) {
                                  const rowRect = targetRow.getBoundingClientRect();

                                  // 根據 insertAfterRow 決定示意線位置
                                  const indicatorTop = insertAfterRow ?
                                    rowRect.bottom - 2 : rowRect.top - 2;

                                  rowInsertIndicator.style.top = `${indicatorTop}px`;
                                  rowInsertIndicator.style.left = `${rowRect.left}px`;
                                  rowInsertIndicator.style.width = `${rowRect.width}px`;

                                }
                              }
                            }
                          };

                          const handleRowMouseUp = () => {

                            document.removeEventListener('mousemove', handleRowMouseMove);
                            document.removeEventListener('mouseup', handleRowMouseUp);
                            handle.style.cursor = 'grab';

                            // 重置列拖曳開始標記
                            isRowDragStarted = false;

                            if (rowDragPreview) {
                              rowDragPreview.remove();
                              rowDragPreview = null;
                            }

                            // 清理列插入示意線
                            if (rowInsertIndicator) {
                              rowInsertIndicator.remove();
                              rowInsertIndicator = null;
                            }

                            if (isDraggingRow && currentTargetRowIndex !== originalRowIndex && !isRowMoveExecuted) {

                              isRowMoveExecuted = true; // 標記為已執行

                              if (editor) {

                                const wrapper = handle.closest('.tableWrapper');
                                const table = wrapper?.querySelector('table');
                                if (table) {

                                  const sourceRow = table.rows[originalRowIndex];
                                  const sourceCell = sourceRow?.cells[0];
                                  if (sourceCell) {

                                    const sourceCellPos = editor.view.posAtDOM(sourceCell, 0);
                                    editor.chain().focus().setTextSelection(sourceCellPos).run();

                                    // 移動列到目標位置

                                    const commandResult = editor.chain().command(({ tr, state }) => {
                                      try {

                                        const { $from } = state.selection;
                                        let tablePos = null;
                                        let tableNode = null;

                                        for (let d = $from.depth; d > 0; d--) {
                                          const node = $from.node(d);
                                          if (node.type.name === 'table') {
                                            tablePos = $from.before(d);
                                            tableNode = node;
                                            break;
                                          }
                                        }

                                        if (!tableNode || tablePos === null) return false;

                                        // 1. 檢查是否有首行或首列
                                        const hasHeaderRow = checkTableHasHeaderRow(tableNode);
                                        const hasHeaderColumn = checkTableHasHeaderColumn(tableNode);

                                        const sourceRowNode = tableNode.child(originalRowIndex);

                                        // 計算實際的插入位置（考慮刪除源行的影響）
                                        let finalTargetIndex;
                                        if (insertAfterRow) {
                                          finalTargetIndex = currentTargetRowIndex + 1;
                                        } else {
                                          finalTargetIndex = currentTargetRowIndex;
                                        }

                                        // 如果目標位置在源行之後，需要調整（因為源行會被刪除）
                                        if (finalTargetIndex > originalRowIndex) {
                                          finalTargetIndex = finalTargetIndex - 1;
                                        }

                                        // 確保目標位置在有效範圍內
                                        finalTargetIndex = Math.max(0, Math.min(finalTargetIndex, tableNode.childCount - 1));

                                        // 2. 取消首行/首列狀態（如果需要）
                                        let needRestoreHeaderRow = false;
                                        let needRestoreHeaderColumn = false;

                                        // 如果移動涉及到 index 0，需要處理首列/首欄
                                        if (hasHeaderRow && (originalRowIndex === 0 || finalTargetIndex === 0)) {
                                          needRestoreHeaderRow = true;
                                          // 先取消首列狀態
                                          tableNode = convertHeaderRowToNormal(tableNode, state.schema);
                                        }
                                        if (hasHeaderColumn && (originalRowIndex === 0 || finalTargetIndex === 0)) {
                                          needRestoreHeaderColumn = true;
                                          // 先取消首欄狀態
                                          tableNode = convertHeaderColumnToNormal(tableNode, state.schema);
                                        }

                                        // 3. 執行移動操作：創建新的表格節點
                                        const newRows = [];

                                        // 重新獲取源列（可能已經被轉換過）
                                        const updatedSourceRowNode = tableNode.child(originalRowIndex);

                                        // 收集除了源列之外的所有列
                                        for (let i = 0; i < tableNode.childCount; i++) {
                                          if (i !== originalRowIndex) {
                                            newRows.push(tableNode.child(i));
                                          }
                                        }

                                        // 在正確位置插入源列
                                        newRows.splice(finalTargetIndex, 0, updatedSourceRowNode);

                                        // 4. 處理首列/首欄的恢復
                                        const processedRows = [];
                                        for (let rowIdx = 0; rowIdx < newRows.length; rowIdx++) {
                                          const row = newRows[rowIdx];
                                          const newCells = [];

                                          for (let colIdx = 0; colIdx < row.childCount; colIdx++) {
                                            const cell = row.child(colIdx);
                                            let newCellType = cell.type.name;

                                            // 恢復首列狀態
                                            if (needRestoreHeaderRow && rowIdx === 0) {
                                              newCellType = 'tableHeader';
                                            } else if (needRestoreHeaderRow && rowIdx !== 0 && cell.type.name === 'tableHeader' && !needRestoreHeaderColumn) {
                                              newCellType = 'tableCell';
                                            }

                                            // 恢復首欄狀態
                                            if (needRestoreHeaderColumn && colIdx === 0) {
                                              newCellType = 'tableHeader';
                                            } else if (needRestoreHeaderColumn && colIdx !== 0 && cell.type.name === 'tableHeader' && !needRestoreHeaderRow) {
                                              newCellType = 'tableCell';
                                            }

                                            const cellType = state.schema.nodes[newCellType];
                                            const newCell = cellType.create(cell.attrs, cell.content, cell.marks);
                                            newCells.push(newCell);
                                          }

                                          const newRow = row.type.create(row.attrs, newCells);
                                          processedRows.push(newRow);
                                        }

                                        // 創建新的表格節點
                                        const newTableNode = tableNode.type.create(
                                          tableNode.attrs,
                                          processedRows
                                        );

                                        // 替換整個表格
                                        tr.replaceWith(tablePos, tablePos + tableNode.nodeSize, newTableNode);

                                        return true;
                                      } catch (error) {
                                        console.error('列移動失敗:', error);
                                        return false;
                                      }
                                    });

                                  }
                                }
                              }
                            }
                          };

                          document.addEventListener('mousemove', handleRowMouseMove);
                          document.addEventListener('mouseup', handleRowMouseUp);
                        };

                        document.addEventListener('mousemove', handleMouseMoveStart);
                        document.addEventListener('mouseup', handleMouseUpStart);
                      });

                      // 精確定位
                      const positionRowHandle = () => {
                        const wrapper = handle.closest('.tableWrapper');
                        if (!wrapper) return;
                        const table = wrapper.querySelector('table');
                        if (!table) return;
                        const targetRow = table.rows[rowIndex];
                        if (!targetRow) return;

                        const wrapperRect = wrapper.getBoundingClientRect();
                        const rowRect = targetRow.getBoundingClientRect();
                        const computedScale = getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim();
                        const SCALE = parseFloat(computedScale) || 1;

                        const topPos = ((rowRect.top - wrapperRect.top) / SCALE) + (rowRect.height / (2 * SCALE)) - 8;
                        const leftFixed = -10 / SCALE;
                        if (rowRect.height === 0) {
                          requestAnimationFrame(positionRowHandle);
                          return;
                        }
                        handle.style.top = `${topPos}px`;
                        handle.style.left = `${leftFixed}px`;
                      };

                      requestAnimationFrame(positionRowHandle);
                      window.addEventListener('resize', positionRowHandle);

                      return handle;
                    },
                    {
                      key: `table-row-drag-${pos}-${rowIndex}`,
                      ignoreSelection: true,
                    }
                  );
                  decorations.push(rowDragHandle);
                }

                // 添加欄拖曳握把
                for (let colIndex = 0; colIndex < tableInfo.cols; colIndex++) {
                  const colDragHandle = Decoration.widget(
                    pos + 1,
                    () => {
                      const handle = document.createElement('div');
                      handle.className = 'table-col-drag-handle';
                      handle.style.cssText = `
                         position: absolute;
                         left: ${colIndex * 100 + 50}px;
                         top: -12px;
                         width: 16px;
                         height: 16px;
                         opacity: 0;
                         cursor: grab;
                         display: flex;
                         align-items: center;
                         justify-content: center;
                         background: var(--surface);
                         border: 1px solid color-mix(in srgb, var(--on) 16%, transparent);
                         border-radius: 4px;
                         transition: opacity 0.2s ease;
                         z-index: 10;
                       `;
                      handle.innerHTML = renderToStaticMarkup(<HorizontalHandleIcon width={16} height={16} />);

                      let clickTimeout = null;
                      let isDragStarted = false;

                      handle.addEventListener('mousedown', (e) => {

                        e.preventDefault();
                        e.stopPropagation();

                        isDragStarted = false;

                        // 設置延遲來區分點擊和拖曳
                        clickTimeout = setTimeout(() => {

                          // 如果 150ms 後還沒有移動，則開始拖曳
                          if (!isDragStarted) {
                            startColumnDrag();
                          }
                        }, 150);

                        const handleMouseMoveStart = (moveEvent) => {
                          // 如果滑鼠移動超過 5px，取消點擊並開始拖曳
                          const distance = Math.sqrt(
                            Math.pow(moveEvent.clientX - e.clientX, 2) +
                            Math.pow(moveEvent.clientY - e.clientY, 2)
                          );

                          if (distance > 5) {

                            isDragStarted = true;
                            clearTimeout(clickTimeout);
                            document.removeEventListener('mousemove', handleMouseMoveStart);
                            document.removeEventListener('mouseup', handleMouseUpStart);

                            // 立即開始拖曳
                            startColumnDrag();
                          }
                        };

                        const handleMouseUpStart = () => {

                          clearTimeout(clickTimeout);
                          document.removeEventListener('mousemove', handleMouseMoveStart);
                          document.removeEventListener('mouseup', handleMouseUpStart);

                          // 如果沒有開始拖曳，則是點擊事件
                          if (!isDragStarted) {

                            // 找到對應的表格元素
                            const wrapper = handle.closest('.tableWrapper');
                            const tableElement = wrapper?.querySelector('table');
                            showTableDragHandleMenu(e, `欄-${colIndex}`, tableElement);
                          }
                        };

                        const startColumnDrag = () => {
                          // 防止重複執行
                          if (isColumnDragStarted) {

                            return;
                          }
                          isColumnDragStarted = true;

                          let isDraggingCol = false;
                          let dragStartX = e.clientX;
                          let originalColIndex = colIndex;
                          let currentTargetColIndex = colIndex;
                          let colDragPreview = null;
                          let colInsertIndicator = null;
                          let insertAfterColumn = false; // 記錄是插入在列前還是列後
                          let isColMoveExecuted = false; // 防止重複執行

                          const handleColMouseMove = (moveEvent) => {
                            if (!isDraggingCol) {
                              const distance = Math.abs(moveEvent.clientX - dragStartX);
                              if (distance > 5) {
                                isDraggingCol = true;
                                handle.style.cursor = 'grabbing';

                                // 創建欄插入示意線
                                const wrapperEl = handle.closest('.tableWrapper');
                                const tableEl = wrapperEl?.querySelector('table');

                                if (wrapperEl && tableEl) {
                                  colInsertIndicator = document.createElement('div');
                                  colInsertIndicator.className = 'column-insert-indicator';

                                  // 獲取實際的 primary 顏色值
                                  const primaryColor = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim();

                                  // 先計算正確的初始位置
                                  const initialCell = tableEl.rows[0]?.cells[originalColIndex];
                                  let initialLeft = '0px';
                                  let initialTop = '0px';
                                  let initialHeight = '100px';

                                  if (initialCell && tableEl) {
                                    const initialCellRect = initialCell.getBoundingClientRect();
                                    const tableRect = tableEl.getBoundingClientRect();
                                    initialLeft = `${initialCellRect.left - 2}px`;
                                    initialTop = `${tableRect.top}px`;
                                    initialHeight = `${tableRect.height}px`;
                                  }

                                  colInsertIndicator.style.cssText = `
                                   position: fixed;
                                   left: ${initialLeft};
                                   top: ${initialTop};
                                   width: 4px;
                                   height: ${initialHeight};
                                   background-color: ${primaryColor || '#BE82FF'};
                                   pointer-events: none;
                                   z-index: 9999;
                                   opacity: 1;
                                   transition: left 0.1s ease;
                                   border-radius: 2px;
                                   box-shadow: 0 2px 8px rgba(190, 130, 255, 0.3);
                                 `;
                                  // 直接添加到 body
                                  document.body.appendChild(colInsertIndicator);

                                }

                                // 創建欄的截圖預覽
                                const wrapper = handle.closest('.tableWrapper');
                                const table = wrapper?.querySelector('table');
                                if (table) {
                                  colDragPreview = document.createElement('div');
                                  colDragPreview.className = 'table-col-drag-preview';
                                  colDragPreview.style.cssText = `
                                   position: fixed;
                                   pointer-events: none;
                                   z-index: 9999;
                                   opacity: 0.6;
                                   box-shadow: 0 8px 24px rgba(0,0,0,0.3);
                                   border-radius: 4px;
                                   background: var(--surface);
                                   border: 2px solid var(--primary);
                                   display: flex;
                                   flex-direction: column;
                                   gap: -1px;
                                 `;

                                  // 複製欄的所有儲存格
                                  Array.from(table.rows).forEach(row => {
                                    const cell = row.cells[originalColIndex];
                                    if (cell) {
                                      const cellClone = cell.cloneNode(true);

                                      const computedStyle = window.getComputedStyle(cell);
                                      const width = cell.offsetWidth;
                                      const height = cell.offsetHeight;

                                      (cellClone as HTMLElement).style.cssText = `
                                       display: flex;
                                       align-items: center;
                                       justify-content: flex-start;
                                       width: ${width}px;
                                       height: ${height}px;
                                       min-width: ${width}px;
                                       min-height: ${height}px;
                                       box-sizing: ${computedStyle.boxSizing};
                                       padding: 12px;
                                       margin: 0;
                                       border: ${computedStyle.border};
                                       background: ${computedStyle.backgroundColor};
                                       color: ${computedStyle.color};
                                       font-family: ${computedStyle.fontFamily};
                                       font-size: ${computedStyle.fontSize};
                                       font-weight: ${computedStyle.fontWeight};
                                       line-height: ${computedStyle.lineHeight};
                                       text-align: left;
                                       vertical-align: middle;
                                     `;

                                      colDragPreview.appendChild(cellClone);
                                    }
                                  });

                                  document.body.appendChild(colDragPreview);
                                }

                              }
                              return;
                            }

                            // 更新預覽位置
                            if (colDragPreview) {
                              colDragPreview.style.left = `${moveEvent.clientX + 10}px`;
                              colDragPreview.style.top = `${moveEvent.clientY + 10}px`;
                            }

                            // 找到滑鼠位置對應的列和插入位置
                            const wrapper = handle.closest('.tableWrapper');
                            if (!wrapper) return;
                            const table = wrapper.querySelector('table');
                            if (!table || !table.rows[0]) return;

                            const cells = Array.from(table.rows[0].cells);

                            // 找到滑鼠位置對應的欄和插入位置
                            let tempTargetColIndex = originalColIndex;
                            let tempInsertAfterColumn = false;
                            for (let i = 0; i < cells.length; i++) {
                              const cellRect = cells[i].getBoundingClientRect();
                              const cellCenter = cellRect.left + cellRect.width / 2;
                              if (moveEvent.clientX < cellCenter) {
                                tempTargetColIndex = i;
                                tempInsertAfterColumn = false; // 插入在這欄之前
                                break;
                              }
                              tempTargetColIndex = i;
                              tempInsertAfterColumn = true; // 插入在這欄之後
                            }

                            // 如果拖曳到最後一欄之後，tempTargetColIndex 應該是最後一欄，tempInsertAfterColumn = true
                            if (moveEvent.clientX > cells[cells.length - 1].getBoundingClientRect().right) {
                              tempTargetColIndex = cells.length - 1;
                              tempInsertAfterColumn = true;
                            }

                            // 修正條件判斷，確保示意線能正確顯示
                            const positionChanged = tempTargetColIndex !== currentTargetColIndex;
                            const directionChanged = tempInsertAfterColumn !== insertAfterColumn;

                            // 檢查是否需要強制更新示意線（處理邊界情況）
                            const isAtRightEdge = moveEvent.clientX > cells[cells.length - 1].getBoundingClientRect().right;
                            const shouldForceUpdate = isAtRightEdge && tempTargetColIndex === cells.length - 1 && tempInsertAfterColumn;

                            if (positionChanged || directionChanged || shouldForceUpdate) {
                              currentTargetColIndex = tempTargetColIndex;
                              insertAfterColumn = tempInsertAfterColumn;

                              // 更新欄插入示意線位置 - 直接根據插入位置顯示
                              if (colInsertIndicator && table) {
                                const targetCell = table.rows[0].cells[currentTargetColIndex];
                                if (targetCell) {
                                  const cellRect = targetCell.getBoundingClientRect();
                                  const tableRect = table.getBoundingClientRect();

                                  // 根據 insertAfterColumn 決定示意線位置
                                  const indicatorLeft = insertAfterColumn ?
                                    cellRect.right - 2 : cellRect.left - 2;

                                  colInsertIndicator.style.left = `${indicatorLeft}px`;
                                  colInsertIndicator.style.top = `${tableRect.top}px`;
                                  colInsertIndicator.style.height = `${tableRect.height}px`;

                                }
                              }
                            }
                          };

                          const handleColMouseUp = () => {

                            document.removeEventListener('mousemove', handleColMouseMove);
                            document.removeEventListener('mouseup', handleColMouseUp);
                            handle.style.cursor = 'grab';

                            // 重置欄拖曳開始標記
                            isColumnDragStarted = false;

                            if (colDragPreview) {
                              colDragPreview.remove();
                              colDragPreview = null;
                            }

                            // 清理欄插入示意線
                            if (colInsertIndicator) {
                              colInsertIndicator.remove();
                              colInsertIndicator = null;
                            }

                            if (isDraggingCol && currentTargetColIndex !== originalColIndex && !isColMoveExecuted) {

                              isColMoveExecuted = true; // 標記為已執行

                              if (editor) {

                                const wrapper = handle.closest('.tableWrapper');
                                const table = wrapper?.querySelector('table');
                                if (table && table.rows[0]) {

                                  const sourceCell = table.rows[0].cells[originalColIndex];
                                  if (sourceCell) {

                                    const sourceCellPos = editor.view.posAtDOM(sourceCell, 0);
                                    editor.chain().focus().setTextSelection(sourceCellPos).run();

                                    // 移動欄到目標位置

                                    const commandResult = editor.chain().command(({ tr, state }) => {
                                      try {

                                        const { $from } = state.selection;
                                        let tablePos = null;
                                        let tableNode = null;

                                        for (let d = $from.depth; d > 0; d--) {
                                          const node = $from.node(d);
                                          if (node.type.name === 'table') {
                                            tablePos = $from.before(d);
                                            tableNode = node;
                                            break;
                                          }
                                        }

                                        if (!tableNode || tablePos === null) return false;

                                        // 1. 檢查是否有首行或首列
                                        const hasHeaderRow = checkTableHasHeaderRow(tableNode);
                                        const hasHeaderColumn = checkTableHasHeaderColumn(tableNode);

                                        // 計算實際的插入位置
                                        let finalTargetIndex;
                                        if (insertAfterColumn) {
                                          finalTargetIndex = currentTargetColIndex + 1;
                                        } else {
                                          finalTargetIndex = currentTargetColIndex;
                                        }

                                        // 如果目標位置在源欄之後，需要調整（因為源欄會被刪除）
                                        if (finalTargetIndex > originalColIndex) {
                                          finalTargetIndex = finalTargetIndex - 1;
                                        }

                                        // 確保目標位置在有效範圍內
                                        const columnCount = tableNode.firstChild ? tableNode.firstChild.childCount : 0;
                                        finalTargetIndex = Math.max(0, Math.min(finalTargetIndex, columnCount - 1));

                                        // 2. 取消首列/首欄狀態（如果需要）
                                        let needRestoreHeaderRow = false;
                                        let needRestoreHeaderColumn = false;

                                        // 如果移動涉及到 index 0，需要處理首列/首欄
                                        if (hasHeaderRow && (originalColIndex === 0 || finalTargetIndex === 0)) {
                                          needRestoreHeaderRow = true;
                                          // 先取消首列狀態
                                          tableNode = convertHeaderRowToNormal(tableNode, state.schema);
                                        }
                                        if (hasHeaderColumn && (originalColIndex === 0 || finalTargetIndex === 0)) {
                                          needRestoreHeaderColumn = true;
                                          // 先取消首欄狀態
                                          tableNode = convertHeaderColumnToNormal(tableNode, state.schema);
                                        }

                                        // 3. 重建表格：對每一行重新排列欄（基於已取消首列/首欄狀態的表格）
                                        const newRows = [];

                                        for (let rowIndex = 0; rowIndex < tableNode.childCount; rowIndex++) {
                                          const rowNode = tableNode.child(rowIndex);
                                          const tempCells = [];

                                          // 收集除了源欄之外的所有欄
                                          for (let colIdx = 0; colIdx < rowNode.childCount; colIdx++) {
                                            if (colIdx !== originalColIndex) {
                                              tempCells.push(rowNode.child(colIdx));
                                            }
                                          }

                                          // 在正確位置插入源欄
                                          const sourceCell = rowNode.child(originalColIndex);
                                          tempCells.splice(finalTargetIndex, 0, sourceCell);

                                          // 4. 處理首列/首欄的恢復
                                          const processedCells = [];
                                          for (let colIdx = 0; colIdx < tempCells.length; colIdx++) {
                                            const cell = tempCells[colIdx];
                                            let newCellType = cell.type.name;

                                            // 恢復首列狀態
                                            if (needRestoreHeaderRow && rowIndex === 0) {
                                              newCellType = 'tableHeader';
                                            } else if (needRestoreHeaderRow && rowIndex !== 0 && cell.type.name === 'tableHeader' && !needRestoreHeaderColumn) {
                                              newCellType = 'tableCell';
                                            }

                                            // 恢復首欄狀態
                                            if (needRestoreHeaderColumn && colIdx === 0) {
                                              newCellType = 'tableHeader';
                                            } else if (needRestoreHeaderColumn && colIdx !== 0 && cell.type.name === 'tableHeader' && !needRestoreHeaderRow) {
                                              newCellType = 'tableCell';
                                            }

                                            const cellType = state.schema.nodes[newCellType];
                                            const newCell = cellType.create(cell.attrs, cell.content, cell.marks);
                                            processedCells.push(newCell);
                                          }

                                          // 創建新的行節點
                                          const newRowNode = rowNode.type.create(
                                            rowNode.attrs,
                                            processedCells
                                          );
                                          newRows.push(newRowNode);
                                        }

                                        // 創建新的表格節點
                                        const newTableNode = tableNode.type.create(
                                          tableNode.attrs,
                                          newRows
                                        );

                                        // 替換整個表格
                                        tr.replaceWith(tablePos, tablePos + tableNode.nodeSize, newTableNode);

                                        return true;
                                      } catch (error) {
                                        console.error('欄移動失敗:', error);
                                        return false;
                                      }
                                    });

                                  }
                                }
                              }
                            }
                          };

                          document.addEventListener('mousemove', handleColMouseMove);
                          document.addEventListener('mouseup', handleColMouseUp);
                        };

                        document.addEventListener('mousemove', handleMouseMoveStart);
                        document.addEventListener('mouseup', handleMouseUpStart);
                      });

                      // 精確定位
                      const positionColHandle = () => {
                        const wrapper = handle.closest('.tableWrapper');
                        if (!wrapper) return;
                        const table = wrapper.querySelector('table');
                        if (!table) return;
                        const targetCell = table.rows[0]?.cells[colIndex];
                        if (!targetCell) return;

                        const tableRect = table.getBoundingClientRect();
                        const cellRect = targetCell.getBoundingClientRect();
                        const computedScale2 = getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim();
                        const SCALE2 = parseFloat(computedScale2) || 1;
                        const leftPos = ((cellRect.left - tableRect.left) / SCALE2) + (cellRect.width / (2 * SCALE2)) - 8;
                        const topFixed = -10 / SCALE2;
                        if (cellRect.width === 0) {
                          requestAnimationFrame(positionColHandle);
                          return;
                        }
                        handle.style.left = `${leftPos}px`;
                        handle.style.top = `${topFixed}px`;
                      };

                      requestAnimationFrame(positionColHandle);
                      window.addEventListener('resize', positionColHandle);

                      return handle;
                    },
                    {
                      key: `table-col-drag-${pos}-${colIndex}`,
                      ignoreSelection: true,
                    }
                  );
                  decorations.push(colDragHandle);
                }

                // 添加表格 hover 事件監聽器
                const tableHoverHandler = Decoration.widget(
                  pos + 1,
                  () => {
                    const hoverDetector = document.createElement('div');
                    hoverDetector.className = 'table-hover-detector';
                    hoverDetector.style.cssText = `
                       position: absolute;
                       top: 0;
                       left: 0;
                       right: 0;
                       bottom: 0;
                       pointer-events: none;
                       z-index: 1;
                     `;

                    // 改用選區更新事件來控制握把顯示
                    if (editor && !(editor.view as any).__tableHandleRegistered) {
                      editor.on('selectionUpdate', ({ editor }) => {
                        const { $anchor } = editor.state.selection;
                        const view = editor.view;
                        const domInfo = view.domAtPos($anchor.pos);
                        let domCell = domInfo.node as HTMLElement;
                        if (domCell.nodeType !== 1) domCell = domCell.parentElement!;
                        const cellEl = (domCell as HTMLElement).closest('td,th') as HTMLElement | null;
                        if (!cellEl) {
                          document.querySelectorAll('.table-row-drag-handle, .table-col-drag-handle').forEach(h => (h as HTMLElement).style.opacity = '0');
                          return;
                        }
                        const rowEl = cellEl.parentElement as HTMLElement;
                        const tableEl = rowEl.closest('table') as HTMLTableElement;
                        const rowIndex = Array.from(tableEl.rows).indexOf(rowEl as HTMLTableRowElement);
                        const colIndex = (cellEl as HTMLTableCellElement).cellIndex;

                        // 先隱藏所有表格的握把
                        const allRowHandles = document.querySelectorAll('.table-row-drag-handle');
                        const allColHandles = document.querySelectorAll('.table-col-drag-handle');
                        allRowHandles.forEach(h => ((h as HTMLElement).style.opacity = '0'));
                        allColHandles.forEach(h => ((h as HTMLElement).style.opacity = '0'));

                        // 找到當前表格對應的 tableWrapper
                        const tableWrapper = tableEl.closest('.tableWrapper');
                        if (!tableWrapper) return;

                        // 只操作這個 tableWrapper 內的握把
                        const currentTableRowHandles = tableWrapper.querySelectorAll('.table-row-drag-handle');
                        const currentTableColHandles = tableWrapper.querySelectorAll('.table-col-drag-handle');

                        if (rowIndex >= 0 && rowIndex < currentTableRowHandles.length) {
                          (currentTableRowHandles[rowIndex] as HTMLElement).style.opacity = '1';
                        }
                        if (colIndex >= 0 && colIndex < currentTableColHandles.length) {
                          (currentTableColHandles[colIndex] as HTMLElement).style.opacity = '1';
                        }
                      });
                      (editor.view as any).__tableHandleRegistered = true;
                    }

                    return hoverDetector;
                  },
                  {
                    key: `table-hover-${pos}`,
                    ignoreSelection: true,
                  }
                );
                decorations.push(tableHoverHandler);

                // 添加新增列按鈕
                const addColumnButton = Decoration.widget(
                  pos + 1,
                  () => {
                    const button = document.createElement('div');
                    button.className = 'table-add-column-button';
                    button.innerHTML = `
                       <svg width="16" height="16" viewBox="0 0 16 16">
                         <path d="M8 0a1 1 0 0 1 1 1v6h6a1 1 0 1 1 0 2H9v6a1 1 0 1 1-2 0V9H1a1 1 0 1 1 0-2h6V1a1 1 0 0 1 1-1z" fill="currentColor"/>
                       </svg>
                     `;

                    const container = document.createElement('div');
                    container.className = 'table-add-column-container';
                    container.appendChild(button);

                    button.addEventListener('click', (e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (editor) {
                        const tableNode = editor.state.doc.nodeAt(pos);
                        if (tableNode && tableNode.type.name === 'table') {
                          const tableEndPos = pos + tableNode.nodeSize;

                          for (let searchPos = tableEndPos - 1; searchPos > pos; searchPos--) {
                            try {
                              const $searchPos = editor.state.doc.resolve(searchPos);
                              for (let depth = $searchPos.depth; depth > 0; depth--) {
                                const node = $searchPos.node(depth);
                                if (node.type.name === 'tableCell' || node.type.name === 'tableHeader') {
                                  editor.chain()
                                    .focus()
                                    .setTextSelection(searchPos)
                                    .addColumnAfter()
                                    .run();
                                  return;
                                }
                              }
                            } catch (e) {
                              continue;
                            }
                          }
                        }
                      }
                    });

                    return container;
                  },
                  {
                    key: `table-add-column-${pos}`,
                    ignoreSelection: true,
                  }
                );

                // 添加新增行按鈕
                const addRowButton = Decoration.widget(
                  pos + 1,
                  () => {
                    const button = document.createElement('div');
                    button.className = 'table-add-row-button';
                    button.innerHTML = `
                       <svg width="16" height="16" viewBox="0 0 16 16">
                         <path d="M8 0a1 1 0 0 1 1 1v6h6a1 1 0 1 1 0 2H9v6a1 1 0 1 1-2 0V9H1a1 1 0 1 1 0-2h6V1a1 1 0 0 1 1-1z" fill="currentColor"/>
                       </svg>
                     `;

                    const container = document.createElement('div');
                    container.className = 'table-add-row-container';
                    container.appendChild(button);

                    button.addEventListener('click', (e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      if (editor) {
                        const tableNode = editor.state.doc.nodeAt(pos);
                        if (tableNode && tableNode.type.name === 'table') {
                          const tableEndPos = pos + tableNode.nodeSize;

                          for (let searchPos = tableEndPos - 1; searchPos > pos; searchPos--) {
                            try {
                              const $searchPos = editor.state.doc.resolve(searchPos);
                              for (let depth = $searchPos.depth; depth > 0; depth--) {
                                const node = $searchPos.node(depth);
                                if (node.type.name === 'tableCell' || node.type.name === 'tableHeader') {
                                  editor.chain()
                                    .focus()
                                    .setTextSelection(searchPos)
                                    .addRowAfter()
                                    .run();
                                  return;
                                }
                              }
                            } catch (e) {
                              continue;
                            }
                          }
                        }
                      }
                    });

                    return container;
                  },
                  {
                    key: `table-add-row-${pos}`,
                    ignoreSelection: true,
                  }
                );

                decorations.push(addColumnButton);
                decorations.push(addRowButton);
              }
            });

            return DecorationSet.create(doc, decorations);
          },
        },
        view: () => ({
          update: () => {
            // 視圖更新時的處理
          },
          destroy: () => {
            // 清理
            if (dropCursor) dropCursor.remove();
            if (dragPreview) dragPreview.remove();
          }
        })
      })
    ];
  }
}); 