import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';

// 產生卡片 DOM
const createCardDom = (meta) => {
  const container = document.createElement('div');
  container.className = 'web-preview-card';
  container.setAttribute('data-url', meta.originUrl);

  const left = document.createElement('div');
  left.className = 'web-preview-left';
  const titleDiv = document.createElement('div');
  titleDiv.className = 'web-preview-title';
  titleDiv.textContent = meta.title ? meta.title : '無標題';
  const bodyDiv = document.createElement('div');
  bodyDiv.className = 'web-preview-body';
  const bodySnippet = meta.content ? meta.content.replace(/\s+/g, ' ').slice(0, 160) : '';
  bodyDiv.textContent = bodySnippet || '無內文';
  left.appendChild(titleDiv);
  left.appendChild(bodyDiv);
  container.appendChild(left);

  if (meta.imageUrl) {
    const right = document.createElement('div');
    right.className = 'web-preview-right';
    const img = document.createElement('img');
    img.className = 'web-preview-img';
    img.src = meta.imageUrl;
    right.appendChild(img);
    container.appendChild(right);
  }

  container.addEventListener('click', (e) => {
    e.preventDefault();
    if (meta.originUrl.startsWith('http')) {
      window.electronAPI.openExternalLink(meta.originUrl);
    }
  });

  return container;
};

const WebPreviewDecoration = Extension.create({
  name: 'webPreviewDecoration',

  addOptions() {
    return {
      // 必須傳入函數，回傳 websiteLinks 陣列
      getWebsiteLinks: () => [],
    };
  },

  addProseMirrorPlugins() {
    const key = new PluginKey('webPreviewDecoration');

    return [
      new Plugin({
        key,
        state: {
          init: () => DecorationSet.empty,
          apply: (tr, oldState) => {
            // 每次 transaction 都重新計算所有 decorations
            const decos = [];
            const links = this.options.getWebsiteLinks() || [];
            const linkMap = new Map();

            // 為每個連結建立編碼和解碼兩個版本的 key
            links.forEach(link => {
              const encodedUrl = link.originUrl;
              const decodedUrl = encodedUrl.replace(/&amp;/g, '&');
              linkMap.set(encodedUrl, link);
              linkMap.set(decodedUrl, link);
            });

            tr.doc.descendants((node, pos) => {
              if (!node.isText) return true;
              const mark = node.marks.find(m => m.type.name === 'link');
              if (mark) {
                const href = mark.attrs.href;

                // 直接從 linkMap 獲取，因為已經包含編碼和解碼兩個版本
                const meta = linkMap.get(href);

                if (meta) {
                  // 檢查是否為純文字連結（連結文字與URL相同）
                  const linkText = node.text;
                  const isPlainTextLink = linkText === href || linkText === href.replace(/^https?:\/\//, '') ||
                    linkText === href.replace(/&amp;/g, '&') || linkText === href.replace(/&amp;/g, '&').replace(/^https?:\/\//, '');

                  // 只有純文字連結才顯示預覽
                  if (isPlainTextLink) {
                    // 只要有 title 或 imageUrl 就產生卡片
                    if (meta && (meta.title || meta.imageUrl)) {
                      const widget = Decoration.widget(pos + node.nodeSize, () => createCardDom(meta), { side: 1 });
                      decos.push(widget);
                    }
                  }
                }
              }
              return true;
            });

            // 強制返回新的 DecorationSet，即使內容相同
            return DecorationSet.create(tr.doc, decos);
          }
        },
        props: {
          decorations(state) {
            return this.getState(state);
          },
        },
      }),
    ];
  },
});

export default WebPreviewDecoration; 