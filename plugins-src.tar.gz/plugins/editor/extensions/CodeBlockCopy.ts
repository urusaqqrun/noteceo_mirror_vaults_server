import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';

export const CodeBlockCopy = Extension.create({
  name: 'codeBlockCopy',

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('code-block-copy'),
        props: {
          decorations: (state) => {
            const decorations = [];
            const doc = state.doc;

            doc.descendants((node, pos) => {
              if (node.type.name === 'codeBlock') {
                // 創建複製按鈕
                const copyButton = document.createElement('button');
                copyButton.className = 'code-block-copy-button';
                copyButton.innerHTML = `
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                `;

                // 添加點擊事件
                copyButton.addEventListener('click', (e) => {
                  e.preventDefault();
                  e.stopPropagation();

                  // 獲取程式碼內容，確保保留換行符
                  let code = '';
                  node.content.forEach((child) => {
                    if (child.isText) {
                      code += child.text;
                    } else if (child.type.name === 'hardBreak') {
                      code += '\n';
                    }
                  });

                  // 如果沒有內容，使用 textContent 作為後備
                  if (!code) {
                    code = node.textContent;
                  }

                  // 複製到剪貼板
                  window.electronClipboard.writeText(code).then(() => {
                    // 設置 editor 的 storage
                    const editor = this.editor;
                    if (editor && (editor.storage as any).markdownClipboard) {
                      (editor.storage as any).markdownClipboard.copiedCode = code;
                    }

                    // 顯示複製成功的視覺反饋
                    copyButton.classList.add('copied');
                    copyButton.innerHTML = `
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    `;

                    // 2秒後恢復原始狀態
                    setTimeout(() => {
                      copyButton.classList.remove('copied');
                      copyButton.innerHTML = `
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                        </svg>
                      `;
                    }, 2000);
                  });
                });

                // 創建裝飾器
                const decoration = Decoration.widget(pos + 1, copyButton, {
                  side: 1,
                  key: `code-block-copy-${pos}`,
                });



                decorations.push(decoration);
              }
            });

            return DecorationSet.create(doc, decorations);
          },
        },
      }),
    ];
  },
}); 