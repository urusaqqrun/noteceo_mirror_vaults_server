
import { Extension } from '@tiptap/core';
import { useFloatingToolbarStore } from '../editorStore';
import { handleListBackspace } from './ListUtils';

export const CustomKeyboardShortcuts = Extension.create({
  addOptions() {
    return {
      setShowUrlDialog: () => { },
      setCurrentUrl: () => { },
      setShowSearchDialog: () => { },
      historyManager: null, // 接收 historyManager 實例
    }
  },

  addKeyboardShortcuts() {
    const historyManager = this.options.historyManager;
    return {
      // Undo/Redo 快捷鍵
      'Mod-z': () => {
        if (historyManager) {
          historyManager.undo()
        }
        return true
      },
      'Shift-Mod-z': () => {
        if (historyManager) {
          historyManager.redo()
        }
        return true
      },
      'Mod-y': () => {
        if (historyManager) {
          historyManager.redo()
        }
        return true
      },

      // 保留其他快捷鍵
      'Mod-b': ({ editor }) => editor.chain().focus().toggleBold().run(),
      'Mod-i': ({ editor }) => editor.chain().focus().toggleItalic().run(),
      'Mod-u': ({ editor }) => editor.chain().focus().toggleUnderline().run(),
      'Mod-s': ({ editor }) => editor.chain().focus().toggleStrike().run(),
      'Mod-h': ({ editor }) => editor.chain().focus().toggleHighlight().run(),
      // 程式碼區塊 - 跨平台相容 (Mac: ⌘+Ctrl+C, Windows: Ctrl+Alt+C)
      ...(window?.electron?.platform === 'win32'
        ? { 'Ctrl-Alt-c': ({ editor }) => editor.chain().focus().toggleCodeBlock().run() }
        : { 'Mod-Ctrl-c': ({ editor }) => editor.chain().focus().toggleCodeBlock().run() }
      ),
      'Mod-l': ({ editor }) => {
        // 獲取當前選中文本的鏈接屬性
        const linkMark = editor.getAttributes('link');
        // 透過全局 store 控制 URL 對話框
        const { setShowUrlDialog, setCurrentUrl } = useFloatingToolbarStore.getState();
        setShowUrlDialog(true);
        // 如果已經有鏈接，傳遞現有的 URL
        if (linkMark.href) {
          setCurrentUrl(linkMark.href);
        }
        return true;
      },

      // 列表快捷鍵 - _handleListChange
      'Mod-4': ({ editor }) => {
        // 如果已經綁定了函數，則使用它
        if ((editor as any)._handleListChange) {
          (editor as any)._handleListChange('bulletList');
          return true;
        } else {
          console.error("editor._handleListChange is not exist");
        }
      },
      'Mod-5': ({ editor }) => {
        if ((editor as any)._handleListChange) {
          (editor as any)._handleListChange('orderedList');
          return true;
        } else {
          console.error("editor._handleListChange is not exist");
        }

      },
      'Mod-6': ({ editor }) => {
        if ((editor as any)._handleListChange) {
          (editor as any)._handleListChange('taskList');
          return true;
        } else {
          console.error("editor._handleListChange is not exist");
        }
      },

      // 標題快捷鍵
      'Mod-1': ({ editor }) => editor.chain().focus().toggleHeading({ level: 1 }).run(),
      'Mod-2': ({ editor }) => editor.chain().focus().toggleHeading({ level: 2 }).run(),
      'Mod-3': ({ editor }) => editor.chain().focus().toggleHeading({ level: 3 }).run(),

      // 其他常用快捷鍵
      'Mod-[': ({ editor }) => (editor.chain().focus() as any).outdent().run(),
      'Mod-]': ({ editor }) => (editor.chain().focus() as any).indent().run(),

      // 表格快捷鍵
      'Mod-Shift-t': ({ editor }) => {
        // 先插入表格
        editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();

        // 獲取當前表格的位置
        const { $from } = editor.state.selection;
        let depth = $from.depth;
        let tableWrapperPos = -1;

        // 向上尋找 tableWrapper 節點
        while (depth > 0) {
          const node = $from.node(depth);
          if (node.type.name === 'table') {
            tableWrapperPos = $from.before(depth);
            break;
          }
          depth--;
        }

        if (tableWrapperPos >= 0) {
          const table = editor.state.doc.nodeAt(tableWrapperPos);
          if (table) {
            const tableEndPos = tableWrapperPos + table.nodeSize;

            // 檢查表格後面是否還有內容
            const $afterTable = editor.state.doc.resolve(tableEndPos);
            const hasContentAfter = $afterTable.nodeAfter;

            // 只有在後面沒有內容時才添加空行
            if (!hasContentAfter) {
              editor.commands.insertContentAt(tableEndPos, { type: 'paragraph' });
            }
          }
        }
        return true;
      },

      // 選擇快捷鍵
      'Mod-a': ({ editor }) => {
        editor.commands.selectAll();
        return true;
      },

      // Enter 鍵處理 - 先檢查 URL 轉換，再創建新行
      'Enter': ({ editor }) => {
        const enterStartTime = performance.now();

        // 檢查是否在 codeBlock 內，如果是則手動插入換行
        const isInCodeBlock = editor.isActive('codeBlock');
        if (isInCodeBlock) {
          // 在 codeBlock 內手動插入換行字符

          editor.commands.insertContent('\n');
          return true;
        }

        // 先檢查是否需要轉換 URL
        const { $from } = editor.state.selection;
        const start = $from.start();
        const end = $from.end();
        const paragraphText = editor.state.doc.textBetween(start, end);

        // 檢查是否有 URL 需要轉換
        const urlRegex = /(?<![(\[])https?:\/\/[^\s\[\]()]+$/;
        const match = paragraphText.match(urlRegex);

        if (match) {
          const url = match[0];
          const urlStartPos = $from.pos - match[0].length;

          // 設置 URL 為超連結
          editor.chain()
            .focus()
            .setTextSelection({ from: urlStartPos, to: $from.pos })
            .setLink({ href: url })
            .setTextSelection($from.pos)  // 還原游標位置到原來的位置
            .run();
        }

        // 滾動邏輯已統一到 scrollToSelection，這裡不再處理
        // 返回 false 讓默認的 Enter 處理邏輯執行（創建新行）
        const enterEndTime = performance.now();
        return false;
      },

      'Backspace': ({ editor }) => {
        // 使用統一的列表 backspace 處理函數
        return handleListBackspace(editor);
      },
    }
  }
});
