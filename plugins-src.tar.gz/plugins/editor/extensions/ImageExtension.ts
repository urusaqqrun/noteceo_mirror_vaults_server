import { Image } from '@tiptap/extension-image';
import { useMaterialModeStore } from '../editorStore';
import OCR_ICON_SVG from '../../../../assets/icon_scan_text_24.svg?raw';

// 簡易版可調整大小的 Image 擴展（四角等比例縮放）
export const ImageExtension = Image.extend({
  // 保持名稱為 image，確保與既有 schema.nodes.image 相容
  name: 'image',

  addOptions() {
    return {
      inline: true,
      allowBase64: true,
      HTMLAttributes: {
        class: 'editor-image',
      },
      selectionClass: 'ProseMirror-selectednode',
      isReadOnlyMode: false,
      resize: false,
    }
  },

  addAttributes() {
    return {
      ...this.parent?.(),
      width: {
        default: null, // 不設定預設值，讓它根據原圖尺寸計算
        // 解析 HTML 時將寬度限制在 0~100 之間，避免出現如 800% 的異常值
        parseHTML: element => {
          const w = element.getAttribute('width');
          if (!w) return null;

          // 若帶有 % 表示本來就是百分比，直接夾在 2~100 之間
          if (w.includes('%')) {
            const value = parseInt(w, 10);
            if (Number.isNaN(value)) return null;
            return Math.min(Math.max(value, 1), 100);
          }

          // 否則視為像素，等真正載入後再用解析度換算，這裡先不設定
          return null;
        },
        // 渲染時同樣保險，再次限制寬度最高 100%
        renderHTML: attrs => {
          if (!attrs.width) return {};
          const width = Math.min(Math.max(attrs.width, 0), 100);
          return { width: `${width}%` };
        },
      },
    };
  },

  addNodeView() {
    return ({ node, getPos, editor, HTMLAttributes }) => {
      const outer = document.createElement('span');
      outer.className = 'note-editor-image-wrapper';
      outer.style.display = 'block';  // 改為 block，避免 inline-block 的居中問題
      outer.style.position = 'relative';
      outer.style.textAlign = 'left'; // 確保圖片靠左對齊

      // 給予合理的初始寬度，避免載入時閃爍
      // 如果已有設定的寬度就使用，否則先給予預設值
      let initialWidth = 75; // 預設寬度
      if (node.attrs.width && node.attrs.width >= 2 && node.attrs.width <= 100) {
        initialWidth = node.attrs.width;
      }
      outer.style.width = `${initialWidth}%`;

      const img = document.createElement('img');
      Object.entries(HTMLAttributes).forEach(([key, val]) => {
        if (val != null && key !== 'width') img.setAttribute(key, val);
      });
      // 應用選項中的 class
      if (this.options.HTMLAttributes.class) {
        img.classList.add(this.options.HTMLAttributes.class);
      }
      img.style.width = '100%';
      img.style.height = 'auto';
      img.style.display = 'block';  // 確保圖片為block元素
      img.style.marginLeft = '0';   // 確保沒有左邊距
      img.style.marginRight = 'auto'; // 右邊距自動，讓圖片靠左

      // 讓圖片可拖曳
      img.draggable = true;
      img.addEventListener('dragstart', (e) => {
        const imageSrc = img.getAttribute('src');
        if (imageSrc) {
          // 將圖片 URL 保存到全局變數
          window.__draggingImageUrl = imageSrc;

          e.dataTransfer.effectAllowed = 'copy';

          // 觸發顯示 AICommander 的拖曳遮罩
          const event = new CustomEvent('showImageDrag', {
            detail: { isImage: true }
          });
          document.dispatchEvent(event);
        }
      });

      img.addEventListener('dragend', (e) => {
        // 觸發隱藏 AICommander 的拖曳遮罩
        const event = new CustomEvent('clearImageDrag');
        document.dispatchEvent(event);

        // 清除全局變數（延遲清除以確保 drop 事件能讀取）
        setTimeout(() => {
          window.__draggingImageUrl = null;
        }, 100);
      });

      // 檢查 editor view 是否可用（tiptap 的 Proxy 會在 view 不可用時拋出錯誤）
      const isEditorViewAvailable = () => {
        try {
          return !editor.isDestroyed && editor.view && editor.view.dom;
        } catch {
          return false;
        }
      };

      // 限制圖片最大高度為 editor-body 的 80%
      const setMaxHeight = () => {
        // 確保 editor view 已經掛載
        if (!isEditorViewAvailable()) return;

        const editorBodyElement = editor.view.dom.closest('.note-editor')?.querySelector('.editor-body');
        if (editorBodyElement) {
          const editorBodyHeight = editorBodyElement.clientHeight;
          const maxHeight = editorBodyHeight * 0.8;
          img.style.maxHeight = `${maxHeight}px`;
        }
      };

      // 監聯視窗大小變化，重新計算最大高度
      const resizeObserver = new ResizeObserver(() => {
        setMaxHeight();
      });

      // 延遲初始化，確保 editor view 已經掛載
      let editorBodyElement = null;
      let retryCount = 0;
      const MAX_RETRY = 100; // 最多重試 100 次（約 1.6 秒）
      const initResizeObserver = () => {
        // 如果 editor 已被銷毀，停止重試
        if (editor.isDestroyed) return;

        if (!isEditorViewAvailable()) {
          // 如果 view 還沒準備好，延遲重試（有次數限制）
          retryCount++;
          if (retryCount < MAX_RETRY) {
            requestAnimationFrame(initResizeObserver);
          }
          return;
        }

        // 初始設定最大高度
        setMaxHeight();

        // 觀察 editor-body 的大小變化
        editorBodyElement = editor.view.dom.closest('.note-editor')?.querySelector('.editor-body');
        if (editorBodyElement) {
          resizeObserver.observe(editorBodyElement);
        }
      };

      // 使用 requestAnimationFrame 延遲初始化
      requestAnimationFrame(initResizeObserver);

      outer.appendChild(img);

      // 創建 OCR 文字圖標按鈕
      const ocrButton = document.createElement('button');
      ocrButton.className = 'note-editor-ocr-button';
      ocrButton.innerHTML = OCR_ICON_SVG;
      ocrButton.title = '查看圖片辨識文字';
      ocrButton.style.display = 'none'; // 預設隱藏

      // 點擊 OCR 按鈕時開啟圖片文字模式
      ocrButton.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        const imageSrc = img.getAttribute('src');
        const currentState = useMaterialModeStore.getState();
        currentState.setisImageTextMode(true);
        currentState.setSelectedImageSrc(imageSrc);

        // 防止移動端跳出鍵盤，blur 掉按鈕的 focus
        ocrButton.blur();
        // 確保不會 focus 到其他元素
        (document.activeElement as HTMLElement)?.blur();
      });

      outer.appendChild(ocrButton);

      // 監聽 imageTextMap 變化，更新 OCR 按鈕顯示狀態
      const updateOcrButtonVisibility = () => {
        const imageSrc = img.getAttribute('src');
        const { imageTextMap } = useMaterialModeStore.getState();
        const hasOcrText = imageTextMap[imageSrc] && imageTextMap[imageSrc].trim() !== '';
        ocrButton.style.display = hasOcrText ? 'flex' : 'none';
      };

      // 初始檢查
      updateOcrButtonVisibility();

      // 訂閱 store 變化
      const unsubscribe = useMaterialModeStore.subscribe((state, prevState) => {
        if (state.imageTextMap !== prevState.imageTextMap) {
          updateOcrButtonVisibility();
        }
      });

      // 圖片選擇邏輯現在由全局的 onSelectionUpdate 處理

      // 當圖片載入完成後，根據原圖尺寸計算合適的寬度比例
      img.addEventListener('load', () => {
        if (editor.isDestroyed) return;

        // 以整個 NoteEditor(.note-editor) 寬度作為計算基準
        const editorElement = editor.view.dom.closest('.note-editor');
        const containerWidth = (editorElement ? editorElement.clientWidth - 62 : outer.parentElement.offsetWidth) || 1; // NoteEditor 內容寬度 (扣掉左右 padding 共 62px)
        const imageWidth = img.naturalWidth;
        const imageHeight = img.naturalHeight;

        // 如果已有合理的寬度設定，就不需要重新計算
        if (node.attrs.width && node.attrs.width >= 2 && node.attrs.width <= 100) {
          return; // 直接返回，不做任何更新
        }

        // 根據圖片寬高比決定預設顯示寬度
        const aspectRatio = imageWidth / imageHeight;
        let defaultDisplayWidth;

        if (aspectRatio >= 1.1) {
          // 橫圖：寬 ≥ 1.1 × 高
          defaultDisplayWidth = 90;
        } else {
          // 其他情況（正方形或直圖）
          defaultDisplayWidth = 75;
        }

        // 只有當計算出的寬度與當前顯示寬度不同時才更新
        if (defaultDisplayWidth !== initialWidth) {
          // 更新畫面
          outer.style.width = `${defaultDisplayWidth}%`;

          // 寫回 node attrs
          const pos = getPos();
          if (typeof pos === 'number' && !editor.isDestroyed) {
            editor.view.dispatch(
              editor.view.state.tr.setNodeMarkup(pos, undefined, {
                ...node.attrs,
                width: defaultDisplayWidth,
              })
            );
          }
        }
      });

      // 圖片載入失敗時的處理
      img.addEventListener('error', () => {
        // 圖片失效時顯示佔位樣式
        img.style.opacity = '0.5';
        img.alt = '圖片載入失敗';
      });

      // 建立 4 個調整把手
      const handles = ['nw', 'ne', 'sw', 'se'];
      handles.forEach(dir => {
        const handle = document.createElement('span');
        handle.className = `note-editor-resize-handle ${dir}`;
        outer.appendChild(handle);

        const cursor = dir === 'nw' || dir === 'se' ? 'nwse-resize' : 'nesw-resize';
        handle.style.cursor = cursor;

        // 統一處理拖曳開始（滑鼠和觸摸）
        const handleDragStart = (startX) => {
          const startWidth = outer.offsetWidth;
          // 拖曳調整時同樣以 NoteEditor 整體寬度為基準
          if (editor.isDestroyed) return { onMove: () => {}, onEnd: () => {} };
          const editorElement = editor.view.dom.closest('.note-editor');
          const parentWidth = (editorElement ? editorElement.clientWidth - 62 : outer.parentElement.offsetWidth) || 1;

          const onMove = (currentX) => {
            let dx = currentX - startX;
            if (dir === 'nw' || dir === 'sw') dx = -dx;

            // 計算新的百分比寬度，保留兩位小數以提高精確度
            let newWidthPercent = Math.round((startWidth + dx) / parentWidth * 10000) / 100;
            // 限制最小寬度為5%，最大寬度為100%
            newWidthPercent = Math.min(Math.max(5, newWidthPercent), 100);

            // 儲存當前的百分比值，以便在結束時使用
            outer.dataset.currentWidthPercent = String(newWidthPercent);
            outer.style.width = `${newWidthPercent}%`;
          };

          const onEnd = () => {
            // 將寬度寫回 node attrs
            const pos = getPos();
            if (typeof pos === 'number' && !editor.isDestroyed) {
              const currentWidthPercent = parseFloat(outer.dataset.currentWidthPercent);
              editor.view.dispatch(
                editor.view.state.tr.setNodeMarkup(pos, undefined, {
                  ...node.attrs,
                  width: currentWidthPercent,
                })
              );
            }
          };

          return { onMove, onEnd };
        };

        // 滑鼠事件處理
        handle.addEventListener('mousedown', e => {
          e.preventDefault();
          e.stopPropagation();

          const { onMove, onEnd } = handleDragStart(e.clientX);

          const onMouseMove = ev => onMove(ev.clientX);
          const onMouseUp = () => {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            onEnd();
          };

          document.addEventListener('mousemove', onMouseMove);
          document.addEventListener('mouseup', onMouseUp);
        });

        // 觸摸事件處理（Mobile 支援）
        handle.addEventListener('touchstart', e => {
          e.preventDefault();
          e.stopPropagation();

          const touch = e.touches[0];
          const { onMove, onEnd } = handleDragStart(touch.clientX);

          const onTouchMove = ev => {
            ev.preventDefault();
            const currentTouch = ev.touches[0];
            onMove(currentTouch.clientX);
          };
          const onTouchEnd = () => {
            document.removeEventListener('touchmove', onTouchMove);
            document.removeEventListener('touchend', onTouchEnd);
            document.removeEventListener('touchcancel', onTouchEnd);
            onEnd();
          };

          document.addEventListener('touchmove', onTouchMove, { passive: false });
          document.addEventListener('touchend', onTouchEnd);
          document.addEventListener('touchcancel', onTouchEnd);
        }, { passive: false });
      });

      return {
        dom: outer,
        contentDOM: null,
        update: updatedNode => {
          if (updatedNode.type !== node.type) return false;
          if (updatedNode.attrs.src !== img.getAttribute('src')) {
            img.setAttribute('src', updatedNode.attrs.src);
          }
          if (updatedNode.attrs.width) {
            outer.style.width = `${updatedNode.attrs.width}%`;
          }
          return true;
        },
        stopEvent: e => {
          return (e.target as Element)?.classList?.contains('note-editor-resize-handle') ?? false;
        },
        destroy: () => {
          // 清理 ResizeObserver
          if (resizeObserver) {
            resizeObserver.disconnect();
          }
          // 取消訂閱 store
          if (unsubscribe) {
            unsubscribe();
          }
        },
      };
    };
  },

  // 添加全局選擇變化監聽，當離開圖片選擇時關閉圖片文字模式
  addProseMirrorPlugins() {
    return [
      ...(this.parent?.() || [])
    ];
  },

  onSelectionUpdate() {
    if (this.editor.isDestroyed) return;

    // 檢查當前選擇是否在圖片節點上
    const { selection } = this.editor.state;
    const { from, to } = selection;

    // 檢查選中的節點是否為圖片，並獲取圖片資訊
    let isImageSelected = false;
    let selectedImageSrc = null;

    this.editor.state.doc.nodesBetween(from, to, (node, pos) => {
      if (node.type.name === 'image' && from === pos && to === pos + 1) {
        isImageSelected = true;
        selectedImageSrc = node.attrs.src;
        return false; // 停止遍歷
      }
    });

    const currentState = useMaterialModeStore.getState();

    // 檢查是否處於只讀模式 - 優先使用選項，其次使用 DOM 檢查
    const editorElement = this.editor.view.dom.closest('.note-editor');
    const isReadOnlyModeEditor = (this.options as any).isReadOnlyMode || editorElement?.closest('.material-library-content');

    // 只在選中圖片時更新 selectedImageSrc，不自動開啟圖片文字模式
    // 圖片文字模式需要通過點擊圖片右上角的 OCR 圖標來開啟
    if (isImageSelected && selectedImageSrc && !isReadOnlyModeEditor) {
      currentState.setSelectedImageSrc(selectedImageSrc);
    } else if (!isReadOnlyModeEditor) {
      // 沒有選中圖片時，如果圖片文字模式是開啟的，才清除 selectedImageSrc
      // 保留 isImageTextMode 的狀態，讓用戶可以繼續查看文字
    }
    // 如果在只讀模式編輯器中，不做任何圖片文字模式的操作
  },
}); 