import { Extension } from '@tiptap/core';

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    indent: {
      indent: () => ReturnType;
      outdent: () => ReturnType;
    };
  }
}

// Indent 擴展
export const IndentExtension = Extension.create({
  name: 'indent',

  addOptions() {
    return {
      types: ['paragraph', 'heading'],
      indentLevels: 8,
      defaultLevel: 0,
    }
  },

  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          indent: {
            default: this.options.defaultLevel,
            parseHTML: element => {
              return parseInt(element.getAttribute('data-indent') || '0', 10);
            },
            renderHTML: attributes => {
              if (attributes.indent === 0) {
                return {}
              }

              return { 'data-indent': attributes.indent }
            },
          },
        },
      },
    ]
  },

  addCommands() {
    return {
      indent: () => ({ tr, commands, chain, state, dispatch }) => {

        const { selection } = state;
        const { $from, $to } = selection;

        // 檢查是否在支持的類型中
        if (!this.options.types.includes($from.parent.type.name)) {

          return false;
        }

        let didSomething = false;

        state.doc.nodesBetween($from.pos, $to.pos, (node, pos) => {
          if (this.options.types.includes(node.type.name)) {
            const currentIndent = node.attrs.indent || 0;
            const newIndent = Math.min(currentIndent + 1, this.options.indentLevels);

            if (currentIndent !== newIndent) {
              if (dispatch) {
                tr.setNodeMarkup(pos, undefined, {
                  ...node.attrs,
                  indent: newIndent,
                });
              }
              didSomething = true;
            }

          }
        });

        if (dispatch && didSomething) {
          dispatch(tr);
        }

        return didSomething;
      },

      outdent: () => ({ tr, state, dispatch }) => {

        const { selection } = state;
        const { $from, $to } = selection;

        // 檢查是否在支持的類型中
        if (!this.options.types.includes($from.parent.type.name)) {

          return false;
        }

        let didSomething = false;

        state.doc.nodesBetween($from.pos, $to.pos, (node, pos) => {
          if (this.options.types.includes(node.type.name)) {
            const currentIndent = node.attrs.indent || 0;
            const newIndent = Math.max(currentIndent - 1, 0);

            if (currentIndent !== newIndent) {
              if (dispatch) {
                tr.setNodeMarkup(pos, undefined, {
                  ...node.attrs,
                  indent: newIndent,
                });
              }
              didSomething = true;
            }

          }
        });

        if (dispatch && didSomething) {
          dispatch(tr);
        }

        return didSomething;
      },
    }
  },
}) 