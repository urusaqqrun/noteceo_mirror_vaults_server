// 簡單的歷史管理器
class HistoryManager {
  historyStack: any[];
  redoStack: any[];
  depth: number;
  newGroupDelay: number;
  lastGroupTime: number;
  instanceId: string;
  isUndoRedoing: boolean;
  onHistoryChange: (() => void) | null;

  constructor(depth = 100, newGroupDelay = 300, instanceId = 'default') {
    this.historyStack = []
    this.redoStack = []
    this.depth = depth
    this.newGroupDelay = newGroupDelay // 毫秒
    this.lastGroupTime = 0
    this.instanceId = instanceId // 用於區分不同的編輯器實例
    this.isUndoRedoing = false
    this.onHistoryChange = null
  }

  private notifyChange() {
    if (this.onHistoryChange) {
      try { this.onHistoryChange(); } catch (_) { /* 不影響核心邏輯 */ }
    }
  }

  // 存入歷史（同時儲存內容和游標位置）
  pushHistory(content, selection = null) {
    const now = Date.now()
    const shouldGroup = now - this.lastGroupTime < this.newGroupDelay

    const historyEntry = {
      content,
      selection: selection ? { from: selection.from, to: selection.to } : null
    }

    if (shouldGroup && this.historyStack.length > 0) {
      // 在同一組內，覆蓋最後一筆記錄
      this.historyStack[this.historyStack.length - 1] = historyEntry
    } else {
      // 新的一組，添加新記錄
      this.historyStack.push(historyEntry)
      if (this.historyStack.length > this.depth) {
        this.historyStack.shift()
      }
    }

    this.redoStack = [] // 清空 redo stack
    this.lastGroupTime = now
    this.notifyChange();
  }

  // 撤銷
  undo() {
    if (this.historyStack.length <= 1) return false

    this.isUndoRedoing = true;
    const current = this.historyStack.pop()
    this.redoStack.push(current)
    const prevEntry = this.historyStack[this.historyStack.length - 1]

    // 發送事件給 NoteEditor（使用實例 ID）
    const event = new CustomEvent(`historyUndo_${this.instanceId}`, {
      detail: {
        content: prevEntry.content,
        selection: prevEntry.selection
      }
    })
    document.dispatchEvent(event)

    this.notifyChange();
    return true
  }

  // 重做
  redo() {
    if (this.redoStack.length === 0) return false

    this.isUndoRedoing = true;
    const nextEntry = this.redoStack.pop()
    this.historyStack.push(nextEntry)

    // 發送事件給 NoteEditor（使用實例 ID）
    const event = new CustomEvent(`historyRedo_${this.instanceId}`, {
      detail: {
        content: nextEntry.content,
        selection: nextEntry.selection
      }
    })
    document.dispatchEvent(event)

    this.notifyChange();
    return true
  }

  canUndo() {
    return this.historyStack.length > 1
  }

  canRedo() {
    return this.redoStack.length > 0
  }

  // 更新最後一個歷史項目的游標位置
  updateLastSelection(selection) {
    if (this.historyStack.length > 0 && selection) {
      const lastEntry = this.historyStack[this.historyStack.length - 1]
      lastEntry.selection = { from: selection.from, to: selection.to }
    }
  }

  // 清空所有歷史
  clear() {
    this.historyStack = []
    this.redoStack = []
    this.notifyChange();
  }
}

// 全局歷史管理器（向後兼容）
const historyManager = new HistoryManager(100, 300)

export { historyManager, HistoryManager } 