import React, { useState, useMemo, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomToolbar, ToolbarButton } from '../../common/CustomToolbar';
import { useTheme } from '../../setting/ThemeProvider';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { useMaterialModeStore, useEditorRefStore } from './editorStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSearchRegistry } from '../../../Store/searchRegistry';
import { useTempHintStore } from '../../../Store/uiStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { mergeTextMulti } from '../note/ai/noteAI';
import { markdownToHtml } from '../../../utils/mdConverter';
import { convertContentColors } from './extensions/NoteEditorColorUtils';

// 导入 SVG 图标
import TagIcon from '../../../assets/icon_tags_add_24.svg?react';
import BellIcon from '../../../assets/icon_bell_add_24.svg?react';
import BellIconN from '../../../assets/icon_bell_24.svg?react';
import PinIcon from '../../../assets/icon_pin_24.svg?react';
import RedoIcon from '../../../assets/icon_redo_24.svg?react';
import UndoIcon from '../../../assets/icon_undo_24.svg?react';
import AudioIcon from '../../../assets/icon_audio_add_24.svg?react';
import ReferenceIcon from '../../../assets/icon_reference_add_24.svg?react';
import ShareCollabIcon from '../../../assets/icon_share_setting_24.svg?react';
import ArrowLeftIcon from '../../../assets/icon_arrow_left_24.svg?react';

import { TopbarMoreMenu } from './NoteEditorMenu';
import { updateItemShareSettings } from '../../../utils/shareAPI';
import { canAccessSharingDialog, canManageMembers, canEdit } from '../../../utils/shareUtils';
import syncService from '../../../utils/syncService';

function NoteEditorTopbar({ itemId, mode = 'normal', selectedNote, onFieldsChange }: { itemId: string | null; mode?: string; selectedNote?: any; onFieldsChange?: (fields: Record<string, any>) => void }) {
    const { t } = useTranslation();
    const theme = useTheme();
    const isMobileView = useIsMobileView();

    // 使用從父組件傳入的 selectedNote 作為 item（live 數據源）
    const item = selectedNote;

    // 從 store 讀取 editor 和 historyManager
    const historyManager = useEditorRefStore(state => state.historyManager);
    const _historyVersion = useEditorRefStore(state => state.historyVersion);
    const isRecording = useEditorRefStore(state => state.isRecording);

    const isTodoMode = item?.itemType === 'TODO';

    // Dialog 狀態
    const showMoreMenu = useMenuStore(state => state.menus['noteEditorMore']?.show);

    const setTempHint = useTempHintStore(state => state.setTempHint);
    const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
    const isMaterialMode = useMaterialModeStore(state => state.isMaterialMode);
    const setisMaterialMode = useMaterialModeStore(state => state.setisMaterialMode);


    // ===== 所有回調搬入自身 =====

    const handleButtonMouseDown = (e) => {
        e.preventDefault();
    };

    // 手機版返回筆記列表
    const handleMobileBack = () => {
        setSelectedItems([]);
    };

    // 釘選切換
    const handlePinClick = async () => {
        if (!item) return;
        const newPinnedAt = item.pinnedAt ? null : Date.now();
        if (onFieldsChange) {
            onFieldsChange({ pinnedAt: newPinnedAt });
        } else {
            try {
                const storeItem = useItemStore.getState().getById(item.id);
                if (storeItem) {
                    await useItemStore.getState().upsertItem(
                        { ...storeItem, pinnedAt: newPinnedAt, updatedAt: Date.now() } as any,
                        { needSync: true }
                    );
                }
            } catch (error) {
                console.error('切換釘選狀態失敗:', error);
            }
        }
    };

    const handleDelete = async () => {
        if (!item) return;
        const isInTrash = item?.isDeleted === true;
        await useItemStore.getState().removeItems([item.id], { needSync: true, softDelete: !isInTrash, navigateOut: true });
        if (mode === 'window') {
            setTimeout(() => { window.electronAPI.close(); }, 100);
        }
    };

    // 通用複製
    const handleCopy = async () => {
        if (!item) return;
        try {
            const { generateObjectID } = await import('../../../../../services/utils/objectIDUtil.mjs');
            const newItemId = generateObjectID();
            const newItem = {
                ...item,
                id: newItemId,
                name: `${item.name || t('untitled')} ${t('copySuffix')}`,
                createdAt: Date.now(),
                updatedAt: Date.now(),
                pinnedAt: null,
                reminderTime: null,
            };
            await useItemStore.getState().upsertItem({ ...newItem, itemType: item.itemType }, { needSync: true });
            useSelectedItemsStore.getState().setSelectedItems([newItem], { scrollToFocusItem: true, highlightItemId: newItem.id });
            useTempHintStore.getState().setTempHint(t('itemCopied'));
            if (mode === 'window') {
                setTimeout(() => { window.electronAPI.close(); }, 100);
            }
        } catch (error) {
            console.error('複製失敗:', error);
            useTempHintStore.getState().setTempHint(t('copyFailed'));
        }
    };

    // 開始錄音（通過 store 通知 MarkdownEditor）
    const handleStartRecording = () => {
        useEditorRefStore.getState().setIsRecording(true);
    };

    // 重新整理筆記
    const handleRefresh = async () => {
        if (!item?.content) return;
        const refreshItemId = item.id;
        try {
            useTempHintStore.getState().setTempHint('正在重新整理筆記...');
            const result = await mergeTextMulti([item.content], '');
            if (result?.content) {
                // AI 回傳已是 Markdown，直接儲存
                const refreshStoreItem = useItemStore.getState().getById(item.id);
                if (refreshStoreItem) {
                    await useItemStore.getState().upsertItem(
                        { ...refreshStoreItem, content: result.content, updatedAt: Date.now() } as any,
                        { needSync: true }
                    );
                }
                // 更新編輯器內容（MD → HTML 給 TipTap）
                const editor = useEditorRefStore.getState().editorRef;
                if (editor && itemId === refreshItemId) {
                    const isDarkMode = theme.mode === 'dark';
                    const htmlContent = markdownToHtml(result.content);
                    const convertedContent = convertContentColors(htmlContent, isDarkMode);
                    editor.commands.setContent(convertedContent);
                }
                useTempHintStore.getState().setTempHint('筆記重新整理完成！');
            } else {
                useTempHintStore.getState().setTempHint('重新整理失敗，請稍後再試');
            }
        } catch (error) {
            console.error('重新整理筆記時發生錯誤:', error);
            useTempHintStore.getState().setTempHint('重新整理失敗，請稍後再試');
        }
    };

    // undo / redo
    const canUndo = historyManager?.canUndo() ?? false;
    const canRedo = historyManager?.canRedo() ?? false;
    const handleUndo = () => { historyManager?.undo(); };
    const handleRedo = () => { historyManager?.redo(); };

    // 計算素材數量（用 electronAPI.getItem 取代直接讀 noteStore.notes）
    const [materialCount, setMaterialCount] = useState(0);
    useEffect(() => {
        if (!item?.mergedMaterials?.length) { setMaterialCount(0); return; }
        Promise.all(item.mergedMaterials.map((id: string) => window.electronAPI.getItem(id)))
            .then(materials => {
                const count = materials.filter((n: any) => n && !n?.mergedMaterials?.length).length;
                setMaterialCount(count);
            });
    }, [item?.mergedMaterials]);

    // 處理點擊外部關閉菜單
    React.useEffect(() => {
        const handleClickOutside = (event) => {
            if (showMoreMenu && !event.target.closest('.more-menu-container')) {
                useMenuStore.getState().close('noteEditorMore');
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [showMoreMenu]);

    const handleToggleMaterialMode = () => {
        setisMaterialMode(!isMaterialMode);
    };

    const itemEditable = !item || canEdit(item);

    // 組裝左側按鈕
    const leftButtons: ToolbarButton[] = [];
    if (isMobileView) {
        leftButtons.push({ icon: <ArrowLeftIcon />, onClick: handleMobileBack, title: t('back') });
    }
    if (!isMobileView && !isTodoMode && itemEditable) {
        leftButtons.push({
            icon: <PinIcon />,
            onClick: handlePinClick,
            title: item?.pinnedAt ? t('unpin') : t('pin'),
            active: !!item?.pinnedAt,
        });
    }

    // 組裝右側按鈕
    const rightButtons: ToolbarButton[] = [];
    if (itemEditable) {
        rightButtons.push(
            { icon: <UndoIcon />, onClick: handleUndo, title: t('undo'), disabled: !canUndo },
            { icon: <RedoIcon />, onClick: handleRedo, title: t('redo'), disabled: !canRedo },
        );
    }
    if (itemEditable && !isTodoMode && materialCount > 0) {
        rightButtons.push({
            icon: <ReferenceIcon />,
            onClick: handleToggleMaterialMode,
            title: isMaterialMode ? t('closeMaterialMode') : t('openMaterialMode'),
            active: isMaterialMode,
            variant: 'primary' as const,
            badge: materialCount,
        });
    }
    if (itemEditable && !item?.audioURLs?.length && !isRecording) {
        rightButtons.push({ icon: <AudioIcon />, onClick: handleStartRecording, title: t('record') });
    }
    if (itemEditable && !isTodoMode) {
        rightButtons.push({
            icon: item?.reminderTime ? <BellIconN /> : <BellIcon />,
            onClick: () => useDialogStore.getState().open('reminder', {
                item,
                onConfirm: (itemId, reminderTime, offsetMinutes) => {
                    onFieldsChange?.({ reminderTime, offsetMinutes });
                },
                onCancel: (itemId) => {
                    onFieldsChange?.({ reminderTime: null, offsetMinutes: null });
                },
            }),
            title: item?.reminderTime ? t('editReminder') : t('addReminder'),
            active: !!item?.reminderTime,
            variant: 'primary' as const,
        });
    }
    if (itemEditable) rightButtons.push({
        icon: <TagIcon />,
        onClick: async () => {
            if (!item) return;
            const allItems = useSearchRegistry.getState().search('');
            const tagMap = new Map<string, { tag: string; count: number }>();
            allItems.forEach((baseItem: any) => {
                if (!baseItem?.tags) return;
                const itemTags = typeof baseItem.tags === 'string' ? JSON.parse(baseItem.tags) : baseItem.tags;
                if (Array.isArray(itemTags)) {
                    itemTags.forEach((tagEntry: any) => {
                        const tagName = typeof tagEntry === 'string' ? tagEntry : tagEntry?.tag;
                        if (!tagName || typeof tagName !== 'string') return;
                        const existing = tagMap.get(tagName);
                        tagMap.set(tagName, { tag: tagName, count: (existing?.count || 0) + 1 });
                    });
                }
            });
            const allTags = Array.from(tagMap.values());
            useDialogStore.getState().open('tag', {
                item,
                allTags,
                onConfirm: async (tags: string[]) => {
                    onFieldsChange?.({ tags, aiTags: [] });
                },
            });
        },
        title: t('addTag'),
    });
    if (!isTodoMode && item && canAccessSharingDialog(item)) {
        rightButtons.push({
            icon: <ShareCollabIcon />,
            onClick: () => {
                useDialogStore.getState().open('sharing', {
                    item: { id: item.id, name: item.name, isPublic: item.isPublic, itemType: item.itemType },
                    onSave: async (settings) => {
                        await updateItemShareSettings({ ...settings, extra: {} });
                        await syncService.syncChanges();
                        setTempHint(settings.isPublic ? t('shareEnabled') : t('shareDisabled'));
                    },
                });
            },
            title: t('shareSettings'),
        });
    }
    rightButtons.push({
        node: (
            <TopbarMoreMenu
                showMenu={showMoreMenu}
                onMenuClick={() => {
                    if (showMoreMenu) useMenuStore.getState().close('noteEditorMore');
                    else useMenuStore.getState().openAt('noteEditorMore', 0, 0);
                }}
                isNote={item?.itemType === 'NOTE'}
                onDelete={() => { useMenuStore.getState().close('noteEditorMore'); handleDelete(); }}
                onSearch={() => {
                    useMenuStore.getState().close('noteEditorMore');
                    const selectedText = window.getSelection().toString().trim();
                    useDialogStore.getState().open('searchReplace', { searchText: selectedText, editor: useEditorRefStore.getState().editorRef });
                }}
                onCopy={() => {
                    useMenuStore.getState().close('noteEditorMore');
                    handleCopy();
                }}
                noteId={item?.id}
                onCopyNoteLink={(linkItemId) => {
                    const link = `cubelv://note/${linkItemId}`;
                    window.electronClipboard.writeText(link)
                        .then(() => { setTempHint(t('noteLinkCopied')); })
                        .catch(err => {
                            console.error('複製連結失敗:', err);
                            navigator.clipboard.writeText(link)
                                .then(() => { setTempHint(t('noteLinkCopied')); })
                                .catch(clipboardErr => { console.error('所有複製方法都失敗:', clipboardErr); });
                        });
                    useMenuStore.getState().close('noteEditorMore');
                }}
                onRefresh={() => {
                    useMenuStore.getState().close('noteEditorMore');
                    handleRefresh();
                }}
                handleButtonMouseDown={handleButtonMouseDown}
                buttonClassName="custom-toolbar-button"
                onClose={() => useMenuStore.getState().close('noteEditorMore')}
            />
        ),
    });

    return (
        <CustomToolbar
            left={{ buttons: leftButtons }}
            right={{ buttons: rightButtons }}
            borderBottom
        />
    );
}

export default NoteEditorTopbar; 
