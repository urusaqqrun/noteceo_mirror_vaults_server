import React from 'react';
import { useTimeout } from '../../../hooks/useTimeout';
import { useIsConnectedStore } from '../../../Store/uiStore';
import { useAudioRecording } from './hooks/useAudioRecording';
import { deleteFile } from '../../../utils/fileUpload';
import AudioPlayer from './AudioPlayer';
import AudioRecorder from './AudioRecorder';

function AudioContainer({
  noteId,
  selectedNote,
  setSelectedNote,
  onFieldsChangeSilent,
}: {
  noteId: string;
  selectedNote: any;
  setSelectedNote: React.Dispatch<React.SetStateAction<any>>;
  onFieldsChangeSilent: (fields: Record<string, any>) => void;
}) {
  const isConnected = useIsConnectedStore(state => state.isConnected);
  const { setTimeout: safeSetTimeout } = useTimeout();

  const {
    isRecording, audioRecorderRef,
    handleRecordingComplete, handleCancelRecording,
  } = useAudioRecording({
    selectedNote,
    setSelectedNote,
    onFieldsChangeSilent,
    resolvedNoteId: noteId,
    isConnected,
    safeSetTimeout,
  });

  if (!selectedNote) return null;

  return (
    <div className="audio-container">
      {isRecording ? (
        AudioRecorder && (() => {
          const AR = AudioRecorder as React.ComponentType<{
            ref?: React.Ref<unknown>;
            onRecordingComplete?: (audioData: any) => Promise<void>;
            onCancel?: () => void;
          }>;
          return (
            <AR
              ref={audioRecorderRef}
              onRecordingComplete={handleRecordingComplete}
              onCancel={handleCancelRecording}
            />
          );
        })()
      ) : (
        <div style={{ position: 'relative' }}>
          {selectedNote?.audioUrl_local && (selectedNote.audioUrl_local as string[]).length > 0 && (
            <div className="offline-label">
              offline
            </div>
          )}
          <AudioPlayer
            audioURLs={selectedNote?.audioURLs}
            audioUrl_local={selectedNote?.audioUrl_local}
            audioTexts={selectedNote?.audioTexts}
            onTranscriptSave={(updatedTexts) => {
              setSelectedNote(prevNote => ({
                ...prevNote,
                audioTexts: updatedTexts,
              }));
            }}
            onDelete={() => {
              if (!selectedNote?.audioURLs?.length && !selectedNote?.audioUrl_local?.length) return;

              try {
                if (selectedNote.audioURLs) {
                  Promise.all(
                    selectedNote.audioURLs.map(url => deleteFile(url))
                  );
                }

                setSelectedNote({
                  ...selectedNote,
                  audioURLs: null,
                  audioTexts: null,
                  audioUrl_local: null,
                });
              } catch (error) {
                console.error('刪除音頻失敗:', error);
              }
            }}
          />
        </div>
      )}
    </div>
  );
}

export default AudioContainer;
