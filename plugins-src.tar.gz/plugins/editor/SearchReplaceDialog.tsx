import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './SearchReplaceDialog.css';
import { Decoration, DecorationSet } from 'prosemirror-view';
import { Plugin, PluginKey } from 'prosemirror-state';
import { useDialogStore } from '../../../Store/dialogStore';
import { useCommandManager } from '../../../Store/commandManager';

interface SearchReplaceDialogData {
  editor: any;  // Tiptap Editor instance
  searchText?: string;
}

const SearchReplaceDialog = () => {
  const { t } = useTranslation();
  // 從 store 獲取狀態
  const showSearchDialog = useDialogStore(state => state.dialogs['searchReplace']?.show);
  const searchData = useDialogStore(state => state.dialogs['searchReplace']?.data) as SearchReplaceDialogData | null;
  const editor = searchData?.editor || null;
  const initialSearchText = searchData?.searchText || '';
  const closeSearchDialog = () => useDialogStore.getState().close('searchReplace');
  const [searchText, setSearchText] = useState(initialSearchText);
  const [replaceText, setReplaceText] = useState('');
  const [isCaseSensitive, setIsCaseSensitive] = useState(false);
  const [matchCount, setMatchCount] = useState(0);
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);
  const [isReplaceMode, setIsReplaceMode] = useState(false);
  const [matches, setMatches] = useState([]);
  const searchInputRef = useRef(null);
  const searchPluginKey = useRef(new PluginKey('searchHighlightPlugin'));
  const searchDecorations = useRef(DecorationSet.empty);

  // 當對話框打開時清空狀態並聚焦輸入框
  useEffect(() => {
    if (showSearchDialog) {
      setSearchText(initialSearchText);
      setMatchCount(0);
      setCurrentMatchIndex(0);
      setMatches([]);

      // 聚焦搜索輸入框
      setTimeout(() => {
        if (searchInputRef.current) {
          searchInputRef.current.focus();
          searchInputRef.current.select();
        }
      }, 10);

      // 如果对话框打开，创建搜索插件
      createSearchPlugin();
    } else {
      // 对话框关闭时，清除搜索高亮
      clearHighlights();
    }
  }, [showSearchDialog, initialSearchText]);

  // 當搜索文本變化時重新搜索
  useEffect(() => {
    if (searchText && editor && showSearchDialog) {
      performSearch();
    } else {
      clearHighlights();
    }
  }, [searchText, isCaseSensitive, editor]);

  // Escape — commandManager 統一管理
  useEffect(() => {
    if (!showSearchDialog) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'search-replace:escape',
        name: t('cmd.closeSearchReplace'),
        callback: () => closeSearchDialog(),
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [showSearchDialog, closeSearchDialog]);

  // 创建搜索高亮插件
  const createSearchPlugin = () => {
    if (!editor) return;

    // 检查是否已经存在搜索插件
    const plugins = editor.view.state.plugins;
    const existingPluginIndex = plugins.findIndex(p => p.key === (searchPluginKey.current as any).key);

    if (existingPluginIndex === -1) {
      // 创建新的搜索插件
      const searchPlugin = new Plugin({
        key: searchPluginKey.current,
        state: {
          init() {
            return { decorations: DecorationSet.empty };
          },
          apply(tr, state) {
            // 檢查是否有特定的元數據
            const meta = tr.getMeta(searchPluginKey.current);
            if (meta && meta.decorations) {
              return { decorations: meta.decorations };
            }
            return { decorations: searchDecorations.current };
          }
        },
        props: {
          decorations(state) {
            const pluginState = this.getState(state);
            return pluginState ? pluginState.decorations : DecorationSet.empty;
          }
        }
      });

      // 添加插件到编辑器
      editor.registerPlugin(searchPlugin);
    }
  };

  // 清除所有高亮
  const clearHighlights = () => {
    if (editor) {
      // 重置装饰器集合
      searchDecorations.current = DecorationSet.empty;

      // 更新编辑器视图
      const { state, dispatch } = editor.view;
      dispatch(state.tr.setMeta(searchPluginKey.current, { decorations: searchDecorations.current }));

      setMatches([]);
      setMatchCount(0);
      setCurrentMatchIndex(0);
    }
  };

  // 執行搜索
  const performSearch = () => {
    if (!editor || !searchText) return;

    clearHighlights();

    // 遍歷文檔查找所有匹配項
    const foundMatches = [];
    const doc = editor.state.doc;

    doc.descendants((node, pos) => {
      if (node.isText) {
        const nodeText = node.text;

        // 正則搜索模式：考慮大小寫
        const regex = new RegExp(searchText.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&'),
          isCaseSensitive ? 'g' : 'gi');

        let match;
        while ((match = regex.exec(nodeText)) !== null) {
          const from = pos + match.index;
          const to = from + match[0].length;

          foundMatches.push({
            from,
            to,
            text: match[0]
          });
        }
      }
      return true;
    });

    setMatches(foundMatches);
    setMatchCount(foundMatches.length);

    // 如果有匹配項，高亮顯示所有匹配項，並將第一個標記為當前項
    if (foundMatches.length > 0) {
      setCurrentMatchIndex(0); // 確保第一個匹配項被設為當前項
      highlightMatches(foundMatches, 0); // 傳遞索引0表示第一個匹配項為當前項
    }
  };

  // 高亮所有匹配項 - 使用裝飾器
  const highlightMatches = (matchesToHighlight, currentIndex = null) => {
    if (!editor || !matchesToHighlight.length) return;

    const decorations = [];

    // 为每个匹配项创建装饰器
    matchesToHighlight.forEach((match, index) => {
      const { from, to } = match;

      // 判斷是否為當前匹配項
      const isCurrent = currentIndex !== null && index === currentIndex;

      // 创建装饰器
      const decoration = Decoration.inline(
        from,
        to,
        {
          class: isCurrent ? 'search-highlight search-highlight-current' : 'search-highlight'
        }
      );

      decorations.push(decoration);
    });

    // 创建装饰器集合
    searchDecorations.current = DecorationSet.create(editor.state.doc, decorations);

    // 更新编辑器视图
    const { state, dispatch } = editor.view;
    dispatch(state.tr.setMeta(searchPluginKey.current, { decorations: searchDecorations.current }));

    // 如果指定了當前項，確保它可見
    if (currentIndex !== null && matchesToHighlight.length > 0) {
      setTimeout(() => {
        const currentHighlight = document.querySelector('.search-highlight-current');
        if (currentHighlight) {
          currentHighlight.scrollIntoView({
            behavior: 'smooth',
            block: 'center',
            inline: 'nearest'
          });
        }
      }, 10);
    }
  };

  // 高亮當前匹配項
  const highlightCurrentMatch = (index) => {
    if (!editor || !matches.length) return;

    const decorations = [];

    // 为每个匹配项创建装饰器，当前匹配项使用不同的类
    matches.forEach((match, i) => {
      const { from, to } = match;

      // 创建装饰器，当前匹配项添加特殊类
      const decoration = Decoration.inline(
        from,
        to,
        {
          class: i === index ? 'search-highlight search-highlight-current' : 'search-highlight'
        }
      );

      decorations.push(decoration);
    });

    // 创建装饰器集合
    searchDecorations.current = DecorationSet.create(editor.state.doc, decorations);

    // 更新编辑器视图
    const { state, dispatch } = editor.view;
    dispatch(state.tr.setMeta(searchPluginKey.current, { decorations: searchDecorations.current }));
  };

  // 導航到指定匹配項
  const navigateToMatch = (index, matchsList = matches) => {
    if (!editor || !matchsList.length) return;

    // 確保索引在有效範圍內
    const validIndex = (index + matchsList.length) % matchsList.length;
    setCurrentMatchIndex(validIndex);

    const matchInfo = matchsList[validIndex];

    // 更新高亮，但不選擇文本
    highlightCurrentMatch(validIndex);

    // 確保匹配項在視野範圍內，但不進行文本選擇
    setTimeout(() => {
      // 找到當前高亮元素
      const currentHighlight = document.querySelector('.search-highlight-current');
      if (currentHighlight) {
        // 滾動到可見區域
        currentHighlight.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'nearest'
        });
      }
    }, 10);
  };

  // 搜索下一個匹配項
  const findNext = () => {
    if (matches.length === 0) {
      performSearch();
      return;
    }

    navigateToMatch(currentMatchIndex + 1);
  };

  // 搜索上一個匹配項
  const findPrev = () => {
    if (matches.length === 0) {
      performSearch();
      return;
    }

    navigateToMatch(currentMatchIndex - 1);
  };

  // 替換當前匹配項
  const replaceMatch = () => {
    if (!editor || matches.length === 0 || currentMatchIndex < 0) return;

    const matchInfo = matches[currentMatchIndex];

    // 執行替換
    editor.chain()
      .focus()
      .setTextSelection({ from: matchInfo.from, to: matchInfo.to })
      .deleteSelection()
      .insertContent(replaceText)
      .run();

    // 重新執行搜索以更新匹配項
    performSearch();
  };

  // 替換所有匹配項
  const replaceAll = () => {
    if (!editor || matches.length === 0) return;

    // 從後往前替換，避免位置變化問題
    [...matches].reverse().forEach(matchInfo => {
      editor.chain()
        .setTextSelection({ from: matchInfo.from, to: matchInfo.to })
        .deleteSelection()
        .insertContent(replaceText)
        .run();
    });

    // 重新執行搜索以更新匹配項
    performSearch();
  };

  // 關閉對話框
  const handleClose = () => {
    clearHighlights();

    // 卸載插件
    if (editor) {
      const { state, dispatch } = editor.view;
      const tr = state.tr;

      // 清除裝飾
      dispatch(tr.setMeta(searchPluginKey.current, { decorations: DecorationSet.empty }));
    }

    closeSearchDialog();
  };

  // 處理快捷鍵
  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      handleClose();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      if (e.shiftKey) {
        findPrev();
      } else {
        findNext();
      }
    } else if (e.key === 'F3') {
      e.preventDefault();
      if (e.shiftKey) {
        findPrev();
      } else {
        findNext();
      }
    }
  };

  // 切換替換模式
  const toggleReplaceMode = () => {
    setIsReplaceMode(!isReplaceMode);
  };

  if (!showSearchDialog) return null;

  return (
    <div className="search-replace-dialog" onKeyDown={handleKeyDown}>
      <div className="search-replace-header">
        <div className="search-replace-tabs">
          <button
            className={`search-replace-tab ${!isReplaceMode ? 'active' : ''}`}
            onClick={() => setIsReplaceMode(false)}
          >
            尋找
          </button>
          <button
            className={`search-replace-tab ${isReplaceMode ? 'active' : ''}`}
            onClick={() => setIsReplaceMode(true)}
          >
            替換
          </button>
        </div>
        <button className="search-replace-close" onClick={handleClose}>
          <svg viewBox="0 0 24 24" width="16" height="16">
            <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" />
          </svg>
        </button>
      </div>

      <div className="search-replace-content">
        <div className="search-row">
          <input
            ref={searchInputRef}
            type="text"
            className="search-input"
            placeholder={t('findPlaceholder')}
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
          <div className="search-actions">
            <button
              className="search-button prev"
              onClick={findPrev}
              disabled={matchCount === 0}
              title="上一個匹配 (Shift+Enter)"
            >
              <svg viewBox="0 0 24 24" width="16" height="16">
                <path fill="currentColor" d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z" />
              </svg>
            </button>
            <button
              className="search-button next"
              onClick={findNext}
              disabled={matchCount === 0}
              title="下一個匹配 (Enter)"
            >
              <svg viewBox="0 0 24 24" width="16" height="16">
                <path fill="currentColor" d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z" />
              </svg>
            </button>
            <span className="search-count">
              {matchCount > 0 ? `${currentMatchIndex + 1}/${matchCount}` : '0/0'}
            </span>
          </div>
        </div>

        {isReplaceMode && (
          <div className="search-row">
            <input
              type="text"
              className="search-input"
              placeholder={t('replaceWithPlaceholder')}
              value={replaceText}
              onChange={(e) => setReplaceText(e.target.value)}
            />
            <div className="search-actions">
              <button
                className="replace-button"
                onClick={replaceMatch}
                disabled={matchCount === 0}
              >
                替換
              </button>
              <button
                className="replace-all-button"
                onClick={replaceAll}
                disabled={matchCount === 0}
              >
                全部替換
              </button>
            </div>
          </div>
        )}

        <div className="search-options">
          <label className="search-option">
            <input
              type="checkbox"
              checked={isCaseSensitive}
              onChange={(e) => setIsCaseSensitive(e.target.checked)}
            />
            <span>{t('caseSensitive')}</span>
          </label>
        </div>
      </div>
    </div>
  );
};

export default SearchReplaceDialog; 