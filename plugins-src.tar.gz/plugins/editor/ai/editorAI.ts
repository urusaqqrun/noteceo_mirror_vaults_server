// editorAI.ts — AI functions for the editor plugin

import { callPrompt, checkAndHandleCreditsError, getAILanguage } from '../../../../aiService/promptClient';
import {
  GEN_TITLE_PROMPT,
  GEN_TITLE_DEFAULT_DEMAND,
  NOTE_INTENTION_ANALYSIS_PROMPT,
  TAG_INTENTION_ANALYSIS_PROMPT,
  IMG_URL_TO_THEME_PROMPT,
  PROCESS_AUDIO_SUMMARY_PROMPT,
} from './prompts';

// ─── autoTitle ──────────────────────────────────────────────────────────────

export async function autoTitle(
  content: string,
  user_demand: string = '',
): Promise<{ title: string }> {
  try {
    const demand = user_demand || GEN_TITLE_DEFAULT_DEMAND;
    const prompt = GEN_TITLE_PROMPT
      .replace('{context}', content)
      .replace('{user_demand}', demand);

    const lang = getAILanguage();

    const response = await callPrompt({
      action: 'gen_title',
      prompt: `${prompt}\n\nLanguage: ${lang}`,
      model: 'gpt-4.1-nano',
    });

    return {
      title: response.content,
    };
  } catch (error: any) {
    console.error('autoTitle error:', error);
    checkAndHandleCreditsError(error, false, 'titleGeneration');
    throw error;
  }
}

// ─── noteIntentionAnalysis ──────────────────────────────────────────────────

export async function noteIntentionAnalysis(
  content: string,
  abortSignal?: AbortSignal,
): Promise<{ intentionAnalysis: string; intentionJudgment: boolean }> {
  try {
    if (abortSignal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    const prompt = NOTE_INTENTION_ANALYSIS_PROMPT.replace('{content}', content);
    const lang = getAILanguage();

    const response = await callPrompt({
      action: 'note_intention_analysis',
      prompt: `${prompt}\n\nLanguage: ${lang}`,
      model: 'gpt-4.1-nano',
    });

    try {
      const jsonString = response.content
        .replace(/'/g, '"')
        .replace(/True/g, 'true')
        .replace(/False/g, 'false');
      const jsonData = JSON.parse(jsonString);

      return {
        intentionAnalysis: jsonData.intention_analysis,
        intentionJudgment: jsonData.intention_judgment,
      };
    } catch (parseError) {
      console.error('noteIntentionAnalysis JSON parse error:', parseError);
      return {
        intentionAnalysis: '無法解析筆記意圖',
        intentionJudgment: false,
      };
    }
  } catch (error: any) {
    console.error('noteIntentionAnalysis error:', error);
    throw error;
  }
}

// ─── tagIntentionAnalysis ───────────────────────────────────────────────────

export async function tagIntentionAnalysis(
  notes: any,
  tag: any,
): Promise<any> {
  try {
    const notesStr = typeof notes === 'string' ? notes : JSON.stringify(notes);
    const tagStr = typeof tag === 'string' ? tag : JSON.stringify(tag);

    const prompt = TAG_INTENTION_ANALYSIS_PROMPT
      .replace('{notes}', notesStr)
      .replace('{tag}', tagStr);

    const lang = getAILanguage();

    const response = await callPrompt({
      action: 'tag_intention_analysis',
      prompt: `${prompt}\n\nLanguage: ${lang}`,
      model: 'gpt-4.1-nano',
    });

    return {
      analysis: response.content,
    };
  } catch (error: any) {
    console.error('tagIntentionAnalysis error:', error);
    checkAndHandleCreditsError(error, false, 'tagIntentionAnalysis');
    throw error;
  }
}

// ─── imgUrlToTheme ──────────────────────────────────────────────────────────

export async function imgUrlToTheme(
  imageUrl: string,
  detail: string = 'low',
): Promise<any> {
  try {
    const lang = getAILanguage();

    const response = await callPrompt({
      action: 'img_url_to_theme',
      prompt: `${IMG_URL_TO_THEME_PROMPT}\n\nDetail level: ${detail}\nLanguage: ${lang}`,
      model: 'gpt-4o',
      images: [imageUrl],
    });

    try {
      const result = JSON.parse(response.content);
      const theme = result.theme || response.content;
      return { theme };
    } catch {
      // If the response is plain text (not JSON), use it directly as the theme
      return { theme: response.content };
    }
  } catch (error: any) {
    console.error('imgUrlToTheme error:', error);
    throw error;
  }
}

// ─── processAudioSummary ────────────────────────────────────────────────────

export async function processAudioSummary(
  text: string,
  abortSignal?: AbortSignal,
): Promise<any> {
  try {
    if (abortSignal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    const prompt = PROCESS_AUDIO_SUMMARY_PROMPT.replace('{text}', text);
    const lang = getAILanguage();

    const response = await callPrompt({
      action: 'process_audio_summary',
      prompt: `${prompt}\n\nLanguage: ${lang}`,
      model: 'gpt-4o',
    });

    return {
      content: response.content,
    };
  } catch (error: any) {
    console.error('processAudioSummary error:', error);
    throw error;
  }
}
