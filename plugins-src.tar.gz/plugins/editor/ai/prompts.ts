// prompts.ts — Prompt templates for editor plugin AI functions

export const GEN_TITLE_PROMPT = `As an expert at extracting concise headlines, read the context below and produce a single brief title that clearly summarizes the main idea, like a typical note title.

Context:
{context}

{user_demand}

Example: For a passage about Roman architecture, a suitable title might be "Roman Architecture Highlights".

Title:`;

export const GEN_TITLE_DEFAULT_DEMAND =
  'Create a concise title that directly conveys the main idea. Keep it brief like a typical note title. Avoid punctuation.';

export const NOTE_INTENTION_ANALYSIS_PROMPT = `Determine whether the note has a clear, specific purpose. If so, state the purpose; otherwise indicate that there is no clear purpose.

Note content:
{content}

Respond in JSON format with two fields:
- "intention_analysis": a brief description of the note's purpose
- "intention_judgment": true if the note has a clear purpose, false otherwise`;

export const TAG_INTENTION_ANALYSIS_PROMPT = `Analyze whether the given tag is relevant to the provided notes. Evaluate the relationship and provide your analysis.

Notes:
{notes}

Tag:
{tag}

Provide your analysis in JSON format with a "content" field describing the relevance.`;

export const IMG_URL_TO_THEME_PROMPT = `Describe the main theme or subject of this image in a brief sentence.`;

export const PROCESS_AUDIO_SUMMARY_PROMPT = `Summarize the following transcribed audio text into a structured summary. Identify the key points, main topics, and any action items mentioned.

Audio text:
{text}

Provide a structured summary.`;
