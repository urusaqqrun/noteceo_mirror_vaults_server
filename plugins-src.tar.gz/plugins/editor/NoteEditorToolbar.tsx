import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import './NoteEditorToolbar.css';
import { DarkEditorColors, LightEditorColors, useTheme } from '../../setting/ThemeProvider';
import { useFloatingToolbarStore, useEditorRefStore, useMaterialModeStore } from './editorStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTimeout } from '../../../hooks/useTimeout';
import { useCommandManager } from '../../../Store/commandManager';

// 导入 SVG 图标
import BoldIcon from '../../../assets/bk_icon_bold.svg?react';
import LinkIcon from '../../../assets/icon_link_24.svg?react';
import LinkBrokenIcon from '../../../assets/icon_link_broken_24.svg?react';
import ColorSettingIcon from '../../../assets/bk_icon_color_setting.svg?react';
import ItalicIcon from '../../../assets/bk_icon_format_italic.svg?react';
import UnderlineIcon from '../../../assets/font_underlined_26_n.svg?react';
import StrikethroughIcon from '../../../assets/font_strikethrough_26_n.svg?react';
import HighlightIcon from '../../../assets/highlight_mark_26_n.svg?react';
import CodeBlockIcon from '../../../assets/icon_code_24.svg?react';
import PhotoAddIcon from '../../../assets/icon_photo_add_24.svg?react';
import AIRewriteDarkIcon from '../../../assets/icon_ai_rewrite_dark.svg?react';
import AIRewriteLightIcon from '../../../assets/icon_ai_rewrite_light.svg?react';
import ListOutdentIcon from '../../../assets/icon_list_outdent_24.svg?react';
import ListIndentIcon from '../../../assets/icon_list_indent_24.svg?react';
import CustomHint from '../../common/CustomHint';

// 导入菜单组件
import { FontMenu, ListMenu } from './NoteEditorMenu';

// 導入共享的列表按鈕處理函數
import { handleListChange, handleListBackspace } from './extensions/ListUtils';

// 将颜色转换为标准 RGB 格式，便于比较
function normalizeColor(color) {
  if (!color) return '';

  // 已经是 rgb 格式
  if (color.startsWith('rgb')) {
    return color.toLowerCase();
  }

  // CSS 变量直接返回
  if (color.startsWith('var') || color.startsWith('color-mix')) {
    return color.toLowerCase();
  }

  // 十六进制转 RGB
  try {
    const div = document.createElement('div');
    div.style.color = color;
    document.body.appendChild(div);
    const rgbColor = window.getComputedStyle(div).color;
    document.body.removeChild(div);
    return rgbColor.toLowerCase();
  } catch (e) {
    console.error('颜色转换错误:', e);
    return color.toLowerCase();
  }
}

// 比较两个颜色是否相同（考虑不同格式）
function colorsEqual(color1, color2) {
  if (!color1 || !color2) return false;

  try {
    return normalizeColor(color1) === normalizeColor(color2);
  } catch (e) {
    console.error('颜色比较错误:', e);
    // 降级为直接字符串比较
    return color1.toLowerCase() === color2.toLowerCase();
  }
}

function NoteEditorToolbarAndMenu() {
  // 從 store 獲取所有需要的狀態
  const { t } = useTranslation();
  const { setTimeout: safeSetTimeout } = useTimeout();
  const {
    showFloatingToolbar,
    position: floatingToolbarPosition,
    activeColor,
    showFloatingFontMenu,
    showFloatingListMenu,
    showColorMenu,
    setFloatingFontMenu,
    setFloatingListMenu,
    setColorMenu,
    setActiveColor,
    setShowUrlDialog,
    setCurrentUrl,
    hideToolbar
  } = useFloatingToolbarStore();

  const editor = useEditorRefStore(state => state.editorRef);
  const isAIRewriteMode = useMaterialModeStore(state => state.isAIRewriteMode);
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);

  const floatingToolbarRef = useRef(null);
  const [focusedButtonIndex, setFocusedButtonIndex] = useState(-1);
  const [toolbarButtons, setToolbarButtons] = useState([]);
  const [menuFocusState, setMenuFocusState] = useState({ active: false, type: null, index: -1 });
  // 添加悬停提示状态
  const [hoverHint, setHoverHint] = useState('');
  // 添加調色盤方向狀態
  const [colorMenuDirection, setColorMenuDirection] = useState('right');
  const [colorMenuVerticalDirection, setColorMenuVerticalDirection] = useState('up');
  const colorMenuRef = useRef(null);

  // 檢測是否為 mobile 模式
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  // Mobile 模式下的 toolbar top 位置（用於適應虛擬鍵盤）
  const [mobileToolbarTop, setMobileToolbarTop] = useState(0);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Mobile 模式：監聽 visualViewport 變化，動態調整 toolbar 位置
  // 這是為了解決 iOS 虛擬鍵盤彈出時 position: fixed 元素被推走的問題
  useEffect(() => {
    if (!isMobile) return;

    const updateToolbarPosition = () => {
      if (!window.visualViewport) {
        setMobileToolbarTop(0);
        return;
      }

      // visualViewport.offsetTop 是可見區域相對於 layout viewport 的偏移
      // 當頁面被鍵盤推動時，這個值會變化
      const offsetTop = window.visualViewport.offsetTop || 0;
      setMobileToolbarTop(offsetTop);
    };

    // 初始化
    updateToolbarPosition();

    // 監聽 visualViewport 變化
    window.visualViewport?.addEventListener('resize', updateToolbarPosition);
    window.visualViewport?.addEventListener('scroll', updateToolbarPosition);

    return () => {
      window.visualViewport?.removeEventListener('resize', updateToolbarPosition);
      window.visualViewport?.removeEventListener('scroll', updateToolbarPosition);
    };
  }, [isMobile]);

  const theme = useTheme();
  // 根據主題模式選擇顏色列表
  const editorColors = theme.mode === 'dark' ? DarkEditorColors : LightEditorColors;

  // 根據平台獲取修飾鍵文字
  const getModifierKey = () => {
    return window?.electron?.platform === 'win32' ? 'Ctrl' : '⌘';
  };

  // 根據平台獲取第二修飾鍵文字（用於程式碼區塊）
  const getSecondModifierKey = () => {
    return window?.electron?.platform === 'win32' ? 'Alt' : '⌃';
  };

  // 同步外部状态
  useEffect(() => {
    if (showFloatingToolbar && floatingToolbarRef.current) {
      const buttons = Array.from(floatingToolbarRef.current.children)
        .filter(child => (child as any).tagName === 'BUTTON' || (child as any).querySelector(':scope > button'))
        .map(child => (child as any).tagName === 'BUTTON' ? child : (child as any).querySelector(':scope > button'));
      setToolbarButtons(buttons);
    }
  }, [showFloatingToolbar]);

  // 檢測調色盤應該向哪個方向展開
  useEffect(() => {
    if (showColorMenu && floatingToolbarRef.current) {
      const colorMenuContainer = floatingToolbarRef.current.querySelector('.color-menu-container');
      if (colorMenuContainer) {
        // 水平方向判斷
        const rect = colorMenuContainer.getBoundingClientRect();
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        const colorMenuWidth = 280; // 預估的調色盤寬度
        const colorMenuHeight = 180; // 預估的調色盤高度

        // 如果顏色按鈕距離右側邊緣不足以展示調色盤，則向左展開
        if (rect.right + colorMenuWidth > windowWidth) {
          setColorMenuDirection('left');
        } else {
          setColorMenuDirection('right');
        }

        // 垂直方向判斷
        // 預設向上展開，但如果上方空間不足，則向下展開
        if (rect.top - colorMenuHeight < 0) {
          setColorMenuVerticalDirection('down');
        } else {
          setColorMenuVerticalDirection('up');
        }
      }
    }
  }, [showColorMenu, floatingToolbarPosition]);

  // 監聽點擊事件來關閉工具列
  useEffect(() => {
    const handleDocumentClick = (e) => {
      if (floatingToolbarRef.current?.contains(e.target)) {
        return; // 點擊工具列本身不關閉
      }

      // Mobile 模式：點擊編輯器內部不關閉 toolbar（因為 focus 就應該顯示）
      if (isMobile) {
        const editorElement = document.querySelector('.ProseMirror');
        if (editorElement?.contains(e.target)) {
          return; // 點擊編輯器內部不關閉
        }
      }

      setHoverHint(''); // 清除 hint
      setFocusedButtonIndex(-1); // 清除 focused button
      hideToolbar();
    };

    if (showFloatingToolbar) {
      document.addEventListener('mousedown', handleDocumentClick);
      return () => {
        document.removeEventListener('mousedown', handleDocumentClick);
      };
    }
  }, [showFloatingToolbar, hideToolbar, isMobile]);

  // 監聽 editor blur 事件（iOS 鍵盤「完成」按鈕會觸發）
  useEffect(() => {
    if (!editor || !showFloatingToolbar) return;

    const handleBlur = () => {
      // 延遲檢查，因為點擊 toolbar 按鈕時 preventDefault 需要時間生效
      safeSetTimeout(() => {
        // 如果 editor 真的失去焦點（不是點擊 toolbar），關閉 toolbar
        if (!editor.isFocused) {
          setHoverHint('');
          setFocusedButtonIndex(-1);
          hideToolbar();
        }
      }, 100);
    };

    editor.on('blur', handleBlur);
    return () => {
      editor.off('blur', handleBlur);
    };
  }, [editor, showFloatingToolbar, hideToolbar]);

  useEffect(() => {
    if (isMobile && !lastSelected && showFloatingToolbar) {
      hideToolbar();
    }
  }, [isMobile, lastSelected, showFloatingToolbar, hideToolbar]);

  // 修改 updateFloatingToolbar 函數 - 合併版本
  const updateFloatingToolbar = useCallback(() => {

    if (!editor) {

      return;
    }

    // 清除之前的 hint 和 focused button 狀態
    setHoverHint('');
    setFocusedButtonIndex(-1);

    const { from, to } = editor.state.selection;
    const isCollapsed = from === to;

    // Mobile 模式：只要 editor focus（有游標）就顯示 toolbar
    // Desktop 模式：需要有 selection 才顯示
    if (isCollapsed && !isMobile) {
      setHoverHint(''); // 清除 hint
      setFocusedButtonIndex(-1); // 清除 focused button
      useFloatingToolbarStore.getState().hideToolbar();
      return;
    }

    // 检查选区是否只包含分隔线或图片
    let hasHorizontalRule = false;
    let hasImage = false;
    let hasOtherContent = false;

    editor.state.doc.nodesBetween(from, to, (node) => {
      if (node.type.name === 'horizontalRule') {
        hasHorizontalRule = true;
      } else if (node.type.name === 'image') {
        hasImage = true;
      } else if (node.type.name === 'text' && node.text.trim()) {
        hasOtherContent = true;
      } else if (node.type.name !== 'paragraph' && node.type.name !== 'doc') {
        hasOtherContent = true;
      }
      return true;
    });

    // 如果只有分隔线或只有图片（没有其他内容），不显示工具栏
    if ((hasHorizontalRule || hasImage) && !hasOtherContent) {
      setHoverHint(''); // 清除 hint
      setFocusedButtonIndex(-1); // 清除 focused button
      useFloatingToolbarStore.getState().hideToolbar();
      return;
    }

    const selection = window.getSelection();

    // Mobile 空行時，用游標位置定位 toolbar
    if (isMobile && isCollapsed) {
      // 獲取選中文字的顏色
      const currentColor = editor.getAttributes('textStyle').color;
      setActiveColor(currentColor || 'var(--on)');
      // Mobile 模式固定在頂部，不需要計算位置
      useFloatingToolbarStore.getState().showToolbar({ top: 0, left: 0 });
      return;
    }

    if (!selection || selection.rangeCount === 0) {
      return;
    }

    // 獲取選中文字的顏色
    const currentColor = editor.getAttributes('textStyle').color;
    const activeColorToUse = currentColor || 'var(--on)';

    const range = selection.getRangeAt(0);
    let rect = range.getBoundingClientRect();

    // 對於長選區，找到可見區域內的位置
    if (rect.height > window.innerHeight || rect.top < 0 || rect.bottom > window.innerHeight) {
      rect = {
        left: rect.left,
        right: rect.right,
        width: rect.width,
        top: Math.max(50, Math.min(rect.top, window.innerHeight / 2)),
        bottom: Math.max(50, Math.min(rect.top, window.innerHeight / 2)) + 20,
        height: 20,
        x: rect.left,
        y: Math.max(50, Math.min(rect.top, window.innerHeight / 2)),
        toJSON: () => ({})
      } as DOMRect;
    }

    if (rect.width === 0 && rect.height === 0) return;

    // 計算水平位置，從 CSS 變數獲取實際的縮放值
    const computedScale = getComputedStyle(document.documentElement)
      .getPropertyValue('--content-scale')
      .trim();
    const SCALE = parseFloat(computedScale) || 1;

    const toolbarHeight = 40;
    const toolbarWidth = 400; // 預估工具列寬度

    // 將選區位置轉換回未縮放的座標
    let newLeft = rect.left / SCALE;

    // 置中對齊工具列
    newLeft = newLeft + (rect.width / SCALE / 2) - (toolbarWidth / 2);

    // 確保工具列不會超出視窗邊界
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;

    if (newLeft < 10) {
      newLeft = 10;
    } else if (newLeft + toolbarWidth > windowWidth - 10) {
      newLeft = windowWidth - toolbarWidth - 10;
    }

    // 計算垂直位置 - 根據平台調整偏移量
    const isWindows = window?.electron?.platform === 'win32';
    // Windows 需要額外的偏移量來補償標題列高度
    const platformOffset = isWindows ? -36 : 0;
    let newTop = (rect.top + platformOffset) / SCALE - toolbarHeight - 10;

    if (newTop < 10) {
      newTop = (rect.bottom + platformOffset) / SCALE + 10;
    }

    // 設置位置並顯示工具列
    useFloatingToolbarStore.getState().showToolbar({
      left: newLeft,
      top: newTop
    }, activeColorToUse);
  }, [editor]);

  // 監聽選區變化來更新工具列位置
  useEffect(() => {
    if (!editor) {
      return;
    }
    // 監聯編輯器的選區變化事件
    const handleSelectionUpdate = () => {

      // 使用 safeSetTimeout 確保 DOM 更新完成後再計算位置
      safeSetTimeout(updateFloatingToolbar, 0);
    };

    // Mobile 模式：監聽 focus 事件，focus 就顯示 toolbar
    const handleFocus = () => {
      if (isMobile) {
        safeSetTimeout(updateFloatingToolbar, 0);
      }
    };

    editor.on('selectionUpdate', handleSelectionUpdate);
    editor.on('focus', handleFocus);


    if (isMobile && editor.isFocused) {
      safeSetTimeout(updateFloatingToolbar, 0);
    }

    return () => {

      editor.off('selectionUpdate', handleSelectionUpdate);
      editor.off('focus', handleFocus);
    };
  }, [editor, updateFloatingToolbar, isMobile]);

  // 重置所有菜单状态
  const resetMenuState = () => {
    setMenuFocusState({ active: false, type: null, index: -1 });
    setFloatingFontMenu(false);
    setFloatingListMenu(false);
    setColorMenu(false);
  };

  // 處理格式化操作
  const handleFormat = (type, value?) => {
    if (!editor) return;

    switch (type) {
      case 'aiRewrite':
        // 開啟 AI rewrite 模式
        useMaterialModeStore.getState().setisAIRewriteMode(true);
        // 關閉 toolbar
        hideToolbar();
        break;
      case 'bold':
        editor.chain().focus().toggleBold().run();
        break;
      case 'italic':
        editor.chain().focus().toggleItalic().run();
        break;
      case 'strike':
        editor.chain().focus().toggleStrike().run();
        break;
      case 'underline':
        editor.chain().focus().toggleUnderline().run();
        break;
      case 'highlight':
        editor.chain().focus().toggleHighlight().run();
        break;
      case 'color':
        editor.chain().focus().setColor(value).run();
        break;
      case 'link':
        // 获取当前选中文本的链接属性
        const linkMark = editor.getAttributes('link');

        // 如果選中的是連結的一部分，應該擴展選擇範圍到整個連結
        if (linkMark.href) {
          const { from, to } = editor.state.selection;
          const { state } = editor;

          // 向前搜索連結的開始
          let startPos = from;
          while (startPos > 0 && state.doc.rangeHasMark(startPos - 1, startPos, state.schema.marks.link)) {
            startPos--;
          }

          // 向後搜索連結的結束
          let endPos = to;
          while (endPos < state.doc.content.size && state.doc.rangeHasMark(endPos, endPos + 1, state.schema.marks.link)) {
            endPos++;
          }

          // 選擇整个連結文本
          console.error('[SELECTION_CHANGE] toolbar link setTextSelection', { startPos, endPos });
          editor.chain().focus().setTextSelection({ from: startPos, to: endPos }).run();

          // 更新當前 URL（用於在對話框中顯示）
          setCurrentUrl(linkMark.href);
        } else if (editor.state.selection.empty) {
          // 如果沒有選擇任何文字，提示用戶選擇文字
          return;
        }

        setShowUrlDialog(true);
        // 如果已经有链接，传递现有的 URL
        if (linkMark.href) {
          // 将现有 URL 作为参数传递给对话框
          setCurrentUrl(linkMark.href);
        } else {
          // 重置為預設 URL
          setCurrentUrl('https://');
        }
        break;
      case 'unlink':
        const { state } = editor;
        const { from, to } = state.selection;

        // 找到当前位置的 marks
        const marks = state.doc.rangeHasMark(from, to, state.schema.marks.link);

        if (marks) {
          // 向前搜索链接的开始
          let startPos = from;
          while (startPos > 0 && state.doc.rangeHasMark(startPos - 1, startPos, state.schema.marks.link)) {
            startPos--;
          }

          // 向后搜索链接的结束
          let endPos = to;
          while (endPos < state.doc.content.size && state.doc.rangeHasMark(endPos, endPos + 1, state.schema.marks.link)) {
            endPos++;
          }

          // 选择整个链接文本并取消链接
          console.error('[SELECTION_CHANGE] toolbar unlink setTextSelection', { startPos, endPos });
          editor.chain()
            .focus()
            .setTextSelection({ from: startPos, to: endPos })
            .unsetLink()
            .run();

          hideToolbar();
        }
        break;
      case 'codeBlock':
        editor.chain().focus().toggleCodeBlock().run();
        break;
    }
  };

  // 處理浮動選單點擊
  const handleFloatingMenuClick = (menuType) => (e) => {
    e?.preventDefault();
    e?.stopPropagation();

    switch (menuType) {
      case 'font':
        setFloatingFontMenu(!showFloatingFontMenu);
        setFloatingListMenu(false);
        setColorMenu(false);
        break;
      case 'list':
        setFloatingListMenu(!showFloatingListMenu);
        setFloatingFontMenu(false);
        setColorMenu(false);
        break;
      case 'color':
        setColorMenu(!showColorMenu);
        setFloatingFontMenu(false);
        setFloatingListMenu(false);
        break;
    }
  };

  // 處理字體大小選擇
  const handleFontSizeSelect = (level) => {
    if (!editor) return;

    switch (level) {
      case 'content':
      case 0:
        editor.chain().focus().setParagraph().run();
        break;
      case 'h1':
      case 1:
        editor.chain().focus().toggleHeading({ level: 1 }).run();
        break;
      case 'h2':
      case 2:
        editor.chain().focus().toggleHeading({ level: 2 }).run();
        break;
      case 'h3':
      case 3:
        editor.chain().focus().toggleHeading({ level: 3 }).run();
        break;
    }
    setFloatingFontMenu(false);
  };

  // 使用共享的列表按鈕處理函數
  const handleListButtonClickLocal = (listType) => {
    handleListChange(editor, listType, () => {
      hideToolbar();
      setFloatingListMenu(false);
    });
  };

  // 工具列鍵盤導航 — commandManager 統一管理
  useEffect(() => {
    if (!showFloatingToolbar) return;
    const cm = useCommandManager.getState();

    // 包裝 handler 為 checkCallback（需要內部判斷 menuFocusState）
    // requireFocus: 方向鍵需要有按鈕被鍵盤聚焦才攔截，否則會阻擋編輯器內的游標移動
    const makeToolbarNavCommand = (id: string, name: string, key: string, handler: () => void, requireFocus = false) =>
      cm.register({
        command: {
          id,
          name,
          checkCallback: (checking: boolean) => {
            if (!showFloatingToolbar || !floatingToolbarRef.current) return false;
            // 方向鍵：只有在有按鈕被鍵盤聚焦或菜單活動時才攔截，
            // 否則讓方向鍵正常移動游標（修復選區後無法用左右鍵移動的問題）
            if (requireFocus && focusedButtonIndex < 0 && !menuFocusState.active) return false;
            if (!checking) handler();
            return true;
          },
        },
        hotkeys: [{ modifiers: [], key }],
      });

    const handleArrowNav = (direction: 'left' | 'right' | 'up' | 'down') => {
      // 如果菜单处于活动状态，处理菜单内的导航
      if (menuFocusState.active) {
        let menuContainer, itemsArray;
        if (menuFocusState.type === 'font') {
          menuContainer = floatingToolbarRef.current.querySelector('.font-menu.floating');
          itemsArray = menuContainer ? Array.from(menuContainer.querySelectorAll('.font-menu-item')) : [];
        } else if (menuFocusState.type === 'list') {
          menuContainer = floatingToolbarRef.current.querySelector('.list-menu.floating');
          itemsArray = menuContainer ? Array.from(menuContainer.querySelectorAll('.list-menu-item')) : [];
        } else if (menuFocusState.type === 'color') {
          menuContainer = floatingToolbarRef.current.querySelector('.color-menu.floating');
          itemsArray = menuContainer ? Array.from(menuContainer.querySelectorAll('.toolbar-color-button')) : [];
        }
        if (!menuContainer || !itemsArray.length) { resetMenuState(); return; }
        const ITEMS_PER_ROW = menuFocusState.type === 'color' ? 7 : 1;
        const currentIndex = menuFocusState.index;
        let newIndex = currentIndex;
        if (direction === 'up') {
          newIndex = menuFocusState.type === 'color' ? (currentIndex - ITEMS_PER_ROW < 0 ? itemsArray.length - 1 : currentIndex - ITEMS_PER_ROW) : (currentIndex <= 0 ? itemsArray.length - 1 : currentIndex - 1);
        } else if (direction === 'down') {
          newIndex = menuFocusState.type === 'color' ? (currentIndex + ITEMS_PER_ROW >= itemsArray.length ? currentIndex % ITEMS_PER_ROW : currentIndex + ITEMS_PER_ROW) : (currentIndex >= itemsArray.length - 1 ? 0 : currentIndex + 1);
        } else if (direction === 'left' && menuFocusState.type === 'color') {
          newIndex = currentIndex <= 0 ? itemsArray.length - 1 : currentIndex - 1;
        } else if (direction === 'right' && menuFocusState.type === 'color') {
          newIndex = currentIndex >= itemsArray.length - 1 ? 0 : currentIndex + 1;
        } else if (direction === 'left' || direction === 'right') {
          // 非 color 菜单不处理左右，走工具栏导航
          handleToolbarNav(direction);
          return;
        }
        if (newIndex !== currentIndex) {
          (itemsArray[currentIndex] as HTMLElement)?.classList.remove('keyboard-focus');
          (itemsArray[newIndex] as HTMLElement)?.classList.add('keyboard-focus');
          setMenuFocusState({ ...menuFocusState, index: newIndex });
        }
        return;
      }
      // 工具栏按钮导航
      handleToolbarNav(direction);
    };

    const handleToolbarNav = (direction: string) => {
      if (direction === 'left') {
        if (focusedButtonIndex === -1) return;
        const newIndex = focusedButtonIndex <= 0 ? toolbarButtons.length - 1 : focusedButtonIndex - 1;
        toolbarButtons[newIndex]?.classList.add('keyboard-focus');
        toolbarButtons[focusedButtonIndex]?.classList.remove('keyboard-focus');
        setFocusedButtonIndex(newIndex);
        updateHintForButton(newIndex);
      } else if (direction === 'right') {
        if (focusedButtonIndex === -1) return;
        const newIndexRight = focusedButtonIndex >= toolbarButtons.length - 1 ? 0 : focusedButtonIndex + 1;
        toolbarButtons[newIndexRight]?.classList.add('keyboard-focus');
        toolbarButtons[focusedButtonIndex]?.classList.remove('keyboard-focus');
        setFocusedButtonIndex(newIndexRight);
        updateHintForButton(newIndexRight);
      }
    };

    const unsubs = [
      makeToolbarNavCommand('toolbar:arrow-left', 'Toolbar Left', 'ArrowLeft', () => handleArrowNav('left'), true),
      makeToolbarNavCommand('toolbar:arrow-right', 'Toolbar Right', 'ArrowRight', () => handleArrowNav('right'), true),
      makeToolbarNavCommand('toolbar:arrow-up', 'Toolbar Up', 'ArrowUp', () => handleArrowNav('up'), true),
      makeToolbarNavCommand('toolbar:arrow-down', 'Toolbar Down', 'ArrowDown', () => handleArrowNav('down'), true),
      makeToolbarNavCommand('toolbar:enter', 'Toolbar Enter', 'Enter', () => {
        if (menuFocusState.active) {
          let menuContainer, itemsArray;
          if (menuFocusState.type === 'font') {
            menuContainer = floatingToolbarRef.current.querySelector('.font-menu.floating');
            itemsArray = menuContainer ? Array.from(menuContainer.querySelectorAll('.font-menu-item')) : [];
          } else if (menuFocusState.type === 'list') {
            menuContainer = floatingToolbarRef.current.querySelector('.list-menu.floating');
            itemsArray = menuContainer ? Array.from(menuContainer.querySelectorAll('.list-menu-item')) : [];
          } else if (menuFocusState.type === 'color') {
            menuContainer = floatingToolbarRef.current.querySelector('.color-menu.floating');
            itemsArray = menuContainer ? Array.from(menuContainer.querySelectorAll('.toolbar-color-button')) : [];
          }
          if (menuFocusState.index >= 0 && itemsArray?.length) {
            (itemsArray[menuFocusState.index] as HTMLElement)?.classList.remove('keyboard-focus');
            (itemsArray[menuFocusState.index] as HTMLElement)?.click();
            toolbarButtons.forEach(button => button?.classList.remove('keyboard-focus'));
            resetMenuState();
          }
          return;
        }
        if (focusedButtonIndex >= 0 && focusedButtonIndex < toolbarButtons.length) {
          const button = toolbarButtons[focusedButtonIndex];
          const isFontButton = button.closest('.font-menu-container');
          const isListButton = button.closest('.list-menu-container');
          const isColorButton = button.closest('.color-menu-container');
          if (isFontButton) {
            button.click();
            setMenuFocusState({ active: true, type: 'font', index: 0 });
            safeSetTimeout(() => { document.querySelector('.font-menu.floating .font-menu-item')?.classList.add('keyboard-focus'); }, 0);
          } else if (isListButton) {
            button.click();
            setMenuFocusState({ active: true, type: 'list', index: 0 });
            safeSetTimeout(() => { document.querySelector('.list-menu.floating .list-menu-item')?.classList.add('keyboard-focus'); }, 0);
          } else if (isColorButton) {
            button.click();
            setMenuFocusState({ active: true, type: 'color', index: 0 });
            safeSetTimeout(() => { document.querySelector('.color-menu.floating .toolbar-color-button')?.classList.add('keyboard-focus'); }, 0);
          } else {
            button.click();
          }
        }
      }),
      makeToolbarNavCommand('toolbar:tab', 'Toolbar Tab', 'Tab', () => {
        document.querySelectorAll('.tab-button').forEach(button => (button as HTMLElement).blur());
        if (focusedButtonIndex === -1) {
          setFocusedButtonIndex(0);
          toolbarButtons[0]?.classList.add('keyboard-focus');
          updateHintForButton(0);
        } else {
          const newTabIndex = focusedButtonIndex >= toolbarButtons.length - 1 ? 0 : focusedButtonIndex + 1;
          toolbarButtons[newTabIndex]?.classList.add('keyboard-focus');
          toolbarButtons[focusedButtonIndex]?.classList.remove('keyboard-focus');
          updateHintForButton(newTabIndex);
          setFocusedButtonIndex(newTabIndex);
        }
      }),
      makeToolbarNavCommand('toolbar:escape', 'Toolbar Escape', 'Escape', () => {
        if (menuFocusState.active) {
          let itemsArray;
          if (menuFocusState.type === 'font') {
            itemsArray = Array.from(floatingToolbarRef.current.querySelectorAll('.font-menu.floating .font-menu-item'));
          } else if (menuFocusState.type === 'list') {
            itemsArray = Array.from(floatingToolbarRef.current.querySelectorAll('.list-menu.floating .list-menu-item'));
          } else if (menuFocusState.type === 'color') {
            itemsArray = Array.from(floatingToolbarRef.current.querySelectorAll('.color-menu.floating .toolbar-color-button'));
          }
          if (menuFocusState.index >= 0 && itemsArray?.length) {
            (itemsArray[menuFocusState.index] as HTMLElement)?.classList.remove('keyboard-focus');
          }
          resetMenuState();
          return;
        }
        if (focusedButtonIndex >= 0) {
          toolbarButtons[focusedButtonIndex]?.classList.remove('keyboard-focus');
          setFocusedButtonIndex(-1);
          setHoverHint('');
        }
      }),
    ];
    return () => unsubs.forEach(u => u());
  }, [showFloatingToolbar, toolbarButtons, focusedButtonIndex, menuFocusState]);

  if (!showFloatingToolbar || !editor) {
    return null;
  }

  const isSelectionCollapsed = editor?.state?.selection?.empty;

  // 檢測是否在列表項中
  const isInListItem = (() => {
    if (!editor) return false;
    const { from } = editor.state.selection;
    const $pos = editor.state.doc.resolve(from);
    let depth = $pos.depth;
    while (depth > 0) {
      const node = $pos.node(depth);
      if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
        return true;
      }
      depth--;
    }
    return false;
  })();

  // 處理列表升階（減少縮進）- 先移到列表項開頭，再調用 handleListBackspace
  const handleListOutdent = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!editor) return;

    // 獲取當前位置
    const { from } = editor.state.selection;
    const $pos = editor.state.doc.resolve(from);

    // 找到列表項節點，獲取列表項開頭位置
    for (let d = $pos.depth; d > 0; d--) {
      const node = $pos.node(d);
      if (node.type.name === 'listItem' || node.type.name === 'taskItem') {
        // 找到列表項開頭位置（+1 是進入列表項內部的段落開頭）
        const listItemStart = $pos.before(d) + 1;
        // 先將光標移到列表項開頭
        console.error('[SELECTION_CHANGE] toolbar listOutdent setTextSelection', { listItemStart });
        editor.chain().focus().setTextSelection(listItemStart).run();
        break;
      }
    }

    // 調用自製的升階邏輯
    handleListBackspace(editor);
  };

  // 處理列表降階（增加縮進）- 使用和 Tab 鍵一樣的做法
  const handleListIndent = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!editor) return;

    // 獲取當前列表類型
    const { from } = editor.state.selection;
    const $pos = editor.state.doc.resolve(from);
    let currentListType = null;

    for (let d = $pos.depth; d > 0; d--) {
      const node = $pos.node(d);
      if (['bulletList', 'orderedList', 'taskList'].includes(node.type.name)) {
        currentListType = node.type.name;
        break;
      }
    }

    const itemType = currentListType === 'taskList' ? 'taskItem' : 'listItem';
    editor.chain().focus().sinkListItem(itemType).run();
  };

  // 设置字体菜单的快捷键提示
  const handleFontMenuHover = () => {
    setHoverHint(`『${getModifierKey()}』+『1/2/3』${t('switchHeading')}`);
  };

  // 设置列表菜单的快捷键提示
  const handleListMenuHover = () => {
    setHoverHint(`『${getModifierKey()}』+『4/5/6』${t('switchList')}`);
  };

  // 添加一個函數來更新鍵盤導航時的提示信息
  const updateHintForButton = (index) => {
    if (index < 0 || index >= toolbarButtons.length) return;

    const button = toolbarButtons[index];
    if (!button) return;

    // 检查按钮类型并设置相应的提示
    if (button.closest('.font-menu-container')) {
      setHoverHint(`『${getModifierKey()}』+『1/2/3』${t('switchHeading')}`);
    } else if (button.closest('.list-menu-container')) {
      setHoverHint(`『${getModifierKey()}』+『4/5/6』${t('switchList')}`);
    } else if (button.closest('.color-menu-container')) {
      setHoverHint(t('textColor'));
    } else {
      // 根据按钮在工具栏中的位置设置提示
      const toolbarIndex = Array.from(toolbarButtons).indexOf(button);

      if (toolbarIndex === 0) { // AI rewrite 按钮
        setHoverHint(`『${getModifierKey()}』+『R』${t('aiRewrite')}`);
      } else if (toolbarIndex === 4) { // 粗体按钮（位置調整）
        setHoverHint(`『${getModifierKey()}』+『B』${t('bold')}`);
      } else if (toolbarIndex === 5) { // 斜体按钮
        setHoverHint(`『${getModifierKey()}』+『I』${t('italic')}`);
      } else if (toolbarIndex === 6) { // 删除线按钮
        setHoverHint(`『${getModifierKey()}』+『S』${t('strikethrough')}`);
      } else if (toolbarIndex === 7) { // 下划线按钮
        setHoverHint(`『${getModifierKey()}』+『U』${t('underline')}`);
      } else if (toolbarIndex === 8) { // 高亮按钮
        setHoverHint(`『${getModifierKey()}』+『H』${t('highlight')}`);
      } else if (toolbarIndex === 10) { // 链接按钮（位置調整）
        setHoverHint(`『${getModifierKey()}』+『L』${t('addLink')}`);
      } else if (toolbarIndex === 11) { // 移除链接按钮
        setHoverHint(t('removeLink'));
      } else if (toolbarIndex === 12) { // 程式碼區塊按鈕
        setHoverHint(`『${getModifierKey()}』+『${getSecondModifierKey()}』+『C』${t('codeBlock')}`);
      }
    }
  };

  return (
    <>
      <div
        ref={floatingToolbarRef}
        className="floating-toolbar active"
        onMouseDown={(e) => e.preventDefault()}
        style={{
          position: 'fixed',
          // Mobile 模式：使用動態計算的 top 位置來適應虛擬鍵盤
          // 桌面模式：使用 floatingToolbarPosition.top
          top: isMobile ? `${mobileToolbarTop}px` : `${floatingToolbarPosition.top}px`,
          left: `${floatingToolbarPosition.left}px`,
        }}
      >
        {/* 內層 wrapper 處理橫向滾動，讓 toolbar 本身 overflow: visible */}
        {/* 當選單打開時加 menu-open class 讓 wrapper overflow: visible */}
        <div className={`toolbar-scroll-wrapper ${showFloatingFontMenu || showFloatingListMenu || showColorMenu ? 'menu-open' : ''}`}>
          <button
            onClick={() => handleFormat('aiRewrite')}
            className={`toolbar-button ${isAIRewriteMode ? 'active' : ''}`}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『R』${t('aiRewrite')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            {theme.mode === 'dark' ? <AIRewriteDarkIcon /> : <AIRewriteLightIcon />}
          </button>

          {/* Mobile 模式下，非列表中顯示圖片插入按鈕 */}
          {isMobile && isSelectionCollapsed && !isInListItem && (
            <button
              className="toolbar-button"
              title={t('addImage')}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                document.dispatchEvent(new CustomEvent('note-editor-add-image'));
              }}
            >
              <PhotoAddIcon />
            </button>
          )}

          {/* Mobile 模式下，在列表中顯示升降階按鈕 */}
          {isMobile && isInListItem && (
            <>
              <button
                className="toolbar-button"
                title={t('listOutdent')}
                onClick={handleListOutdent}
              >
                <ListOutdentIcon />
              </button>
              <button
                className="toolbar-button"
                title={t('listIndent')}
                onClick={handleListIndent}
              >
                <ListIndentIcon />
              </button>
            </>
          )}

          <FontMenu
            showMenu={showFloatingFontMenu}
            onMenuClick={handleFloatingMenuClick('font')}
            onFontSizeSelect={handleFontSizeSelect}
            handleButtonMouseDown={() => { }}
            buttonClassName="toolbar-button"
            floating={true}
            onMouseEnter={handleFontMenuHover}
            onMouseLeave={() => setHoverHint('')}
          />

          <ListMenu
            showMenu={showFloatingListMenu}
            onMenuClick={handleFloatingMenuClick('list')}
            handleListChange={handleListButtonClickLocal}
            handleButtonMouseDown={() => { }}
            buttonClassName="toolbar-button"
            floating={true}
            onMouseEnter={handleListMenuHover}
            onMouseLeave={() => setHoverHint('')}
          />

          <button
            onClick={() => handleFormat('bold')}
            className={`toolbar-button ${editor?.isActive('bold') ? 'active' : ''}`}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『B』${t('bold')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <BoldIcon />
          </button>
          <button
            onClick={() => handleFormat('italic')}
            className={`toolbar-button ${editor?.isActive('italic') ? 'active' : ''}`}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『I』${t('italic')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <ItalicIcon />
          </button>
          <button
            onClick={() => handleFormat('strike')}
            className={`toolbar-button ${editor?.isActive('strike') ? 'active' : ''}`}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『S』${t('strikethrough')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <StrikethroughIcon />
          </button>
          <button
            onClick={() => handleFormat('underline')}
            className={`toolbar-button ${editor?.isActive('underline') ? 'active' : ''}`}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『U』${t('underline')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <UnderlineIcon />
          </button>
          <button
            onClick={() => handleFormat('highlight')}
            className={`toolbar-button ${editor?.isActive('highlight') ? 'active' : ''}`}
            data-highlight={editor?.isActive('highlight') ? 'true' : undefined}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『H』${t('highlight')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <HighlightIcon />
          </button>
          <div className="color-menu-container">
            <button
              onClick={handleFloatingMenuClick('color')}
              className="toolbar-button"
              onMouseEnter={() => setHoverHint(t('textColor'))}
              onMouseLeave={() => setHoverHint('')}
            >
              <ColorSettingIcon style={{ color: activeColor }} />
            </button>
            <div
              ref={colorMenuRef}
              className={`color-menu floating ${showColorMenu ? 'active' : ''} ${colorMenuDirection === 'left' ? 'align-right' : ''} ${colorMenuVerticalDirection === 'up' ? 'align-top' : 'align-bottom'}`}
            >
              <div className="color-grid">
                {editorColors.map(({ id, color }, index) => {
                  // 使用新的颜色比较函数
                  const isActive = colorsEqual(activeColor, color);

                  return (
                    <button
                      key={id}
                      className={`toolbar-color-button ${isActive ? 'active' : ''}`}
                      onClick={(e) => {
                        // 确保事件对象存在
                        if (e) {
                          e.preventDefault();
                          e.stopPropagation();
                        }

                        // 如果是左上角第一個顏色（default），則移除顏色而不是設置顏色
                        if (index === 0 || id === 'default') {
                          editor?.chain().focus().unsetColor().run();
                          setActiveColor('var(--on)');
                        } else {
                          handleFormat('color', color);
                          setActiveColor(color);
                        }

                        // 修改调用方式，避免 undefined 事件对象
                        const closeMenu = handleFloatingMenuClick('color');
                        closeMenu(e);
                      }}
                      style={{
                        ['--button-color' as string]: color
                      }}
                    />
                  );
                })}
              </div>
            </div>
          </div>
          <button
            className={`toolbar-button ${editor?.isActive('link') ? 'active' : ''}`}
            onClick={() => handleFormat('link')}
            title={t('addLink')}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『L』${t('addLink')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <LinkIcon />
          </button>
          {false && (
            <button
              className="toolbar-button"
              title={t('addTable')}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                document.dispatchEvent(new CustomEvent('note-editor-add-table', { detail: { anchor: e.currentTarget } }));
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" transform="scale(0.9)">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2" stroke="currentColor" strokeWidth="2" fill="none" />
                <line x1="9" y1="3" x2="9" y2="21" stroke="currentColor" strokeWidth="2" />
                <line x1="15" y1="3" x2="15" y2="21" stroke="currentColor" strokeWidth="2" />
                <line x1="3" y1="9" x2="21" y2="9" stroke="currentColor" strokeWidth="2" />
                <line x1="3" y1="15" x2="21" y2="15" stroke="currentColor" strokeWidth="2" />
              </svg>
            </button>
          )}

          {editor?.isActive('link') && (
            <button
              className="toolbar-button"
              onClick={() => handleFormat('unlink')}
              title={t('removeLink')}
              onMouseEnter={() => setHoverHint(t('removeLink'))}
              onMouseLeave={() => setHoverHint('')}
            >
              <LinkBrokenIcon />
            </button>
          )}

          {/* 程式碼區塊切換按鈕 */}
          <button
            onClick={() => handleFormat('codeBlock')}
            className={`toolbar-button ${editor?.isActive('codeBlock') ? 'active' : ''}`}
            onMouseEnter={() => setHoverHint(`『${getModifierKey()}』+『${getSecondModifierKey()}』+『C』${t('codeBlock')}`)}
            onMouseLeave={() => setHoverHint('')}
          >
            <CodeBlockIcon />
          </button>
        </div>{/* 關閉 toolbar-scroll-wrapper */}
      </div>
      <CustomHint show={showFloatingToolbar && !!hoverHint}>
        {hoverHint}
      </CustomHint>
    </>
  );
}

export default NoteEditorToolbarAndMenu; 