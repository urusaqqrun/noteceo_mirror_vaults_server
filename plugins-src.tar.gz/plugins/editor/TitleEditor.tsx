import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useTheme } from '../../setting/ThemeProvider';
import CorrectIcon from '../../../assets/icon_correct.svg?react';
import RefreshDark from '../../../assets/icon_refresh_dark_24@2x.png';
import RefreshLight from '../../../assets/icon_refresh_light_24@2x.png';
import './TitleEditor.css';

// ===== TitleEditor Props =====

export interface TitleEditorProps {
  id: string | null;
  title: string;
  aiTitle: string | null;
  isReadOnly: boolean;
  isRefreshingAiTitle: boolean;
  onTitleChange: (title: string) => void;
  onAiTitleConfirm: () => void;
  onRefreshAiTitle: () => Promise<void>;
}

// ===== 純 UI 組件 =====

function TitleEditor({
  id,
  title,
  aiTitle,
  isReadOnly,
  isRefreshingAiTitle,
  onTitleChange,
  onAiTitleConfirm,
  onRefreshAiTitle,
}: TitleEditorProps) {
  const { t } = useTranslation();
  const theme = useTheme();

  // 本地 title 狀態（debounce 用）
  const [localTitle, setLocalTitle] = useState('');
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isShowingAiTitle = !!aiTitle && !title;

  // 同步外部 title/aiTitle 到本地
  useEffect(() => {
    setLocalTitle(isShowingAiTitle ? aiTitle! : title);
  }, [title, aiTitle, isShowingAiTitle]);

  // 清理 debounce
  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  // textarea 高度自適應
  useEffect(() => {
    const el = document.querySelector('.editor-title');
    if (el) {
      (el as HTMLElement).style.height = 'auto';
      (el as HTMLElement).style.height = `${el.scrollHeight}px`;
    }
  }, [localTitle]);

  // 使用者輸入 → debounce → 通知 hook
  const handleTitleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newTitle = e.target.value;
    setLocalTitle(newTitle);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      debounceRef.current = null;
      onTitleChange(newTitle);
    }, 300);
  };

  // 貼上去格式
  const handleTitlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const { stripContent } = (window as any).textUtils;
    const rawText = e.clipboardData.getData('text/html') || e.clipboardData.getData('text/plain');
    const text = stripContent(rawText);
    document.execCommand('insertText', false, text);
  };

  // IME 組字
  const handleCompositionStart = (e: React.CompositionEvent) => {
    (e.target as HTMLElement).setAttribute('data-composing', 'true');
  };
  const handleCompositionEnd = (e: React.CompositionEvent) => {
    (e.target as HTMLElement).setAttribute('data-composing', 'false');
  };

  // 按鈕防止 textarea blur
  const handleButtonMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  return (
    <div className="editor-title-wrapper">
      <textarea
        className={`editor-title ${isShowingAiTitle ? 'ai-title with-ai-buttons' : ''}`}
        value={localTitle}
        onChange={handleTitleChange}
        onPaste={handleTitlePaste}
        onCompositionStart={handleCompositionStart}
        onCompositionEnd={handleCompositionEnd}
        data-composing="false"
        placeholder={t('titlePlaceholder')}
        rows={1}
      />
      <div className={`editor-title-buttons ${isShowingAiTitle ? 'ai-mode' : 'hover-mode'}`}>
        {!isReadOnly && (
          <button
            className={`editor-title-button-refresh ${isRefreshingAiTitle ? 'refreshing' : ''}`}
            title={t('regenerateAITitle')}
            onMouseDown={handleButtonMouseDown}
            onClick={onRefreshAiTitle}
          >
            <img src={theme.mode === 'dark' ? RefreshDark : RefreshLight} alt="refresh" />
          </button>
        )}
        {isShowingAiTitle && (
          <button
            className="editor-title-button-confirm"
            title={t('confirmAITitle')}
            onMouseDown={handleButtonMouseDown}
            onClick={onAiTitleConfirm}
          >
            <CorrectIcon />
          </button>
        )}
      </div>
    </div>
  );
}

export default TitleEditor;
