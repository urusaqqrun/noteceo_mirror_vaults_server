import React, { useEffect, useCallback, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import './NoteEditorMenu.css';
import ContentIcon from '../../../assets/icon_text_content_24.svg?react';
import TitleLevel1Icon from '../../../assets/icon_title_level1_24.svg?react';
import TitleLevel2Icon from '../../../assets/icon_title_level2_24.svg?react';
import TitleLevel3Icon from '../../../assets/icon_title_level3_24.svg?react';
import ListIcon from '../../../assets/icon_level_24.svg?react';
import LinkIcon from '../../../assets/icon_link_24.svg?react';
import BulletListIcon from '../../../assets/icon_level_24.svg?react';
import NumberListIcon from '../../../assets/icon_numberlist_24.svg?react';
import CheckListIcon from '../../../assets/icon_checklist_black_24.svg?react';
import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';
import SearchIcon from '../../../assets/icon_search_24.svg?react';
import RefreshDark from '../../../assets/bk_refresh_dark.svg?react';
import RefreshLight from '../../../assets/bk_refresh_light.svg?react';
import CopyNoteIcon from '../../../assets/copy_note.svg?react';
import HistoryIcon from '../../../assets/history.svg?react';
import PhotoAddIcon from '../../../assets/icon_photo_add_24.svg?react';
import CodeBlockIcon from '../../../assets/icon_code_24.svg?react';
import RowHeadIcon from '../../../assets/icon_sheet_row_head_24.svg?react';
import ColumnHeadIcon from '../../../assets/icon_sheet_column_head_24.svg?react';
import RowAddIcon from '../../../assets/icon_sheet_row_add_24.svg?react';
import ColumnAddIcon from '../../../assets/icon_sheet_column_add_24.svg?react';
import RowDeleteIcon from '../../../assets/icon_sheet_row_delete_24.svg?react';
import ColumnDeleteIcon from '../../../assets/icon_sheet_column_delete_24.svg?react';

import { useDialogStore } from '../../../Store/dialogStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { eventBus } from '../../../Store/eventBus';
import { useItemStore } from '../../../Store/itemStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { useTheme } from '../../setting/ThemeProvider';
import { useEditorRefStore } from './editorStore';

// 添加菜单组件
export function AddMenuContainer({
  showMenu,
  onFontSizeSelect,
  handleListChange,
  handleButtonMouseDown,
  menuClassName = '',
  floating = false,
  onClose,
  onAddImage,
  onAddLink,
  onAddTable,
  onAddCodeBlock,
}) {
  const { t } = useTranslation();
  const handleEscKey = useCallback((event) => {

    if (event.detail.key === 'Escape' && showMenu && onClose) {
      onClose();
    }
  }, [showMenu, onClose]);

  useEffect(() => {
    if (showMenu) {
      document.addEventListener('menu-key', handleEscKey);
    }

    return () => {
      document.removeEventListener('menu-key', handleEscKey);
    };
  }, [showMenu, handleEscKey]);

  return (
    <div className="add-menu-container">
      <div className={`add-menu ${floating ? 'floating' : ''} ${showMenu ? 'active' : ''} ${menuClassName}`}>
        <button
          className="add-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('content')}
        >
          <ContentIcon />
          <span>{t('bodyText')}</span>
          <span className="add-menu-shortcut"></span>
        </button>
        <button
          className="add-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('h1')}
        >
          <TitleLevel1Icon />
          <span>{t('largeHeading')}</span>
          <span className="add-menu-shortcut">#</span>
        </button>
        <button
          className="add-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('h2')}
        >
          <TitleLevel2Icon />
          <span>{t('mediumHeading')}</span>
          <span className="add-menu-shortcut">##</span>
        </button>
        <button
          className="add-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('h3')}
        >
          <TitleLevel3Icon />
          <span>{t('smallHeading')}</span>
          <span className="add-menu-shortcut">###</span>
        </button>
        <button
          className="add-menu-item"
          onClick={() => handleListChange('bulletList')}
          onMouseDown={handleButtonMouseDown}
        >
          <BulletListIcon />
          <span>{t('bulletList')}</span>
          <span className="add-menu-shortcut">-</span>
        </button>
        <button
          className="add-menu-item"
          onClick={() => handleListChange('orderedList')}
          onMouseDown={handleButtonMouseDown}
        >
          <NumberListIcon />
          <span>{t('numberedList')}</span>
          <span className="add-menu-shortcut">1.</span>
        </button>
        <button
          className="add-menu-item"
          onClick={() => handleListChange('taskList')}
          onMouseDown={handleButtonMouseDown}
        >
          <CheckListIcon />
          <span>{t('checklist')}</span>
          <span className="add-menu-shortcut">[]</span>
        </button>
        <button
          className="add-menu-item"
          onClick={onAddImage}
          onMouseDown={handleButtonMouseDown}
        >
          <PhotoAddIcon />
          <span>{t('addImage')}</span>
          <span className="add-menu-shortcut"></span>
        </button>
        <button
          className="add-menu-item"
          onClick={onAddLink}
          onMouseDown={handleButtonMouseDown}
        >
          <LinkIcon />
          <span>{t('addLink')}</span>
          <span className="add-menu-shortcut"></span>
        </button>
        <button
          className="add-menu-item"
          onClick={(e) => onAddTable(e)}
          onMouseDown={handleButtonMouseDown}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" transform="scale(0.9)">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" stroke="currentColor" strokeWidth="2" fill="none" />
            <line x1="9" y1="3" x2="9" y2="21" stroke="currentColor" strokeWidth="2" />
            <line x1="15" y1="3" x2="15" y2="21" stroke="currentColor" strokeWidth="2" />
            <line x1="3" y1="9" x2="21" y2="9" stroke="currentColor" strokeWidth="2" />
            <line x1="3" y1="15" x2="21" y2="15" stroke="currentColor" strokeWidth="2" />
          </svg>
          <span>{t('addTable')}</span>
          <span className="add-menu-shortcut"></span>
        </button>
        <button
          className="add-menu-item"
          onClick={onAddCodeBlock}
          onMouseDown={handleButtonMouseDown}
        >
          <CodeBlockIcon />
          <span>{t('codeBlock')}</span>
          <span className="add-menu-shortcut"></span>
        </button>
      </div>
    </div>
  );
}

// 字体菜单组件
export function FontMenu({
  showMenu,
  onMenuClick,
  onFontSizeSelect,
  handleButtonMouseDown,
  menuClassName = '',
  buttonClassName = '',
  floating = false,
  onMouseEnter,
  onMouseLeave
}) {
  const { t } = useTranslation();
  return (
    <div className="font-menu-container">
      <button
        className={`${buttonClassName || 'menu-button'}`}
        onClick={onMenuClick}
        onMouseDown={handleButtonMouseDown}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
      >
        <ContentIcon />
      </button>
      <div className={`font-menu ${floating ? 'floating' : ''} ${showMenu ? 'active' : ''} ${menuClassName}`}>
        <button
          className="font-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('content')}
        >
          <ContentIcon />
          <span>{t('bodyText')}</span>
        </button>
        <button
          className="font-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('h1')}
        >
          <TitleLevel1Icon />
          <span>{t('largeHeading')}</span>
        </button>
        <button
          className="font-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('h2')}
        >
          <TitleLevel2Icon />
          <span>{t('mediumHeading')}</span>
        </button>
        <button
          className="font-menu-item"
          onMouseDown={handleButtonMouseDown}
          onClick={() => onFontSizeSelect('h3')}
        >
          <TitleLevel3Icon />
          <span>{t('smallHeading')}</span>
        </button>
      </div>
    </div>
  );
}

// 列表菜单组件
export function ListMenu({
  showMenu,
  onMenuClick,
  handleListChange,
  handleButtonMouseDown,
  menuClassName = '',
  buttonClassName = '',
  floating = false,
  onMouseEnter,
  onMouseLeave
}) {
  const { t } = useTranslation();
  return (
    <div className="list-menu-container">
      <button
        className={`${buttonClassName || 'menu-button'}`}
        onClick={onMenuClick}
        onMouseDown={handleButtonMouseDown}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
      >
        <ListIcon />
      </button>
      <div className={`list-menu ${floating ? 'floating' : ''} ${showMenu ? 'active' : ''} ${menuClassName}`}>
        <button
          className="list-menu-item"
          onClick={() => handleListChange('bulletList')}
          onMouseDown={handleButtonMouseDown}
        >
          <BulletListIcon />
          <span>{t('bulletList')}</span>
        </button>
        <button
          className="list-menu-item"
          onClick={() => handleListChange('orderedList')}
          onMouseDown={handleButtonMouseDown}
        >
          <NumberListIcon />
          <span>{t('numberedList')}</span>
        </button>
        <button
          className="list-menu-item"
          onClick={() => handleListChange('taskList')}
          onMouseDown={handleButtonMouseDown}
        >
          <CheckListIcon />
          <span>{t('checklist')}</span>
        </button>
      </div>
    </div>
  );
}

// TopbarMoreMenu 组件
export function TopbarMoreMenu({
  showMenu,
  onMenuClick,
  isNote,
  onSearch,
  onDelete,
  onRefresh,
  handleButtonMouseDown,
  menuClassName = '',
  buttonClassName = '',
  floating = false,
  onClose,
  noteId,
  onCopyNoteLink,
  onCopy,
  isInTrash = false,
}) {
  const { t } = useTranslation();
  const theme = useTheme();
  const handleEscKey = useCallback((event) => {
    if (event.detail.key === 'Escape' && showMenu && onClose) {
      onClose();
    }
  }, [showMenu, onClose]);

  useEffect(() => {
    if (showMenu) {
      document.addEventListener('menu-key', handleEscKey);
    }

    return () => {
      document.removeEventListener('menu-key', handleEscKey);
    };
  }, [showMenu, handleEscKey]);

  const handleCopyNoteLink = () => {
    if (noteId && onCopyNoteLink) {
      onCopyNoteLink(noteId);
    } else if (noteId) {
      const link = `cubelv://note/${noteId}`;
      navigator.clipboard.writeText(link)
        .then(() => {

        })
        .catch(err => {
          console.error('複製連結失敗:', err);
        });
    } else {
      console.error('無法複製連結：筆記 ID 未定義');
    }

    if (onClose) {
      onClose();
    }
  };

  return (
    <div className="more-menu-container">
      <button
        className={`${buttonClassName || 'menu-button'}`}
        onClick={onMenuClick}
        onMouseDown={handleButtonMouseDown}
      >
        <MoreIcon />
      </button>
      <div className={`more-menu ${floating ? 'floating' : ''} ${showMenu ? 'active' : ''} ${menuClassName}`}>
        {/* 重新整理：只在筆記模式顯示 */}
        {isNote && (
          <button
            className="more-menu-item rainbow-text"
            onClick={onRefresh}
            onMouseDown={handleButtonMouseDown}
          >
            {theme.mode === 'dark' ? <RefreshDark /> : <RefreshLight />}
            <span>{t('refresh')}</span>
          </button>
        )}
        <button
          className="more-menu-item"
          onClick={onCopy}
          onMouseDown={handleButtonMouseDown}
        >
          <CopyNoteIcon />
          <span>{t('copyItem')}</span>
        </button>
        {/* 複製筆記連結：只在筆記模式顯示 */}
        {isNote && noteId && (
          <button
            className="more-menu-item"
            onClick={handleCopyNoteLink}
            onMouseDown={handleButtonMouseDown}
          >
            <LinkIcon />
            <span>{t('copyNoteLink')}</span>
          </button>
        )}
        <button
          className="more-menu-item"
          onClick={onSearch}
          onMouseDown={handleButtonMouseDown}
        >
          <SearchIcon />
          <span>{isNote ? t('findInNote') : t('findInTodo')}</span>
        </button>
        <button
          className="more-menu-item error"
          onClick={onDelete}
          onMouseDown={handleButtonMouseDown}
        >
          <DeleteIcon />
          <span>{isNote ? (isInTrash ? t('deleteNote') : t('moveToTrash')) : t('deleteTodo')}</span>
        </button>
      </div>
    </div>
  );
}


// 表格拖曳手把點擊選單組件
export function TableDragHandleClickMenu({
  showMenu,
  position,
  tablePos,
  tableElement,
  editor,
  onClose
}) {
  const { t } = useTranslation();
  const theme = useTheme();

  // 關閉菜單
  const closeMenu = () => {
    if (onClose) {
      onClose();
    }
  };

  // 點擊外部關閉菜單
  const handleClickOutside = useCallback((e) => {
    if (showMenu) {
      const menuElement = document.querySelector('.table-drag-handle-click-menu');
      if (menuElement && !menuElement.contains(e.target)) {
        closeMenu();
      }
    }
  }, [showMenu]);

  // ESC 鍵關閉菜單
  const handleEscKey = useCallback((event) => {
    if (event.detail.key === 'Escape' && showMenu) {
      closeMenu();
    }
  }, [showMenu]);

  // 監聽事件
  useEffect(() => {
    if (showMenu) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('menu-key', handleEscKey);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('menu-key', handleEscKey);
    };
  }, [showMenu, handleClickOutside, handleEscKey]);

  // 解析 tablePos 來判斷是列還是欄
  const isRow = tablePos && typeof tablePos === 'string' && tablePos.startsWith('列-');
  const isColumn = tablePos && typeof tablePos === 'string' && tablePos.startsWith('欄-');
  const index = (tablePos && typeof tablePos === 'string') ? parseInt(tablePos.split('-')[1]) || 0 : 0;
  const isFirstIndex = index === 0; // 檢查是否為第一列或第一欄

  // 檢查當前列/欄是否為標題
  const [isCurrentlyHeader, setIsCurrentlyHeader] = useState(false);

  // 檢查表格是否有首列的函數
  const checkTableHasHeaderRow = (table) => {
    if (!table || !table.rows[0]) return false;
    const firstRow = table.rows[0];
    for (let i = 0; i < firstRow.cells.length; i++) {
      if (firstRow.cells[i].tagName.toLowerCase() !== 'th') {
        return false;
      }
    }
    return firstRow.cells.length > 0;
  };

  // 檢查表格是否有首欄的函數
  const checkTableHasHeaderColumn = (table) => {
    if (!table || table.rows.length === 0) return false;
    for (let rowIdx = 0; rowIdx < table.rows.length; rowIdx++) {
      const firstCell = table.rows[rowIdx].cells[0];
      if (!firstCell || firstCell.tagName.toLowerCase() !== 'th') {
        return false;
      }
    }
    return true;
  };

  // 檢測當前列/欄是否為標題的函數
  const checkIfHeader = useCallback(() => {
    if (!editor || !tableElement) return false;

    try {
      const table = tableElement;

      if (isRow && index < table.rows.length) {
        // 檢查整列是否都是標題儲存格
        const targetRow = table.rows[index];
        if (!targetRow) return false;

        // 檢查該列的所有儲存格是否都是 th
        for (let i = 0; i < targetRow.cells.length; i++) {
          if (targetRow.cells[i].tagName.toLowerCase() !== 'th') {
            return false;
          }
        }
        return targetRow.cells.length > 0; // 確保有儲存格存在

      } else if (!isRow && table.rows.length > 0 && index < table.rows[0].cells.length) {
        // 檢查整欄是否都是標題儲存格
        for (let rowIdx = 0; rowIdx < table.rows.length; rowIdx++) {
          const cell = table.rows[rowIdx].cells[index];
          if (!cell || cell.tagName.toLowerCase() !== 'th') {
            return false;
          }
        }
        return table.rows.length > 0; // 確保有列存在
      }
    } catch (error) {
      console.error('檢查標題狀態失敗:', error);
    }
    return false;
  }, [editor, tableElement, isRow, index]);

  // 當選單顯示時檢查標題狀態
  useEffect(() => {
    if (showMenu) {
      setIsCurrentlyHeader(checkIfHeader());
    }
  }, [showMenu, checkIfHeader]);

  // 選單項目處理函數
  const handleSetAsFirst = () => {
    const actionText = isCurrentlyHeader
      ? `取消設為首${isRow ? '列' : '欄'}`
      : `設為首${isRow ? '列' : '欄'}`;

    if (!editor || !tableElement) {
      closeMenu();
      return;
    }

    try {
      // 使用傳遞的表格元素
      const targetTable = tableElement;
      let targetCell = null;

      if (isRow && index < targetTable.rows.length) {
        targetCell = targetTable.rows[index]?.cells[0];
      } else if (!isRow && targetTable.rows[0] && index < targetTable.rows[0].cells.length) {
        targetCell = targetTable.rows[0]?.cells[index];
      }

      if (targetCell && targetTable) {
        // 設置選區到目標儲存格
        const cellPos = editor.view.posAtDOM(targetCell, 0);
        editor.chain().focus().setTextSelection(cellPos).run();

        // 執行設為標題操作（toggle 會自動處理設置/取消）
        if (isRow) {
          editor.chain().focus().toggleHeaderRow().run();
        } else {
          editor.chain().focus().toggleHeaderColumn().run();
        }
      }
    } catch (error) {
      console.error('設為/取消首行/列失敗:', error);
    }

    closeMenu();
  };

  const handleInsertBefore = () => {

    if (!editor || !tableElement) {
      closeMenu();
      return;
    }

    try {
      // 使用傳遞的表格元素
      const targetTable = tableElement;
      let targetCell = null;

      if (isRow && index < targetTable.rows.length) {
        targetCell = targetTable.rows[index]?.cells[0];
      } else if (!isRow && targetTable.rows[0] && index < targetTable.rows[0].cells.length) {
        targetCell = targetTable.rows[0]?.cells[index];
      }

      if (targetCell && targetTable) {
        // 1. 檢查是否有首列或首欄
        const hasHeaderRow = checkTableHasHeaderRow(targetTable);
        const hasHeaderColumn = checkTableHasHeaderColumn(targetTable);

        // 設置選區到目標儲存格
        const cellPos = editor.view.posAtDOM(targetCell, 0);
        editor.chain().focus().setTextSelection(cellPos).run();

        // 2. 若有首列/首欄，先取消
        if (isRow && hasHeaderRow && index === 0) {
          // 在首列前插入，需要先取消首列
          editor.chain().focus().toggleHeaderRow().run();
        }
        if (!isRow && hasHeaderColumn && index === 0) {
          // 在首欄前插入，需要先取消首欄
          editor.chain().focus().toggleHeaderColumn().run();
        }

        // 3. 執行插入操作
        if (isRow) {
          editor.chain().focus().addRowBefore().run();
        } else {
          editor.chain().focus().addColumnBefore().run();
        }

        // 4. 若原本有首列/欄，將 index 0 再改回首列/欄
        setTimeout(() => {
          if (isRow && hasHeaderRow) {
            // 設置選區到新的第一列第一個儲存格
            const newFirstCell = targetTable.rows[0]?.cells[0];
            if (newFirstCell) {
              const newCellPos = editor.view.posAtDOM(newFirstCell, 0);
              editor.chain().focus().setTextSelection(newCellPos).toggleHeaderRow().run();
            }
          }
          if (!isRow && hasHeaderColumn) {
            // 設置選區到新的第一欄第一個儲存格
            const newFirstCell = targetTable.rows[0]?.cells[0];
            if (newFirstCell) {
              const newCellPos = editor.view.posAtDOM(newFirstCell, 0);
              editor.chain().focus().setTextSelection(newCellPos).toggleHeaderColumn().run();
            }
          }
        }, 50); // 稍微延遲確保插入操作完成
      }
    } catch (error) {
      console.error('插入表格列/欄失敗:', error);
    }

    closeMenu();
  };

  const handleInsertAfter = () => {

    if (!editor || !tableElement) {
      closeMenu();
      return;
    }

    try {
      // 使用傳遞的表格元素
      const targetTable = tableElement;
      let targetCell = null;

      if (isRow && index < targetTable.rows.length) {
        targetCell = targetTable.rows[index]?.cells[0];
      } else if (!isRow && targetTable.rows[0] && index < targetTable.rows[0].cells.length) {
        targetCell = targetTable.rows[0]?.cells[index];
      }

      if (targetCell && targetTable) {
        // 1. 檢查是否有首列或首欄
        const hasHeaderRow = checkTableHasHeaderRow(targetTable);
        const hasHeaderColumn = checkTableHasHeaderColumn(targetTable);

        // 設置選區到目標儲存格
        const cellPos = editor.view.posAtDOM(targetCell, 0);
        editor.chain().focus().setTextSelection(cellPos).run();

        // 2. 對於 insertAfter，不需要預先取消首列/欄，因為不會影響到 index 0

        // 3. 執行插入操作
        if (isRow) {
          editor.chain().focus().addRowAfter().run();
        } else {
          editor.chain().focus().addColumnAfter().run();
        }

        // 4. insertAfter 不需要恢復首列/欄，因為 index 0 的位置沒有改變
      }
    } catch (error) {
      console.error('插入表格列/欄失敗:', error);
    }

    closeMenu();
  };

  const handleDelete = () => {

    if (!editor || !tableElement) {
      closeMenu();
      return;
    }

    try {
      // 使用傳遞的表格元素
      const targetTable = tableElement;
      let targetCell = null;

      if (isRow && index < targetTable.rows.length) {
        targetCell = targetTable.rows[index]?.cells[0];
      } else if (!isRow && targetTable.rows[0] && index < targetTable.rows[0].cells.length) {
        targetCell = targetTable.rows[0]?.cells[index];
      }

      if (targetCell && targetTable) {
        // 設置選區到目標儲存格
        const cellPos = editor.view.posAtDOM(targetCell, 0);
        editor.chain().focus().setTextSelection(cellPos).run();

        // 執行刪除操作
        if (isRow) {
          editor.chain().focus().deleteRow().run();
        } else {
          editor.chain().focus().deleteColumn().run();
        }
      }
    } catch (error) {
      console.error('刪除表格列/欄失敗:', error);
    }

    closeMenu();
  };

  const handleDeleteTable = () => {

    if (!editor || !tableElement) {
      closeMenu();
      return;
    }

    try {
      // 使用傳遞的表格元素
      const table = tableElement;

      if (table) {
        // 設置選區到表格的第一個儲存格
        const firstCell = table.querySelector('td, th');
        if (firstCell) {
          const cellPos = editor.view.posAtDOM(firstCell, 0);
          editor.chain().focus().setTextSelection(cellPos).run();

          // 刪除整個表格
          editor.chain().focus().deleteTable().run();
        }
      }
    } catch (error) {
      console.error('刪除表格失敗:', error);
    }

    closeMenu();
  };

  return showMenu ? (
    <div
      className="table-drag-handle-click-menu right-click-menu"
      style={{
        position: 'fixed',
        top: position.y,
        left: position.x,
      }}
      onClick={(e) => e.stopPropagation()}
      tabIndex={-1}
    >
      {/* 第一組：設為首行/首列（只有在 index 0 時顯示） */}
      {isFirstIndex && (
        <div className="right-click-menu-group">
          <button
            className="right-click-menu-item"
            onClick={handleSetAsFirst}
            onMouseDown={(e) => e.preventDefault()}
            tabIndex={-1}
          >
            {isRow ? <RowHeadIcon /> : <ColumnHeadIcon />}
            <span>{isCurrentlyHeader ? t('cancelSetAsFirst') : t('setAsFirst')}{isRow ? t('row') : t('column')}</span>
          </button>
        </div>
      )}

      {/* 第二組：插入行/列 */}
      <div className="right-click-menu-group">
        <button
          className="right-click-menu-item"
          onClick={handleInsertBefore}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          {isRow ?
            <RowAddIcon style={{ transform: 'rotate(180deg)' }} /> :
            <ColumnAddIcon style={{ transform: 'rotate(180deg)' }} />
          }
          <span>{isRow ? t('insertRowUp') : t('insertColumnLeft')}</span>
        </button>
        <button
          className="right-click-menu-item"
          onClick={handleInsertAfter}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          {isRow ? <RowAddIcon /> : <ColumnAddIcon />}
          <span>{isRow ? t('insertRowDown') : t('insertColumnRight')}</span>
        </button>
      </div>

      {/* 第三組：刪除行/列 */}
      <div className="right-click-menu-group">
        <button
          className={`right-click-menu-item ${theme.mode === 'dark' ? 'error-dark' : 'error-light'}`}
          onClick={handleDelete}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          {isRow ? <RowDeleteIcon /> : <ColumnDeleteIcon />}
          <span>{isRow ? t('deleteThisRow') : t('deleteThisColumn')}</span>
        </button>
      </div>

      {/* 第四組：刪除整個表格 */}
      <div className="right-click-menu-group">
        <button
          className={`right-click-menu-item ${theme.mode === 'dark' ? 'error-dark' : 'error-light'}`}
          onClick={handleDeleteTable}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <DeleteIcon />
          <span>{t('deleteTable')}</span>
        </button>
      </div>
    </div>
  ) : null;
}

// 添加 EditorRightClickMenu 组件
export function EditorRightClickMenu({ editor, historyManager }) {
  const { t } = useTranslation();
  // 內部狀態管理
  const [showMenu, setShowMenu] = useState(false);
  const [position, setPosition] = useState<{ x: number; y: number; growRight?: boolean; growDown?: boolean }>({ x: 0, y: 0 });

  // Store 引用
  const setTempHint = useTempHintStore(state => state.setTempHint);

  // 根據平台獲取修飾鍵文字
  const getModifierKey = () => {
    return window?.electron?.platform === 'win32' ? 'Ctrl' : '⌘';
  };

  // 根據平台獲取 Shift 鍵文字
  const getShiftKey = () => {
    return window?.electron?.platform === 'win32' ? 'Shift' : '⇧';
  };

  // 根據平台獲取刪除鍵文字
  const getDeleteKey = () => {
    return window?.electron?.platform === 'win32' ? 'Ctrl+Del' : '⌘⌫';
  };

  // 關閉菜單
  const closeMenu = () => {
    setShowMenu(false);
  };

  // 處理各種編輯器操作
  const handleUndo = () => {
    historyManager.undo();
    closeMenu();
  };

  const handleRedo = () => {
    historyManager.redo();
    closeMenu();
  };

  const handleCut = () => {

    const cutEvent = new ClipboardEvent('cut', {
      bubbles: true,
      cancelable: true,
    });
    editor?.commands.focus();
    editor?.view.dom.dispatchEvent(cutEvent);
    closeMenu();
  };

  const handleCopy = () => {

    const copyEvent = new ClipboardEvent('copy', {
      bubbles: true,
      cancelable: true,
    });
    editor?.commands.focus();
    editor?.view.dom.dispatchEvent(copyEvent);
    closeMenu();
  };

  const handlePaste = () => {

    const pasteEvent = new ClipboardEvent('paste', {
      bubbles: true,
      cancelable: true,
    });
    editor?.commands.focus();
    editor?.view.dom.dispatchEvent(pasteEvent);
    closeMenu();
  };

  const handleDelete = () => {
    editor?.chain().focus().deleteSelection().run();
    closeMenu();
  };

  const handleSearch = () => {
    closeMenu();

    // 獲取選中的文本作為初始搜索文本
    let selectedText = '';
    if (editor) {
      const { from, to } = editor.state.selection;
      selectedText = editor.state.doc.textBetween(from, to).trim();
    }

    // 使用 store 打開搜索對話框
    useDialogStore.getState().open('searchReplace', { searchText: selectedText, editor: useEditorRefStore.getState().editorRef });
  };

  const handleRefresh = async () => {
    closeMenu();

    const _lastId = useSelectedItemsStore.getState().path.at(-1)?.id;
    const selectedNote = _lastId
      ? (await (window as any).electronAPI.getItem(_lastId) ?? null)
      : null;

    if (!selectedNote?.content) {

      return;
    }

    try {
      // 顯示加載提示
      setTempHint(t('refreshingNote'));

      // 調用 mergeTextMulti API
      const { mergeTextMulti } = await import('../note/ai/noteAI');
      const result = await mergeTextMulti([selectedNote.content], '');

      if (result?.content) {
        // 更新筆記內容
        const updatedNote = {
          ...selectedNote,
          content: result.content
        };
        const storeItem = useItemStore.getState().getById(updatedNote.id);
        if (storeItem) {
          await useItemStore.getState().upsertItem(
            { ...storeItem, content: result.content, updatedAt: Date.now() } as any,
            { needSync: true }
          );
        }

        // 更新編輯器內容
        setTimeout(() => {
          eventBus.emit('editor:force-reload');
        }, 50);

        setTempHint(t('refreshComplete'));
      } else {
        console.error('重新整理失敗：API 沒有返回內容');
        setTempHint(t('refreshFailed'));
      }
    } catch (error) {
      console.error('重新整理筆記時發生錯誤:', error);
      setTempHint(t('refreshFailed'));
    }
  };

  // 處理右鍵菜單
  const handleContextMenu = useCallback((e) => {
    if (!editor) return;

    e.preventDefault();
    // 檢查點擊是否在當前編輯器區域內
    const currentEditorContent = editor.view?.dom;
    if (currentEditorContent && currentEditorContent.contains(e.target)) {
      // 获取当前缩放比例
      const computedScale = getComputedStyle(document.documentElement)
        .getPropertyValue('--content-scale')
        .trim();
      const SCALE = parseFloat(computedScale) || 1;

      // 右键菜单的長寬
      const MENU_WIDTH = 160;
      const MENU_HEIGHT = 250;

      // 将点击位置转换为未缩放的坐标
      const unscaledX = e.clientX / SCALE;
      const unscaledY = e.clientY / SCALE;

      // 計算視窗中點並以此判斷生長方向
      const viewportMidX = (window.innerWidth / SCALE) / 2;
      const viewportMidY = (window.innerHeight / SCALE) / 2;

      const growRight = unscaledX < viewportMidX;
      const growDown = unscaledY < viewportMidY;

      // 根据生长方向调整位置
      let adjustedX = unscaledX;
      let adjustedY = unscaledY;

      // 如果向左生长，需要减去菜单宽度
      if (!growRight) {
        adjustedX = unscaledX - MENU_WIDTH;
      }

      // 如果向上生长，需要减去菜单高度
      if (!growDown) {
        adjustedY = unscaledY - MENU_HEIGHT - 14;
      } else { // 向下
        adjustedY = unscaledY + 14;
      }

      setPosition({
        x: adjustedX,
        y: adjustedY,
        growRight,
        growDown
      });
      setShowMenu(true);
    }
  }, [editor]);

  // 點擊外部關閉菜單
  const handleClickOutside = useCallback((e) => {
    if (showMenu) {
      const menuElement = document.querySelector('.right-click-menu');
      if (menuElement && !menuElement.contains(e.target)) {
        closeMenu();
      }
    }
  }, [showMenu]);

  // ESC 鍵關閉菜單
  const handleEscKey = useCallback((event) => {
    if (event.detail.key === 'Escape' && showMenu) {
      closeMenu();
    }
  }, [showMenu]);

  // 監聽事件
  useEffect(() => {
    if (!editor) return;

    // 找到當前編輯器的容器
    const currentNoteEditor = editor.view?.dom?.closest('.note-editor');
    if (currentNoteEditor) {
      currentNoteEditor.addEventListener('contextmenu', handleContextMenu);
    }

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('menu-key', handleEscKey);

    return () => {
      if (currentNoteEditor) {
        currentNoteEditor.removeEventListener('contextmenu', handleContextMenu);
      }
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('menu-key', handleEscKey);
    };
  }, [editor, handleContextMenu, handleClickOutside, handleEscKey]);

  return showMenu ? (
    <div
      className="right-click-menu"
      style={{
        position: 'fixed',
        top: position.y,
        left: position.x,
      }}
      tabIndex={-1}
    >
      {/* 第一組：重新整理 */}
      <div className="right-click-menu-group">
        <button
          className="right-click-menu-item rainbow-text"
          onClick={handleRefresh}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <span>{t('refresh')}</span>
        </button>
      </div>

      {/* 第二組：復原 / 取消復原 */}
      <div className="right-click-menu-group">
        <button
          className={`right-click-menu-item ${!historyManager.canUndo() ? 'disabled' : ''}`}
          onClick={handleUndo}
          onMouseDown={(e) => e.preventDefault()}
          disabled={!historyManager.canUndo()}
          tabIndex={-1}
        >
          <span>{t('undo')}</span>
          <span className="shortcut">{getModifierKey()} + Z</span>
        </button>
        <button
          className={`right-click-menu-item ${!historyManager.canRedo() ? 'disabled' : ''}`}
          onClick={handleRedo}
          onMouseDown={(e) => e.preventDefault()}
          disabled={!historyManager.canRedo()}
          tabIndex={-1}
        >
          <span>{t('redo')}</span>
          <span className="shortcut">{window?.electron?.platform === 'win32' ? `${getModifierKey()} + Y` : `${getShiftKey()}${getModifierKey()}Z`}</span>
        </button>
      </div>

      {/* 第三組：尋找 */}
      <div className="right-click-menu-group">
        <button
          className="right-click-menu-item"
          onClick={handleSearch}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <span>{t('find')}</span>
          <span className="shortcut">{getModifierKey()} + F</span>
        </button>
      </div>

      {/* 第四組：剪下 / 複製 / 貼上 / 刪除 */}
      <div className="right-click-menu-group">
        <button
          className="right-click-menu-item"
          onClick={handleCut}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <span>{t('cut')}</span>
          <span className="shortcut">{getModifierKey()} + X</span>
        </button>
        <button
          className="right-click-menu-item"
          onClick={handleCopy}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <span>{t('copy')}</span>
          <span className="shortcut">{getModifierKey()} + C</span>
        </button>
        <button
          className="right-click-menu-item"
          onClick={handlePaste}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <span>{t('paste')}</span>
          <span className="shortcut">{getModifierKey()} + V</span>
        </button>
        <button
          className="right-click-menu-item"
          onClick={handleDelete}
          onMouseDown={(e) => e.preventDefault()}
          tabIndex={-1}
        >
          <span>{t('delete')}</span>
          <span className="shortcut">{getDeleteKey()}</span>
        </button>
      </div>
    </div>
  ) : null;
} 