import React, { useState } from 'react';
import './NoteEditorTable.css';

const TableSizeSelector = ({ onSelect, onClose }) => {
  const [hoveredCell, setHoveredCell] = useState({ row: 0, col: 0 });

  const handleCellHover = (row, col) => {
    setHoveredCell({ row, col });
  };

  const handleCellClick = (row, col) => {
    onSelect(row + 1, col + 1);
    onClose();
  };

  const renderCells = () => {
    const cells = [];
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const isActive = row <= hoveredCell.row && col <= hoveredCell.col;
        cells.push(
          <div
            key={`${row}-${col}`}
            className={`table-size-cell ${isActive ? 'active' : ''}`}
            onMouseEnter={() => handleCellHover(row, col)}
            onClick={() => handleCellClick(row, col)}
          />
        );
      }
    }
    return cells;
  };

  return (
    <div className="table-size-selector">
      {renderCells()}
      <div className="table-size-info">
        {hoveredCell.row + 1} × {hoveredCell.col + 1}
      </div>
    </div>
  );
};

export default TableSizeSelector; 
