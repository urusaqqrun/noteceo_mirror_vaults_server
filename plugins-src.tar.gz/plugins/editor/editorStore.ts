import { create } from 'zustand';

// ===== EditorRef Store =====
interface EditorRefState {
    editorRef: any;
    historyManager: any;
    historyVersion: number;
    isRecording: boolean;
    isUploading: boolean;
    setEditorRef: (editorRef: any) => void;
    setHistoryManager: (hm: any) => void;
    bumpHistoryVersion: () => void;
    setIsRecording: (recording: boolean) => void;
    setIsUploading: (uploading: boolean) => void;
}

export const useEditorRefStore = create<EditorRefState>((set) => ({
    editorRef: null,
    historyManager: null,
    historyVersion: 0,
    isRecording: false,
    isUploading: false,
    setEditorRef: (editorRef) => set({ editorRef }),
    setHistoryManager: (historyManager) => set({ historyManager }),
    bumpHistoryVersion: () => set((state) => ({ historyVersion: state.historyVersion + 1 })),
    setIsRecording: (isRecording) => set({ isRecording }),
    setIsUploading: (isUploading) => set({ isUploading }),
}));

// ===== FloatingToolbar Store =====
interface FloatingToolbarState {
    showFloatingToolbar: boolean;
    position: { top: number; left: number };
    activeColor: string;
    showFloatingFontMenu: boolean;
    showFloatingListMenu: boolean;
    showColorMenu: boolean;
    showUrlDialog: boolean;
    currentUrl: string;
    showToolbar: (position: { top: number; left: number }, activeColor?: string) => void;
    hideToolbar: () => void;
    setPosition: (position: { top: number; left: number }) => void;
    setFloatingFontMenu: (show: boolean) => void;
    setFloatingListMenu: (show: boolean) => void;
    setColorMenu: (show: boolean) => void;
    setActiveColor: (color: string) => void;
    setShowUrlDialog: (show: boolean) => void;
    setCurrentUrl: (url: string) => void;
    resetMenuState: () => void;
}

export const useFloatingToolbarStore = create<FloatingToolbarState>((set, get) => ({
    // 顯示狀態
    showFloatingToolbar: false,

    // 位置信息
    position: { top: 0, left: 0 },

    // 選中文字的顏色
    activeColor: 'var(--on)',

    // 子選單狀態
    showFloatingFontMenu: false,
    showFloatingListMenu: false,
    showColorMenu: false,

    // URL 對話框狀態
    showUrlDialog: false,
    currentUrl: 'https://',

    // 行為函數
    showToolbar: (position, activeColor = 'var(--on)') => {
        set({
            showFloatingToolbar: true,
            position,
            activeColor,
            // 重置所有子選單
            showFloatingFontMenu: false,
            showFloatingListMenu: false,
            showColorMenu: false
        });
    },

    hideToolbar: () => {
        set({
            showFloatingToolbar: false,
            showFloatingFontMenu: false,
            showFloatingListMenu: false,
            showColorMenu: false
        });
    },

    // 更新工具列位置
    setPosition: (position) => set({ position }),

    setFloatingFontMenu: (show) => set({ showFloatingFontMenu: show }),
    setFloatingListMenu: (show) => set({ showFloatingListMenu: show }),
    setColorMenu: (show) => set({ showColorMenu: show }),
    setActiveColor: (color) => set({ activeColor: color }),

    // URL 對話框控制
    setShowUrlDialog: (show) => set({ showUrlDialog: show }),
    setCurrentUrl: (url) => set({ currentUrl: url }),

    // 重置所有選單狀態
    resetMenuState: () => set({
        showFloatingFontMenu: false,
        showFloatingListMenu: false,
        showColorMenu: false
    })
}));

// ===== MaterialMode Store =====
interface MaterialModeState {
    showMaterialLibrary: boolean;
    isMaterialMode: boolean;
    isImageTextMode: boolean;
    isAIRewriteMode: boolean;
    keepImageModeOpen: boolean;
    materialID: string | null;
    selectedImageSrc: string | null;

    imageTextMap: Record<string, string>;
    setisMaterialMode: (show: boolean) => void;
    setisImageTextMode: (show: boolean) => void;
    setisAIRewriteMode: (show: boolean) => void;

    setKeepImageModeOpen: (show: boolean) => void;
    setMaterialID: (id: string | null) => void;
    setSelectedImageSrc: (src: string | null) => void;

    setImageTextMap: (map: Record<string, string>) => void;
    setShowMaterialLibrary: (show: boolean) => void;
}

export const useMaterialModeStore = create<MaterialModeState>((set) => ({
    showMaterialLibrary: false,
    isMaterialMode: false,
    isImageTextMode: false,
    isAIRewriteMode: false,
    keepImageModeOpen: false,
    materialID: null,
    selectedImageSrc: null,

    imageTextMap: {},

    setisMaterialMode: (show) => {
        set((state) => ({
            ...state,
            isMaterialMode: show,
            showMaterialLibrary: show || state.isImageTextMode || state.isAIRewriteMode || state.keepImageModeOpen
        }));
    },
    setisImageTextMode: (show) => {
        set((state) => ({
            ...state,
            isImageTextMode: show,
            showMaterialLibrary: state.isMaterialMode || show || state.isAIRewriteMode || state.keepImageModeOpen
        }));
    },
    setisAIRewriteMode: (show) => {
        set((state) => {
            const newIsMaterialMode = show ? false : state.isMaterialMode;
            const newIsImageTextMode = show ? false : state.isImageTextMode;

            return {
                ...state,
                isAIRewriteMode: show,
                isMaterialMode: newIsMaterialMode,
                isImageTextMode: newIsImageTextMode,
                showMaterialLibrary: newIsMaterialMode || newIsImageTextMode || show || state.keepImageModeOpen
            };
        });
    },

    setKeepImageModeOpen: (show) => {
        set((state) => ({
            ...state,
            keepImageModeOpen: show,
            showMaterialLibrary: state.isMaterialMode || state.isImageTextMode || state.isAIRewriteMode || show
        }));
    },
    setMaterialID: (id) => {
        set({ materialID: id });
    },
    setSelectedImageSrc: (src) => {
        set({ selectedImageSrc: src });
    },

    setImageTextMap: (map) => {
        set({ imageTextMap: map });
    },
    setShowMaterialLibrary: (show) => {
        set({ showMaterialLibrary: show });
    }
}));
