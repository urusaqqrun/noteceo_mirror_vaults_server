import React, { useState, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import './SetReminderTimeDialog.css';
import '../../common/BasicComponents.css';
import '../../common/CustomDialog.css';
import { useDialogStore } from '../../../Store/dialogStore';
import { CustomDialog } from '../../common/CustomDialog';

interface ReminderDialogData {
  item: { id: string; reminderTime?: number | null; offsetMinutes?: number | null; [key: string]: any };
  onConfirm: (itemId: string, reminderTime: number, offsetMinutes: number) => void;
  onCancel: (itemId: string) => void;
}

const SetReminderTimeDialog = () => {
  const { t } = useTranslation();
  const showReminderDialog = useDialogStore(state => state.dialogs['reminder']?.show);
  const dialogData = useDialogStore(state => state.dialogs['reminder']?.data) as ReminderDialogData | null;
  const closeReminderDialog = () => useDialogStore.getState().close('reminder');

  // 從 store.data 解構（呼叫方透過 open('reminder', { item, onConfirm, onCancel }) 傳入）
  const item = dialogData?.item ?? null;
  const onConfirm = dialogData?.onConfirm ?? null;
  const onCancel = dialogData?.onCancel ?? null;

  // 當前提醒時間和偏移分鐘數（從 item 讀取）
  const currentReminder = item?.reminderTime;
  const currentOffsetMinutes = item?.offsetMinutes;

  // 時間狀態
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [period, setPeriod] = useState('AM');
  const [hour, setHour] = useState(12);
  const [minute, setMinute] = useState(0);
  const [offsetMinutes, setOffsetMinutes] = useState(15);
  const [isOffsetEnabled, setIsOffsetEnabled] = useState(false);

  // 初始化時間狀態
  const initializeDateTime = useCallback(() => {
    const rawDate = currentReminder ? new Date(currentReminder) : new Date();
    const baseDate = isNaN(rawDate.getTime()) ? new Date() : rawDate;

    setSelectedDate(baseDate);
    setPeriod(baseDate.getHours() >= 12 ? 'PM' : 'AM');
    setHour(
      baseDate.getHours() > 12
        ? baseDate.getHours() - 12
        : baseDate.getHours() === 0
          ? 12
          : baseDate.getHours()
    );
    setMinute(baseDate.getMinutes());

    if (typeof currentOffsetMinutes === 'number') {
      if (currentOffsetMinutes === 0) {
        setIsOffsetEnabled(false);
        setOffsetMinutes(15);
      } else {
        setIsOffsetEnabled(true);
        setOffsetMinutes(currentOffsetMinutes);
      }
    } else {
      setIsOffsetEnabled(false);
      setOffsetMinutes(15);
    }
  }, [currentReminder, currentOffsetMinutes]);

  // 計算最終 reminderTime
  const computeReminderTime = useCallback(() => {
    const reminderDate = new Date(selectedDate);
    let hours = hour;
    if (period === 'PM' && hours !== 12) hours += 12;
    if (period === 'AM' && hours === 12) hours = 0;
    reminderDate.setHours(hours);
    reminderDate.setMinutes(minute);
    reminderDate.setSeconds(0);
    reminderDate.setMilliseconds(0);
    return reminderDate.getTime();
  }, [selectedDate, hour, minute, period]);

  // 確認
  const handleConfirm = useCallback(() => {
    if (!item) return;
    const reminderTime = computeReminderTime();
    const offsetValue = isOffsetEnabled ? offsetMinutes : 0;
    onConfirm?.(item.id, reminderTime, offsetValue);
    closeReminderDialog();
  }, [item, computeReminderTime, isOffsetEnabled, offsetMinutes, onConfirm]);

  // 取消提醒
  const handleCancelReminder = useCallback(() => {
    if (!item) return;
    onCancel?.(item.id);
    closeReminderDialog();
  }, [item, onCancel]);

  // 對話框開啟時初始化
  useEffect(() => {
    if (showReminderDialog) {
      initializeDateTime();
    }
  }, [showReminderDialog, currentReminder, currentOffsetMinutes]);

  const formatDate = (date) => {
    return date.toLocaleDateString('zh-Hant', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      weekday: 'long',
    });
  };

  const formatTime = () => {
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} ${period}`;
  };

  const generateOptions = (start, end) => {
    return Array.from({ length: end - start + 1 }, (_, i) => {
      const value = start + i;
      return (
        <option key={value} value={value}>
          {value.toString().padStart(2, '0')}
        </option>
      );
    });
  };

  const getSuggestedTimes = () => {
    const now = new Date();
    return [
      {
        label: t('todayEvening'),
        time: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 20, 0)
      },
      {
        label: t('tomorrowMorning'),
        time: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 9, 0)
      },
      {
        label: t('tomorrowAfternoon'),
        time: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 14, 0)
      },
      {
        label: t('tomorrowEvening'),
        time: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 20, 0)
      },
      {
        label: t('nextMondayMorning'),
        time: (() => {
          const monday = new Date();
          monday.setDate(monday.getDate() + ((1 + 7 - monday.getDay()) % 7));
          monday.setHours(9, 0, 0, 0);
          return monday;
        })()
      },
      {
        label: t('nextMondayAfternoon'),
        time: (() => {
          const monday = new Date();
          monday.setDate(monday.getDate() + ((1 + 7 - monday.getDay()) % 7));
          monday.setHours(14, 0, 0, 0);
          return monday;
        })()
      },
      {
        label: t('oneWeekLater'),
        time: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7, now.getHours(), 0)
      },
      {
        label: t('oneMonthLater'),
        time: new Date(now.getFullYear(), now.getMonth() + 1, now.getDate(), now.getHours(), 0)
      }
    ];
  };

  // 建議時間點擊
  const handleSuggestedTime = useCallback((suggestedTime: Date) => {
    if (!item) return;
    const reminderTime = suggestedTime.getTime();
    const offsetValue = isOffsetEnabled ? offsetMinutes : 0;
    onConfirm(item.id, reminderTime, offsetValue);
    closeReminderDialog();
  }, [item, isOffsetEnabled, offsetMinutes, onConfirm]);

  return (
    <CustomDialog
      isOpen={showReminderDialog}
      onClose={closeReminderDialog}
      onConfirm={handleConfirm}
      title={t('setReminder')}
      className="reminder-dialog"
    >
      {currentReminder && (
        <button
          className="cancel-reminder-btn"
          onClick={handleCancelReminder}
        >
          {t('removeReminder')}
        </button>
      )}

      <div className="reminder-content">
        {/* 左側：日期選擇 */}
        <div className="reminder-left">
          <div className="reminder-section-header">
            <h3 className="reminder-dialog-section-title">{t('date')}</h3>
            <p className="display-text">{formatDate(selectedDate)}</p>
          </div>
          <Calendar
            onChange={setSelectedDate as any}
            value={selectedDate}
            locale="zh-Hant"
          />
        </div>

        {/* 右側：時間選擇和建議 */}
        <div className="reminder-right">
          <div className="reminder-section">
            <div className="reminder-section-header">
              <h3 className="reminder-dialog-section-title">{t('time')}</h3>
              <p className="display-text">{formatTime()}</p>
            </div>
            <div className="time-picker">
              <select value={period} onChange={(e) => setPeriod(e.target.value)}>
                <option value="AM">AM</option>
                <option value="PM">PM</option>
              </select>
              <select value={hour} onChange={(e) => setHour(Number(e.target.value))}>
                {generateOptions(1, 12)}
              </select>
              <select value={minute} onChange={(e) => setMinute(Number(e.target.value))}>
                {generateOptions(0, 59)}
              </select>
            </div>

            <div className="reminder-toggle-section reminder-offset-toggle">
              <span className="reminder-dialog-section-title">
                <select
                  value={offsetMinutes}
                  onChange={(e) => setOffsetMinutes(Number(e.target.value))}
                  className="offset-minutes-select"
                >
                  <option value={5}>{t('fiveMinutes')}</option>
                  <option value={10}>{t('tenMinutes')}</option>
                  <option value={15}>{t('fifteenMinutes')}</option>
                  <option value={30}>{t('thirtyMinutes')}</option>
                  <option value={60}>{t('oneHour')}</option>
                </select>
                {t('remindBefore')}
              </span>
              <label className="custom-toggle-switch">
                <input
                  type="checkbox"
                  checked={isOffsetEnabled}
                  onChange={(e) => setIsOffsetEnabled(e.target.checked)}
                />
                <span className="custom-toggle-slider"></span>
              </label>
            </div>
          </div>

          <div className="reminder-section">
            <h3 className="reminder-dialog-section-title">{t('suggestedTime')}</h3>
            <div className="suggested-times">
              {getSuggestedTimes().map((suggestion, index) => (
                <button
                  key={index}
                  className="suggested-time-btn"
                  onClick={() => handleSuggestedTime(suggestion.time)}
                >
                  {suggestion.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </CustomDialog>
  );
};

export default SetReminderTimeDialog;
