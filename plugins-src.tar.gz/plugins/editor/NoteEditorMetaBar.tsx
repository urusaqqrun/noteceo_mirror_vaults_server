import React, { useCallback, useMemo, useState, useEffect } from 'react';
import { useMaterialModeStore } from './editorStore';
import { useIsConnectedStore } from '../../../Store/uiStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useItemStore } from '../../../Store/itemStore';
import { tagIntentionAnalysis } from './ai/editorAI';
import CustomMetaBar from './CustomMetaBar';

// ===== NoteEditorMetaBar — Note 專屬 MetaBar Wrapper（含邏輯） =====

function NoteEditorMetaBar({ noteId, mode, selectedNote, onFieldsChange }: { noteId: string | null; mode: string; selectedNote: any; onFieldsChange?: (fields: Record<string, any>) => void }) {

  // ===== 1. 取得筆記（從 prop 傳入，取代 store subscription） =====
  const sharedNote = useMaterialModeStore(state =>
    mode === 'viewShared' ? state.sharedNoteWithInfo : null
  );

  const note = mode === 'viewShared' ? sharedNote : selectedNote;

  // ===== 2. 解析 tags / aiTags（JSON → string[]） =====
  const tags = useMemo(() => {
    if (!note?.tags) return [];
    try {
      const parsed = typeof note.tags === 'string' ? JSON.parse(note.tags) : note.tags;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }, [note?.tags]);

  const aiTags = useMemo(() => {
    if (!note?.aiTags) return [];
    try {
      const parsed = typeof note.aiTags === 'string' ? JSON.parse(note.aiTags) : note.aiTags;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }, [note?.aiTags]);

  // ===== 3. reminderTime =====
  const reminderTime = useMemo(() => {
    if (!note?.reminderTime) return null;
    return note.reminderTime;
  }, [note?.reminderTime]);

  // ===== 4. isReadOnly =====
  const isReadOnly = mode !== 'normal' && mode !== 'window';

  // ===== 5. onReminderTriggered 監聽 =====
  // 觸發時強制重渲染，讓 UI 用 Date.now() 重新判斷過期樣式
  const [, setReminderTick] = useState(0);
  useEffect(() => {
    if (typeof (window as any).electronAPI?.onReminderTriggered !== 'function') return;
    const unsubscribe = (window as any).electronAPI.onReminderTriggered(() => {
      setReminderTick(c => c + 1);
    });
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  // ===== 6. Callbacks =====

  const onTagsChange = useCallback((newTags: string[]) => {
    if (!noteId) return;
    onFieldsChange?.({ tags: newTags });
  }, [noteId, onFieldsChange]);

  const onAiTagConfirm = useCallback(async (aiTag: string) => {
    if (!noteId || !note) return;

    try {
      const tagExists = tags.some(t => t === aiTag);
      if (tagExists) return;

      const updatedTags = [...tags, aiTag];
      const updatedAiTags = aiTags.filter(tag => tag !== aiTag);

      onFieldsChange?.({ tags: updatedTags, aiTags: updatedAiTags });

      // ---- 以下為死代碼路徑 ----
      // tagsNeedIntentionAnalysis 恆為空陣列，此 if 永遠不進入
      // 保留原樣以防未來啟用
      const isConnected = useIsConnectedStore.getState().isConnected;
      if (!isConnected) return;

      const tagsNeedIntentionAnalysis: string[] = [];
      const notesWithTags: any[] = [];

      if (tagsNeedIntentionAnalysis.length > 0) {
        const noteIdBeforeAPI = noteId;
        for (const tagName of tagsNeedIntentionAnalysis) {
          try {
            const { processItemContent } = await import('../../../utils/textUtils');
            const notes = notesWithTags.map((n: any) =>
              processItemContent(n)
            );

            const result = await tagIntentionAnalysis(notes, tagName);

            const updatePromises = notesWithTags.map(async (n: any) => {
              try {
                const latestNote = await (window as any).electronAPI.getItem(n.id);
                if (!latestNote) {
                  console.error(`找不到筆記 ${n.id}`);
                  return null;
                }

                const updatedTags = (latestNote.tags || []).map((t: any) => {
                  if (t === tagName) {
                    return t;
                  }
                  return t;
                });

                return { ...latestNote, tags: updatedTags };
              } catch (error) {
                console.error(`更新筆記 ${n.id} 失敗:`, error);
                return null;
              }
            });

            const updateResults = await Promise.all(updatePromises);
            const notesNeedUpdate = updateResults.filter(Boolean);

            if (notesNeedUpdate.length > 0) {
              for (const noteToUpdate of notesNeedUpdate) {
                const si = useItemStore.getState().getById((noteToUpdate as any).id);
                if (si) {
                  await useItemStore.getState().upsertItem(
                    { ...si, tags: (noteToUpdate as any).tags } as any,
                    { needSync: false }
                  );
                }
              }
            }


          } catch (error) {
            console.error(`分析標籤 "${tagName}" 意圖時發生錯誤:`, error);
          }
        }
      }
      // ---- 死代碼路徑結束 ----
    } catch (error) {
      console.error('處理 AI 標籤時出錯:', error);
    }
  }, [noteId, note, tags, aiTags]);

  const onReminderClick = useCallback(() => {
    document.dispatchEvent(new CustomEvent('openReminderDialog'));
  }, []);

  const onReminderDelete = useCallback(async () => {
    if (!noteId) return;
    try {
      onFieldsChange?.({ reminderTime: null, offsetMinutes: null });
    } catch (error) {
      console.error('刪除提醒失敗:', error);
    }
  }, [noteId, onFieldsChange]);

  const onTagClick = useCallback((tagName: string) => {
    window.localStorage.setItem('searchInitialText', tagName);
    useDialogStore.getState().open('search', { isFromTag: true });
  }, []);

  // ===== 7. 渲染純 UI =====
  return (
    <CustomMetaBar
      tags={tags}
      aiTags={aiTags}
      reminderTime={reminderTime}
      isReadOnly={isReadOnly}
      onTagsChange={onTagsChange}
      onAiTagConfirm={onAiTagConfirm}
      onReminderClick={onReminderClick}
      onReminderDelete={onReminderDelete}
      onTagClick={onTagClick}
    />
  );
}

export default NoteEditorMetaBar;
