// ===== EditorPlugin — 筆記編輯器插件（預載） =====

import React from 'react';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import NoteEditor from './NoteEditor';

class NoteEditorView extends ReactView {
    getViewType() { return 'note-editor'; }
    getDisplayText() { return '筆記編輯器'; }
    renderComponent() { return <NoteEditor />; }
}

export class EditorPlugin extends Plugin {
    onload() {
        this.registerView('note-editor', (leaf) => new NoteEditorView(leaf));
    }
}

registerPluginClass(EditorPlugin, '編輯器', {
    alwaysLoaded: true,
});
