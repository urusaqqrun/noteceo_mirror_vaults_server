import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { useFloatingToolbarStore } from './editorStore';
import { AddMenuContainer } from './NoteEditorMenu';
import { handleListChange } from './extensions/ListUtils';

function AddMenu({ editor, showAddMenu, position, addButtonRef, hideMenu, onAddImage, onAddTable, isWindowMode = false }) {

  const {
    setShowUrlDialog,
    setCurrentUrl
  } = useFloatingToolbarStore();

  const menuRef = useRef(null);

  // 監聽點擊事件來關閉選單
  useEffect(() => {
    const handleDocumentClick = (e) => {
      // 如果點擊的是選單內部或者添加按鈕，不關閉選單
      if (menuRef.current?.contains(e.target) || addButtonRef?.contains(e.target)) {
        return;
      }
      hideMenu();
    };

    if (showAddMenu) {
      document.addEventListener('mousedown', handleDocumentClick);
      return () => {
        document.removeEventListener('mousedown', handleDocumentClick);
      };
    }
  }, [showAddMenu, hideMenu, addButtonRef]);

  // 如果不顯示選單，返回 null
  if (!showAddMenu || !editor) {
    return null;
  }

  // 處理字型尺寸選擇
  const handleFontSizeSelect = (level) => {

    hideMenu();

    if (level === 'content') {
      // 設為段落
      editor.chain().focus().setParagraph().run();
    } else {
      // 設為標題
      const headingLevel = level.replace('h', '');
      editor.chain().focus().toggleHeading({ level: parseInt(headingLevel) }).run();
    }
  };

  // 使用共享的列表按鈕處理函數
  const handleListButtonClickLocal = (listType) => {
    handleListChange(editor, listType, hideMenu);
  };

  // 處理按鈕滑鼠按下
  const handleButtonMouseDown = (e) => {
    e.preventDefault();
  };

  const absolutePosition = position;

  return createPortal(
    <div
      ref={menuRef}
      style={{
        position: 'fixed',
        top: `${absolutePosition.top}px`,
        left: `${absolutePosition.left}px`,
        zIndex: 9999
      }}
    >
      <AddMenuContainer
        showMenu={showAddMenu}
        onFontSizeSelect={handleFontSizeSelect}
        handleListChange={handleListButtonClickLocal}
        handleButtonMouseDown={handleButtonMouseDown}
        floating={true}
        onClose={hideMenu}
        onAddLink={() => {
          hideMenu();
          setShowUrlDialog(true);
          setCurrentUrl('https://');
        }}
        onAddImage={() => {
          hideMenu();
          if (typeof onAddImage === 'function') {
            onAddImage();
          }
        }}
        onAddTable={(e) => {
          hideMenu();
          if (typeof onAddTable === 'function') {
            onAddTable(e);
          }
        }}
        onAddCodeBlock={() => {
          hideMenu();
          editor.chain().focus().toggleCodeBlock().run();
        }}
        menuClassName={isWindowMode ? 'grow-right' : ''}
      />
    </div>,
    document.body
  );
}

export default AddMenu; 
