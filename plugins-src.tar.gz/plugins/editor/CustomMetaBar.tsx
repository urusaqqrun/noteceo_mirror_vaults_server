import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import '../../common/BasicComponents.css';
import BellIconN from '../../../assets/icon_bell_24.svg?react';
import CustomHint from '../../common/CustomHint';
import './CustomMetaBar.css';

// ===== CustomMetaBar Props =====

export interface CustomMetaBarProps {
  tags: string[];
  aiTags: string[];
  reminderTime: number | null;
  isReadOnly: boolean;
  onTagsChange: (tags: string[]) => void;
  onAiTagConfirm: (tag: string) => void;
  onReminderClick: () => void;
  onReminderDelete: () => void;
  onTagClick: (tagName: string) => void;
}

// ===== 純 UI 組件 =====

function CustomMetaBar({
  tags,
  aiTags,
  reminderTime,
  isReadOnly,
  onTagsChange,
  onAiTagConfirm,
  onReminderClick,
  onReminderDelete,
  onTagClick,
}: CustomMetaBarProps) {
  const { t } = useTranslation();
  const [showTagHint, setShowTagHint] = useState(false);

  // 無內容 → 不渲染
  if (!reminderTime && tags.length === 0 && aiTags.length === 0) {
    return null;
  }

  const handleTagDelete = (tagToDelete: string) => {
    onTagsChange(tags.filter(tag => tag !== tagToDelete));
  };

  const isExpired = reminderTime ? new Date(Number(reminderTime)) < new Date() : false;

  return (
    <div className="editor-meta-bar">
      {/* 提醒 Badge — reminderTime 已被 hook 根據 status 過濾 */}
      {reminderTime && (
        <div
          className={`reminder-badge ${isExpired ? 'expired' : ''}`}
          onClick={onReminderClick}
        >
          <BellIconN />
          {new Date(reminderTime).toLocaleString('zh-Hant', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
          }).replace(/\//g, '/')}
          {!isReadOnly && (
            <button
              className="custom-reminder-delete-btn"
              onClick={(e) => {
                e.stopPropagation();
                onReminderDelete();
              }}
            >
              ×
            </button>
          )}
        </div>
      )}

      {/* 已確認標籤 */}
      {tags.length > 0 && tags.map((tag, index) => (
        <div
          key={`${tag}-${index}`}
          className="tag-item"
          onClick={() => onTagClick(tag)}
        >
          {tag}
          {!isReadOnly && (
            <button
              className="tag-delete-btn"
              onClick={(e) => {
                e.stopPropagation();
                handleTagDelete(tag);
              }}
            >
              ×
            </button>
          )}
        </div>
      ))}

      {/* AI 建議標籤 */}
      {aiTags
        .filter(aiTag => !tags.some(tag => tag === aiTag))
        .map((aiTag, index) => (
          <div
            key={index}
            className="ai-tag-item"
            onMouseEnter={() => setShowTagHint(true)}
            onMouseLeave={() => setShowTagHint(false)}
            onClick={() => {
              onAiTagConfirm(aiTag);
              setShowTagHint(false);
            }}
          >
            {aiTag}
          </div>
        ))}

      <CustomHint show={showTagHint}>
        {t('clickToConfirmTag')}
      </CustomHint>
    </div>
  );
}

export default CustomMetaBar;
