import React from 'react';
import { useTranslation } from 'react-i18next';
import './UpdateNotification.css';

function UpdateNotification({ onClose, onView, sharerName }) {
  const { t } = useTranslation();

  return (
    <div className="update-notification">
      <span className="update-notification-message">
        {t('sharerUpdatedVersion', { name: sharerName || 'Unknown' })}
      </span>
      <div className="update-notification-actions">
        <button
          className="update-notification-button"
          onClick={onClose}
        >
          {t('closeNotification')}
        </button>
        <button
          className="update-notification-button update-notification-button-primary"
          onClick={onView}
        >
          {t('view')}
        </button>
      </div>
    </div>
  );
}

export default UpdateNotification;

