import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './AddUrlDialog.css';
import '../../common/BasicComponents.css';
import SearchDialog from '../../common/SearchDialog';
import { useFloatingToolbarStore, useEditorRefStore } from './editorStore';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

function AddUrlDialog() {
  const { t } = useTranslation();
  // 從 store 獲取狀態
  const showUrlDialog = useFloatingToolbarStore(state => state.showUrlDialog);
  const currentUrl = useFloatingToolbarStore(state => state.currentUrl);
  const editorRef = useEditorRefStore(state => state.editorRef);

  const [url, setUrl] = useState('https://');
  const [linkText, setLinkText] = useState('');
  const [isError, setIsError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const showSearchDialog = useDialogStore(state => state.dialogs['search']?.show);

  const CUBELV_LINK_RE = /^(?:CubeLV|cubelv):\/\/(\w+)\/([a-zA-Z0-9_-]{3,})(?:\?.*)?$/;

  const isValidUrl = (url: string) => {
    if (/^https?:\/\//.test(url)) {
      try {
        const urlObj = new URL(url);
        return urlObj.hostname.includes('.') &&
          urlObj.hostname.split('.').pop().length >= 2;
      } catch (e) {
        return false;
      }
    }
    return CUBELV_LINK_RE.test(url);
  };

  const formatUrl = (inputUrl: string) => {
    const trimmedUrl = inputUrl.trim();

    if (/^https?:\/\//.test(trimmedUrl)) {
      try { return new URL(trimmedUrl).toString(); }
      catch { return trimmedUrl; }
    }

    // cubelv 協議：統一轉小寫
    if (trimmedUrl.startsWith('CubeLV://')) {
      return 'cubelv' + trimmedUrl.substring(7);
    }
    if (trimmedUrl.startsWith('cubelv://')) {
      return trimmedUrl;
    }

    // 模糊輸入修正：包含 cubelv 但格式不完整 → 嘗試提取 ID
    if (/cubelv/i.test(trimmedUrl)) {
      const match = trimmedUrl.match(/(?:CubeLV|cubelv).*?([a-zA-Z0-9_-]{3,})/i);
      if (match?.[1]) return `cubelv://note/${match[1]}`;
      return trimmedUrl;
    }

    if (/^\d{8,}$/.test(trimmedUrl)) {
      return `cubelv://note/${trimmedUrl}`;
    }

    if (!trimmedUrl.includes('://') &&
      /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/.test(trimmedUrl)) {
      return `https://${trimmedUrl}`;
    }

    return trimmedUrl;
  };

  const getCubelvLinkTitle = async (url: string): Promise<string | null> => {
    const match = url.match(CUBELV_LINK_RE);
    if (!match) return null;
    const itemId = match[2];
    const item = await (window as any).electronAPI.getItem(itemId);
    return item?.name || item?.aiTitle || null;
  };

  // 處理從SearchDialog選擇的筆記
  const handleNoteSelect = (noteId, noteTitle) => {
    // 設置URL為筆記連結格式
    setUrl(`cubelv://note/${noteId}`);

    // 使用筆記標題作為連結文字，總是覆蓋原有內容
    setLinkText(noteTitle);

    // 關閉SearchDialog
    useDialogStore.getState().close('search');

    // 清除錯誤訊息
    setIsError(false);
    setErrorMessage('');
  };

  // 關閉對話框
  const handleClose = () => {
    useFloatingToolbarStore.getState().setShowUrlDialog(false);
    useFloatingToolbarStore.getState().setCurrentUrl('https://');
  };

  // 確認並插入連結
  const handleConfirm = (finalUrl, finalText) => {
    const editor = editorRef;
    if (!editor) return;

    // 檢查是否有指定的文字
    if (finalText && finalText.trim() !== '') {
      // 先取消選區，然後插入帶有鏈接的文字
      const { from, to } = editor.state.selection;
      // 選擇當前區域並刪除
      editor.chain().focus().deleteSelection().run();
      // 插入新的文字並添加鏈接
      editor.chain().focus().insertContent(finalText).run();
      // 選擇剛插入的文字
      const newFrom = from;
      const newTo = from + finalText.length;
      editor.chain().focus().setTextSelection({ from: newFrom, to: newTo }).run();
      // 添加鏈接
      editor.chain().focus().setLink({ href: finalUrl }).run();
    } else {
      // 如果沒有指定文字，則使用原有的選區文字添加鏈接
      editor.chain().focus().setLink({ href: finalUrl }).run();
    }
    // 將光標移動到結尾
    const { from, to } = editor.state.selection;
    editor.chain().setTextSelection(to).run();
  };

  useEffect(() => {
    if (showUrlDialog) {
      setUrl(currentUrl);
      setIsError(false);
      setErrorMessage('');

      // 獲取當前選中的文字作為初始連結文字
      const selectedText = window.getSelection().toString();
      setLinkText(selectedText || '');

      // 等待 DOM 更新后聚焦
      setTimeout(() => {
        // 先聚焦連結文字輸入框
        const textInput = document.querySelector('.link-text-input') as HTMLInputElement;
        if (textInput) {
          textInput.focus();
          if (selectedText) {
            textInput.select();
          }
        }
      }, 0);
    }
  }, [showUrlDialog, currentUrl]);

  const handleUrlSubmit = async () => {
    if (!url || url.trim() === '' || url === 'https://') {
      setIsError(true);
      setErrorMessage(t('pleaseEnterUrl'));
      return;
    }

    const formattedUrl = formatUrl(url);

    if (formattedUrl && isValidUrl(formattedUrl)) {
      setIsError(false);
      setErrorMessage('');
      let finalLinkText = linkText.trim();
      if (!finalLinkText) {
        const cubelvTitle = await getCubelvLinkTitle(formattedUrl);
        finalLinkText = cubelvTitle || formattedUrl;
      }
      handleConfirm(formattedUrl, finalLinkText);
      setTimeout(() => {
        handleClose();
      }, 100);
    } else {
      setIsError(true);
      if (formattedUrl.includes('CubeLV') || formattedUrl.includes('cubelv')) {
        setErrorMessage(t('invalidNoteLinkFormat'));
      } else if (formattedUrl.startsWith('https://') || formattedUrl.startsWith('http://')) {
        setErrorMessage(t('invalidUrlFormat'));
      } else {
        setErrorMessage(t('pleaseEnterValidUrl'));
      }
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    handleUrlSubmit();
  };

  const handleUrlChange = (e) => {
    const newUrl = e.target.value;
    setUrl(newUrl);

    // 即時驗證，只在有明顯錯誤時顯示
    if (isError) {
      if (newUrl.trim() === '' || newUrl === 'https://') {
        setErrorMessage(t('pleaseEnterUrl'));
      } else if (isValidUrl(formatUrl(newUrl))) {
        setIsError(false);
        setErrorMessage('');
      }
    }
  };

  const handleTextChange = (e) => {
    setLinkText(e.target.value);
  };

  return (
    <>
      <CustomDialog
        isOpen={showUrlDialog}
        onClose={handleClose}
        onConfirm={handleUrlSubmit}
        title={t('addLink')}
        className="url-dialog-container"
        disableBackdropClose={true}
      >
        <form className="url-dialog" onSubmit={handleSubmit}>
          <input
            type="text"
            value={linkText}
            onChange={handleTextChange}
            className="link-text-input"
            placeholder={t('linkText')}
          />
          <input
            type="text"
            value={url}
            onChange={handleUrlChange}
            className={`url-input ${isError ? 'error' : ''}`}
            placeholder={t('enterUrl')}
            required
          />
          <button
            type="button"
            className="text-link-button"
            onClick={() => useDialogStore.getState().open('search')}
          >
            <span>{t('addNoteLink')}</span>
          </button>
          {isError && <div className="error-message">{errorMessage || t('pleaseEnterValidUrl')}</div>}
        </form>
      </CustomDialog>

      {/* 添加SearchDialog */}
      {showSearchDialog && (
        <SearchDialog
          onClose={() => useDialogStore.getState().close('search')}
          isFromAddUrlDialog={true}
          onNoteSelect={handleNoteSelect}
          currentFolderId={null}
          folders={[]}
        />
      )}
    </>
  );
}

export default AddUrlDialog; 
