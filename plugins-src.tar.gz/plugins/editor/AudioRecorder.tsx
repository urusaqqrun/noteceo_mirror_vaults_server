import React, { useState, useRef, useEffect, forwardRef, useImperativeHandle } from 'react';
import { useTranslation } from 'react-i18next';
import './AudioRecorder.css';

const AudioRecorder = forwardRef<{ cancelRecording: () => void }, { onRecordingComplete?: (data: any) => void; onCancel?: () => void }>(({ onRecordingComplete, onCancel }, ref) => {
  const { t } = useTranslation();
  const [recordingTime, setRecordingTime] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerRef = useRef(null);
  const isCanceledRef = useRef(false);

  // 暴露 cancelRecording 方法給父組件
  useImperativeHandle(ref, () => ({
    cancelRecording: () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        setIsRecording(false);
        isCanceledRef.current = true;
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
        audioChunksRef.current = [];
        stopTimer();
      }
    }
  }));

  // 將 Blob 轉換為 base64
  const blobToBase64 = (blob) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  useEffect(() => {
    // 組件掛載時立即開始錄音
    startRecording();

    // 組件卸載時清理
    return () => {
      stopTimer();
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // 開始錄音
  const startRecording = async () => {
    try {
      isCanceledRef.current = false;
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 44100,
          sampleSize: 16,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      const mimeType = getSupportedMimeType();

      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: mimeType,
        audioBitsPerSecond: 128000
      });

      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (isCanceledRef.current) return;
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = async () => {
        if (isCanceledRef.current) return;

        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        const file = new File([audioBlob], 'recording.m4a', { type: mimeType });

        try {
          // 轉換為 base64
          const base64Data = await blobToBase64(audioBlob);

          // 回傳檔案和 base64 資料
          onRecordingComplete({
            file,
            base64: base64Data
          });
        } catch (error) {
          console.error('轉換音頻為base64失敗:', error);
          onCancel();
        }
      };

      mediaRecorderRef.current.onstart = () => {
        setIsRecording(true);
        startTimer();
      };

      // 每秒收集一次數據
      mediaRecorderRef.current.start(1000);
    } catch (error) {
      console.error('開始錄音失敗:', error);
      if (error.name === 'NotAllowedError') {
        console.error('麥克風權限被拒絕');
        onCancel();
      }
    }
  };

  // 停止錄音
  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      setIsRecording(false);
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      stopTimer();
    }
  };

  // 計時器
  const startTimer = () => {
    setRecordingTime(0);
    timerRef.current = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  // 格式化時間
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 檢查支持的音頻格式
  const getSupportedMimeType = () => {
    const types = [
      'audio/mp4',
      'audio/mp4;codecs=mp4a',
      'audio/aac',
      'audio/mpeg',
      'audio/webm;codecs=opus',
      'audio/webm'
    ];

    for (const type of types) {
      if (MediaRecorder.isTypeSupported(type)) {

        return type;
      }
    }

    console.error('沒有找到支持的音頻格式');
    return 'audio/webm';  // 默認格式
  };

  return (
    <div className="audio-recorder">
      <div className="recorder-controls">
        <div className="recording-time">{isRecording ? formatTime(recordingTime) : ''}</div>
        <button className="stop-button" onClick={stopRecording}>
          {t('stopRecording')}
        </button>
        <button className="custom-secondary-button" onClick={() => {
          (ref as React.RefObject<{ cancelRecording: () => void }>).current.cancelRecording();
          onCancel();
        }}>
          {t('cancel')}
        </button>
      </div>
    </div>
  );
});

export default AudioRecorder; 