import React, { useState, useMemo, useCallback, useRef } from 'react';
import { useLiveInputStore } from '../../../Store/uiStore';
import { useItemStore } from '../../../Store/itemStore';
import { autoTitle } from './ai/editorAI';
import TitleEditor from './TitleEditor';

// ===== NoteEditorTitle — Note 專屬標題 Wrapper（含邏輯） =====

function NoteEditorTitle({ noteId, mode, selectedNote }: { noteId: string; mode: string; selectedNote: any }) {

  // ===== 1. 從 selectedNote 取得筆記標題相關欄位 =====
  const fields = useMemo(() => {
    if (!selectedNote) return null;
    return {
      name: selectedNote.name || '',
      aiTitle: selectedNote.aiTitle || null,
    };
  }, [selectedNote?.name, selectedNote?.aiTitle]);

  // ===== 2. liveTitleInput 即時同步 =====
  const liveTitleInput = useLiveInputStore(
    state => noteId ? state.liveTitleInputs[noteId] : undefined
  );

  // ===== 3. 計算顯示值 =====
  const { title, aiTitle } = useMemo(() => {
    if (!fields) return { title: '', aiTitle: null as string | null };

    // liveTitleInput 優先（來自 TodoList / NoteList 的即時同步）
    if (liveTitleInput !== undefined) {
      return { title: liveTitleInput, aiTitle: null as string | null };
    }

    const hasAiTitle = !fields.name && !!fields.aiTitle;
    return {
      title: fields.name,
      aiTitle: hasAiTitle ? fields.aiTitle : null,
    };
  }, [fields?.name, fields?.aiTitle, liveTitleInput]);

  const isReadOnly = mode !== 'normal' && mode !== 'window' && mode !== 'material';

  // ===== 4. AI 刷新 loading 狀態 =====
  const [isRefreshingAiTitle, setIsRefreshingAiTitle] = useState(false);
  const isRefreshingRef = useRef(false);
  const noteIdRef = useRef(noteId);
  noteIdRef.current = noteId;

  // ===== 5. handleTitleChange =====
  const handleTitleChange = useCallback(async (newTitle: string) => {
    if (!noteId) return;
    const item = useItemStore.getState().getById(noteId);
    if (!item) return;
    await useItemStore.getState().upsertItem(
      { ...item, name: newTitle, aiTitle: null, updatedAt: Date.now() } as any,
      { needSync: true }
    );
  }, [noteId]);

  // ===== 6. handleAiTitleConfirm =====
  const handleAiTitleConfirm = useCallback(async () => {
    if (!noteId) return;
    const item = useItemStore.getState().getById(noteId);
    if (!item || !(item as any).aiTitle) return;
    await useItemStore.getState().upsertItem(
      { ...item, name: (item as any).aiTitle, aiTitle: '', updatedAt: Date.now() } as any,
      { needSync: true }
    );
  }, [noteId]);

  // ===== 7. handleRefreshAiTitle =====
  const handleRefreshAiTitle = useCallback(async () => {
    if (!noteId) return;
    if (isRefreshingRef.current) return;

    const note = await window.electronAPI.getItem(noteId);
    if (!note) return;

    const currentTitle = note.name || '';
    const currentAiTitle = note.aiTitle || '';
    const { processItemContent } = await import('../../../utils/textUtils');
    const content = processItemContent(note, false, false);

    if (!content && !currentTitle && !currentAiTitle) return;

    setIsRefreshingAiTitle(true);
    isRefreshingRef.current = true;
    const refreshNoteId = noteId;

    try {
      let result;
      if (content.trim() !== '') {
        result = await autoTitle(content);
      } else {
        result = await autoTitle(
          content,
          "請重新生成標題，不要使用相同的標題:" + (currentTitle || currentAiTitle)
        );
      }

      if (!result?.title) return;

      // 確認使用者仍在同一筆記
      if (noteIdRef.current !== refreshNoteId) return;

      const refreshItem = useItemStore.getState().getById(refreshNoteId);
      if (!refreshItem) return;
      if (currentTitle) {
        await useItemStore.getState().upsertItem(
          { ...refreshItem, name: result.title, updatedAt: Date.now() } as any,
          { needSync: true }
        );
      } else {
        await useItemStore.getState().upsertItem(
          { ...refreshItem, aiTitle: result.title, updatedAt: Date.now() } as any,
          { needSync: true }
        );
      }
    } catch (error) {
      console.error('重新生成 AI 標題失敗:', error);
    } finally {
      setIsRefreshingAiTitle(false);
      isRefreshingRef.current = false;
    }
  }, [noteId]);

  // ===== 8. 渲染純 UI =====
  return (
    <TitleEditor
      id={noteId}
      title={title}
      aiTitle={aiTitle}
      isReadOnly={isReadOnly}
      isRefreshingAiTitle={isRefreshingAiTitle}
      onTitleChange={handleTitleChange}
      onAiTitleConfirm={handleAiTitleConfirm}
      onRefreshAiTitle={handleRefreshAiTitle}
    />
  );
}

export default NoteEditorTitle;
