import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './AudioPlayer.css';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { isElectron } from '../../../utils/platform';

const AudioPlayer = ({ audioURLs, audioUrl_local, audioTexts, onDelete, onTranscriptSave }) => {
  const { t } = useTranslation();
  const showMenu = useMenuStore(state => state.menus['audioMenu']?.show);
  const [playbackRate, setPlaybackRate] = useState(1);
  const audioRef = useRef(null);
  const containerRef = useRef(null);

  // 獲取實際要播放的音頻URL
  const getAudioSource = () => {
    if (audioUrl_local && audioUrl_local.length > 0) {
      return audioUrl_local[0];  // 使用本地base64音頻
    }
    if (audioURLs && audioURLs.length > 0) {
      return audioURLs[0];  // 使用遠端音頻
    }
    return null;  // 返回 null 而不是空字串
  };

  const playbackRates = [
    { value: 0.5, label: `0.5x ${t('speed')}` },
    { value: 0.75, label: `0.75x ${t('speed')}` },
    { value: 1, label: `1.0x ${t('speed')}` },
    { value: 1.25, label: `1.25x ${t('speed')}` },
    { value: 1.5, label: `1.5x ${t('speed')}` },
    { value: 2, label: `2.0x ${t('speed')}` },
    { value: 2.5, label: `2.5x ${t('speed')}` },
    { value: 3, label: `3.0x ${t('speed')}` },
  ];

  // 處理點擊事件
  const handleMoreClick = (e) => {
    e.stopPropagation();
    if (showMenu) useMenuStore.getState().close('audioMenu');
    else useMenuStore.getState().openAt('audioMenu', 0, 0);
  };

  // 處理下載：Electron 用 IPC 繞過 CORS，Web 用 window.open 避免頁面跳轉
  const handleDownload = async () => {
    const audioSource = getAudioSource();
    if (!audioSource) return;
    useMenuStore.getState().close('audioMenu');

    try {
      if (isElectron) {
        const buffer = await (window as any).electronAPI.downloadAudioFile(audioSource);
        const blob = new Blob([buffer], { type: 'audio/mp4' });
        const blobUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = 'audio.m4a';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
      } else {
        window.open(audioSource, '_blank');
      }
    } catch (e) {
      console.error('下載音頻失敗:', e);
    }
  };

  // 處理刪除
  const handleDelete = (e) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete();
    }
    useMenuStore.getState().close('audioMenu');
  };

  // 處理播放速度
  const handlePlaybackRate = (rate) => {
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
      setPlaybackRate(rate);
    }
    useMenuStore.getState().close('audioMenu');
  };

  // 處理顯示逐字稿
  const handleShowTranscript = (e) => {
    e.stopPropagation();
    useDialogStore.getState().open('transcript', {
      audioTexts,
      onSave: handleTranscriptSave,
    });
    useMenuStore.getState().close('audioMenu');
  };

  // 處理逐字稿儲存
  const handleTranscriptSave = (updatedTexts) => {
    if (onTranscriptSave) {
      onTranscriptSave(updatedTexts);
    }
  };

  // 點擊外部關閉選單
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        useMenuStore.getState().close('audioMenu');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // 當切換筆記時，暫停音頻播放
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
  }, [audioURLs, audioUrl_local]);

  const hasAudio = (audioURLs && audioURLs.length > 0) || (audioUrl_local && audioUrl_local.length > 0);
  const audioSource = getAudioSource();

  return (
    <div className={`audio-player ${!hasAudio ? 'hidden' : ''}`}>
      <div className="audio-player-container" ref={containerRef} onClick={handleMoreClick}>
        <audio
          ref={audioRef}
          controls
          src={audioSource}
          className="audio-element"
          controlsList="nodownload noplaybackrate noremoteplayback"
          preload="metadata"
        >
          {t('browserNotSupportAudio')}
        </audio>
        {showMenu && hasAudio && (
          <div className="audio-menu">
            <div className="audio-menu-item" onClick={handleShowTranscript}>
              {t('showTranscript')}
            </div>
            <div className="audio-menu-item" onClick={handleDownload}>
              {t('downloadAudio')}
            </div>
            <div className="audio-menu-item" onClick={handleDelete}>
              {t('deleteAudio')}
            </div>
            <div className="audio-menu-separator" />
            {playbackRates.map((rate) => (
              <div
                key={rate.value}
                className={`audio-menu-item ${playbackRate === rate.value ? 'active' : ''}`}
                onClick={() => handlePlaybackRate(rate.value)}
              >
                {rate.label}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};

export default AudioPlayer; 
