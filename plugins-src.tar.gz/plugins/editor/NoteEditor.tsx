import React, { forwardRef, useState, useEffect, useLayoutEffect, useMemo, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './NoteEditor.css';
import NoteEditorTopbar from './NoteEditorTopbar';
import NoteEditorTitle from './NoteEditorTitle';
import NoteEditorMetaBar from './NoteEditorMetaBar';
import MarkdownEditor from './MarkdownEditor';
import AudioContainer from './AudioContainer';
import EditorPlaceholder from './EditorPlaceholder';
import type { ShortcutHint } from './EditorPlaceholder';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useMergedNoteStore } from '../../../Store/uiStore';
import { useItemStore } from '../../../Store/itemStore';
import { eventBus } from '../../../Store/eventBus';

const LazyNoteEditorToolbarAndMenu = React.lazy(() => import('./NoteEditorToolbar'));

const NoteEditor = forwardRef(({
  mode = 'normal',
  noteId: propNoteId = null,
  editorId: _propEditorId = null,
}: {
  mode?: string;
  noteId?: string | null;
  editorId?: string | null;
}, ref) => {
  const { t } = useTranslation();
  const isReadOnlyMode = mode !== 'normal' && mode !== 'window' && mode !== 'material';

  // ===== noteId 解析 =====
  const lastSelectionId = useSelectedItemsStore(state => {
    if (mode !== 'normal') return null;
    const last = state.path.at(-1);
    return (last && !last.itemType?.endsWith('_FOLDER')) ? last.id : null;
  });
  const resolvedNoteId = mode === 'normal'
    ? (lastSelectionId || null)
    : propNoteId;

  // ===== 筆記 state 管理（從 NoteEditorContent 提升） =====
  const [selectedNote, setSelectedNote] = useState<any>(null);
  const [saveVersion, setSaveVersion] = useState(0);
  const isInitialLoadRef = useRef(true);
  const needUpdateNoteWithoutUpdateAtRef = useRef(false);
  const needSyncRef = useRef(true);
  const autosaveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const preNoteIdRef = useRef<string | null>(null);

  const wrappedSetSelectedNote = useCallback((noteOrUpdater: any) => {
    setSelectedNote(noteOrUpdater);
    setSaveVersion(v => v + 1);
  }, []);

  const onFieldsChange = useCallback((fields: Record<string, any>) => {
    needSyncRef.current = true;
    setSelectedNote((prev: any) => prev ? { ...prev, ...fields } : prev);
    setSaveVersion(v => v + 1);
  }, []);

  const onFieldsChangeSilent = useCallback((fields: Record<string, any>) => {
    needUpdateNoteWithoutUpdateAtRef.current = true;
    needSyncRef.current = true;
    setSelectedNote((prev: any) => prev ? { ...prev, ...fields } : prev);
    setSaveVersion(v => v + 1);
  }, []);

  // ===== 訂閱 useItemStore：外部欄位更新時自動同步 selectedNote =====
  const storeItem = useItemStore(state =>
    selectedNote?.id ? state.getById(selectedNote.id) : null
  );

  useEffect(() => {
    if (!storeItem || !selectedNote || storeItem.id !== selectedNote.id) return;
    if (storeItem.updatedAt === selectedNote.updatedAt) return;
    const contentChanged = ((storeItem as any).content || '') !== (selectedNote.content || '');
    if (contentChanged) return;
    setSelectedNote(storeItem);
  }, [storeItem, selectedNote?.id, selectedNote?.updatedAt, selectedNote?.content]);

  // ===== 跨視窗即時同步：偵測遠端 upsert，強制更新 selectedNote（含 content） =====
  const selectedNoteIdRef = useRef<string | null>(null);
  useEffect(() => { selectedNoteIdRef.current = selectedNote?.id ?? null; }, [selectedNote?.id]);

  useEffect(() => {
    const unsub = eventBus.on('item:remote-upsert', (item: any) => {
      if (!item || item.id !== selectedNoteIdRef.current) return;
      isInitialLoadRef.current = true;
      setSelectedNote(item);
    });
    return unsub;
  }, []);

  // ===== 監聽跳過時間戳記更新的事件 =====
  useEffect(() => {
    const handleSkipUpdateTimestamp = () => {
      needUpdateNoteWithoutUpdateAtRef.current = true;
    };
    document.addEventListener('skipUpdateTimestamp', handleSkipUpdateTimestamp);
    return () => {
      document.removeEventListener('skipUpdateTimestamp', handleSkipUpdateTimestamp);
    };
  }, []);

  // ===== 切換筆記前：立即 flush 待存內容（防止空白筆記誤刪）=====
  // useLayoutEffect 確保在 NoteList 的 useEffect（空白筆記自動刪除）之前執行
  useLayoutEffect(() => {
    if (autosaveTimeoutRef.current && selectedNote) {
      clearTimeout(autosaveTimeoutRef.current);
      autosaveTimeoutRef.current = null;
      const storeItem = useItemStore.getState().getById(selectedNote.id);
      if (storeItem) {
        const isSilent = needUpdateNoteWithoutUpdateAtRef.current;
        const merged = isSilent
          ? { ...storeItem, ...selectedNote }
          : { ...storeItem, ...selectedNote, updatedAt: Date.now() };
        useItemStore.getState().upsertItem(merged, { needSync: needSyncRef.current });
      }
      if (needUpdateNoteWithoutUpdateAtRef.current) needUpdateNoteWithoutUpdateAtRef.current = false;
      needSyncRef.current = true;
    }
  }, [resolvedNoteId]);

  // ===== 統一的 note 取得邏輯 =====
  useEffect(() => {
    needUpdateNoteWithoutUpdateAtRef.current = true;

    const handlePreviousNote = async () => {
      if (preNoteIdRef.current) {
        try {
          const previousNote = await (window.electronAPI as any).getItem(preNoteIdRef.current);
          if (previousNote &&
            previousNote.tags &&
            previousNote.aiTags &&
            Array.isArray(previousNote.tags) &&
            Array.isArray(previousNote.aiTags) &&
            previousNote.tags.length > 0 &&
            previousNote.aiTags.length > 0) {
            const prevItem = useItemStore.getState().getById(previousNote.id);
            if (prevItem) {
              await useItemStore.getState().upsertItem(
                { ...prevItem, aiTags: [], updatedAt: Date.now() } as any,
                { needSync: true }
              );
            }
          }
        } catch (error) {
          console.error('處理前一個筆記的 aiTags 清空時發生錯誤:', error);
        }
      }
    };

    handlePreviousNote();

    if (!resolvedNoteId) {
      isInitialLoadRef.current = true;
      setSelectedNote(null);
      return;
    }

    const loadNote = async () => {
      let note: any = null;

      note = await window.electronAPI.getItem(resolvedNoteId) || null;
      preNoteIdRef.current = note?.id || null;

      // 必須在 setSelectedNote 之前設置 isInitialLoadRef
      // 因為 React 18 在 async context 中會立即 flush state update
      isInitialLoadRef.current = true;
      setSelectedNote(note);
    };
    loadNote();

  }, [resolvedNoteId, mode]);

  // ===== autosave =====
  useEffect(() => {
    if (!selectedNote) { console.log('[NoteEditor autosave] skip: no selectedNote'); return; }

    if (isInitialLoadRef.current) {
      console.log('[NoteEditor autosave] skip: isInitialLoad, setting false');
      isInitialLoadRef.current = false;
      return;
    }

    console.log('[NoteEditor autosave] SCHEDULING save for', selectedNote.id, 'content length:', selectedNote?.content?.length);

    if (autosaveTimeoutRef.current) {
      clearTimeout(autosaveTimeoutRef.current);
    }

    autosaveTimeoutRef.current = setTimeout(() => {
      autosaveTimeoutRef.current = null;

      const isSilent = needUpdateNoteWithoutUpdateAtRef.current;
      console.log('[NoteEditor autosave] FIRING', isSilent ? 'save-silent' : 'save', 'for', selectedNote.id, 'content length:', selectedNote?.content?.length, 'needSync:', needSyncRef.current);

      const storeItem = useItemStore.getState().getById(selectedNote.id);
      if (storeItem) {
        const merged = isSilent
          ? { ...storeItem, ...selectedNote }
          : { ...storeItem, ...selectedNote, updatedAt: Date.now() };
        useItemStore.getState().upsertItem(merged, { needSync: needSyncRef.current });
      }
      if (isSilent) needUpdateNoteWithoutUpdateAtRef.current = false;
      needSyncRef.current = true;

      if (useMergedNoteStore.getState().mergedNoteId === selectedNote.id) {
        useMergedNoteStore.getState().setMergedNoteId(null);
      }
    }, 300);

    return () => {
      if (autosaveTimeoutRef.current) {
        clearTimeout(autosaveTimeoutRef.current);
      }
    };

  }, [saveVersion]);

  // ===== EditorPlaceholder shortcuts 組裝 =====
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const lastPath = useSelectedItemsStore(state => state.path.at(-1) ?? null);

  const [folderInfo, setFolderInfo] = useState<any>(null);
  useEffect(() => {
    if (!selectedFolderId) { setFolderInfo(null); return; }
    window.electronAPI.getItem(selectedFolderId).then(f => setFolderInfo(f ?? null));
  }, [selectedFolderId]);

  const emptyShortcuts = useMemo<ShortcutHint[]>(() => {
    const isCompletedView = lastPath?.itemType === 'TODO_FOLDER' && lastPath?.id === 'completed';
    const isTodoViewFilter = lastPath?.itemType === 'TODO_FOLDER' && ['today', 'preview', 'completed'].includes(lastPath?.id);
    const isTodoMode = isTodoViewFilter || folderInfo?.itemType === 'TODO_FOLDER';
    const isTempFolder = !!folderInfo?.isTemp;

    const list: ShortcutHint[] = [];

    if (!isCompletedView) {
      const enterDesc = isTempFolder ? t('confirmClassification') : (isTodoMode ? t('addTodo') : t('addNote'));
      list.push({ key: 'Enter', desc: enterDesc });
    }

    list.push({ key: '→', desc: t('enterNextLevel') });
    list.push({ key: '← / Esc', desc: t('returnPreviousLevel') });
    list.push({ key: '↑ / ↓', desc: t('navigateUpDown') });

    return list;
  }, [lastPath, folderInfo, t]);

  // ===== 純 Layout =====
  return (
    <div
      className={`note-editor-container ${mode !== 'normal' && mode !== 'window' ? 'material-mode' : ''}`}
      style={{ height: '100%', display: 'flex', flexDirection: 'column' }}
    >
      {resolvedNoteId ? (
        <>
          {(mode === 'normal' || mode === 'window') && (
            <NoteEditorTopbar itemId={resolvedNoteId} mode={mode} selectedNote={selectedNote} onFieldsChange={onFieldsChange} />
          )}
          <NoteEditorTitle noteId={resolvedNoteId} mode={mode} selectedNote={selectedNote} />
          <AudioContainer
            noteId={resolvedNoteId}
            selectedNote={selectedNote}
            setSelectedNote={wrappedSetSelectedNote}
            onFieldsChangeSilent={onFieldsChangeSilent}
          />
          <MarkdownEditor
            ref={ref}
            noteId={resolvedNoteId}
            mode={mode}
            selectedNote={selectedNote}
            setSelectedNote={wrappedSetSelectedNote}
            onFieldsChange={onFieldsChange}
            onFieldsChangeSilent={onFieldsChangeSilent}
          />
          <NoteEditorMetaBar noteId={resolvedNoteId} mode={mode} selectedNote={selectedNote} onFieldsChange={onFieldsChange} />
        </>
      ) : (
        isReadOnlyMode ? (
          <div className="no-note-selected">
            <p>{t('pleaseSelectMaterial')}</p>
          </div>
        ) : (
          <EditorPlaceholder shortcuts={emptyShortcuts} />
        )
      )}
      <React.Suspense fallback={null}>
        <LazyNoteEditorToolbarAndMenu />
      </React.Suspense>
    </div>
  );
});

(NoteEditor as React.ComponentType & { whyDidYouRender?: object }).whyDidYouRender = {
  logOnDifferentValues: true,
  logOwnerReasons: true,
  trackAllPureComponents: true,
  trackHooks: true,
  customName: 'NoteEditor',
  diffNameColor: 'orange',
};

export default NoteEditor;
