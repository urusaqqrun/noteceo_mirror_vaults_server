import { create } from 'zustand';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';

import { BaseItem, itemType } from '../../../types/item';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';

// ===== Types =====

@itemType('CHART_FOLDER', '圖表資料夾')
export class ChartType extends BaseItem {
  chartKind?: string = '';
}

@itemType('CHART', '圖表資料')
export class Chart extends BaseItem {
}

const getChartFolders = () => useItemStore.getState().getByType('CHART_FOLDER') as ChartType[];
const getCharts = () => useItemStore.getState().getByType('CHART') as Chart[];

interface ChartsState {
  // ===== Chart Folders（已遷移至 useItemStore）=====
  loadChartFolders: () => Promise<void>;
  updateChartFolder: (data: any) => Promise<void>;
  addChartFolder: (data: any) => Promise<void>;
  deleteChartFolder: (folderIds: string | string[], needSync?: boolean) => Promise<void>;
  // ===== Charts（已遷移至 useItemStore）=====
  loadCharts: () => Promise<void>;
  getChartById: (id: string) => Chart | null;
  getChartsByParentId: (parentID: string) => Chart[];
  searchChartsByName: (query: string) => Chart[];
  addChart: (newChart: any | any[], needSync?: boolean) => Promise<void>;
  updateChart: (updatedChart: any | any[], needSync?: boolean) => Promise<void>;
  deleteChart: (chartIds: string | string[], needSync?: boolean) => Promise<void>;
}

// ==================== Charts Store ====================
export const useChartsStore = create<ChartsState>((set, get) => ({
  // ===== Chart Folders 狀態和方法 =====
  loadChartFolders: async () => {
    try {
      await useItemStore.getState().loadByType('CHART_FOLDER');
    } catch (error) {
      console.error('Failed to load chart folders:', error);
    }
  },
  updateChartFolder: async (data: any, needSync = true) => {
    try {
      const existing = getChartFolders().find(f => f.id === data.id);
      const merged = { ...existing, ...data, itemType: 'CHART_FOLDER' };
      await useItemStore.getState().upsertItem(merged, { needSync });
    } catch (error) {
      console.error('Failed to update chart folder:', error);
    }
  },
  addChartFolder: async (data: any, needSync = true) => {
    try {
      const now = Date.now();

      // 計算 orderAt：新資料夾排在同層最後面（比現有最大 orderAt 更大）
      let orderAt = data.orderAt;
      if (orderAt === undefined || orderAt === null) {
        const allFolders = useItemStore.getState().getByType('CHART_FOLDER');
        const parentID = data.parentID || null;
        const siblings = allFolders.filter((f: any) =>
          ((f.parentID || null) === parentID)
        );
        const getOrder = (f: any) => {
          const o = Number(f.orderAt) || 0;
          return o !== 0 ? o : (Number(f.createdAt) || 0);
        };
        const maxOrder = siblings.length > 0
          ? Math.max(...siblings.map(getOrder))
          : now;
        orderAt = maxOrder + 1000;
      }

      const folder = {
        ...data,
        id: data.id || generateObjectID(),
        itemType: 'CHART_FOLDER',
        createdAt: data.createdAt || now,
        updatedAt: data.updatedAt || now,
        orderAt,
      };
      await useItemStore.getState().upsertItem(folder, { needSync });
    } catch (error) {
      console.error('Failed to add chart folder:', error);
    }
  },
  deleteChartFolder: async (folderIds, needSync = true) => {
    try {
      const ids = Array.isArray(folderIds) ? folderIds : [folderIds];
      if (ids.length === 0) return;

      const folders = getChartFolders();
      const charts = getCharts();

      // 遞迴收集子資料夾
      const collectDescendantIds = (parentId: string): string[] => {
        const childIds: string[] = [];
        folders.filter(f => f.parentID === parentId).forEach(child => {
          childIds.push(child.id);
          childIds.push(...collectDescendantIds(child.id));
        });
        return childIds;
      };

      const foldersNeedDelete: string[] = [];
      ids.forEach(fid => {
        const allIds = [fid, ...collectDescendantIds(fid)];
        allIds.forEach(id => { if (!foldersNeedDelete.includes(id)) foldersNeedDelete.push(id); });
      });

      // 刪除資料夾下的圖表
      const affectedFolderIds = new Set(foldersNeedDelete);
      const chartsToDelete = charts.filter(c => affectedFolderIds.has(c.parentID as string));
      if (chartsToDelete.length > 0) {
        await get().deleteChart(chartsToDelete.map(c => c.id), needSync);
      }

      await useItemStore.getState().removeItems(foldersNeedDelete, { needSync });

      await get().loadChartFolders();
      await get().loadCharts();
    } catch (error) {
      console.error('刪除圖表資料夾失敗:', error);
    }
  },
  // ===== Charts 狀態和方法 =====
  loadCharts: async () => {
    try {
      await useItemStore.getState().loadByType('CHART');
    } catch (error) {
      console.error('Failed to load charts:', error);
    }
  },
  getChartById: (id) => {
    return getCharts().find(c => c.id === id) || null;
  },
  getChartsByParentId: (parentID) => {
    return getCharts().filter(c => c.parentID === parentID);
  },
  searchChartsByName: (query) => {
    if (!query) return getCharts();
    const lowerQuery = query.toLowerCase();
    return getCharts().filter(c =>
      c.name && c.name.toLowerCase().includes(lowerQuery)
    );
  },
  addChart: async (newChart, needSync = true) => {
    // 若傳入陣列，批次新增圖表
    if (Array.isArray(newChart)) {
      try {
        const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
        const chartsWithMeta = newChart.map(c => ({
          ...c,
          id: c.id || generateObjectID(),
          memberID: c.memberID || userData?.ID
        }));

        for (const c of chartsWithMeta) {
          const chart = { ...c, itemType: 'CHART' as const };
          await useItemStore.getState().upsertItem(chart, { needSync });
        }
      } catch (error) {
        console.error('批次新增圖表錯誤：', error);
      }
      return;
    }

    try {
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const chartWithMeta = {
        ...newChart,
        id: newChart.id || generateObjectID(),
        memberID: newChart.memberID || userData?.ID
      };

      const chart = { ...chartWithMeta, itemType: 'CHART' as const };
      await useItemStore.getState().upsertItem(chart, { needSync });
    } catch (error) {
      console.error('新增圖表錯誤：', error);
    }
  },
  updateChart: async (updatedChart, needSync = true) => {
    // 支援批次更新
    if (Array.isArray(updatedChart)) {
      try {
        for (const c of updatedChart) {
          const chart = { ...c, itemType: 'CHART' as const };
          await useItemStore.getState().upsertItem(chart, { needSync });
        }
      } catch (error) {
        console.error('批次更新圖表錯誤：', error);
      }
      return;
    }

    try {
      const chart = { ...updatedChart, itemType: 'CHART' as const };
      await useItemStore.getState().upsertItem(chart, { needSync });
    } catch (error) {
      console.error('更新圖表錯誤：', error);
    }
  },
  deleteChart: async (chartIds, needSync = true) => {
    try {
      const ids = Array.isArray(chartIds) ? chartIds : [chartIds];

      await useItemStore.getState().removeItems(ids, { needSync });
    } catch (error) {
      console.error('刪除圖表錯誤：', error);
    }
  }
}));


