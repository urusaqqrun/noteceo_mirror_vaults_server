import React, { useMemo, useCallback, memo, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  LineChart, Line,
  AreaChart, Area,
  BarChart, Bar,
  PieChart, Pie, Cell,
  ScatterChart, Scatter,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  RadialBarChart, RadialBar,
  Treemap,
  FunnelChart, Funnel, LabelList,
  ComposedChart,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { useTheme } from '../../setting/ThemeProvider';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import './ChartRender.css';

// 預設顏色調色盤（由 ThemeProvider 注入的 CSS 變數）
const COLORS = [
  'var(--chart-oceanBlue)',
  'var(--chart-mintGreen)',
  'var(--chart-tangerineOrange)',
  'var(--chart-cherryRed)',
  'var(--chart-lavenderPurple)',
  'var(--chart-slateGrey)',
  'var(--chart-turquoiseTeal)',
  'var(--chart-orchidMagenta)',
  'var(--chart-sunsetOrange)',
  'var(--chart-tropicalCyan)'
];

/**
 * ChartRender 組件
 * 根據 ChartType.kind 渲染對應的 Recharts 圖表
 */
function ChartRender({ chart, chartType }) {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobileView = useIsMobileView();

  // 修正：app 啟動時延遲渲染圖表，確保容器尺寸就緒
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsReady(true);
    }, 200);
    return () => clearTimeout(timer);
  }, []);

  // 解析 chart.data（JSON 字串）
  const chartData = useMemo(() => {
    if (!chart?.data) return [];
    try {
      const parsed = typeof chart.data === 'string' ? JSON.parse(chart.data) : chart.data;
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.error('解析圖表數據失敗:', e);
      return [];
    }
  }, [chart?.data]);

  // 取得 X 軸的 key：第一個字符串類型的 key
  const xAxisKey = useMemo(() => {
    if (chartData.length === 0) return 'name';
    const firstItem = chartData[0];
    for (const key of Object.keys(firstItem)) {
      if (typeof firstItem[key] === 'string') {
        return key;
      }
    }
    return Object.keys(firstItem)[0] || 'name';
  }, [chartData]);

  // 數據 keys：所有數值類型的 key
  const dataKeys = useMemo(() => {
    if (chartData.length === 0) return [];
    const firstItem = chartData[0];
    return Object.keys(firstItem).filter(key => typeof firstItem[key] === 'number');
  }, [chartData]);

  // 圖表通用配置（使用 useMemo 避免重複創建）
  const chartConfig = useMemo(() => ({
    width: '100%' as const,
    height: '100%' as const,
    minHeight: 200, // 防止初始渲染時高度為 0 導致警告和閃爍
    margin: { top: 20, right: 30, left: 20, bottom: 5 }
  }), []);

  // 主題相關樣式
  const axisStyle = useMemo(() => ({
    stroke: theme.mode === 'dark' ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)',
    fontSize: 12
  }), [theme.mode]);

  const gridStyle = useMemo(() => ({
    strokeDasharray: '3 3',
    stroke: theme.mode === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'
  }), [theme.mode]);

  // 圓餅圖標籤函數（穩定引用）- 名稱與百分比分兩行顯示，置中對齊
  const pieLabel = useCallback(({ cx, cy, midAngle, outerRadius, name, percent }) => {
    const RADIAN = Math.PI / 180;
    //如果是mobile版，則增加距離避免重疊
    const radius = isMobileView ? outerRadius * 1.35 : outerRadius * 1.25;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        textAnchor="middle"
        dominantBaseline="central"
        style={{ fontSize: '12px', fill: 'var(--on)' }}
      >
        <tspan x={x} dy="-0.5em">{name}</tspan>
        <tspan x={x} dy="1.2em">{(percent * 100).toFixed(0)}%</tspan>
      </text>
    );
  }, []);

  // 圓餅圖圖例渲染（穩定引用）
  const renderPieLegend = useCallback((props) => {
    const { payload } = props;
    return (
      <div style={{ display: 'flex', justifyContent: 'center', gap: '16px', flexWrap: 'wrap' }}>
        {payload.map((entry, index) => (
          <div key={`legend-${index}`} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <div style={{
              width: '10px',
              height: '10px',
              borderRadius: '50%',
              backgroundColor: entry.color,
              flexShrink: 0
            }} />
            <span style={{ fontSize: '14px', color: 'var(--on)' }}>{entry.value}</span>
          </div>
        ))}
      </div>
    );
  }, []);

  // 無數據狀態
  if (chartData.length === 0) {
    return (
      <div className="chart-render chart-render-empty">
        <p>{t('noChartData')}</p>
      </div>
    );
  }

  // 根據 kind 渲染不同圖表
  const renderChart = () => {
    const kind = chartType?.kind || 'LineChart';

    switch (kind) {
      case 'LineChart':
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <LineChart data={chartData} margin={chartConfig.margin}>
              <CartesianGrid {...gridStyle} />
              <XAxis dataKey={xAxisKey} {...axisStyle} />
              <YAxis {...axisStyle} />
              <Tooltip />
              <Legend />
              {dataKeys.map((key, index) => (
                <Line
                  key={key}
                  type="monotone"
                  dataKey={key}
                  stroke={COLORS[index % COLORS.length]}
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                  animationDuration={400}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        );

      case 'AreaChart':
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <AreaChart data={chartData} margin={chartConfig.margin}>
              <CartesianGrid {...gridStyle} />
              <XAxis dataKey={xAxisKey} {...axisStyle} />
              <YAxis {...axisStyle} />
              <Tooltip />
              <Legend />
              {dataKeys.map((key, index) => (
                <Area
                  key={key}
                  type="monotone"
                  dataKey={key}
                  stroke={COLORS[index % COLORS.length]}
                  fill={COLORS[index % COLORS.length]}
                  fillOpacity={0.3}
                  animationDuration={400}
                />
              ))}
            </AreaChart>
          </ResponsiveContainer>
        );

      case 'BarChart':
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <BarChart data={chartData} margin={chartConfig.margin}>
              <CartesianGrid {...gridStyle} />
              <XAxis dataKey={xAxisKey} {...axisStyle} />
              <YAxis {...axisStyle} />
              <Tooltip />
              <Legend />
              {dataKeys.map((key, index) => (
                <Bar
                  key={key}
                  dataKey={key}
                  fill={COLORS[index % COLORS.length]}
                  animationDuration={400}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        );

      case 'PieChart':
        // Pie Chart 通常只使用一個數值欄位
        const pieDataKey = dataKeys[0] || 'value';
        // Mobile 時縮小圓餅圖
        const pieOuterRadius = isMobileView ? "50%" : "70%";
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={pieLabel as any}
                outerRadius={pieOuterRadius}
                dataKey={pieDataKey}
                nameKey={xAxisKey}
                animationBegin={0}
                animationDuration={400}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend content={renderPieLegend} />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'ScatterChart':
        // Scatter 需要 x, y 兩個數值欄位
        const xKey = dataKeys[0] || 'x';
        const yKey = dataKeys[1] || 'y';
        // 自訂 Tooltip 顯示點的名稱
        const ScatterTooltip = ({ active, payload }: { active?: any; payload?: any }) => {
          if (active && payload && payload.length) {
            const data = payload[0].payload;
            return (
              <div style={{
                backgroundColor: 'var(--surface)',
                padding: '8px 12px',
                border: '1px solid color-mix(in srgb, var(--on) 16%, transparent)',
                borderRadius: '4px'
              }}>
                <p style={{ margin: 0, fontWeight: 'bold', color: 'var(--on)' }}>
                  {data[xAxisKey] || ''}
                </p>
                <p style={{ margin: '4px 0 0', color: 'var(--on)' }}>
                  {xKey}: {data[xKey]}
                </p>
                <p style={{ margin: '4px 0 0', color: 'var(--on)' }}>
                  {yKey}: {data[yKey]}
                </p>
              </div>
            );
          }
          return null;
        };
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <ScatterChart margin={chartConfig.margin}>
              <CartesianGrid {...gridStyle} />
              <XAxis type="number" dataKey={xKey} name={xKey} {...axisStyle} />
              <YAxis type="number" dataKey={yKey} name={yKey} {...axisStyle} />
              <Tooltip content={<ScatterTooltip />} cursor={{ strokeDasharray: '3 3' }} />
              <Scatter name={chart.name || 'Data'} data={chartData} fill={COLORS[0]} animationDuration={400} />
            </ScatterChart>
          </ResponsiveContainer>
        );

      case 'RadarChart':
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
              <PolarGrid stroke={gridStyle.stroke} />
              <PolarAngleAxis dataKey={xAxisKey} {...axisStyle} />
              <PolarRadiusAxis {...axisStyle} />
              <Tooltip />
              <Legend />
              {dataKeys.map((key, index) => (
                <Radar
                  key={key}
                  name={key}
                  dataKey={key}
                  stroke={COLORS[index % COLORS.length]}
                  fill={COLORS[index % COLORS.length]}
                  fillOpacity={0.3}
                  animationDuration={400}
                />
              ))}
            </RadarChart>
          </ResponsiveContainer>
        );

      case 'RadialBarChart':
        const radialDataKey = dataKeys[0] || 'value';
        // 為 RadialBarChart 添加名稱欄位到資料中
        const radialData = chartData.map((item, index) => ({
          ...item,
          fill: COLORS[index % COLORS.length]
        }));
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <RadialBarChart
              cx="50%"
              cy="50%"
              innerRadius="10%"
              outerRadius="80%"
              data={radialData}
              startAngle={180}
              endAngle={0}
            >
              <RadialBar
                {...{
                  minAngle: 15,
                  label: {
                    position: 'insideStart' as const,
                    fill: '#fff',
                    formatter: (value: any) => {
                      const item = radialData.find((d: any) => d[radialDataKey] === value);
                      return item ? item[xAxisKey] : value;
                    }
                  },
                  background: true,
                  clockWise: true,
                  dataKey: radialDataKey,
                  animationDuration: 400
                } as any}
              />
              <Tooltip
                formatter={(value, name, props) => [value, props.payload[xAxisKey] || name]}
              />
              <Legend
                formatter={(value, entry) => entry.payload[xAxisKey] || value}
              />
            </RadialBarChart>
          </ResponsiveContainer>
        );

      case 'Treemap':
        const treemapDataKey = dataKeys[0] || 'size';
        // 自訂 Treemap 內容顯示名稱
        const TreemapContent = (props) => {
          const { x, y, width, height, index, name } = props;
          const displayName = props[xAxisKey] || name || '';
          return (
            <g>
              <rect
                x={x}
                y={y}
                width={width}
                height={height}
                style={{
                  fill: COLORS[index % COLORS.length],
                  stroke: '#fff',
                  strokeWidth: 2,
                }}
              />
              {width > 50 && height > 20 && (
                <text
                  x={x + width / 2}
                  y={y + height / 2}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="#fff"
                  fontSize={12}
                  fontWeight="bold"
                >
                  {displayName}
                </text>
              )}
            </g>
          );
        };
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <Treemap
              data={chartData}
              dataKey={treemapDataKey}
              nameKey={xAxisKey}
              aspectRatio={4 / 3}
              stroke="#fff"
              content={<TreemapContent />}
              animationDuration={400}
            >
              <Tooltip
                formatter={(value, name, props) => [value, props.payload[xAxisKey] || name]}
              />
            </Treemap>
          </ResponsiveContainer>
        );

      case 'FunnelChart':
        const funnelDataKey = dataKeys[0] || 'value';
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <FunnelChart>
              <Tooltip />
              <Funnel
                dataKey={funnelDataKey}
                data={chartData}
                isAnimationActive
                animationDuration={400}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
                <LabelList position="right" fill="#000" stroke="none" dataKey={xAxisKey} />
              </Funnel>
            </FunnelChart>
          </ResponsiveContainer>
        );

      case 'ComposedChart':
        // 組合圖：第一個 key 用 Bar，其餘用 Line
        return (
          <ResponsiveContainer width="100%" height={chartConfig.height} minHeight={chartConfig.minHeight}>
            <ComposedChart data={chartData} margin={chartConfig.margin}>
              <CartesianGrid {...gridStyle} />
              <XAxis dataKey={xAxisKey} {...axisStyle} />
              <YAxis {...axisStyle} />
              <Tooltip />
              <Legend />
              {dataKeys.map((key, index) => (
                index === 0 ? (
                  <Bar key={key} dataKey={key} fill={COLORS[index % COLORS.length]} animationDuration={400} />
                ) : (
                  <Line
                    key={key}
                    type="monotone"
                    dataKey={key}
                    stroke={COLORS[index % COLORS.length]}
                    strokeWidth={2}
                    animationDuration={400}
                  />
                )
              ))}
            </ComposedChart>
          </ResponsiveContainer>
        );

      default:
        return (
          <div className="chart-render chart-render-unsupported">
            <p>{t('unsupportedChartKind')}: {kind}</p>
          </div>
        );
    }
  };

  return (
    <div className="chart-render">
      <h4 className="chart-render-title">{chart.name || t('untitledChart')}</h4>
      <div className="chart-render-container">
        {isReady && renderChart()}
      </div>
    </div>
  );
}

// 自定義比較函數：只有當 chart 數據或 chartType 真正改變時才重新渲染
const arePropsEqual = (prevProps, nextProps) => {
  // 比較 chart
  if (prevProps.chart?.id !== nextProps.chart?.id) return false;

  // 比較 chart.data（深度比較）
  const prevData = JSON.stringify(prevProps.chart?.data);
  const nextData = JSON.stringify(nextProps.chart?.data);
  if (prevData !== nextData) return false;

  // 比較 chart.name
  if (prevProps.chart?.name !== nextProps.chart?.name) return false;

  // 比較 chartType
  if (prevProps.chartType?.id !== nextProps.chartType?.id) return false;
  if (prevProps.chartType?.kind !== nextProps.chartType?.kind) return false;

  return true;
};

export default memo(ChartRender, arePropsEqual);

