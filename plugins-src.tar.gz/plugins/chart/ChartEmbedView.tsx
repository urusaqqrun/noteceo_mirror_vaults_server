// ChartEmbedView — Chart 插件的嵌入式預覽渲染器
//
// 由 ChartPlugin 註冊到 EmbedRendererRegistry，
// 被 ItemEmbedExtension（editor 基礎設施）委派渲染。
// 取代原本的 NoteChartExtension。

import React, { useMemo, useState, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import ChartRender from './ChartRender';
import CustomDataTable from '../../common/CustomDataTable';
import { useChartsStore } from './chartStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import type { EmbedRendererProps } from '../../../Store/embedRendererRegistry';
import './NoteChartExtension.css';

const CHART_HEIGHT = 280;

const ChartEmbedView: React.FC<EmbedRendererProps> = ({ itemId }) => {
  const { t } = useTranslation();

  const charts = useItemStore(s => s.byType['CHART'] ?? []);
  const chartFolders = useItemStore(s => s.byType['CHART_FOLDER'] ?? []);

  const [isTableExpanded, setIsTableExpanded] = useState(false);
  const hasTableAnimatedRef = useRef(false);

  const chart = useMemo(() => charts.find(c => c.id === itemId), [charts, itemId]);

  const chartType = useMemo(() => {
    if (!chart) return null;
    return chart.parentID ? chartFolders.find(f => f.id === chart.parentID) || null : null;
  }, [chart, chartFolders]);

  const handleChartClick = useCallback((e) => {
    e.stopPropagation();
    if (!chart) return;
    const folderId = chart.parentID;
    if (folderId) {
      const folder = useItemStore.getState().getByType('CHART_FOLDER').find((f: any) => f.id === folderId);
      if (folder) useSelectedItemsStore.getState().setSelectedItems([folder], { scrollToFocusItem: true });
    }
  }, [chart]);

  const handleToggleTable = useCallback((e) => {
    e.stopPropagation();
    setIsTableExpanded(prev => {
      if (!prev) {
        setTimeout(() => { hasTableAnimatedRef.current = true; }, 250);
      }
      return !prev;
    });
  }, []);

  if (!chart) {
    return <div className="note-chart-extension-error">{t('chartNotFound')}</div>;
  }

  return (
    <div className="note-chart-extension-container" onClick={handleChartClick}>
      {/* 圖表區塊 */}
      <div className="note-chart-extension-chart-section" style={{ height: CHART_HEIGHT }}>
        <ChartRender
          chart={chart}
          chartType={chartType ? { ...chartType, kind: (chartType as any).kind || (chartType as any).chartKind } : null}
        />
      </div>

      {/* 展開表格按鈕 */}
      <div className="note-chart-extension-toggle-bar">
        <button
          className={`note-chart-extension-toggle-btn ${isTableExpanded ? 'expanded' : ''}`}
          onClick={handleToggleTable}
          title={isTableExpanded ? t('collapseTable') : t('expandTable')}
        >
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="note-chart-extension-toggle-icon">
            <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="note-chart-extension-toggle-text">
            {isTableExpanded ? t('collapseTable') : t('expandTable')}
          </span>
        </button>
      </div>

      {/* 表格區塊（可展開） */}
      {isTableExpanded && (
        <div className={`note-chart-extension-table-section ${!hasTableAnimatedRef.current ? 'animate' : ''}`}>
          <CustomDataTable {...({ chart: chart as any, showHeader: false } as any)} />
        </div>
      )}
    </div>
  );
};

export default ChartEmbedView;
