import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import ChartRender from './ChartRender';
import CustomDataTable from '../../common/CustomDataTable';
import CustomScrollbar from '../../common/CustomScrollbar';
import './ChartDetailPanel.css';

const DEFAULT_CHART_HEIGHT = 320;
const MIN_CHART_HEIGHT = 200;
const MIN_TABLE_HEIGHT = 100;

/**
 * ChartDetailPanel 組件
 * 顯示圖表詳情：圖表渲染區 + 可拖曳分隔線 + 數據表格區
 * 用於 ChartReportView 和 ChartWindowContent
 */
function ChartDetailPanel({
  chart,
  chartType,
  onUpdateChart,
  storageKey = 'chartDetailPanelHeight',
  className = ''
}) {
  const { t } = useTranslation();

  // 可拖曳分隔線：圖表區高度
  const [chartHeight, setChartHeight] = useState(() => {
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      const parsed = parseInt(saved, 10);
      if (!isNaN(parsed) && parsed >= MIN_CHART_HEIGHT) {
        return parsed;
      }
    }
    return DEFAULT_CHART_HEIGHT;
  });
  const [isResizing, setIsResizing] = useState(false);
  const panelRef = useRef(null);
  const resizeStartRef = useRef({ startY: 0, startHeight: 0 });

  // 拖曳分隔線：開始拖曳
  const handleResizeStart = useCallback((e) => {
    e.preventDefault();
    resizeStartRef.current = {
      startY: e.clientY,
      startHeight: chartHeight
    };
    setIsResizing(true);
  }, [chartHeight]);

  // 拖曳分隔線：拖曳中
  useEffect(() => {
    if (!isResizing) return;

    const handleMouseMove = (e) => {
      if (!panelRef.current) return;

      const panelRect = panelRef.current.getBoundingClientRect();
      const panelHeight = panelRect.height;

      // 計算滑鼠移動的差值
      const deltaY = e.clientY - resizeStartRef.current.startY;
      const newHeight = resizeStartRef.current.startHeight + deltaY;

      // 限制最小/最大高度
      const maxHeight = panelHeight - MIN_TABLE_HEIGHT;
      const clampedHeight = Math.max(MIN_CHART_HEIGHT, Math.min(maxHeight, newHeight));

      setChartHeight(clampedHeight);
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      // 保存到 localStorage
      localStorage.setItem(storageKey, chartHeight.toString());
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing, chartHeight, storageKey]);

  if (!chart || !chartType) {
    return (
      <div className="chart-detail-panel-no-chart">
        <p className="chart-detail-panel-empty-text">{t('noChartSelected')}</p>
      </div>
    );
  }

  return (
    <div
      className={`chart-detail-panel ${isResizing ? 'chart-detail-panel-resizing' : ''} ${className}`}
      ref={panelRef}
    >
      {/* 圖表渲染區 */}
      <div
        className="chart-detail-panel-render-section"
        style={{ height: chartHeight, minHeight: MIN_CHART_HEIGHT }}
      >
        <ChartRender
          chart={chart}
          chartType={chartType}
        />
      </div>

      {/* 可拖曳分隔線 */}
      <div
        className="chart-detail-panel-resize-handle"
        onMouseDown={handleResizeStart}
      >
        <div className="chart-detail-panel-resize-handle-line" />
      </div>

      {/* 數據表格區 */}
      <div className="chart-detail-panel-table-section">
        <CustomScrollbar>
          <CustomDataTable
            {...({ chart, onUpdateChart, chartType } as any)}
          />
        </CustomScrollbar>
      </div>
    </div>
  );
}

export default ChartDetailPanel;

