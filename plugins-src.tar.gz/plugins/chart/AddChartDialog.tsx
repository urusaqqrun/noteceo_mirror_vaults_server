import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import './AddChartDialog.css';
import CustomDataTable from '../../common/CustomDataTable';
import { useDialogStore } from '../../../Store/dialogStore';

/**
 * AddChartDialogData — Dialog Service 資料介面
 */
export interface AddChartDialogData {
  chartType: any;
  editChart?: any;
  referenceChart?: any;
  onConfirm: (chartData: any) => void;
}

/**
 * AddChartDialog 組件（純 UI 化）
 * 從 dialogStore['addChart'].data 讀取配置
 * - 新增模式：editChart 為 undefined
 * - 編輯模式：editChart 為現有圖表資料
 */
const AddChartDialog: React.FC = () => {
  const { t } = useTranslation();
  const isOpen = useDialogStore(state => state.dialogs['addChart']?.show);
  const dialogData = useDialogStore(state => state.dialogs['addChart']?.data) as AddChartDialogData | null;
  const onClose = () => useDialogStore.getState().close('addChart');

  const chartType = dialogData?.chartType ?? null;
  const editChart = dialogData?.editChart ?? null;
  const referenceChart = dialogData?.referenceChart ?? null;
  const onConfirm = dialogData?.onConfirm ?? null;

  // 表單狀態
  const [chartName, setChartName] = useState('');
  // 內部使用 key/values 形式渲染表格（與 CustomDataTable 格式一致）
  const [chartData, setChartData] = useState([]); // { key: string, values: (string|number)[] }[]
  const [isSubmitting, setIsSubmitting] = useState(false);

  // 推斷出的欄位（用於編輯模式：把既有資料對應回原本欄位）
  const [xKey, setXKey] = useState('name');
  const [yKeys, setYKeys] = useState(['value']); // 改為陣列以支援多欄位
  const [valueIsNumber, setValueIsNumber] = useState(true);

  const nameInputRef = useRef(null);

  // 初始化表單數據
  useEffect(() => {
    if (editChart) {
      setChartName(editChart.name || '');
      // data 可能是字串或陣列
      let parsedData = [];
      try {
        parsedData = typeof editChart.data === 'string'
          ? JSON.parse(editChart.data || '[]')
          : (editChart.data || []);
      } catch (e) {
        console.error('解析圖表數據失敗:', e);
        parsedData = [];
      }

      // 推斷 xKey（第一個 string 欄位）與 yKeys（所有 number 欄位）
      const firstRow = Array.isArray(parsedData) && parsedData.length > 0 ? parsedData[0] : null;
      if (firstRow && typeof firstRow === 'object' && !Array.isArray(firstRow)) {
        const keys = Object.keys(firstRow);
        const inferredX = keys.find(k => typeof firstRow[k] === 'string') || keys[0] || 'name';
        const numericKeys = keys.filter(k => typeof firstRow[k] === 'number' && k !== inferredX);
        const inferredYKeys = numericKeys.length > 0 ? numericKeys : keys.filter(k => k !== inferredX).slice(0, 1);
        if (inferredYKeys.length === 0) inferredYKeys.push('value');
        const inferredValueIsNumber = typeof firstRow[inferredYKeys[0]] === 'number' || numericKeys.length > 0;

        setXKey(inferredX);
        setYKeys(inferredYKeys);
        setValueIsNumber(inferredValueIsNumber);

        // 轉成內部表格格式（key/values）
        setChartData(
          (parsedData || []).map(row => ({
            key: row?.[inferredX] ?? '',
            values: inferredYKeys.map(yk => row?.[yk] ?? '')
          }))
        );
      } else {
        // 無法推斷（空資料或非物件陣列）
        setXKey(t('key'));
        setYKeys([t('value')]);
        setValueIsNumber(true);
        setChartData([{ key: '', values: [''] }]);
      }
    } else {
      setChartName('');

      // 新增模式：如果同類別已有圖表，先帶入其表頭
      if (referenceChart?.data) {
        let parsedData = [];
        try {
          parsedData = typeof referenceChart.data === 'string'
            ? JSON.parse(referenceChart.data || '[]')
            : (referenceChart.data || []);
        } catch (e) {
          console.error('解析參考圖表數據失敗:', e);
          parsedData = [];
        }

        const firstRow = Array.isArray(parsedData) && parsedData.length > 0 ? parsedData[0] : null;
        if (firstRow && typeof firstRow === 'object' && !Array.isArray(firstRow)) {
          const keys = Object.keys(firstRow);
          const inferredX = keys.find(k => typeof firstRow[k] === 'string') || keys[0] || 'name';
          const numericKeys = keys.filter(k => typeof firstRow[k] === 'number' && k !== inferredX);
          const inferredYKeys = numericKeys.length > 0 ? numericKeys : keys.filter(k => k !== inferredX).slice(0, 1);
          if (inferredYKeys.length === 0) inferredYKeys.push('value');
          const inferredValueIsNumber = typeof firstRow[inferredYKeys[0]] === 'number' || numericKeys.length > 0;

          setXKey(inferredX);
          setYKeys(inferredYKeys);
          setValueIsNumber(inferredValueIsNumber);
        } else {
          setXKey(t('key'));
          setYKeys([t('value')]);
          setValueIsNumber(true);
        }
      } else {
        setXKey(t('key'));
        setYKeys([t('value')]);
        setValueIsNumber(true);
      }

      setChartData([{ key: '', values: [''] }]); // 預設一行空數據
    }
  }, [editChart, referenceChart, t]);

  // CustomDataTable 的 onChange 回調
  const handleTableChange = useCallback(({ chartData: newData, xKey: newXKey, yKeys: newYKeys, valueIsNumber: newValueIsNumber }) => {
    if (newData !== undefined) setChartData(newData);
    if (newXKey !== undefined) setXKey(newXKey);
    if (newYKeys !== undefined) setYKeys(newYKeys);
    if (newValueIsNumber !== undefined) setValueIsNumber(newValueIsNumber);
  }, []);

  // 提交表單
  const handleSubmit = async () => {
    if (!chartName.trim()) {
      return;
    }

    setIsSubmitting(true);
    try {
      const normalizedXKey = (xKey || '').trim() || t('key');
      const normalizedYKeys = yKeys.map((yk, i) => {
        let normalized = (yk || '').trim() || `value${i + 1}`;
        if (normalized === normalizedXKey) {
          normalized = `${normalized}_${i + 1}`;
        }
        return normalized;
      });

      // 過濾掉空行
      const filteredData = chartData.filter(row => {
        const k = (row.key ?? '').toString().trim();
        const hasValue = (row.values || []).some(v => {
          const vStr = v === null || v === undefined ? '' : v.toString().trim();
          return vStr !== '';
        });
        return k || hasValue;
      });

      // 轉回 ChartRender/ChartTable 使用的物件格式
      const payloadData = filteredData.map(row => {
        const out = {};
        out[normalizedXKey] = (row.key ?? '').toString();

        normalizedYKeys.forEach((yk, i) => {
          const v = row.values?.[i];
          if (valueIsNumber) {
            const n = typeof v === 'number' ? v : parseFloat((v ?? '').toString());
            out[yk] = Number.isFinite(n) ? n : 0;
          } else {
            out[yk] = v ?? '';
          }
        });

        return out;
      });

      if (editChart) {
        // 編輯模式
        if (onConfirm) {
          await onConfirm({
            ...editChart,
            name: chartName.trim(),
            data: payloadData
          });
        }
      } else {
        // 新增模式
        if (onConfirm) {
          await onConfirm({
            name: chartName.trim(),
            parentID: chartType?.id,
            data: payloadData
          });
        }
      }
      onClose();
    } catch (error) {
      console.error('保存圖表失敗:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="add-chart-dialog-overlay" onClick={onClose}>
      <div className="add-chart-dialog" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="add-chart-dialog-header">
          <h3>{editChart ? t('editChart') : t('addChart')}</h3>
          <button className="add-chart-close-btn" onClick={onClose}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        {/* Body */}
        <div className="add-chart-dialog-body">
          {/* 圖表名稱 */}
          <div className="add-chart-field">
            <label className="add-chart-label">{t('chartName')}</label>
            <input
              ref={nameInputRef}
              type="text"
              className="add-chart-input"
              value={chartName}
              onChange={(e) => setChartName(e.target.value)}
              placeholder={t('enterChartName')}
            />
          </div>

          {/* 數據表格 */}
          <div className="add-chart-field">
            <label className="add-chart-label">{t('chartData')}</label>

            {/* 使用 CustomDataTable 組件（受控模式） */}
            <CustomDataTable
              {...({ chartData, xKey, yKeys, valueIsNumber, onChange: handleTableChange, chartType, showHeader: false } as any)}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="add-chart-dialog-footer">
          <button className="custom-secondary-button" onClick={onClose}>
            {t('cancel')}
          </button>
          <button
            className="custom-primary-button"
            onClick={handleSubmit}
            disabled={isSubmitting || !chartName.trim()}
          >
            {isSubmitting ? t('saving') : t('confirm')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddChartDialog;
