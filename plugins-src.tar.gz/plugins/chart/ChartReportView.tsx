import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './ChartReportView.css';

import { useChartsStore, Chart } from './chartStore';
import type { BaseItem } from '../../../types/item';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useListKeyboardNav } from '../../../hooks/useListKeyboardNav';
import { useTempHintStore, useMobileSidebarStore } from '../../../Store/uiStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';

import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import ChartList from './ChartList';
import ChartDetailPanel from './ChartDetailPanel';
import MobileTopbar from '../../common/MobileTopbar';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import syncService from '../../../utils/syncService';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import { useDialogStore } from '../../../Store/dialogStore';

const STORAGE_KEY = 'chartReportViewChartHeight';

/**
 * ChartReportView 組件
 * 當用戶點擊圖表資料夾時，取代 NoteList 和 NoteEditor 顯示
 * 左側為 ChartList（圖表列表），右側為圖表詳情（ChartRender + ChartTable）
 */
function ChartReportView() {
  const { t } = useTranslation();

  const setIsMobileSidebarOpen = useMobileSidebarStore(state => state.setIsMobileSidebarOpen);
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
  // 統一使用 store 的 selectedFolderId
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const charts = useItemStore(s => s.getByType('CHART')) as Chart[];
  const addChart = useChartsStore(state => state.addChart);
  const updateChart = useChartsStore(state => state.updateChart);
  const deleteChart = useChartsStore(state => state.deleteChart);
  const chartFolders = useItemStore(s => s.getByType('CHART_FOLDER'));

  const setTempHint = useTempHintStore(state => state.setTempHint);

  // 當前選中的 Chart（從 lastSelected 推導）
  const selectedChartId = lastSelected?.itemType === 'CHART' ? lastSelected.id : null;

  // 手機版響應式
  const isMobileView = useIsMobileView();
  const [isMobileDetailVisible, setIsMobileDetailVisible] = useState(false);

  // 手機版圖表更多選單狀態
  const [mobileChartMenuPosition, setMobileChartMenuPosition] = useState(null);
  // 手機版選擇圖表時顯示詳情
  const handleSelectChart = useCallback((chartId) => {
    if (chartId) {
      const c = useItemStore.getState().getByType('CHART').find(c => c.id === chartId);
      if (c) setSelectedItems([c]);
    } else {
      setSelectedItems([]);
    }
    if (isMobileView && chartId) {
      setIsMobileDetailVisible(true);
    }
  }, [isMobileView, setSelectedItems]);

  // 手機版返回列表
  const handleMobileBack = useCallback(() => {
    setIsMobileDetailVisible(false);
  }, []);

  // 切換資料夾時重置手機版詳情狀態
  useEffect(() => {
    setIsMobileDetailVisible(false);
  }, [selectedFolderId]);

  // 當前 ChartType（從 folders 取得）
  const currentChartType = useMemo(() => {
    if (!selectedFolderId) return null;
    return chartFolders.find(f => f.id === selectedFolderId) || null;
  }, [selectedFolderId, chartFolders]);

  // 過濾該類型下的 Charts，依 orderAt 或 createdAt 排序
  const filteredCharts = useMemo(() => {
    if (!selectedFolderId) return [];
    const typeCharts = charts.filter(c => c.parentID === selectedFolderId);
    const getOrderValue = (c: Chart) => {
      if (c.orderAt && !isNaN(parseFloat(String(c.orderAt)))) return parseFloat(String(c.orderAt));
      return parseFloat(String(c.createdAt)) || 0;
    };
    return [...typeCharts].sort((a, b) => getOrderValue(b) - getOrderValue(a));
  }, [selectedFolderId, charts]);

  const filteredChartIds = useMemo(() => filteredCharts.map(c => c.id), [filteredCharts]);

  const isChartSelected = useCallback(
    () => useSelectedItemsStore.getState().path.at(-1)?.itemType === 'CHART',
    [],
  );

  useListKeyboardNav({
    prefix: 'chart-list',
    sortedIds: filteredChartIds,
    isActive: isChartSelected,
    onNavigateLeft: () => useSelectedItemsStore.getState().navigateOut(),
    labels: {
      up: t('cmd.chartListUp'),
      down: t('cmd.chartListDown'),
      shiftUp: t('cmd.chartListShiftUp'),
      shiftDown: t('cmd.chartListShiftDown'),
      left: t('cmd.chartListLeft'),
      right: t('cmd.chartListRight'),
    },
  });

  // 當前選中的 Chart 數據
  const selectedChart = useMemo(() => {
    if (!selectedChartId) return null;
    return filteredCharts.find(c => c.id === selectedChartId) || null;
  }, [selectedChartId, filteredCharts]);

  // 當前選中的 chart 被刪除時，fallback 到第一個
  React.useEffect(() => {
    if (!selectedChartId) return;
    if (!filteredCharts.find(c => c.id === selectedChartId)) {
      const fallback = filteredCharts[0];
      setSelectedItems(fallback ? [fallback] : []);
    }
  }, [filteredCharts, selectedChartId, setSelectedItems]);

  // 處理拖曳排序（依 orderAt 更新）
  const handleReorderCharts = useCallback(async (newCharts: Chart[]) => {
    if (!newCharts.length) return;
    const baseOrder = Date.now();
    const updates = newCharts.map((c, i) => ({ ...c, orderAt: baseOrder - i * 1000 }));
    await updateChart(updates);
    syncService.syncChanges();
  }, [updateChart]);

  // 處理刪除圖表
  const handleDeleteChart = useCallback(async (chartId) => {
    if (!chartId) return;

    if (selectedChartId === chartId) {
      setSelectedItems([]);
    }

    await deleteChart(chartId);
    syncService.syncChanges();
  }, [selectedChartId, deleteChart]);

  // 處理新增圖表
  const handleAddChart = useCallback(async (chartData) => {
    if (!chartData || !selectedFolderId) return;

    const newChartId = generateObjectID();
    const chartWithId = {
      ...chartData,
      id: newChartId,
      parentID: selectedFolderId
    };

    await addChart(chartWithId);
    syncService.syncChanges();
  }, [addChart, selectedFolderId]);

  // 處理更新圖表
  const handleUpdateChart = useCallback(async (chartData) => {
    if (!chartData) return;

    await updateChart(chartData);

    // 同步變更
    syncService.syncChanges();
  }, [updateChart]);

  // 手機版：複製圖表連結
  const handleMobileCopyChartLink = useCallback(async () => {
    if (selectedChartId && currentChartType) {
      const kind = (currentChartType as any)?.chartKind || 'LineChart';
      const link = `cubelv://chart/${selectedChartId}?kind=${kind}`;
      try {
        await navigator.clipboard.writeText(link);
        setTempHint(t('chartLinkCopied'));
      } catch (error) {
        console.error('複製圖表連結失敗:', error);
      }
    }
    setMobileChartMenuPosition(null);
  }, [selectedChartId, currentChartType, setTempHint, t]);

  // 手機版：刪除圖表
  const handleMobileDeleteChart = useCallback(() => {
    if (selectedChartId) {
      handleDeleteChart(selectedChartId);
      setIsMobileDetailVisible(false);
    }
    setMobileChartMenuPosition(null);
  }, [selectedChartId, handleDeleteChart]);

  // 手機版：編輯圖表
  const handleMobileEditChart = useCallback(() => {
    setMobileChartMenuPosition(null);
    if (selectedChart) {
      useDialogStore.getState().open('addChart', {
        chartType: currentChartType,
        editChart: selectedChart,
        onConfirm: handleUpdateChart,
      });
    }
  }, [selectedChart, currentChartType, handleUpdateChart]);

  // 空狀態：沒有選中 ChartType
  if (!selectedFolderId || !currentChartType) {
    return (
      <div className="chart-report-view chart-report-view-empty">
        <p className="chart-report-view-empty-text">{t('selectChartFolder')}</p>
      </div>
    );
  }

  return (
    <div className="chart-report-view">
      {/* 左側：ChartList */}
      <div className={`chart-report-view-list-panel ${isMobileView && isMobileDetailVisible ? 'mobile-hidden' : ''}`}>
        <ChartList
          chartType={currentChartType}
          charts={filteredCharts}
          selectedChartId={selectedChartId}
          onSelectChart={handleSelectChart}
          onReorderCharts={handleReorderCharts}
          onDeleteChart={handleDeleteChart}
          onAddChart={handleAddChart}
          onUpdateChart={handleUpdateChart}
          isMobileView={isMobileView}
          onMobileMenuClick={() => setIsMobileSidebarOpen(true)}
        />
      </div>

      {/* 右側：ChartReportDetail */}
      <div
        className={`chart-report-view-detail-panel ${isMobileView && isMobileDetailVisible ? 'mobile-visible' : ''}`}
      >
        {/* 手機版頂部列 */}
        {isMobileView && isMobileDetailVisible && (
          <MobileTopbar
            leftIcon="back"
            onLeftClick={handleMobileBack}
            title={selectedChart?.name || t('untitledChart')}
            rightContent={
              <button
                className="mobile-topbar-button"
                tabIndex={-1}
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  setMobileChartMenuPosition({ x: rect.right, y: rect.bottom + 4 });
                }}
              >
                <MoreIcon />
              </button>
            }
          />
        )}



        <ChartDetailPanel
          chart={selectedChart}
          chartType={currentChartType}
          onUpdateChart={handleUpdateChart}
          storageKey={STORAGE_KEY}
        />
      </div>

      {/* 手機版圖表更多選單 */}
      {mobileChartMenuPosition && (
        <PopupMenu
          x={mobileChartMenuPosition.x}
          y={mobileChartMenuPosition.y}
          onClose={() => setMobileChartMenuPosition(null)}
        >
          <PopupMenuItem onClick={handleMobileEditChart}>
            {t('editChart')}
          </PopupMenuItem>
          <PopupMenuItem onClick={handleMobileCopyChartLink}>
            {t('copyChartLink')}
          </PopupMenuItem>
          <PopupMenuItem danger onClick={handleMobileDeleteChart}>
            {t('deleteChart')}
          </PopupMenuItem>
        </PopupMenu>
      )}

    </div>
  );
}

export default ChartReportView;

