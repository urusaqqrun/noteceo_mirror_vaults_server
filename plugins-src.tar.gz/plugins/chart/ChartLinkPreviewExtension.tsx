/**
 * ChartLinkPreviewExtension
 * 
 * 從 TemplateLinkPreviewExtension 拆出的圖表連結預覽擴展。
 * 偵測 cubelv://chart/xxx 連結，在連結後面插入展開預覽按鈕。
 * 歸屬 ChartPlugin，由 ChartPlugin.onload() 註冊到 editorExtensionRegistry。
 */
import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { useTranslation } from 'react-i18next';
import ChartRender from './ChartRender';
import CustomDataTable from '../../common/CustomDataTable';
import { getIconByName } from '../../common/IconRegistry';
import { useChartsStore } from './chartStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';

// localStorage key 前綴
const COLLAPSED_TEMPLATES_KEY = 'cubelv_collapsed_templates';

const getCollapsedTemplates = () => {
    try {
        const stored = localStorage.getItem(COLLAPSED_TEMPLATES_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const saveCollapsedTemplates = (collapsedList) => {
    try {
        localStorage.setItem(COLLAPSED_TEMPLATES_KEY, JSON.stringify(collapsedList));
    } catch (e) {
        console.error('Failed to save collapsed templates to localStorage:', e);
    }
};

const isTemplateCollapsed = (noteId, templateId) => {
    const key = `${noteId}-chart-${templateId}`;
    return getCollapsedTemplates().includes(key);
};

const setTemplateCollapsed = (noteId, templateId, collapsed) => {
    const key = `${noteId}-chart-${templateId}`;
    const list = getCollapsedTemplates();
    if (collapsed) {
        if (!list.includes(key)) { list.push(key); saveCollapsedTemplates(list); }
    } else {
        const idx = list.indexOf(key);
        if (idx > -1) { list.splice(idx, 1); saveCollapsedTemplates(list); }
    }
};

const CHART_PREVIEW_HEIGHT = 280;

// 圖表連結預覽元件
const ChartLinkPreview = ({ chartId, noteId }) => {
    const { t } = useTranslation();
    const [isExpanded, setIsExpanded] = useState(() => !isTemplateCollapsed(noteId, chartId));
    const [isTableExpanded, setIsTableExpanded] = useState(false);
    const hasAnimatedRef = useRef(isExpanded);
    const hasTableAnimatedRef = useRef(false);

    const charts = useItemStore(state => state.getByType('CHART'));
    const chartFolders = useItemStore(state => state.getByType('CHART_FOLDER'));

    const item = charts.find(c => c.id === chartId);
    const itemType = item ? chartFolders.find(ct => ct.id === (item as any).parentID) : null;

    const ChartIcon = useMemo(() => {
        if (!(itemType as any)?.kind) return null;
        return getIconByName((itemType as any).kind);
    }, [(itemType as any)?.kind]);

    const handleToggle = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const newExpanded = !isExpanded;
        setIsExpanded(newExpanded);
        setTemplateCollapsed(noteId, chartId, !newExpanded);
    };

    useEffect(() => {
        if (isExpanded) {
            const timer = setTimeout(() => { hasAnimatedRef.current = true; }, 250);
            return () => clearTimeout(timer);
        }
    }, [isExpanded]);

    const handleToggleTable = useCallback((e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsTableExpanded(prev => {
            if (!prev) {
                setTimeout(() => { hasTableAnimatedRef.current = true; }, 250);
            }
            return !prev;
        });
    }, []);

    const handleChartClick = useCallback((e) => {
        e.stopPropagation();
        if (!item) return;
        if ((item as any).parentID) {
            const folder = useItemStore.getState().getByType('CHART_FOLDER').find(f => f.id === (item as any).parentID);
            if (folder) useSelectedItemsStore.getState().setSelectedItems([folder], { scrollToFocusItem: true });
        }
    }, [item]);

    return (
        <>
            <button
                className={`template-link-expand-btn ${isExpanded ? 'expanded' : ''}`}
                onClick={handleToggle}
                onMouseDown={(e) => e.preventDefault()}
                title={isExpanded ? t('collapseChart') : t('expandChart')}
            >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="template-link-expand-icon">
                    <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            </button>
            {isExpanded && (
                <div className={`chart-gallery-item template-link-preview-item ${!hasAnimatedRef.current ? 'animate' : ''}`}>
                    {item && itemType ? (
                        <div className="chart-link-preview-container" onClick={handleChartClick}>
                            {/* 圖表區塊 */}
                            <div className="chart-link-preview-chart-section" style={{ height: CHART_PREVIEW_HEIGHT }}>
                                <ChartRender chart={item} chartType={itemType} />
                            </div>

                            {/* 展開表格按鈕 */}
                            <div className="chart-link-preview-toggle-bar">
                                <button
                                    className={`chart-link-preview-toggle-btn ${isTableExpanded ? 'expanded' : ''}`}
                                    onClick={handleToggleTable}
                                    title={isTableExpanded ? t('collapseTable') : t('expandTable')}
                                >
                                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="chart-link-preview-toggle-icon">
                                        <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                                    </svg>
                                    <span className="chart-link-preview-toggle-text">
                                        {isTableExpanded ? t('collapseTable') : t('expandTable')}
                                    </span>
                                </button>
                            </div>

                            {/* 表格區塊（可展開） */}
                            {isTableExpanded && (
                                <div
                                    className={`chart-link-preview-table-section ${!hasTableAnimatedRef.current ? 'animate' : ''}`}
                                    onClick={(e) => e.stopPropagation()}
                                >
                                    <CustomDataTable {...({ chart: item, showHeader: false } as any)} />
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="template-link-preview-not-found">{t('chartNotFound')}</div>
                    )}
                </div>
            )}
        </>
    );
};

// 建立展開按鈕 DOM
const createChartExpandButton = (chartId, noteId) => {
    const container = document.createElement('span');
    container.className = 'template-link-preview-root';
    container.setAttribute('data-template-id', chartId);
    container.setAttribute('data-mode', 'chart');
    container.contentEditable = 'false';

    const root = ReactDOM.createRoot(container);
    root.render(<ChartLinkPreview chartId={chartId} noteId={noteId} />);
    (container as any)._reactRoot = root;
    return container;
};

const isChartLink = (href) => href?.toLowerCase().startsWith('cubelv://chart/');
const extractChartId = (href) => {
    const match = href.match(/cubelv:\/\/chart\/([^?#]+)/i);
    return match ? match[1] : null;
};

export const ChartLinkPreviewExtension = Extension.create({
    name: 'chartLinkPreview',

    addOptions() {
        return { getNoteId: () => null };
    },

    addProseMirrorPlugins() {
        const key = new PluginKey('chartLinkPreview');
        const { getNoteId } = this.options;

        const buildDecorations = (doc) => {
            const decos = [];
            const noteId = getNoteId();

            doc.descendants((node, pos) => {
                if (!node.isText) return true;
                const linkMark = node.marks.find(m => m.type.name === 'link');
                if (linkMark && isChartLink(linkMark.attrs.href)) {
                    const chartId = extractChartId(linkMark.attrs.href);
                    if (chartId && noteId) {
                        decos.push(Decoration.widget(
                            pos + node.nodeSize,
                            () => createChartExpandButton(chartId, noteId),
                            { side: 1, key: `template-preview-chart-${chartId}-${noteId}` }
                        ));
                    }
                }
                return true;
            });

            return DecorationSet.create(doc, decos);
        };

        return [
            new Plugin({
                key,
                state: {
                    init: (_, editorState) => buildDecorations(editorState.doc),
                    apply: (tr, oldState, oldEditorState, newEditorState) => {
                        return buildDecorations(newEditorState.doc);
                    }
                },
                props: {
                    decorations(state) { return this.getState(state); },
                },
            }),
        ];
    },
});

export default ChartLinkPreviewExtension;
