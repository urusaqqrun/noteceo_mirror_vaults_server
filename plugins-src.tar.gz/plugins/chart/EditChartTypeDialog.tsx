/**
 * EditChartTypeDialog — 編輯圖表類型的純 UI 化 Dialog
 *
 * 從 dialogStore['editChartType'].data 讀取配置
 * 切換操作透過 onConfirm callback 傳入
 */
import React from 'react';
import { useDialogStore } from '../../../Store/dialogStore';
import AddChartTypeDialog from './AddChartTypeDialog';

export interface EditChartTypeDialogData {
  chartType: any;
  onConfirm: () => void;
}

const EditChartTypeDialog: React.FC = () => {
  const isOpen = useDialogStore(state => state.dialogs['editChartType']?.show);
  const dialogData = useDialogStore(state => state.dialogs['editChartType']?.data) as EditChartTypeDialogData | null;
  const onClose = () => useDialogStore.getState().close('editChartType');

  if (!isOpen || !dialogData?.chartType) return null;

  return (
    <AddChartTypeDialog
      isEdit={true}
      initialData={dialogData.chartType}
      onClose={onClose}
      onConfirm={dialogData.onConfirm ?? (() => {})}
    />
  );
};

export default EditChartTypeDialog;
