// ===== ChartPlugin — 图表插件 =====
//
// 掛載條件：selectedItems 最後一項的 itemType 是 CHART_FOLDER 或 CHART
//
// 面板配置：
//   centerPane1 → leaf-chartlist   (chart-list，size:280，min:200)
//   centerPane2 → leaf-chartdetail (chart-detail，flex:1，min:360)

import React from 'react';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import chartEn from './locales/en.json';
import chartZhHant from './locales/zh-Hant.json';
import chartJa from './locales/ja.json';
import { useTranslation } from 'react-i18next';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useChartsStore } from './chartStore';
import { useItemStore } from '../../../Store/itemStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { eventBus } from '../../../Store/eventBus';
import i18n from '../../../i18n/config';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import { getIconByName } from '../../common/IconRegistry';
import type { BaseItem } from '../../../types/item';
import CardFolderIcon from '../../../assets/icon_card_folder_24.svg?react';
import ChartIcon from '../../../assets/chart/icon_chart_barchart.svg?react';
import AddChartTypeDialog from './AddChartTypeDialog';
import { CustomDialog } from '../../common/CustomDialog';
import ChartListView from './ChartListView';
import ChartDetailView from './ChartDetailView';
import { ChartLinkPreviewExtension } from './ChartLinkPreviewExtension';
import ChartEmbedView from './ChartEmbedView';
import { registerEmbedRenderer } from '../../../Store/embedRendererRegistry';
import { registerWindowComponent } from '../../../workspace/windowComponentRegistry';
import ChartWindowContent from './ChartWindowContent';
import AddChartDialog from './AddChartDialog';
import EditChartTypeDialog from './EditChartTypeDialog';
import ContributorsDialog from '../../common/share/ContributorsDialog';
const ChartDeleteFolderDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['deleteFolder']?.show);
    const folder = useDialogStore(state => state.dialogs['deleteFolder']?.data?.folder);

    if (!showDialog || !folder || (folder.itemType !== 'CHART_FOLDER' && !(folder as any).isChartFolder)) return null;

    const hideDialog = () => useDialogStore.getState().close('deleteFolder');

    const handleConfirm = async () => {
        try {
            await useChartsStore.getState().deleteChartFolder(folder.id);

            const chartFolders = useItemStore.getState().getByType('CHART_FOLDER');
            const remaining = chartFolders.filter(f => f.id !== folder.id);
            if (remaining.length > 0) {
                useSelectedItemsStore.getState().setSelectedItems([remaining[0]], { scrollToFocusItem: true });
            }
            useTempHintStore.getState().setTempHint(t('deletedChartType', { name: folder.name }));
            hideDialog();
        } catch (error) {
            console.error('刪除失敗:', error);
            useTempHintStore.getState().setTempHint(t('deleteFailed'));
        }
    };

    return (
        <CustomDialog isOpen onClose={hideDialog} title={t('deleteChartType')} onConfirm={handleConfirm}>
            <p className="custom-dialog-description">
                {t('deleteChartTypeConfirm', { name: folder.name })}
            </p>
        </CustomDialog>
    );
};

// sidebar section 資料 hook
// ⚠️ Sidebar item 規範：所有 item（items / prefixItems / suffixItems）的 itemType 必須以 _FOLDER 結尾，否則不會顯示
function useChartSidebarData() {
    const chartFolders = useItemStore(s => s.byType['CHART_FOLDER'] ?? []);
    const charts = useItemStore(s => s.byType['CHART'] ?? []);

    const items = React.useMemo(
        () => chartFolders as BaseItem[],
        [chartFolders],
    );

    const getCount = React.useCallback((item: BaseItem) => {
        const count = charts.filter(c => (c as any).parentID === item.id).length;
        return { value: count };
    }, [charts]);

    const renderIcon = React.useCallback((item: BaseItem) => {
        // 用 kind 取得圖表類型圖示（LineChart, BarChart, PieChart 等）
        const kind = (item as any).chartKind || (item as any).kind;
        const KindIcon = kind ? getIconByName(kind) : null;
        if (KindIcon) return <KindIcon className="folder-icon" />;
        return <CardFolderIcon className="folder-icon" />;
    }, []);

    return { items, getCount, renderIcon };
}

class ChartListViewWrapper extends ReactView {
    getViewType() { return 'chart-list'; }
    getDisplayText() { return '圖表列表'; }
    renderComponent() { return <ChartListView />; }
}

class ChartDetailViewWrapper extends ReactView {
    getViewType() { return 'chart-detail'; }
    getDisplayText() { return '圖表詳情'; }
    renderComponent() { return <ChartDetailView />; }
}

const ChartContextMenu: React.FC = () => {
    const menu = useMenuStore(state => state.menus['sidebarChartFolder']);
    const { t } = useTranslation();
    if (!menu?.show) return null;

    const close = () => useMenuStore.getState().close('sidebarChartFolder');
    const folder = menu.data?.folder;

    const handleEdit = () => {
        useDialogStore.getState().open('addTemplate', { mode: 'chart', folder });
        close();
    };
    const handleDelete = () => {
        const isFolderGroup = Array.isArray(folder?.children) && folder.children.length > 0;
        if (isFolderGroup) {
            useDialogStore.getState().open('sidebar:deleteGroup', {
                folder: { ...folder, name: folder?.name, isChartFolder: true }
            });
        } else {
            useDialogStore.getState().open('deleteFolder', {
                folder: { ...folder, name: folder?.name, isChartFolder: true }
            });
        }
        close();
    };

    return (
        <PopupMenu x={menu.position.x} y={menu.position.y} onClose={close}>
            <PopupMenuItem onClick={handleEdit}>
                {t('editChartType')}
            </PopupMenuItem>
            <PopupMenuItem onClick={handleDelete}>
                {t('deleteChartType')}
            </PopupMenuItem>
        </PopupMenu>
    );
};

const ChartTemplateDialog: React.FC = () => {
    const showDialog = useDialogStore(state => state.dialogs['addTemplate']?.show);
    const dialogData = useDialogStore(state => state.dialogs['addTemplate']?.data);

    if (!showDialog || dialogData?.mode !== 'chart') return null;

    const handleClose = () => useDialogStore.getState().close('addTemplate');

    return (
        <AddChartTypeDialog
            onClose={handleClose}
            onConfirm={handleClose}
            isEdit={!!dialogData?.folder}
            initialData={dialogData?.folder || null}
        />
    );
};

export class ChartPlugin extends Plugin {
    onload() {
        this.registerWindowView('CHART', 'chart-report', {
            width: 800, height: 900, minWidth: 400, minHeight: 300,
        });
        this.registerOverlay('chartContextMenu', ChartContextMenu);
        this.registerOverlay('chartTemplateDialog', ChartTemplateDialog);
        this.registerOverlay('chartDeleteFolderDialog', ChartDeleteFolderDialog);
        this.registerOverlay('addChartDialog', AddChartDialog);
        this.registerOverlay('editChartTypeDialog', EditChartTypeDialog);
        this.registerOverlay('contributorsDialog', ContributorsDialog);

        // 註冊 embed renderer：圖表嵌入式預覽（透過 ItemEmbedExtension 委派渲染）
        registerEmbedRenderer('CHART', { component: ChartEmbedView });

        // 註冊 editor 擴展：圖表連結預覽
        this.registerEditorExtension('chart:chartLinkPreview', ChartLinkPreviewExtension);

        // 圖表拖到 MarkdownEditor：插入圖表連結
        this.registerEvent('drop:markdown-editor', async (items: any[], _meta: any, editor: any, dropPos: number) => {
            const chartItems = items.filter(i => i.itemType === 'CHART');
            if (chartItems.length === 0 || !editor || dropPos == null) return;
            for (const item of chartItems) {
                const linkText = item.name || i18n.t('untitledChart');
                const chartLink = `cubelv://chart/${item.id}`;
                editor.chain().insertContentAt(dropPos, {
                    type: 'text',
                    text: linkText,
                    marks: [{ type: 'link', attrs: { href: chartLink, class: 'editor-link', target: '_blank' } }]
                }).run();
            }
        });

        this.registerSidebarWithView({
            sidebar: {
                id: 'chart',
                title: i18n.t('charts'),
                orderAt: 500,
                useData: useChartSidebarData,
                addFolder: {
                    actionText: i18n.t('addChartFolder'),
                    icon: <ChartIcon />,
                    onClick: () => useDialogStore.getState().open('addTemplate', { mode: 'chart' }),
                },
            },
            views: [
                { type: 'chart-list', creator: (leaf) => new ChartListViewWrapper(leaf) },
                { type: 'chart-detail', creator: (leaf) => new ChartDetailViewWrapper(leaf) },
            ],
            activateOnItemTypes: ['CHART_FOLDER', 'CHART'],
            panes: {
                centerPane1: { leafId: 'leaf-chartlist', viewType: 'chart-list', size: 280, minSize: 200 },
                centerPane2: { leafId: 'leaf-chartdetail', viewType: 'chart-detail', flex: 1, minSize: 360 },
            },
        });

        // 註冊搜尋 provider
        this.registerSearchProvider('CHART', {
            renderIcon: () => <ChartIcon />,
            search: (query) => {
                const charts = useItemStore.getState().getByType('CHART');
                const q = query.toLowerCase();
                return charts.filter(c => {
                    if (!query) return true;
                    return c.name?.toLowerCase().includes(q)
                        || JSON.stringify((c as any).data || []).toLowerCase().includes(q);
                });
            },
        });
        this.registerSearchProvider('CHART_FOLDER', {
            renderIcon: (item) => {
                const kind = (item as any).chartKind || (item as any).kind;
                const KindIcon = kind ? getIconByName(kind) : null;
                if (KindIcon) return <KindIcon />;
                return <CardFolderIcon />;
            },
            search: (query) => {
                const chartFolders = useItemStore.getState().getByType('CHART_FOLDER');
                const q = query.toLowerCase();
                return chartFolders.filter(f => !query || f.name?.toLowerCase().includes(q));
            },
        });

        // 右鍵選單
        this.registerEvent('contextMenu', ({ item, event }: { item: BaseItem; event: React.MouseEvent }) => {
            if (item.itemType !== 'CHART_FOLDER') return;
            const scale = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim()) || 1;
            useMenuStore.getState().openAt('sidebarChartFolder', event.clientX / scale, event.clientY / scale, {
                folder: item, isGroup: false,
            });
        });

        // 註冊 AI Skill：圖表模板生成與調整
        this.registerAISkill({
            name: 'chart_template',
            instruction: `# 圖表模板生成與調整

## 建立新模板

根據圖表類型定義生成 HTML + CSS row template。

輸入：
- Chart Type（資料夾名稱）
- Fields（欄位定義 JSON）
- Style Hint（用戶設計提示，可選）

## 調整現有模板

根據用戶指示修改現有模板的 HTML/CSS。

輸入：
- Current HTML + CSS
- Fields
- Adjustment（調整指示）

## 規則（建立和調整共用）

- ALL CSS class names MUST start with "chart-template-" prefix to avoid conflicts
- NO emojis at all. If one emoji appears, output is invalid
- Use exact field names as placeholders: {{fieldName}}
- Each placeholder appears once and only once
- Width and height both auto (adaptive to content)
- Use modern CSS (flex/grid, rounded corners, shadow)
- Prevent overflow: word-wrap: break-word; overflow-wrap: break-word; overflow: hidden
- Design for tabular/row-based data display (each row is one data entry)

Available field types (only 5):
- TEXT: Labels, categories, dimensions
- TEXTAREA: Notes, descriptions
- NUMBER: Numeric values, measures
- DATE: Single date (YYYY/MM/DD)
- DATERANGE: Date range (YYYY/MM/DD ~ YYYY/MM/DD)

## Colors

- Background: var(--surface)
- Text: var(--on)
- Chart colors: custom colors as needed
- Use color-mix() for transparency

## Icons

- No emoji
- Icons inherit color and size
- Use Google Material Symbols only: <span class="g-icon">icon_name</span>
- Icon and text must be vertically centered (use align-items: center)

## Output

- Return ONLY one JSON object
- Format: {"templateHtml":"...","templateCss":"..."}
- No text before or after JSON`,
        });

        // AI Hints
        this.registerAIHints('CHART_FOLDER', [
            '當使用者要求建立新的圖表資料夾、或調整現有圖表的模板樣式時，先讀取 .skills/chart_template.md 取得 templateHtml/templateCss 的生成規則',
            '建立圖表資料夾時必須定義欄位（chartFieldsDef），再依照 .skills/chart_template.md 的規則生成 templateHtml 和 templateCss',
        ]);
    }
}

registerWindowComponent('chart-report', ChartWindowContent);
registerPluginClass(ChartPlugin, '圖表', {
    dependencies: ['SidebarPlugin'],
    descriptionKey: 'modulesChartDesc',
    setupI18n: () => registerPluginLocales('ChartPlugin', { 'en': chartEn, 'zh-Hant': chartZhHant, 'ja': chartJa }),
});
