import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './ChartReportView.css';

/**
 * ChartTable 組件
 * 以表格形式顯示 Chart 的原始數據
 */
function ChartTable({ chart, chartType }) {
  const { t } = useTranslation();

  // 解析 chart.data（JSON 字串）
  const chartData = useMemo(() => {
    if (!chart?.data) return [];
    try {
      const parsed = typeof chart.data === 'string' ? JSON.parse(chart.data) : chart.data;
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.error('解析圖表數據失敗:', e);
      return [];
    }
  }, [chart?.data]);

  // 從數據中提取所有欄位名稱
  const columns = useMemo(() => {
    if (chartData.length === 0) return [];
    // 合併所有行的 keys
    const allKeys = new Set<string>();
    chartData.forEach(row => {
      Object.keys(row).forEach(key => allKeys.add(key));
    });
    return Array.from(allKeys);
  }, [chartData]);

  // 無數據狀態
  if (chartData.length === 0) {
    return (
      <div className="chart-table chart-table-empty">
        <p>{t('noChartData')}</p>
      </div>
    );
  }

  return (
    <div className="chart-table">
      <h4 className="chart-table-title">{t('chartData')}</h4>
      <div className="chart-table-container custom-scrollbar-content">
        <table className="chart-table-table">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col} className="chart-table-th">{col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {chartData.map((row, rowIndex) => (
              <tr key={rowIndex} className="chart-table-tr">
                {columns.map(col => (
                  <td key={col} className="chart-table-td">
                    {row[col] !== undefined ? String(row[col]) : '-'}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ChartTable;

