// ===== ChartDetailView — 自包含的圖表詳情 View =====
// 用於 workspace 的 centerPane2，從 store 自行取資料

import React, { useMemo, useCallback, useState } from 'react';
import { useTranslation } from 'react-i18next';

import './ChartReportView.css';
import { useChartsStore, type Chart } from './chartStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { useDialogStore } from '../../../Store/dialogStore';
import { useTempHintStore } from '../../../Store/uiStore';
import syncService from '../../../utils/syncService';

import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import ChartDetailPanel from './ChartDetailPanel';
import MobileTopbar from '../../common/MobileTopbar';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';

const STORAGE_KEY = 'chartReportViewChartHeight';

/**
 * ChartDetailView — 自包含圖表詳情
 * 直接從 store 取所有資料，不需要 props
 */
function ChartDetailView() {
  const { t } = useTranslation();
  const isMobileView = useIsMobileView();
  const setTempHint = useTempHintStore(state => state.setTempHint);

  // Navigation state
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);

  // Data from stores
  const charts = useItemStore(s => s.getByType('CHART')) as Chart[];
  const chartFolders = useItemStore(s => s.getByType('CHART_FOLDER'));
  const updateChart = useChartsStore(state => state.updateChart);
  const deleteChart = useChartsStore(state => state.deleteChart);

  // Current selected chart
  const selectedChartId = lastSelected?.itemType === 'CHART' ? lastSelected.id : null;

  // Current ChartType (from folders)
  const currentChartType = useMemo(() => {
    if (!selectedFolderId) return null;
    return chartFolders.find(f => f.id === selectedFolderId) || null;
  }, [selectedFolderId, chartFolders]);

  // Filter charts for current folder & find selected
  const filteredCharts = useMemo(() => {
    if (!selectedFolderId) return [];
    const typeCharts = charts.filter(c => c.parentID === selectedFolderId);
    const getOrderValue = (c: Chart) => {
      if (c.orderAt && !isNaN(parseFloat(String(c.orderAt)))) return parseFloat(String(c.orderAt));
      return parseFloat(String(c.createdAt)) || 0;
    };
    return [...typeCharts].sort((a, b) => getOrderValue(b) - getOrderValue(a));
  }, [selectedFolderId, charts]);

  const selectedChart = useMemo(() => {
    if (!selectedChartId) return null;
    return filteredCharts.find(c => c.id === selectedChartId) || null;
  }, [selectedChartId, filteredCharts]);

  // Mobile detail visibility: in split-pane mode, detail is always visible on desktop
  // On mobile, we show when a chart is selected
  const [isMobileDetailVisible, setIsMobileDetailVisible] = useState(false);

  // Show detail when chart selected on mobile
  React.useEffect(() => {
    if (isMobileView && selectedChartId) {
      setIsMobileDetailVisible(true);
    }
  }, [isMobileView, selectedChartId]);

  // Reset on folder change
  React.useEffect(() => {
    setIsMobileDetailVisible(false);
  }, [selectedFolderId]);

  // Mobile menu state
  const [mobileChartMenuPosition, setMobileChartMenuPosition] = useState<{ x: number; y: number } | null>(null);

  // Handlers
  const handleUpdateChart = useCallback(async (chartData: any) => {
    if (!chartData) return;
    await updateChart(chartData);
    syncService.syncChanges();
  }, [updateChart]);

  const handleDeleteChart = useCallback(async (chartId: string) => {
    if (!chartId) return;
    if (selectedChartId === chartId) {
      useSelectedItemsStore.getState().setSelectedItems([]);
    }
    await deleteChart(chartId);
    syncService.syncChanges();
  }, [selectedChartId, deleteChart]);

  // Mobile: copy chart link
  const handleMobileCopyChartLink = useCallback(async () => {
    if (selectedChartId && currentChartType) {
      const kind = (currentChartType as any)?.chartKind || 'LineChart';
      const link = `cubelv://chart/${selectedChartId}?kind=${kind}`;
      try {
        await navigator.clipboard.writeText(link);
        setTempHint(t('chartLinkCopied'));
      } catch (error) {
        console.error('複製圖表連結失敗:', error);
      }
    }
    setMobileChartMenuPosition(null);
  }, [selectedChartId, currentChartType, setTempHint, t]);

  // Mobile: delete chart
  const handleMobileDeleteChart = useCallback(() => {
    if (selectedChartId) {
      handleDeleteChart(selectedChartId);
      setIsMobileDetailVisible(false);
    }
    setMobileChartMenuPosition(null);
  }, [selectedChartId, handleDeleteChart]);

  // Mobile: edit chart
  const handleMobileEditChart = useCallback(() => {
    setMobileChartMenuPosition(null);
    if (selectedChart) {
      useDialogStore.getState().open('addChart', {
        chartType: currentChartType,
        editChart: selectedChart,
        onConfirm: handleUpdateChart,
      });
    }
  }, [selectedChart, currentChartType, handleUpdateChart]);

  // Mobile: back
  const handleMobileBack = useCallback(() => {
    setIsMobileDetailVisible(false);
  }, []);

  return (
    <div className="chart-report-view-detail-panel">
      {/* 手機版頂部列 */}
      {isMobileView && isMobileDetailVisible && (
        <MobileTopbar
          leftIcon="back"
          onLeftClick={handleMobileBack}
          title={selectedChart?.name || t('untitledChart')}
          rightContent={
            <button
              className="mobile-topbar-button"
              tabIndex={-1}
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                setMobileChartMenuPosition({ x: rect.right, y: rect.bottom + 4 });
              }}
            >
              <MoreIcon />
            </button>
          }
        />
      )}

      <ChartDetailPanel
        chart={selectedChart}
        chartType={currentChartType}
        onUpdateChart={handleUpdateChart}
        storageKey={STORAGE_KEY}
      />

      {/* 手機版圖表更多選單 */}
      {mobileChartMenuPosition && (
        <PopupMenu
          x={mobileChartMenuPosition.x}
          y={mobileChartMenuPosition.y}
          onClose={() => setMobileChartMenuPosition(null)}
        >
          <PopupMenuItem onClick={handleMobileEditChart}>
            {t('editChart')}
          </PopupMenuItem>
          <PopupMenuItem onClick={handleMobileCopyChartLink}>
            {t('copyChartLink')}
          </PopupMenuItem>
          <PopupMenuItem danger onClick={handleMobileDeleteChart}>
            {t('deleteChart')}
          </PopupMenuItem>
        </PopupMenu>
      )}
    </div>
  );
}

export default ChartDetailView;
