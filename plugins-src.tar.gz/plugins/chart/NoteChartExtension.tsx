import { Node, mergeAttributes } from '@tiptap/core';
import { ReactNodeViewRenderer, NodeViewWrapper } from '@tiptap/react';
import React, { useMemo, useState, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import ChartRender from './ChartRender';
import CustomDataTable from '../../common/CustomDataTable';
import { useChartsStore } from './chartStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import './NoteChartExtension.css';

// 固定的圖表高度
const CHART_HEIGHT = 280;

/**
 * NoteChartComponent - 圖表預覽組件
 * 用於在筆記編輯器中顯示圖表連結的展開預覽
 * 支援二段式展開：展開圖表卡片 -> 可選展開表格
 */
const NoteChartComponent = ({ node }) => {
  const { t } = useTranslation();
  const chartId = node.attrs.chartId;

  // 從 store 取得圖表資料
  const charts = useItemStore(state => state.getByType('CHART'));
  const chartFolders = useItemStore(state => state.getByType('CHART_FOLDER'));

  // 表格展開狀態（預設關閉）
  const [isTableExpanded, setIsTableExpanded] = useState(false);
  // 追蹤是否已播放過動畫
  const hasTableAnimatedRef = useRef(false);

  // 取得當前圖表
  const chart = useMemo(() => {
    return charts.find(c => c.id === chartId);
  }, [charts, chartId]);

  // 取得圖表類型（從 folders）
  const chartType = useMemo(() => {
    if (!chart) return null;
    return chart.parentID ? chartFolders.find(f => f.id === chart.parentID) || null : null;
  }, [chart, chartFolders]);

  // 點擊圖表卡片時導航到圖表
  const handleChartClick = useCallback((e) => {
    e.stopPropagation();
    if (!chart) return;

    const folderId = chart.parentID;
    if (folderId) {
      const folder = useItemStore.getState().getByType('CHART_FOLDER').find(f => f.id === folderId);
      if (folder) useSelectedItemsStore.getState().setSelectedItems([folder], { scrollToFocusItem: true });
    }
  }, [chart]);

  // 切換表格展開狀態
  const handleToggleTable = useCallback((e) => {
    e.stopPropagation();
    setIsTableExpanded(prev => {
      if (!prev) {
        // 展開時，延遲標記已動畫
        setTimeout(() => {
          hasTableAnimatedRef.current = true;
        }, 250);
      }
      return !prev;
    });
  }, []);

  // 如果找不到圖表
  if (!chartId) {
    return (
      <NodeViewWrapper className="note-chart-wrapper">
        <div className="note-chart-extension-error">
          {t('invalidChartId')}
        </div>
      </NodeViewWrapper>
    );
  }

  if (!chart) {
    return (
      <NodeViewWrapper className="note-chart-wrapper">
        <div className="note-chart-extension-error">
          {t('chartNotFound')}
        </div>
      </NodeViewWrapper>
    );
  }

  return (
    <NodeViewWrapper className="note-chart-wrapper">
      <div
        className="note-chart-extension-container"
        onClick={handleChartClick}
      >
        {/* 圖表區塊 */}
        <div
          className="note-chart-extension-chart-section"
          style={{ height: CHART_HEIGHT }}
        >
          <ChartRender
            chart={chart}
            chartType={chartType ? { ...chartType, kind: (chartType as any).kind || (chartType as any).chartKind } : null}
          />
        </div>

        {/* 展開表格按鈕 */}
        <div className="note-chart-extension-toggle-bar">
          <button
            className={`note-chart-extension-toggle-btn ${isTableExpanded ? 'expanded' : ''}`}
            onClick={handleToggleTable}
            title={isTableExpanded ? t('collapseTable') : t('expandTable')}
          >
            <svg
              width="12"
              height="12"
              viewBox="0 0 12 12"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="note-chart-extension-toggle-icon"
            >
              <path
                d="M2.5 4.5L6 8L9.5 4.5"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className="note-chart-extension-toggle-text">
              {isTableExpanded ? t('collapseTable') : t('expandTable')}
            </span>
          </button>
        </div>

        {/* 表格區塊（可展開） */}
        {isTableExpanded && (
          <div className={`note-chart-extension-table-section ${!hasTableAnimatedRef.current ? 'animate' : ''}`}>
            <CustomDataTable
              {...({
                chart: chart as any,
                showHeader: false,
              } as any)}
            />
          </div>
        )}
      </div>
    </NodeViewWrapper>
  );
};

/**
 * NoteChartExtension - TipTap 圖表節點擴展
 * 在筆記中以區塊形式顯示圖表
 */
export const NoteChartExtension = Node.create({
  name: 'noteChart',
  group: 'block',
  selectable: false,
  atom: true,

  addAttributes() {
    return {
      chartId: {
        default: null,
        parseHTML: element => element.getAttribute('chart-id'),
        renderHTML: attributes => {
          if (!attributes.chartId) return {};
          return {
            'chart-id': attributes.chartId,
          };
        },
      },
    };
  },

  parseHTML() {
    return [
      {
        tag: 'note-chart',
        getAttrs: element => ({
          chartId: element.getAttribute('chart-id'),
        }),
      },
    ];
  },

  renderHTML({ HTMLAttributes }) {
    return ['note-chart', mergeAttributes(HTMLAttributes)];
  },

  addNodeView() {
    return ReactNodeViewRenderer(NoteChartComponent);
  },
});

export default NoteChartExtension;

