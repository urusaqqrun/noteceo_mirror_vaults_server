// ===== ChartListView — 自包含的圖表列表 View =====
// 用於 workspace 的 centerPane1，從 store 自行取資料

import React, { useMemo, useCallback, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { useChartsStore, type Chart } from './chartStore';
import './ChartReportView.css';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useMobileSidebarStore } from '../../../Store/uiStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { useListKeyboardNav } from '../../../hooks/useListKeyboardNav';
import syncService from '../../../utils/syncService';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';

import ChartList from './ChartList';

/**
 * ChartListView — 自包含圖表列表
 * 直接從 store 取所有資料，不需要 props
 */
function ChartListView() {
  const { t } = useTranslation();
  const isMobileView = useIsMobileView();
  const setIsMobileSidebarOpen = useMobileSidebarStore(state => state.setIsMobileSidebarOpen);

  // Navigation state
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);

  // Data from stores
  const charts = useItemStore(s => s.getByType('CHART')) as Chart[];
  const chartFolders = useItemStore(s => s.getByType('CHART_FOLDER'));
  const addChart = useChartsStore(state => state.addChart);
  const updateChart = useChartsStore(state => state.updateChart);
  const deleteChart = useChartsStore(state => state.deleteChart);

  // Current selected chart
  const selectedChartId = lastSelected?.itemType === 'CHART' ? lastSelected.id : null;

  // Current ChartType (folder)
  const currentChartType = useMemo(() => {
    if (!selectedFolderId) return null;
    return chartFolders.find(f => f.id === selectedFolderId) || null;
  }, [selectedFolderId, chartFolders]);

  // Filter & sort charts for current folder
  const filteredCharts = useMemo(() => {
    if (!selectedFolderId) return [];
    const typeCharts = charts.filter(c => c.parentID === selectedFolderId);
    const getOrderValue = (c: Chart) => {
      if (c.orderAt && !isNaN(parseFloat(String(c.orderAt)))) return parseFloat(String(c.orderAt));
      return parseFloat(String(c.createdAt)) || 0;
    };
    return [...typeCharts].sort((a, b) => getOrderValue(b) - getOrderValue(a));
  }, [selectedFolderId, charts]);

  const filteredChartIds = useMemo(() => filteredCharts.map(c => c.id), [filteredCharts]);

  // Keyboard navigation
  const isChartSelected = useCallback(
    () => useSelectedItemsStore.getState().path.at(-1)?.itemType === 'CHART',
    [],
  );

  useListKeyboardNav({
    prefix: 'chart-list',
    sortedIds: filteredChartIds,
    isActive: isChartSelected,
    onNavigateLeft: () => useSelectedItemsStore.getState().navigateOut(),
    labels: {
      up: t('cmd.chartListUp'),
      down: t('cmd.chartListDown'),
      shiftUp: t('cmd.chartListShiftUp'),
      shiftDown: t('cmd.chartListShiftDown'),
      left: t('cmd.chartListLeft'),
      right: t('cmd.chartListRight'),
    },
  });

  // Fallback to first chart when selected chart is deleted
  useEffect(() => {
    if (!selectedChartId) return;
    if (!filteredCharts.find(c => c.id === selectedChartId)) {
      const fallback = filteredCharts[0];
      setSelectedItems(fallback ? [fallback] : []);
    }
  }, [filteredCharts, selectedChartId, setSelectedItems]);

  // Handlers
  const handleSelectChart = useCallback((chartId: string | null) => {
    if (chartId) {
      const c = useItemStore.getState().getByType('CHART').find(c => c.id === chartId);
      if (c) setSelectedItems([c]);
    } else {
      setSelectedItems([]);
    }
  }, [setSelectedItems]);

  const handleReorderCharts = useCallback(async (newCharts: Chart[]) => {
    if (!newCharts.length) return;
    const baseOrder = Date.now();
    const updates = newCharts.map((c, i) => ({ ...c, orderAt: baseOrder - i * 1000 }));
    await updateChart(updates);
    syncService.syncChanges();
  }, [updateChart]);

  const handleDeleteChart = useCallback(async (chartId: string) => {
    if (!chartId) return;
    if (selectedChartId === chartId) {
      setSelectedItems([]);
    }
    await deleteChart(chartId);
    syncService.syncChanges();
  }, [selectedChartId, deleteChart, setSelectedItems]);

  const handleAddChart = useCallback(async (chartData: any) => {
    if (!chartData || !selectedFolderId) return;
    const newChartId = generateObjectID();
    const chartWithId = {
      ...chartData,
      id: newChartId,
      parentID: selectedFolderId
    };
    await addChart(chartWithId);
    syncService.syncChanges();
  }, [addChart, selectedFolderId]);

  const handleUpdateChart = useCallback(async (chartData: any) => {
    if (!chartData) return;
    await updateChart(chartData);
    syncService.syncChanges();
  }, [updateChart]);

  // Empty state
  if (!selectedFolderId || !currentChartType) {
    return (
      <div className="chart-report-view chart-report-view-empty">
        <p className="chart-report-view-empty-text">{t('selectChartFolder')}</p>
      </div>
    );
  }

  return (
    <ChartList
      chartType={currentChartType}
      charts={filteredCharts}
      selectedChartId={selectedChartId}
      onSelectChart={handleSelectChart}
      onReorderCharts={handleReorderCharts}
      onDeleteChart={handleDeleteChart}
      onAddChart={handleAddChart}
      onUpdateChart={handleUpdateChart}
      isMobileView={isMobileView}
      onMobileMenuClick={() => setIsMobileSidebarOpen(true)}
    />
  );
}

export default ChartListView;
