import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import ChartDetailPanel from './ChartDetailPanel';
import { useChartsStore } from './chartStore';
import { useItemStore } from '../../../Store/itemStore';
import syncService from '../../../utils/syncService';
import type { WindowComponentProps } from '../../../workspace/windowComponentRegistry';

const STORAGE_KEY = 'chartWindowChartHeight';

function ChartWindowContent({ itemId }: WindowComponentProps) {
    const { t } = useTranslation();
    const charts = useItemStore(state => state.getByType('CHART'));
    const chartFolders = useItemStore(state => state.getByType('CHART_FOLDER'));
    const updateChart = useChartsStore(state => state.updateChart);

    const handleUpdateChart = useCallback(async (chartData: any) => {
        if (!chartData) return;
        await updateChart(chartData);
        syncService.syncChanges();
    }, [updateChart]);

    const chart = charts.find(c => c.id === itemId);
    const chartType = chart
        ? chartFolders.find(f => f.id === chart.parentID)
        : null;

    if (!chart || !chartType) {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', color: 'var(--on)' }}>
                {t('chartNotFound')}
            </div>
        );
    }

    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: 'var(--editorBackground)' }}>
            <ChartDetailPanel
                chart={chart}
                chartType={chartType}
                onUpdateChart={handleUpdateChart}
                storageKey={STORAGE_KEY}
            />
        </div>
    );
}

export default ChartWindowContent;
