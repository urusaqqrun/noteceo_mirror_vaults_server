import React, { useState, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './ChartReportView.css';
import { getIconByName } from '../../common/IconRegistry';
import type { BaseItem } from '../../../types/item';

import { eventBus } from '../../../Store/eventBus';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import CustomToolbar from '../../common/CustomToolbar';
import type { ToolbarButton } from '../../common/CustomToolbar';
import MenuIcon from '../../../assets/icon_menu_24.svg?react';
import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import PlusIcon from '../../../assets/icon_plus_24.svg?react';
import ShareCollabIcon from '../../../assets/icon_share_setting_24.svg?react';
import EditIcon from '../../../assets/icon_edit_24.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_fill_20_n.svg?react';
import { useDialogStore } from '../../../Store/dialogStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { ShareMemberThumbnailList } from '../../common/share/ShareMemberThumbnailList';
import { canAccessSharingDialog } from '../../../utils/shareUtils';
import { updateItemShareSettings } from '../../../utils/shareAPI';
import syncService from '../../../utils/syncService';


/**
 * ChartList 組件
 * 顯示該 ChartType 下所有 Chart 的列表
 * 支援拖曳調整順序、右鍵選單刪除/編輯
 */
function ChartList({ chartType, charts, selectedChartId, onSelectChart, onReorderCharts, onDeleteChart, onAddChart, onUpdateChart, isMobileView, onMobileMenuClick }) {
  const { t } = useTranslation();
  const setTempHint = useTempHintStore(state => state.setTempHint);
  // 統一使用 store 的 selectedFolderId
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const chartFolders = useItemStore(s => s.byType['CHART_FOLDER'] ?? []);


  // 當前選中的 chart folder（從 chartFolders 取得）
  const selectedChartFolder = useMemo(() => {
    if (!selectedFolderId) return null;
    return chartFolders.find(f => f.id === selectedFolderId) || null;
  }, [selectedFolderId, chartFolders]);

  // 拖曳狀態
  const [draggedChartId, setDraggedChartId] = useState(null);
  const [dragOverChartId, setDragOverChartId] = useState(null);
  const [dragPosition, setDragPosition] = useState(null); // 'above' 或 'below'

  // 右鍵選單狀態
  const [contextMenu, setContextMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    chartId: null
  });

  // EventBus: 圖表拖到 AICommander 的 drop handler
  useEffect(() => {
    const unsub = eventBus.on('drop:ai-commander:chart', (e: any, addAttachment: any, attachedItems: any, inputAreaRef: any) => {
      const chartData = e.dataTransfer.getData('application/cubelv-chart');
      if (!chartData) return;
      try {
        const chart = JSON.parse(chartData);
        if (!attachedItems.some((item: any) => item.id === chart.id && item.type === 'chart')) {
          addAttachment(chart);
          if (inputAreaRef.current?.closeSaveMode) inputAreaRef.current.closeSaveMode();
        }
      } catch (error) { console.error('解析圖表資料失敗:', error); }
    });
    return unsub;
  }, []);

  // 手機版更多選單狀態
  const [moreMenuPosition, setMoreMenuPosition] = useState(null);

  // 取得 ChartType 圖標
  const ChartIcon = chartType?.chartKind ? getIconByName(chartType.chartKind) : null;

  // 拖曳開始
  const handleDragStart = (e, chartId) => {
    setDraggedChartId(chartId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', chartId);
    e.currentTarget.classList.add('chart-list-item-dragging');

    // 設置 chart 資料供 AICommander 使用
    const chart = charts.find(c => c.id === chartId);
    if (chart) {
      const chartData = JSON.stringify({
        id: chart.id,
        name: chart.name,
        parentID: chart.parentID,
        chartTypeName: (chartType as any)?.name || '',
        data: (chart as any).data
      });
      e.dataTransfer.setData('application/cubelv-chart', chartData);
      e.dataTransfer.setData('sourceType', 'chart');
      e.dataTransfer.setData('dragItems', JSON.stringify([chart]));



      eventBus.emit('drag:note-editor-drag-overlay', { icon: EditIcon, text: t('insertLink') });
      eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: t('dragToAttach', '拖曳放置後附加') });
    }
  };

  // 拖曳經過其他項目
  const handleDragOver = (e, chartId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';

    if (!draggedChartId || chartId === draggedChartId) return;

    // 計算滑鼠位置決定上方或下方
    const rect = e.currentTarget.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const position = e.clientY < midY ? 'above' : 'below';

    setDragOverChartId(chartId);
    setDragPosition(position);
  };

  // 拖曳離開
  const handleDragLeave = (e) => {
    const relatedTarget = e.relatedTarget;
    if (!e.currentTarget.contains(relatedTarget)) {
      setDragOverChartId(null);
      setDragPosition(null);
    }
  };

  // 拖曳放下
  const handleDrop = (e, targetChartId) => {
    e.preventDefault();

    if (!draggedChartId || !targetChartId || draggedChartId === targetChartId) {
      setDraggedChartId(null);
      setDragOverChartId(null);
      setDragPosition(null);
      return;
    }

    // 重新排序
    const draggedIndex = charts.findIndex(c => c.id === draggedChartId);
    const targetIndex = charts.findIndex(c => c.id === targetChartId);

    if (draggedIndex === -1 || targetIndex === -1) {
      setDraggedChartId(null);
      setDragOverChartId(null);
      setDragPosition(null);
      return;
    }

    const newCharts = [...charts];
    const [draggedChart] = newCharts.splice(draggedIndex, 1);

    // 計算插入位置
    let insertIndex = targetIndex;
    if (draggedIndex < targetIndex) {
      insertIndex = dragPosition === 'above' ? targetIndex - 1 : targetIndex;
    } else {
      insertIndex = dragPosition === 'above' ? targetIndex : targetIndex + 1;
    }

    newCharts.splice(insertIndex, 0, draggedChart);

    // 通知父組件更新順序
    if (onReorderCharts) {
      onReorderCharts(newCharts);
    }

    // 清除拖曳狀態
    setDraggedChartId(null);
    setDragOverChartId(null);
    setDragPosition(null);
  };

  // 拖曳結束
  const handleDragEnd = (e) => {
    e.currentTarget.classList.remove('chart-list-item-dragging');
    setDraggedChartId(null);
    setDragOverChartId(null);
    setDragPosition(null);


    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  };

  // 右鍵選單處理
  const handleContextMenu = (e, chartId) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      chartId
    });
  };

  // 關閉右鍵選單
  const closeContextMenu = () => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0,
      chartId: null
    });
  };

  // 刪除圖表
  const handleDelete = () => {
    if (contextMenu.chartId && onDeleteChart) {
      onDeleteChart(contextMenu.chartId);
    }
    closeContextMenu();
  };

  // 編輯圖表（從右鍵選單）
  const handleEdit = () => {
    const chart = charts.find(c => c.id === contextMenu.chartId);
    if (chart) {
      useDialogStore.getState().open('addChart', {
        chartType,
        editChart: chart,
        onConfirm: onUpdateChart,
      });
    }
    closeContextMenu();
  };

  // 複製圖表連結（包含 kind 參數以便顯示正確圖標）
  const handleCopyChartLink = async () => {
    if (contextMenu.chartId) {
      const kind = chartType?.chartKind || 'LineChart';
      const link = `cubelv://chart/${contextMenu.chartId}?kind=${kind}`;
      try {
        await navigator.clipboard.writeText(link);
        setTempHint(t('chartLinkCopied'));
      } catch (error) {
        console.error('複製圖表連結失敗:', error);
      }
    }
    closeContextMenu();
  };

  // 新增圖表
  const handleAddClick = () => {
    // 新增模式：如果同類別已有圖表，先帶入表頭（優先選中的圖表）
    const ref = charts.find(c => c.id === selectedChartId) || charts[0] || null;
    useDialogStore.getState().open('addChart', {
      chartType,
      referenceChart: ref,
      onConfirm: onAddChart,
    });
  };

  // 打開共用設定
  const handleOpenShareSettings = () => {
    if (!selectedChartFolder) return;
    useDialogStore.getState().open('sharing', {
      item: { id: selectedChartFolder.id, name: selectedChartFolder.name, isPublic: (selectedChartFolder as any).isPublic, itemType: selectedChartFolder.itemType },
      onSave: async (settings) => {
        await updateItemShareSettings({ ...settings, extra: {} });
        await syncService.syncChanges();
        setTempHint(settings.isPublic ? t('shareEnabled') : t('shareDisabled'));
      },
    });
  };

  // 組裝右側按鈕
  const rightButtons: ToolbarButton[] = [];

  if (selectedChartFolder && canAccessSharingDialog(selectedChartFolder)) {
    rightButtons.push({
      icon: <ShareCollabIcon />,
      onClick: handleOpenShareSettings,
      title: t('shareSettings'),
    });
  }

  rightButtons.push(
    { icon: <PlusIcon />, onClick: handleAddClick, title: t('addChart') },
  );

  return (
    <div className="chart-list">
      {/* 標題區 */}
      <CustomToolbar
        className="chart-list-header"
        borderBottom
        left={{
          buttons: isMobileView ? [{ icon: <MenuIcon />, onClick: onMobileMenuClick }] : [],
          suffix: (
            <>
              {ChartIcon && <ChartIcon className="chart-list-header-icon" />}
              <h3 className="chart-list-title">{chartType?.name || t('charts')}</h3>
              {selectedChartFolder && (
                <ShareMemberThumbnailList itemId={selectedChartFolder.id} permissions={selectedChartFolder._permissions || []} maxDisplay={10} />
              )}
            </>
          ),
        }}
        right={{
          buttons: [
            ...rightButtons,
            ...(isMobileView
              ? [{
                  node: (
                    <button
                      className="custom-toolbar-button"
                      tabIndex={-1}
                      onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                        const rect = e.currentTarget.getBoundingClientRect();
                        setMoreMenuPosition({ x: rect.right, y: rect.bottom + 4 });
                      }}
                    >
                      <MoreIcon />
                    </button>
                  ),
                }]
              : []),
          ] as ToolbarButton[],
        }}
      />

      {/* 列表區 */}
      <div className="chart-list-content custom-scrollbar-content">
        {charts.length === 0 ? (
          <div className="chart-list-empty">
            <p>{t('noChartsYet')}</p>
          </div>
        ) : (
          <div className="chart-list-item-list">
            {charts.map(chart => (
              <div
                key={chart.id}
                className={`chart-list-item ${selectedChartId === chart.id ? 'chart-list-item-selected' : ''} ${draggedChartId === chart.id ? 'chart-list-item-dragging' : ''} ${dragOverChartId === chart.id ? `chart-list-item-drag-over chart-list-item-drag-${dragPosition}` : ''}`}
                draggable
                onDragStart={(e) => handleDragStart(e, chart.id)}
                onDragOver={(e) => handleDragOver(e, chart.id)}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, chart.id)}
                onDragEnd={handleDragEnd}
                onClick={() => {

                  onSelectChart(chart.id);
                }}
                onContextMenu={(e) => handleContextMenu(e, chart.id)}
              >
                <span className="chart-list-item-name">{chart.name || t('untitledChart')}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 右鍵選單 */}
      {contextMenu.visible && (
        <PopupMenu x={contextMenu.x} y={contextMenu.y} onClose={closeContextMenu}>
          <PopupMenuItem onClick={handleEdit}>
            {t('editChart')}
          </PopupMenuItem>
          <PopupMenuItem onClick={handleCopyChartLink}>
            {t('copyChartLink')}
          </PopupMenuItem>
          <PopupMenuItem danger onClick={handleDelete}>
            {t('deleteChart')}
          </PopupMenuItem>
        </PopupMenu>
      )}



      {/* 手機版更多選單 */}
      {moreMenuPosition && (
        <PopupMenu
          x={moreMenuPosition.x}
          y={moreMenuPosition.y}
          onClose={() => setMoreMenuPosition(null)}
        >
          <PopupMenuItem
            icon={EditIcon}
            onClick={() => {
              setMoreMenuPosition(null);
              useDialogStore.getState().open('editChartType', {
                chartType,
                onConfirm: () => {},
              });
            }}
          >
            {t('editChartType')}
          </PopupMenuItem>
          <PopupMenuItem
            icon={DeleteIcon}
            danger
            onClick={() => {
              setMoreMenuPosition(null);
              // 調用 DeleteFolderDialog 顯示確認對話框
              if (selectedChartFolder) {
                useDialogStore.getState().open('deleteFolder', {
                  folder: {
                    ...selectedChartFolder,
                    name: (selectedChartFolder as any).name,
                    isChartFolder: true,
                    isGroup: false
                  }
                });
              }
            }}
          >
            {t('deleteChartType')}
          </PopupMenuItem>
        </PopupMenu>
      )}
    </div>
  );
}

export default ChartList;

