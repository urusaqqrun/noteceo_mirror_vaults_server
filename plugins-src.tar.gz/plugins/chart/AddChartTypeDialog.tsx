/**
 * AddChartTypeDialog — 圖表插件專用：新增/編輯圖表類型
 * 
 * 只需要：typeName + chartKind 選擇 + 重名檢查
 * 完全獨立，不依賴卡片插件
 */
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import '../../common/BasicComponents.css';
import '../../common/CustomSelect.css';
import { CustomDialog } from '../../common/CustomDialog';
import { useChartsStore } from './chartStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';

interface AddChartTypeDialogProps {
    onClose: () => void;
    onConfirm?: () => void;
    isEdit?: boolean;
    initialData?: any;
    targetGroup?: any;
}

function AddChartTypeDialog({
    onClose,
    onConfirm,
    isEdit = false,
    initialData = null,
    targetGroup = null,
}: AddChartTypeDialogProps) {
    const { t } = useTranslation();
    const chartFolders = useItemStore(state => state.getByType('CHART_FOLDER'));

    const [typeName, setTypeName] = useState(initialData?.name || '');
    const [chartKind, setChartKind] = useState(initialData?.kind || 'LineChart');
    const [errorMessage, setErrorMessage] = useState('');

    const handleSubmit = async () => {
        if (!typeName.trim()) {
            setErrorMessage(t('typeNameRequired'));
            return;
        }

        // 重名檢查
        const isDuplicate = chartFolders.some(ct => {
            const nameMatch = ct.name?.toLowerCase() === typeName.trim().toLowerCase();
            const isSelf = isEdit && String(ct.id) === String(initialData?.id);
            return nameMatch && !isSelf;
        });
        if (isDuplicate) {
            setErrorMessage(t('duplicateCardTypeName'));
            return;
        }

        const now = Date.now().toString();
        const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
        const memberID = userData?.ID || 'default';

        if (isEdit && initialData?.id) {
            await useChartsStore.getState().updateChartFolder({
                id: initialData.id,
                name: typeName.trim(),
                kind: chartKind,
                updatedAt: now,
            });
            await useChartsStore.getState().loadChartFolders();
        } else {
            const newTypeData = {
                id: generateObjectID(),
                memberID,
                name: typeName.trim(),
                itemType: 'CHART',
                kind: chartKind,
                parentID: targetGroup?.id || null,
                createdAt: now,
                updatedAt: now,
            };
            await useChartsStore.getState().addChartFolder(newTypeData);
            await useChartsStore.getState().loadChartFolders();
            const savedItem = useItemStore.getState().getById(newTypeData.id);
            if (savedItem) useSelectedItemsStore.getState().setSelectedItems([savedItem], { scrollToFocusItem: true });
        }

        if (onConfirm) onConfirm();
        onClose();
    };

    return (
        <CustomDialog
            isOpen={true}
            onClose={onClose}
            title={isEdit ? t('editChartType') : t('newChartType')}
            className="add-chart-type-dialog"
            onConfirm={handleSubmit}
        >
            <div className="add-chart-type-dialog-body">
                {/* 圖表類型名稱 */}
                <div className="card-type-form-section">
                    <div className="section-header">
                        <label className="form-label">{t('chartTypeName')}</label>
                    </div>
                    <input
                        type="text"
                        value={typeName}
                        onChange={(e) => { setTypeName(e.target.value); setErrorMessage(''); }}
                        className="custom-dialog-input"
                        placeholder={t('chartTypeNamePlaceholder')}
                    />
                </div>

                {/* 圖表種類選擇器 */}
                <div className="card-type-form-section">
                    <label className="form-label">{t('chartKind')}</label>
                    <select
                        value={chartKind}
                        onChange={(e) => setChartKind(e.target.value)}
                        className="custom-select"
                    >
                        <option value="LineChart">{t('chartKindLineChart')}</option>
                        <option value="AreaChart">{t('chartKindAreaChart')}</option>
                        <option value="BarChart">{t('chartKindBarChart')}</option>
                        <option value="PieChart">{t('chartKindPieChart')}</option>
                        <option value="ScatterChart">{t('chartKindScatterChart')}</option>
                        <option value="RadarChart">{t('chartKindRadarChart')}</option>
                        <option value="RadialBarChart">{t('chartKindRadialBarChart')}</option>
                        <option value="Treemap">{t('chartKindTreemap')}</option>
                        <option value="FunnelChart">{t('chartKindFunnelChart')}</option>
                        <option value="ComposedChart">{t('chartKindComposedChart')}</option>
                    </select>
                </div>

                {errorMessage && <p className="dialog-error">{errorMessage}</p>}
            </div>
        </CustomDialog>
    );
}

export default AddChartTypeDialog;
