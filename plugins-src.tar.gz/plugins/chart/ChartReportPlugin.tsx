// ===== ChartReportPlugin — ChartReportView 插件 =====

import React from 'react';
import { Plugin } from '../../../workspace/Plugin';
import { ReactView } from '../../../workspace/ReactView';
import ChartReportView from './ChartReportView';

class ChartReportViewWrapper extends ReactView {
    getViewType() { return 'chart-report'; }
    getDisplayText() { return '图表报告'; }
    renderComponent() { return <ChartReportView />; }
}

export class ChartReportPlugin extends Plugin {
    onload() {
        this.registerView('chart-report', (leaf) => new ChartReportViewWrapper(leaf));
    }
}
