import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import PhotoIcon from '../../../assets/icon_photo_24.svg?react';
import AudioIcon from '../../../assets/icon_audio_on_26.svg?react';
import SendIcon from '../../../assets/round_send_26_n.svg?react';
import StopIcon from '../../../assets/icon_stop_round_26.svg?react';
import NoteIcon from '../../../assets/icon_note_24.svg?react';
import ArrowDownIcon from '../../../assets/icon_arrow_chevron_down.svg?react';
import CloseSmallIcon from '../../../assets/icon_close_24.svg?react';
import { useAICommanderAttachmentsStore, useAICommanderStore, usePreInputStore } from './aiStore';
import { useChatBotSessionsStore } from './chatStore';
import { useDialogStore } from '../../../Store/dialogStore';

import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore } from '../../../Store/uiStore';

import { uploadFile } from '../../../utils/fileUpload';
import { audioToText } from '../../../aiService/promptClient';
import AttachedableEditor from './AttachedableEditor';
import { availableModels, DEFAULT_MODEL } from '../../../aiService/modelConfig';

// 生成簡單的 UUID
const generateUUID = () => {
  return Math.random().toString(36).substr(2, 9);
};

const AICommanderInputArea = forwardRef<unknown, { abortControllerRef?: any; chatRoomRef?: any }>(({
  abortControllerRef,
  chatRoomRef
}, ref) => {
  const { t } = useTranslation();

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const [inputValue, setInputValue] = useState('');
  const [isSaveMode, setIsSaveMode] = useState(() => {
    // 從 localStorage 讀取初始值，預設為 false（暫時停用）
    const saved = localStorage.getItem('aiCommanderSaveMode');
    return saved !== null ? saved === 'true' : false;
  });
  const [selectedModel, setSelectedModel] = useState(() => {
    const saved = localStorage.getItem('aiCommanderSelectedModel');
    return saved || DEFAULT_MODEL;
  });
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isUploadingImages, setIsUploadingImages] = useState(false); // 圖片上傳中狀態
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const streamRef = useRef(null); // 保存音頻流引用
  const voiceActionRef = useRef(null); // 'send' | 'cancel' - 用戶選擇的語音操作
  const audioContextRef = useRef(null); // Web Audio API 上下文
  const analyserRef = useRef(null); // 音頻分析器
  const animationFrameRef = useRef(null); // 動畫幀 ID
  const audioLevelsRef = useRef(Array(10).fill(0)); // 波形歷史數據（10條）
  const [audioLevels, setAudioLevels] = useState(Array(10).fill(0)); // 音量等級（10條）
  const activeSegment = useChatBotSessionsStore(state => state.activeSegment);
  const setActiveSegment = useChatBotSessionsStore(state => state.setActiveSegment);
  const setUserLastInput = useChatBotSessionsStore(state => state.setUserLastInput);
  const setIsInterrupted = useChatBotSessionsStore(state => state.setIsInterrupted);
  const isInterrupted = useChatBotSessionsStore(state => state.isInterrupted);
  const currentSessionID = useChatBotSessionsStore(state => state.currentSessionID);
  // 🔧 直接訂閱當前 thread 的 isResponding 狀態（響應式）
  const isResponding = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.isResponding || false;
  });
  const respondingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);
  const inputAreaRef = useRef(null);
  const modelSelectorRef = useRef(null);
  const editorRef = useRef(null);
  const prevIsRespondingRef = useRef(false);

  // 預輸入佇列（per-session）
  const preInputQueue = usePreInputStore(state => state.getQueue(currentSessionID));

  // 附加項目 store
  const attachedItems = useAICommanderAttachmentsStore(state => state.attachedItems);
  const addAttachment = useAICommanderAttachmentsStore(state => state.addAttachment);
  const removeAttachment = useAICommanderAttachmentsStore(state => state.removeAttachment);
  const clearAttachments = useAICommanderAttachmentsStore(state => state.clearAttachments);

  const setTempHint = useTempHintStore(state => state.setTempHint);
  const setCurrentSessionID = useChatBotSessionsStore(state => state.setCurrentSessionID);
  const addSession = useChatBotSessionsStore(state => state.addSession);
  const updateSession = useChatBotSessionsStore(state => state.updateSession);

  // 獲取 pendingFocus 狀態（用於 mobile 自動聚焦）
  const pendingFocus = useAICommanderStore(state => state.pendingFocus);
  const clearPendingFocus = useAICommanderStore(state => state.clearPendingFocus);

  // 獲取當前選中的畫廊信息（用於動態 placeholder）
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const lastSelectedId = lastSelected?.id ?? null;
  const [selectedFolder, setSelectedFolder] = useState<any>(null);

  useEffect(() => {
    if (!lastSelectedId) { setSelectedFolder(null); return; }
    window.electronAPI?.getItem(lastSelectedId).then(item => {
      setSelectedFolder(item?.itemType?.endsWith('_FOLDER') ? item : null);
    });
  }, [lastSelectedId]);

  // 計算動態 placeholder
  const getPlaceholder = () => {
    if (activeSegment === 0) return t('placeholderSave');

    if (selectedFolder) {
      let fields = selectedFolder.cardFieldsDef;
      if (typeof fields === 'string') {
        try { fields = JSON.parse(fields); } catch { fields = null; }
      }
      if (Array.isArray(fields) && fields.length > 0) {
        const firstTextField = fields.find(f => f.type === 'TEXT' || f.type === 'TEXTAREA');
        if (firstTextField) {
          return t('placeholderCardGallery', { fieldName: firstTextField.name, galleryName: selectedFolder.name });
        }
      }
    }

    return t('placeholderAsk');
  };

  // 同步 isSaveMode 和 activeSegment
  useEffect(() => {
    setActiveSegment(isSaveMode ? 0 : 1);
  }, [isSaveMode, setActiveSegment]);

  // 點擊外部關閉模型選擇下拉菜單
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modelSelectorRef.current && !modelSelectorRef.current.contains(event.target)) {
        setShowModelDropdown(false);
      }
    };

    if (showModelDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showModelDropdown]);

  // 載入草稿
  useEffect(() => {
    if (currentSessionID) {
      try {
        const sessionDrafts = JSON.parse(localStorage.getItem('sessionDraft') || '{}');
        const draft = sessionDrafts[currentSessionID];
        if (draft && draft.trim()) {
          setInputValue(draft);
        } else {
          setInputValue('');
        }
      } catch (error) {
        console.error('載入草稿失敗:', error);
        setInputValue('');
      }
    } else {
      // 如果沒有 currentSessionID，清空輸入框
      setInputValue('');
    }
  }, [currentSessionID]);

  // 防抖儲存草稿的 ref
  const saveDraftTimeoutRef = useRef(null);

  // 暴露方法給父組件
  useImperativeHandle(ref, () => ({
    setInputValue: (value) => {
      setInputValue(value);
      editorRef.current?.setValue(value);
    },
    getInputValue: () => {
      return inputValue;
    },
    // 暴露 focus 方法
    focus: () => {
      editorRef.current?.focus();
    },
    // 暴露關閉儲存模式的方法
    closeSaveMode: () => {
      if (isSaveMode) {
        setIsSaveMode(false);
        localStorage.setItem('aiCommanderSaveMode', 'false');
      }
    },
    // 🔧 暴露停止方法給外部調用（統一的中斷邏輯）
    handleStop: () => {

      // 手動停止 - 中斷當前操作
      if (respondingTimeoutRef.current) {
        clearTimeout(respondingTimeoutRef.current);

      }

      // 中斷所有進行中的 API 請求
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;

      }

      // 中斷 WebSocket 流式對話
      if (chatRoomRef.current?.interruptStreaming) {
        console.log('[Interrupt] Calling chatRoomRef.current.interruptStreaming()');
        chatRoomRef.current.interruptStreaming();
      } else {
        console.log('[Interrupt] chatRoomRef.current?.interruptStreaming is not available:', chatRoomRef.current);
      }

      // 重置狀態（無論 isResponding 是什麼，都重置）
      useChatBotSessionsStore.getState().setIsResponding(currentSessionID, false);
      setIsInterrupted(true);

      // ★ 中斷時處理預輸入佇列：取出最舊一筆放到 inputArea（不自動送出）
      const queue = usePreInputStore.getState().getQueue(currentSessionID);
      if (queue.length > 0) {
        const firstItem = usePreInputStore.getState().shiftPreInput(currentSessionID);
        if (firstItem) {
          editorRef.current?.setValue(firstItem.content);
          setInputValue(firstItem.content);
          // 恢復附件
          if (firstItem.attachedItems?.length > 0) {
            clearAttachments();
            firstItem.attachedItems.forEach(item => {
              addAttachment(item);
            });
          }
        }
      }

      // 短暫延遲後重置中斷狀態，允許發送新消息
      safeSetTimeout(() => {
        setIsInterrupted(false);

      }, 100);
    }
  }));

  // 儲存草稿到 localStorage
  const saveDraft = (value, immediate = false) => {
    if (!currentSessionID) return;

    const saveDraftAction = () => {
      try {
        const sessionDrafts = JSON.parse(localStorage.getItem('sessionDraft') || '{}');
        if (value && value.trim()) {
          sessionDrafts[currentSessionID] = value;
        } else {
          delete sessionDrafts[currentSessionID];
        }
        localStorage.setItem('sessionDraft', JSON.stringify(sessionDrafts));
      } catch (error) {
        console.error('儲存草稿失敗:', error);
      }
    };

    if (immediate) {
      // 立即儲存，清除防抖計時器
      if (saveDraftTimeoutRef.current) {
        clearTimeout(saveDraftTimeoutRef.current);
      }
      saveDraftAction();
    } else {
      // 防抖儲存
      if (saveDraftTimeoutRef.current) {
        clearTimeout(saveDraftTimeoutRef.current);
      }

      saveDraftTimeoutRef.current = safeSetTimeout(saveDraftAction, 500); // 500ms 防抖
    }
  };

  // 停止音頻分析
  const stopAudioAnalysis = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    analyserRef.current = null;
    audioLevelsRef.current = Array(10).fill(0);
    setAudioLevels(Array(10).fill(0));
  };

  // 開始音頻分析（波形可視化）
  const startAudioAnalysis = (stream) => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioContext;

      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      analyser.smoothingTimeConstant = 0.3;
      analyserRef.current = analyser;

      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);

      // 使用時域數據（波形）而不是頻率數據，更敏感
      const dataArray = new Uint8Array(analyser.fftSize);
      let lastUpdateTime = 0;
      const updateInterval = 80; // 每 80ms 更新一次（約 12.5fps）

      const updateLevels = (timestamp) => {
        if (!analyserRef.current) return;

        // 控制更新頻率
        if (timestamp - lastUpdateTime < updateInterval) {
          animationFrameRef.current = requestAnimationFrame(updateLevels);
          return;
        }
        lastUpdateTime = timestamp;

        // 獲取時域數據（波形）
        analyser.getByteTimeDomainData(dataArray);

        // 計算 RMS（均方根）音量 - 更準確反映實際音量
        let sumSquares = 0;
        for (let i = 0; i < dataArray.length; i++) {
          const normalized = (dataArray[i] - 128) / 128; // -1 到 1
          sumSquares += normalized * normalized;
        }
        const rms = Math.sqrt(sumSquares / dataArray.length);

        // 放大音量值使其更敏感（乘以 3-4 倍）
        const amplifiedLevel = Math.min(1, rms * 4);

        // 由左到右的波浪效果：新值從右邊進入，舊值向左移動
        const newLevels = [...audioLevelsRef.current.slice(1), amplifiedLevel];
        audioLevelsRef.current = newLevels;
        setAudioLevels(newLevels);

        animationFrameRef.current = requestAnimationFrame(updateLevels);
      };

      animationFrameRef.current = requestAnimationFrame(updateLevels);
    } catch (error) {
      console.error('音頻分析初始化失敗:', error);
    }
  };

  // 處理語音輸入 - 開始錄音
  const handleVoiceInput = async () => {
    if (isRecording) {
      return; // 錄音中不允許再次點擊
    }

    try {
      // 請求麥克風權限
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // 開始音頻分析（波形可視化）
      startAudioAnalysis(stream);

      // 創建 MediaRecorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      voiceActionRef.current = null; // 重置操作狀態

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        // 立即取得 action 值（在任何 async 操作之前）
        const action = voiceActionRef.current;

        voiceActionRef.current = null;

        // 停止音頻分析
        stopAudioAnalysis();

        setIsRecording(false);
        setIsTranscribing(true);
        setTempHint('正在轉換語音...');

        // 停止所有音軌
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
        }

        try {
          // 創建音頻 Blob
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });

          // 創建 File 對象
          const audioFile = new File([audioBlob], `audio_${Date.now()}.webm`, { type: 'audio/webm' });

          // 調用 audioToText API（直接傳 File 對象）
          const result = await audioToText(audioFile, false, false);

          // 根據操作類型處理轉錄結果
          if (result.content) {
            const newContent = result.content;

            if (action === 'send') {

              // 送出模式：設置內容後直接送出
              if (editorRef.current) {
                editorRef.current.setValue(newContent);
              }
              setInputValue(newContent);
              setIsTranscribing(false);
              setTempHint('');
              // 使用 setTimeout 確保 React state 已更新
              safeSetTimeout(() => {

                handleSendMessage();
              }, 100);
              return;
            } else {

              // 中止模式：將文字添加到輸入框（不送出）
              if (editorRef.current) {
                editorRef.current.insertText(' ' + newContent);
                const currentVal = editorRef.current.getValue();
                setInputValue(currentVal);
              }
              setIsTranscribing(false);
              setTempHint('');
              return;
            }
          } else {
            setTempHint('未識別到語音');
            safeSetTimeout(() => setTempHint(''), 2000);
          }
        } catch (error) {
          console.error('🎤 語音轉文字錯誤:', error);
          setTempHint('語音轉換失敗');
          safeSetTimeout(() => setTempHint(''), 2000);
        } finally {
          setIsTranscribing(false);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setTempHint('');

    } catch (error) {
      console.error('無法訪問麥克風:', error);
      setTempHint('無法訪問麥克風，請檢查權限');
      safeSetTimeout(() => setTempHint(''), 3000);
    }
  };

  // 語音送出 - 停止錄音並送出
  const handleVoiceSend = () => {

    if (!isRecording) {

      return;
    }
    voiceActionRef.current = 'send';

    if (mediaRecorderRef.current) {

      if (mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
    }
  };

  // 語音中止 - 停止錄音並添加到輸入框
  const handleVoiceCancel = () => {

    if (!isRecording) {

      return;
    }
    voiceActionRef.current = 'cancel';

    if (mediaRecorderRef.current) {

      if (mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
    }
  };

  // 清理音頻分析（組件卸載時）
  useEffect(() => {
    return () => {
      stopAudioAnalysis();
    };
  }, []);

  // ★ 自動送出 effect：isResponding 從 true→false 且非中斷時，自動取出佇列第一條送出
  useEffect(() => {
    if (prevIsRespondingRef.current && !isResponding && !isInterrupted) {
      const queue = usePreInputStore.getState().getQueue(currentSessionID);
      if (queue.length > 0) {
        const firstItem = usePreInputStore.getState().shiftPreInput(currentSessionID);
        if (firstItem) {
          // 恢復附件到 store
          if (firstItem.attachedItems?.length > 0) {
            clearAttachments();
            firstItem.attachedItems.forEach(item => addAttachment(item));
          }
          editorRef.current?.setValue(firstItem.content);
          setInputValue(firstItem.content);
          safeSetTimeout(() => {
            handleSendMessage();
          }, 100);
        }
      }
    }
    prevIsRespondingRef.current = isResponding;
  }, [isResponding, isInterrupted, currentSessionID]);

  // 處理發送訊息
  const handleSendMessage = async () => {

    if (isUploadingImages) return;

    if (!editorRef.current) return;

    const originalInputValue = editorRef.current.getFormattedContent();
    if (!originalInputValue) return;

    // ★ 回應中時，加入當前 session 的預輸入佇列而非直接送出
    if (isResponding) {
      const currentAttachments = [...useAICommanderAttachmentsStore.getState().attachedItems];
      usePreInputStore.getState().addPreInput(currentSessionID, originalInputValue, currentAttachments);
      setInputValue('');
      editorRef.current.setValue('');
      clearAttachments();
      return;
    }

    // (已在上方處理 editorRef.current 和 originalInputValue)

    // 🔧 立即清除防抖計時器，避免競態條件導致草稿被重新保存
    if (saveDraftTimeoutRef.current) {
      clearTimeout(saveDraftTimeoutRef.current);
      saveDraftTimeoutRef.current = null;
    }

    // 根據 isSaveMode 決定是否在內容前加上「幫我儲存：」
    const messageContent = isSaveMode ? `${t('saveModePrefix')}${originalInputValue}` : originalInputValue;

    // 準備要發送的附加項目
    // ⚠️ 從 store 即時讀取（而非使用 React 閉包中的 attachedItems），
    //    確保自動送出 effect 恢復附件後能正確讀取
    const latestAttachedItems = useAICommanderAttachmentsStore.getState().attachedItems;

    let finalAttachedItems = [...latestAttachedItems];

    // ⚡ 處理圖片上傳 - 在發送時才上傳圖片
    const imageItems = latestAttachedItems.filter(item => item.type === 'image');

    if (imageItems.length > 0) {

      setIsUploadingImages(true);
      const userData = JSON.parse(localStorage.getItem('userData_local')) || {};
      const memberID = userData.ID || 'unknown';

      try {
        // 並行上傳所有圖片
        const uploadPromises = imageItems.map(async (item) => {
          try {
            // 將 base64 轉成 File
            const res = await fetch(item.data);
            const blob = await res.blob();
            const file = new File([blob], item.title, { type: item.mimeType });

            // 上傳圖片
            const uploadResult = await uploadFile(file, memberID, 'temp', {
              maxWidth: 1920,
              maxHeight: 1080,
              quality: 0.8,
              maxSizeKB: 1024
            });

            if (uploadResult?.downloadURL) {

              return {
                id: item.id,
                type: 'image',
                title: item.title,
                url: uploadResult.downloadURL
              };
            }
            return null;
          } catch (error) {
            console.error(`❌ 圖片上傳失敗: ${item.title}`, error);
            return null;
          }
        });

        const uploadedImages = await Promise.all(uploadPromises);
        const successfulImages = uploadedImages.filter(img => img !== null);

        // 檢查是否有圖片上傳失敗
        const failedCount = imageItems.length - successfulImages.length;
        if (failedCount > 0) {

          setTempHint(`有 ${failedCount} 張圖片上傳失敗，已自動移除`);
          safeSetTimeout(() => setTempHint(''), 3000);
        }

        // 更新 finalAttachedItems - 移除原本的 base64 圖片，加入上傳後的 URL 圖片
        finalAttachedItems = finalAttachedItems.filter(item => item.type !== 'image').concat(successfulImages);
      } catch (error) {
        console.error('❌ 圖片上傳過程出錯:', error);
        setTempHint('圖片上傳失敗，請稍後再試');
        setIsUploadingImages(false);
        return;
      } finally {
        setIsUploadingImages(false);
      }
    }

    const newMessage = {
      role: 'user',
      content: messageContent,
      attachedItems: finalAttachedItems.length > 0 ? finalAttachedItems : undefined
    };

    // 創建新的 AbortController
    abortControllerRef.current = new AbortController();

    // 🔧 立即更新 store 中的 messages - 從當前 thread 的 state 取得
    const currentState = useChatBotSessionsStore.getState().getSessionState(currentSessionID);
    const currentMessages = currentState.messages || [];
    const updatedMessages = [...currentMessages, newMessage];

    // 如果沒有 currentSessionID，創建包含該消息的新線程
    let sessionID = currentSessionID;
    if (!sessionID) {
      sessionID = crypto.randomUUID();

      try {
        // 創建包含該消息的新線程
        const newSession = {
          session_id: sessionID,
          messages: updatedMessages,
          updated_at: Date.now().toString(),
          title: null
        };

        await addSession(newSession);
        setCurrentSessionID(sessionID);
        useChatBotSessionsStore.getState().setSessionNew(sessionID, true);

      } catch (error) {
        console.error('❌ 創建新線程失敗:', error);
        return;
      }
    } else {
      // 使用點1: InputArea的輸入 - 將用戶消息添加到現有線程
      // 🔧 立即同步更新 sessionStates，讓 UI 馬上顯示新的 user 訊息
      // 避免依賴 updateSession 的非同步 setMessages（已移除），防止競態覆蓋
      useChatBotSessionsStore.getState().setMessages(sessionID, updatedMessages);

      const sessions = useChatBotSessionsStore.getState().sessions;
      const currentSession = sessions.find(s => s.session_id === sessionID);

      if (currentSession) {
        const updatedSession = {
          ...currentSession,
          messages: updatedMessages,
          updated_at: Date.now().toString()
        };

        updateSession(updatedSession);  // fire-and-forget，僅 DB 持久化
      }
    }

    setInputValue('');
    setUserLastInput(originalInputValue);

    // 清空 contenteditable 內容
    if (editorRef.current) {
      editorRef.current.setValue('');
    }

    // 清空附加項目
    clearAttachments();

    // 清空該線程的草稿
    if (chatRoomRef.current?.clearDraft) {
      chatRoomRef.current.clearDraft(sessionID);
    }

    // 命令式送出
    if (chatRoomRef.current?.sendUserMessage) {
      console.log('[Pending-DEBUG] InputArea: direct call sendUserMessage, sessionID:', sessionID);
      chatRoomRef.current.sendUserMessage(newMessage, sessionID);
    } else {
      console.log('[Pending-DEBUG] InputArea: ChatRoom not ready, writing pendingUserMessage, sessionID:', sessionID);
      useChatBotSessionsStore.getState().setPendingUserMessage(sessionID, newMessage);
    }

    if (respondingTimeoutRef.current) clearTimeout(respondingTimeoutRef.current);
  };

  // 清理防抖計時器
  useEffect(() => {
    return () => {
      if (saveDraftTimeoutRef.current) {
        clearTimeout(saveDraftTimeoutRef.current);
      }
    };
  }, []);

  // 處理圖片選擇
  const handleImageSelect = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];

      // 檢查文件類型
      if (!file.type.startsWith('image/')) {
        setTempHint(t('invalidImageType'));
        safeSetTimeout(() => setTempHint(null), 2000);
        continue;
      }

      // 檢查文件大小（限制 10MB）
      if (file.size > 10 * 1024 * 1024) {
        setTempHint(t('imageTooLarge'));
        safeSetTimeout(() => setTempHint(null), 2000);
        continue;
      }

      try {
        // 將 base64 轉成 File
        const base64 = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        // 添加到附加項目（只暫存 base64，不上傳）
        const imageId = generateUUID();
        addAttachment({
          id: imageId,
          type: 'image',
          title: file.name,
          data: base64,  // 暫存 base64，發送時才上傳
          mimeType: file.type,
          file: file  // 保存原始 File 對象以便稍後上傳
        });
      } catch (error) {
        console.error('讀取圖片失敗:', error);
        setTempHint(t('imageReadError'));
        safeSetTimeout(() => setTempHint(null), 2000);
      }
    }

    // 清空 input 以允許重複選擇同一文件
    e.target.value = '';
  };

  const handleInputAreaClickCapture = (e) => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const memberID = JSON.parse(localStorage.getItem('userData_local') || '{}').ID || '';
    if (!isLoggedIn || localStorage.getItem('isGuest') === 'true') {
      e.stopPropagation();
      e.preventDefault();
      useAICommanderStore.getState().setIsAICommanderOpen(false);
      useDialogStore.getState().open('login', { message: t('loginDialogAIContent') });
    }
  };

  return (
    <div
      className="ai-commander-input-area"
      ref={inputAreaRef}
      onClickCapture={handleInputAreaClickCapture}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        style={{ display: 'none' }}
        onChange={handleImageSelect}
      />

      {/* 預輸入佇列 UI */}
      {preInputQueue.length > 0 && (
        <div className="ai-commander-pre-input-queue">
          {preInputQueue.map((item, index) => (
            <div key={item.id} className="ai-commander-pre-input-item">
              <span className="ai-commander-pre-input-index">{index + 1}</span>
              <div className="ai-commander-pre-input-body">
                <div
                  className="ai-commander-pre-input-content"
                  contentEditable
                  suppressContentEditableWarning
                  onBlur={(e) => {
                    const newContent = e.currentTarget.textContent || '';
                    if (newContent !== item.content) {
                      usePreInputStore.getState().updatePreInput(currentSessionID, item.id, newContent);
                    }
                  }}
                >
                  {item.content}
                </div>
                {item.attachedItems.length > 0 && (
                  <div className="ai-commander-pre-input-attachments">
                    {item.attachedItems.map(att => (
                      <span key={att.id} className="ai-commander-attach-tag">
                        <span className="ai-commander-attach-tag-text">{att.title || att.name || att.type}</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <button
                className="ai-commander-pre-input-remove"
                onClick={() => usePreInputStore.getState().removePreInput(currentSessionID, item.id)}
              >
                <CloseSmallIcon />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* 輸入框區域 - 錄音/轉錄時隱藏（用 CSS 隱藏保持 ref 有效） */}
      <div style={{ display: isRecording || isTranscribing ? 'none' : 'block' }}>
        <AttachedableEditor
          ref={editorRef}
          value={inputValue}
          onChange={(val) => {
            setInputValue(val);
            saveDraft(val);
          }}
          onSubmit={handleSendMessage}
          placeholder={getPlaceholder()}
          attachedItems={attachedItems}
          onAddAttachment={addAttachment}
          onRemoveAttachment={removeAttachment}
          isSaveMode={isSaveMode}
          setIsSaveMode={(value) => {
            setIsSaveMode(value);
            localStorage.setItem('aiCommanderSaveMode', value.toString());
          }}
          autoFocus={pendingFocus}
          onAutoFocused={clearPendingFocus}
        // onAttachmentClick 使用默認行為
        />
      </div>

      {/* 操作區域 */}
      <div className={`ai-commander-actions ${isRecording || isTranscribing ? 'recording-mode' : ''}`}>
        {isRecording || isTranscribing ? (
          // 錄音/轉錄模式佈局
          <>
            <button
              className="ai-commander-button cancel"
              onClick={handleVoiceCancel}
              disabled={isTranscribing}
            >
              <StopIcon />
            </button>
            <div className="ai-commander-voice-waveform">
              {isTranscribing ? (
                // 轉錄中顯示 loader
                <>
                  <div className="ai-commander-button-loader"></div>
                  <span className="ai-commander-voice-transcribing-text">{t('voiceTranscribing')}</span>
                </>
              ) : (
                // 錄音中顯示波形動畫（根據音量變化）
                <>
                  {audioLevels.map((level, index) => (
                    <div
                      key={index}
                      className="ai-commander-voice-waveform-bar"
                      style={{ height: `${3 + level * 23}px` }}
                    ></div>
                  ))}
                </>
              )}
            </div>
            <button
              className="ai-commander-button send"
              onClick={handleVoiceSend}
              disabled={isTranscribing}
            >
              <SendIcon />
            </button>
          </>
        ) : (
          // 正常模式佈局
          <>
            <div className="ai-commander-actions-left">
              {/* 暫時隱藏儲存按鈕 */}
              <div className="ai-commander-save-tag" style={{ display: 'none' }}>
                <span
                  className={isSaveMode ? 'actived' : ''}
                  onClick={() => {
                    const newValue = !isSaveMode;
                    setIsSaveMode(newValue);
                    localStorage.setItem('aiCommanderSaveMode', newValue.toString());
                  }}
                >
                  <NoteIcon />{t('save')}
                </span>
              </div>
              <div className="ai-commander-model-selector" ref={modelSelectorRef}>
                <button
                  className="ai-commander-model-selector-button"
                  onClick={() => setShowModelDropdown(!showModelDropdown)}
                >
                  <span>{availableModels.find(m => m.id === selectedModel)?.name || 'Claude Opus 4.6'}</span>
                  <ArrowDownIcon className={showModelDropdown ? 'rotated' : ''} />
                </button>
                {showModelDropdown && (
                  <div className="ai-commander-model-dropdown">
                    {availableModels.map(model => (
                      <div
                        key={model.id}
                        className={`ai-commander-model-option ${selectedModel === model.id ? 'selected' : ''}`}
                        onClick={() => {
                          setSelectedModel(model.id);
                          localStorage.setItem('aiCommanderSelectedModel', model.id);
                          setShowModelDropdown(false);

                          // 斷開現有的 WebSocket 連接，下次發送消息時會用新模型重新連接
                          if (chatRoomRef.current?.disconnectSession) {

                            chatRoomRef.current.disconnectSession();
                          }
                        }}
                      >
                        {model.name}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="ai-commander-actions-right">
              <button
                className="ai-commander-button add"
                onClick={() => fileInputRef.current?.click()}
                onMouseEnter={() => setTempHint(t('addImageHint'))}
                onMouseLeave={() => setTempHint('')}
              >
                <PhotoIcon />
              </button>
              <button
                className="ai-commander-button add"
                onClick={handleVoiceInput}
                onMouseEnter={() => setTempHint(t('dictationHint'))}
                onMouseLeave={() => setTempHint('')}
              >
                <AudioIcon />
              </button>
              <button
                className={`ai-commander-button ${isResponding && !inputValue.trim() ? 'stop' : 'send'}`}
                onClick={() => {
                  if (isResponding && !inputValue.trim()) {
                    // 無內容 + 回應中 → 中斷
                    if ((ref as React.RefObject<any>)?.current?.handleStop) {
                      (ref as React.RefObject<any>).current.handleStop();
                    }
                  } else {
                    // 有內容 → 送出 or 加入佇列（由 handleSendMessage 判斷）
                    handleSendMessage();
                  }
                }}
                disabled={!inputValue.trim() && !isResponding && !isUploadingImages}
              >
                {isUploadingImages ? (
                  <div className="ai-commander-button-loader"></div>
                ) : isResponding && !inputValue.trim() ? (
                  <StopIcon />
                ) : (
                  <SendIcon />
                )}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
});

export default AICommanderInputArea;