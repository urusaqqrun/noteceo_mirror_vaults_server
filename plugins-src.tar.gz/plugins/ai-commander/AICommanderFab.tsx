// ===== AICommanderFab — AICommander 浮動按鈕 (FAB) =====
//
// 透過 AICommanderPlugin.registerOverlay 註冊，由 OverlayRenderer 渲染。
// 當 AICommander 面板關閉時顯示在右下角，點擊後展開面板。

import React from 'react';
import { useAICommanderStore } from './aiStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import CubeLVLogoDark from '../../../assets/CubeLV_logo_dark.png';
import CubeLVLogoLight from '../../../assets/CubeLV_logo_light.png';

const AICommanderFab: React.FC = () => {
    const isAICommanderOpen = useAICommanderStore(s => s.isAICommanderOpen);
    const setIsAICommanderOpen = useAICommanderStore(s => s.setIsAICommanderOpen);
    const isMobileView = useIsMobileView();

    // AI 指揮中心的 taskReport 頁有自己的 play 按鈕，隱藏 FAB
    const navParams = useSelectedItemsStore(s => s.navParams);
    const lastSelected = useSelectedItemsStore(s => s.path.at(-1));
    const isAIAdminWithTask = lastSelected?.itemType === 'AI_ADMIN_FOLDER' && navParams.initialTaskId;

    if (isAICommanderOpen || isAIAdminWithTask) {
        return null;
    }

    return (
        <button
            className="app-mobile-ai-fab"
            onClick={() => setIsAICommanderOpen(true, isMobileView)}
        >
            <img
                src={CubeLVLogoDark}
                alt="AI"
                className="app-mobile-ai-fab-logo app-mobile-ai-fab-logo-dark"
            />
            <img
                src={CubeLVLogoLight}
                alt="AI"
                className="app-mobile-ai-fab-logo app-mobile-ai-fab-logo-light"
            />
        </button>
    );
};

export default AICommanderFab;
