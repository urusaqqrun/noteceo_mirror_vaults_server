import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import ChatIcon from '../../../assets/bk_chat_bubble_outline_26.svg?react';
import { useChatBotSessionsStore } from './chatStore';
import { formatTimestamp } from '../../Utils/dateFormat';
import { updateSessionTitle } from '../../../aiService/AIChatBotService';
import { CustomDialog } from '../../common/CustomDialog';


// 歷史項目 loader 組件
const HistoryLoader = () => (
  <div className="ai-commander-history-loader" />
);

// AICommanderHistorySection
// 顯示 AI 指令歷史簡易列表
// props:
//   onViewMore: 點擊「查看更多」按鈕時呼叫
const AICommanderHistorySection = ({ onViewMore }) => {
  const { t } = useTranslation();
  const sessions = useChatBotSessionsStore((state) => state.sessions);
  const sessionStates = useChatBotSessionsStore((state) => state.sessionStates);
  const setCurrentSessionID = useChatBotSessionsStore((state) => state.setCurrentSessionID);
  const updateSession = useChatBotSessionsStore((state) => state.updateSession);
  const deleteSession = useChatBotSessionsStore((state) => state.deleteSession);
  const [recentSessions, setRecentSessions] = useState([]);

  // 右鍵選單狀態
  const [contextMenu, setContextMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    sessionId: null
  });

  // 編輯名稱 Dialog 狀態
  const [renameDialog, setRenameDialog] = useState({
    isOpen: false,
    sessionId: null,
    title: ''
  });

  // 刪除確認 Dialog 狀態
  const [deleteDialog, setDeleteDialog] = useState({
    isOpen: false,
    sessionId: null,
    title: ''
  });

  // 當 sessions 變化時更新 recentSessions
  useEffect(() => {
    const items = sessions
      .filter(session => session.title) // 只顯示有標題的聊天記錄
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, 3);
    setRecentSessions(items);
  }, [sessions]);

  // 關閉右鍵選單
  const closeContextMenu = () => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0,
      sessionId: null
    });
  };

  // 處理右鍵選單的關閉（點擊外部時）
  useEffect(() => {
    const handleOutsideInteraction = (e) => {
      if (!contextMenu.visible) return;
      const menuEl = document.querySelector('.ai-commander-history-context-menu');
      if (menuEl && menuEl.contains(e.target)) return;
      closeContextMenu();
    };

    document.addEventListener('click', handleOutsideInteraction, true);
    document.addEventListener('contextmenu', handleOutsideInteraction, true);

    return () => {
      document.removeEventListener('click', handleOutsideInteraction, true);
      document.removeEventListener('contextmenu', handleOutsideInteraction, true);
    };
  }, [contextMenu.visible]);

  // 右鍵點擊處理
  const handleItemRightClick = (e, sessionId) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      sessionId
    });
  };

  // 開啟編輯名稱 Dialog
  const handleEditName = () => {
    const session = recentSessions.find(t => t.session_id === contextMenu.sessionId);
    if (session) {
      setRenameDialog({
        isOpen: true,
        sessionId: contextMenu.sessionId,
        title: session.title
      });
      closeContextMenu();
    }
  };

  // 關閉編輯名稱 Dialog
  const closeRenameDialog = () => {
    setRenameDialog({
      isOpen: false,
      sessionId: null,
      title: ''
    });
  };

  // 保存編輯的名稱
  const handleSaveTitle = async () => {
    if (!renameDialog.sessionId || !renameDialog.title.trim()) {
      closeRenameDialog();
      return;
    }

    const session = sessions.find(t => t.session_id === renameDialog.sessionId);
    if (session) {
      const newTitle = renameDialog.title.trim();

      // 更新本地資料庫
      await updateSession({
        ...session,
        title: newTitle,
        updated_at: Date.now().toString()
      });

      // 同步到後端
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const memberID = userData.ID;
      if (memberID) {
        await updateSessionTitle(memberID, renameDialog.sessionId, newTitle, 'chat');
      }
    }

    closeRenameDialog();
  };

  // 處理 Dialog 輸入框的鍵盤事件
  const handleRenameKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSaveTitle();
    }
  };

  // 開啟刪除確認 Dialog
  const handleDeleteSession = () => {
    const session = recentSessions.find(t => t.session_id === contextMenu.sessionId);
    if (session) {
      setDeleteDialog({
        isOpen: true,
        sessionId: contextMenu.sessionId,
        title: session.title
      });
      closeContextMenu();
    }
  };

  // 確認刪除
  const handleConfirmDelete = async () => {
    if (deleteDialog.sessionId) {
      await deleteSession(deleteDialog.sessionId);
    }
    setDeleteDialog({ isOpen: false, sessionId: null, title: '' });
  };

  // 如果沒有聊天記錄，返回 null
  if (recentSessions.length === 0) {
    return null;
  }

  return (
    <div className="ai-commander-history-section">
      <div className="ai-commander-history-header">
        <h4>{t('historyTitle')}</h4>
        <button className="view-more" onClick={onViewMore}>{t('viewMore')}</button>
      </div>
      <div className="ai-commander-history-list">
        {/* 右鍵選單 */}
        {contextMenu.visible && (
          <div
            className="ai-commander-history-context-menu"
            style={{
              left: `${contextMenu.x}px`,
              top: `${contextMenu.y}px`
            }}
          >
            <div
              className="ai-commander-history-context-menu-item"
              onClick={handleEditName}
            >
              {t('editName')}
            </div>
            <div
              className="ai-commander-history-context-menu-item ai-commander-history-context-menu-item-danger"
              onClick={handleDeleteSession}
            >
              {t('deleteSession')}
            </div>
          </div>
        )}
        {recentSessions.map((session) => (
          <div
            key={session.session_id}
            className="ai-commander-history-item"
            onClick={() => setCurrentSessionID(session.session_id)}
            onContextMenu={(e) => handleItemRightClick(e, session.session_id)}
          >
            <div className="ai-commander-history-item-left">
              <div className="ai-commander-history-icon">
                {sessionStates[session.session_id]?.isResponding ? <HistoryLoader /> : <ChatIcon />}
              </div>
              <p className="ai-commander-history-title">{session.title}</p>
            </div>
            <span className="ai-commander-history-time">
              {formatTimestamp(session.updated_at)}
            </span>
          </div>
        ))}
      </div>

      {/* 編輯名稱 Dialog */}
      <CustomDialog
        isOpen={renameDialog.isOpen}
        onClose={closeRenameDialog}
        title={t('editName')}
      >
        <input
          type="text"
          className="custom-dialog-input"
          value={renameDialog.title}
          onChange={(e) => setRenameDialog(prev => ({ ...prev, title: e.target.value }))}
          onKeyDown={handleRenameKeyDown}
        />
        <div className="custom-dialog-buttons">
          <button className="custom-secondary-button" onClick={closeRenameDialog}>
            {t('cancel')}
          </button>
          <button className="custom-primary-button" onClick={handleSaveTitle}>
            {t('confirm')}
          </button>
        </div>
      </CustomDialog>

      {/* 刪除確認 Dialog */}
      <CustomDialog
        isOpen={deleteDialog.isOpen}
        onClose={() => setDeleteDialog({ isOpen: false, sessionId: null, title: '' })}
        title={t('deleteSession')}
      >
        <p className="custom-dialog-message">{t('deleteSessionConfirm')}</p>
        <div className="custom-dialog-buttons">
          <button className="custom-secondary-button" onClick={() => setDeleteDialog({ isOpen: false, sessionId: null, title: '' })}>
            {t('cancel')}
          </button>
          <button className="custom-danger-button" onClick={handleConfirmDelete}>
            {t('delete')}
          </button>
        </div>
      </CustomDialog>
    </div>
  );
};

export default AICommanderHistorySection; 