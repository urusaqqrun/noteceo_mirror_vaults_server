import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import './AICommander.css';
import { useAICommanderStore, useAICommanderAttachmentsStore } from './aiStore';
import { useChatBotSessionsStore } from './chatStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { eventBus } from '../../../Store/eventBus';
import DragOverlay from '../../common/DragOverlay';
import AICommanderHistory from './AICommanderHistory';
import AICommanderHistorySection from './AICommanderHistorySection';
import AICommanderChatRoom from './AICommanderChatRoom';
import AICommanderInputArea from './AICommanderInputArea';
import CloseIcon from '../../../assets/icon_close_round_24.svg?react';
import CustomToolbar from '../../common/CustomToolbar';
import { useIsMobileView } from '../../../hooks/useWindowSize';

const AICommander = () => {
  const { t } = useTranslation();

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const setIsAICommanderOpen = useAICommanderStore(state => state.setIsAICommanderOpen);
  const currentSessionID = useChatBotSessionsStore(state => state.currentSessionID);

  //頁面切換動畫用
  const [activeComponent, setActiveComponent] = useState(null);
  const [animationState, setAnimationState] = useState('idle'); // 'idle', 'entering', 'exiting'
  const [navigationDirection, setNavigationDirection] = useState('forward'); // 'forward', 'backward'

  const abortControllerRef = useRef(null);
  const chatRoomRef = useRef(null);
  const inputAreaRef = useRef(null);

  // 添加拖曳相關狀態
  const isMobileView = useIsMobileView();
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [isImageDragOver, setIsImageDragOver] = useState(false);
  const dragCounterRef = useRef(0);

  // DragOverlay 純 UI：由拖曳方推送 overlay 的 icon/text
  const [overlayProps, setOverlayProps] = useState<{ icon?: React.FC; text?: string } | null>(null);

  // 附加項目 store
  const addAttachment = useAICommanderAttachmentsStore(state => state.addAttachment);
  const attachedItems = useAICommanderAttachmentsStore(state => state.attachedItems);
  const setTempHint = useTempHintStore(state => state.setTempHint);
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const isAIAdminView = lastSelected?.itemType === 'AI_ADMIN_FOLDER';

  // 元件掛載時同步遠端 sessions（確保歷史列表在 Web 重登後可見）
  useEffect(() => {
    const store = useChatBotSessionsStore.getState();
    store.loadSessions().then(() => {
      store.syncSessions();
    });
  }, []);

  // DragOverlay：監聯 overlay 事件，由拖曳方推送 icon/text
  useEffect(() => {
    const unsub = eventBus.on('drag:ai-commander-drag-overlay', (props: { icon?: React.FC; text?: string } | null) => {
      setOverlayProps(props);
    });
    return unsub;
  }, []);

  // 訂閱圖片拖曳事件 + 全局 dragleave
  useEffect(() => {
    const handleShowImageDrag = () => {
      setIsImageDragOver(true);
    };

    const handleClearImageDrag = () => {
      setIsImageDragOver(false);
    };

    document.addEventListener('showImageDrag', handleShowImageDrag);
    document.addEventListener('clearImageDrag', handleClearImageDrag);

    return () => {
      document.removeEventListener('showImageDrag', handleShowImageDrag);
      document.removeEventListener('clearImageDrag', handleClearImageDrag);
    };
  }, []);

  // 處理組件切換的動畫效果
  const handleComponentChange = (componentName) => {
    if (componentName === activeComponent) return;

    // 判斷導航方向
    // 如果當前沒有活動組件，或者從主頁面到子頁面，則是向前導航
    // 如果從子頁面返回主頁面，則是向後導航
    const isBackward = activeComponent !== null && componentName === null;
    setNavigationDirection(isBackward ? 'backward' : 'forward');

    setAnimationState('exiting');

    // 等待退出動畫完成後再切換組件
    safeSetTimeout(() => {
      setActiveComponent(componentName);
      setAnimationState('entering');

      // 動畫完成後恢復到閒置狀態
      safeSetTimeout(() => {
        setAnimationState('idle');
      }, 300);
    }, 300);
  };

  // 處理從外部拖曳文件的檢測
  const handleFileDragEnter = (e) => {
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      // 檢查是否為圖片文件
      const hasImageFile = Array.from(e.dataTransfer.items as DataTransferItemList).some((item: DataTransferItem) => {
        return item.kind === 'file' && item.type.startsWith('image');
      });

      if (hasImageFile) {
        dragCounterRef.current++;
        setIsImageDragOver(true);
      }
    }
  };

  const handleFileDragLeave = (e) => {
    dragCounterRef.current--;
    if (dragCounterRef.current === 0) {
      setIsImageDragOver(false);
    }
  };

  // 處理圖片拖放
  const handleImageDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    setIsImageDragOver(false);
    setIsDraggingOver(false);
    dragCounterRef.current = 0;

    // 從全局變數讀取圖片 URL
    const imageUrl = window.__draggingImageUrl;

    // 檢查是否是圖片 URL（http/https URL 或 base64）
    const isImageUrl = imageUrl && (
      imageUrl.startsWith('http://') ||
      imageUrl.startsWith('https://') ||
      imageUrl.startsWith('data:image')
    );

    if (isImageUrl) {

      try {
        // 如果是 base64，直接使用
        if (imageUrl.startsWith('data:image')) {
          const imageId = Math.random().toString(36).substr(2, 9);
          // 從 base64 中提取 MIME 類型和檔名
          const mimeMatch = imageUrl.match(/data:(image\/[^;]+);/);
          const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';
          const extension = mimeType.split('/')[1] || 'jpg';

          addAttachment({
            id: imageId,
            type: 'image',
            title: `image.${extension}`,
            data: imageUrl,
            mimeType: mimeType
          });

          setTempHint('圖片已添加');
          safeSetTimeout(() => setTempHint(null), 2000);
          return;
        }

        // 如果是 URL（http/https），使用 Electron API 下載以避免 CORS
        if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {

          const response = await window.electronAPI.fetchImage({ url: imageUrl });

          if (!response.ok) {
            throw new Error(`圖片下載失敗: HTTP ${response.status}`);
          }

          // 將 Base64 轉換為 data URL
          const base64 = `data:${response.contentType};base64,${response.data}`;
          const fileName = imageUrl.split('/').pop() || 'image.jpg';
          const imageId = Math.random().toString(36).substr(2, 9);

          // 將 base64 轉換為 File 對象以便後續上傳
          const binaryString = atob(response.data);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          const blob = new Blob([bytes], { type: response.contentType });
          const file = new File([blob], fileName, { type: response.contentType });

          addAttachment({
            id: imageId,
            type: 'image',
            title: fileName,
            data: base64,
            mimeType: response.contentType,
            file: file
          });

          setTempHint('圖片已添加');
          safeSetTimeout(() => setTempHint(null), 2000);
          return;
        }
      } catch (error) {
        console.error('處理拖曳圖片失敗:', error);
        setTempHint('處理圖片失敗');
        safeSetTimeout(() => setTempHint(null), 2000);
        return;
      }
    }

    // 處理文件拖曳
    const files = Array.from(e.dataTransfer.files);
    const imageFiles = files.filter(file => {
      // 檢查文件類型
      if (file.type && file.type.startsWith('image')) return true;

      // 若無 MIME，改以副檔名比對常見圖片格式
      const ext = file.name.split('.').pop().toLowerCase();
      return ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'heic', 'heif', 'tiff', 'tif', 'svg'].includes(ext);
    });

    if (imageFiles.length === 0) {
      setTempHint('請拖放圖片檔案');
      safeSetTimeout(() => setTempHint(null), 2000);
      return;
    }

    // 處理所有圖片
    for (const file of imageFiles) {
      // 檢查文件大小（限制 10MB）
      if (file.size > 10 * 1024 * 1024) {
        setTempHint(t('imageTooLarge'));
        safeSetTimeout(() => setTempHint(null), 2000);
        continue;
      }

      try {
        // 將圖片轉換為 base64
        const base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        // 添加到附加項目
        const imageId = Math.random().toString(36).substr(2, 9);
        addAttachment({
          id: imageId,
          type: 'image',
          title: file.name,
          data: base64,
          mimeType: file.type,
          file: file
        });
      } catch (error) {
        console.error('讀取拖放圖片失敗:', error);
      }
    }
  };


  const renderContent = () => {
    switch (activeComponent) {
      case 'ai-commander-history':
        return <AICommanderHistory onCancel={() => handleComponentChange(null)} />;
      default:
        return (
          <>
            {!currentSessionID ? (
              <>
                <CustomToolbar
                  className="ai-commander-empty-topbar"
                  right={{ buttons: [{ icon: <CloseIcon />, onClick: () => setIsAICommanderOpen(false) }] }}
                />
                <div className="ai-commander-empty-content">
                  <div className="ai-commander-header">
                    <h2>{t('greeting')}</h2>
                    <p>{t(isAIAdminView ? 'aiAdminWelcomeMessage' : 'welcomeMessage')}</p>
                  </div>
                  <AICommanderHistorySection onViewMore={() => handleComponentChange('ai-commander-history')} />
                </div>
              </>
            ) : (
              <>
                <AICommanderChatRoom
                  abortSignal={abortControllerRef.current?.signal}
                  abortControllerRef={abortControllerRef}
                  onClose={() => setIsAICommanderOpen(false)}
                  onHistory={() => handleComponentChange('ai-commander-history')}
                  inputAreaRef={inputAreaRef}
                  ref={chatRoomRef}
                />
              </>
            )}
            <AICommanderInputArea
              {...{ ref: inputAreaRef, abortControllerRef, chatRoomRef } as any}
            />
          </>
        );
    }
  };

  return (
    <div
      className="ai-commander"
      onDragEnter={handleFileDragEnter}
      onDragLeave={handleFileDragLeave}
      onDragOver={(e) => e.preventDefault()}
    >
      {/* AICommander 內容 */}
      <div className={`ai-commander-content-wrapper ${animationState} ${navigationDirection}`}>
        {renderContent()}
      </div>

      {/* DragOverlay：監聽 overlay 事件 */}
      {!isMobileView && overlayProps && (
        <DragOverlay
          icon={overlayProps.icon}
          text={overlayProps.text}
          onDrop={(e) => {
            e.preventDefault();
            setOverlayProps(null);
            setIsDraggingOver(false);
            const sourceType = e.dataTransfer.getData('sourceType');
            if (sourceType) {
              eventBus.emit(`drop:ai-commander:${sourceType}`, e, addAttachment, attachedItems, inputAreaRef);
            }
          }}
          onDragLeave={() => setOverlayProps(null)}
        />
      )}



      {/* 圖片拖曳遮罩 - mobile 版本隱藏 */}
      {isImageDragOver && !isMobileView && (
        <div
          className="ai-commander-drag-overlay"
          onDragOver={(e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            setIsDraggingOver(true);
          }}
          onDragLeave={() => {
            setIsDraggingOver(false);
          }}
          onDrop={handleImageDrop}
        >
          <div className={`ai-commander-drag-message ${isDraggingOver ? 'dragging-over' : ''}`}>
            <div className="ai-commander-drag-icon">📷</div>
            <div className="ai-commander-drag-text">
              {t('dragToAttachImage')}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default React.memo(AICommander);