import React, { useState, useEffect, useRef, useCallback, forwardRef, useImperativeHandle } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import { getCliToolLabel } from './toolIntentLabel';
import SearchIcon from '../../../assets/icon_search_24.svg?react';
import AIRewriteIcon from '../../../assets/icon_ai_rewrite_26.svg?react';
import AddIcon from '../../../assets/icon_chat_add_24.svg?react';
import HistoryIcon from '../../../assets/icon_history_outline_24.svg?react';
import CloseIcon from '../../../assets/icon_close_round_24.svg?react';
import ArrowLeftIcon from '../../../assets/icon_arrow_left_24.svg?react';
import NoteIcon from '../../../assets/icon_note_24.svg?react';
import ArrowIcon from '../../../assets/icon_arrow_right_24.svg?react';
import { useAICommanderAttachmentsStore } from './aiStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useChatBotSessionsStore, useSocketManagerStore } from './chatStore';

import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useSearchRegistry } from '../../../Store/searchRegistry';
import { useTempHintStore } from '../../../Store/uiStore';
import { eventBus } from '../../../Store/eventBus';
import { DEFAULT_MODEL } from '../../../aiService/modelConfig';
import { getWorkspace } from '../../../workspace/Workspace';
import CustomScrollbar from '../../common/CustomScrollbar';
import syncService from '../../../utils/syncService';

import './AICommanderChatRoom.css';

import ChatMessageAssistant from './ChatMessageAssistant';
import AICommanderChatRoomTopbarTitle from './AICommanderChatRoomTopbarTitle';
import CustomToolbar from '../../common/CustomToolbar';
import ImagePreviewWindow from '../../common/ImagePreviewWindow';

// 穩定的空數組引用，避免每次渲染創建新引用導致無限循環
const EMPTY_MESSAGES = [];

interface AICommanderChatRoomProps {
  abortSignal?: AbortSignal | null;
  abortControllerRef?: React.MutableRefObject<AbortController> | null;
  onClose?: (() => void) | null;
  onHistory?: (() => void) | null;
  onBack?: (() => void) | null;
  inputAreaRef?: React.RefObject<{ setInputValue: (val: string) => void }> | null;
  sessionID?: string | null;
  mode?: string;
}

const AICommanderChatRoom = forwardRef<any, AICommanderChatRoomProps>(({ abortSignal = null, abortControllerRef = null, onClose = null, onHistory = null, onBack = null, inputAreaRef = null, sessionID: propSessionID = null, mode = 'chat' }, ref) => {
  const { t } = useTranslation();

  const toolConfig = {
    fetch: {
      Icon: SearchIcon,
      text: t('toolFetch')
    },
    web_search: {
      Icon: SearchIcon,
      text: t('toolWebSearch')
    },
  };

  const setTempHint = useTempHintStore(state => state.setTempHint);

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const scrollContainerRef = useRef(null);
  const isUserScrolledUpRef = useRef(false);
  const ignoreScrollRef = useRef(false);
  const processedTools = useRef(new Set()); // 用於 interrupt 時清理狀態
  const checkedMessagesCount = useRef(0);

  // 根據 mode 選擇使用的 store
  const isTaskMode = mode === 'task';

  // Store 方法
  const updateSession =useChatBotSessionsStore(state => state.updateSession);
  const isInterrupted = useChatBotSessionsStore(state => state.isInterrupted);
  const setIsInterrupted = useChatBotSessionsStore(state => state.setIsInterrupted);

  // 決定 currentSessionID
  const chatStoreSessionID = useChatBotSessionsStore(state => state.currentSessionID);
  const currentSessionID = propSessionID || chatStoreSessionID;

  // 直接訂閱當前 thread 的狀態（響應式）
  // 使用穩定的空數組引用，避免每次渲染時創建新引用導致 useEffect 無限循環
  const messages = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.messages || EMPTY_MESSAGES;
  });
  const isResponding = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.isResponding || false;
  });
  const isStreamingTokens = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.isStreamingTokens || false;
  });
  const isCliPreparing = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.isCliPreparing || false;
  });
  const isSyncing = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.isSyncing || false;
  });
  const forgeStates = useChatBotSessionsStore(state => state.forgeStates || {});
  const hasPreviousMessage = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.hasPreviousMessage || false;
  });

  const title = useChatBotSessionsStore(state => {
    const session = state.sessions.find(t => t.session_id === currentSessionID);
    return session?.title || '';
  });

  // Store 方法（統一用 store.getState() 直接呼叫）
  const setMessages = (updater) => useChatBotSessionsStore.getState().setMessages(currentSessionID, updater);
  const setHasPreviousMessage = (hasPrev) => useChatBotSessionsStore.getState().setHasPreviousMessage(currentSessionID, hasPrev);
  const loadOlderMessages = () => useChatBotSessionsStore.getState().loadOlderMessages(currentSessionID, isTaskMode ? 'task' : 'chat');
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [previewImageSrc, setPreviewImageSrc] = useState('');
  const [thinkingExpanded, setThinkingExpanded] = useState({});

  // 附加項目 store
  const addAttachment = useAICommanderAttachmentsStore(state => state.addAttachment);

  // 獲取當前頁面上下文（用於 chat 模式）
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const [selectedItemDetail, setSelectedItemDetail] = useState<any>(null);

  useEffect(() => {
    if (!lastSelected?.id) { setSelectedItemDetail(null); return; }
    window.electronAPI?.getItem(lastSelected.id).then(item => setSelectedItemDetail(item || lastSelected));
  }, [lastSelected?.id]);

  const getAllItems = useCallback(() => useSearchRegistry.getState().search(''), []);

  // 從 lastSelected 推導 folderId 與 folderType
  const derivedFolderInfo = React.useMemo(() => {
    const item = selectedItemDetail || lastSelected;
    if (!item) return { folderId: null, folderType: null };

    const type = item.itemType;
    if (!type) return { folderId: null, folderType: null };

    if (['today', 'preview', 'completed'].includes(item.id)) {
      return { folderId: null, folderType: type.replace('_FOLDER', '') };
    }

    const baseType = type.replace('_FOLDER', '');
    if (type.endsWith('_FOLDER')) {
      return { folderId: item.id, folderType: baseType };
    }
    return {
      folderId: (item as any).aiFolderID || item.parentID || null,
      folderType: baseType
    };
  }, [selectedItemDetail, lastSelected]);

  // 構建 pageContext（僅 chat 模式使用，層級可疊加）
  const getPageContext = useCallback(() => {
    if (isTaskMode) return null;

    const context: { folder?: any; item?: any } = {};
    const { folderId, folderType } = derivedFolderInfo;

    // ========== 層級 1：資料夾/類型 ==========
    const isVirtualTodoView = lastSelected?.itemType === 'TODO_FOLDER' && ['today', 'preview', 'completed'].includes(lastSelected?.id);
    if (isVirtualTodoView) {
      // 虛擬視圖篩選，無具體 folder
    } else if (folderId && folderType) {
      const allItems = getAllItems();
      const folder = allItems.find(i => i.id === folderId);
      if (folder) {
        context.folder = { pageId: folder.id, pageName: (folder as any)?.name, pageType: folderType };
      }
    }

    // ========== 層級 2：具體項目 ==========
    const item = selectedItemDetail || lastSelected;
    if (item && !item.itemType?.endsWith('_FOLDER')) {
      context.item = { pageId: item.id, pageName: (item as any)?.name || '未命名' };
    }

    if (!context.folder && !context.item) return null;

    return context;
  }, [isTaskMode, derivedFolderInfo, lastSelected, selectedItemDetail, getAllItems]);

  // 獲取當前線程
  const getCurrentSession = () => {
    const sessions = useChatBotSessionsStore.getState().sessions;
    return sessions.find(session => session.session_id === currentSessionID);
  };

  const lastMsg = messages[messages.length - 1];

  // Socket Manager Store
  const socketManager = useSocketManagerStore();
  const chatSessionRef = useRef(null);  // 保留 ref 以兼容現有代碼
  const [isSessionConnected, setIsSessionConnected] = useState(false);

  // 取得當前 thread 的 socket（從 Socket Manager）
  const getCurrentSocket = useCallback(() => {
    if (!currentSessionID) return null;

    // 從 Socket Manager 取得 socket
    const socket = socketManager.getSocket(currentSessionID);

    // 同步到 ref（為了兼容現有代碼）
    if (socket && chatSessionRef.current !== socket) {
      chatSessionRef.current = socket;
    }

    return socket;
  }, [currentSessionID, socketManager]);

  // 監聯 socket 狀態變化
  useEffect(() => {
    const socket = getCurrentSocket();
    if (socket) {
      setIsSessionConnected(socket.isConnected || false);
    } else {
      setIsSessionConnected(false);
    }
  }, [currentSessionID, getCurrentSocket]);

  // 🔧 方案 C：前台恢復時檢查連線狀態
  // 當用戶從後台返回時，檢查 WebSocket 是否還連接，如果斷了就清理並準備重連
  useEffect(() => {
    const handleVisibilityChange = async () => {
      if (document.visibilityState === 'visible') {
        const socket = socketManager.getSocket(currentSessionID);
        const isConnectedProp = socket?.isSocketConnected?.() ?? false;
        const sessionState = useChatBotSessionsStore.getState().getSessionState(currentSessionID);
        const storeMessages = sessionState.messages || [];
        console.log(`[VIS] 頁面恢復，thread=${currentSessionID?.slice(-8)}，socket=${!!socket}，connected=${isConnectedProp}，store有${storeMessages.length}條`);

        const needsPingCheck = isConnectedProp && sessionState.isResponding && socket;
        let isReallyConnected = isConnectedProp;

        if (needsPingCheck) {
          try {
            await socket.ping(2000);
            isReallyConnected = true;
            console.log('[VIS] ping 成功');
          } catch (error) {
            isReallyConnected = false;
            console.log('[VIS] ping 失敗，連接已斷');
          }
        }

        if (currentSessionID && socket && !isReallyConnected) {
          console.log('[VIS] Socket 已斷，清理引用（不 disconnect）');
          chatSessionRef.current = null;
          setIsSessionConnected(false);
        }

        if (currentSessionID) {
          console.log('[VIS] 開始 sync...');
          try {
            await useChatBotSessionsStore.getState().syncCurrentSession();
            const afterSync = useChatBotSessionsStore.getState().getSessionState(currentSessionID).messages?.length || 0;
            console.log(`[VIS] sync 完成，store 現在有 ${afterSync} 條`);
          } catch (error) {
            console.error('[VIS] sync 失敗:', error);
          }
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [currentSessionID, socketManager]);

  // 從 currentSessionID 變化時載入對應的消息和標題、草稿
  useEffect(() => {
    const loadCurrentSession = async () => {
      if (currentSessionID) {
        // 檢查該 thread 是否有活躍連線
        const hasActiveSocket = socketManager.getSocket(currentSessionID);
        const sessionState = useChatBotSessionsStore.getState().getSessionState(currentSessionID);

        if (isTaskMode) {
          // Task 模式：如果該 thread 正在回應中，不要從 server 載入
          if (isResponding) {

            return;
          }
          // Task 模式：從 server 載入執行紀錄

          await useChatBotSessionsStore.getState().loadTaskReportMessages(currentSessionID);
        } else {
          // Chat 模式：如果該 thread 正在回應中且有活躍連線，跳過載入
          if (sessionState.isResponding && hasActiveSocket) {

            return;
          }

          console.log(`[LOAD] 開始 Chat 模式，thread=${currentSessionID.slice(-8)}，hasSocket=${!!hasActiveSocket}，isResponding=${sessionState.isResponding}`);

          // ★ 先查後端狀態（只設定狀態，不在這裡阻塞建 socket）
          let shouldEnsureSocket = false;
          let memberIDForSocket = null;
          if (!hasActiveSocket) {
            try {
              const userData = JSON.parse(localStorage.getItem('userData_local'));
              const memberID = userData?.ID?.toString();
              if (memberID) {
                const { getSessionStatus } = await import('../../../aiService/AIChatBotService');
                const status = await getSessionStatus(memberID, currentSessionID);
                console.log(`[LOAD] 後端 status=${status}`);

                if (status === 'asking') {
                  console.log('[LOAD] AI 處理中，設 isResponding=true（稍後建 socket）');
                  useChatBotSessionsStore.getState().setIsResponding(currentSessionID, true);
                  shouldEnsureSocket = true;
                  memberIDForSocket = memberID;
                } else if (sessionState.isResponding) {
                  console.log('[LOAD] 後端已完成，重置 isResponding');
                  useChatBotSessionsStore.getState().setIsResponding(currentSessionID, false);
                }
              }
            } catch (error) {
              console.error('[LOAD] 查 status 失敗:', error);
            }
          }
          console.log('[LOAD] status 查詢完成，繼續載入消息...');

          // ★ 從本地 DB 載入到 store
          const localSession = await window.electronAPI.getChatbotSessionById(currentSessionID);
          if (localSession && localSession.messages) {
            console.log(`[LOAD] 本地DB有 ${localSession.messages.length} 條，載入到 store`);
            useChatBotSessionsStore.getState().setMessages(currentSessionID, localSession.messages);
          } else {
            console.log('[LOAD] 本地DB無消息');
          }

          // ★ sync 遠端
          console.log('[LOAD] 開始 sync 遠端...');
          await useChatBotSessionsStore.getState().syncCurrentSession();

          // ★ 從 sessionStates 讀取到 local state
          const syncedState = useChatBotSessionsStore.getState().getSessionState(currentSessionID);
          console.log(`[LOAD] sync 完成，sessionStates=${syncedState.messages?.length || 0} 條`);

          if (syncedState.messages && syncedState.messages.length > 0) {
            setMessages(syncedState.messages);
            setHasPreviousMessage(syncedState.hasPreviousMessage);
            console.log(`[LOAD] ✅ setMessages (local state) ${syncedState.messages.length} 條`);
          } else {
            setMessages([]);
            setHasPreviousMessage(false);
            console.log('[LOAD] ⚠️ setMessages([]) 空白');
          }

          // ★ 本地DB + sync 完成後再嘗試建立 socket（避免阻塞畫面）
          if (shouldEnsureSocket && memberIDForSocket) {
            const existingSocket = socketManager.getSocket(currentSessionID);
            if (!existingSocket) {
              const selectedModel = localStorage.getItem('aiCommanderSelectedModel') || DEFAULT_MODEL;
              console.log('[LOAD] 準備建 socket...');
              try {
                const socket = await socketManager.getOrCreateSocket(currentSessionID, memberIDForSocket, {
                  collection: null,
                  sessionID: currentSessionID,
                  model: selectedModel,
                  mode: 'chat',
                  streaming: true
                });
                console.log(`[LOAD] getOrCreateSocket 完成，socket=${!!socket}`);
                if (socket) {
                  chatSessionRef.current = socket;
                  setIsSessionConnected(true);
                  console.log('[LOAD] Socket 連線成功');
                } else {
                  console.log('[LOAD] ⚠️ socket 為 null');
                }
              } catch (socketError) {
                console.error('[LOAD] getOrCreateSocket 失敗:', socketError);
              }
            }
          }
        }
      } else {
        setMessages([]);
        setHasPreviousMessage(false);
      }

      // 重置已檢查的訊息數量，以便在切換線程時重新檢查所有訊息
      checkedMessagesCount.current = 0;

      // 進入 room 後，印出當前所有 message
      if (currentSessionID) {
        const finalState = useChatBotSessionsStore.getState().getSessionState(currentSessionID);
        const finalMessages = finalState?.messages || [];
        console.log(`[ROOM] 進入 room，thread ID: ${currentSessionID.slice(-8)}，共 ${finalMessages.length} 條訊息`);
        console.log(`[ROOM] 所有訊息內容：`, finalMessages);
      }

    };

    loadCurrentSession();
  }, [currentSessionID, isTaskMode]);

  // 送出 user message 的核心邏輯（獨立函數，useImperativeHandle 和 pending message useEffect 共用）
  const getTaskModeModel = useCallback(() => {
    const sessionState = useChatBotSessionsStore.getState().getSessionState(currentSessionID);
    const msgs = sessionState?.messages || [];
    const firstUser = msgs.find(m => m.role === 'user');
    const agentAttach = firstUser?.attachedItems?.find(item => item.type === 'agent');
    return agentAttach?.model || DEFAULT_MODEL;
  }, [currentSessionID]);

  const sendUserMessage = useCallback(async (userMsg: any, sessionID?: string) => {
    const capturedSessionID = sessionID || currentSessionID;
    console.log('[Pending-DEBUG] sendUserMessage called, capturedSessionID:', capturedSessionID, 'from:', sessionID ? 'param' : 'closure', 'content:', typeof userMsg?.content === 'string' ? userMsg.content.substring(0, 30) : '(object)');
    if (!capturedSessionID) return;
    useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, true);

    const userData = JSON.parse(localStorage.getItem('userData_local'));
    const memberID = userData?.ID?.toString() || `user_${Date.now()}`;

    try {
      let socket = socketManager.getSocket(capturedSessionID);
      const needNewSocket = !socket || !socket.isSocketConnected || !socket.isSocketConnected();

      if (needNewSocket) {
        const selectedModel = isTaskMode ? getTaskModeModel() : (localStorage.getItem('aiCommanderSelectedModel') || DEFAULT_MODEL);
        const pageContext = getPageContext();
        const sessionState = useChatBotSessionsStore.getState().getSessionState(capturedSessionID);
        const isNewSession = sessionState.isNew === true;

        socket = await socketManager.getOrCreateSocket(capturedSessionID, memberID, {
          collection: null,
          sessionID: capturedSessionID,
          model: selectedModel,
          mode: isTaskMode ? 'task' : 'chat',
          streaming: true,
          ...(pageContext && { pageContext }),
          ...(isNewSession && { isNew: true }),
        });

        if (isNewSession) {
          useChatBotSessionsStore.getState().setSessionNew(capturedSessionID, false);
        }

        if (!socket) {
          const activeCount = socketManager.getActiveSocketCount();
          if (activeCount >= 3) {
            const confirmed = await new Promise<boolean>(resolve => {
              useDialogStore.getState().open('sessionLimit', {
                activeCount,
                onConfirm: () => resolve(true),
                onCancel: () => resolve(false),
              });
            });
            if (!confirmed) {
              useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);
              return;
            }
            socketManager.evictOldestSocket();
            socket = await socketManager.getOrCreateSocket(capturedSessionID, memberID, {
              collection: null,
              sessionID: capturedSessionID,
              model: selectedModel,
              mode: isTaskMode ? 'task' : 'chat',
              streaming: true,
              ...(pageContext && { pageContext }),
              ...(isNewSession && { isNew: true }),
            });
          }
          if (!socket) {
            console.error('[ChatRoom] 無法創建 socket');
            useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);
            return;
          }
        }

        chatSessionRef.current = socket;
        setIsSessionConnected(true);
      }

      const isSocketReady = socket && socket.isSocketConnected && socket.isSocketConnected();

      if (isSocketReady) {
        try {
          const hasAttachments = userMsg.attachedItems && Array.isArray(userMsg.attachedItems) && userMsg.attachedItems.length > 0;
          const wsResponse = await socket.sendMessage(userMsg, hasAttachments ? null : getPageContext());

          if (wsResponse.type === 'message') {
            useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => [...prev, {
              role: 'assistant',
              content: wsResponse.content
            }]);
          }
          return;
        } catch (wsError) {
          console.error('[ChatRoom] WebSocket 發送失敗:', wsError);
          useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);
          useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => [...prev, {
            role: 'assistant',
            content: '抱歉，連接發生問題，請稍後再試。'
          }]);
          return;
        }
      } else {
        console.error('[ChatRoom] WebSocket 未連接，嘗試重新創建...');
        const selectedModel = isTaskMode ? getTaskModeModel() : (localStorage.getItem('aiCommanderSelectedModel') || DEFAULT_MODEL);
        socket = await socketManager.getOrCreateSocket(capturedSessionID, memberID, {
          collection: null,
          sessionID: capturedSessionID,
          model: selectedModel,
          mode: isTaskMode ? 'task' : 'chat',
          streaming: true
        });

        if (socket && socket.isSocketConnected && socket.isSocketConnected()) {
          const hasAttachments = userMsg.attachedItems && Array.isArray(userMsg.attachedItems) && userMsg.attachedItems.length > 0;
          await socket.sendMessage(userMsg, hasAttachments ? null : getPageContext());
          return;
        }

        useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);
        useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => [...prev, {
          role: 'assistant',
          content: '抱歉，目前無法連接到服務器，請檢查網絡連接後重試。'
        }]);
      }
    } catch (error) {
      if (error.name === 'AbortError') return;
      console.error('[ChatRoom] 對話請求失敗:', error);
      useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => [...prev, {
        role: 'assistant',
        content: '抱歉，目前無法處理您的請求，請稍後再試。'
      }]);
    }
  }, [currentSessionID, socketManager, isTaskMode, getPageContext, getTaskModeModel]);

  // 暴露方法給父組件（InputArea 透過 chatRoomRef 呼叫）
  useImperativeHandle(ref, () => ({
    interruptStreaming: () => {
      console.log('[Interrupt] interruptStreaming called, currentSessionID:', currentSessionID);
      const socket = getCurrentSocket();
      console.log('[Interrupt] socket:', socket, 'isConnected:', socket?.isConnected);
      if (socket) {
        const success = socket.interrupt();
        console.log('[Interrupt] socket.interrupt() result:', success);
      } else {
        console.log('[Interrupt] No socket available');
      }
    },
    disconnectSession: () => {
      if (currentSessionID) {
        socketManager.disconnectSocket(currentSessionID);
        chatSessionRef.current = null;
        setIsSessionConnected(false);
      }
    },
    clearDraft: (sessionID) => {
      if (sessionID) {
        try {
          const sessionDrafts = JSON.parse(localStorage.getItem('sessionDraft') || '{}');
          delete sessionDrafts[sessionID];
          localStorage.setItem('sessionDraft', JSON.stringify(sessionDrafts));
        } catch (error) {
          console.error('清空草稿失敗:', error);
        }
      }
    },
    sendUserMessage,
  }), [currentSessionID, getCurrentSocket, socketManager, sendUserMessage]);

  // 新 session 時 ChatRoom 尚未 mount，InputArea 把 message 寫入 store；ChatRoom mount 後在這裡撿起來送
  const pendingUserMessage = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.pendingUserMessage || null;
  });

  useEffect(() => {
    console.log('[Pending-DEBUG] useEffect fired, pending:', !!pendingUserMessage, 'sessionID:', currentSessionID);
    if (pendingUserMessage && currentSessionID) {
      console.log('[Pending-DEBUG] consuming pending message, content:', typeof pendingUserMessage.content === 'string' ? pendingUserMessage.content.substring(0, 30) : '(object)');
      useChatBotSessionsStore.getState().setPendingUserMessage(currentSessionID, null);
      sendUserMessage(pendingUserMessage, currentSessionID);
    }
  }, [pendingUserMessage, currentSessionID, sendUserMessage]);

  // 中斷當前動作並清除後續訊息的函數
  const interruptAndClearMessages = (targetMessageIndex) => {
    // 1. 中斷當前的所有動作
    if (abortControllerRef?.current && !abortControllerRef.current.signal.aborted) {
      abortControllerRef.current.abort();
      // 創建新的 AbortController 供後續使用
      abortControllerRef.current = new AbortController();
    }

    // 2. 設置中斷狀態
    setIsInterrupted(true);

    // 3. 清除目標訊息之後的所有訊息
    setMessages(prev => prev.slice(0, targetMessageIndex + 1));

    // 4. 清除已處理的工具記錄
    processedTools.current.clear();

    // 5. 重置中斷狀態，準備重新執行
    safeSetTimeout(() => {
      setIsInterrupted(false);
    }, 100);
  };


  const isThinking = lastMsg && (
    (lastMsg.role === 'assistant' && lastMsg.tool_calls && lastMsg.tool_calls.length > 0)
  );

  // 檢查是否滾動到底部
  const isScrolledToBottom = useCallback(() => {
    if (!scrollContainerRef.current) return true;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const threshold = 60; // 加大容差，避免串流期間內容增長導致誤判
    return scrollHeight - scrollTop - clientHeight <= threshold;
  }, []);

  // 滾動到底部（串流期間使用 instant，避免動畫追不上內容增長）
  const scrollToBottom = useCallback((smooth = true) => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: smooth ? 'smooth' : 'auto'
      });
    }
  }, []);

  // 監聽滾動事件，判斷用戶是否主動向上滾動（使用 ref 即時生效）
  const handleScroll = useCallback(() => {
    if (ignoreScrollRef.current) return;
    isUserScrolledUpRef.current = !isScrolledToBottom();
  }, [isScrolledToBottom]);

  // 綁定滾動事件監聽器（handleScroll 穩定不變，不需要重新綁定）
  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) return;

    scrollContainer.addEventListener('scroll', handleScroll);
    return () => {
      scrollContainer.removeEventListener('scroll', handleScroll);
    };
  }, [handleScroll]);

  // 手機版：鍵盤彈出/收起時的滾動處理
  // 使用 ResizeObserver 監聽滾動容器大小變化，實現即時調整
  const wasAtBottomBeforeResizeRef = useRef(true);
  const isResizingRef = useRef(false);

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const resizeObserver = new ResizeObserver(() => {
      if (!scrollContainerRef.current) return;

      // 如果正在 resize 過程中，且之前在底部，立即滾動到底部（無動畫）
      if (isResizingRef.current && wasAtBottomBeforeResizeRef.current) {
        scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
      }
    });

    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
    };
  }, []);

  // 監聽 visualViewport 變化，標記 resize 狀態
  const initialViewportHeightRef = useRef(window.visualViewport?.height || window.innerHeight);

  useEffect(() => {
    const KEYBOARD_THRESHOLD = 150;
    let resizeEndTimer = null;

    const handleViewportResize = () => {
      if (!window.visualViewport || !scrollContainerRef.current) return;

      const currentHeight = window.visualViewport.height;
      const initialHeight = initialViewportHeightRef.current;
      const keyboardHeight = initialHeight - currentHeight;

      // 開始 resize（鍵盤高度變化超過閾值）
      if (Math.abs(keyboardHeight) > KEYBOARD_THRESHOLD && !isResizingRef.current) {
        // 記錄 resize 前是否在底部
        wasAtBottomBeforeResizeRef.current = isScrolledToBottom();
        isResizingRef.current = true;
        ignoreScrollRef.current = true;
      }

      // 清除之前的結束計時器
      if (resizeEndTimer) clearTimeout(resizeEndTimer);

      // 設置 resize 結束計時器
      resizeEndTimer = setTimeout(() => {
        isResizingRef.current = false;
        ignoreScrollRef.current = false;

        // 更新初始高度（如果鍵盤收起了）
        if (Math.abs(keyboardHeight) < 50) {
          initialViewportHeightRef.current = currentHeight;
        }
      }, 300);
    };

    window.visualViewport?.addEventListener('resize', handleViewportResize);

    return () => {
      window.visualViewport?.removeEventListener('resize', handleViewportResize);
      if (resizeEndTimer) clearTimeout(resizeEndTimer);
    };
  }, []);

  // AI 開始回應時，重置下滾狀態，確保新回應能自動下滾
  useEffect(() => {
    if (isResponding) {
      isUserScrolledUpRef.current = false;
    }
  }, [isResponding]);

  // 監聽 messages 內容變化，處理滾動（包括流式更新）
  useEffect(() => {
    if (messages.length === 0) return;

    // 如果用戶主動向上滾動且不是第一則訊息，跳過自動滾動
    if (isUserScrolledUpRef.current && messages.length > 1) {
      return;
    }

    // 暫時忽略滾動事件，防止滾動過程中誤觸發 handleScroll
    ignoreScrollRef.current = true;

    // 串流期間使用 instant 滾動（避免動畫追不上內容增長），非串流用 smooth
    const useSmooth = !isStreamingTokens;
    scrollToBottom(useSmooth);

    // 用 requestAnimationFrame 確保滾動完成後再恢復監聽
    requestAnimationFrame(() => {
      ignoreScrollRef.current = false;
    });
  }, [messages, isStreamingTokens, scrollToBottom]); // 監聽整個 messages 陣列，包括內容變化

  // 判斷最後一個 assistant message 是否有 tool_calls
  const lastAssistantMsg = [...messages].reverse().find(msg => msg.role === 'assistant');
  const hasToolCalls = lastAssistantMsg?.tool_calls && lastAssistantMsg.tool_calls.length > 0;

  // 判斷是否需要顯示思考中的指示器
  // 當 isResponding 為 true 且沒有正在接收 token 且沒有 tool_calls 時顯示
  // 一旦有 tool_calls 出現，tool 項目本身就是視覺反饋，不需要底部指示器
  // 修正：task 模式下，如果 messages 為空，不顯示思考中（表示紀錄已過期）
  const showThinkingRaw = isResponding && !isStreamingTokens && !hasToolCalls && !(isTaskMode && messages.length === 0);

  // debounce：「正在思考」需持續 300ms 才顯示，避免 isResponding→cli_preparing 之間的瞬間閃爍
  const [showThinkingIndicator, setShowThinkingIndicator] = useState(false);
  useEffect(() => {
    if (showThinkingRaw) {
      const timer = setTimeout(() => setShowThinkingIndicator(true), 300);
      return () => clearTimeout(timer);
    }
    setShowThinkingIndicator(false);
  }, [showThinkingRaw]);

  // 思考指示器出現時，補一次自動滾動（因為 messages 不會變，主滾動 effect 不會觸發）
  useEffect(() => {
    if (showThinkingIndicator && !isUserScrolledUpRef.current) {
      ignoreScrollRef.current = true;
      scrollToBottom(true);
      requestAnimationFrame(() => {
        ignoreScrollRef.current = false;
      });
    }
  }, [showThinkingIndicator, scrollToBottom]);

  // 找出最後一個 assistant message 的 index，判斷是否需要動畫
  const lastAssistantIndex = (() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'assistant') return i;
    }
    return -1;
  })();

  useEffect(() => {

  }, [messages]);

  // 監聽 messages 變化，檢查 tool 訊息中的 version
  useEffect(() => {
    const checkToolVersion = async () => {
      // 只檢查新添加的訊息
      const newMessages = messages.slice(checkedMessagesCount.current);

      for (const msg of newMessages) {
        if (msg.role === 'tool' && msg.content) {
          try {
            // 嘗試解析 content
            let toolContent;
            if (typeof msg.content === 'string' && msg.content.trim().startsWith('{')) {
              // 先嘗試直接解析（對齊渲染區塊的做法）
              try {
                toolContent = JSON.parse(msg.content);
              } catch {
                // 如果直接解析失敗，只處理特殊控制字符（排除 \n \r \t）
                const sanitizedContent = msg.content
                  .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, (char) => {
                    return `\\u${char.charCodeAt(0).toString(16).padStart(4, '0')}`;
                  });
                toolContent = JSON.parse(sanitizedContent);
              }
            } else {
              continue;
            }

            // AI tool 回傳 version 表示 server 端資料已變更，觸發同步
            if (toolContent.version !== undefined && toolContent.version !== null) {
              await syncService.syncChanges();
              useChatBotSessionsStore.getState().setMessages(currentSessionID, prev => [...prev]);
              eventBus.emit('editor:force-reload');
            }

          } catch (error) {
            // console.error('解析 tool 訊息失敗:', error);
          }
        }
      }

      // 更新已檢查的訊息數量
      checkedMessagesCount.current = messages.length;
    };

    if (messages.length > checkedMessagesCount.current) {
      checkToolVersion();
    }
  }, [messages, currentSessionID]);

  // user message 的發送已移至 useImperativeHandle.sendUserMessage，由 InputArea 直接呼叫

  // 監聯中斷事件，恢復輸入框的值
  const streamInterruptedEvent = useSocketManagerStore(state => state.streamInterruptedEvent);
  const clearStreamInterruptedEvent = useSocketManagerStore(state => state.clearStreamInterruptedEvent);

  // 記錄上次處理的事件 timestamp，避免重複處理
  const lastHandledEventRef = useRef(null);

  useEffect(() => {
    // 只有當事件是新的（timestamp 不同）且 sessionID 匹配時才處理
    if (streamInterruptedEvent &&
      streamInterruptedEvent.sessionID === currentSessionID &&
      streamInterruptedEvent.timestamp !== lastHandledEventRef.current) {

      // 記錄已處理
      lastHandledEventRef.current = streamInterruptedEvent.timestamp;

      // 清空去重記錄
      processedTools.current.clear();

      // 清理 socket ref
      chatSessionRef.current = null;
      setIsSessionConnected(false);

      // 恢復輸入框的值
      if (inputAreaRef?.current && streamInterruptedEvent.originalMessage) {
        const originalMsg = streamInterruptedEvent.originalMessage as any;
        const contentToRestore = typeof originalMsg === 'object' ? originalMsg.content : originalMsg;
        inputAreaRef.current.setInputValue(contentToRestore);

        // 恢復附加的項目
        if (originalMsg.attachedItems && Array.isArray(originalMsg.attachedItems)) {
          const currentAttachedItems = useAICommanderAttachmentsStore.getState().attachedItems;
          const existingIds = new Set(currentAttachedItems.map(item => item.id));

          originalMsg.attachedItems.forEach(item => {
            if (!existingIds.has(item.id)) {
              addAttachment(item);
            }
          });
        }
      }

      // 清除事件
      clearStreamInterruptedEvent();
    }
  }, [streamInterruptedEvent, currentSessionID, clearStreamInterruptedEvent, addAttachment]);

  // 解析用戶消息中的 #[ID] 標籤，轉換成可點擊的元素
  const parseUserMessage = (content) => {
    if (!content) return null;

    // 匹配 #[ID] 格式
    const regex = /#\[([^\]]+)\]/g;
    const parts = [];
    let lastIndex = 0;
    let match;

    while ((match = regex.exec(content)) !== null) {
      // 添加標籤前的文字
      if (match.index > lastIndex) {
        parts.push({
          type: 'text',
          content: content.substring(lastIndex, match.index)
        });
      }

      // 添加標籤
      const id = match[1];
      parts.push({
        type: 'mention',
        id: id
      });

      lastIndex = regex.lastIndex;
    }

    // 添加剩餘的文字
    if (lastIndex < content.length) {
      parts.push({
        type: 'text',
        content: content.substring(lastIndex)
      });
    }

    // 如果沒有標籤，直接返回原文
    if (parts.length === 0) {
      return content;
    }

    // 渲染解析後的內容
    return parts.map((part, index) => {
      if (part.type === 'text') {
        return <span key={index}>{part.content}</span>;
      } else if (part.type === 'mention') {
        const allItems = getAllItems();
        const item = allItems.find(i => i.id === part.id);

        if (item) {
          const type = item.itemType;
          const provider = useSearchRegistry.getState().getProvider(type);
          const displayName = (item as any).name || (item as any).title || (item as any).aiTitle || t('untitled');

          const typeClass = type?.endsWith('_FOLDER')
            ? ((item as any).isGroup ? 'foldergroup' : 'folder')
            : type?.toLowerCase().replace('_', '') || 'note';

          const handleClick = () => {
            useSelectedItemsStore.getState().setSelectedItems([item], { scrollToFocusItem: true, highlightItemId: item.id });
          };

          return (
            <span key={index} className={`chat-message-user-attach-tag chat-message-user-attach-tag-${typeClass}`} onClick={handleClick}>
              <div className="ai-commander-attach-tag-icon">
                {provider?.renderIcon(item) || <NoteIcon />}
              </div>
              <span className="ai-commander-attach-tag-text">{displayName}</span>
            </span>
          );
        }

        return <span key={index}>#{part.id}</span>;
      }
      return null;
    });
  };

  // 提取消息內容中的所有 #[ID]
  const extractInlineIds = (content) => {
    if (!content) return new Set();

    const regex = /#\[([^\]]+)\]/g;
    const ids = new Set();
    let match;

    while ((match = regex.exec(content)) !== null) {
      ids.add(match[1]);
    }

    return ids;
  };

  // 統一處理所有導航（組件級別）
  const handleNavigate = useCallback(async ({ type, id }) => {

    if (mode === 'task') {
      const upperType = type.toUpperCase();
      getWorkspace()?.openWindow({ id, itemType: upperType });
      return;
    }

    const item = await (window.electronAPI as any)?.getItem(id);
    if (!item) return;

    useSelectedItemsStore.getState().setSelectedItems([item], { scrollToFocusItem: true, highlightItemId: id });
  }, [mode]);

  return (
    <>
      {/* Topbar — chat 模式：標題 + 新增/歷史/關閉；task 模式：返回 + 標題 */}
      {(mode !== 'task' || onBack) && (
        <CustomToolbar
          className="ai-commander-chat-room-topbar"
          left={
            mode === 'task' && onBack
              ? {
                  buttons: [{ icon: <ArrowLeftIcon />, onClick: onBack }],
                  suffix: <AICommanderChatRoomTopbarTitle title={title} />,
                }
              : { prefix: <AICommanderChatRoomTopbarTitle title={title} /> }
          }
          right={
            mode !== 'task'
              ? {
                  buttons: [
                    { icon: <AddIcon />, onClick: () => useChatBotSessionsStore.getState().setCurrentSessionID(null) },
                    { icon: <HistoryIcon />, onClick: () => onHistory?.() },
                    { icon: <CloseIcon />, onClick: () => onClose?.() },
                  ],
                }
              : undefined
          }
        />
      )}

      <CustomScrollbar ref={scrollContainerRef}>
        <div className="ai-commander-chat-room">
          <>
            {/* Task 模式：當 messages 為空且不在回應中時，顯示執行紀錄已過期 */}
            {isTaskMode && messages.length === 0 && !isResponding && (
              <div className="ai-commander-chat-room-expired-hint">
                {t('taskReportExpired')}
              </div>
            )}

            {/* 載入較舊訊息按鈕 */}
            {hasPreviousMessage && (
              <div
                className={`load-older-messages-btn ${isSyncing ? 'loading' : ''}`}
                onClick={async () => {
                  if (isSyncing || isResponding) return; // 防止重複點擊或 AI 回應中點擊

                  // 記住載入前的滾動高度
                  const scrollContainer = scrollContainerRef.current;
                  const oldScrollHeight = scrollContainer ? scrollContainer.scrollHeight : 0;

                  await loadOlderMessages();

                  // 載入完成後，調整滾動位置以保持用戶的閱讀位置
                  safeSetTimeout(() => {
                    if (scrollContainer) {
                      const newScrollHeight = scrollContainer.scrollHeight;
                      const heightDifference = newScrollHeight - oldScrollHeight;
                      if (heightDifference > 0) {
                        scrollContainer.scrollTop = heightDifference;
                      }
                    }
                  }, 100);
                }}
              >
                {isSyncing ? '載入中...' : '---載入較舊的訊息---'}
              </div>
            )}
            {Array.isArray(messages) && messages.map((msg, idx) => {
              if (msg.role === 'user') {
                const attachedImages = msg.attachedItems?.filter(item => item.type === 'image') || [];
                const attachedItems = msg.attachedItems?.filter(item => item.type !== 'image') || [];

                return (
                  <div key={idx} className="chat-message-user">
                    {attachedImages.length > 0 && (
                      <>
                        <div className="chat-message-user-images">
                          {attachedImages.map((image) => (
                            <img
                              key={image.id}
                              src={image.url}
                              alt={image.title}
                              className="chat-message-user-image"
                              onClick={() => {
                                setPreviewImageSrc(image.url);
                                setShowImagePreview(true);
                              }}
                            />
                          ))}
                        </div>
                        <div className="chat-message-user-divider"></div>
                      </>
                    )}
                    <div>{parseUserMessage(msg.content)}</div>
                    {(() => {
                      const inlineIds = extractInlineIds(msg.content);
                      const filtered = attachedItems.filter(item => !inlineIds.has(item.id));

                      return filtered.length > 0 && (
                        <>
                          <div className="chat-message-user-divider"></div>
                          <div className="chat-message-user-attachments">
                            {filtered.map((item) => {
                              const provider = item.itemType ? useSearchRegistry.getState().getProvider(item.itemType) : null;
                              return (
                                <div
                                  key={item.id}
                                  className="chat-message-user-attach-tag"
                                  onClick={() => handleNavigate({ type: item.itemType?.toLowerCase() || item.type, id: item.id })}
                                >
                                  <div className="ai-commander-attach-tag-icon">
                                    {provider?.renderIcon(item)}
                                  </div>
                                  <span className="ai-commander-attach-tag-text">
                                    {item.name || item.title || item.aiTitle || t('untitled')}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </>
                      );
                    })()}
                  </div>
                );
              } else if (msg.role === 'thinking') {
                return (
                  <div key={idx} className="chat-message-thinking">
                    <div className="thinking-indicator">🤔 思考中...</div>
                    <div className="thinking-content">{msg.content}</div>
                  </div>
                );
              } else if (msg.role === 'assistant') {
                const elements = [];

                // 從 content list 中提取 thinking 文本
                let thinkingText = '';
                if (Array.isArray(msg.content)) {
                  const thinkingBlock = msg.content.find(block => block.type === 'thinking');
                  if (thinkingBlock) {
                    thinkingText = thinkingBlock.thinking || '';
                  }
                }

                // 如果有 thinking 內容，先顯示可折疊的 thinking
                if (thinkingText && thinkingText.trim()) {
                  const thinkingKey = `${idx}-thinking`;
                  // 檢查是否有 content（兼容 string 和 array 格式）
                  let hasContent = false;
                  if (msg.content) {
                    if (typeof msg.content === 'string') {
                      hasContent = msg.content.trim().length > 0;
                    } else if (Array.isArray(msg.content)) {
                      // content 是 array，檢查是否有 text block
                      hasContent = msg.content.some(block =>
                        block.type === 'text' && block.text && block.text.trim().length > 0
                      );
                    }
                  }
                  // 判斷思考是否完成：有 content 或有 tool_calls 都表示已完成
                  const hasToolCalls = msg.tool_calls && msg.tool_calls.length > 0;
                  const isCompleted = hasContent || hasToolCalls;
                  const isExpanded = thinkingExpanded[thinkingKey] ?? !isCompleted;

                  // 決定顯示文字
                  let displayText;
                  if (!isCompleted) {
                    displayText = t('thinkingInProgress');
                  } else if (isExpanded) {
                    displayText = t('collapseThinking');
                  } else {
                    displayText = t('expandThinking');
                  }

                  elements.push(
                    <div key={thinkingKey} className="chat-message-thinking">
                      <div
                        className="thinking-header"
                        onClick={() => setThinkingExpanded(prev => ({ ...prev, [thinkingKey]: !prev[thinkingKey] }))}
                      >
                        <span className="thinking-indicator">
                          {displayText}
                          <ArrowIcon className={`thinking-toggle ${isExpanded ? 'expanded' : ''}`} />
                        </span>
                      </div>
                      {isExpanded && (
                        <div className="thinking-content">{thinkingText}</div>
                      )}
                    </div>
                  );
                }

                // 如果有 content，顯示 assistant 訊息
                // 需要檢查 content 是否有實際內容（不只是空字串或只有 thinking block）
                let hasActualContent = false;
                if (msg.content) {
                  if (typeof msg.content === 'string') {
                    hasActualContent = msg.content.trim().length > 0;
                  } else if (Array.isArray(msg.content)) {
                    const textBlocks = msg.content.filter(block => block.type === 'text');
                    hasActualContent = textBlocks.some(block => block.text && block.text.trim().length > 0);
                  }
                }

                if (hasActualContent) {
                  elements.push(
                    <ChatMessageAssistant
                      key={`${idx}-content`}
                      content={msg.content}
                      messages={messages}
                      currentMessageIndex={idx}
                      interruptAndClearMessages={interruptAndClearMessages}
                      setMessages={setMessages}
                      mode={mode}
                      onLinkClick={handleNavigate}
                      isResponding={isResponding}
                    />
                  );
                }
                // 如果有 tool_calls，只處理 forge 和 fetch/web_search
                if (msg.tool_calls && msg.tool_calls.length > 0) {
                  msg.tool_calls.forEach((toolCall, toolIndex) => {
                    const functionName = toolCall.function.name;

                    // 插件鍛造卡片
                    if (functionName === 'mcp__plugin-forge__plugin_forge') {
                      let forgeTitle = '';
                      try {
                        const args = JSON.parse(toolCall.function.arguments);
                        forgeTitle = args.title || t('forgeInit');
                      } catch {}
                      const liveForge = forgeStates[toolCall.id];
                      const forgeState = liveForge
                        || { active: false, title: '', currentIntent: '', status: 'done' as const, sessionId: '' };
                      elements.push(
                        <div key={`forge-${toolCall.id}`} className="sub-agent-card">
                          <div className="sub-agent-title">{forgeTitle}</div>
                          <div className={`sub-agent-intent ${forgeState.status === 'error' ? 'error' : forgeState.status === 'cancelled' ? 'cancelled' : ''}`}>
                            {forgeState.status === 'running' && <span className="sub-agent-dot" />}
                            {forgeState.currentIntent || (
                              forgeState.status === 'done'
                                ? t('forgeCompleted')
                                : forgeState.status === 'cancelled'
                                  ? t('forgeCancelled')
                                  : t('forgeWaiting')
                            )}
                          </div>
                        </div>
                      );
                      return;
                    }

                    // CLI 內建工具用 getCliToolLabel 產生多語言標題
                    let cliDescription = '';
                    try {
                      const args = JSON.parse(toolCall.function.arguments);
                      cliDescription = getCliToolLabel(functionName, args);
                    } catch (e) {}

                    const matched = toolConfig[functionName];
                    const { Icon, text } = matched || { Icon: AIRewriteIcon, text: cliDescription || functionName };
                    const hasWave = idx === lastAssistantIndex;

                    let extra = '';
                    if (matched) {
                      try {
                        const args = JSON.parse(toolCall.function.arguments);
                        if (functionName === 'web_search' && args.q) extra = args.q;
                        if (functionName === 'fetch' && args.url) extra = args.url;
                      } catch {}
                    }

                    elements.push(
                      <div key={`${idx}-tool-${toolIndex}`} className="chat-message-tool">
                        <Icon />
                        <span className={hasWave ? "loading-wave" : ""}>
                          {text}
                          {extra && <> {extra}</>}
                        </span>
                      </div>
                    );
                  });
                }

                // 如果沒有任何內容，返回 null
                if (elements.length === 0) {
                  return null;
                }

                // 如果只有一個元素，直接返回
                if (elements.length === 1) {
                  return elements[0];
                }

                // 如果有多個元素，用 Fragment 包裝
                return (
                  <React.Fragment key={idx}>
                    {elements}
                  </React.Fragment>
                );
              } else if (msg.role === 'tool') {
                // 處理特殊的 tool 訊息（noteID、search_mergeable、interrupt）
                // 非 JSON 或解析失敗的 tool result 不需要特殊 UI，靜默跳過
                try {
                  let toolResult;
                  if (typeof msg.content === 'string' && msg.content.trim().startsWith('{')) {
                    try {
                      toolResult = JSON.parse(msg.content);
                    } catch {
                      const cleaned = msg.content
                        .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, (char) => {
                          return `\\u${char.charCodeAt(0).toString(16).padStart(4, '0')}`;
                        });
                      try {
                        toolResult = JSON.parse(cleaned);
                      } catch {
                        return null;
                      }
                    }
                  } else {
                    return null;
                  }

                  if (toolResult.noteID) {
                    const noteId = toolResult.noteID;
                    const matchedFolders = JSON.stringify(toolResult.matchedFolderNames || []);
                    const content = `<note-embed note-id="${noteId}"></note-embed>\n<note-folder-selector note-id="${noteId}" matched-folders='${matchedFolders}'></note-folder-selector>`;

                return (
                      <ChatMessageAssistant
                        key={idx}
                        content={content}
                        messages={messages}
                        currentMessageIndex={idx}
                        interruptAndClearMessages={interruptAndClearMessages}
                        setMessages={setMessages}
                        mode={mode}
                        onLinkClick={handleNavigate}
                      />
                    );
                  }

                  if (toolResult.name === 'search_mergeable_note_in_folder' && toolResult.relatedNotesIds !== undefined) {
                    if (toolResult.relatedNotesIds.length === 0) {
                      return (
                        <ChatMessageAssistant
                          key={idx}
                          content={t('noRelatedNotes')}
                          messages={messages}
                          currentMessageIndex={idx}
                          interruptAndClearMessages={interruptAndClearMessages}
                          setMessages={setMessages}
                          mode={mode}
                          onLinkClick={handleNavigate}
                        />
                      );
                    }

                    return null;
                  }

                  if (toolResult.function === 'interrupt') {
                    return (
                      <div key={idx} style={{
                        display: 'flex',
                        alignItems: 'center',
                        margin: '8px 0',
                        gap: '12px'
                      }}>
                        <div style={{
                          flex: 1,
                          height: '1px',
                          background: 'color-mix(in srgb, var(--on) 16%, transparent)'
                        }}></div>
                        <span style={{
                          color: 'color-mix(in srgb, var(--on) 50%, transparent)',
                          fontSize: '14px',
                          whiteSpace: 'nowrap'
                        }}>
                          {t('interrupted')}
                        </span>
                        <div style={{
                          flex: 1,
                          height: '1px',
                          background: 'color-mix(in srgb, var(--on) 16%, transparent)'
                        }}></div>
                      </div>
                    );
                  }
                } catch {
                  return null;
                }
                return null;
              }
              return null;
            })}

            {/* 當 CLI 正在準備時，優先顯示準備中指示器 */}
            {isCliPreparing && (
              <div className="chat-message-tool">
                <SearchIcon />
                <span className="loading-wave">{t('cliPreparing')}</span>
              </div>
            )}
            {/* 當 AI 正在響應但還沒有內容回應時，顯示思考中指示器 */}
            {!isCliPreparing && showThinkingIndicator && (
              <div className="chat-message-tool">
                <SearchIcon />
                <span className="loading-wave">{t('toolThinking')}</span>
              </div>
            )}
          </>
        </div>
      </CustomScrollbar>

      <ImagePreviewWindow
        isOpen={showImagePreview}
        src={previewImageSrc}
        onClose={() => setShowImagePreview(false)}
      />
    </>
  );
});

export default AICommanderChatRoom; 
