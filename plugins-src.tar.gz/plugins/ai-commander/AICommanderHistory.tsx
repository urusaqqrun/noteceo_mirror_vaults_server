import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './AICommanderHistory.css';
import ChatIcon from '../../../assets/bk_chat_bubble_outline_26.svg?react';
import SearchIcon from '../../../assets/icon_search_24.svg?react';
import { useChatBotSessionsStore } from './chatStore';
import { formatTimestamp } from '../../Utils/dateFormat';
import { updateSessionTitle } from '../../../aiService/AIChatBotService';
import { CustomDialog } from '../../common/CustomDialog';

// 歷史項目 loader 組件
const HistoryLoader = () => (
  <div className="aicommanderhistory-history-item-loader" />
);

const AICommanderHistory = ({ onCancel }) => {
  const { t } = useTranslation();

  const sessions = useChatBotSessionsStore((state) => state.sessions);
  const sessionStates = useChatBotSessionsStore((state) => state.sessionStates);
  const setCurrentSessionID = useChatBotSessionsStore((state) => state.setCurrentSessionID);
  const updateSession = useChatBotSessionsStore((state) => state.updateSession);
  const deleteSession = useChatBotSessionsStore((state) => state.deleteSession);
  const [historyItems, setHistoryItems] = useState<{ id: string; title: string; time: string }[]>([]);

  // 右鍵選單狀態
  const [contextMenu, setContextMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    itemId: null
  });

  // 編輯名稱 Dialog 狀態
  const [renameDialog, setRenameDialog] = useState({
    isOpen: false,
    itemId: null,
    title: ''
  });

  // 刪除確認 Dialog 狀態
  const [deleteDialog, setDeleteDialog] = useState({
    isOpen: false,
    itemId: null,
    title: ''
  });

  // 從 localStorage 讀取搜尋狀態
  const [isSearchExpanded, setIsSearchExpanded] = useState(() => {
    const saved = localStorage.getItem('aiCommanderHistorySearchExpanded');
    return saved === 'true';
  });
  const [searchQuery, setSearchQuery] = useState(() => {
    return localStorage.getItem('aiCommanderHistorySearchQuery') || '';
  });

  // 保存搜尋狀態到 localStorage
  useEffect(() => {
    localStorage.setItem('aiCommanderHistorySearchExpanded', isSearchExpanded.toString());
  }, [isSearchExpanded]);

  useEffect(() => {
    localStorage.setItem('aiCommanderHistorySearchQuery', searchQuery);
  }, [searchQuery]);

  // 關閉右鍵選單
  const closeContextMenu = () => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0,
      itemId: null
    });
  };

  // 處理右鍵選單的關閉（點擊外部時）
  useEffect(() => {
    const handleOutsideInteraction = (e) => {
      if (!contextMenu.visible) return;
      const menuEl = document.querySelector('.aicommanderhistory-context-menu');
      if (menuEl && menuEl.contains(e.target)) return;
      closeContextMenu();
    };

    document.addEventListener('click', handleOutsideInteraction, true);
    document.addEventListener('contextmenu', handleOutsideInteraction, true);

    return () => {
      document.removeEventListener('click', handleOutsideInteraction, true);
      document.removeEventListener('contextmenu', handleOutsideInteraction, true);
    };
  }, [contextMenu.visible]);

  // 右鍵點擊處理
  const handleItemRightClick = (e, itemId) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      itemId
    });
  };

  // 開啟編輯名稱 Dialog
  const handleEditName = () => {
    const item = historyItems.find(i => i.id === contextMenu.itemId);
    if (item) {
      setRenameDialog({
        isOpen: true,
        itemId: contextMenu.itemId,
        title: item.title
      });
      closeContextMenu();
    }
  };

  // 關閉編輯名稱 Dialog
  const closeRenameDialog = () => {
    setRenameDialog({
      isOpen: false,
      itemId: null,
      title: ''
    });
  };

  // 保存編輯的名稱
  const handleSaveTitle = async () => {
    if (!renameDialog.itemId || !renameDialog.title.trim()) {
      closeRenameDialog();
      return;
    }

    const session = sessions.find(t => t.session_id === renameDialog.itemId);
    if (session) {
      const newTitle = renameDialog.title.trim();

      // 更新本地資料庫
      await updateSession({
        ...session,
        title: newTitle,
        updated_at: Date.now().toString()
      });

      // 同步到後端
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const memberID = userData.ID;
      if (memberID) {
        await updateSessionTitle(memberID, renameDialog.itemId, newTitle, 'chat');
      }
    }

    closeRenameDialog();
  };

  // 處理 Dialog 輸入框的鍵盤事件
  const handleRenameKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSaveTitle();
    }
  };

  // 開啟刪除確認 Dialog
  const handleDeleteSession = () => {
    const item = historyItems.find(i => i.id === contextMenu.itemId);
    if (item) {
      setDeleteDialog({
        isOpen: true,
        itemId: contextMenu.itemId,
        title: item.title
      });
      closeContextMenu();
    }
  };

  // 確認刪除
  const handleConfirmDelete = async () => {
    if (deleteDialog.itemId) {
      await deleteSession(deleteDialog.itemId);
    }
    setDeleteDialog({ isOpen: false, itemId: null, title: '' });
  };

  // 當 sessions 或 searchQuery 變化時更新 historyItems
  useEffect(() => {
    let filteredSessions = sessions
      .filter(s => s.title); // 只顯示有標題的聊天記錄

    // 如果有搜尋關鍵字，進行過濾
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filteredSessions = filteredSessions.filter(s => {
        // 搜尋標題
        if (s.title && s.title.toLowerCase().includes(query)) {
          return true;
        }

        // 搜尋 messages 內容
        if ((s as any).messages && Array.isArray((s as any).messages)) {
          return (s as any).messages.some(message => {
            if (message.content) {
              // 如果是字串，直接搜尋
              if (typeof message.content === 'string') {
                return message.content.toLowerCase().includes(query);
              }
              // 如果是陣列，搜尋每個項目的 text
              if (Array.isArray(message.content)) {
                return message.content.some(item => {
                  if (item.type === 'text' && item.text) {
                    return item.text.toLowerCase().includes(query);
                  }
                  return false;
                });
              }
            }
            return false;
          });
        }

        return false;
      });
    }

    const items = filteredSessions
      .sort((a, b) => new Date((b as any).updatedAt ?? (b as any).updated_at ?? 0).getTime() - new Date((a as any).updatedAt ?? (a as any).updated_at ?? 0).getTime())
      .map(s => ({
        id: s.session_id ?? '',
        title: s.title ?? '',
        time: formatTimestamp((s as any).updatedAt ?? (s as any).updated_at)
      }));
    setHistoryItems(items);
  }, [sessions, searchQuery]);

  return (
    <div className="ai-commander-history">
      <div className="aicommanderhistory-history-topbar"></div>
      <div
        className="aicommanderhistory-history-item-add"
        onClick={() => {
          useChatBotSessionsStore.getState().setCurrentSessionID(null);
          // 不需要呼叫 setMessages，因為切換到 null thread
          onCancel();
        }}
      />
      <div className="aicommanderhistory-actions-container">
        <div className={`aicommanderhistory-search-wrapper ${isSearchExpanded ? 'expanded' : ''}`}>
          <button
            className={`aicommanderhistory-search-button ${isSearchExpanded ? 'active' : ''}`}
            onClick={() => {
              if (!isSearchExpanded) {
                // 展開搜尋框
                setIsSearchExpanded(true);
                setTimeout(() => {
                  document.querySelector<HTMLElement>('.aicommanderhistory-search-input')?.focus();
                }, 100);
              } else {
                // 關閉搜尋框並清空文字
                setIsSearchExpanded(false);
                setSearchQuery('');
              }
            }}
          >
            <SearchIcon />
          </button>
          <input
            type="text"
            className="aicommanderhistory-search-input"
            placeholder={t('search')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      <div className="aicommanderhistory-history-header">
        <h2> </h2>
      </div>

      <div className="aicommanderhistory-history-list">
        {/* 右鍵選單 */}
        {contextMenu.visible && (
          <div
            className="aicommanderhistory-context-menu"
            style={{
              left: `${contextMenu.x}px`,
              top: `${contextMenu.y}px`
            }}
          >
            <div
              className="aicommanderhistory-context-menu-item"
              onClick={handleEditName}
            >
              {t('editName')}
            </div>
            <div
              className="aicommanderhistory-context-menu-item aicommanderhistory-context-menu-item-danger"
              onClick={handleDeleteSession}
            >
              {t('deleteSession')}
            </div>
          </div>
        )}
        {historyItems.map(item => (
          <div
            key={item.id}
            className="aicommanderhistory-history-item"
            onClick={() => {
              setCurrentSessionID(item.id);
              onCancel(); // 關閉歷史頁面，返回聊天室
            }}
            onContextMenu={(e) => handleItemRightClick(e, item.id)}
          >
            <div className="aicommanderhistory-history-item-title">{item.title}</div>
            <div className="aicommanderhistory-history-item-footer">
              <div className="aicommanderhistory-history-item-type-container">
                {sessionStates[item.id]?.isResponding ? <HistoryLoader /> : <ChatIcon />}
                <span>{t('chat')}</span>
              </div>
              <div className="aicommanderhistory-history-item-time">{item.time}</div>
            </div>
          </div>
        ))}
        {historyItems.length === 0 && (
          <div className="aicommanderhistory-empty-state">
            <div className="aicommanderhistory-empty-text">{t('noHistory')}</div>
          </div>
        )}
      </div>

      {/* 編輯名稱 Dialog */}
      <CustomDialog
        isOpen={renameDialog.isOpen}
        onClose={closeRenameDialog}
        title={t('editName')}
      >
        <input
          type="text"
          className="custom-dialog-input"
          value={renameDialog.title}
          onChange={(e) => setRenameDialog(prev => ({ ...prev, title: e.target.value }))}
          onKeyDown={handleRenameKeyDown}
        />
        <div className="custom-dialog-buttons">
          <button className="custom-secondary-button" onClick={closeRenameDialog}>
            {t('cancel')}
          </button>
          <button className="custom-primary-button" onClick={handleSaveTitle}>
            {t('confirm')}
          </button>
        </div>
      </CustomDialog>

      {/* 刪除確認 Dialog */}
      <CustomDialog
        isOpen={deleteDialog.isOpen}
        onClose={() => setDeleteDialog({ isOpen: false, itemId: null, title: '' })}
        title={t('deleteSession')}
      >
        <p className="custom-dialog-message">{t('deleteSessionConfirm')}</p>
        <div className="custom-dialog-buttons">
          <button className="custom-secondary-button" onClick={() => setDeleteDialog({ isOpen: false, itemId: null, title: '' })}>
            {t('cancel')}
          </button>
          <button className="custom-danger-button" onClick={handleConfirmDelete}>
            {t('delete')}
          </button>
        </div>
      </CustomDialog>
    </div>
  );
};

export default AICommanderHistory; 