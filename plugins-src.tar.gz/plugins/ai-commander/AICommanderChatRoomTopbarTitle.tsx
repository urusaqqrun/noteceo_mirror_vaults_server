import React, { useState, useEffect, useRef } from 'react';
import { useChatBotSessionsStore } from './chatStore';
import { updateSessionTitle } from '../../../aiService/AIChatBotService';

const AICommanderChatRoomTopbarTitle = ({ title }) => {
  const [displayedTitle, setDisplayedTitle] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState('');
  const inputRef = useRef(null);

  // 🔧 直接訂閱當前 thread 的 isResponding 狀態（響應式）
  const currentSessionID = useChatBotSessionsStore(state => state.currentSessionID);
  const sessions = useChatBotSessionsStore(state => state.sessions);
  const updateSession = useChatBotSessionsStore(state => state.updateSession);
  const isResponding = useChatBotSessionsStore(state => {
    const sessionState = state.sessionStates[currentSessionID];
    return sessionState?.isResponding || false;
  });

  useEffect(() => {
    // 當 title 從空變為有內容時，且 isResponding 為 false 時，開始打字動畫
    if (title && displayedTitle !== title && !isResponding) {
      setIsTyping(true);
      setDisplayedTitle('');

      let currentIndex = 0;
      const typingInterval = setInterval(() => {
        if (currentIndex <= title.length) {
          setDisplayedTitle(title.slice(0, currentIndex));
          currentIndex++;
        } else {
          clearInterval(typingInterval);
          setIsTyping(false);
        }
      }, 50); // 每50ms顯示一個字符

      return () => {
        clearInterval(typingInterval);
        setIsTyping(false);
      };
    } else if (!title) {
      // 如果標題變為空，直接清空
      setDisplayedTitle('');
    }
    // 如果 title 和 displayedTitle 相同，不做任何處理
  }, [title, isResponding]);

  // 開始編輯
  const handleStartEdit = () => {
    if (!currentSessionID || !title) return;
    setIsEditing(true);
    setEditValue(title);
    setTimeout(() => {
      inputRef.current?.focus();
      inputRef.current?.select();
    }, 50);
  };

  // 保存編輯
  const handleSaveEdit = async () => {
    if (!editValue.trim() || editValue.trim() === title) {
      setIsEditing(false);
      return;
    }

    const session = sessions.find(t => t.session_id === currentSessionID);
    if (session) {
      const newTitle = editValue.trim();

      // 更新本地資料庫
      await updateSession({
        ...session,
        title: newTitle,
        updated_at: Date.now().toString()
      });

      // 同步到後端
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const memberID = userData.ID;
      if (memberID) {
        await updateSessionTitle(memberID, currentSessionID, newTitle, 'chat');
      }

      // 立即更新顯示
      setDisplayedTitle(newTitle);
    }

    setIsEditing(false);
  };

  // 處理鍵盤事件
  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      setIsEditing(false);
    }
  };

  // 編輯模式
  if (isEditing) {
    return (
      <input
        ref={inputRef}
        type="text"
        className="ai-commander-chat-room-topbar-title-input"
        value={editValue}
        onChange={(e) => setEditValue(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={handleSaveEdit}
      />
    );
  }

  return (
    <div
      className="ai-commander-chat-room-topbar-title"
      onClick={handleStartEdit}
      style={{ cursor: title ? 'pointer' : 'default' }}
    >
      {displayedTitle}
      {isTyping && <span className="typing-cursor">|</span>}
    </div>
  );
};

export default AICommanderChatRoomTopbarTitle; 