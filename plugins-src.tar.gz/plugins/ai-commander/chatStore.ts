import { create } from 'zustand';
import i18n from 'i18next';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { isLoggedIn } from '../../../aiService/apiClient';
import { resolveSubAgentIntent } from './toolIntentLabel';
import { DEFAULT_MODEL } from '../../../aiService/modelConfig';


// ===== Types =====
interface ChatSession {
  id: string;
  memberID: string;
  sessionID: string;
  session_id?: string;
  title?: string | null;
  lastMessage?: string | null;
  mode?: string;
  agentId?: string | null;
  participants?: string | null;
  model?: string | null;
  version?: number;
  has_previous?: boolean;
  createdAt?: string | number;
  updatedAt?: string | number;
}

interface ChatMessage {
  id?: string;
  memberID?: string;
  sessionID?: string;
  role: string;
  content: string | any[];
  version?: number;
  createdAt?: string | number;
  updatedAt?: string | number;
  toolCalls?: any[] | null;
  tool_calls?: any[] | null;
  toolCallId?: string | null;
  isThinking?: boolean;
  thinkingContent?: string;
  checkpoint_id?: string | null;
  attachedItems?: any[] | null;
  [key: string]: any;
}

interface SubAgentState {
  active: boolean;
  title: string;
  currentIntent: string;
  status: 'idle' | 'running' | 'done' | 'error' | 'cancelled';
  sessionId: string;
}

interface SessionState {
  messages: ChatMessage[];
  isResponding: boolean;
  isStreamingTokens: boolean;
  isCliPreparing: boolean;
  isSyncing: boolean;
  hasPreviousMessage: boolean;
  isNew?: boolean;
  pendingUserMessage?: ChatMessage | null;
  subAgent: SubAgentState;
}

interface ExecutingReport {
  sessionID: string;
  agentId: string;
  [key: string]: any;
}

interface StreamInterruptedEvent {
  sessionID: string;
  originalMessage: string;
  timestamp: number;
}

interface SocketEntry {
  socket: any;
  isConnected?: boolean;
  sessionID: string;
  mode: string;
  createdAt?: number;
}

// DB 層擴充字段的 ChatSession（包含 messages / updated_at 等欄位）
interface LocalChatSession extends ChatSession {
  messages?: any[] | null;
  updated_at?: string | null;
}

// Socket 含動態處理屬性的擴展型別
interface PatchedSocket {
  onMessage?: (data: any) => void;
  onTitleUpdate?: (data: any) => void;
}

interface ChatBotSessionsState {
  sessions: ChatSession[];
  isSyncing: boolean;
  currentSessionID: string | null;
  activeSegment: number;
  userLastInput: string;
  isInterrupted: boolean;
  sessionStates: Record<string, SessionState>;
  forgeStates: Record<string, SubAgentState>;
  executingReports: Record<string, ExecutingReport>;
  setSessions: (sessions: ChatSession[]) => void;
  setActiveSegment: (segment: number) => void;
  setUserLastInput: (input: string) => void;
  setIsInterrupted: (interrupted: boolean) => void;
  _defaultSessionState: SessionState;
  getSessionState: (sessionID: string | null) => SessionState;
  setHasPreviousMessage: (sessionID: string | null, hasPrevious: boolean) => void;
  setMessages: (sessionID: string | null, updater: ChatMessage[] | ((prev: ChatMessage[]) => ChatMessage[])) => void;
  setIsResponding: (sessionID: string | null, responding: boolean) => void;
  setIsStreamingTokens: (sessionID: string | null, streaming: boolean) => void;
  setIsCliPreparing: (sessionID: string | null, preparing: boolean) => void;
  setPendingUserMessage: (sessionID: string | null, msg: ChatMessage | null) => void;
  setIsSyncing: (sessionID: string | null, syncing: boolean) => void;
  setCurrentSessionID: (sessionID: string | null) => void;
  loadSessions: () => Promise<void>;
  addSession: (session: any) => Promise<void>;
  updateSession: (session: any) => Promise<void>;
  deleteSession: (sessionId: string) => Promise<void>;
  loadOlderMessages: (sessionID: string, mode?: string) => Promise<void>;
  syncCurrentSession: () => Promise<void>;
  syncSessions: () => Promise<void>;
  setExecutingReport: (agentId: string, executingReport: ExecutingReport) => void;
  getExecutingReport: (agentId: string) => ExecutingReport | undefined;
  clearExecutingReport: (agentId: string) => void;
  clearExecutingReportBySessionId: (sessionId: string) => void;
  loadTaskReportMessages: (sessionID: string) => Promise<void>;
  clearSession: (sessionID: string) => void;
  setSessionNew: (sessionID: string, isNew: boolean) => void;
}

interface SocketManagerState {
  sockets: Record<string, SocketEntry>;
  streamInterruptedEvent: StreamInterruptedEvent | null;
  clearStreamInterruptedEvent: () => void;
  getOrCreateSocket: (sessionID: string, memberID: string, config?: any) => Promise<any>;
  getSocket: (sessionID: string) => any;
  disconnectSocket: (sessionID: string) => void;
  getActiveSocketCount: () => number;
  evictOldestSocket: () => void;
}

// 同步鎖：用於防止 syncCurrentSession 併發執行
let syncCurrentSessionPromise: Promise<void> | null = null;

// 延遲取 useSocketManagerStore（定義在本檔底部，呼叫時一定已初始化）
const getSocketManagerStore = () => useSocketManagerStore.getState();

// 聊天機器人線程 store
export const useChatBotSessionsStore = create<ChatBotSessionsState>((set, get) => ({
  sessions: [],
  isSyncing: false,
  currentSessionID: null,
  activeSegment: 0, // 0: 儲存, 1: 對話
  userLastInput: '',
  isInterrupted: false,
  sessionStates: {},
  executingReports: {},
  forgeStates: {},

  setSessions: (sessions) => set({ sessions }),
  setActiveSegment: (segment) => set({ activeSegment: segment }),
  setUserLastInput: (input) => set({ userLastInput: input }),
  setIsInterrupted: (interrupted) => set({ isInterrupted: interrupted }),

  // 預設 session 狀態
  _defaultSessionState: { messages: [], isResponding: false, isStreamingTokens: false, isCliPreparing: false, isSyncing: false, hasPreviousMessage: false, subAgent: { active: false, title: '', currentIntent: '', status: 'idle' } },

  // 取得指定 session 的狀態
  getSessionState: (sessionID) => {
    const defaultState = get()._defaultSessionState;
    if (!sessionID) return defaultState;
    return get().sessionStates[sessionID] || defaultState;
  },

  setSessionNew: (sessionID, isNew) => {
    if (!sessionID) return;
    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, isNew }
        }
      };
    });
  },

  // 設置指定 session 的 hasPreviousMessage
  setHasPreviousMessage: (sessionID, hasPrevious) => {
    if (!sessionID) return;

    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, hasPreviousMessage: hasPrevious }
        }
      };
    });
  },

  // 設置指定 session 的 messages
  setMessages: (sessionID, updater) => {
    if (!sessionID) return;

    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      const newMessages = typeof updater === 'function' ? updater(currentState.messages) : updater;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, messages: newMessages }
        }
      };
    });
  },

  // 設置指定 session 的 isResponding（僅用於 AI 回應狀態）
  setIsResponding: (sessionID, responding) => {
    if (!sessionID) return;

    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, isResponding: responding }
        }
      };
    });
  },

  // 設置指定 session 的 isStreamingTokens（用於追蹤是否正在接收 token）
  setIsStreamingTokens: (sessionID, streaming) => {
    if (!sessionID) return;

    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, isStreamingTokens: streaming }
        }
      };
    });
  },

  // 設置指定 session 的 isCliPreparing（用於 CLI 啟動中狀態）
  setIsCliPreparing: (sessionID, preparing) => {
    if (!sessionID) return;

    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, isCliPreparing: preparing }
        }
      };
    });
  },

  setPendingUserMessage: (sessionID, msg) => {
    if (!sessionID) return;
    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, pendingUserMessage: msg }
        }
      };
    });
  },

  setIsSyncing: (sessionID, syncing) => {
    if (!sessionID) return;

    set(state => {
      const currentState = state.sessionStates[sessionID] || get()._defaultSessionState;
      return {
        sessionStates: {
          ...state.sessionStates,
          [sessionID]: { ...currentState, isSyncing: syncing }
        }
      };
    });
  },
  setCurrentSessionID: (sessionID) => {
    set({ currentSessionID: sessionID });
    if (sessionID) {
      localStorage.setItem('currentSessionID', sessionID);
    } else {
      localStorage.removeItem('currentSessionID');
    }
  },

  // 載入本地線程
  loadSessions: async () => {
    try {
      const sessions = await window.electronAPI.getAllChatbotSessions();

      if (Array.isArray(sessions)) {
        set({ sessions: sessions as ChatSession[] });
      }
    } catch (error) {
      console.error('載入聊天機器人線程失敗:', error);
    }
  },

  // 添加線程 - 同時更新 state 和 db
  addSession: async (session) => {
    try {

      await window.electronAPI.addChatbotSession(session);
      await get().loadSessions();

      // ⚠️ 同步更新 sessionStates，讓訂閱者能收到變化
      if (session.session_id && session.messages) {
        get().setMessages(session.session_id, session.messages);
      }
    } catch (error) {
      console.error('添加聊天機器人線程失敗:', error);
      throw error;
    }
  },

  // 更新線程 - 只負責 DB 持久化 + 刷新 sessions 列表
  // ⚠️ 不再在此處 setMessages，避免多個 updateSession 競態導致 sessionStates 被舊快照覆蓋
  // 呼叫方需自行在 updateSession 之前同步呼叫 setMessages 更新 sessionStates
  updateSession: async (session) => {

    try {
      await window.electronAPI.updateChatbotSession(session);
      await get().loadSessions();
    } catch (error) {
      console.error('更新聊天機器人線程失敗:', error);
      throw error;
    }
  },

  // 刪除線程 - 清除所有層：Zustand state / Socket / 本地 SQLite / 後端 PostgreSQL
  deleteSession: async (sessionId) => {
    try {
      // 1. 如果刪除的是當前線程，切走
      if (get().currentSessionID === sessionId) {
        get().setCurrentSessionID(null);
      }

      // 2. 斷開 WebSocket
      try {
        getSocketManagerStore().disconnectSocket(sessionId);
      } catch (_) { /* socketManager 尚未初始化時忽略 */ }

      // 3. 清除 Zustand sessionStates / executingReports / forgeStates
      set(state => {
        const newSessionStates = { ...state.sessionStates };
        delete newSessionStates[sessionId];
        const newExecutingReports = { ...state.executingReports };
        delete newExecutingReports[sessionId];
        const newForgeStates = Object.fromEntries(
          Object.entries(state.forgeStates).filter(([_, v]) => v.sessionId !== sessionId)
        );
        return {
          sessionStates: newSessionStates,
          executingReports: newExecutingReports,
          forgeStates: newForgeStates
        };
      });

      // 4. 刪除本地 SQLite
      await window.electronAPI.deleteChatbotSession(sessionId);

      // 5. 刪除後端 PostgreSQL（session_mapping + chat_messages）
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const memberID = userData.ID;
      if (memberID) {
        const { deleteSessionFromServer } = await import('../../../aiService/AIChatBotService');
        const result = await deleteSessionFromServer(memberID, sessionId);
        if (!result.success) {
          console.error('後端刪除 session 失敗:', result.error);
        }
      }

      // 6. 重新載入 sessions 列表
      await get().loadSessions();
    } catch (error) {
      console.error('刪除聊天機器人線程失敗:', error);
      throw error;
    }
  },

  // 載入較舊的訊息
  loadOlderMessages: async (sessionID, mode = 'chat') => {
    if (!sessionID) {

      return;
    }

    if (!isLoggedIn()) return;

    // 如果正在同步/載入中，跳過載入
    const currentState = get().getSessionState(sessionID);
    if (currentState.isSyncing) {

      return;
    }

    try {
      // 設置載入狀態（使用 isSyncing，不影響終止按鈕）
      get().setIsSyncing(sessionID, true);

      // 1. 獲取當前 messages
      let currentMessages = currentState.messages || [];

      // 2. 找出第一個有 checkpoint_id 的消息
      let firstCheckpointId = null;
      for (let i = 0; i < currentMessages.length; i++) {
        if (currentMessages[i].checkpoint_id) {
          firstCheckpointId = currentMessages[i].checkpoint_id;
          break;
        }
      }

      if (!firstCheckpointId) {

        return;
      }

      // 3. 動態導入 AIChatBotService
      const { getMessagesBeforeCheckpoint } = await import('../../../aiService/AIChatBotService');

      // 4. 獲取檢查點前的消息
      const result = await getMessagesBeforeCheckpoint(sessionID, firstCheckpointId, mode);

      if (result.success) {
        const olderMessages = result.messages || [];
        const hasPrevious = result.hasPrevious || false;

        if (olderMessages.length === 0) {

          return;
        }

        // 5. 將較舊的消息插入到當前消息的開頭（避免重複）
        let mergedMessages = [...currentMessages];

        // 檢查重複
        if (currentMessages.length > 0 && olderMessages.length > 0) {
          const firstLocal = currentMessages[0];
          const lastOlder = olderMessages[olderMessages.length - 1];

          const isDuplicate = firstLocal && lastOlder &&
            firstLocal.role === lastOlder.role &&
            firstLocal.content === lastOlder.content;

          if (isDuplicate) {

            mergedMessages = [...olderMessages.slice(0, -1), ...currentMessages];
          } else {
            mergedMessages = [...olderMessages, ...currentMessages];
          }
        } else {
          mergedMessages = [...olderMessages, ...currentMessages];
        }

        get().setMessages(sessionID, mergedMessages);

        // 更新本地線程的 has_previous 狀態（僅 chat 模式）
        if (mode === 'chat') {
          const localSession = await window.electronAPI.getChatbotSessionById(sessionID);
          if (localSession) {
            const updatedSession: LocalChatSession = {
              ...(localSession as LocalChatSession),
              messages: mergedMessages,
              has_previous: hasPrevious
            };
            await get().updateSession(updatedSession);
            await get().loadSessions();
          }
        }

        get().setHasPreviousMessage(sessionID, hasPrevious);

      } else {

      }

    } catch (error) {
      console.error('載入較舊訊息失敗:', error);
    } finally {
      // 無論成功或失敗都要重置同步狀態
      get().setIsSyncing(sessionID, false);
    }
  },

  // 同步當前線程的消息
  syncCurrentSession: async () => {
    const currentSessionID = get().currentSessionID;
    if (!currentSessionID) {

      return;
    }

    if (!isLoggedIn()) return;

    // 🔒 同步鎖：如果已有進行中的同步，等待其完成而不是重複執行
    if (syncCurrentSessionPromise) {

      return syncCurrentSessionPromise;
    }

    // 如果正在同步中，跳過同步
    const currentState = get().getSessionState(currentSessionID);
    if (currentState.isSyncing) {

      return;
    }

    // 創建同步 Promise 並設置鎖
    syncCurrentSessionPromise = (async () => {
      try {
        // 設置同步狀態（使用 isSyncing，不影響終止按鈕）
        get().setIsSyncing(currentSessionID, true);

        // 1. 優先使用 sessionState 中的 messages，如果為空才去抓 db 的
        let localMessages = currentState.messages || [];
        let localSession = null;
        localSession = await window.electronAPI.getChatbotSessionById(currentSessionID);
        if (localMessages.length === 0) {
          localMessages = localSession?.messages || [];
        }
        console.log(`[SYNC] 開始 ${currentSessionID.slice(-8)}，store=${currentState.messages?.length || 0}, DB=${localSession?.messages?.length || 0}, 合併本地=${localMessages.length}`);

        // 2. 找出最後一個有 checkpoint_id 的消息
        let lastCheckpointId = null;
        for (let i = localMessages.length - 1; i >= 0; i--) {
          if (localMessages[i].checkpoint_id) {
            lastCheckpointId = localMessages[i].checkpoint_id;
            break;
          }
        }
        console.log(`[SYNC] checkpointID=${lastCheckpointId ? lastCheckpointId.slice(-8) : 'None'}`);

        // 3. 動態導入 AIChatBotService
        const { getMessagesAfterCheckpoint } = await import('../../../aiService/AIChatBotService');

        // 4. 獲取檢查點後的消息
        const result = await getMessagesAfterCheckpoint(currentSessionID, lastCheckpointId, 'chat');

        if (result.success) {
          const remoteMessages = result.messages || [];
          const hasPrevious = result.hasPrevious || false;
          console.log(`[SYNC] 遠端返回 ${remoteMessages.length} 條`);

          if (remoteMessages.length === 0) {
            console.log('[SYNC] 遠端 0 條，保持本地');
            get().setMessages(currentSessionID, localMessages);
            if (localSession) {
              const updatedSession = {
                session_id: currentSessionID,
                messages: localMessages,
                updated_at: localSession.updated_at || new Date().toISOString(),
                title: localSession.title || null,
                has_previous: hasPrevious
              };
              await get().updateSession(updatedSession);
            }
            return;
          }

          // 5. 合併消息：遠端多於本地才替換，否則保留本地
          const currentStoreMessages = get().getSessionState(currentSessionID).messages || [];
          const localMsgCount = Math.max(localMessages.length, currentStoreMessages.length);
          const remoteMsgCount = remoteMessages.length;

          let mergedMessages;
          if (remoteMsgCount >= localMsgCount) {
            mergedMessages = remoteMessages;
            console.log(`[SYNC] ✅ 用遠端 (${remoteMsgCount}) 替換本地 (${localMsgCount})`);
          } else {
            mergedMessages = currentStoreMessages.length > localMessages.length ? currentStoreMessages : localMessages;
            console.log(`[SYNC] ✅ 保留本地 (${mergedMessages.length})，遠端較少 (${remoteMsgCount})`);
          }

          get().setMessages(currentSessionID, mergedMessages);
          console.log(`[SYNC] setMessages 完成，store 現在有 ${get().getSessionState(currentSessionID).messages?.length || 0} 條`);

          // 6. 更新本地線程
          const updatedSession = {
            session_id: currentSessionID,
            messages: mergedMessages,
            updated_at: localSession?.updated_at || new Date().toISOString(),
            title: localSession?.title || null,
            has_previous: hasPrevious
          };

          await get().updateSession(updatedSession);

          await get().loadSessions();

        } else {

        }

      } catch (error) {
        console.error('同步當前線程消息失敗:', error);
      } finally {
        // 無論成功或失敗都要重置同步狀態和釋放鎖
        get().setIsSyncing(currentSessionID, false);
        syncCurrentSessionPromise = null;
      }
    })();

    return syncCurrentSessionPromise;
  },

  // 同步聊天機器人線程
  syncSessions: async () => {
    // 檢查是否正在同步中
    if (get().isSyncing) {

      return;
    }

    if (!isLoggedIn()) return;

    // 設定同步狀態為進行中
    set({ isSyncing: true });

    try {
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const memberID = userData.ID;

      if (!memberID) {

        return;
      }

      // 獲取本地線程 - 直接從資料庫獲取最新資料
      const localSessions = await window.electronAPI.getAllChatbotSessions();
      const localSessionMap = new Map((localSessions as LocalChatSession[]).map(t => [t.session_id, t]));

      // 動態導入 AIChatBotService
      const { getSessionsByMemberID } = await import('../../../aiService/AIChatBotService');

      // 獲取遠端線程列表（預設使用 chat 模式）
      const result = await getSessionsByMemberID(memberID, 'chat');

      if (result.success) {
        const remoteSessions = result.sessions || [];
        const remoteSessionMap = new Map(remoteSessions.map(t => [t.session_id, t]));

        // 1. 批次收集需要新增的線程
        const sessionsToAdd = [];
        for (const session of remoteSessions) {
          if (!localSessionMap.has(session.session_id)) {
            sessionsToAdd.push({
              session_id: session.session_id,
              messages: null,
              updated_at: session.updated_at,
              title: session.session_title || null,
              has_previous: false
            });
          }
        }

        // 批次新增線程
        if (sessionsToAdd.length > 0) {

          for (const sessionData of sessionsToAdd) {
            try {
              await window.electronAPI.addChatbotSession(sessionData);
            } catch (error) {
              console.error(`新增線程 ${sessionData.session_id} 失敗:`, error);
            }
          }
        }

        // 2. 批次收集需要更新的線程
        const sessionsToUpdate = [];
        for (const remoteSession of remoteSessions) {
          const localSession = localSessionMap.get(remoteSession.session_id);
          if (localSession) {
            const remoteUpdatedAt = new Date((remoteSession as LocalChatSession).updated_at || 0).getTime();
            const localUpdatedAt = new Date((localSession as LocalChatSession).updated_at || 0).getTime();

            if (remoteUpdatedAt > localUpdatedAt) {
              sessionsToUpdate.push({
                session_id: (localSession as LocalChatSession).session_id,
                messages: (localSession as LocalChatSession).messages,
                updated_at: (remoteSession as LocalChatSession).updated_at,
                title: (localSession as LocalChatSession).title,
                has_previous: (localSession as LocalChatSession).has_previous
              });
            }
          }
        }

        // 批次更新線程
        if (sessionsToUpdate.length > 0) {

          for (const sessionData of sessionsToUpdate) {
            try {
              // 🔧 重新讀取 DB 中最新的 messages，避免用開頭快照的舊 messages 覆蓋
              // syncCurrentSession 可能已經在這之間寫入了更新的 messages
              const freshSession = await window.electronAPI.getChatbotSessionById(sessionData.session_id);
              if (freshSession) {
                sessionData.messages = (freshSession as LocalChatSession).messages ?? null;
              }
              await window.electronAPI.updateChatbotSession(sessionData);
            } catch (error) {
              console.error(`更新線程 ${sessionData.session_id} 失敗:`, error);
            }
          }
        }

        // 3. 批次收集需要刪除的線程
        const oneMinuteAgo = Date.now() - (60 * 1000);
        const sessionIdsToDelete = [];

        for (const localSession of localSessions) {
          if (!remoteSessionMap.has((localSession as LocalChatSession).session_id)) {
            const sessionUpdateTime = parseInt((localSession as LocalChatSession).updated_at || '0') || 0;

            if (sessionUpdateTime > oneMinuteAgo) {

              continue;
            }

            sessionIdsToDelete.push((localSession as LocalChatSession).session_id);
          }
        }

        // 批次刪除線程
        if (sessionIdsToDelete.length > 0) {

          const currentSessionID = get().currentSessionID;

          for (const sessionId of sessionIdsToDelete) {
            try {
              // 如果刪除的是當前線程，清空相關狀態
              if (currentSessionID === sessionId) {
                get().setCurrentSessionID(null);
              }
              await window.electronAPI.deleteChatbotSession(sessionId);
            } catch (error) {
              console.error(`刪除線程 ${sessionId} 失敗:`, error);
            }
          }
        }

        // 同步完成後只重新載入一次本地線程到 state
        await get().loadSessions();
      } else {

      }
    } catch (error) {
      console.error('同步聊天機器人線程失敗:', error);
    } finally {
      // 無論成功或失敗都要重置同步狀態
      set({ isSyncing: false });
    }
  },

  setExecutingReport: (agentId, executingReport) => {
    set(state => ({
      executingReports: {
        ...state.executingReports,
        [agentId]: executingReport
      }
    }));
  },

  getExecutingReport: (agentId) => {
    return get().executingReports[agentId] || null;
  },

  clearExecutingReport: (agentId) => {
    set(state => {
      const { [agentId]: _, ...rest } = state.executingReports;
      return { executingReports: rest };
    });
  },

  clearExecutingReportBySessionId: (sessionId) => {
    set(state => {
      const newReports = { ...state.executingReports };
      for (const [agentId, report] of Object.entries(newReports)) {
        if (report.id === sessionId) {
          delete newReports[agentId];
          break;
        }
      }
      return { executingReports: newReports };
    });
  },

  // 載入 Task Report 執行紀錄（從 server，不儲存本地）
  loadTaskReportMessages: async (sessionID) => {
    if (!sessionID) return;

    const currentState = get().getSessionState(sessionID);
    if (currentState.isResponding) return;

    try {
      get().setIsResponding(sessionID, true);
      const { getMessagesAfterCheckpoint } = await import('../../../aiService/AIChatBotService');
      const result = await getMessagesAfterCheckpoint(sessionID, null, 'task');

      if (result.success) {
        set(state => ({
          sessionStates: {
            ...state.sessionStates,
            [sessionID]: {
              messages: result.messages || [],
              isResponding: false,
              isStreamingTokens: false,
              isSyncing: false,
              hasPreviousMessage: result.hasPrevious || false
            }
          }
        }));
      } else {
        get().setIsResponding(sessionID, false);
      }
    } catch (error) {
      console.error('載入 task report 失敗:', error);
      get().setIsResponding(sessionID, false);
    }
  },

  // 清除指定 session 的狀態
  clearSession: (sessionID) => {
    set(state => {
      const newStates = { ...state.sessionStates };
      delete newStates[sessionID];
      return { sessionStates: newStates };
    });
  }
}));

// ===== Stream Animation Buffer =====
// CLI 輸出是一坨一坨的（~20字/400ms），不是逐字。
// 這個 buffer 逐字揭露 chunk，模擬打字機效果。
interface StreamAnimBuffer {
  targetText: string;
  targetThinking: string;
  revealedTextLen: number;
  revealedThinkingLen: number;
  rafId: number | null;
}

const _animBufs: Record<string, StreamAnimBuffer> = {};

function _getAnimBuf(sid: string): StreamAnimBuffer {
  if (!_animBufs[sid]) {
    _animBufs[sid] = { targetText: '', targetThinking: '', revealedTextLen: 0, revealedThinkingLen: 0, rafId: null };
  }
  return _animBufs[sid];
}

function _flushAnimBuf(sid: string) {
  const buf = _animBufs[sid];
  if (!buf) return;
  if (buf.rafId !== null) { cancelAnimationFrame(buf.rafId); buf.rafId = null; }
  if (buf.revealedTextLen < buf.targetText.length || buf.revealedThinkingLen < buf.targetThinking.length) {
    buf.revealedTextLen = buf.targetText.length;
    buf.revealedThinkingLen = buf.targetThinking.length;
    _applyAnimBuf(sid, buf);
  }
  delete _animBufs[sid];
}

function _applyAnimBuf(sid: string, buf: StreamAnimBuffer) {
  const txt = buf.targetText.slice(0, buf.revealedTextLen);
  const thk = buf.targetThinking.slice(0, buf.revealedThinkingLen);

  useChatBotSessionsStore.getState().setMessages(sid, prev => {
    const msgs = [...prev];
    const last = msgs.length - 1;

    if (msgs[last]?.role === 'assistant') {
      let c = msgs[last].content;
      if (thk || Array.isArray(c)) {
        if (!Array.isArray(c)) c = c ? [{ type: 'text', text: String(c) }] : [];
        else c = [...c];
        if (thk) {
          const i = c.findIndex((b: any) => b.type === 'thinking');
          if (i >= 0) c[i] = { ...c[i], thinking: thk };
          else c.unshift({ type: 'thinking', thinking: thk });
        }
        if (txt) {
          const i = c.findIndex((b: any) => b.type === 'text');
          if (i >= 0) c[i] = { type: 'text', text: txt };
          else c.push({ type: 'text', text: txt });
        }
        msgs[last] = { ...msgs[last], content: c };
      } else {
        msgs[last] = { ...msgs[last], content: txt };
      }
    } else {
      if (thk) {
        const blocks: any[] = [{ type: 'thinking', thinking: thk }];
        if (txt) blocks.push({ type: 'text', text: txt });
        msgs.push({ role: 'assistant', content: blocks });
      } else {
        msgs.push({ role: 'assistant', content: txt });
      }
    }
    return msgs;
  });
}

function _startAnimBuf(sid: string) {
  const buf = _animBufs[sid];
  if (!buf || buf.rafId !== null) return;
  const tick = () => {
    const b = _animBufs[sid];
    if (!b) return;
    const pt = b.targetText.length - b.revealedTextLen;
    const pk = b.targetThinking.length - b.revealedThinkingLen;
    if (pt <= 0 && pk <= 0) { b.rafId = null; return; }
    if (pt > 0) b.revealedTextLen = Math.min(b.revealedTextLen + (pt > 100 ? Math.ceil(pt / 30) : 1), b.targetText.length);
    if (pk > 0) b.revealedThinkingLen = Math.min(b.revealedThinkingLen + (pk > 100 ? Math.ceil(pk / 30) : 1), b.targetThinking.length);
    _applyAnimBuf(sid, b);
    b.rafId = requestAnimationFrame(tick);
  };
  buf.rafId = requestAnimationFrame(tick);
}

// WebSocket Socket Manager Store
// 管理多個 socket 連接，獨立於組件生命週期
export const useSocketManagerStore = create<SocketManagerState>((set, get) => ({
  // sockets: { [sessionID]: { socket, isConnected, sessionID, mode } }
  sockets: {},

  // 流式中斷事件（用於通知 UI 組件）
  streamInterruptedEvent: null, // { sessionID, originalMessage, timestamp }

  // 清除中斷事件
  clearStreamInterruptedEvent: () => set({ streamInterruptedEvent: null }),

  // 取得或創建 socket
  getOrCreateSocket: async (sessionID, memberID, config = {}) => {
    if (!sessionID) return null;

    const existingSockets = get().sockets;
    const existing = existingSockets[sessionID];

    // 直接檢查實際連接狀態
    const isConnected = existing?.socket?.isSocketConnected?.() ?? false;

    // 如果已存在且連接中，直接返回
    if (existing && isConnected && existing.socket) {

      return existing.socket;
    }

    // 如果存在但已斷開，先清理舊的
    if (existing && !isConnected) {

      try {
        existing.socket?.disconnect?.();
      } catch (e) {
        // ignore
      }
    }

    // 限制同一 user 最多 3 個活躍 socket
    const MAX_SOCKETS = 3;
    const connectedCount = Object.values(get().sockets).filter(s => s.socket?.isSocketConnected?.()).length;
    if (connectedCount >= MAX_SOCKETS) {
      const activeCount = get().getActiveSocketCount();
      if (activeCount >= MAX_SOCKETS) {
        // 全部都在執行中 → 回傳 null，讓呼叫者彈 dialog 確認
        return null;
      }
      // 有閒置的 → 靜默清掉
      get().evictOldestSocket();
    }

    // 創建新的 socket
    const { createStreamingChatSession } = await import('../../../aiService/AIChatBotService');

    const socket = createStreamingChatSession(memberID, 'CubeLVBot', {
      collection: null,
      sessionID: sessionID,
      model: config.model || DEFAULT_MODEL,
      mode: config.mode || 'task',
      streaming: config.streaming !== undefined ? config.streaming : true,
      ...config
    });

    // 連接 socket
    try {
      await socket.connect();

      // 儲存 socket（連接狀態直接用 socket.isSocketConnected() 判斷）
      set(state => ({
        sockets: {
          ...state.sockets,
          [sessionID]: {
            socket,
            sessionID,
            mode: config.mode || 'task',
            createdAt: Date.now()
          }
        }
      }));

      // 捕獲 sessionID 避免閉包問題
      const capturedSessionID = sessionID;

      // 用於追蹤 token 是否正在接收的計時器
      let streamingTokenTimer = null;

      // ⚠️ 在創建 socket 時就設置好所有事件處理器
      socket.setStreamingHandlers({
        onStart: (data) => {

          useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, true);
        },

        onToken: (data) => {
          clearTimeout(streamingTokenTimer);
          useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, true);
          streamingTokenTimer = setTimeout(() => {
            useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, false);
          }, 3000);

          let content = data.accumulated || data.token;

          if (typeof content === 'string' && content.startsWith('[') && content.includes("'role':")) {
            try {
              const parsed = JSON.parse(content.replace(/'/g, '"'));
              if (Array.isArray(parsed) && parsed[0]?.content) {
                content = parsed[0].content;
              }
            } catch (error) { /* ignore */ }
          }

          if (!content || !content.trim()) return;

          const buf = _getAnimBuf(capturedSessionID);
          buf.targetText = content;
          _startAnimBuf(capturedSessionID);
        },

        onThinking: (data) => {
          clearTimeout(streamingTokenTimer);
          useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, true);
          streamingTokenTimer = setTimeout(() => {
            useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, false);
          }, 3000);

          const thinkingContent = data.accumulated || data.token;
          const buf = _getAnimBuf(capturedSessionID);
          buf.targetThinking = thinkingContent;
          _startAnimBuf(capturedSessionID);
        },

        onEnd: (data) => {
          _flushAnimBuf(capturedSessionID);

          clearTimeout(streamingTokenTimer);
          useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, false);
          useChatBotSessionsStore.getState().setIsCliPreparing(capturedSessionID, false);

          // 重置回應狀態
          useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);

          // 更新 messages 添加 checkpoint_id
          useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => {
            const newMessages = [...prev];
            const lastIndex = newMessages.length - 1;
            if (newMessages[lastIndex]?.role === 'assistant' && data.checkpointId) {
              newMessages[lastIndex] = {
                ...newMessages[lastIndex],
                checkpoint_id: data.checkpointId
              };
            }
            return newMessages;
          });

          // 如果是 task 模式，任務完成後跳通知（在清除 report 之前取得任務標題）
          const socketInfo = get().sockets[capturedSessionID];
          if (socketInfo?.mode === 'task') {
            const currentMessages = useChatBotSessionsStore.getState().getSessionState(capturedSessionID)?.messages || [];
            const firstUserMessage = currentMessages.find(m => m.role === 'user');
            const agentAttachment = firstUserMessage?.attachedItems?.find(item => item.type === 'agent');
            const agentName = agentAttachment?.name || i18n.t('untitledTask');
            const agentId = agentAttachment?.id;

            const showAgentNotification = () => {
              if (typeof Notification === 'undefined') return;

              const notification = new Notification(agentName, {
                body: i18n.t('taskCompleted'),
                silent: false,
              });

              notification.onclick = () => {
                window.focus();
                if (agentId) {
                  useSelectedItemsStore.getState().setSelectedItems([{ itemType: 'AI_ADMIN_FOLDER', id: '__ai_admin__', name: '', parentID: null, version: 0, createdAt: 0, updatedAt: 0 }], { initialAgentId: agentId });
                } else {
                  useSelectedItemsStore.getState().setSelectedItems([{ itemType: 'AI_ADMIN_FOLDER', id: '__ai_admin__', name: '', parentID: null, version: 0, createdAt: 0, updatedAt: 0 }]);
                }
              };
            };

            if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
              showAgentNotification();
            } else if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
              Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                  showAgentNotification();
                }
              });
            }
          }

          // 清除正在執行的 task report
          useChatBotSessionsStore.getState().clearExecutingReportBySessionId(capturedSessionID);

          // 更新本地線程
          const chatStore = useChatBotSessionsStore.getState();
          const sessions = chatStore.sessions;
          const session = sessions.find(t => t.session_id === capturedSessionID);
          if (session) {
            const currentState = chatStore.getSessionState(capturedSessionID);
            const updatedSession = {
              ...session,
              messages: currentState.messages,
              updated_at: Date.now().toString(),
              has_previous: session.has_previous
            };
            chatStore.updateSession(updatedSession);
          }

          // 如果用戶還在這個 session，保持 socket 連接；否則斷開
          const currentSessionID = useChatBotSessionsStore.getState().currentSessionID;
          if (currentSessionID !== capturedSessionID) {

            get().disconnectSocket(capturedSessionID);
          } else {

          }
        },

        onError: (data) => {
          _flushAnimBuf(capturedSessionID);
          console.error(`[StreamingHandler] onError，sessionID: ${capturedSessionID}`);

          clearTimeout(streamingTokenTimer);
          useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, false);
          useChatBotSessionsStore.getState().setIsCliPreparing(capturedSessionID, false);

          // 重置回應狀態
          useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);

          // 添加錯誤訊息
          useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => [
            ...prev,
            { role: 'assistant', content: '抱歉，發生錯誤，請稍後再試。' }
          ]);
        },

        onStreamInterrupted: (data) => {
          _flushAnimBuf(capturedSessionID);

          clearTimeout(streamingTokenTimer);
          useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, false);
          useChatBotSessionsStore.getState().setIsCliPreparing(capturedSessionID, false);

          // 重置回應狀態
          useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);

          // 將該 session 所有 running 的 forgeStates 標記為 cancelled
          const allForge = useChatBotSessionsStore.getState().forgeStates;
          const updated: Record<string, SubAgentState> = {};
          let hasUpdate = false;
          for (const [id, state] of Object.entries(allForge)) {
            if (state.sessionId === capturedSessionID && state.status === 'running') {
              updated[id] = { ...state, status: 'cancelled', currentIntent: i18n.t('forgeCancelled') };
              hasUpdate = true;
            }
          }
          if (hasUpdate) {
            useChatBotSessionsStore.setState({ forgeStates: { ...allForge, ...updated } });
          }

          // 清除正在執行的 task report
          useChatBotSessionsStore.getState().clearExecutingReportBySessionId(capturedSessionID);

          // 檢查是否已經有 assistant 的流式回應
          const currentState = useChatBotSessionsStore.getState().getSessionState(capturedSessionID);
          const currentMessages = currentState.messages || [];

          // 找出最後一個 user 訊息的位置
          let lastUserIndex = -1;
          for (let i = currentMessages.length - 1; i >= 0; i--) {
            if (currentMessages[i].role === 'user') {
              lastUserIndex = i;
              break;
            }
          }

          // 只在最後一個 user 之後尋找 assistant
          const messagesAfterLastUser = lastUserIndex >= 0
            ? currentMessages.slice(lastUserIndex + 1)
            : [];
          const lastAssistantMsg = messagesAfterLastUser.find(msg => msg.role === 'assistant');

          // 檢查是否有 assistant 內容
          let hasAssistantContent = false;
          if (lastAssistantMsg && lastAssistantMsg.content) {
            if (Array.isArray(lastAssistantMsg.content)) {
              hasAssistantContent = lastAssistantMsg.content.some(
                block =>
                  (block.type === 'text' && block.text && block.text.trim().length > 0) ||
                  (block.type === 'thinking' && block.thinking && block.thinking.trim().length > 0)
              );
            } else if (typeof lastAssistantMsg.content === 'string') {
              hasAssistantContent = lastAssistantMsg.content.trim().length > 0;
            }
          }

          if (hasAssistantContent) {

            // 更新 messages 添加 checkpoint_id
            useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => {
              const newMessages = [...prev];
              const lastIndex = newMessages.length - 1;
              if (newMessages[lastIndex]?.role === 'assistant') {
                const existingContent = newMessages[lastIndex].content;
                let updatedContent;

                if (Array.isArray(existingContent)) {
                  updatedContent = existingContent.map(block => {
                    if (block.type === 'text') {
                      return {
                        ...block,
                        text: data.finalResponse || block.text
                      };
                    }
                    return block;
                  });
                } else {
                  updatedContent = data.finalResponse || existingContent;
                }

                newMessages[lastIndex] = {
                  ...newMessages[lastIndex],
                  content: updatedContent
                };

                if (data.checkpointId) {
                  newMessages[lastIndex].checkpoint_id = data.checkpointId;
                }
              }
              return newMessages;
            });
          } else {

            // 刪除最後一個 user 消息及其之後的所有消息
            useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => {
              let lastUserIdx = -1;
              for (let i = prev.length - 1; i >= 0; i--) {
                if (prev[i].role === 'user') {
                  lastUserIdx = i;
                  break;
                }
              }

              if (lastUserIdx === -1) {
                return prev;
              }

              return prev.slice(0, lastUserIdx);
            });

            // 設置中斷事件，通知 UI 組件恢復輸入
            set({
              streamInterruptedEvent: {
                sessionID: capturedSessionID,
                originalMessage: data.originalMessage,
                timestamp: Date.now()
              }
            });
          }

          // 更新本地線程
          const chatStore = useChatBotSessionsStore.getState();
          const sessions = chatStore.sessions;
          const session = sessions.find(t => t.session_id === capturedSessionID);
          if (session) {
            const updatedState = chatStore.getSessionState(capturedSessionID);
            const updatedSession = {
              ...session,
              messages: updatedState.messages,
              updated_at: Date.now().toString(),
              has_previous: session.has_previous
            };
            chatStore.updateSession(updatedSession);
          }

          // 如果用戶還在這個 session，保持 socket 連接；否則斷開
          const currentSessionID = useChatBotSessionsStore.getState().currentSessionID;
          if (currentSessionID !== capturedSessionID) {

            get().disconnectSocket(capturedSessionID);
          } else {

          }
        }
      });

      // 設置 onMessage 處理器（處理 tool_calls 和 tool 消息）
      (socket as unknown as PatchedSocket).onMessage = (data: any) => {
        const contentPreview = typeof data.content === 'string'
          ? data.content.slice(0, 50)
          : JSON.stringify(data.content)?.slice(0, 50);

        // tool 訊息代表 turn 結束，清掉動畫 buffer 的 thinking
        // 防止舊 turn 的 thinking 被殘留到下一個 assistant message
        if (data.role === 'tool') {
          const buf = _animBufs[capturedSessionID];
          if (buf) {
            buf.targetThinking = '';
            buf.revealedThinkingLen = 0;
          }
        }

        if (data.role === 'assistant' && data.tool_calls && data.tool_calls.length > 0) {
          useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => {
            const newMessages = [...prev];
            const lastIndex = newMessages.length - 1;

            if (newMessages[lastIndex]?.role === 'assistant') {
              const existing = newMessages[lastIndex].tool_calls || [];
              const existingIDs = new Set(existing.map((tc: any) => tc.id));
              const toAdd = data.tool_calls.filter((tc: any) => !existingIDs.has(tc.id));
              newMessages[lastIndex] = {
                ...newMessages[lastIndex],
                tool_calls: [...existing, ...toAdd],
              };
            } else {
              newMessages.push(data);
            }

            return newMessages;
          });
        } else if (data.role === 'tool') {
          useChatBotSessionsStore.getState().setMessages(capturedSessionID, prev => [...prev, data]);
        }
      };

      // 設置 onTitleUpdate 處理器
      (socket as unknown as PatchedSocket).onTitleUpdate = (data: any) => {

        // 更新本地線程標題
        const chatStore = useChatBotSessionsStore.getState();
        const sessions = chatStore.sessions;

        const session = sessions.find(t => t.session_id === capturedSessionID);

        if (session && data.title) {
          const updatedSession = {
            ...session,
            title: data.title,
            updated_at: Date.now().toString(),
            has_previous: session.has_previous
          };

          chatStore.updateSession(updatedSession);

        } else {

        }
      };

      // 鍛造完成時暫存插件名稱，供 onVaultChanged 顯示掛載提示
      let _lastForgedTitle = '';
      let _vaultChangedTimer: ReturnType<typeof setTimeout> | null = null;

      // 設置 onVaultChanged 處理器 — CLI 改了 Vault 檔案，觸發 sync + 動態插件載入（1.5s debounce）
      (socket as any).onVaultChanged = () => {
        if (_vaultChangedTimer) clearTimeout(_vaultChangedTimer);
        _vaultChangedTimer = setTimeout(async () => {
          _vaultChangedTimer = null;
          try {
            const syncService = (await import('../../../utils/syncService')).default;
            await syncService.syncChanges();
            const workspace = (window as any).__workspace;
            if (workspace) {
              const { loadDynamicPlugins } = await import('../../../workspace/pluginLoader');
              if (_lastForgedTitle) {
                const { useTempHintStore } = await import('../../../Store/uiStore');
                useTempHintStore.getState().setTempHint(i18n.t('forgeMounting', { name: _lastForgedTitle }));
              }
              console.log('[VaultChanged] sync done, loading dynamic plugins...');
              await loadDynamicPlugins(workspace);
              workspace.resolveEmptyViews();
              if (_lastForgedTitle) {
                const { useTempHintStore } = await import('../../../Store/uiStore');
                _lastForgedTitle = '';
                setTimeout(() => useTempHintStore.getState().clearTempHint(), 1500);
              }
            }
          } catch (e) {
            console.error('[VaultChanged] sync/plugin-load failed:', e);
          }
        }, 1500);
      };

      // WS 連線/重連時觸發 vault sync 斷線補漏
      (async () => {
        if (localStorage.getItem('vaultSyncDir')) {
          const { reconcileVaultSync } = await import('../../../utils/vaultSyncEngine');
          reconcileVaultSync().catch(() => {});
        }
      })();

      // onVaultFilesChanged 已移除 — plugins 走 Git，BaseItem 走 PG sync + mirrorItemsToLocal

      // 設置 onCliPreparing / onCliReady 處理器 — CLI 啟動中狀態
      (socket as any).onCliPreparing = () => {
        useChatBotSessionsStore.getState().setIsCliPreparing(capturedSessionID, true);
      };
      (socket as any).onCliReady = () => {
        useChatBotSessionsStore.getState().setIsCliPreparing(capturedSessionID, false);
      };

      // 設置 Sub-Agent 事件處理器 — 插件鍛造意圖流
      // 用獨立的 forgeState（不在 sessionStates 內，避免被其他 setter 覆蓋）
      (socket as any).onSubAgentStart = (data: any) => {
        const id = data?.tool_call_id;
        if (!id) return;
        console.log('[chatStore] forgeStates[%s] → running', id);
        const prev = useChatBotSessionsStore.getState().forgeStates;
        useChatBotSessionsStore.setState({ forgeStates: { ...prev, [id]: { active: true, title: data?.title || '', currentIntent: i18n.t('forgeWaiting'), status: 'running', sessionId: capturedSessionID } } });
      };
      (socket as any).onSubAgentIntent = (data: any) => {
        const id = data?.tool_call_id;
        if (!id) return;
        const label = resolveSubAgentIntent(data || {});
        if (!label) return;
        console.log('[chatStore] forgeStates[%s] intent:', id, label);
        const prev = useChatBotSessionsStore.getState().forgeStates;
        const existing = prev[id] || { active: true, title: '', currentIntent: '', status: 'running' as const, sessionId: capturedSessionID };
        useChatBotSessionsStore.setState({ forgeStates: { ...prev, [id]: { ...existing, currentIntent: label } } });
      };
      (socket as any).onSubAgentComplete = (data: any) => {
        const id = data?.tool_call_id;
        if (!id) return;
        console.log('[chatStore] forgeStates[%s] → complete:', id, data?.status);
        if (data?.status === 'success' && data?.title) {
          _lastForgedTitle = data.title;
        }
        const prev = useChatBotSessionsStore.getState().forgeStates;
        useChatBotSessionsStore.setState({ forgeStates: { ...prev, [id]: {
          active: true, title: '',
          currentIntent: data?.status === 'success'
            ? i18n.t('forgeCompleted')
            : data?.status === 'cancelled'
              ? i18n.t('forgeCancelled')
              : i18n.t('forgeFailed'),
          status: data?.status === 'success'
            ? 'done'
            : data?.status === 'cancelled'
              ? 'cancelled'
              : 'error',
          sessionId: capturedSessionID,
        } } });
      };

      // WS 斷線時重置回應狀態，避免 UI 卡在 tool_calls 執行中
      (socket as any).onDisconnect = () => {
        _flushAnimBuf(capturedSessionID);
        useChatBotSessionsStore.getState().setIsResponding(capturedSessionID, false);
        useChatBotSessionsStore.getState().setIsStreamingTokens(capturedSessionID, false);
        useChatBotSessionsStore.getState().setIsCliPreparing(capturedSessionID, false);
      };

    } catch (error) {
      console.error(`[SocketManager] Socket 連接失敗，sessionID: ${sessionID}`, error);

      // 連接失敗，移除該 socket
      set(state => {
        const { [sessionID]: _, ...rest } = state.sockets;
        return { sockets: rest };
      });

      return null;
    }

    return socket;
  },

  // 取得現有 socket（不創建）
  getSocket: (sessionID) => {
    const socketInfo = get().sockets[sessionID];
    return socketInfo?.socket || null;
  },

  // 斷開指定 socket
  disconnectSocket: (sessionID) => {
    _flushAnimBuf(sessionID);
    const socketInfo = get().sockets[sessionID];
    if (socketInfo && socketInfo.socket) {

      try {
        socketInfo.socket.disconnect();
      } catch (error) {
        console.error('[SocketManager] 斷開 socket 時發生錯誤:', error);
      }

      // 從 store 移除
      set(state => {
        const { [sessionID]: _, ...rest } = state.sockets;
        return { sockets: rest };
      });
    }
    // 確保回應狀態被重置
    useChatBotSessionsStore.getState().setIsResponding(sessionID, false);
    useChatBotSessionsStore.getState().setIsStreamingTokens(sessionID, false);
  },

  // 取得正在執行中（isResponding）的 socket 數量
  getActiveSocketCount: () => {
    const sockets = get().sockets;
    let count = 0;
    for (const [sid, info] of Object.entries(sockets)) {
      if (info.socket?.isSocketConnected?.()) {
        const sessionState = useChatBotSessionsStore.getState().getSessionState(sid);
        if (sessionState?.isResponding) {
          count++;
        }
      }
    }
    return count;
  },

  // 斷開最舊的非執行中 socket；如果都在執行中，斷開最舊的
  evictOldestSocket: () => {
    const sockets = get().sockets;
    const entries = Object.entries(sockets)
      .filter(([, info]) => info.socket?.isSocketConnected?.())
      .sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));

    // 優先斷開非執行中的
    for (const [sid, info] of entries) {
      const sessionState = useChatBotSessionsStore.getState().getSessionState(sid);
      if (!sessionState?.isResponding) {
        try { info.socket?.disconnect?.(); } catch {}
        set(state => {
          const { [sid]: _, ...rest } = state.sockets;
          return { sockets: rest };
        });
        return;
      }
    }
    // 都在執行中，斷開最舊的
    if (entries.length > 0) {
      const [sid, info] = entries[0];
      try { info.socket?.disconnect?.(); } catch {}
      set(state => {
        const { [sid]: _, ...rest } = state.sockets;
        return { sockets: rest };
      });
    }
  }
}));


// 窗口焦點回來時同步（原本在 App.tsx handleWindowFocus 中）
if (typeof window !== 'undefined') {
  window.addEventListener('focus', async () => {
    if (!isLoggedIn()) return;
    // 必須先等 syncSessions 完成，再同步當前線程消息
    // 否則 syncSessions 的 updateSession 會用舊的 messages 覆蓋 syncCurrentSession 剛合併的新消息
    await useChatBotSessionsStore.getState().syncSessions();
    await useChatBotSessionsStore.getState().syncCurrentSession();
  });
}
