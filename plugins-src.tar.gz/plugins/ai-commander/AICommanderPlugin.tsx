// ===== AICommanderPlugin — AICommander 插件 =====

import React from 'react';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import aiCommanderEn from './locales/en.json';
import aiCommanderZhHant from './locales/zh-Hant.json';
import aiCommanderJa from './locales/ja.json';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useAICommanderStore, AI_COMMANDER_DEFAULT_SIZE } from './aiStore';
import AICommanderFab from './AICommanderFab';
import AICommander from './AICommander';
import SessionLimitDialog from './SessionLimitDialog';
import type { ViewStateResult } from '../../../workspace/types';

class AICommanderView extends ReactView {
    private lastOpenWidth = AI_COMMANDER_DEFAULT_SIZE;

    getViewType() { return 'ai-commander'; }
    getDisplayText() { return 'AI 助理'; }
    renderComponent() { return <AICommander />; }

    getState() {
        return { lastOpenWidth: this.lastOpenWidth };
    }

    async setState(state: unknown, result: ViewStateResult): Promise<void> {
        if (state && typeof state === 'object') {
            const candidate = (state as { lastOpenWidth?: unknown }).lastOpenWidth;
            if (typeof candidate === 'number' && candidate > 0) {
                this.lastOpenWidth = candidate;
            }
        }
        await super.setState(state, result);
    }

    setLastOpenWidth(width: number): void {
        if (width > 0) {
            this.lastOpenWidth = Math.round(width);
        }
    }

    getLastOpenWidth(): number {
        return this.lastOpenWidth;
    }
}

export class AICommanderPlugin extends Plugin {
    onload() {
        this.registerView('ai-commander', (leaf) => new AICommanderView(leaf));

        // 註冊 FAB 浮動按鈕 overlay
        this.registerOverlay('aiCommanderFab', AICommanderFab);

        // 註冊 session limit dialog overlay
        this.registerOverlay('sessionLimitDialog', SessionLimitDialog);

        // 初始掛載：預設關閉；若已保存 layout，ensureLeafInPane 會保留原本的 size。
        this.ensureLeafInPane('rightPane', 'leaf-ai', 'ai-commander', {
            size: 0,
            minSize: 0,
        });

        const syncOpenState = () => {
            const leaf = this.workspace.getLeafById('leaf-ai') as any;
            if (leaf?.sizeValue > 0) {
                leaf.view?.setLastOpenWidth?.(leaf.sizeValue);
            }
            useAICommanderStore.getState().syncIsAICommanderOpen();
        };
        syncOpenState();
        this.workspace.on('layout-change', syncOpenState);
        this.register(() => this.workspace.off('layout-change', syncOpenState));

        // Cmd+P 快捷鍵 → 切換 AI Commander 開關
        this.registerDomEvent(window, 'keydown', (event: KeyboardEvent) => {
            if (event.key !== 'p' || !(event.metaKey || event.ctrlKey)) return;
            // 跳過已被 dialog / menu 攔截的場景
            const hasOpenDialog = document.querySelector('.custom-dialog-overlay');
            const hasOpenMenu = document.querySelector('.add-menu.active') ||
                document.querySelector('.more-menu.active') ||
                document.querySelector('.right-click-menu') ||
                document.querySelector('.account-menu');
            if (hasOpenDialog || hasOpenMenu) return;

            event.preventDefault();
            const { isAICommanderOpen, setIsAICommanderOpen } = useAICommanderStore.getState();
            setIsAICommanderOpen(!isAICommanderOpen);
        });
    }
}

registerPluginClass(AICommanderPlugin, 'AI 助理', {
    alwaysLoaded: true,
    descriptionKey: 'modulesAICommanderDesc',
    setupI18n: () => registerPluginLocales('AICommanderPlugin', { 'en': aiCommanderEn, 'zh-Hant': aiCommanderZhHant, 'ja': aiCommanderJa }),
});
