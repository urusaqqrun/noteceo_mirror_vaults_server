import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDialogStore } from '../../../Store/dialogStore';
import './AICommander.css';

const SessionLimitDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['sessionLimit']?.show);
    const data = useDialogStore(state => state.dialogs['sessionLimit']?.data);

    if (!showDialog) return null;

    const hideDialog = () => useDialogStore.getState().close('sessionLimit');

    const handleConfirm = () => {
        data?.onConfirm?.();
        hideDialog();
    };

    const handleClose = () => {
        data?.onCancel?.();
        hideDialog();
    };

    return (
        <div className="custom-dialog-overlay" onClick={handleClose}>
            <div className="custom-dialog" onClick={(e) => e.stopPropagation()}>
                <div className="custom-dialog-header">
                    <h3 className="custom-dialog-title">{t('sessionLimitTitle')}</h3>
                </div>
                <div className="custom-dialog-body">
                    <p className="custom-dialog-description">
                        {t('sessionLimitMessage', { count: data?.activeCount || 3 })}
                    </p>
                </div>
                <div className="custom-dialog-footer">
                    <button className="custom-dialog-cancel-btn" onClick={handleClose}>
                        {t('cancel', { defaultValue: '取消' })}
                    </button>
                    <button className="custom-dialog-confirm-btn" onClick={handleConfirm}>
                        {t('confirm', { defaultValue: '確認' })}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SessionLimitDialog;
