import React, { useEffect, useState, createContext, useContext, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import { useEditor, EditorContent } from '@tiptap/react';
import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { DOMSerializer } from 'prosemirror-model';
import StarterKit from '@tiptap/starter-kit';
import { TaskList } from '@tiptap/extension-task-list';
import { TaskItem } from '@tiptap/extension-task-item';
import { Underline } from '@tiptap/extension-underline';
import { Highlight } from '@tiptap/extension-highlight';
import { TextStyle } from '@tiptap/extension-text-style';
import { Color } from '@tiptap/extension-color';
import { ImageExtension } from '../editor/extensions/ImageExtension';
import { Link } from '@tiptap/extension-link';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableHeader } from '@tiptap/extension-table-header';
import { TableCell } from '@tiptap/extension-table-cell';
import { IndentExtension } from '../editor/extensions/IndentExtension';
import WebPreviewDecoration from '../editor/extensions/WebPreviewDecoration';
import { useEditorExtensionRegistry } from '../../../Store/editorExtensionRegistry';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSearchRegistry } from '../../../Store/searchRegistry';
import { useTempHintStore } from '../../../Store/uiStore';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import MarkdownIt from 'markdown-it';
import CopyIcon from '../../../assets/icon_copy_16.svg?react';
import CorrectIcon from '../../../assets/icon_correct.svg?react';
import SaveIcon from '../../../assets/icon_disksave_outline_16.svg?react';
import '../editor/NoteEditor.css';
import './ChatMessageAssistant.css';

// 初始化 MarkdownIt 實例
const markdownIt = new MarkdownIt({
  html: true,
  breaks: true,
  linkify: true
});

// 清理和修復 HTML 內容，確保符合 TipTap 的節點模型
function sanitizeHTML(html) {
  const customTagNames = ['note-embed', 'note-folder-selector', 'merge-note-suggester'];
  let cleanedHtml = html;

  // 最直接的方法：找到最後一個 < 符號的位置
  // 檢查從那個位置開始是否是不完整的自定義標籤
  for (const tagName of customTagNames) {
    // 找到所有可能的開始標籤位置
    const tagPattern = `<${tagName}`;
    let lastIndex = cleanedHtml.lastIndexOf(tagPattern);

    while (lastIndex !== -1) {
      // 找到這個標籤的結束位置
      const afterTag = cleanedHtml.substring(lastIndex);

      // 檢查是否有 > 結束開始標籤
      const closeAngleBracket = afterTag.indexOf('>');

      if (closeAngleBracket === -1) {
        // 沒有 >，這是不完整的標籤，直接截斷
        cleanedHtml = cleanedHtml.substring(0, lastIndex);
        break; // 已經移除，不需要繼續檢查這個標籤
      }

      // 有 >，檢查是否是自閉合標籤
      const tagContent = afterTag.substring(0, closeAngleBracket + 1);
      const isSelfClosing = tagContent.endsWith('/>');

      if (!isSelfClosing) {
        // 不是自閉合，檢查是否有結束標籤
        const closeTag = `</${tagName}>`;
        const hasCloseTag = afterTag.includes(closeTag);

        if (!hasCloseTag) {
          // 沒有結束標籤，移除這個開始標籤
          cleanedHtml = cleanedHtml.substring(0, lastIndex) +
            cleanedHtml.substring(lastIndex + closeAngleBracket + 1);
        }
      }

      // 繼續檢查前面是否還有這個標籤
      const previousPart = cleanedHtml.substring(0, lastIndex);
      lastIndex = previousPart.lastIndexOf(tagPattern);
    }
  }

  // 創建臨時 DOM 元素來解析和清理 HTML
  const temp = document.createElement('div');
  temp.innerHTML = cleanedHtml;

  // 修復空的列表項目：如果 <li> 是空的或只有空白，給它加上一個段落
  const listItems = temp.querySelectorAll('li');
  listItems.forEach(li => {
    // 檢查是否為空或只有空白字符
    if (!li.textContent.trim() && li.children.length === 0) {
      li.innerHTML = '<p></p>';
    }
    // 如果列表項目直接包含文本節點（沒有包裹在 p 標籤中），將其包裹起來
    else if (li.childNodes.length > 0) {
      const hasBlockElement = Array.from(li.children).some(child => {
        const tag = child.tagName?.toLowerCase();
        return ['p', 'div', 'ul', 'ol', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'pre'].includes(tag);
      });

      // 如果沒有塊級元素，且第一個子節點是文本節點或行內元素，需要包裹
      if (!hasBlockElement) {
        const fragment = document.createDocumentFragment();
        const p = document.createElement('p');
        while (li.firstChild) {
          p.appendChild(li.firstChild);
        }
        fragment.appendChild(p);
        li.appendChild(fragment);
      }
    }
  });

  // 移除空的段落標籤（但保留 <p><br></p> 這種）
  const paragraphs = temp.querySelectorAll('p');
  paragraphs.forEach(p => {
    if (!p.textContent.trim() && p.children.length === 0) {
      p.innerHTML = '<br>';
    }
  });

  // 移除末尾的空段落（避免 ProseMirror-trailingBreak 造成多餘空行）
  let lastChild = temp.lastElementChild;
  while (lastChild && lastChild.tagName === 'P' && !lastChild.textContent.trim() &&
    (lastChild.children.length === 0 ||
      (lastChild.children.length === 1 && lastChild.children[0].tagName === 'BR'))) {
    temp.removeChild(lastChild);
    lastChild = temp.lastElementChild;
  }

  return temp.innerHTML;
}

// 清理自定義標籤周圍的多餘空行
function removeExtraNewlinesAroundCustomTags(text) {
  const customTags = ['note-embed', 'note-folder-selector', 'merge-note-suggester'];
  let cleanedText = text;

  for (const tagName of customTags) {
    // 移除「文字：\n」後面到標籤之間的所有換行（只保留冒號和標籤，中間沒有換行）
    cleanedText = cleanedText.replace(
      new RegExp(`([：:])\\s*\\n+\\s*(<${tagName}[^>]*>)`, 'gi'),
      '$1$2'  // 文字：<tag>，中間沒有換行
    );

    // 移除標籤開頭前的所有空行
    cleanedText = cleanedText.replace(
      new RegExp(`\\n[\\s\\n]*(<${tagName}[^>]*>)`, 'gi'),
      '$1'  // 完全移除標籤前的換行
    );

    // 移除標籤結束後的所有換行
    cleanedText = cleanedText.replace(
      new RegExp(`(</${tagName}>|<${tagName}[^>]*/>)\\s*\\n+\\s*`, 'gi'),
      '$1'  // 完全移除標籤後的換行
    );
  }

  return cleanedText;
}

// 檢查文字是否為 Markdown 格式
function isMarkdown(text) {
  // 檢查常見的 Markdown 語法特徵
  const markdownPatterns = [
    /^#{1,6}\s/, // 標題
    /^[*-]\s/, // 無序列表
    /^\d+\.\s/, // 有序列表
    /^>\s/, // 引用
    /^```/, // 程式碼區塊
    /\[.*?\]\(.*?\)/, // 連結
    /\*\*.*?\*\*/, // 粗體
    /\*.*?\*/, // 斜體
    /^---/, // 分隔線
    /^===/, // 另一種標題格式
    /^\|.*\|.*\|/, // 表格
    /^- \[ \]/, // 待辦事項
  ];

  // 將文字分行檢查
  const lines = text.split('\n');

  // 檢查是否至少有一行符合 Markdown 語法
  return lines.some(line =>
    markdownPatterns.some(pattern => pattern.test(line.trim()))
  );
}

// 🔧 移除不完整的 Markdown table 行
function removeIncompleteMarkdownTableRows(markdown) {
  const lines = markdown.split('\n');
  let inTable = false;
  let expectedColumns = 0;
  const validLines = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // 只有以 | 開頭的行才視為表格行，避免誤判普通文字中的 |（如 |ψ|²）
    const hasTableMarker = line.startsWith('|');

    if (hasTableMarker) {
      if (!inTable) {
        // 開始一個新的 table
        inTable = true;
        // 從第一行計算預期的列數
        expectedColumns = (line.match(/\|/g) || []).length - 1;
      }

      // 計算當前行的列數
      const pipeCount = (line.match(/\|/g) || []).length;
      const hasEndPipe = line.endsWith('|');
      const currentColumns = hasEndPipe ? pipeCount - 1 : pipeCount;

      // 檢查行是否完整
      const isComplete = hasEndPipe && currentColumns === expectedColumns;

      // 檢查是否是分隔行（格式較寬鬆）
      const isSeparator = /^\|[\s\-:|]+\|$/.test(line);

      if (isComplete || (isSeparator && hasEndPipe)) {
        // 完整的行，保留
        validLines.push(lines[i]);
      } else {
        // 不完整的行，移除（不添加到 validLines）

      }
    } else if (inTable && line === '') {
      // 空行表示 table 結束
      validLines.push(lines[i]);
      inTable = false;
      expectedColumns = 0;
    } else if (inTable) {
      // 非空行且不是 table 格式，table 結束
      validLines.push(lines[i]);
      inTable = false;
      expectedColumns = 0;
    } else {
      // 不在 table 中，正常保留
      validLines.push(lines[i]);
    }
  }

  return validLines.join('\n');
}

// 提取並暫存自定義標籤，返回 { cleanText, tags }
function extractCustomTags(text) {
  const customTagPattern = /<(note-embed|note-folder-selector|merge-note-suggester)[^>]*>(?:<\/\1>)?/gi;
  const tags = [];
  let cleanText = text;

  // 使用 HTML 註釋作為佔位符，這樣 MarkdownIt 會保留它們
  cleanText = cleanText.replace(customTagPattern, (match) => {
    const placeholder = `<!--CUSTOMTAG${tags.length}-->`;
    tags.push(match);
    return placeholder;
  });

  return { cleanText, tags };
}

// 將自定義標籤還原回文本
function restoreCustomTags(text, tags) {
  let result = text;
  tags.forEach((tag, index) => {
    const placeholder = `<!--CUSTOMTAG${index}-->`;
    // 也要處理可能被包裹在 <p> 標籤中的情況
    const wrappedPlaceholder = `<p>${placeholder}</p>`;
    if (result.includes(wrappedPlaceholder)) {
      result = result.replace(wrappedPlaceholder, tag);
    } else {
      result = result.replace(placeholder, tag);
    }
  });
  return result;
}

// 創建 Context 來傳遞聊天室相關信息
export const ChatRoomContext = createContext({
  messages: [],
  currentMessageIndex: -1,
  interruptAndClearMessages: null,
  setMessages: null
});

const ChatMessageAssistant = ({ content = '', messages = [], currentMessageIndex = -1, interruptAndClearMessages = null, setMessages = null, mode = 'chat', onLinkClick, isResponding = false }) => {
  const { t } = useTranslation();

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const setTempHint = useTempHintStore(state => state.setTempHint);
  // 統一使用 store 的 selectedFolderId
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const [isCopied, setIsCopied] = useState(false);

  // 🔧 節流更新相關 refs - 減少 TipTap 編輯器重建頻率
  const lastUpdateTimeRef = useRef(0);
  const pendingContentRef = useRef(null);
  const throttleTimeoutRef = useRef(null);
  const THROTTLE_INTERVAL = 80; // 節流間隔 80ms

  // 🔧 處理 content 格式：如果是 array（包含 thinking block），提取 text block
  let textContent = content;
  if (Array.isArray(content)) {
    // content 是 array，提取所有 text block 的內容
    const textBlocks = content.filter(block => block.type === 'text');
    textContent = textBlocks.map(block => block.text || '').join('');
  }

  // 🔧 處理轉義的換行符：將 \n 字面字串轉換為實際換行符
  if (typeof textContent === 'string') {
    textContent = textContent.replace(/\\n/g, '\n');
  }

  // 將 textContent 賦值回 content，後續代碼保持不變
  content = textContent;

  // 將 #[id] 或 #id 格式轉換為 Markdown 連結格式，並查找對應的筆記/資料夾/任務標題
  // 同時處理前面可能重複的名稱（例如 "旅遊規劃 #[ID]" 或 "**旅遊規劃** #[ID]"）
  const convertNoteIdBrackets = useCallback((text) => {
    const allItems = useSearchRegistry.getState().search('');

    const generateLinkForId = (id: string) => {
      const item = allItems.find(i => i.id === id);
      if (!item) return null;

      const type = item.itemType;
      let displayName = (item as any).name || (item as any).title || (item as any).aiTitle;

      if (displayName === 'inbox') displayName = t('inbox');
      else if (displayName === 'trash') displayName = t('trash');
      else if (displayName === 'todoInbox') displayName = t('todoInbox');

      if (!displayName) displayName = t('untitled');

      return `[${displayName}](#${type.toLowerCase()}-${id})`;
    };

    let result = text.replace(/#([0-9a-f]{24})(?![0-9a-f\]])/gi, (_match: string, id: string) => {
      return generateLinkForId(id) || '';
    });

    return result.replace(/#\[([^\]]+)\]/gi, (_match: string, id: string) => {
      return generateLinkForId(id) || '';
    });
  }, [t]);

  // 移除 #[ID] 前後重複的名稱（例如 "**名稱** #[ID]" → "#[ID]" 或 "#[ID] 名稱" → "#[ID]"）
  const removeDuplicateNamesBeforeIds = useCallback((text) => {
    const allItems = useSearchRegistry.getState().search('');

    const getDisplayName = (id: string) => {
      const item = allItems.find(i => i.id === id);
      if (!item) return null;

      let displayName = (item as any).name || (item as any).title || (item as any).aiTitle;
      if (displayName === 'inbox') return t('inbox');
      if (displayName === 'trash') return t('trash');
      if (displayName === 'todoInbox') return t('todoInbox');
      return displayName || t('untitled');
    };

    // 找出所有 #[ID]，然後逐一檢查並替換
    const idRegex = /#\[([^\]]+)\]/g;
    let result = text;
    let matchResult;
    const replacements = [];

    while ((matchResult = idRegex.exec(text)) !== null) {
      const id = matchResult[1];
      const displayName = getDisplayName(id);
      if (!displayName) continue;

      const idStart = matchResult.index;
      const idEnd = idStart + matchResult[0].length;
      const beforeText = text.substring(0, idStart);
      const afterText = text.substring(idEnd);

      // 轉義顯示名稱用於正則
      const escapedName = displayName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

      // 檢查前面是否以 **名稱** 結尾
      const boldRegex = new RegExp(`\\*\\*${escapedName}\\*\\*\\s*$`);
      const boldMatch = beforeText.match(boldRegex);
      if (boldMatch) {
        replacements.push({
          start: idStart - boldMatch[0].length,
          end: idStart,
          replacement: ''
        });
        continue;
      }

      // 檢查前面是否以 名稱 結尾（前面是空格或 -）
      const plainBeforeRegex = new RegExp(`([\\s\\-])${escapedName}\\s*$`);
      const plainBeforeMatch = beforeText.match(plainBeforeRegex);
      if (plainBeforeMatch) {
        // 保留前面的空格或 -
        const keepChar = plainBeforeMatch[1];
        replacements.push({
          start: idStart - plainBeforeMatch[0].length + keepChar.length,
          end: idStart,
          replacement: ''
        });
        continue;
      }

      // 檢查後面是否以 名稱 開頭
      const plainAfterRegex = new RegExp(`^\\s+${escapedName}`);
      const plainAfterMatch = afterText.match(plainAfterRegex);
      if (plainAfterMatch) {
        replacements.push({
          start: idEnd,
          end: idEnd + plainAfterMatch[0].length,
          replacement: ''
        });
      }
    }

    // 從後往前替換，避免位置錯亂
    for (let i = replacements.length - 1; i >= 0; i--) {
      const { start, end, replacement } = replacements[i];
      result = result.substring(0, start) + replacement + result.substring(end);
    }

    return result;
  }, [t]);

  // 將 # 開頭的筆記ID連結轉換為標準格式
  const convertNoteLinks = (text) => {
    // 將 Markdown 格式的 [文字](#noteID) 轉換為 [文字](CubeLV://note/noteID)
    return text.replace(/\[([^\]]+)\]\(#([0-9a-f]{24})\)/gi, '[$1](CubeLV://note/$2)');
  };

  // 將 HTML 中的 # 開頭的筆記ID連結轉換為標準格式（支持多種類型）
  const convertNoteLinksInHTML = (html) => {
    if (!html) return html;

    return html.replace(/href=["']#([a-z_]+)-([0-9a-f]{24})["']/gi, (_m, type, id) => {
      return `href="cubelv://${type}/${id}"`;
    });
  };

  // 複製內容到剪貼板
  const handleCopy = () => {
    if (content) {
      // 轉換筆記連結格式
      const convertedContent = convertNoteLinks(content);
      navigator.clipboard.writeText(convertedContent).then(() => {

        setIsCopied(true);
        // 2秒後恢復圖標
        safeSetTimeout(() => {
          setIsCopied(false);
        }, 2000);
      }).catch(err => {
        console.error('❌ 複製失敗:', err);
      });
    }
  };

  // 儲存至資料夾
  const handleSaveAsNote = async () => {

    if (!content) {

      return;
    }

    try {
      // 決定目標資料夾：如果有選擇資料夾則用選擇的，否則用 inbox
      let targetFolderId = selectedFolderId;

      if (!targetFolderId) {
        const allItems = useSearchRegistry.getState().search('');
        const inboxFolder = allItems.find(f => (f as any)?.name === 'inbox' && f.itemType?.endsWith('_FOLDER'));
        if (inboxFolder) {
          targetFolderId = inboxFolder.id;
        } else {
          console.error('❌ 找不到 inbox 資料夾');
          setTempHint(t('inboxNotFound'));
          safeSetTimeout(() => setTempHint(null), 2000);
          return;
        }
      }

      // 從編輯器獲取 HTML 內容
      let htmlContent = content;
      if (editor) {
        htmlContent = editor.getHTML();
      } else if (isMarkdown(content)) {
        // 如果編輯器未初始化且內容是 Markdown，手動轉換
        // 🔧 先移除不完整的 Markdown table 行
        const cleanedMarkdown = removeIncompleteMarkdownTableRows(content);
        htmlContent = markdownIt.render(cleanedMarkdown);
        htmlContent = sanitizeHTML(htmlContent);
      }

      // 轉換筆記連結格式
      htmlContent = convertNoteLinksInHTML(htmlContent);

      const now = Date.now();
      // 創建新筆記
      const newNote = {
        id: generateObjectID(),
        content: htmlContent,
        parentID: targetFolderId,
        version: 0,
        name: '',
        status: 'NORMAL',
        createdAt: now,
        updatedAt: now,
      };

      await useItemStore.getState().upsertItem({ ...newNote, itemType: 'NOTE' }, { needSync: true });

      setTempHint(t('noteSaved'));
      safeSetTimeout(() => setTempHint(null), 2000);


      const savedNote = useItemStore.getState().getById(newNote.id);
      if (savedNote) useSelectedItemsStore.getState().setSelectedItems([savedNote], { scrollToFocusItem: true, highlightItemId: newNote.id });
    } catch (error) {
      console.error('❌ 儲存筆記失敗:', error);
      setTempHint(t('saveNoteFailed'));
      safeSetTimeout(() => setTempHint(null), 2000);
    }
  };

  const editor = useEditor({
    extensions: [
      Extension.create({
        name: 'customAttributes',
        addGlobalAttributes() {
          return [
            {
              types: ['paragraph', 'listItem', 'taskItem'],
              attributes: {
                tempId: {
                  default: null,
                  parseHTML: element => element.getAttribute('data-temp-id'),
                  renderHTML: attributes => {
                    if (!attributes.tempId) return {};
                    return {
                      'data-temp-id': attributes.tempId,
                    };
                  },
                },
              },
            },
          ];
        },
      }),
      Extension.create({
        name: 'customCopyHandler',
        addProseMirrorPlugins() {
          return [
            new Plugin({
              key: new PluginKey('customCopyHandler'),
              props: {
                handleDOMEvents: {
                  copy: (view, event) => {
                    const { state } = view;
                    const { selection } = state;

                    if (selection.empty) {
                      return false;
                    }

                    try {
                      // 獲取選中的內容
                      const { from, to } = selection;
                      const slice = state.doc.slice(from, to);

                      // 序列化為 HTML
                      const serializer = DOMSerializer.fromSchema(state.schema);
                      const fragment = serializer.serializeFragment(slice.content);
                      const tempDiv = document.createElement('div');
                      tempDiv.appendChild(fragment);
                      let html = tempDiv.innerHTML;

                      // 轉換筆記連結格式
                      html = convertNoteLinksInHTML(html);

                      // 設置到剪貼板
                      event.clipboardData.setData('text/html', html);
                      event.clipboardData.setData('text/plain', state.doc.textBetween(from, to, '\n'));

                      event.preventDefault();
                      return true;
                    } catch (error) {
                      console.error('複製處理失敗:', error);
                      return false;
                    }
                  }
                }
              }
            })
          ];
        }
      }),
      StarterKit.configure({
        paragraph: {
          draggable: false, // 禁用拖曳
        } as any,
        history: false,
        bulletList: {
          keepMarks: true,
          keepAttributes: true,
          HTMLAttributes: {
            class: 'bullet-list'
          }
        },
        orderedList: {
          keepMarks: true,
          keepAttributes: true,
          HTMLAttributes: {
            class: 'ordered-list'
          }
        },
        heading: {
          levels: [1, 2, 3]
        },
        dropcursor: false,
        gapcursor: false,
      } as any),
      TaskList.configure({
        excludes: ['bulletList', 'orderedList'],
        HTMLAttributes: {
          class: 'task-list'
        }
      } as any),
      TaskItem.configure({
        nested: true,
      }),
      Underline.configure({}),
      Highlight.configure({
        multicolor: false,
        HTMLAttributes: {
          class: 'highlight-text'
        }
      }),
      TextStyle,
      Color,
      ImageExtension.configure({
        isMaterialMode: true
      } as any),
      Link.configure({
        HTMLAttributes: {
          class: 'editor-link',
          rel: 'noopener noreferrer',
          target: '_blank',
        },
        validate: href => {
          // 允許 http/https、CubeLV 協議、以及 # 開頭的內部連結
          return /^https?:\/\//.test(href) ||
            /^[Cc]ube[Ll][Vv]:\/\//.test(href) ||
            href.startsWith('#');
        },
        protocols: ['http', 'https', 'mailto', 'tel', 'cubelv'],
        autolink: false,
        openOnClick: false, // 禁用點擊打開連結
        linkOnPaste: false, // 禁用貼上時自動轉換連結
      }),
      Table.configure({
        resizable: false, // 禁用表格調整大小
      }),
      TableRow,
      TableHeader,
      TableCell,
      IndentExtension,
      WebPreviewDecoration.configure({ getWebsiteLinks: () => [] }),
      ...useEditorExtensionRegistry.getState().getAll(),
    ],
    content: content || '',
    editable: false, // 核心：完全禁用編輯
    // 性能優化：不在每次事務時重渲染 React 組件
    shouldRerenderOnTransaction: false,
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none chat-message-assistant-editor'
      }
    }
  }, []);

  // 處理連結點擊 - 解析連結類型和 ID，交由 AICommanderChatRoom 統一處理
  const handleLinkClick = (e) => {
    const link = e.target.closest('a');
    if (link && link.classList.contains('editor-link')) {
      e.preventDefault();
      e.stopPropagation();
      const href = link.getAttribute('href');

      // 解析連結類型和 ID
      let linkType = null;
      let linkId = null;

      const cubelvMatch = href.match(/^[Cc]ube[Ll][Vv]:\/\/([^/]+)\/(.+)/);
      if (cubelvMatch) {
        linkType = cubelvMatch[1].toLowerCase();
        linkId = cubelvMatch[2].split('?')[0];
      } else if (href.startsWith('#')) {
        const hashContent = href.substring(1);
        const dashIdx = hashContent.indexOf('-');
        if (dashIdx > 0) {
          linkType = hashContent.substring(0, dashIdx);
          linkId = hashContent.substring(dashIdx + 1);
        }
      } else if (!href.startsWith('#')) {
        // 外部連結
        linkType = 'external';
        linkId = href;
      }

      // 交由 AICommanderChatRoom 統一處理
      if (linkType && linkId && onLinkClick) {
        onLinkClick({ type: linkType, id: linkId });
      } else if (linkType === 'external' && linkId) {
        // 外部連結直接處理
        try {
          new URL(linkId);
          window.electronAPI?.openExternalLink(linkId);
        } catch (error) {
          console.error('無效的 URL:', linkId, error);
        }
      }
    }
  };

  // 🔧 實際執行編輯器內容更新的函數
  const updateEditorContent = useCallback((contentToUpdate) => {
    // 確保 editor 和 view 都已掛載
    if (!editor || !editor.view || !editor.view.dom) return;

    queueMicrotask(() => {
      try {
        // 如果內容為空字符串，清空編輯器
        if (contentToUpdate === '') {
          editor.commands.clearContent();
        } else {
          // 檢查是否為 Markdown 格式並轉換
          let processedContent = contentToUpdate;

          // 先清理自定義標籤周圍的多餘空行
          processedContent = removeExtraNewlinesAroundCustomTags(processedContent);

          // 提取自定義標籤
          const { cleanText, tags } = extractCustomTags(processedContent);

          // 先移除 #[ID] 前面重複的名稱，再轉換為 Markdown 連結
          const textWithoutDuplicates = removeDuplicateNamesBeforeIds(cleanText);
          let textToProcess = convertNoteIdBrackets(textWithoutDuplicates);

          // 🔧 直接使用 Markdown 渲染，避免模式切換導致抖動
          // 先移除不完整的 Markdown table 行
          const cleanedMarkdown = removeIncompleteMarkdownTableRows(textToProcess);
          // 轉換 Markdown 為 HTML
          let convertedHtml = markdownIt.render(cleanedMarkdown);

          // 處理連續空格問題：將連續空格轉換為 &nbsp; 實體
          convertedHtml = convertedHtml.replace(/ {2,}/g, match => {
            return Array(match.length).fill('&nbsp;').join('');
          });

          // 還原自定義標籤
          processedContent = restoreCustomTags(convertedHtml, tags);

          // 無論是否為 Markdown，都要清理和修復 HTML 結構（移除不完整的自定義標籤）
          processedContent = sanitizeHTML(processedContent);

          // 使用 emitUpdate: false 避免觸發不必要的更新
          editor.commands.setContent(processedContent);
        }
      } catch (error) {
        console.error('設置編輯器內容失敗:', error);
        console.error('問題內容:', contentToUpdate);
        // 如果設置內容失敗，嘗試清空編輯器避免顯示錯誤狀態
        try {
          editor.commands.clearContent();
        } catch (clearError) {
          console.error('清空編輯器也失敗:', clearError);
        }
      }
    });
  }, [editor, convertNoteIdBrackets]);

  // 🔧 清理節流計時器
  useEffect(() => {
    return () => {
      if (throttleTimeoutRef.current) {
        clearTimeout(throttleTimeoutRef.current);
        throttleTimeoutRef.current = null;
      }
    };
  }, []);

  // 當 content 從外部改變時更新編輯器（帶節流）
  useEffect(() => {
    // 確保 editor 和 view 都已掛載
    if (editor && editor.view && editor.view.dom && content !== editor.getHTML()) {
      const now = Date.now();
      const timeSinceLastUpdate = now - lastUpdateTimeRef.current;

      if (timeSinceLastUpdate >= THROTTLE_INTERVAL) {
        // 距離上次更新超過節流間隔，立即更新
        updateEditorContent(content);
        lastUpdateTimeRef.current = now;
        pendingContentRef.current = null;
      } else {
        // 節流：保存待更新內容，延遲執行
        pendingContentRef.current = content;

        if (!throttleTimeoutRef.current) {
          const delay = THROTTLE_INTERVAL - timeSinceLastUpdate;
          throttleTimeoutRef.current = setTimeout(() => {
            if (pendingContentRef.current !== null) {
              updateEditorContent(pendingContentRef.current);
              lastUpdateTimeRef.current = Date.now();
              pendingContentRef.current = null;
            }
            throttleTimeoutRef.current = null;
          }, delay);
        }
      }
    }
  }, [content, editor, updateEditorContent]);

  // 綁定連結點擊事件
  useEffect(() => {
    // 檢查 editor 和 editor.view 是否都已掛載，避免切換 thread 時 crash
    if (editor && editor.view && editor.view.dom) {
      const editorContent = editor.view.dom;
      editorContent.addEventListener('click', handleLinkClick, true);

      return () => {
        // cleanup 時也要檢查 view 是否還存在
        if (editor.view && editor.view.dom) {
          editorContent.removeEventListener('click', handleLinkClick, true);
        }
      };
    }
  }, [editor]);

  if (!editor) {
    return null;
  }

  // 判斷下一個 message 是否也是 assistant message，或者當前消息有 tool_calls
  const currentMessage = messages[currentMessageIndex];
  const nextMessage = messages[currentMessageIndex + 1];
  const isNextMessageAssistant = nextMessage && nextMessage.role === 'assistant';
  const hasToolCalls = currentMessage && currentMessage.tool_calls && currentMessage.tool_calls.length > 0;

  // 判斷當前 content 是否包含特殊自定義標籤
  const customTags = ['note-embed', 'note-folder-selector', 'merge-note-suggester'];
  const hasCustomTags = customTags.some(tag => content.includes(`<${tag}`));

  // 判斷是否為最新回應中的 assistant message（正在回應中時不顯示 actions）
  const isInLatestResponse = (() => {
    for (let i = currentMessageIndex + 1; i < messages.length; i++) {
      if (messages[i].role === 'user') return false;
    }
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'assistant') return i === currentMessageIndex;
    }
    return false;
  })();

  // 只有在不是連續 assistant message 的最後一條、沒有 tool_calls、沒有自定義標籤、不是 task 模式、且不在回應中時才顯示 actions
  const shouldShowActions = !isNextMessageAssistant && !hasToolCalls && !hasCustomTags && mode !== 'task' && !(isResponding && isInLatestResponse);

  const shouldShowAnimation = !hasToolCalls && mode !== 'task';

  return (
    <ChatRoomContext.Provider value={{ messages, currentMessageIndex, interruptAndClearMessages, setMessages }}>
      <div className={`chat-message-assistant-wrapper ${shouldShowAnimation ? 'with-animation' : ''}`}>
        <div className="chat-message-assistant">
          <EditorContent editor={editor} />
        </div>
        <div className={`chat-message-assistant-actions ${shouldShowActions ? '' : 'chat-message-assistant-actions-hidden'}`}>
          <button
            className="chat-message-assistant-action-btn"
            onClick={handleCopy}
            onMouseEnter={() => setTempHint(isCopied ? t('copied') : t('copy'))}
            onMouseLeave={() => setTempHint(null)}
          >
            {isCopied ? <CorrectIcon /> : <CopyIcon />}
          </button>
          <button
            className="chat-message-assistant-action-btn"
            onClick={handleSaveAsNote}
            onMouseEnter={() => setTempHint(selectedFolderId ? t('saveToCurrentFolder') : t('saveToInbox'))}
            onMouseLeave={() => setTempHint(null)}
          >
            <SaveIcon />
          </button>
        </div>
      </div>
    </ChatRoomContext.Provider>
  );
};

export default ChatMessageAssistant; 