import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef, useMemo, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { isLoggedIn } from '../../../aiService/apiClient';
import PhotoIcon from '../../../assets/icon_photo_24.svg?react';
import ClassificationIcon from '../../../assets/icon_classification_24.svg?react';
import CloseIcon from '../../../assets/icon_close_round_24.svg?react';
import { useAICommanderStore } from './aiStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useCommandManager } from '../../../Store/commandManager';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useSearchRegistry } from '../../../Store/searchRegistry';
import { processItemContent } from '../../../utils/textUtils';
import { getWorkspace } from '../../../workspace/Workspace';
import MentionSuggestionList from './MentionSuggestionList';
import ImagePreviewWindow from '../../common/ImagePreviewWindow';
import syncService from '../../../utils/syncService';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';

interface AttachedableEditorProps {
    value?: string;
    onChange?: (value: string) => void;
    onSubmit?: (value: string) => void;
    placeholder?: string;
    attachedItems?: any[];
    onAddAttachment?: (item: any) => void;
    onRemoveAttachment?: (id: string) => void;
    onAttachmentClick?: (item: any) => void;
    className?: string;
    style?: React.CSSProperties;
    disabled?: boolean;
    autoHeight?: boolean;
    submitOnEnter?: boolean | null;
    isSaveMode?: boolean;
    setIsSaveMode?: (v: boolean) => void;
    autoFocus?: boolean;
    onAutoFocused?: () => void;
}

const AttachedableEditor = forwardRef<any, AttachedableEditorProps>(({
    value = '',
    onChange,
    onSubmit,
    placeholder,
    attachedItems = [],
    onAddAttachment,
    onRemoveAttachment,
    onAttachmentClick,
    className = '',
    style = {},
    disabled = false,
    autoHeight = true,
    submitOnEnter = null,
    isSaveMode = false,
    setIsSaveMode,
    autoFocus = false,
    onAutoFocused
}, ref) => {
    const { t } = useTranslation();
    const textareaRef = useRef(null);
    const [isComposing, setIsComposing] = useState(false);

    // autoFocus 處理
    useEffect(() => {
        if (autoFocus && textareaRef.current) {
            if (isLoggedIn()) {
                textareaRef.current.focus();
            }
            if (onAutoFocused) {
                onAutoFocused();
            }
        }
    }, [autoFocus, onAutoFocused]);

    const loggedIn = isLoggedIn();
    // 使用 ref 追蹤組字狀態，避免閉包問題
    const isComposingRef = useRef(false);

    const shouldSubmitOnEnter = submitOnEnter !== null ? submitOnEnter : !!onSubmit;

    const [showMentionSuggestions, setShowMentionSuggestions] = useState(false);
    const [mentionSearchText, setMentionSearchText] = useState('');
    const [mentionSuggestions, setMentionSuggestions] = useState([]);
    const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(0);
    const [mentionStartPos, setMentionStartPos] = useState(-1);
    const [suggestionPosition, setSuggestionPosition] = useState('above');
    const [cursorRect, setCursorRect] = useState(null);

    const [showImagePreview, setShowImagePreview] = useState(false);

    // Mobile 刪除選單
    const isMobileView = useIsMobileView();
    const [deleteMenuState, setDeleteMenuState] = useState({ show: false, x: 0, y: 0, itemId: null });
    const [previewImageSrc, setPreviewImageSrc] = useState('');

    const currentInlineIdsRef = useRef(new Set<string>());

    // 根據 id 獲取 name（如果 item 沒有 name，從 db 查詢）
    const getItemTitle = useCallback((item) => {
        if (item.name) return item.name;
        if (item.title) return item.title;
        if (item.type === 'image') return t('image');
        return t('untitled');
    }, [t]);

    useImperativeHandle(ref, () => ({
        focus: () => {
            textareaRef.current?.focus();
        },
        setValue: (newValue) => {
            if (textareaRef.current) {
                if (!newValue) {
                    // 空值時用 innerHTML 徹底清空，避免瀏覽器殘留 <br> 導致 :empty placeholder 不顯示
                    textareaRef.current.innerHTML = '';
                } else {
                    textareaRef.current.textContent = newValue;
                }
                scanInlineTags();
                if (newValue) moveCursorToEnd();
            }
        },
        getValue: () => {
            return textareaRef.current?.textContent || '';
        },
        insertText: (text) => {
            if (!textareaRef.current) return;
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                range.deleteContents();
                range.insertNode(document.createTextNode(text));
            } else {
                textareaRef.current.textContent += text;
            }
            triggerInput();
        },
        getFormattedContent: () => {
            if (!textareaRef.current) return '';

            const extractedText = [];

            const processNode = (node) => {
                if (node.nodeType === Node.TEXT_NODE) {
                    return node.textContent;
                } else if (node.nodeType === Node.ELEMENT_NODE && node.classList.contains('ai-commander-attach-tag')) {
                    // 從 data-mention-id 獲取 ID，改用 #[ID] 格式
                    const mentionId = node.getAttribute('data-mention-id');
                    if (mentionId) {
                        return `#[${mentionId}]`;
                    }
                    return '';
                } else if (node.nodeName === 'BR') {
                    return '\n';
                } else if (node.nodeName === 'DIV') {
                    // 遞歸處理 DIV 內的子節點
                    let divContent = '';
                    node.childNodes.forEach(child => {
                        divContent += processNode(child);
                    });
                    return '\n' + divContent;
                } else {
                    // 其他元素，遞歸處理子節點
                    let content = '';
                    node.childNodes.forEach(child => {
                        content += processNode(child);
                    });
                    return content;
                }
            };

            textareaRef.current.childNodes.forEach((node, i) => {
                const text = processNode(node);

                extractedText.push(text);
            });

            let result = extractedText.join('');
            // 只去掉首尾的空格，但保留換行符
            result = result.replace(/^[\t ]+|[\t ]+$/g, '');

            return result;
        }
    }));

    const scanInlineTags = () => {
        if (!textareaRef.current) return;

        const newInlineIds = new Set<string>();
        const tags = textareaRef.current.querySelectorAll('.ai-commander-attach-tag');
        tags.forEach(tag => {
            const id = tag.getAttribute('data-mention-id');
            if (id) newInlineIds.add(id);
        });

        currentInlineIdsRef.current.forEach(id => {
            if (!newInlineIds.has(id)) {
                if (onRemoveAttachment) {
                    onRemoveAttachment(id);
                }
            }
        });

        currentInlineIdsRef.current = newInlineIds;
    };

    useEffect(() => {
        if (textareaRef.current && value !== textareaRef.current.textContent) {
            // 只在編輯器沒有焦點時才更新（避免覆蓋用戶正在編輯的內容）
            if (document.activeElement !== textareaRef.current) {
                // 檢查是否包含 #[ID] 格式
                if (/#\[([^\]]+)\]/g.test(value) && attachedItems && attachedItems.length > 0) {

                    // 創建 attachedItems 映射
                    const itemsMap = {};
                    attachedItems.forEach(item => {
                        itemsMap[item.id] = item;
                    });

                    // 清空編輯器
                    textareaRef.current.innerHTML = '';

                    // 解析並創建 DOM
                    const regex = /#\[([^\]]+)\]/g;
                    let lastIndex = 0;
                    let match;
                    const fragment = document.createDocumentFragment();

                    while ((match = regex.exec(value)) !== null) {
                        // 添加前面的文字
                        if (match.index > lastIndex) {
                            fragment.appendChild(document.createTextNode(value.substring(lastIndex, match.index)));
                        }

                        // 使用統一的函數創建內聯標籤
                        const id = match[1];
                        const item = itemsMap[id];
                        if (item) {
                            fragment.appendChild(createInlineTagElement(item));
                        } else {
                            fragment.appendChild(document.createTextNode(match[0]));
                        }

                        lastIndex = regex.lastIndex;
                    }

                    // 添加剩餘文字
                    if (lastIndex < value.length) {
                        fragment.appendChild(document.createTextNode(value.substring(lastIndex)));
                    }

                    textareaRef.current.appendChild(fragment);

                    scanInlineTags();
                } else {
                    textareaRef.current.textContent = value;
                    scanInlineTags();
                }
            }
        }
    }, [value, attachedItems]);

    // Escape 關閉 mention suggestions — commandManager 統一管理
    useEffect(() => {
        const unsub = useCommandManager.getState().register({
            command: {
                id: 'attachable-editor:escape-mention',
                name: t('cmd.closeMentionSuggestions'),
                callback: () => {
                    if (mentionStartPos !== -1 && textareaRef.current) {
                        const selection = window.getSelection();
                        if (selection.rangeCount > 0) {
                            try {
                                const range = selection.getRangeAt(0);
                                const cursorPos = getCursorPosition();
                                const textToDelete = cursorPos - mentionStartPos;
                                for (let i = 0; i < textToDelete; i++) {
                                    range.setStart(range.startContainer, Math.max(0, range.startOffset - 1));
                                }
                                range.deleteContents();
                                range.collapse(true);
                                selection.removeAllRanges();
                                selection.addRange(range);
                                triggerInput();
                            } catch (error) {
                                console.error('刪除 @ 標記失敗:', error);
                            }
                        }
                    }
                    setShowMentionSuggestions(false);
                    setMentionSearchText('');
                    setMentionStartPos(-1);
                },
            },
            hotkeys: [{ modifiers: [], key: 'Escape' }],
            enabled: () => showMentionSuggestions,
        });
        return unsub;
    }, [showMentionSuggestions, mentionStartPos]);

    const triggerInput = () => {
        if (textareaRef.current) {
            const inputEvent = new Event('input', { bubbles: true });
            textareaRef.current.dispatchEvent(inputEvent);
        }
    };

    const moveCursorToEnd = () => {
        if (!textareaRef.current) return;
        const range = document.createRange();
        const selection = window.getSelection();
        range.selectNodeContents(textareaRef.current);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    };

    const getCursorPosition = () => {
        if (!textareaRef.current) return 0;

        const selection = window.getSelection();
        if (!selection.rangeCount) return 0;

        const range = selection.getRangeAt(0);
        const preCaretRange = range.cloneRange();
        preCaretRange.selectNodeContents(textareaRef.current);
        preCaretRange.setEnd(range.endContainer, range.endOffset);

        return preCaretRange.toString().length;
    };

    const setCursorPosition = (pos) => {
        if (!textareaRef.current) return;

        const range = document.createRange();
        const sel = window.getSelection();

        let currentPos = 0;
        let found = false;

        const findPosition = (node) => {
            if (found) return;

            if (node.nodeType === Node.TEXT_NODE) {
                const length = node.textContent.length;
                if (currentPos + length >= pos) {
                    range.setStart(node, pos - currentPos);
                    range.collapse(true);
                    found = true;
                    return;
                }
                currentPos += length;
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                for (const child of node.childNodes) {
                    findPosition(child);
                    if (found) return;
                }
            }
        };

        findPosition(textareaRef.current);

        if (found) {
            sel.removeAllRanges();
            sel.addRange(range);
        }
    };

    const handleContentEditableInput = (e) => {
        if (!textareaRef.current) return;

        const text = textareaRef.current.textContent || '';

        // 無文字且無 inline tag 時強制清除殘留 HTML，確保 :empty placeholder 顯示
        if (!text && !textareaRef.current.querySelector('[data-mention-id]')) {
            textareaRef.current.innerHTML = '';
        }

        scanInlineTags();

        // 組字期間不觸發 onChange，避免保存中間狀態（如 "風ㄍㄜˊ"）
        if (onChange && !isComposingRef.current) {
            onChange(text);
        }

        const cursorPos = getCursorPosition();
        detectMention(text, cursorPos);
    };

    const handlePaste = async (e) => {
        e.preventDefault();

        // 先處理剪貼板中的圖片數據
        const items = e.clipboardData?.items;
        if (items && onAddAttachment) {
            for (let i = 0; i < items.length; i++) {
                const item = items[i];
                if (item.type.indexOf('image') === 0) {
                    const blob = item.getAsFile();
                    if (blob) {
                        try {
                            // 將圖片轉換為 base64
                            const base64 = await new Promise((resolve, reject) => {
                                const reader = new FileReader();
                                reader.onload = () => resolve(reader.result);
                                reader.onerror = reject;
                                reader.readAsDataURL(blob);
                            });

                            // 生成唯一 ID
                            const imageId = Math.random().toString(36).substr(2, 9);
                            const extension = blob.type.split('/')[1] || 'png';

                            // 添加到附加項目
                            onAddAttachment({
                                id: imageId,
                                type: 'image',
                                title: blob.name || `image.${extension}`,
                                data: base64,
                                mimeType: blob.type,
                                file: blob
                            });

                            // 粘貼圖片時，如果儲存模式開啟，自動關閉
                            if (isSaveMode && setIsSaveMode) {
                                setIsSaveMode(false);
                            }
                        } catch (error) {
                            console.error('讀取圖片失敗:', error);
                        }
                    }
                    return; // 已處理圖片，退出
                }
            }
        }

        // 如果沒有圖片，處理文字粘貼
        const text = e.clipboardData.getData('text/plain').replace(/\n\n/g, '\n');

        // 使用 execCommand 插入文字，這樣可以正確保留瀏覽器的撤銷歷史
        document.execCommand('insertText', false, text);

        triggerInput();
    };

    const detectMention = (value, cursorPos) => {
        if (!value || cursorPos === undefined) {
            setShowMentionSuggestions(false);
            return;
        }

        const textBeforeCursor = value.substring(0, cursorPos);
        const lastAtIndex = textBeforeCursor.lastIndexOf('@');

        if (lastAtIndex === -1) {
            setShowMentionSuggestions(false);
            return;
        }

        const textAfterAt = textBeforeCursor.substring(lastAtIndex + 1);

        if (/[\s\n]/.test(textAfterAt)) {
            setShowMentionSuggestions(false);
            return;
        }

        // 只在非自動高度模式（TaskEditor）時計算游標位置
        if (!autoHeight && textareaRef.current) {
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                const rect = range.getBoundingClientRect();

                // 儲存游標位置
                setCursorRect({
                    top: rect.top,
                    left: rect.left,
                    bottom: rect.bottom,
                    right: rect.right
                });

                const editorRect = textareaRef.current.getBoundingClientRect();
                const cursorTop = rect.top - editorRect.top;
                const editorHeight = editorRect.height;

                // 如果游標在編輯器上半部，顯示在下方；否則顯示在上方
                setSuggestionPosition(cursorTop < editorHeight / 2 ? 'below' : 'above');
            }
        } else {
            // 聊天室模式：保持原樣（顯示在上方）
            setCursorRect(null);
            setSuggestionPosition('above');
        }

        setShowMentionSuggestions(true);
        setMentionSearchText(textAfterAt);
        setMentionStartPos(lastAtIndex);
        setSelectedSuggestionIndex(0);
    };

    useEffect(() => {
        if (!showMentionSuggestions) {
            setMentionSuggestions([]);
            return;
        }

        const searchText = mentionSearchText.trim().toLowerCase();

        // 統一走 SearchRegistry（包含 AGENT）
        const registryResults = useSearchRegistry.getState().search(searchText);
        const results = registryResults.map(item => ({
            ...item,
            title: item.name || t('untitled'),
            contentPreview: processItemContent(item, false, false),
            updatedAt: item.updatedAt || 0,
        }));

        const sorted = results.sort((a, b) => {
            const aTitleMatch = a.title?.toLowerCase().includes(searchText);
            const bTitleMatch = b.title?.toLowerCase().includes(searchText);
            if (aTitleMatch && !bTitleMatch) return -1;
            if (!aTitleMatch && bTitleMatch) return 1;
            return Number(b.updatedAt || 0) - Number(a.updatedAt || 0);
        });

        setMentionSuggestions(sorted.slice(0, 100));
    }, [showMentionSuggestions, mentionSearchText, t]);

    // 創建內聯標籤元素的統一函數
    const createInlineTagElement = (item) => {
        const mentionSpan = document.createElement('span');
        mentionSpan.className = 'ai-commander-attach-tag ai-commander-attach-tag-inline';
        mentionSpan.contentEditable = 'false';
        mentionSpan.setAttribute('data-mention-id', item.id);
        mentionSpan.setAttribute('data-mention-type', item.type);
        mentionSpan.style.display = 'inline-flex';
        mentionSpan.style.verticalAlign = 'middle';

        const iconContainer = document.createElement('span');
        iconContainer.className = 'ai-commander-attach-tag-icon';
        iconContainer.style.pointerEvents = 'none';

        // title：先用 item 上已有的 name，否則從 DB 非同步取
        let displayTitle = item.name || item.title || '';
        if (!displayTitle) {
            displayTitle = t('untitled');
            window.electronAPI!.getItem(item.id).then(dbItem => {
                if (dbItem?.name) textSpan.textContent = dbItem.name;
            });
        }

        const textSpan = document.createElement('span');
        textSpan.className = 'ai-commander-attach-tag-text';
        textSpan.textContent = displayTitle;

        mentionSpan.appendChild(iconContainer);
        mentionSpan.appendChild(textSpan);

        // 動態加載圖標
        const tempContainer = document.createElement('div');
        tempContainer.style.display = 'none';
        document.body.appendChild(tempContainer);

        import('react-dom/client').then(({ createRoot }) => {
            const root = createRoot(tempContainer);

            const provider = item.itemType ? useSearchRegistry.getState().getProvider(item.itemType) : null;
            if (provider) {
                root.render(provider.renderIcon(item));
            } else if (item.type === 'image') {
                root.render(React.createElement(PhotoIcon));
            } else {
                root.render(React.createElement(ClassificationIcon));
            }

            // 使用 requestAnimationFrame 確保 React 已經完成渲染
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    const svg = tempContainer.querySelector('svg');

                    if (svg) {
                        const clonedSvg = svg.cloneNode(true);
                        iconContainer.appendChild(clonedSvg);

                    } else {
                        console.error('[內聯標籤] 找不到 SVG 元素');
                    }
                    root.unmount();
                    document.body.removeChild(tempContainer);
                });
            });
        }).catch(err => {
            console.error('[內聯標籤] 動態加載圖標失敗:', err);
        });

        return mentionSpan;
    };

    const selectMentionNote = (item) => {
        if (!item || !textareaRef.current) return;

        const isAlreadyAttached = attachedItems.some(attachedItem => attachedItem.id === item.id);
        if (!isAlreadyAttached && onAddAttachment) {
            onAddAttachment(item);
            if (isSaveMode && setIsSaveMode) setIsSaveMode(false);
        }

        if (mentionStartPos !== -1) {
            const selection = window.getSelection();
            if (!selection.rangeCount) return;

            const range = selection.getRangeAt(0);

            // 計算要刪除的文字範圍（從 @ 到當前光標）
            const currentText = textareaRef.current.textContent;
            const cursorPos = getCursorPosition();
            const textToDelete = currentText.substring(mentionStartPos, cursorPos);

            try {
                // 選中要刪除的文字（從 @ 到光標位置）
                for (let i = 0; i < textToDelete.length; i++) {
                    range.setStart(range.startContainer, Math.max(0, range.startOffset - 1));
                }
                selection.removeAllRanges();
                selection.addRange(range);

                const tagDisplayText = item.name || item.title || item.aiTitle || t('untitled');
                const tagHtml = `<span class="ai-commander-attach-tag ai-commander-attach-tag-inline" contenteditable="false" data-mention-id="${item.id}" data-mention-type="${item.type}" style="display: inline-flex; vertical-align: middle;"><span class="ai-commander-attach-tag-icon" style="pointer-events: none;"></span><span class="ai-commander-attach-tag-text">${tagDisplayText}</span></span>&nbsp;`;

                // 使用 execCommand 插入 HTML，保持撤銷歷史
                document.execCommand('insertHTML', false, tagHtml);

                // 設置光標位置到標籤後面
                const insertedTag = textareaRef.current.querySelector(`.ai-commander-attach-tag[data-mention-id="${item.id}"]`);
                if (insertedTag && insertedTag.nextSibling) {
                    const newRange = document.createRange();
                    const newSelection = window.getSelection();
                    // 將光標放在標籤後面的文字節點（&nbsp;）之後
                    if (insertedTag.nextSibling.nodeType === Node.TEXT_NODE) {
                        newRange.setStart(insertedTag.nextSibling, insertedTag.nextSibling.length);
                    } else {
                        newRange.setStartAfter(insertedTag.nextSibling);
                    }
                    newRange.collapse(true);
                    newSelection.removeAllRanges();
                    newSelection.addRange(newRange);
                }

                // 動態加載圖標到剛插入的標籤
                if (insertedTag) {
                    const iconContainer = insertedTag.querySelector('.ai-commander-attach-tag-icon');
                    if (iconContainer) {
                        import('react-dom/client').then(({ createRoot }) => {
                            const tempContainer = document.createElement('div');
                            tempContainer.style.display = 'none';
                            document.body.appendChild(tempContainer);

                            const root = createRoot(tempContainer);
                            const inlineProvider = item.itemType ? useSearchRegistry.getState().getProvider(item.itemType) : null;
                            if (inlineProvider) {
                                root.render(inlineProvider.renderIcon(item));
                            } else if (item.type === 'image') {
                                root.render(React.createElement(PhotoIcon));
                            } else {
                                root.render(React.createElement(ClassificationIcon));
                            }

                            requestAnimationFrame(() => {
                                requestAnimationFrame(() => {
                                    const svg = tempContainer.querySelector('svg');
                                    if (svg) {
                                        iconContainer.appendChild(svg.cloneNode(true));
                                    }
                                    root.unmount();
                                    document.body.removeChild(tempContainer);
                                });
                            });
                        });
                    }
                }
            } catch (error) {
                console.error('插入標籤失敗:', error);
            }

            textareaRef.current.focus();

            scanInlineTags();

            // 手動觸發 onChange，讓父組件知道內容已變化
            if (onChange) {
                onChange(textareaRef.current.textContent);
            }
        }

        setShowMentionSuggestions(false);
        setMentionSearchText('');
        setMentionStartPos(-1);
    };

    const handleKeyDown = (e) => {
        if (isComposing) return;

        if (showMentionSuggestions && mentionSuggestions.length > 0) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                setSelectedSuggestionIndex(prev =>
                    prev < mentionSuggestions.length - 1 ? prev + 1 : prev
                );
                return;
            }

            if (e.key === 'ArrowUp') {
                e.preventDefault();
                setSelectedSuggestionIndex(prev => prev > 0 ? prev - 1 : 0);
                return;
            }

            if (e.key === 'Enter') {
                e.preventDefault();
                const selected = mentionSuggestions[selectedSuggestionIndex];
                if (selected) {
                    selectMentionNote(selected);
                }
                return;
            }
        }

        if (e.key === 'Enter' && !e.shiftKey) {
            if (shouldSubmitOnEnter) {
                e.preventDefault();
                if (onSubmit) onSubmit(textareaRef.current?.textContent || '');
                // 手機版：送出後失焦以收起鍵盤
                if (isMobileView) {
                    textareaRef.current?.blur();
                }
                return;
            }
        }

        if (e.key === 'Backspace' && attachedItems.length > 0) {
            const cursorPosition = getCursorPosition();
            const textValue = textareaRef.current?.textContent || '';

            if (textValue.length === 0 || cursorPosition === 0) {
                if (onRemoveAttachment) {
                    const lastItem = attachedItems[attachedItems.length - 1];

                    const isInDom = textareaRef.current?.querySelector(`.ai-commander-attach-tag[data-mention-id="${lastItem.id}"]`);

                    if (!isInDom) {
                        onRemoveAttachment(lastItem.id);
                        if (textValue.length === 0) e.preventDefault();
                    }
                }
            }
        }
    };

    const handleItemClick = (item) => {

        if (onAttachmentClick) {
            onAttachmentClick(item);
        } else {
            if (item.type === 'image') {
                setPreviewImageSrc(item.data || item.url);
                setShowImagePreview(true);
            } else {
                if (useSelectedItemsStore.getState().path.at(-1)?.itemType === 'AI_ADMIN_FOLDER') {
                    getWorkspace()?.openWindow({ id: item.id, itemType: item.itemType || 'NOTE' });
                    return;
                }
                window.electronAPI!.getItem(item.id).then(fullItem => {
                    if (fullItem) useSelectedItemsStore.getState().setSelectedItems([fullItem], { scrollToFocusItem: true, highlightItemId: item.id });
                });
            }
        }
    };

    const handleDragOver = (e) => {
        // dataTransfer.types 可能是 DOMStringList，需要轉換或使用 Array.from
        const types = Array.from(e.dataTransfer.types || []);
        const shouldAllow = types.includes('folderid') ||
            types.includes('application/cubelv-item') ||
            types.includes('application/cubelv-folder') ||
            types.includes('application/cubelv-card') ||
            types.includes('application/cubelv-cards') ||
            types.includes('application/cubelv-cardtype') ||
            types.includes('application/cubelv-sharedcardtype') ||
            types.includes('application/cubelv-chart') ||
            types.includes('application/cubelv-charttype');

        if (shouldAllow) {
            e.preventDefault();
            e.stopPropagation();
        }
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();

        // 處理多卡片拖曳（包含分享卡片）
        const cardsData = e.dataTransfer.getData('application/cubelv-cards');

        if (cardsData) {
            try {
                const cards = JSON.parse(cardsData);
                let addedCount = 0;

                cards.forEach(card => {
                    const alreadyAttached = attachedItems.some(item => item.id === card.id);
                    if (alreadyAttached) return;
                    if (onAddAttachment) {
                        onAddAttachment(card);
                        addedCount++;
                    }
                });

                // 拖曳卡片時，如果儲存模式開啟，自動關閉
                if (addedCount > 0 && isSaveMode && setIsSaveMode) {
                    setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析多卡片資料失敗:', error);
            }
            return;
        }

        // 處理單卡片拖曳（包含分享卡片）
        const cardData = e.dataTransfer.getData('application/cubelv-card');

        if (cardData) {
            try {
                const card = JSON.parse(cardData);
                const alreadyAttached = attachedItems.some(item => item.id === card.id);
                if (alreadyAttached) return;

                if (onAddAttachment) onAddAttachment(card);

                // 拖曳卡片時，如果儲存模式開啟，自動關閉
                if (isSaveMode && setIsSaveMode) {
                    setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析卡片資料失敗:', error);
            }
            return;
        }

        // 處理卡片類型拖曳（包含分享卡片類型）
        const cardTypeData = e.dataTransfer.getData('application/cubelv-cardtype') ||
            e.dataTransfer.getData('application/cubelv-sharedcardtype');

        if (cardTypeData) {
            try {
                const cardType = JSON.parse(cardTypeData);

                if (cardType.isCardGroup) {
                    cardType.childCardTypes?.forEach(child => {
                        if (attachedItems.some(a => a.id === child.id)) return;
                        if (onAddAttachment) onAddAttachment(child);
                    });
                } else {
                    if (attachedItems.some(a => a.id === cardType.id)) return;
                    if (onAddAttachment) onAddAttachment(cardType);
                }

                // 拖曳卡片類型時，如果儲存模式開啟，自動關閉
                if (isSaveMode && setIsSaveMode) {
                    setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析卡片類型資料失敗:', error);
            }
            return;
        }

        // 處理單個圖表拖曳
        const chartData = e.dataTransfer.getData('application/cubelv-chart');

        if (chartData) {
            try {
                const chart = JSON.parse(chartData);
                if (attachedItems.some(a => a.id === chart.id)) return;
                if (onAddAttachment) onAddAttachment(chart);

                // 拖曳圖表時，如果儲存模式開啟，自動關閉
                if (isSaveMode && setIsSaveMode) {
                    setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析圖表資料失敗:', error);
            }
            return;
        }

        // 處理圖表類型拖曳
        const chartTypeData = e.dataTransfer.getData('application/cubelv-charttype');

        if (chartTypeData) {
            try {
                const chartType = JSON.parse(chartTypeData);

                if (chartType.isChartGroup) {
                    chartType.childChartTypes?.forEach(child => {
                        if (attachedItems.some(a => a.id === child.id)) return;
                        if (onAddAttachment) onAddAttachment(child);
                    });
                } else {
                    if (attachedItems.some(a => a.id === chartType.id)) return;
                    if (onAddAttachment) onAddAttachment(chartType);
                }

                // 拖曳圖表類型時，如果儲存模式開啟，自動關閉
                if (isSaveMode && setIsSaveMode) {
                    setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析圖表類型資料失敗:', error);
            }
            return;
        }

        // 處理 Sidebar 統一拖曳格式（application/cubelv-item）
        const sidebarItemData = e.dataTransfer.getData('application/cubelv-item');
        if (sidebarItemData) {
            try {
                const item = JSON.parse(sidebarItemData);
                const alreadyAttached = attachedItems.some(a => a.id === item.id);
                if (alreadyAttached) return;

                if (onAddAttachment) {
                    onAddAttachment(item);
                    if (isSaveMode && setIsSaveMode) setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析 sidebar item 資料失敗:', error);
            }
            return;
        }

        // 處理資料夾拖曳（原有邏輯）
        const folderData = e.dataTransfer.getData('application/cubelv-folder');
        if (folderData) {
            try {
                const folder = JSON.parse(folderData);
                if (attachedItems.some(a => a.id === folder.id)) return;
                if (onAddAttachment) onAddAttachment(folder);

                // 拖曳資料夾時，如果儲存模式開啟，自動關閉
                if (isSaveMode && setIsSaveMode) {
                    setIsSaveMode(false);
                }
            } catch (error) {
                console.error('解析資料夾資料失敗:', error);
            }
        }
    };

    return (
        <>
            {/* 顯示附加項目區域 */}
            {attachedItems.length > 0 && (
                <div className="ai-commander-attach-container">
                    {attachedItems.map((item) => (
                        <div
                            key={item.id}
                            className="ai-commander-attach-tag"
                            onClick={(e) => {
                                // Mobile：點擊整個 tag 顯示刪除選單
                                if (isMobileView) {
                                    e.stopPropagation();
                                    setDeleteMenuState({
                                        show: true,
                                        x: e.clientX,
                                        y: e.clientY,
                                        itemId: item.id
                                    });
                                }
                            }}
                        >
                            <button
                                className="ai-commander-attach-tag-icon"
                                style={isMobileView ? { pointerEvents: 'none' } : {}}
                                onClick={(e) => {
                                    // 桌面版：點擊 icon 直接刪除
                                    if (!isMobileView) {
                                        e.stopPropagation();

                                        if (onRemoveAttachment) onRemoveAttachment(item.id);
                                    }
                                }}
                            >
                                {(() => {
                                    if (item.type === 'image') return <PhotoIcon />;
                                    const p = item.itemType ? useSearchRegistry.getState().getProvider(item.itemType) : null;
                                    if (p) return p.renderIcon(item);
                                    return <ClassificationIcon />;
                                })()}
                                <span className="ai-commander-attach-tag-close"><CloseIcon /></span>
                            </button>
                            <span
                                className="ai-commander-attach-tag-text"
                                onClick={(e) => {
                                    if (!isMobileView) {
                                        handleItemClick(item);
                                    }
                                }}
                                style={{ cursor: 'pointer' }}
                            >
                                {getItemTitle(item)}
                            </span>
                        </div>
                    ))}
                </div>
            )}

            {/* Mobile 刪除選單 */}
            {deleteMenuState.show && (
                <PopupMenu
                    x={deleteMenuState.x}
                    y={deleteMenuState.y}
                    onClose={() => setDeleteMenuState({ show: false, x: 0, y: 0, itemId: null })}
                >
                    <PopupMenuItem
                        danger
                        onClick={() => {
                            if (onRemoveAttachment && deleteMenuState.itemId) {
                                onRemoveAttachment(deleteMenuState.itemId);
                            }
                            setDeleteMenuState({ show: false, x: 0, y: 0, itemId: null });
                        }}
                    >
                        {t('delete')}
                    </PopupMenuItem>
                </PopupMenu>
            )}

            <div
                className={`ai-commander-input-wrapper ${className}`}
                style={{
                    ...style,
                    flex: 1,
                    display: 'flex',
                    alignItems: 'flex-start',
                    height: autoHeight ? 'auto' : '100%',
                    position: 'relative'
                }}
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                onClick={(e) => {
                    if (!loggedIn) {
                        e.preventDefault();
                        e.stopPropagation();
                        useAICommanderStore.getState().setIsAICommanderOpen(false);
                        useDialogStore.getState().open('login', { type: 'ai' });
                    }
                }}
            >
                {showMentionSuggestions && (
                    <MentionSuggestionList
                        suggestions={mentionSuggestions}
                        selectedIndex={selectedSuggestionIndex}
                        onSelect={selectMentionNote}
                        position={suggestionPosition}
                        cursorRect={cursorRect}
                        useFixedPosition={!autoHeight}
                    />
                )}
                <div
                    ref={textareaRef}
                    className={`ai-commander-input-contenteditable ${autoHeight ? 'auto-height' : 'fill-height'}`}
                    contentEditable={!disabled}
                    data-placeholder={placeholder}
                    onInput={handleContentEditableInput}
                    onPaste={handlePaste}
                    onKeyDown={handleKeyDown}
                    onCompositionStart={() => {
                        setIsComposing(true);
                        isComposingRef.current = true;
                    }}
                    onCompositionEnd={() => {
                        setIsComposing(false);
                        isComposingRef.current = false;
                        // 組字完成後觸發 onChange，確保最終值被正確保存
                        if (onChange && textareaRef.current) {
                            onChange(textareaRef.current.textContent || '');
                        }
                    }}
                    onFocus={(e) => {
                        if (!loggedIn) {
                            e.target.blur();
                            useAICommanderStore.getState().setIsAICommanderOpen(false);
                            useDialogStore.getState().open('login', { type: 'ai' });
                            return;
                        }
                        syncService.checkUnsyncedContent();
                    }}
                    suppressContentEditableWarning={true}
                />
            </div>

            <ImagePreviewWindow
                isOpen={showImagePreview}
                src={previewImageSrc}
                onClose={() => setShowImagePreview(false)}
            />
        </>
    );
});

export default AttachedableEditor;
