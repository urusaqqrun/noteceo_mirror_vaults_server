export const mockAgents = {
  'agent_001': {
    id: 'agent_001',
    parentID: '691f133b864be384e560f1ef',
    status: 'active',
    name: '整理會議記錄',
    content: '',
    runPolicies: [],
    attachedItems: []
  },
  'agent_002': {
    id: 'agent_002',
    parentID: '691f133b864be384e560f1ef',
    status: 'active',
    name: '撰寫專案報告',
    content: '',
    runPolicies: [],
    attachedItems: []
  },
  'agent_003': {
    id: 'agent_003',
    parentID: '691f133b864be384e560f1ef',
    status: 'active',
    name: '複習英文單字',
    content: '',
    runPolicies: [],
    attachedItems: []
  },
  'agent_004': {
    id: 'agent_004',
    parentID: '691f133b864be384e560f1ef',
    status: 'active',
    name: '每日回顧',
    content: '',
    runPolicies: [],
    attachedItems: []
  },
  'agent_005': {
    id: 'agent_005',
    parentID: '691f133b864be384e560f1ef',
    status: 'active',
    name: '整理書摘',
    content: '',
    runPolicies: [],
    attachedItems: []
  }
};

export const mockAgentReports = [
  {
    id: 'report_001',
    agentId: 'agent_001',
    type: 'NeedSelection',
    content: '這是一個需要您選擇的報告內容，請查看詳細信息並做出決定。',
    isRead: false,
    updatedAt: '2023-10-01T10:00:00Z',
    options: ['同意', '拒絕'],
    userAnswer: null
  },
  {
    id: 'report_002',
    agentId: 'agent_002',
    type: 'NeedInput',
    content: '這是一個需要您回應的報告內容，請查看詳細信息並提供您的意見。',
    isRead: false,
    updatedAt: '2023-10-02T14:30:00Z',
    options: null,
    userAnswer: null
  },
  {
    id: 'report_003',
    agentId: 'agent_003',
    type: 'Completed',
    content: '這是一個已完成的報告內容。',
    isRead: true,
    updatedAt: '2023-10-03T09:15:00Z',
    options: null,
    userAnswer: null
  },
  {
    id: 'report_004',
    agentId: 'agent_004',
    type: 'Failed',
    content: '這是一個執行失敗的報告。',
    isRead: true,
    updatedAt: '2023-10-04T16:45:00Z',
    options: null,
    userAnswer: null
  },
  {
    id: 'report_005',
    agentId: 'agent_005',
    type: 'Completed',
    content: '這是另一個已完成的報告。',
    isRead: false,
    updatedAt: '2023-10-05T11:20:00Z',
    options: null,
    userAnswer: null
  }
];
