import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './MentionSuggestionList.css';
import NoteIcon from '../../../assets/icon_note_24.svg?react';
import { useSearchRegistry } from '../../../Store/searchRegistry';

const MentionSuggestionList = ({ suggestions, selectedIndex, onSelect, position, cursorRect, useFixedPosition = false }) => {
  const { t } = useTranslation();
  const selectedItemRef = useRef(null);

  useEffect(() => {
    if (selectedItemRef.current) {
      selectedItemRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
      });
    }
  }, [selectedIndex]);

  if (!suggestions || suggestions.length === 0) {
    return null;
  }

  if (useFixedPosition && !cursorRect) {
    return null;
  }

  const style = useFixedPosition && cursorRect ? {
    left: `${cursorRect.left}px`,
    top: position === 'above' ? `${cursorRect.top}px` : `${cursorRect.bottom}px`
  } : {};

  const className = `mention-suggestion-list ${position === 'below' ? 'position-below' : 'position-above'} ${useFixedPosition ? 'position-fixed' : ''}`;

  return (
    <div className={className} style={style}>
      {suggestions.map((item, index) => {
        const provider = item.itemType ? useSearchRegistry.getState().getProvider(item.itemType) : null;
        const displayName = item.name || item.title || item.aiTitle || t('untitled');
        const isShared = item.isShared && item.sharerName;

        return (
          <div
            key={item.id}
            ref={index === selectedIndex ? selectedItemRef : null}
            className={`mention-suggestion-item ${index === selectedIndex ? 'selected' : ''}`}
            onClick={() => onSelect(item)}
            onMouseEnter={(e) => {
              e.currentTarget.classList.add('hover');
            }}
            onMouseLeave={(e) => {
              e.currentTarget.classList.remove('hover');
            }}
          >
            <div className="mention-suggestion-icon">
              {provider?.renderIcon(item) || <NoteIcon className="mention-note-icon" />}
            </div>
            <div className="mention-suggestion-content">
              <div className="mention-suggestion-title">
                {displayName}{isShared ? ` (${item.sharerName})` : ''}
              </div>
              {item.contentPreview?.replace(/[\s\u00A0\u200B\u200C\u200D\uFEFF]+/g, ' ').trim() ? (
                <div className="mention-suggestion-preview">
                  {item.contentPreview.replace(/[\s\u00A0\u200B\u200C\u200D\uFEFF]+/g, ' ').trim()}
                </div>
              ) : null}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default MentionSuggestionList;

