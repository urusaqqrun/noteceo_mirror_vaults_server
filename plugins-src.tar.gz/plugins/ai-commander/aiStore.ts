import { create } from 'zustand';

import { useCardInfoPanelStore } from '../../../Store/uiStore';

export const AI_COMMANDER_DEFAULT_SIZE = 353;



interface AICommanderState {
    isAICommanderOpen: boolean;
    pendingFocus: boolean;
    setIsAICommanderOpen: (newValue: boolean, shouldFocus?: boolean) => void;
    syncIsAICommanderOpen: () => void;
    clearPendingFocus: () => void;
}


interface AttachmentItem {
    id: string;
    type?: string;
    name?: string;
    title?: string;
    content?: string;
    url?: string;
    [key: string]: any;
}

interface AICommanderAttachmentsState {
    attachedItems: AttachmentItem[];
    addAttachment: (item: AttachmentItem) => void;
    removeAttachment: (id: string) => void;
    clearAttachments: () => void;
}



interface CommanderItem {
    id: string;
    type?: string;
    fields: string | CommanderFields;
}

interface CommanderFields {
    aiRewriteCommands?: any[];
    aiRewriteResults?: any[];
    memberID?: string;
    updatedAt?: string;
}

interface AiCommanderDataState {
    commander: CommanderItem | null;
    getCommands: () => any[];
    getResults: () => any[];
    updateCommander: (aiRewriteCommands: any[], aiRewriteResults: any[], needSync?: boolean) => Promise<void>;
    loadCommander: () => Promise<void>;
    reset: () => void;
}

// ===== Stores =====

// AI Commander 狀態 store
function getAICommanderLeaf(): any | null {
    return (window as any).__workspace?.getLeafById?.('leaf-ai') ?? null;
}

function getAICommanderIsOpen(): boolean {
    const leaf = getAICommanderLeaf();
    return !!leaf && !!leaf.sizeValue;
}

export const useAICommanderStore = create<AICommanderState>((set) => ({
    isAICommanderOpen: false,
    pendingFocus: false,
    setIsAICommanderOpen: (newValue, shouldFocus = false) => {
        const workspace = (window as any).__workspace;
        const leaf = getAICommanderLeaf();

        if (leaf) {
            const view = leaf.view as any;
            if (!newValue && leaf.sizeValue > 0) {
                view?.setLastOpenWidth?.(leaf.sizeValue);
                leaf.sizeValue = 0;
            } else if (newValue) {
                const restoredWidth = view?.getLastOpenWidth?.() ?? AI_COMMANDER_DEFAULT_SIZE;
                leaf.sizeValue = restoredWidth > 0 ? restoredWidth : AI_COMMANDER_DEFAULT_SIZE;
            }
            workspace?.trigger?.('layout-change');
            workspace?.requestSaveLayout?.();
        }

        if (newValue) {
            useCardInfoPanelStore.getState().setIsCardInfoPanelOpen(false);
        }
        set({ isAICommanderOpen: getAICommanderIsOpen(), pendingFocus: shouldFocus });
    },
    syncIsAICommanderOpen: () => set({ isAICommanderOpen: getAICommanderIsOpen() }),
    clearPendingFocus: () => set({ pendingFocus: false })
}));


// AICommander 附加項目 Store
export const useAICommanderAttachmentsStore = create<AICommanderAttachmentsState>((set) => ({
    attachedItems: [],
    addAttachment: (item) => set((state) => ({
        attachedItems: [...state.attachedItems, item]
    })),
    removeAttachment: (id) => set((state) => ({
        attachedItems: state.attachedItems.filter(item => item.id !== id)
    })),
    clearAttachments: () => set({ attachedItems: [] })
}));

// ==================== AI Commander Data Store ====================
export const useAiCommanderDataStore = create<AiCommanderDataState>((set, get) => ({
    commander: null,
    getCommands: () => {
        const commander = get().commander;
        if (!commander) return [];
        return commander.aiRewriteCommands || [];
    },
    getResults: () => {
        const commander = get().commander;
        if (!commander) return [];
        return commander.aiRewriteResults || [];
    },
    updateCommander: async (aiRewriteCommands, aiRewriteResults, needSync = true) => {
        const current = get().commander;

        const updatedCommander = {
            ...current,
            aiRewriteCommands,
            aiRewriteResults,
            updatedAt: new Date().toISOString()
        };

        const item = {
            id: current?.id || `ai_commander_${current?.memberID || 'default'}`,
            itemType: 'AI_REWRITE_CONFIG',
            ...updatedCommander
        };

        set({ commander: updatedCommander });

        if (current) {
            if (window.electronAPI?.updateItem) {
                await window.electronAPI.updateItem(item);
            }
        } else {
            if (window.electronAPI?.addItem) {
                await window.electronAPI.addItem(item);
            }
        }

        if (needSync) {
            localStorage.setItem('itemsPendingSync', 'true');
        }
    },
    loadCommander: async () => {
        const getItems = window.electronAPI?.getItemsByType;
        if (getItems) {
            const items = await getItems('AI_REWRITE_CONFIG');
            if (items && items.length > 0) {
                const item = items[0];
                set({ commander: item });
            }
        }
    },
    reset: () => set({ commander: null })
}));


// ==================== Pre-Input Queue Store ====================
// 預輸入佇列：per-session 設計，每個 session 各自獨立

interface PreInputItem {
    id: string;
    content: string;
    attachedItems: AttachmentItem[];
    createdAt: number;
}

interface PreInputState {
    queues: Record<string, PreInputItem[]>;
    getQueue: (sessionID: string | null) => PreInputItem[];
    addPreInput: (sessionID: string | null, content: string, attachedItems: AttachmentItem[]) => void;
    updatePreInput: (sessionID: string | null, id: string, content: string) => void;
    removePreInput: (sessionID: string | null, id: string) => void;
    shiftPreInput: (sessionID: string | null) => PreInputItem | undefined;
    clearSession: (sessionID: string | null) => void;
    clearAll: () => void;
}

export const usePreInputStore = create<PreInputState>((set, get) => ({
    queues: {},

    getQueue: (sessionID) => {
        if (!sessionID) return [];
        return get().queues[sessionID] || [];
    },

    addPreInput: (sessionID, content, attachedItems) => {
        if (!sessionID) return;
        const newItem: PreInputItem = {
            id: crypto.randomUUID(),
            content,
            attachedItems: [...attachedItems],
            createdAt: Date.now(),
        };
        set(state => ({
            queues: {
                ...state.queues,
                [sessionID]: [...(state.queues[sessionID] || []), newItem],
            },
        }));
    },

    updatePreInput: (sessionID, id, content) => {
        if (!sessionID) return;
        set(state => {
            const queue = state.queues[sessionID];
            if (!queue) return state;
            return {
                queues: {
                    ...state.queues,
                    [sessionID]: queue.map(item =>
                        item.id === id ? { ...item, content } : item
                    ),
                },
            };
        });
    },

    removePreInput: (sessionID, id) => {
        if (!sessionID) return;
        set(state => {
            const queue = state.queues[sessionID];
            if (!queue) return state;
            return {
                queues: {
                    ...state.queues,
                    [sessionID]: queue.filter(item => item.id !== id),
                },
            };
        });
    },

    shiftPreInput: (sessionID) => {
        if (!sessionID) return undefined;
        const queue = get().queues[sessionID];
        if (!queue || queue.length === 0) return undefined;
        const first = queue[0];
        set(state => ({
            queues: {
                ...state.queues,
                [sessionID]: (state.queues[sessionID] || []).slice(1),
            },
        }));
        return first;
    },

    clearSession: (sessionID) => {
        if (!sessionID) return;
        set(state => {
            const newQueues = { ...state.queues };
            delete newQueues[sessionID];
            return { queues: newQueues };
        });
    },

    clearAll: () => set({ queues: {} }),
}));
