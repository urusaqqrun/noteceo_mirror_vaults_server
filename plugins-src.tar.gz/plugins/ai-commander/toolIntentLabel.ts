import i18n from 'i18next';

const EXT_RE = /\.\w{1,5}$/;
function stripExt(name: string): string {
  return name.replace(EXT_RE, '');
}

// Sub-agent 結構化事件 → 前端顯示文字
export function resolveSubAgentIntent(data: Record<string, any>): string {
  const t = i18n.t.bind(i18n);

  if (data.step) {
    switch (data.step) {
      case 'forge_init':      return t('forgeInit');
      case 'forge_compile':   return t('forgeCompile');
      case 'forge_register':  return t('forgeRegister');
      case 'forge_heartbeat': return '';
      default:                return data.step;
    }
  }

  const toolName: string = data.tool_name || '';
  return getCliToolLabel(toolName, data);
}

// CLI 工具名稱 + input 參數 → 前端顯示文字（main agent / sub-agent 共用）
export function getCliToolLabel(toolName: string, params: Record<string, any>): string {
  const t = i18n.t.bind(i18n);
  const rawName = params.file_name || params.file_path?.split('/').pop() || '';
  const fileName = stripExt(rawName);
  switch (toolName) {
    case 'Read':
      return fileName ? t('cliRead', { name: fileName }) : t('cliReadGeneric');
    case 'Write':
      return fileName ? t('cliWrite', { name: fileName }) : t('cliWriteGeneric');
    case 'Edit':
    case 'MultiEdit':
      return fileName ? t('cliEdit', { name: fileName }) : t('cliEditGeneric');
    case 'Bash': {
      if (params.description) return stripExt(params.description);
      if (params.command) return stripExt(params.command.substring(0, 60));
      return t('cliBashGeneric');
    }
    case 'Glob':
      return params.pattern ? t('cliGlob', { pattern: params.pattern }) : t('cliGlobGeneric');
    case 'Grep':
      return params.pattern ? t('cliGrep', { pattern: params.pattern }) : t('cliGrepGeneric');
    case 'ToolSearch':
      return t('cliToolSearch');
    default:
      return toolName;
  }
}
