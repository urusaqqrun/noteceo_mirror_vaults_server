import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout } from '../../../hooks/useTimeout';
import './AutoTaskRoom.css';
import { useCommandManager } from '../../../Store/commandManager';

import { eventBus } from '../../../Store/eventBus';
import TaskEditor from './TaskEditor';
import AgentDetailPanel from './AgentDetailPanel';
import CEOTaskNotificationList from './CEOTaskNotificationList';
import AICommanderChatRoom from '../ai-commander/AICommanderChatRoom';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import AddTaskTemplateDialog from './AddTaskTemplateDialog';
import BreathingDot from '../../common/BreathingDot';
import BellIconN from '../../../assets/icon_bell_24.svg?react';
import MenuIcon from '../../../assets/icon_menu_24.svg?react';
import PlayIcon from '../../../assets/bk_icon_play_26_n.svg?react';
import StopIcon from '../../../assets/bk_icon_stop_26_n.svg?react';
import BackIcon from '../../../assets/icon_arrow_left_24.svg?react';
import EditIcon from '../../../assets/icon_edit_24.svg?react';
import MobileTopbar from '../../common/MobileTopbar';
import { useTheme } from '../../setting/ThemeProvider';
import { useItemStore } from '../../../Store/itemStore';
import { useAgentStore, useAgentReportStore, Agent, AgentReport } from './autoTaskStore';
import { useAICommanderStore } from '../ai-commander/aiStore';
import { useChatBotSessionsStore } from '../ai-commander/chatStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore, useMobileSidebarStore } from '../../../Store/uiStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import syncService from '../../../utils/syncService';

// 穩定空陣列，避免 useItemStore 的 ?? [] 在 undefined 時回傳新參考導致無限重渲染
const EMPTY_ARR: any[] = [];

const AutoTaskRoom = ({ initialAgentIdFromDialog = null }) => {
  const { t } = useTranslation();

  // 安全定時器 hook - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();

  const theme = useTheme();

  const setTempHint = useTempHintStore(state => state.setTempHint);
  const isMobileView = useIsMobileView();
  const setIsMobileSidebarOpen = useMobileSidebarStore(state => state.setIsMobileSidebarOpen);

  // AutoTaskRoom — 從 navParams 獲取初始導航參數（一次性消費）
  const navParams = useSelectedItemsStore(state => state.navParams);
  const clearNavParams = useSelectedItemsStore(state => state.clearNavParams);
  const storeInitialAgentId = (navParams.initialAgentId as string | null) ?? null;
  const initialAgentId = initialAgentIdFromDialog || storeInitialAgentId;
  const initialTaskReportId = (navParams.initialTaskReportId as string | null) ?? null;
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
  const storedSelectedAgentId = initialAgentId;
  const storedSelectedReportId = initialTaskReportId;

  const taskItems = useItemStore(s => s.byType['AGENT'] ?? EMPTY_ARR);
  const reportItems = useItemStore(s => s.byType['AGENT_REPORT'] ?? EMPTY_ARR);
  const agents = useMemo(() => taskItems as Agent[], [taskItems]);
  const reports = useMemo(() => reportItems as AgentReport[], [reportItems]);
  const addAgent = useAgentStore(state => state.addAgent);
  const updateAgent = useAgentStore(state => state.updateAgent);
  const deleteAgent = useAgentStore(state => state.deleteAgent);
  const markReportAsRead = useAgentReportStore(state => state.markReportAsRead);
  const reorderAgents = useAgentStore(state => state.reorderAgents);

  const chatRoomRef = useRef(null);
  const abortControllerRef = useRef(null);
  const reportListScrollRef = useRef(null); // Report List 滾動容器的 ref
  const reportListScrollTopRef = useRef(0); // 記錄 Report List 的滾動位置
  const taskEditorRef = useRef(null); // Mobile 編輯面板的 TaskEditor ref

  // 從 AI Store 獲取所有任務
  const allAgents = useMemo(() => {
    return agents;
  }, [agents]);

  const allAgentReports = useMemo(() => {
    return reports;
  }, [reports]);

  const getInitialAgent = () => {
    if (storedSelectedAgentId) {
      const agent = allAgents.find(a => a.id === storedSelectedAgentId);
      if (agent) return agent;
    }
    if (isMobileView) return null;
    return allAgents[0] || null;
  };

  const getInitialReport = () => {
    if (storedSelectedReportId) {
      const report = allAgentReports.find(r => r.id === storedSelectedReportId);
      if (report) return report;
    }
    return null;
  };

  const [selectedAgent, setSelectedAgentState] = useState(getInitialAgent);
  const [selectedNotification, setSelectedNotificationState] = useState(getInitialReport);

  // 頁面切換動畫用
  const [animationState, setAnimationState] = useState('idle'); // 'idle', 'entering', 'exiting'
  const [navigationDirection, setNavigationDirection] = useState('forward'); // 'forward', 'backward'

  // Mobile 編輯 Panel 狀態
  const [showMobileEditPanel, setShowMobileEditPanel] = useState(false);
  const [mobileEditMode, setMobileEditMode] = useState('edit'); // 'edit' | 'create'
  const [pendingTask, setPendingTask] = useState(null); // create 模式下的臨時任務
  // Mobile Chat Room Panel 狀態
  const [showMobileChatPanel, setShowMobileChatPanel] = useState(false);
  const [mobileChatSessionId, setMobileChatSessionId] = useState(null);

  const setSelectedAgent = useCallback((agent) => {
    setSelectedAgentState(agent);
  }, []);

  const setSelectedNotification = useCallback((notification) => {
    setSelectedNotificationState(notification);
  }, []);
  const [taskRightClickMenu, setTaskRightClickMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    agentId: null
  });

  // 拖曳狀態
  const [draggedTaskId, setDraggedTaskId] = useState(null);
  const [dragOverTaskId, setDragOverTaskId] = useState(null);
  const [dragPosition, setDragPosition] = useState(null); // 'above' 或 'below'

  // 類別選擇 Dialog 狀態
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);

  // Task Report Store（統一使用 useChatBotSessionsStore）
  const taskStore = useChatBotSessionsStore();
  // 直接訂閱 executingReports 以確保響應式更新
  const executingReports = useChatBotSessionsStore(state => state.executingReports);
  const [reloadKey, setReloadKey] = useState(0);
  useEffect(() => {
    const unsub = eventBus.on('editor:force-reload', () => setReloadKey(k => k + 1));
    return unsub;
  }, []);

  // EventBus: 任務拖到 AICommander 的 drop handler
  useEffect(() => {
    const unsub = eventBus.on('drop:ai-commander:autoTask', (e: any, addAttachment: any, attachedItems: any, inputAreaRef: any) => {
      const taskData = e.dataTransfer.getData('application/cubelv-task');
      if (!taskData) return;
      try {
        const task = JSON.parse(taskData);
        if (!attachedItems.some((item: any) => item.id === task.id && item.type === 'task')) {
          addAttachment(task);
          if (inputAreaRef.current?.closeSaveMode) {
            inputAreaRef.current.closeSaveMode();
          }
        }
      } catch (error) {
        console.error('解析任務資料失敗:', error);
      }
    });
    return unsub;
  }, []);

  const currentExecutingReport = selectedAgent ? executingReports[selectedAgent.id] : null;
  useEffect(() => {
    if (!selectedAgent) {
      setSelectedNotification(null);
      return;
    }

    if (currentExecutingReport) {
      setSelectedNotification(currentExecutingReport);
    } else {
      if (selectedNotification?.type === 'Executing') {
        const completedReport = allAgentReports.find(r => r.id === selectedNotification.id);
        if (completedReport) {
          setSelectedNotification(completedReport);
        }
      }
    }
  }, [selectedAgent?.id, currentExecutingReport, allAgentReports]);

  useEffect(() => {
    if (allAgents.length && !selectedAgent) {
      if (!isMobileView) {
        setSelectedAgent(allAgents[0]);
      }
    } else if (selectedAgent) {
      const updated = allAgents.find(a => a.id === selectedAgent.id);
      if (updated) {
        if (updated.updatedAt !== selectedAgent.updatedAt) {
          setSelectedAgent(updated);
        }
      } else if (allAgents.length) {
        if (!isMobileView) {
          setSelectedAgent(allAgents[0]);
        } else {
          setSelectedAgent(null);
        }
      } else {
        setSelectedAgent(null);
      }
    }
  }, [allAgents, isMobileView]);

  useEffect(() => {
    if (selectedAgent) {
      const updated = allAgents.find(a => a.id === selectedAgent.id);
      if (updated) setSelectedAgent(updated);
    }
  }, [reloadKey]);

  // 記錄是否已經執行過滾動
  const hasScrolledTaskRef = useRef(false);
  const hasScrolledReportRef = useRef(false);

  // 滾動到指定元素的輔助函數
  const scrollToElement = useCallback((element) => {
    if (!element) return;
    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, []);

  useEffect(() => {
    if (!allAgents.length || !initialAgentId || hasScrolledTaskRef.current) return;

    const target = allAgents.find(a => a.id === initialAgentId);
    if (target) {
      hasScrolledTaskRef.current = true;
      setSelectedAgent(target);
      safeSetTimeout(() => {
        const taskColumn = document.querySelector('.ai-admin-column-list');
        const taskElement = taskColumn?.querySelector(`[data-task-id="${initialAgentId}"]`);
        scrollToElement(taskElement);
      }, 50);
      clearNavParams();
    }
  }, [allAgents, initialAgentId, scrollToElement, clearNavParams]);

  useEffect(() => {
    if (!initialTaskReportId || !selectedAgent || !allAgentReports.length || hasScrolledReportRef.current) return;

    const targetReport = allAgentReports.find(r => r.id === initialTaskReportId);

    if (targetReport) {
      hasScrolledReportRef.current = true;
      setSelectedNotification(targetReport);
      safeSetTimeout(() => {
        const reportColumn = document.querySelector('.ai-admin-column-report');
        const reportElement = reportColumn?.querySelector(`[data-report-id="${initialTaskReportId}"]`);
        scrollToElement(reportElement);
      }, 50);
    }
  }, [initialTaskReportId, selectedAgent, allAgentReports, scrollToElement]);

  // Escape — commandManager 統一管理（清除選中的報告）
  useEffect(() => {
    if (!selectedNotification) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'auto-task-room:escape',
        name: t('cmd.clearSelectedNotification'),
        callback: () => setSelectedNotification(null),
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [selectedNotification, selectedAgent]);

  useEffect(() => {
    if (selectedNotification && selectedNotification.isRead === false) {
      markReportAsRead(selectedNotification.id);
    }
  }, [selectedNotification?.id]);

  const closeTaskRightClickMenu = () => {
    setTaskRightClickMenu({
      visible: false,
      x: 0,
      y: 0,
      agentId: null
    });
  };

  // 處理右鍵選單的關閉
  useEffect(() => {
    const handleOutsideInteraction = (e) => {
      if (!taskRightClickMenu.visible) return;
      const menuEl = document.querySelector('.popup-menu');
      if (menuEl && menuEl.contains(e.target)) return;
      closeTaskRightClickMenu();
    };

    document.addEventListener('click', handleOutsideInteraction, true);
    document.addEventListener('contextmenu', handleOutsideInteraction, true);

    return () => {
      document.removeEventListener('click', handleOutsideInteraction, true);
      document.removeEventListener('contextmenu', handleOutsideInteraction, true);
    };
  }, [taskRightClickMenu.visible]);

  const normalizeAgent = useCallback((agent, previous) => {
    return {
      id: agent.id || previous?.id || generateObjectID(),
      parentID: agent.parentID || null,
      name: agent.name ?? previous?.name ?? t('newTask'),
      content: agent.content ?? previous?.content ?? '',
      icon: agent.icon ?? previous?.icon ?? '',
      model: agent.model ?? previous?.model ?? '',
      runPolicies: agent?.runPolicies ?? previous?.runPolicies ?? [],
      status: agent.status ?? previous?.status ?? 'active',
      isOpenPush: typeof agent.isOpenPush === 'boolean' ? agent.isOpenPush : (typeof previous?.isOpenPush === 'boolean' ? previous.isOpenPush : false),
      attachedItems: agent.attachedItems ?? previous?.attachedItems ?? [],
      budgetMonthly: agent.budgetMonthly ?? previous?.budgetMonthly ?? null,
      budgetSpent: agent.budgetSpent ?? previous?.budgetSpent ?? 0,
      lastRunAt: agent.lastRunAt ?? previous?.lastRunAt ?? '',
    };
  }, [t]);

  const handleAgentSave = async (updatedAgent) => {
    if (!updatedAgent) return;
    const normalized = normalizeAgent(updatedAgent, allAgents.find(a => a.id === updatedAgent.id));
    await updateAgent(normalized.id, normalized);
    setSelectedAgent(normalized);
    syncService.syncChanges();
  };

  // 處理 Report 點擊 - Mobile 下彈出 Panel，Desktop 下進入 Chat Room
  const handleNotificationClick = async (notification) => {

    if (isMobileView) {
      // Mobile: 彈出 Chat Room Panel
      setMobileChatSessionId(notification.id);
      setShowMobileChatPanel(true);
      // Mobile 需要手動標記已讀（Desktop 是透過 selectedNotification 的 useEffect 觸發）
      if (notification.isRead === false) {
        markReportAsRead(notification.id);
      }
    } else {
      // Desktop: 使用原有的頁面切換動畫
      // 記錄 Report List 的滾動位置
      if (reportListScrollRef.current) {
        reportListScrollTopRef.current = reportListScrollRef.current.scrollTop;
      }

      // 向前導航動畫
      setNavigationDirection('forward');
      setAnimationState('exiting');

      // 等待退出動畫完成後再切換
      safeSetTimeout(() => {
        setSelectedNotification(notification);
        setAnimationState('entering');

        // 動畫完成後恢復到閒置狀態
        safeSetTimeout(() => {
          setAnimationState('idle');
        }, 300);
      }, 300);
    }
  };

  // 處理返回 Report List（向後導航）
  const handleBackToReportList = () => {
    // 向後導航動畫
    setNavigationDirection('backward');
    setAnimationState('exiting');

    // 等待退出動畫完成後再切換
    safeSetTimeout(() => {
      setSelectedNotification(null);
      setAnimationState('entering');

      // 恢復 Report List 的滾動位置
      safeSetTimeout(() => {
        if (reportListScrollRef.current) {
          reportListScrollRef.current.scrollTop = reportListScrollTopRef.current;
        }
      }, 0);

      // 動畫完成後恢復到閒置狀態
      safeSetTimeout(() => {
        setAnimationState('idle');
      }, 300);
    }, 300);
  };

  const markCurrentAgentReportsAsRead = async (agentId) => {
    if (!agentId) return;
    const unread = allAgentReports.filter(r => r.agentId === agentId && r.isRead === false);
    for (const report of unread) {
      await markReportAsRead(report.id);
    }
  };

  const handleAgentSwitch = async (newAgent) => {
    if (selectedAgent?.id && selectedAgent.id !== newAgent?.id) {
      await markCurrentAgentReportsAsRead(selectedAgent.id);
    }
    setSelectedAgent(newAgent);
    setSelectedNotification(null);
  };

  const handleRunAgent = (e) => {
    if (e) e.stopPropagation();
    if (!selectedAgent) return;

    const existingExecutingReport = executingReports[selectedAgent.id];
    if (existingExecutingReport) return;

    const newSessionId = generateObjectID();

    const agentAsAttachedItem = {
      id: selectedAgent.id,
      type: 'agent',
      title: selectedAgent.name || t('untitledTask'),
      content: selectedAgent.content || '',
      parentID: selectedAgent.parentID,
      model: selectedAgent.model || '',
      runPolicies: selectedAgent.runPolicies || [],
      attachedItems: selectedAgent.attachedItems || []
    };

    const executingReport = {
      id: newSessionId,
      sessionID: newSessionId,
      agentId: selectedAgent.id,
      type: 'Executing',
      content: t('taskExecuting'),
      updatedAt: new Date().toISOString(),
      isRead: false
    };

    taskStore.setExecutingReport(selectedAgent.id, executingReport);
    setSelectedNotification(executingReport);

    if (isMobileView) {
      setMobileChatSessionId(executingReport.id);
      setShowMobileChatPanel(true);
    }

    const userMessage = {
      role: 'user',
      content: (selectedAgent.content || '').trim(),
      attachedItems: [agentAsAttachedItem]
    };
    taskStore.setMessages(newSessionId, [userMessage]);
    taskStore.setIsResponding(newSessionId, true);
    taskStore.setPendingUserMessage(newSessionId, userMessage);
  };

  const handleInterruptAgent = (e) => {
    if (e) e.stopPropagation();

    const executingReport = selectedAgent ? executingReports[selectedAgent.id] : null;
    if (!executingReport) return;

    if (chatRoomRef.current?.interruptStreaming) {
      chatRoomRef.current.interruptStreaming();
    }

    taskStore.setIsResponding(executingReport.id, false);
    taskStore.clearExecutingReport(selectedAgent.id);
    setSelectedNotification(null);
  };

  const handleDeleteAgent = async (agentId) => {
    await deleteAgent(agentId);
    if (selectedAgent?.id === agentId) {
      if (isMobileView) {
        setSelectedAgent(null);
      } else {
        setSelectedAgent(allAgents.filter(a => a.id !== agentId)[0] || null);
      }
    }
  };

  const handleAgentRightClick = (e, agentId) => {
    e.preventDefault();
    e.stopPropagation();
    setTaskRightClickMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      agentId
    });
  };

  const handleAddAgent = async () => {
    const newAgent = {
      id: generateObjectID(),
      parentID: null,
      name: '',
      content: '',
      runPolicies: [],
      status: 'active',
      isOpenPush: false,
      attachedItems: []
    };

    if (isMobileView) {
      setPendingTask(newAgent);
      setMobileEditMode('create');
      setShowMobileEditPanel(true);
    } else {
      await addAgent(newAgent);
      setSelectedAgent(newAgent);
      safeSetTimeout(() => {
        const taskColumn = document.querySelector('.ai-admin-column-list');
        const taskElement = taskColumn?.querySelector(`[data-task-id="${newAgent.id}"]`);
        scrollToElement(taskElement);
      }, 50);
    }
  };

  const handleAgentDragStart = (e, agentId) => {
    setDraggedTaskId(agentId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', agentId);
    e.dataTransfer.setData('sourceType', 'autoTask');

    const agent = allAgents.find(a => a.id === agentId);
    if (agent) {
      e.dataTransfer.setData('application/cubelv-task', JSON.stringify(agent));
    }

    // 添加拖曳中的視覺效果
    e.currentTarget.classList.add('ai-admin-task-dragging');



    eventBus.emit('drag:note-editor-drag-overlay', { icon: EditIcon, text: t('dragTaskToAttach') });
    eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: t('dragToAttach', '拖曳放置後附加') });
  };

  const handleAgentDragOver = (e, agentId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';

    if (!draggedTaskId || agentId === draggedTaskId) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const position = e.clientY < midY ? 'above' : 'below';

    setDragOverTaskId(agentId);
    setDragPosition(position);
  };

  const handleAgentDragLeave = (e) => {
    // 只有離開整個元素時才清除
    const relatedTarget = e.relatedTarget;
    if (!e.currentTarget.contains(relatedTarget)) {
      setDragOverTaskId(null);
      setDragPosition(null);
    }
  };

  const handleAgentDrop = async (e, targetTaskId) => {
    e.preventDefault();

    if (!draggedTaskId || !targetTaskId || draggedTaskId === targetTaskId) {
      setDraggedTaskId(null);
      setDragOverTaskId(null);
      setDragPosition(null);
      return;
    }

    const draggedIndex = allAgents.findIndex(a => a.id === draggedTaskId);
    const targetIndex = allAgents.findIndex(a => a.id === targetTaskId);

    if (draggedIndex === -1 || targetIndex === -1) {
      setDraggedTaskId(null);
      setDragOverTaskId(null);
      setDragPosition(null);
      return;
    }

    const newList = [...allAgents];
    const [draggedAgent] = newList.splice(draggedIndex, 1);

    // 計算插入位置
    let insertIndex = targetIndex;
    if (draggedIndex < targetIndex) {
      insertIndex = dragPosition === 'above' ? targetIndex - 1 : targetIndex;
    } else {
      insertIndex = dragPosition === 'above' ? targetIndex : targetIndex + 1;
    }

    newList.splice(insertIndex, 0, draggedAgent);

    await reorderAgents(newList);
    syncService.syncChanges();

    // 清除拖曳狀態
    setDraggedTaskId(null);
    setDragOverTaskId(null);
    setDragPosition(null);
  };

  const handleAgentDragEnd = (e) => {
    e.currentTarget.classList.remove('ai-admin-task-dragging');
    setDraggedTaskId(null);
    setDragOverTaskId(null);
    setDragPosition(null);


    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  };

  const handleToggleAgentStatus = async (e, agentId) => {
    e.stopPropagation();
    const agent = allAgents.find(a => a.id === agentId);
    if (!agent) return;

    const newStatus = agent.status === 'active' ? 'paused' : 'active';
    await updateAgent(agentId, { status: newStatus });

    if (selectedAgent?.id === agentId) {
      setSelectedAgent({ ...agent, status: newStatus });
    }
  };

  // 處理類別選擇確認
  const handleCategoryConfirm = (selectedCategories) => {

  };

  return (
    <div className="ai-admin-room">
      {/* 手機版頂部標題列 */}
      {isMobileView && (
        <MobileTopbar
          leftIcon={selectedAgent ? 'back' : 'menu'}
          onLeftClick={() => selectedAgent ? setSelectedAgent(null) : setIsMobileSidebarOpen(true)}
          title={selectedAgent ? (selectedAgent.name?.trim() ? selectedAgent.name : t('untitledTask')) : t('autoTaskRoom')}
          rightContent={
            <>
              <button
                className="ai-admin-outline-btn ai-admin-mobile-template-btn"
                onClick={() => setShowCategoryDialog(true)}
              >
                <span>{t('addTemplate')}</span>
              </button>
              {selectedAgent && (
                <button
                  className="mobile-topbar-button"
                  onClick={() => {
                    setMobileEditMode('edit');
                    setShowMobileEditPanel(true);
                  }}
                >
                  <EditIcon />
                </button>
              )}
            </>
          }
        />
      )}

      {/* 桌面版 Header */}
      {!isMobileView && (
        <div className="ai-admin-room-header">
          <div className="ai-admin-room-title-container">
            <h2 className="ai-admin-room-main-title">{t('automatedTaskManagement')}</h2>
            <div className="ai-admin-room-subtitle">{t('autoTaskSubtitle')}</div>
          </div>
          <div className="ai-admin-room-actions">
            <button
              className="ai-admin-outline-btn"
              tabIndex={-1}
              onClick={() => setShowCategoryDialog(true)}
            >
              <span>{t('addTemplate')}</span>
            </button>

          </div>
        </div>
      )}

      {/* Body */}
      <div className="ai-admin-room-body">
        {(!isMobileView || !selectedAgent) && (
          <div className="ai-admin-column ai-admin-column-list">
            <div className="ai-admin-column-content">
              {allAgents.map(agent => {
                const hasUnreadReport = allAgentReports.some(r => r.agentId === agent.id && r.isRead === false);
                return (
                  <div
                    key={agent.id}
                    data-task-id={agent.id}
                    className={`ai-admin-task-item ${selectedAgent?.id === agent.id ? 'selected' : ''} ${draggedTaskId === agent.id ? 'ai-admin-task-dragging' : ''} ${dragOverTaskId === agent.id ? `ai-admin-task-drag-over ai-admin-task-drag-${dragPosition}` : ''}`}
                    draggable
                    onDragStart={(e) => handleAgentDragStart(e, agent.id)}
                    onDragOver={(e) => handleAgentDragOver(e, agent.id)}
                    onDragLeave={handleAgentDragLeave}
                    onDrop={(e) => handleAgentDrop(e, agent.id)}
                    onDragEnd={handleAgentDragEnd}
                    onClick={() => handleAgentSwitch(agent)}
                    onContextMenu={(e) => handleAgentRightClick(e, agent.id)}
                  >
                    {hasUnreadReport && <BreathingDot className="ai-admin-task-unread-dot" />}
                    <div className="ai-admin-task-content">
                      <div className="ai-admin-task-name">
                        {agent.name?.trim() ? agent.name : t('untitledTask')}
                      </div>
                      <div className="ai-admin-task-meta">
                        {agent.runPolicies && agent.runPolicies.length > 0 ? (
                          <span className="ai-admin-task-tag">
                            <BellIconN />
                            {`${agent.runPolicies.length} rules`}
                          </span>
                        ) : (
                          <span className="ai-admin-task-tag inactive">
                            <BellIconN />
                            {t('noPeriod')}
                          </span>
                        )}
                      </div>
                    </div>
                    {executingReports[agent.id] ? (
                      <div className="task-item-loader" />
                    ) : (
                      agent.runPolicies && agent.runPolicies.length > 0 && (
                        <div
                          className={`mock-task-toggle ${agent.status === 'active' ? 'active' : ''}`}
                          onClick={(e) => handleToggleAgentStatus(e, agent.id)}
                        >
                          <div className="mock-task-toggle-track" />
                          <div className="mock-task-toggle-thumb" />
                        </div>
                      )
                    )}
                  </div>
                );
              })}

              <button
                className="ai-admin-add-btn"
                onClick={handleAddAgent}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                <span>{t('addTask')}</span>
              </button>
            </div>
          </div>
        )}

        {!isMobileView && (
          <div className="ai-admin-column ai-admin-column-editor">
            <div className="ai-admin-column-content" style={{ padding: 0, position: 'relative' }}>
              {selectedAgent ? (
                <AgentDetailPanel
                  agent={selectedAgent}
                  reports={allAgentReports}
                  onSave={handleAgentSave}
                  onRun={() => handleRunAgent(null)}
                  onInterrupt={() => handleInterruptAgent(null)}
                  isExecuting={!!executingReports[selectedAgent.id]}
                  reloadKey={reloadKey}
                />
              ) : (
                <div className="ai-admin-empty-state">{t('selectTask')}</div>
              )}
            </div>
          </div>
        )}

        {selectedAgent && (
          <div className="ai-admin-column ai-admin-column-report-or-room">
            <div className="ai-admin-column-content" style={{ padding: 0 }}>
              {/* Mobile 下只顯示 Report List，Desktop 下可切換 */}
              <div className={`ai-admin-report-room-wrapper ${!isMobileView ? `${animationState} ${navigationDirection}` : ''}`}>
                {(!isMobileView && selectedNotification) ? (
                  // Desktop: 顯示 Chat Room（帶返回鍵）
                  <AICommanderChatRoom
                    ref={chatRoomRef}
                    sessionID={selectedNotification.id}
                    abortControllerRef={abortControllerRef}
                    mode="task"
                    onBack={handleBackToReportList}
                  />
                ) : (
                  // Mobile & Desktop (無選中 notification): 顯示 Report List
                  <CEOTaskNotificationList
                    ref={reportListScrollRef}
                    onNotificationClick={handleNotificationClick}
                    selectedId={selectedNotification?.id}
                    selectedTaskId={selectedAgent?.id}
                    executingTask={executingReports[selectedAgent.id]}
                  />
                )}
              </div>
            </div>

            {/* Mobile 浮動按鈕 - 執行/暫停 - 只在 Report List 顯示，進入 Room 後隱藏 */}
            {isMobileView && !showMobileChatPanel && (
              <button
                className="ai-admin-mobile-fab"
                onClick={!!executingReports[selectedAgent.id] ? handleInterruptAgent : handleRunAgent}
              >
                {!!executingReports[selectedAgent.id] ? <StopIcon /> : <PlayIcon />}
              </button>
            )}
          </div>
        )}
      </div>

      {taskRightClickMenu.visible && (
        <PopupMenu x={taskRightClickMenu.x} y={taskRightClickMenu.y} onClose={closeTaskRightClickMenu}>
          <PopupMenuItem danger onClick={() => { handleDeleteAgent(taskRightClickMenu.agentId); closeTaskRightClickMenu(); }}>
            {t('deleteTask')}
          </PopupMenuItem>
        </PopupMenu>
      )}

      {isMobileView && showMobileEditPanel && (mobileEditMode === 'create' ? pendingTask : selectedAgent) && (
        <div className="ai-admin-mobile-edit-overlay" onClick={() => {
          if (mobileEditMode === 'create') setPendingTask(null);
          setShowMobileEditPanel(false);
        }}>
          <div className="ai-admin-mobile-edit-panel" onClick={(e) => e.stopPropagation()}>
            <TaskEditor
              ref={taskEditorRef}
              key={`mobile-${mobileEditMode === 'create' ? pendingTask?.id : selectedAgent?.id}-${reloadKey}`}
              task={mobileEditMode === 'create' ? pendingTask : selectedAgent}
              onDelete={mobileEditMode === 'edit' ? () => {
                handleDeleteAgent(selectedAgent.id);
                setShowMobileEditPanel(false);
              } : undefined}
              className="mobile-task-editor"
              autoSave={false}
            />
            <div className="ai-admin-mobile-edit-footer">
              <button
                className="custom-secondary-button"
                onClick={() => {
                  if (mobileEditMode === 'create') setPendingTask(null);
                  setShowMobileEditPanel(false);
                }}
              >
                {t('cancel')}
              </button>
              <button
                className="custom-primary-button"
                onClick={async () => {
                  const agentData = taskEditorRef.current?.getCurrentTaskData();
                  if (!agentData) return;

                  if (mobileEditMode === 'create') {
                    const normalized = normalizeAgent(agentData, null);
                    await addAgent(normalized);
                    setSelectedAgent(normalized);
                    setPendingTask(null);
                  } else {
                    await handleAgentSave(agentData);
                  }
                  setShowMobileEditPanel(false);
                }}
              >
                {t('confirm')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Chat Room Panel */}
      {isMobileView && showMobileChatPanel && mobileChatSessionId && (
        <div className="ai-admin-mobile-chat-overlay" onClick={() => setShowMobileChatPanel(false)}>
          <div className="ai-admin-mobile-chat-panel" onClick={(e) => e.stopPropagation()}>
            <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              <AICommanderChatRoom
                ref={chatRoomRef}
                sessionID={mobileChatSessionId}
                abortControllerRef={abortControllerRef}
                mode="task"
                onBack={() => setShowMobileChatPanel(false)}
              />
            </div>
          </div>
        </div>
      )}

      {/* 類別選擇 Dialog */}
      {showCategoryDialog && (
        <AddTaskTemplateDialog
          onClose={() => setShowCategoryDialog(false)}
          onConfirm={handleCategoryConfirm}
        />
      )}
    </div>
  );
};

export default AutoTaskRoom;
