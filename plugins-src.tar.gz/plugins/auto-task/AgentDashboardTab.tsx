import React from 'react';
import { useTranslation } from 'react-i18next';
import './AgentDashboardTab.css';
import type { Agent, AgentReport } from './autoTaskStore';

interface AgentDashboardTabProps {
  agent: Agent;
  reports: AgentReport[];
}

const AgentDashboardTab = ({ agent, reports }: AgentDashboardTabProps) => {
  const { t } = useTranslation();

  const sortedReports = [...reports]
    .sort((a, b) => new Date(b.updatedAt as string).getTime() - new Date(a.updatedAt as string).getTime())
    .slice(0, 10);

  const statusLabel = agent.status === 'active' ? t('statusActive') : agent.status === 'paused' ? t('statusPaused') : t('statusError');
  const statusClass = agent.status === 'active' ? 'active' : agent.status === 'paused' ? 'paused' : 'error';

  return (
    <div className="agent-dashboard-tab">
      <div className="agent-dashboard-cards">
        <div className="agent-dashboard-card">
          <div className="agent-dashboard-card-label">{t('statusLabel')}</div>
          <div className={`agent-dashboard-card-value status-${statusClass}`}>{statusLabel}</div>
        </div>
        <div className="agent-dashboard-card">
          <div className="agent-dashboard-card-label">{t('lastRunAt')}</div>
          <div className="agent-dashboard-card-value">
            {agent.lastRunAt ? new Date(agent.lastRunAt).toLocaleString() : t('neverRun')}
          </div>
        </div>
        <div className="agent-dashboard-card">
          <div className="agent-dashboard-card-label">{t('totalReports')}</div>
          <div className="agent-dashboard-card-value">{reports.length}</div>
        </div>
      </div>

      <div className="agent-dashboard-section">
        <div className="agent-dashboard-section-title">{t('recentReports')}</div>
        {sortedReports.length === 0 ? (
          <div className="agent-dashboard-empty">{t('noTaskReportsYet')}</div>
        ) : (
          <div className="agent-dashboard-report-list">
            {sortedReports.map(report => (
              <div key={report.id} className="agent-dashboard-report-item">
                <div className="agent-dashboard-report-time">
                  {new Date(report.updatedAt as string).toLocaleString()}
                </div>
                <div className="agent-dashboard-report-content">
                  {(report.content || '').slice(0, 100)}
                  {(report.content || '').length > 100 ? '...' : ''}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AgentDashboardTab;
