import React, { useMemo, useState, useEffect, useRef, forwardRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import './CEOTaskNotificationList.css';
import CustomScrollbar from '../../common/CustomScrollbar';
import BreathingDot from '../../common/BreathingDot';
import { useItemStore } from '../../../Store/itemStore';
import { useAgentReportStore, Agent, AgentReport } from './autoTaskStore';
import { getWorkspace } from '../../../workspace/Workspace';
import { formatTimestamp } from '../../Utils/dateFormat';
import ChatMessageAssistant from '../ai-commander/ChatMessageAssistant';

// 穩定空陣列，避免 useItemStore 的 ?? [] 在 undefined 時回傳新參考導致無限重渲染
const EMPTY_ARR: any[] = [];

interface CEOTaskNotificationListProps {
  onNotificationClick?: (notification: any) => void | Promise<void>;
  selectedId?: string | null;
  selectedFolderId?: string | null;
  selectedTaskId?: string | null;
  executingTask?: any | null;
}

const CEOTaskNotificationList = forwardRef<any, CEOTaskNotificationListProps>(({ onNotificationClick, selectedId, selectedFolderId, selectedTaskId, executingTask }, ref) => {
  const { t } = useTranslation();
  const folderCacheRef = useRef<Map<string, any>>(new Map());
  const scrollRef = useRef(null);

  // 暴露滾動容器給父組件
  React.useImperativeHandle(ref, () => scrollRef.current);

  const taskItems = useItemStore(s => s.byType['AGENT'] ?? EMPTY_ARR);
  const reportItems = useItemStore(s => s.byType['AGENT_REPORT'] ?? EMPTY_ARR);
  const agents = useMemo(() => taskItems as Agent[], [taskItems]);
  const reports = useMemo(() => reportItems as AgentReport[], [reportItems]);
  const deleteReport = useAgentReportStore(state => state.deleteReport);

  // 右鍵選單狀態
  const [contextMenu, setContextMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    reportId: null
  });

  // 統一處理連結點擊
  const handleNavigate = useCallback(({ type, id }: { type: string; id: string }) => {
    const typeMap: Record<string, string> = { note: 'NOTE', todo: 'NOTE', card: 'CARD', chart: 'CHART' };
    const itemType = typeMap[type];
    if (itemType) getWorkspace()?.openWindow({ id, itemType });
  }, []);

  // 關閉右鍵選單
  const closeContextMenu = () => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0,
      reportId: null
    });
  };

  // 處理右鍵選單的關閉（點擊外部時）
  useEffect(() => {
    const handleOutsideInteraction = (e) => {
      if (!contextMenu.visible) return;
      const menuEl = document.querySelector('.ceo-task-report-context-menu');
      if (menuEl && menuEl.contains(e.target)) return;
      closeContextMenu();
    };

    document.addEventListener('click', handleOutsideInteraction, true);
    document.addEventListener('contextmenu', handleOutsideInteraction, true);

    return () => {
      document.removeEventListener('click', handleOutsideInteraction, true);
      document.removeEventListener('contextmenu', handleOutsideInteraction, true);
    };
  }, [contextMenu.visible]);

  // 右鍵點擊處理
  const handleReportRightClick = (e, reportId) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      reportId
    });
  };

  const handleDeleteReport = async () => {
    if (contextMenu.reportId) {
      await deleteReport(contextMenu.reportId);
    }
    closeContextMenu();
  };

  const agentsMap = useMemo(() => {
    const map = {};
    agents.forEach(agent => {
      map[agent.id] = agent;
    });
    return map;
  }, [agents]);

  const sortedReports = useMemo(() => {
    let allReports = [...reports];

    if (selectedFolderId) {
      const agentIdsInFolder = agents
        .filter(a => a.parentID === selectedFolderId)
        .map(a => a.id);
      allReports = allReports.filter(r => agentIdsInFolder.includes(r.agentId));
    }

    if (selectedTaskId) {
      allReports = allReports.filter(r => r.agentId === selectedTaskId);
    }

    // 排序：NeedSelection/NeedInput 優先，Completed/Failed 其次，各組按 updatedAt 由新到舊
    const highPriority = allReports.filter(r => r.type === 'NeedSelection' || r.type === 'NeedInput');
    const lowPriority = allReports.filter(r => r.type === 'Completed' || r.type === 'Failed');

    const parseTime = (t) => typeof t === 'string' && /^\d+$/.test(t) ? parseInt(t, 10) : new Date(t).getTime();
    const sortByUpdatedAt = (a, b) => parseTime(b.updatedAt) - parseTime(a.updatedAt);
    highPriority.sort(sortByUpdatedAt);
    lowPriority.sort(sortByUpdatedAt);

    return [...highPriority, ...lowPriority];
  }, [reports, agents, selectedFolderId, selectedTaskId]);

  const getAgent = (agentId) => agentsMap[agentId] || null;

  // folder name 快取 + 非同步載入
  const [folderNames, setFolderNames] = useState<Map<string, string>>(new Map());

  const fetchFolderName = useCallback(async (folderId: string) => {
    if (!folderId || folderCacheRef.current.has(folderId)) return;
    folderCacheRef.current.set(folderId, '');
    const item = await window.electronAPI!.getItem(folderId);
    if (!item) return;
    const specialNames = { inbox: t('inbox'), todoInbox: t('todoInbox'), trash: t('trash') };
    const displayName = specialNames[item.name] || item.name || '';
    folderCacheRef.current.set(folderId, displayName);
    setFolderNames(new Map(folderCacheRef.current));
  }, [t]);

  useEffect(() => {
    agents.forEach(agent => {
      if (agent.parentID) fetchFolderName(agent.parentID);
    });
  }, [agents, fetchFolderName]);

  const getFolderDisplayName = (folderId) => folderNames.get(folderId) || '';

  // 判斷是否已完成（已讀且不需要操作）
  const isCompleted = (report) => {
    return report.isRead && (report.type === 'Completed' || report.type === 'Failed' || report.userAnswer !== null);
  };

  return (
    <div className="ceo-task-report-list">
      {/* 報告列表 */}
      <CustomScrollbar ref={scrollRef} offsetRight={4}>
        <div className="ceo-task-content-list">
          {/* 右鍵選單 */}
          {contextMenu.visible && (
            <div
              className="ceo-task-report-context-menu"
              style={{
                left: `${contextMenu.x}px`,
                top: `${contextMenu.y}px`
              }}
            >
              <div
                className="ceo-task-report-context-menu-item"
                onClick={handleDeleteReport}
              >
                {t('deleteNotification')}
              </div>
            </div>
          )}
          {!executingTask && sortedReports.length === 0 && (
            <div className="ceo-task-report-empty-hint">
              {t('noTaskReportsYet')}
            </div>
          )}

          {/* 執行中的任務（置頂顯示） */}
          {executingTask && (
            <div
              key={executingTask.id}
              className="ceo-task-report-item executing"
              onClick={() => onNotificationClick && onNotificationClick(executingTask)}
              style={{ cursor: onNotificationClick ? 'pointer' : 'default' }}
            >
              <div className="ceo-task-report-text">
                {/* 報告狀態：執行中 */}
                <div className="ceo-task-report-state">
                  <div className="ceo-task-report-icon executing" />
                  <span className="ceo-task-report-state-text">
                    {getAgent(executingTask.agentId)?.name || t('untitledTask')}
                  </span>
                </div>

                {/* 內容 */}
                <div className="ceo-task-report-content">
                  <ChatMessageAssistant content={executingTask.content || t('taskExecuting')} mode="task" onLinkClick={handleNavigate} />
                </div>

                {/* 執行中指示器 */}
                <div className="ceo-task-report-footer">
                  <span className="ceo-task-report-executing-indicator">
                    <span className="ceo-task-executing-dot" />
                    <span className="ceo-task-executing-dot" />
                    <span className="ceo-task-executing-dot" />
                  </span>
                </div>
              </div>
            </div>
          )}

          {sortedReports.map((report) => (
            <div
              key={report.id}
              data-report-id={report.id}
              className={`ceo-task-report-item ${isCompleted(report) ? 'completed' : ''}`}
              onClick={() => onNotificationClick && onNotificationClick(report)}
              onContextMenu={(e) => handleReportRightClick(e, report.id)}
              style={{ cursor: onNotificationClick ? 'pointer' : 'default' }}
            >
              {/* 未讀紅點 */}
              {report.isRead === false && (
                <BreathingDot className="ceo-task-report-unread-dot" />
              )}
              <div className="ceo-task-report-text">
                {/* 報告狀態：taskTitle */}
                <div className="ceo-task-report-state">
                  <div className="ceo-task-report-icon" />
                  <span className="ceo-task-report-state-text">
                    {getAgent(report.agentId)?.name || t('untitledTask')}
                    {getAgent(report.agentId)?.parentID && (
                      <span className="ceo-task-report-folder-hint">
                        {' → '}{getFolderDisplayName(getAgent(report.agentId)?.parentID)}
                      </span>
                    )}
                  </span>
                </div>

                {/* 內容 */}
                <div className="ceo-task-report-content">
                  <ChatMessageAssistant content={report.content} mode="task" onLinkClick={handleNavigate} />
                </div>

                {/* 日期 */}
                <div className="ceo-task-report-footer">
                  <span className="ceo-task-report-date">{formatTimestamp(report.updatedAt)}</span>
                </div>
              </div>

              {/* 控制按鈕 - 需要選擇（選擇題） */}
              {report.type === 'NeedSelection' && !isCompleted(report) && report.options && (
                <div className="ceo-task-report-controls selection">
                  {(Array.isArray(report.options) ? report.options : []).map((option, index) => (
                    <div
                      key={index}
                      className="ceo-task-control-option"
                      onClick={(e) => e.stopPropagation()}
                    >
                      {option}
                    </div>
                  ))}
                </div>
              )}

              {/* 控制按鈕 - 需要輸入回應 */}
              {report.type === 'NeedInput' && !isCompleted(report) && (
                <div className="ceo-task-report-controls response">
                  <textarea
                    className="ceo-task-response-field"
                    placeholder={t('responseField')}
                    onClick={(e) => e.stopPropagation()}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </CustomScrollbar>
    </div>
  );
});

export default CEOTaskNotificationList;
