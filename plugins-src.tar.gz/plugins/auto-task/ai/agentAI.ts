import { callPrompt, checkAndHandleCreditsError } from '../../../../aiService/promptClient';
import { iconRegistry } from '../../../common/IconRegistry';

const ICON_SELECT_SYSTEM = `You are an icon selection expert. Based on the given name, choose the most appropriate icon from the provided list. Output only the exact icon name, nothing else.`;

const ICON_SELECT_PROMPT = (name: string, iconNames: string[]) => {
  const formatted = iconNames.map((n, i) => `${i + 1}. ${n}`).join('\n');
  return `Name: ${name}\n\nAvailable icons:\n${formatted}\n\nSelected icon:`;
};

const categoryIconNames = Object.keys(iconRegistry).filter(k => !k.match(/^[A-Z]/));

export async function selectAgentIcon(agentName: string): Promise<string> {
  if (!agentName.trim()) return 'briefcase';

  try {
    const result = await callPrompt({
      action: 'agent_selectIcon',
      system_prompt: ICON_SELECT_SYSTEM,
      prompt: ICON_SELECT_PROMPT(agentName, categoryIconNames),
      model: 'gpt-4.1-nano',
      temperature: 0.3,
      max_tokens: 50,
    });

    const selected = result.content.trim();
    return categoryIconNames.includes(selected) ? selected : 'briefcase';
  } catch (error: any) {
    checkAndHandleCreditsError(error, true, 'selectAgentIcon');
    return 'briefcase';
  }
}
