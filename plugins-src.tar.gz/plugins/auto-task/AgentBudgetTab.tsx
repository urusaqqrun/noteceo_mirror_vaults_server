import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import './AgentBudgetTab.css';
import type { Agent } from './autoTaskStore';

interface AgentBudgetTabProps {
  agent: Agent;
  onSave: (agentData: any) => void;
}

const SOFT_ALERT_PERCENT = 80;

const AgentBudgetTab = ({ agent, onSave }: AgentBudgetTabProps) => {
  const { t } = useTranslation();

  const budget = agent.budgetMonthly ?? 0;
  const spent = agent.budgetSpent ?? 0;
  const remaining = Math.max(budget - spent, 0);
  const usedPercent = budget > 0 ? Math.min((spent / budget) * 100, 100) : 0;
  const remainingPercent = 100 - usedPercent;

  const [inputVal, setInputVal] = useState(budget > 0 ? budget.toFixed(2) : '');

  const handleUpdate = () => {
    const num = parseFloat(inputVal);
    if (!isNaN(num) && num >= 0) {
      onSave({ ...agent, budgetMonthly: num });
    }
  };

  return (
    <div className="agent-budget-tab">
      {/* Stats row */}
      <div className="budget-stats-row">
        <div className="budget-stat">
          <span className="budget-stat-label">{t('budgetObserved')}</span>
          <span className="budget-stat-value">${spent.toFixed(2)}</span>
          <span className="budget-stat-sub">
            {budget > 0 ? `${usedPercent.toFixed(0)}% ${t('budgetOfLimit')}` : t('noBudgetSet')}
          </span>
        </div>
        <div className="budget-stat">
          <span className="budget-stat-label">{t('budgetLabel')}</span>
          <span className="budget-stat-value">${budget.toFixed(2)}</span>
          <span className="budget-stat-sub">
            {t('budgetSoftAlert', { percent: SOFT_ALERT_PERCENT })}
          </span>
        </div>
      </div>

      {/* Remaining bar */}
      <div className="budget-remaining-section">
        <div className="budget-remaining-header">
          <span className="budget-remaining-label">{t('budgetRemaining')}</span>
          <span className="budget-remaining-value">${remaining.toFixed(2)}</span>
        </div>
        <div className="budget-bar-track">
          <div
            className={`budget-bar-fill ${usedPercent >= 100 ? 'over' : ''}`}
            style={{ width: `${remainingPercent}%` }}
          />
        </div>
      </div>

      {/* Input row */}
      <div className="budget-input-section">
        <span className="budget-input-label">{t('budgetInputLabel')}</span>
        <div className="budget-input-row">
          <input
            type="number"
            className="budget-input"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            placeholder="0.00"
            min="0"
            step="0.01"
          />
          <button className="budget-update-btn" onClick={handleUpdate}>
            {t('budgetUpdate')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AgentBudgetTab;
