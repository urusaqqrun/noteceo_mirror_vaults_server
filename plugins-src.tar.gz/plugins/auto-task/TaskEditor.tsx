
import React, { useState, useMemo, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { useTranslation } from 'react-i18next';
import './TaskEditor.css';
import '../../common/CustomSelect.css';
import '../../common/BasicComponents.css';
import '../ai-commander/AICommander.css';
import AttachedableEditor from '../ai-commander/AttachedableEditor';
import FolderTreeSelect from '../../common/FolderTreeSelect';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';
import NotebookFolderIcon from '../../../assets/icon_notebook_folder_24.svg?react';
import CardFolderIcon from '../../../assets/icon_card_folder_24.svg?react';
import { getIconByName } from '../../common/IconRegistry';
import type { TodoFolder } from '../todo/todoStore';
import { useItemStore } from '../../../Store/itemStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { availableModels, DEFAULT_MODEL } from '../../../aiService/modelConfig';
import type { RunRule, ScheduleRule, HookRule } from './autoTaskStore';

interface TaskEditorProps {
  task?: any | null;
  onSave?: ((taskData: any) => void) | null;
  onCancel?: (() => void) | null;
  onDelete?: (() => void) | null;
  onRun?: (() => void) | null;
  onInterrupt?: (() => void) | null;
  isExecuting?: boolean;
  className?: string;
  autoSave?: boolean;
}

const TaskEditor = forwardRef<any, TaskEditorProps>(({ task = null, onSave = null, onCancel = null, onDelete = null, onRun = null, onInterrupt = null, isExecuting = false, className = '', autoSave: enableAutoSave = true }, ref) => {
  const { t } = useTranslation();
  const isMobileView = useIsMobileView();
  const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('../note/noteStore').NoteFolder[];
  const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const cardFolders = useItemStore(s => s.byType['CARD_FOLDER'] ?? []);
  const chartFolders = useItemStore(s => s.byType['CHART_FOLDER'] ?? []);
  const folders = useMemo(() => [...noteFolders, ...todoFolders, ...cardFolders, ...chartFolders], [noteFolders, todoFolders, cardFolders, chartFolders]);
  const cardTypes = cardFolders;
  const chartTypes = chartFolders;

  const [title, setTitle] = useState(task?.name || '');
  const [content, setContent] = useState(task?.content || '');
  const [folderId, setFolderId] = useState(task?.parentID || '');
  const [runPolicies, setRunPolicies] = useState<RunRule[]>(task?.runPolicies || []);
  const [isOpenPush, setIsOpenPush] = useState(task?.isOpenPush ?? false);
  const [model, setModel] = useState(task?.model || DEFAULT_MODEL);
  const [showFolderDropdown, setShowFolderDropdown] = useState(false);
  const folderDropdownRef = useRef(null);

  const [showAddMenu, setShowAddMenu] = useState(false);
  const [addType, setAddType] = useState<'schedule' | 'hook' | null>(null);
  const [schedFreq, setSchedFreq] = useState<ScheduleRule['frequency']>('DAILY');
  const [schedRunAt, setSchedRunAt] = useState('');
  const [schedTime, setSchedTime] = useState('09:00');
  const [schedDaysOfWeek, setSchedDaysOfWeek] = useState<number[]>([]);
  const [schedDaysOfMonth, setSchedDaysOfMonth] = useState<number[]>([]);
  const [schedIntervalMs, setSchedIntervalMs] = useState(600000);
  const [hookTargetId, setHookTargetId] = useState('');
  const addMenuRef = useRef<HTMLDivElement>(null);

  // 渲染選中項目的顯示內容（帶 icon）
  const renderSelectedDisplay = () => {
    if (!folderId) return t('noTargetFolder');

    // 檢查是否是資料夾
    const folder = folders.find(f => f.id === folderId);
    if (folder) {
      const IconComponent = NotebookFolderIcon;
      return (
        <span className="task-editor-selected-item">
          {IconComponent && <IconComponent className="task-editor-selected-icon" />}
          <span>{(folder as any)?.name}</span>
        </span>
      );
    }

    // 檢查是否是 CardType ID（CARD 類型資料夾）
    const cardType = cardTypes.find(ct => ct.id === folderId);
    if (cardType) {
      const IconComponent = CardFolderIcon;
      const displayName = (cardType as any)?.name;
      return (
        <span className="task-editor-selected-item">
          {IconComponent && <IconComponent className="task-editor-selected-icon" />}
          <span>{displayName}</span>
        </span>
      );
    }

    // 檢查是否是 ChartType ID（CHART 類型資料夾）
    const chartType = chartTypes.find(ct => ct.id === folderId);
    if (chartType) {
      const ChartKindIcon = getIconByName((chartType as any)?.chartKind || (chartType as any)?.kind);
      const IconComponent = ChartKindIcon || CardFolderIcon;
      const displayName = (chartType as any)?.name;
      return (
        <span className="task-editor-selected-item">
          {IconComponent && <IconComponent className="task-editor-selected-icon" />}
          <span>{displayName}</span>
        </span>
      );
    }

    return t('noTargetFolder');
  };

  // 點擊外部關閉下拉框
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (folderDropdownRef.current && !folderDropdownRef.current.contains(event.target)) {
        setShowFolderDropdown(false);
      }
    };
    if (showFolderDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showFolderDropdown]);

  useEffect(() => {
    const handleClickOutsideMenu = (event) => {
      if (addMenuRef.current && !addMenuRef.current.contains(event.target)) {
        setShowAddMenu(false);
      }
    };
    if (showAddMenu) {
      document.addEventListener('mousedown', handleClickOutsideMenu);
    }
    return () => document.removeEventListener('mousedown', handleClickOutsideMenu);
  }, [showAddMenu]);

  const generateRuleId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  const getRuleLabel = (rule: RunRule): string => {
    if (rule.type === 'hook') {
      return `\u300C${rule.targetName || rule.targetId}\u300D${t('onVaultChange')}`;
    }
    const sr = rule as ScheduleRule;
    switch (sr.frequency) {
      case 'ONCE': {
        if (sr.runAt) {
          const display = sr.runAt.replace('T', ' ').substring(0, 16);
          return `${t('once')} ${display}`;
        }
        return t('once');
      }
      case 'DAILY':
        return `${t('daily')} ${sr.timeOfDay || ''}`;
      case 'WEEKLY': {
        const dayNames = (sr.daysOfWeek || []).map(d => t(`weekDay${d}`)).join('');
        return `${t('weekly')}${dayNames} ${sr.timeOfDay || ''}`;
      }
      case 'MONTHLY': {
        const days = (sr.daysOfMonth || []).join(',');
        return `${t('monthly')} ${days} ${sr.timeOfDay || ''}`;
      }
      case 'LOOP': {
        const ms = sr.intervalMs || 600000;
        if (ms === 600000) return t('every10min');
        if (ms === 900000) return t('every15min');
        if (ms === 1800000) return t('every30min');
        if (ms === 3600000) return t('every1hour');
        if (ms === 7200000) return t('every2hours');
        return `${t('loop')} ${Math.round(ms / 60000)}min`;
      }
      default:
        return '';
    }
  };

  const resetForm = () => {
    setAddType(null);
    setShowAddMenu(false);
    setSchedFreq('DAILY');
    setSchedRunAt('');
    setSchedTime('09:00');
    setSchedDaysOfWeek([]);
    setSchedDaysOfMonth([]);
    setSchedIntervalMs(600000);
    setHookTargetId('');
  };

  const handleAddSchedule = () => {
    const rule: ScheduleRule = {
      type: 'schedule',
      id: generateRuleId(),
      frequency: schedFreq,
      timezone: 'Asia/Taipei',
    };
    if (schedFreq === 'ONCE') rule.runAt = schedRunAt;
    if (['DAILY', 'WEEKLY', 'MONTHLY'].includes(schedFreq)) rule.timeOfDay = schedTime;
    if (schedFreq === 'WEEKLY') rule.daysOfWeek = schedDaysOfWeek;
    if (schedFreq === 'MONTHLY') rule.daysOfMonth = schedDaysOfMonth;
    if (schedFreq === 'LOOP') rule.intervalMs = schedIntervalMs;
    setRunPolicies(prev => [...prev, rule]);
    resetForm();
  };

  const handleAddHook = () => {
    if (!hookTargetId.trim()) return;
    const rule: HookRule = {
      type: 'hook',
      id: generateRuleId(),
      targetId: hookTargetId.trim(),
      targetName: hookTargetId.trim().split('/').pop() || hookTargetId.trim(),
      debounceMs: 5000,
    };
    setRunPolicies(prev => [...prev, rule]);
    resetForm();
  };

  const handleDeleteRule = (ruleId: string) => {
    setRunPolicies(prev => prev.filter(r => r.id !== ruleId));
  };

  const toggleDayOfWeek = (day: number) => {
    setSchedDaysOfWeek(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day].sort()
    );
  };

  const toggleDayOfMonth = (day: number) => {
    setSchedDaysOfMonth(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day].sort()
    );
  };

  // AttachedableEditor 的 ref，用於獲取格式化內容（跟 AICommanderChatRoom 一樣）
  const editorRef = useRef(null);

  // 用於追蹤是否已初始化，避免首次渲染時觸發 autoSave
  const isInitializedRef = useRef(false);

  // 附加項目狀態
  const [attachedItems, setAttachedItems] = useState(() => {

    if (!Array.isArray(task?.attachedItems)) return [];
    return task.attachedItems.map(str => { try { return JSON.parse(str); } catch { return null; } }).filter(Boolean);
  });

  // 獲取當前任務資料的函數
  const getCurrentTaskData = () => {
    // 跟 AICommanderChatRoom 一樣，使用 getFormattedContent() 獲取包含 #[ID] 格式的內容
    const formattedContent = editorRef.current ? editorRef.current.getFormattedContent() : content;

    return {
      ...task,
      name: title,
      content: formattedContent,
      parentID: folderId || null,
      runPolicies,
      isOpenPush,
      model,
      attachedItems: attachedItems.map(item => JSON.stringify(item))
    };
  };

  // 暴露方法給父組件
  useImperativeHandle(ref, () => ({
    getCurrentTaskData
  }));

  // 自動保存函數
  const performAutoSave = () => {
    if (!onSave || !enableAutoSave) return;
    onSave(getCurrentTaskData());
  };

  // 監聽所有變化並自動保存（跳過首次渲染，且僅在 enableAutoSave 為 true 時執行）
  useEffect(() => {
    if (!enableAutoSave) return;
    if (!isInitializedRef.current) {
      isInitializedRef.current = true;
      return;
    }
    performAutoSave();
  }, [title, content, folderId, runPolicies, isOpenPush, model, attachedItems, enableAutoSave]);

  const handleAddAttachment = (item) => {
    setAttachedItems(prev => [...prev, item]);
  };

  const handleRemoveAttachment = (id) => {
    setAttachedItems(prev => prev.filter(i => i.id !== id));
  };

  return (
    <div className={`task-editor-container ${className}`}>
      {/* 標題編輯 */}
      <div className="task-edit-field">
        <label className="task-edit-label">{t('taskName')}</label>
        <div className="task-edit-row">
          <input
            type="text"
            className="task-edit-input"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('enterTaskName')}
            style={{ flex: 1 }}
          />
          {/* Mobile: 顯示刪除按鈕 */}
          {isMobileView && onDelete && (
            <button
              className="task-edit-delete-btn"
              onClick={onDelete}
              title={t('deleteTask')}
            >
              <DeleteIcon />
              <span>{t('deleteTask')}</span>
            </button>
          )}
        </div>
      </div>

      {/* 內容編輯 */}
      <div className="task-edit-field">
        <label className="task-edit-label">{t('taskContent')}</label>
      </div>
      <div className="task-edit-field-grow">
        <AttachedableEditor
          ref={editorRef}
          value={content}
          onChange={setContent}
          placeholder={t('enterTaskContent')}
          attachedItems={attachedItems}
          onAddAttachment={handleAddAttachment}
          onRemoveAttachment={handleRemoveAttachment}
          autoHeight={false}
          submitOnEnter={false}
          className="task-edit-textarea"
          style={{
            border: '1px solid color-mix(in srgb, var(--on) 16%, transparent)',
            borderRadius: '8px',
            padding: '8px',
            background: 'color-mix(in srgb, var(--on) 3%, transparent)',
            height: '100%'
          }}
        />
      </div>

      {/* AI 模型 */}
      <div className="task-edit-field">
        <label className="task-edit-label">{t('agentModel')}</label>
        <select
          className="custom-select"
          value={model}
          onChange={(e) => setModel(e.target.value)}
        >
          {availableModels.map(m => (
            <option key={m.id} value={m.id}>{m.name}</option>
          ))}
        </select>
      </div>

      <div className="task-edit-field">
        <label className="task-edit-label">{t('runPolicy')}</label>
        <div className="run-policy-section">
          {runPolicies.length > 0 ? (
            <div className="run-policy-chips">
              {runPolicies.map((rule: RunRule) => (
                <div key={rule.id} className="run-policy-chip">
                  <span className="run-policy-chip-text">{getRuleLabel(rule)}</span>
                  <button
                    type="button"
                    className="run-policy-chip-delete"
                    onClick={() => handleDeleteRule(rule.id)}
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="run-policy-placeholder">{t('noRulesSet')}</div>
          )}

          {!addType && (
            <div className="run-policy-add-wrapper" ref={addMenuRef}>
              <button
                type="button"
                className="run-policy-add-btn"
                onClick={() => setShowAddMenu(!showAddMenu)}
              >
                + {t('addRule')}
              </button>
              {showAddMenu && (
                <div className="run-policy-type-menu">
                  <div
                    className="run-policy-type-option"
                    onClick={() => { setAddType('schedule'); setShowAddMenu(false); }}
                  >
                    {t('scheduleRule')}
                  </div>
                  <div
                    className="run-policy-type-option"
                    onClick={() => { setAddType('hook'); setShowAddMenu(false); }}
                  >
                    {t('hookRule')}
                  </div>
                </div>
              )}
            </div>
          )}

          {addType === 'schedule' && (
            <div className="run-policy-form">
              <select
                className="custom-select"
                value={schedFreq}
                onChange={(e) => setSchedFreq(e.target.value as ScheduleRule['frequency'])}
              >
                <option value="ONCE">{t('once')}</option>
                <option value="DAILY">{t('daily')}</option>
                <option value="WEEKLY">{t('weekly')}</option>
                <option value="MONTHLY">{t('monthly')}</option>
                <option value="LOOP">{t('loop')}</option>
              </select>

              {schedFreq === 'ONCE' && (
                <input
                  type="datetime-local"
                  className="task-edit-input"
                  value={schedRunAt}
                  onChange={(e) => setSchedRunAt(e.target.value)}
                />
              )}

              {(schedFreq === 'DAILY' || schedFreq === 'WEEKLY' || schedFreq === 'MONTHLY') && (
                <input
                  type="time"
                  className="task-edit-input"
                  value={schedTime}
                  onChange={(e) => setSchedTime(e.target.value)}
                />
              )}

              {schedFreq === 'WEEKLY' && (
                <div className="task-edit-days-grid">
                  {[1, 2, 3, 4, 5, 6, 7].map(d => (
                    <button
                      key={d}
                      type="button"
                      className={`task-edit-day-button ${schedDaysOfWeek.includes(d) ? 'selected' : ''}`}
                      onClick={() => toggleDayOfWeek(d)}
                    >
                      {t(`weekDay${d}`)}
                    </button>
                  ))}
                </div>
              )}

              {schedFreq === 'MONTHLY' && (
                <div className="task-edit-days-grid task-edit-days-grid-month">
                  {Array.from({ length: 31 }, (_, i) => i + 1).map(d => (
                    <button
                      key={d}
                      type="button"
                      className={`task-edit-day-button ${schedDaysOfMonth.includes(d) ? 'selected' : ''}`}
                      onClick={() => toggleDayOfMonth(d)}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              )}

              {schedFreq === 'LOOP' && (
                <select
                  className="custom-select"
                  value={schedIntervalMs}
                  onChange={(e) => setSchedIntervalMs(Number(e.target.value))}
                >
                  <option value={600000}>{t('every10min')}</option>
                  <option value={900000}>{t('every15min')}</option>
                  <option value={1800000}>{t('every30min')}</option>
                  <option value={3600000}>{t('every1hour')}</option>
                  <option value={7200000}>{t('every2hours')}</option>
                </select>
              )}

              <div className="run-policy-form-actions">
                <button type="button" className="run-policy-form-cancel" onClick={resetForm}>
                  {t('cancelAdd')}
                </button>
                <button type="button" className="run-policy-form-confirm" onClick={handleAddSchedule}>
                  {t('confirmAdd')}
                </button>
              </div>
            </div>
          )}

          {addType === 'hook' && (
            <div className="run-policy-form">
              <input
                type="text"
                className="task-edit-input"
                value={hookTargetId}
                onChange={(e) => setHookTargetId(e.target.value)}
                placeholder={t('vaultFolderPath')}
              />
              <div className="run-policy-form-actions">
                <button type="button" className="run-policy-form-cancel" onClick={resetForm}>
                  {t('cancelAdd')}
                </button>
                <button type="button" className="run-policy-form-confirm" onClick={handleAddHook}>
                  {t('confirmAdd')}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 目標資料夾或卡片類別 */}
      <div className="task-edit-field">
        <label className="task-edit-label">{t('targetFolder')}</label>
        <div className="task-editor-folder-select-wrapper" ref={folderDropdownRef}>
          <div
            className={`custom-select ${showFolderDropdown ? 'active' : ''}`}
            onClick={() => setShowFolderDropdown(!showFolderDropdown)}
            style={{ cursor: 'pointer' }}
          >
            {renderSelectedDisplay()}
          </div>
          {showFolderDropdown && (
            <div className="task-editor-folder-select-dropdown">
              {/* 不指定選項 */}
              <div
                className={`folder ${!folderId ? 'selected' : ''}`}
                onClick={() => {
                  setFolderId('');
                  setShowFolderDropdown(false);
                }}
              >
                <span className="folder-name">
                  <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
                    {t('noTargetFolder')}
                  </div>
                </span>
              </div>
              <FolderTreeSelect
                mode="selector"
                types={['TODO', 'NOTE', 'CARD', 'CHART']}
                value={folderId}
                onChange={(val) => {
                  setFolderId(val);
                  setShowFolderDropdown(false);
                }}
                showCount={false}
                showInbox={false}
                showTrash={false}
              />
            </div>
          )}
        </div>
      </div>

      {/* 是否開啟推播 */}
      <div className="task-edit-field">
        <div className="task-edit-toggle-row">
          <label className="task-edit-label">{t('enableNotifications')}</label>
          <div
            className={`mock-task-toggle ${isOpenPush ? 'active' : ''}`}
            onClick={() => setIsOpenPush(!isOpenPush)}
          >
            <div className="mock-task-toggle-track" />
            <div className="mock-task-toggle-thumb" />
          </div>
        </div>
      </div>
    </div>
  );
});

export default TaskEditor;
