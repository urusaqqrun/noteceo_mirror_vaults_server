import React, { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './TaskEditDialog.css';
import './AddTaskTemplateDialog.css';
import '../../common/BasicComponents.css';
import TaskEditor from './TaskEditor';
import { CustomDialog } from '../../common/CustomDialog';

function TaskEditDialog({ task, onClose, onSave }) {
  const { t } = useTranslation();
  const taskEditorRef = useRef(null);

  // 處理確認儲存
  const handleConfirm = () => {
    if (taskEditorRef.current && onSave) {
      const updatedTask = taskEditorRef.current.getCurrentTaskData();
      onSave(updatedTask);
    }
    onClose();
  };

  // Escape 由 CustomDialog 統一處理

  return (
    <CustomDialog
      isOpen={true}
      onClose={onClose}
      title={t('editTask')}
      className="task-edit-dialog-content"
      onConfirm={handleConfirm}
    >
      {/* Body - Use TaskEditor */}
      <div className="task-edit-dialog-body-wrapper">
        <TaskEditor
          ref={taskEditorRef}
          task={task}
          onCancel={onClose}
          autoSave={false}
        />
      </div>
    </CustomDialog>
  );
}




export default TaskEditDialog;
