import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './AddTaskTemplateDialog.css';
import '../../common/BasicComponents.css';
import TaskEditDialog from './TaskEditDialog';
import { useAgentStore } from './autoTaskStore';
import type { TodoFolder } from '../todo/todoStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSearchRegistry } from '../../../Store/searchRegistry';
import { useTempHintStore } from '../../../Store/uiStore';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import syncService from '../../../utils/syncService';
import EditIcon from '../../../assets/icon_edit_24.svg?react';
import categoryTemplates from './categoryTemplates.json';
import { getIconByName } from '../../common/IconRegistry';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { CustomDialog } from '../../common/CustomDialog';

// Icon components - 使用簡單的 SVG icons
const ChevronDownIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path d="M5 7.5L10 12.5L15 7.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const ChevronUpIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path d="M15 12.5L10 7.5L5 12.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const CheckIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
    <path d="M13.3333 4L6 11.3333L2.66667 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

function AddTaskTemplateDialog({ onClose, onConfirm }) {
  const { t, i18n } = useTranslation();
  const isMobileView = useIsMobileView();
  const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('../note/noteStore').NoteFolder[];
  const todoFolders = useItemStore(s => s.byType['TODO_FOLDER'] ?? []) as TodoFolder[];
  const cardFolders = useItemStore(s => s.byType['CARD_FOLDER'] ?? []);
  const chartFolders = useItemStore(s => s.byType['CHART_FOLDER'] ?? []);
  const folders = useMemo(() => [...noteFolders, ...todoFolders, ...cardFolders, ...chartFolders], [noteFolders, todoFolders, cardFolders, chartFolders]);
  const setTempHint = useTempHintStore(state => state.setTempHint);
  const [expandedCategories, setExpandedCategories] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [currentStep, setCurrentStep] = useState('selection'); // 'selection' 或 'preview'
  const [previewTasks, setPreviewTasks] = useState({}); // 用來儲存每個子類別的任務狀態
  const scrollContainerRef = useRef(null); // scroll 容器的 ref
  const [editingTask, setEditingTask] = useState(null); // 正在編輯的任務
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [userFields, setUserFields] = useState({}); // 用戶填寫的欄位值
  const [requiredFieldsList, setRequiredFieldsList] = useState([]); // 所有需要填寫的欄位列表

  // 取得現有任務的標題列表（用於判斷子類別是否所有任務都已加入）
  const existingTaskTitles = useMemo(() => {
    const existingAgents = useAgentStore.getState().getAgents();
    return existingAgents.map(a => a.name);
  }, []);

  // 檢查子類別是否所有任務都已加入
  const isSubCategoryFullyAdded = (subCategory) => {
    const automationTasks = subCategory.automationTasks || [];
    if (automationTasks.length === 0) return false;
    return automationTasks.every(task => existingTaskTitles.includes(task.title));
  };

  const categories = useMemo(() => {
    return categoryTemplates.map((category) => {
      const CategoryIcon = getIconByName(category.iconName);
      return {
        ...category,
        name: t(category.nameKey),
        icon: CategoryIcon ? <CategoryIcon /> : null,
        color: category.colorClass,
        subCategories: category.subCategories.map((subCategory) => {
          const SubCategoryIcon = getIconByName(subCategory.iconName);
          return {
            ...subCategory,
            name: t(subCategory.nameKey),
            icon: SubCategoryIcon ? <SubCategoryIcon /> : null,
            disabled: subCategory.disabled || false
          };
        })
      };
    });
  }, [t, i18n.language]);

  const buildPreviewTasksFromAutomation = (subCategoryNameKey, automationTasks = [], existingTaskTitles = []) => {
    // 過濾掉已存在同名任務的項目
    return automationTasks
      .filter((task) => !existingTaskTitles.includes(task.title))
      .map((task) => ({
        id: generateObjectID(),
        title: task.title,
        enabled: true,
        actionType: task.actionType,
        content: task.content,
        runPolicies: task.runPolicies || [],
        folderNameKey: task.folderNameKey,
        requiredFields: task.requiredFields || []
      }));
  };

  const getSubCategoryInfo = (subCategoryNameKey) => {
    for (const category of categories) {
      const subCategory = category.subCategories.find(sub => sub.nameKey === subCategoryNameKey);
      if (subCategory) {
        return subCategory;
      }
    }
    return null;
  };

  const getPreviewTasksForSubCategory = (subCategoryNameKey) => {
    const existingPreviewTasks = previewTasks[subCategoryNameKey];
    if (existingPreviewTasks && existingPreviewTasks.length > 0) {
      return existingPreviewTasks;
    }
    const subCategory = getSubCategoryInfo(subCategoryNameKey);
    if (!subCategory) return [];
    // 取得現有任務的標題列表
    const existingAgents = useAgentStore.getState().getAgents();
    const existingNames = existingAgents.map(a => a.name);
    return buildPreviewTasksFromAutomation(subCategoryNameKey, subCategory.automationTasks || [], existingNames);
  };

  const buildFolderTasks = (subCategoryNameKey, targetFolderId) => {
    const sourceTasks = getPreviewTasksForSubCategory(subCategoryNameKey);

    const result = sourceTasks.map((task) => ({
      id: task.id || generateObjectID(),
      parentID: targetFolderId,
      status: task.enabled !== false ? 'active' : 'paused',
      isOpenPush: false,
      name: task.title || '',
      content: task.content || '',
      runPolicies: task.runPolicies || []
    }));

    return result;
  };

  // 不再過濾，顯示所有類別（但在創建時會跳過同名資料夾）
  const availableCategories = categories;

  // 根據 nameKey 獲取子類別資訊
  const getAvailableSubCategoryInfo = (subCategoryNameKey) => {
    for (const category of availableCategories) {
      const subCategory = category.subCategories.find(sub => sub.nameKey === subCategoryNameKey);
      if (subCategory) {
        return subCategory;
      }
    }
    return null;
  };

  const toggleCategory = (categoryNameKey) => {
    setExpandedCategories((prev) =>
      prev.includes(categoryNameKey)
        ? prev.filter((key) => key !== categoryNameKey)
        : [...prev, categoryNameKey]
    );
  };

  const toggleSubCategory = (subCategoryNameKey) => {
    setSelectedItems((prev) =>
      prev.includes(subCategoryNameKey)
        ? prev.filter((key) => key !== subCategoryNameKey)
        : [...prev, subCategoryNameKey]
    );
  };

  const handleSubmit = () => {
    if (selectedItems.length === 0) return;
    const tasks = {};
    const allRequiredFields = [];

    const existingAgents = useAgentStore.getState().getAgents();
    const existingNames = existingAgents.map(a => a.name);

    selectedItems.forEach(subCategoryNameKey => {
      const subCategory = getAvailableSubCategoryInfo(subCategoryNameKey);
      if (!subCategory) {
        tasks[subCategoryNameKey] = [];
        return;
      }
      const automationTasks = subCategory.automationTasks || [];
      tasks[subCategoryNameKey] = buildPreviewTasksFromAutomation(subCategoryNameKey, automationTasks, existingNames);

      // 收集所有需要的欄位
      (automationTasks as Array<{ requiredFields?: Array<{ key: string }> }>).forEach((task) => {
        if (task.requiredFields) {
          task.requiredFields.forEach(field => {
            // 避免重複添加同一個欄位
            if (!allRequiredFields.find(f => f.key === field.key)) {
              allRequiredFields.push(field);
            }
          });
        }
      });
    });

    // 從 userData 中獲取已有的欄位值
    const userDataLocal = localStorage.getItem('userData_local');
    const parsedUserData = userDataLocal ? JSON.parse(userDataLocal) : {};
    const initialFields = {};
    allRequiredFields.forEach(field => {
      if (parsedUserData[field.key]) {
        initialFields[field.key] = parsedUserData[field.key];
      }
    });

    setUserFields(initialFields);
    setRequiredFieldsList(allRequiredFields);
    setPreviewTasks(tasks);
    setCurrentStep('preview');
  };

  const handleComplete = async () => {
    try {
      const allItems = useSearchRegistry.getState().search('');
      const folderTypes = ['NOTE_FOLDER', 'TODO_FOLDER', 'CARD_FOLDER', 'CHART_FOLDER'];
      const allFolders = allItems.filter((i: any) => folderTypes.includes(i.itemType));
      const addAgent = useAgentStore.getState().addAgent;
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const myMemberID = userData?.ID || (window as any).auth?.currentUser?.uid || 'DataProviderDefault';
      const addNoteFolder = async (f: any) => {
        const folderWithMeta = { ...f, id: f.id || generateObjectID(), itemType: 'NOTE_FOLDER' };
        await useItemStore.getState().upsertItem({ ...folderWithMeta, itemType: 'NOTE_FOLDER' } as any, { needSync: true });
      };

      // 收集所有要添加的任務
      const allTasksToAdd = [];

      // 記錄已創建的資料夾（folderNameKey -> targetFolderId）
      const createdFolders = {};

      // 記錄需要創建群組的資料夾（groupNameKey -> { groupFolder, subFolderIds }）
      const groupFolderMap = {};

      // 遍歷所有選中的 subCategory
      for (const subCategoryNameKey of selectedItems) {
        // 找到該 subCategory 所屬的主類別
        let parentCategory = null;
        let subCategory = null;
        for (const category of categories) {
          const found = category.subCategories.find(sub => sub.nameKey === subCategoryNameKey);
          if (found) {
            parentCategory = category;
            subCategory = found;
            break;
          }
        }
        if (!parentCategory || !subCategory) continue;

        // 取得預覽的任務列表
        const previewTaskList = getPreviewTasksForSubCategory(subCategoryNameKey);

        // 遍歷每個任務
        for (const task of previewTaskList) {
          // 如果任務被禁用，跳過
          if (task.enabled === false) continue;

          // 取得 folderNameKey
          const folderNameKey = task.folderNameKey;

          let targetFolderId = null;

          // 如果任務有 folderNameKey，處理資料夾創建
          if (folderNameKey) {
            const folderName = t(folderNameKey);

            // 檢查是否已經處理過這個資料夾
            if (createdFolders[folderNameKey]) {
              targetFolderId = createdFolders[folderNameKey];
            } else {
              // 檢查是否已存在同名資料夾
              let existingFolder = allFolders.find(f =>
                (f as any)?.name?.toLowerCase() === folderName.toLowerCase()
              );

              if (existingFolder) {

                targetFolderId = existingFolder.id;
              } else {
                // 確保群組資料夾存在
                const groupName = parentCategory.name;
                const groupIconName = parentCategory.iconName;

                if (!groupFolderMap[parentCategory.nameKey]) {
                  // 檢查群組是否已存在
                  let groupFolder = allFolders.find(f => (f as any)?.name === groupName);

                  if (!groupFolder) {
                    const groupFolderId = generateObjectID();
                    const newGroupFolder = {
                      id: groupFolderId,
                      name: groupName,
                      folderSummary: `${groupName}相關的資料夾`,
                      icon: groupIconName,
                      isTemp: false,
                      parentID: null
                    };

                    await addNoteFolder(newGroupFolder);

                    groupFolder = { id: groupFolderId, name: groupName } as any;
                  }

                  groupFolderMap[parentCategory.nameKey] = {
                    groupFolder,
                    subFolderIds: []
                  };
                }

                // 創建子資料夾（parentID 指定所屬群組）
                const groupFolderId = groupFolderMap[parentCategory.nameKey].groupFolder.id;
                const subFolderId = generateObjectID();
                const newSubFolder = {
                  id: subFolderId,
                  name: folderName,
                  folderSummary: `${folderName}的相關筆記`,
                  icon: subCategory.iconName,
                  isTemp: false,
                  parentID: groupFolderId
                };

                await addNoteFolder(newSubFolder);

                targetFolderId = subFolderId;

              }

              createdFolders[folderNameKey] = targetFolderId;
            }
          }

          // 替換 content 中的佔位符
          let processedContent = task.content || '';
          if (task.requiredFields && task.requiredFields.length > 0) {
            task.requiredFields.forEach(field => {
              const value = userFields[field.key] || '';
              processedContent = processedContent.replace(new RegExp(`\\{${field.key}\\}`, 'g'), value);
            });
          }

          const newAgent = {
            id: task.id || generateObjectID(),
            parentID: targetFolderId,
            status: task.enabled !== false ? 'active' : 'paused',
            isOpenPush: true,
            name: task.title || '',
            content: processedContent,
            runPolicies: task.runPolicies || []
          };

          allTasksToAdd.push(newAgent);
        }
      }

      await useItemStore.getState().loadByType('NOTE_FOLDER');

      // 將所有任務加入到 AutomationCenter

      for (const a of allTasksToAdd) {
        await addAgent(a);
      }

      // 如果有填寫新的欄位，保存到用戶資料
      if (Object.keys(userFields).length > 0) {
        try {
          const userDataLocal = localStorage.getItem('userData_local');
          const parsedUserData = userDataLocal ? JSON.parse(userDataLocal) : {};

          // 合併新的欄位到本地
          const updatedUserData = { ...parsedUserData, ...userFields };
          localStorage.setItem('userData_local', JSON.stringify(updatedUserData));

          // 同步到服務器（只傳 userFields 欄位，實現部分更新）
          const accessToken = localStorage.getItem('accessToken');
          if (accessToken) {
            await window.electronAPI.graphqlRequest({
              url: 'https://dev.cubelv.com/membercenter/graphql',
              accessToken: accessToken,
              query: `
                mutation UpdateUserProfile($input: UpdateUserProfileInput!) {
                  updateUserProfile(input: $input) {
                    ID
                    cityOfResidence
                    countryOfResidence
                  }
                }
              `,
              variables: {
                input: userFields
              },
              operationName: 'UpdateUserProfile'
            });

          }
        } catch (userDataError) {
          console.error('[CategorySelectionDialog] 保存用戶資料失敗:', userDataError);
        }
      }

      // 同步到服務器（背景執行）
      syncService.syncChanges();

      // 完成後關閉對話框
      onConfirm(selectedItems);
      onClose();
    } catch (error) {
      console.error('創建資料夾失敗:', error);
    }
  };

  const handleBack = () => {
    // 返回到選擇頁面
    setCurrentStep('selection');
  };

  const toggleTask = (subCategoryNameKey, taskId) => {
    setPreviewTasks(prev => ({
      ...prev,
      [subCategoryNameKey]: prev[subCategoryNameKey].map(task =>
        task.id === taskId ? { ...task, enabled: !task.enabled } : task
      )
    }));
  };

  const handleEditTask = (subCategoryNameKey, task) => {
    setEditingTask({ ...task, subCategoryNameKey });
    setShowEditDialog(true);
  };

  const handleSaveTask = (subCategoryNameKey, updatedTask) => {
    setPreviewTasks(prev => {
      // 找到原始任務以保留 requiredFields
      const originalTask = prev[subCategoryNameKey]?.find(t => t.id === updatedTask.id);

      const normalizedTask = {
        ...updatedTask,
        title: updatedTask.title || '',
        enabled: typeof updatedTask.enabled === 'boolean' ? updatedTask.enabled : true,
        runPolicies: updatedTask.runPolicies || [],
        requiredFields: originalTask?.requiredFields || updatedTask.requiredFields || [],
        folderNameKey: originalTask?.folderNameKey || updatedTask.folderNameKey
      };

      return {
        ...prev,
        [subCategoryNameKey]: prev[subCategoryNameKey].map(task =>
          task.id === normalizedTask.id ? normalizedTask : task
        )
      };
    });
    // 自動保存模式：不在此關閉對話框，由 onClose 處理
  };

  // 計算啟用的任務數量
  const getEnabledTaskCount = () => {
    let enabledCount = 0;
    let totalCount = 0;
    Object.values(previewTasks as Record<string, any[]>).forEach(tasks => {
      totalCount += tasks.length;
      enabledCount += tasks.filter(task => task.enabled).length;
    });
    return { enabledCount, totalCount };
  };

  // 檢查是否有未填寫的必填欄位
  const hasUnfilledRequiredFields = () => {
    for (const tasks of Object.values(previewTasks as Record<string, any[]>)) {
      for (const task of tasks) {
        // 只檢查已啟用的任務
        if (task.enabled && task.requiredFields && task.requiredFields.length > 0) {
          for (const field of task.requiredFields) {
            if (!userFields[field.key] || userFields[field.key].trim() === '') {
              return true;
            }
          }
        }
      }
    }
    return false;
  };

  // Escape 由 CustomDialog 統一處理

  // 當切換步驟時，重置 scroll 位置
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTop = 0;
    }
  }, [currentStep]);

  return (
    <CustomDialog
      isOpen={true}
      onClose={onClose}
      className="category-dialog-content"
    >
      {currentStep === 'selection' ? (
        <>
          {/* Header */}
          <div className="category-dialog-header">
            <div className="category-dialog-header-text">
              <h1 className="category-dialog-title">{t('categoryDialogTitle')}</h1>
              {!isMobileView && (
                <p className="category-dialog-subtitle">
                  {t('categoryDialogSubtitle')}
                </p>
              )}
            </div>
            {selectedItems.length > 0 && (
              <div className="category-selected-badge">
                {selectedItems.length}
              </div>
            )}
          </div>

          {/* Categories List */}
          <div className="category-list-container" ref={scrollContainerRef}>
            <div className="category-list">
              {availableCategories.map((category) => {
                const isExpanded = expandedCategories.includes(category.nameKey);
                const selectedCount = category.subCategories.filter((sub) =>
                  selectedItems.includes(sub.nameKey)
                ).length;

                return (
                  <div key={category.nameKey} className="category-card">
                    {/* Category Header */}
                    <button
                      onClick={() => toggleCategory(category.nameKey)}
                      className="category-header-button"
                    >
                      <div className="category-header-left">
                        <div className={`category-icon-box ${category.color}`}>
                          <div className="category-icon">{category.icon}</div>
                        </div>
                        <span className="category-name">{category.name}</span>
                        {selectedCount > 0 && (
                          <div className="category-count-badge">
                            {selectedCount}
                          </div>
                        )}
                      </div>
                      <div className="category-chevron">
                        {isExpanded ? <ChevronUpIcon /> : <ChevronDownIcon />}
                      </div>
                    </button>

                    {/* Sub Categories */}
                    {isExpanded && (
                      <div className="category-subcategories">
                        <div className="subcategory-grid">
                          {category.subCategories.map((subCategory) => {
                            const isSelected = selectedItems.includes(subCategory.nameKey);
                            const isDisabled = subCategory.disabled;
                            const isFullyAdded = isSubCategoryFullyAdded(subCategory);
                            const shouldDisable = isDisabled || isFullyAdded;
                            return (
                              <button
                                key={subCategory.nameKey}
                                onClick={() => !shouldDisable && toggleSubCategory(subCategory.nameKey)}
                                className={`subcategory-button ${isSelected ? 'selected' : ''} ${shouldDisable ? 'disabled' : ''}`}
                                onMouseEnter={() => shouldDisable && setTempHint(isFullyAdded ? t('allTasksAdded') : t('notAvailable'))}
                                onMouseLeave={() => shouldDisable && setTempHint(null)}
                              >
                                <div className="subcategory-content">
                                  <div className="subcategory-icon">{subCategory.icon}</div>
                                  <span className="subcategory-name">{subCategory.name}</span>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Footer */}
          <div className="category-dialog-footer">
            <div className="custom-dialog-buttons">
              <button className="custom-secondary-button" onClick={onClose}>
                {t('cancel')}
              </button>
              <button
                className="custom-primary-button"
                onClick={handleSubmit}
                disabled={selectedItems.length === 0}
              >
                {t('confirm')}
              </button>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* 預覽頁面 - Header */}
          <div className="category-dialog-header">
            <div className="category-dialog-header-text">
              <h1 className="category-dialog-title">Agent 預覽</h1>
              {!isMobileView && (
                <p className="category-dialog-subtitle">
                  根據你選擇的類別，AI 已為你生成專屬的 Agent
                </p>
              )}
              <p className="category-dialog-task-count">
                {(() => {
                  const { enabledCount, totalCount } = getEnabledTaskCount();
                  return `${enabledCount} / ${totalCount} 個 Agent 已啟用`;
                })()}
              </p>
            </div>
          </div>

          {/* 預覽頁面 - 任務列表 */}
          <div className="category-list-container" ref={scrollContainerRef}>
            <div className="category-preview-list">
              {selectedItems.map((subCategoryNameKey) => {
                const subCategoryInfo = getSubCategoryInfo(subCategoryNameKey);
                if (!subCategoryInfo) return null;

                return (
                  <div key={subCategoryNameKey} className="category-preview-section">
                    <h3 className="category-preview-title">{subCategoryInfo.name}</h3>
                    <div className="category-preview-tasks">
                      {previewTasks[subCategoryNameKey]?.map((task) => (
                        <div key={task.id} className="category-preview-task-row">
                          <button
                            className="category-preview-checkbox"
                            onClick={() => toggleTask(subCategoryNameKey, task.id)}
                          >
                            <div className={`category-preview-checkbox-box ${task.enabled ? 'checked' : ''}`}>
                              {task.enabled && <CheckIcon />}
                            </div>
                          </button>
                          <div className="category-preview-task-left">
                            <span className="category-preview-task-name">{task.title}</span>
                            {task.content && (
                              <div className="category-preview-task-content">
                                {(() => {
                                  // 替換佔位符：有值用值，沒值用翻譯後的欄位名稱
                                  let displayContent = task.content;
                                  if (task.requiredFields && task.requiredFields.length > 0) {
                                    task.requiredFields.forEach(field => {
                                      const value = userFields[field.key];
                                      const replacement = value || `{${t(field.key)}}`;
                                      displayContent = displayContent.replace(new RegExp(`\\{${field.key}\\}`, 'g'), replacement);
                                    });
                                  }
                                  return displayContent;
                                })()}
                              </div>
                            )}
                            {/* 必填欄位輸入 */}
                            {task.requiredFields && task.requiredFields.length > 0 && (
                              <div className="category-preview-task-fields">
                                {task.requiredFields.map(field => (
                                  <div key={field.key} className="category-preview-field-row">
                                    <label className="category-preview-field-label">
                                      {t(field.key)}
                                    </label>
                                    <input
                                      type="text"
                                      className="category-preview-field-input"
                                      placeholder={field.placeholderKey ? t(field.placeholderKey) : ''}
                                      value={userFields[field.key] || ''}
                                      onChange={(e) => setUserFields(prev => ({
                                        ...prev,
                                        [field.key]: e.target.value
                                      }))}
                                    />
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                          <div className="category-preview-task-right">
                            <span className="category-preview-task-schedule">{task.schedule}</span>
                            <button
                              className="category-preview-edit-button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEditTask(subCategoryNameKey, task);
                              }}
                              tabIndex={0}
                            >
                              <EditIcon />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 預覽頁面 - Footer */}
          <div className="category-dialog-footer">
            <div className="custom-dialog-buttons">
              <button className="custom-secondary-button" onClick={handleBack}>
                返回
              </button>
              <button
                className="custom-primary-button"
                onClick={handleComplete}
                disabled={hasUnfilledRequiredFields()}
              >
                完成
              </button>
            </div>
          </div>
        </>
      )}

      {/* Task Edit Dialog */}
      {showEditDialog && editingTask && (
        <TaskEditDialog
          task={editingTask}
          onClose={() => {
            setShowEditDialog(false);
            setEditingTask(null);
          }}
          onSave={(task) => handleSaveTask(editingTask.subCategoryNameKey, task)}
        />
      )}
    </CustomDialog>
  );
}

export default AddTaskTemplateDialog;

