// ===== AutoTaskPlugin — AI Agent 插件 =====
//
// 掛載條件：selectedItems 中有 itemType === 'AI_ADMIN_FOLDER' 的項目
//
// 面板配置：
//   centerPane1 → （清空，不使用）
//   centerPane2 → leaf-autotask (auto-task，flex:1，min:360)

import React from 'react';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import autoTaskEn from './locales/en.json';
import autoTaskZhHant from './locales/zh-Hant.json';
import autoTaskJa from './locales/ja.json';
import { useTranslation } from 'react-i18next';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import i18n from '../../../i18n/config';
import type { BaseItem } from '../../../types/item';
import DashboardIcon from '../../../assets/icon_grid_24.svg?react';
import ReviewIcon from '../../../assets/icon_inbox_24.svg?react';
import AgentsIcon from '../../../assets/icon_ceo_admin_outline_24.svg?react';
import CompanyIcon from '../../../assets/icon_folder_group_outline_24.svg?react';
import TaskIcon from '../../../assets/zap.svg?react';
import AutoTaskRoom from './AutoTaskRoom';
import NoteList_FolderTaskTags_patch from './patches/NoteList_FolderTaskTags_patch';
import { startHookWatcher } from './agentHookWatcher';

const sidebarIconMap: Record<string, React.FC<React.SVGProps<SVGSVGElement>>> = {
    AI_DASHBOARD_FOLDER: DashboardIcon,
    AI_REVIEW_FOLDER: ReviewIcon,
    AI_ADMIN_FOLDER: AgentsIcon,
    AI_COMPANY_FOLDER: CompanyIcon,
};

function useAutoTaskSidebarData() {
    const { t } = useTranslation();
    const prefixItems = React.useMemo<BaseItem[]>(() => [
        { itemType: 'AI_DASHBOARD_FOLDER', id: '__ai_dashboard__', name: t('sidebarDashboard'), parentID: null, version: 0, createdAt: 0, updatedAt: 0 },
        { itemType: 'AI_REVIEW_FOLDER', id: '__ai_review__', name: t('sidebarReview'), parentID: null, version: 0, createdAt: 0, updatedAt: 0 },
        { itemType: 'AI_ADMIN_FOLDER', id: '__ai_admin__', name: t('sidebarAgents'), parentID: null, version: 0, createdAt: 0, updatedAt: 0 },
        { itemType: 'AI_COMPANY_FOLDER', id: '__ai_company__', name: t('sidebarCompany'), parentID: null, version: 0, createdAt: 0, updatedAt: 0 },
    ], [t]);

    return {
        items: [] as BaseItem[],
        prefixItems,
        renderIcon: (item: BaseItem) => {
            const Icon = sidebarIconMap[item.itemType] || AgentsIcon;
            return <Icon className="folder-icon" />;
        },
    };
}

class AutoTaskView extends ReactView {
    getViewType() { return 'auto-task'; }
    getDisplayText() { return '自動化中心'; }
    renderComponent() { return <AutoTaskRoom />; }
}

export class AutoTaskPlugin extends Plugin {
    onload() {
        // 猴子補丁：Portal 注入資料夾任務標籤到 NoteList
        this.registerOverlay('NoteList_FolderTaskTags', NoteList_FolderTaskTags_patch);

        this.registerSearchProvider('AGENT', {
            search: (query: string) => {
                const q = query.toLowerCase();
                const items = useItemStore.getState().getByType('AGENT');
                return items
                    .filter((item: any) => {
                        if (!q) return true;
                        const titleMatch = (item.name || '').toLowerCase().includes(q);
                        const contentMatch = (item.content || '').toLowerCase().includes(q);
                        return titleMatch || contentMatch;
                    })
                    .map((item: any) => ({
                        id: item.id,
                        itemType: 'AGENT',
                        name: item.name || '',
                        memberID: item.memberID || '',
                        parentID: item.parentID ?? null,
                        version: item.version || 0,
                        createdAt: item.createdAt || 0,
                        updatedAt: item.updatedAt || 0,
                        content: item.content,
                        status: item.status,
                        runPolicies: item.runPolicies,
                    } as any));
            },
            renderIcon: () => <TaskIcon />,
        });

        this.registerSidebarWithView({
            sidebar: {
                id: 'auto-task',
                title: i18n.t('automationCenter'),
                orderAt: 100,
                useData: useAutoTaskSidebarData,
                hideHeader: false,
            },
            views: [
                { type: 'auto-task', creator: (leaf) => new AutoTaskView(leaf) },
            ],
            activateOnItemTypes: ['AI_DASHBOARD_FOLDER', 'AI_REVIEW_FOLDER', 'AI_ADMIN_FOLDER', 'AI_COMPANY_FOLDER'],
            panes: {
                centerPane1: 'clear',
                centerPane2: { leafId: 'leaf-autotask', viewType: 'auto-task', flex: 1, minSize: 360 },
            },
        });

        // Hook watcher：監聽 vault 檔案變動觸發 Agent
        this.register(startHookWatcher());

        // 推送通知點擊 → 跳轉到 AI 指揮中心
        if (window.electronAPI?.onPushNotificationClick) {
            const unsubscribe = window.electronAPI.onPushNotificationClick((notification: any) => {
                const agentId = notification?.data?.agentId;
                const notifType = notification?.type;
                const aiAdminItem: BaseItem = {
                    id: '__ai_admin__', itemType: 'AI_ADMIN_FOLDER', name: 'Agents',
                    parentID: null, version: 0, createdAt: '', updatedAt: '',
                };

                if (agentId) {
                    useSelectedItemsStore.getState().setSelectedItems([aiAdminItem], { initialAgentId: agentId });
                } else if (notifType === 'agent_completed' || notifType === 'agent_need_input') {
                    useSelectedItemsStore.getState().setSelectedItems([aiAdminItem]);
                }
            });
            if (typeof unsubscribe === 'function') {
                this.register(unsubscribe);
            }
        }
    }
}

registerPluginClass(AutoTaskPlugin, '自動化中心', {
    dependencies: ['SidebarPlugin'],
    descriptionKey: 'modulesAutoTaskDesc',
    setupI18n: () => registerPluginLocales('AutoTaskPlugin', { 'en': autoTaskEn, 'zh-Hant': autoTaskZhHant, 'ja': autoTaskJa }),
});
