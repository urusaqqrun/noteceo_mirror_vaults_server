import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import './AgentDetailPanel.css';
import { Tabs } from '../../common/BasicComponents';
import { IconPicker } from '../../common/IconPicker';
import { getIconByName } from '../../common/IconRegistry';
import TaskEditor from './TaskEditor';
import AgentDashboardTab from './AgentDashboardTab';
import AgentBudgetTab from './AgentBudgetTab';
import PlayIcon from '../../../assets/bk_icon_play_26_n.svg?react';
import StopIcon from '../../../assets/bk_icon_stop_26_n.svg?react';
import type { Agent, AgentReport } from './autoTaskStore';

interface AgentDetailPanelProps {
  agent: Agent;
  reports: AgentReport[];
  onSave: (agentData: any) => void;
  onRun: () => void;
  onInterrupt: () => void;
  isExecuting: boolean;
  reloadKey: number;
}

const AgentDetailPanel = ({
  agent,
  reports,
  onSave,
  onRun,
  onInterrupt,
  isExecuting,
  reloadKey,
}: AgentDetailPanelProps) => {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('config');

  const agentReports = reports.filter(r => r.agentId === agent.id);

  const tabs = [
    { key: 'dashboard', label: t('tabDashboard') },
    { key: 'config', label: t('tabConfig') },
    { key: 'budget', label: t('tabBudget') },
  ];

  const handleIconChange = (iconName: string) => {
    onSave({ ...agent, icon: iconName });
  };

  const DefaultIcon = getIconByName('cpu');

  return (
    <div className="agent-detail-panel">
      <div className="agent-detail-header">
        <div className="agent-detail-header-left">
          <IconPicker
            value={agent.icon || null}
            onChange={handleIconChange}
          />
          <span className="agent-detail-name">
            {agent.name?.trim() || t('untitledTask')}
          </span>
        </div>
        <div className="agent-detail-header-right">
          {!isExecuting ? (
            <button className="agent-detail-play-btn" onClick={onRun}>
              <PlayIcon />
              <span>{t('runImmediately')}</span>
            </button>
          ) : (
            <button className="agent-detail-stop-btn" onClick={onInterrupt}>
              <StopIcon />
              <span>{t('interrupt')}</span>
            </button>
          )}
        </div>
      </div>

      <Tabs tabs={tabs} activeKey={activeTab} onChange={setActiveTab} />

      <div className="agent-detail-tab-content">
        {activeTab === 'dashboard' && (
          <AgentDashboardTab agent={agent} reports={agentReports} />
        )}
        {activeTab === 'config' && (
          <TaskEditor
            key={`${agent.id}-${reloadKey}`}
            task={agent}
            onSave={onSave}
            className="embedded-task-editor"
          />
        )}
        {activeTab === 'budget' && (
          <AgentBudgetTab agent={agent} onSave={onSave} />
        )}
      </div>
    </div>
  );
};

export default AgentDetailPanel;
