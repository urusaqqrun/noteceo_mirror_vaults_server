/**
 * agentHookWatcher — 監聽 vault:reconcile-changed 事件，匹配 Agent hook rules 並觸發執行
 */

import { eventBus } from '../../../Store/eventBus';
import { useAgentStore, type HookRule, type Agent } from './autoTaskStore';

const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();

function handleVaultChanged(changedFiles: string[]) {
    const agents = useAgentStore.getState().getAgents();

    for (const agent of agents) {
        if (agent.status !== 'active') continue;
        if (!agent.runPolicies?.length) continue;

        const hookRules = agent.runPolicies.filter(
            (r): r is HookRule => r.type === 'hook'
        );
        if (!hookRules.length) continue;

        for (const rule of hookRules) {
            const matched = changedFiles.some(fp => fp.startsWith(rule.targetId));
            if (!matched) continue;

            const debounceMs = rule.debounceMs ?? 5000;
            const timerKey = `${agent.id}:${rule.id}`;

            const existing = debounceTimers.get(timerKey);
            if (existing) clearTimeout(existing);

            debounceTimers.set(timerKey, setTimeout(() => {
                debounceTimers.delete(timerKey);
                triggerAgent(agent, rule);
            }, debounceMs));
        }
    }
}

function triggerAgent(agent: Agent, rule: HookRule) {
    console.log(`[AgentHookWatcher] triggering agent "${agent.name}" (${agent.id}) for hook rule ${rule.id}, target: ${rule.targetId}`);
    eventBus.emit('agent:hook-trigger', { agentId: agent.id, ruleId: rule.id, targetId: rule.targetId });
}

let unsub: (() => void) | null = null;

export function startHookWatcher(): () => void {
    if (unsub) unsub();
    unsub = eventBus.on('vault:reconcile-changed', handleVaultChanged);

    return () => {
        if (unsub) { unsub(); unsub = null; }
        for (const timer of debounceTimers.values()) clearTimeout(timer);
        debounceTimers.clear();
    };
}
