import { create } from 'zustand';

import { useItemStore } from '../../../Store/itemStore';
import { BaseItem, itemType } from '../../../types/item';

// ==================== Run Policy 型別 ====================

export interface ScheduleRule {
    type: 'schedule';
    id: string;
    frequency: 'ONCE' | 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'LOOP';
    runAt?: string;
    timeOfDay?: string;
    daysOfWeek?: number[];
    daysOfMonth?: number[];
    intervalMs?: number;
    timezone?: string;
}

export interface HookRule {
    type: 'hook';
    id: string;
    targetId: string;
    targetName?: string;
    debounceMs?: number;
}

export type RunRule = ScheduleRule | HookRule;

// ==================== Schema 註冊 ====================

@itemType('AGENT', 'AI Agent，自主執行任務的角色')
export class Agent extends BaseItem {
    icon?: string = '';
    status?: string = 'active';
    isOpenPush?: boolean = false;
    content?: string = '';
    model?: string = '';
    budgetMonthly?: number | null = null;
    budgetSpent?: number = 0;
    lastRunAt?: string = '';
    runPolicies?: RunRule[] = [];
    attachedItems?: string[] = [];
}

@itemType('AGENT_REPORT', 'Agent 執行報告')
export class AgentReport extends BaseItem {
    agentId?: string = '';
    type?: string = '';
    reportType?: string = 'report';
    content?: string = '';
    isRead?: boolean = false;
    options?: string = '';
    userAnswer?: string = '';
}

// ==================== Agent Store ====================

interface AgentState {
    getAgents: () => Agent[];
    getAgentById: (agentId: string) => Agent | undefined;
    getAgentsByFolder: (folderId: string) => Agent[];
    addAgent: (agent: any, needSync?: boolean) => Promise<void>;
    updateAgent: (agentId: string, updates: Partial<Agent>, needSync?: boolean) => Promise<void>;
    deleteAgent: (agentId: string, needSync?: boolean) => Promise<void>;
    reorderAgents: (newOrder: Agent[], needSync?: boolean) => Promise<void>;
    loadAgents: () => Promise<void>;
    reset: () => void;
}

const _getAgents = () => useItemStore.getState().getByType('AGENT') as Agent[];

export const useAgentStore = create<AgentState>(() => ({
    getAgents: _getAgents,
    getAgentById: (agentId) => _getAgents().find(a => a.id === agentId),
    getAgentsByFolder: (folderId) => _getAgents().filter(a => a.parentID === folderId),
    addAgent: async (agent, needSync = true) => {
        const now = new Date().toISOString();
        await useItemStore.getState().upsertItem({
            ...agent,
            itemType: 'AGENT',
            name: agent.name ?? '',
            parentID: agent.parentID ?? null,
            status: agent.status ?? 'active',
            isOpenPush: agent.isOpenPush ?? false,
            content: agent.content ?? '',
            runPolicies: agent.runPolicies ?? [],
            attachedItems: agent.attachedItems ?? [],
            orderAt: agent.orderAt ?? Date.now(),
            version: 0,
            createdAt: agent.createdAt ?? now,
            updatedAt: agent.updatedAt ?? now,
        } as any, { needSync });
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    updateAgent: async (agentId, updates, needSync = true) => {
        const agent = _getAgents().find(a => a.id === agentId);
        if (!agent) return;
        await useItemStore.getState().upsertItem({
            ...agent,
            ...updates,
            updatedAt: new Date().toISOString(),
            itemType: 'AGENT',
        } as any, { needSync });
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    deleteAgent: async (agentId, needSync = true) => {
        const reports = useItemStore.getState().getByType('AGENT_REPORT') as AgentReport[];
        const relatedIds = reports.filter(r => r.agentId === agentId).map(r => r.id);
        if (relatedIds.length > 0) {
            await useItemStore.getState().removeItems(relatedIds, { needSync });
        }
        await useItemStore.getState().removeItems([agentId], { needSync });
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    reorderAgents: async (newOrder, needSync = true) => {
        const updated = newOrder.map((agent, i) => ({ ...agent, orderAt: i }));
        for (const agent of updated) {
            await useItemStore.getState().upsertItem({
                ...agent,
                itemType: 'AGENT',
            } as any, { needSync });
        }
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    loadAgents: async () => {
        await useItemStore.getState().loadByType('AGENT');
    },
    reset: () => {
        const ids = _getAgents().map(a => a.id);
        if (ids.length > 0) useItemStore.getState().removeItems(ids);
    },
}));

// ==================== Agent Report Store ====================

interface AgentReportState {
    getReports: () => AgentReport[];
    getReportsByAgentId: (agentId: string) => AgentReport[];
    getUnreadReportsCount: () => number;
    addReport: (report: any, needSync?: boolean) => Promise<void>;
    markReportAsRead: (reportId: string, needSync?: boolean) => Promise<void>;
    deleteReport: (reportId: string, needSync?: boolean) => Promise<void>;
    removeReportsByIds: (ids: string[], needSync?: boolean) => void;
    loadReports: () => Promise<void>;
    reset: () => void;
}

const _getReports = () => useItemStore.getState().getByType('AGENT_REPORT') as AgentReport[];

export const useAgentReportStore = create<AgentReportState>(() => ({
    getReports: _getReports,
    getReportsByAgentId: (agentId) =>
        _getReports().filter(r => r.agentId === agentId),
    getUnreadReportsCount: () => _getReports().filter(r => !r.isRead).length,
    addReport: async (report, needSync = true) => {
        const now = new Date().toISOString();
        const agentId = report.agentId ?? '';
        await useItemStore.getState().upsertItem({
            ...report,
            itemType: 'AGENT_REPORT',
            parentID: agentId,
            agentId,
            reportType: report.type || report.reportType || 'SUMMARY',
            content: report.content || '',
            isRead: report.isRead ?? false,
            options: report.options || '',
            userAnswer: report.userAnswer || '',
            version: 0,
            createdAt: report.createdAt ?? now,
            updatedAt: report.updatedAt ?? now,
        } as any, { needSync });
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    markReportAsRead: async (reportId, needSync = true) => {
        const report = _getReports().find(r => r.id === reportId);
        if (!report) return;
        await useItemStore.getState().upsertItem({
            ...report,
            isRead: true,
            updatedAt: new Date().toISOString(),
            itemType: 'AGENT_REPORT',
        } as any, { needSync });
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    deleteReport: async (reportId, needSync = true) => {
        await useItemStore.getState().removeItems([reportId], { needSync });
        if (needSync) localStorage.setItem('itemsPendingSync', 'true');
    },
    removeReportsByIds: async (ids, needSync = true) => {
        if (ids.length > 0) await useItemStore.getState().removeItems(ids, { needSync });
    },
    loadReports: async () => {
        await useItemStore.getState().loadByType('AGENT_REPORT');
    },
    reset: () => {
        const ids = _getReports().map(r => r.id);
        if (ids.length > 0) useItemStore.getState().removeItems(ids);
    },
}));
