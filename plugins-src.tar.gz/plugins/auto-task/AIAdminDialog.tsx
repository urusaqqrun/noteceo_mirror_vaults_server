import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './AIAdminDialog.css';
import AutoTaskRoom from './AutoTaskRoom';
import { CustomDialog } from '../../common/CustomDialog';

/**
 * AIAdminDialog - 以 Dialog 形式顯示自動化任務中心
 * 內容與 AutoTaskRoom 完全相同
 */
const AIAdminDialog = ({ onClose, initialAgentId }) => {
  const { t } = useTranslation();

  return (
    <CustomDialog
      isOpen={true}
      onClose={onClose}
      className="ai-admin-dialog"
      showCloseButton={true}
    >
      <AutoTaskRoom initialAgentIdFromDialog={initialAgentId} />
    </CustomDialog>
  );
};

export default AIAdminDialog;
