/**
 * @patch NoteList_FolderTaskTags
 * @target .folder-summary-container (afterend)
 * @method createPortal + MutationObserver
 * @description 在 NoteList 的摘要區後面注入資料夾任務標籤 + AIAdminDialog
 */

import React, { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useAgentStore, useAgentReportStore } from '../autoTaskStore';
import { useSelectedItemsStore } from '../../../../Store/navigationStore';
import TaskIcon from '../../../../assets/zap.svg?react';
import BreathingDot from '../../../common/BreathingDot';
import AIAdminDialog from '../AIAdminDialog';

function NoteList_FolderTaskTags_patch() {
    const { t } = useTranslation();
    const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
    const agents = useAgentStore(state => state.getAgents()) ?? [];
    const reports = useAgentReportStore(state => state.getReports()) ?? [];

    const [portalTarget, setPortalTarget] = useState<HTMLElement | null>(null);
    const [aiAdminDialogState, setAiAdminDialogState] = useState<{ isOpen: boolean; agentId: string | null }>({ isOpen: false, agentId: null });

    // 用 MutationObserver 尋找 .folder-summary-container 並在其後面插入錨點
    useEffect(() => {
        const findOrCreateAnchor = () => {
            const summaryContainer = document.querySelector('.folder-summary-container');
            if (!summaryContainer) {
                setPortalTarget(null);
                return;
            }

            // 檢查是否已有錨點
            let anchor = summaryContainer.parentElement?.querySelector('[data-auto-task-anchor]') as HTMLElement | null;
            if (!anchor) {
                anchor = document.createElement('div');
                anchor.setAttribute('data-auto-task-anchor', 'true');
                summaryContainer.insertAdjacentElement('afterend', anchor);
            }
            setPortalTarget(anchor);
        };

        findOrCreateAnchor();

        const observer = new MutationObserver(() => {
            findOrCreateAnchor();
        });
        observer.observe(document.body, { childList: true, subtree: true });

        return () => {
            observer.disconnect();
            // 清理錨點
            document.querySelector('[data-auto-task-anchor]')?.remove();
        };
    }, [selectedFolderId]);

    const folderAgents = agents.filter(a => a.parentID === selectedFolderId);
    const activeAgents = folderAgents.filter(a => a.status === 'active');

    const unreadAgentIds = new Set(
        reports.filter(r => r.isRead === false).map(r => r.agentId)
    );

    if (activeAgents.length === 0 || !portalTarget) return null;

    return (
        <>
            {createPortal(
                <div className="folder-task-container">
                    <div className="folder-task-tag-container">
                        {activeAgents.map((agent) => (
                            <div
                                key={agent.id}
                                className="folder-task-tag"
                                onClick={() => {
                                    setAiAdminDialogState({ isOpen: true, agentId: agent.id });
                                }}
                            >
                                <span className="folder-task-tag-icon">
                                    <TaskIcon />
                                </span>
                                <span className="folder-task-tag-text">
                                    {agent.name || t('untitledTask')}
                                </span>
                                {unreadAgentIds.has(agent.id) && (
                                    <BreathingDot className="folder-task-tag-unread-dot" />
                                )}
                            </div>
                        ))}
                    </div>
                </div>,
                portalTarget
            )}

            {/* AIAdminDialog — 點擊任務標籤時打開 */}
            {aiAdminDialogState.isOpen && (
                <AIAdminDialog
                    onClose={() => setAiAdminDialogState({ isOpen: false, agentId: null })}
                    initialAgentId={aiAdminDialogState.agentId}
                />
            )}
        </>
    );
}

export default NoteList_FolderTaskTags_patch;
