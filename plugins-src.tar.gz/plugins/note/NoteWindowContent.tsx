import React, { useRef } from 'react';
import NoteEditor from '../editor/NoteEditor';
import NoteEditorToolbarAndMenu from '../editor/NoteEditorToolbar';
import type { WindowComponentProps } from '../../../workspace/windowComponentRegistry';
import '../../../NoteWindowContent.css';

function NoteWindowContent({ itemId }: WindowComponentProps) {
    const editorRef = useRef(null);
    return (
        <>
            <div className="note-window-content">
                <NoteEditor
                    ref={editorRef}
                    mode="window"
                    noteId={itemId}
                    editorId={`window-editor-${itemId}`}
                />
            </div>
            <NoteEditorToolbarAndMenu />
        </>
    );
}

export default NoteWindowContent;
