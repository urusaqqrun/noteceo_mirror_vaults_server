import React, { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { useNoteStore, type NoteFolder } from './noteStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useMobileSidebarStore } from '../../../Store/uiStore';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import EditIcon from '../../../assets/icon_edit_24.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_fill_20_n.svg?react';
import MobileTopbar from '../../common/MobileTopbar';
import { CustomToolbar } from '../../common/CustomToolbar';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import { ShareMemberThumbnailList } from '../../common/share/ShareMemberThumbnailList';


function NoteListTopbar() {
  const { t } = useTranslation();
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const isMobileView = useIsMobileView();
  const setIsMobileSidebarOpen = useMobileSidebarStore(state => state.setIsMobileSidebarOpen);

  // 資料夾相關
  const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as NoteFolder[];
  const updateNoteFolder = useNoteStore(state => state.updateNoteFolder);
  const getFolderType = useNoteStore(state => state.getFolderType);


  // 手機版更多選單狀態
  const moreMenu = useMenuStore(state => state.menus['noteListTopbarMore']);


  const currentFolder = useMemo(() => {
    if (!selectedFolderId) return null;
    if (selectedFolderId === '__shared_notes__') return { id: '__shared_notes__', name: 'sharedNotes' } as any;
    return noteFolders.find(f => f.id === selectedFolderId) || null;
  }, [selectedFolderId, noteFolders]);

  const currentFolderName = currentFolder?.name ?? 'inbox';

  // 判斷是否為系統資料夾（inbox, trash 不能編輯/刪除）
  const isSystemFolder = currentFolderName === 'inbox' || currentFolderName === 'trash';

  // 判斷是否為群組
  const folderType = useMemo(() => {
    if (!selectedFolderId) return { isGroup: false };
    return getFolderType(selectedFolderId);
  }, [selectedFolderId, getFolderType]);

  // 處理特殊資料夾名稱的翻譯
  const getDisplayFolderName = (folderName) => {
    if (folderName === 'inbox' || folderName === 'trash' || folderName === 'todoInbox' || folderName === 'sharedNotes') {
      return t(folderName);
    }
    return folderName;
  };

  // 處理編輯資料夾
  const handleEditFolder = async (newName: string) => {
    if (!currentFolder) return;

    await updateNoteFolder({
      id: currentFolder.id,
      name: newName,
    });
  };

  // 處理刪除資料夾
  const handleDeleteFolder = () => {
    if (!currentFolder) return;

    useDialogStore.getState().open('deleteFolder', {
      folder: {
        ...currentFolder,
        isGroup: folderType.isGroup
      }
    });
  };

  // 手機版頂部標題列
  if (isMobileView) {
    return (
      <>
        <MobileTopbar
          leftIcon="menu"
          onLeftClick={() => setIsMobileSidebarOpen(true)}
          title={getDisplayFolderName(currentFolderName)}
          titleSuffix={currentFolder && (
            <ShareMemberThumbnailList itemId={currentFolder.id} permissions={currentFolder._permissions || []} size="small" maxDisplay={5} />
          )}
          rightContent={
            !isSystemFolder && currentFolder && (
              <button
                className="mobile-topbar-button"
                tabIndex={-1}
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  useMenuStore.getState().openAt('noteListTopbarMore', rect.right, rect.bottom + 4);
                }}
              >
                <MoreIcon />
              </button>
            )
          }
        />

        {/* 手機版更多選單 */}
        {moreMenu?.show && (
          <PopupMenu
            x={moreMenu.position.x}
            y={moreMenu.position.y}
            onClose={() => useMenuStore.getState().close('noteListTopbarMore')}
          >
            <PopupMenuItem
              icon={EditIcon}
              onClick={() => {
                useMenuStore.getState().close('noteListTopbarMore');
                useDialogStore.getState().open('editFolder', {
                  title: folderType.isGroup ? t('editGroup') : t('editNotebook'),
                  initialName: currentFolder?.name || '',
                  existingNames: noteFolders
                    .filter(f => f.itemType === 'NOTE_FOLDER' && f.name?.toLowerCase() !== currentFolder?.name?.toLowerCase())
                    .map(f => f.name || '').filter(Boolean),
                  placeholder: folderType.isGroup ? t('groupNamePlaceholder') : t('notebookNamePlaceholder'),
                  onConfirm: handleEditFolder,
                });
              }}
            >
              {folderType.isGroup ? t('editNotebookGroupName') : t('editNotebook')}
            </PopupMenuItem>
            <PopupMenuItem
              icon={DeleteIcon}
              danger
              onClick={() => {
                useMenuStore.getState().close('noteListTopbarMore');
                handleDeleteFolder();
              }}
            >
              {folderType.isGroup ? t('deleteNotebookGroup') : t('deleteNotebook')}
            </PopupMenuItem>
          </PopupMenu>
        )}

        {/* NameInputDialog 已改為 NotePlugin overlay 掛載 */}
      </>
    );
  }

  // 桌面版頂部標題列
  return (
    <CustomToolbar
      left={{ prefix: (
        <>
          <span className="notelist-topbar-title">{getDisplayFolderName(currentFolderName)}</span>
          {currentFolder && (
            <ShareMemberThumbnailList itemId={currentFolder.id} permissions={currentFolder._permissions || []} maxDisplay={10} />
          )}
        </>
      ) }}
    />
  );
}

export default NoteListTopbar; 
