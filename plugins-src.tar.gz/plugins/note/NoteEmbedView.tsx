// NoteEmbedView — Note 插件的嵌入式預覽渲染器
//
// 由 NotePlugin 註冊到 EmbedRendererRegistry，
// 被 ItemEmbedExtension（editor 基礎設施）委派渲染。

import React, { useMemo } from 'react';
import NoteItem from './NoteItem';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useNoteStore, type Note } from './noteStore';
import { useItemStore } from '../../../Store/itemStore';
import { getWorkspace } from '../../../workspace/Workspace';
import type { EmbedRendererProps } from '../../../Store/embedRendererRegistry';

const createNoteHandlers = (noteId: string, updateNote) => ({
  handleDragStart: () => { },
  handleDragOver: () => { },
  handleDrop: () => { },
  handleDragEnd: () => { },
  handleDragLeave: () => { },
  handleNoteClick: (e) => {
    const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
    const note = notes.find(n => n.id === noteId);
    if (!note) return;

    if (e?.currentTarget?.closest('.ai-admin-room')) {
      getWorkspace()?.openWindow({ id: noteId, itemType: 'NOTE' });
      return;
    }

    let targetFolderId = note.parentID;
    if (note.parentID && !targetFolderId) {
      const parent = notes.find(n => n.id === note.parentID);
      if (parent) targetFolderId = parent.parentID;
    }
    useSelectedItemsStore.getState().setSelectedItems(
      [note],
      { scrollToFocusItem: !!targetFolderId, scrollToNote: true, highlightItemId: noteId }
    );
  },
  handleContextMenu: () => { },
  handleCheckboxClick: () => { },
  handleInputChange: () => { },
  handleInputKeyDown: () => { },
  handleInputFocus: () => { },
  handleReminderClick: () => { },
  handleDeleteReminder: () => { }
});

const NoteEmbedView: React.FC<EmbedRendererProps> = ({ itemId }) => {
  const allSelected = useSelectedItemsStore(state => [state.path.at(-1), ...state.extraItems].filter(Boolean) as any[]);
  const updateNote = useNoteStore(state => state.updateNote);
  const handlers = useMemo(() => createNoteHandlers(itemId, updateNote), [itemId, updateNote]);

  return (
    <NoteItem
      noteId={itemId}
      isTempFolder={false}
      isInChatRoom={true}
      selectedItems={allSelected}
      dropTarget={null}
      dropPosition={null}
      isShiftPressed={false}
      isCommandPressed={false}
      currentTime={new Date()}
      titleInputRefs={null}
      handlers={handlers}
      noteUpdateRefs={null}
      onRestore={() => { }}
    />
  );
};

export default NoteEmbedView;
