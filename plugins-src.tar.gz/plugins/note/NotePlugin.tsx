// ===== NotePlugin — 筆記插件（含 NoteList + NoteEditor）=====
//
// 掛載條件：selectedItems 最後一項的 itemType 是 NOTE_FOLDER 或 NOTE
// 或 selectedItems 為空（預設視圖）
//
// 面板配置：
//   centerPane1 → leaf-notelist  (note-list，size:350，min:240)
//   centerPane2 → leaf-noteeditor (note-editor，flex:1，min:360)

import React from 'react';
import './NoteSidebar.css';
import { useTranslation } from 'react-i18next';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import noteEn from './locales/en.json';
import noteZhHant from './locales/zh-Hant.json';
import noteJa from './locales/ja.json';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { useNoteStore, type Note, type NoteFolder } from './noteStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { useTempHintStore, useIsConnectedStore } from '../../../Store/uiStore';
import { uploadFile } from '../../../utils/fileUpload';
import { imgUrlToTheme } from './ai/noteAI';
import i18n from '../../../i18n/config';
import { useCommandManager } from '../../../Store/commandManager';
import { eventBus } from '../../../Store/eventBus';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import type { BaseItem } from '../../../types/item';

import NotebookFolderIcon from '../../../assets/icon_notebook_folder_24.svg?react';
import FolderIcon from '../../../assets/icon_notebook_folder_24.svg?react';
import InboxIcon from '../../../assets/icon_classification_24.svg?react';
import NoteIcon from '../../../assets/icon_note_24.svg?react';
import SharedFolderIcon from '../../../assets/icon_lucide_share_2_24.svg?react';
import { processItemContent } from '../../../utils/textUtils';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';

import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';
import NameInputDialog from '../../common/NameInputDialog';
import SharingDialog from '../../common/share/SharingDialog';
import ContributorsDialog from '../../common/share/ContributorsDialog';
import { updateItemShareSettings } from '../../../utils/shareAPI';
import syncService from '../../../utils/syncService';
import { canManageMembers, canAccessSharingDialog, isAlreadyShared, canEdit, canDelete, getEffectivePermission, hasDirectPermission } from '../../../utils/shareUtils';
import { ShareMemberThumbnailList } from '../../common/share/ShareMemberThumbnailList';
import { CustomDialog } from '../../common/CustomDialog';
import NoteList from './NoteList';
import NoteEmbedView from './NoteEmbedView';
import { useEmbedRendererRegistry } from '../../../Store/embedRendererRegistry';
// import { MergeNoteSuggesterExtension } from './MergeNoteSuggesterExtension';
import { registerWindowComponent } from '../../../workspace/windowComponentRegistry';
import NoteWindowContent from './NoteWindowContent';
import SetReminderTimeDialog from '../editor/SetReminderTimeDialog';
import EditNoteTagDialog from '../editor/EditNoteTagDialog';
import AudioTranscriptDialog from '../editor/AudioTranscriptDialog';
import EditIndexCategoryDialog from './EditIndexCategoryDialog';
import AddSubCategoryDialog from './AddSubCategoryDialog';
import EditFolderSummaryDialog from './EditFolderSummaryDialog';
import EditFolderNameDialog from '../../common/EditFolderNameDialog';

const NoteContextMenu: React.FC = () => {
    const menu = useMenuStore(state => state.menus['sidebarFolder']);
    const { t } = useTranslation();
    if (!menu?.show) return null;

    const close = () => useMenuStore.getState().close('sidebarFolder');
    const folder = menu.data?.folder;
    const isGroup = menu.data?.isGroup;

    const handleEdit = () => {
        useDialogStore.getState().open('addFolder', { folder: { ...folder, isGroup } });
        close();
    };
    const handleDelete = () => {
        if (isGroup) {
            useDialogStore.getState().open('sidebar:deleteGroup', { folder });
        } else {
            useDialogStore.getState().open('deleteFolder', { folder });
        }
        close();
    };
    const handleCreateIn = () => {
        useDialogStore.getState().open('addFolder', { targetFolder: folder });
        close();
    };
    const handleShareFolder = () => {
        if (!folder) return;
        useDialogStore.getState().open('sharing', {
            item: { id: folder.id, name: folder.name, isPublic: folder.isPublic, itemType: folder.itemType },
            onSave: async (settings) => {
                await updateItemShareSettings({ ...settings, extra: {} });
                await syncService.syncChanges();
                useTempHintStore.getState().setTempHint(settings.isPublic ? i18n.t('shareEnabled') : i18n.t('shareDisabled'));
            },
        });
        close();
    };

    return (
        <PopupMenu x={menu.position.x} y={menu.position.y} onClose={close}>
            {isGroup && (
                <PopupMenuItem onClick={handleCreateIn}>
                    {t('createNotebookIn', { name: folder?.name })}
                </PopupMenuItem>
            )}
            {isGroup && (canManageMembers(folder) || hasDirectPermission(folder)) && (
                <PopupMenuItem onClick={handleShareFolder}>
                    {canManageMembers(folder)
                        ? (isAlreadyShared(folder) ? t('editShareSettings') : t('shareThisFolder'))
                        : t('shareSettings')}
                </PopupMenuItem>
            )}
            {canEdit(folder) && (
                <PopupMenuItem onClick={handleEdit}>
                    {t('editNotebook')}
                </PopupMenuItem>
            )}
            {getEffectivePermission(folder) === 'owner' && (
                <PopupMenuItem onClick={handleDelete}>
                    {t('deleteNotebook')}
                </PopupMenuItem>
            )}
        </PopupMenu>
    );
};

const NoteAddFolderDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['addFolder']?.show);
    const dialogData = useDialogStore(state => state.dialogs['addFolder']?.data);
    const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('./noteStore').NoteFolder[];

    const isNote = dialogData?.mode === 'note'
        || dialogData?.folder?.itemType === 'NOTE_FOLDER'
        || dialogData?.targetFolder?.itemType === 'NOTE_FOLDER';

    if (!showDialog || !isNote) return null;

    const editFolder = dialogData?.folder;
    const targetFolder = dialogData?.targetFolder;
    const isEdit = !!editFolder;
    const isGroup = !!editFolder?.isGroup || !!targetFolder;

    const handleClose = () => useDialogStore.getState().close('addFolder');

    // 重名檢查：排除當前編輯的資料夾名（如果是編輯模式）
    const existingNames = noteFolders
        .filter(f => f.itemType === 'NOTE_FOLDER')
        .filter(f => !(isEdit && f.name?.toLowerCase() === editFolder?.name?.toLowerCase()))
        .map(f => f.name || '')
        .filter(Boolean);

    const handleConfirm = async (folderName: string) => {
        if (editFolder) {
            const updated = { ...editFolder, name: folderName };
            if (editFolder.isTemp) updated.isTemp = false;
            await useItemStore.getState().upsertItem({ ...updated, itemType: 'NOTE_FOLDER' }, { needSync: true });
        } else if (targetFolder) {
            const newFolder = {
                id: generateObjectID(),
                name: folderName,
                parentID: targetFolder.id,
            };
            await useNoteStore.getState().addNoteFolder(newFolder);

            const added = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === newFolder.id);
            if (added) {
                useSelectedItemsStore.getState().setSelectedItems([added as BaseItem]);
                eventBus.emit('sidebar:folder-select', { folderId: added.id });
            }
        } else {
            const newFolder = {
                id: generateObjectID(),
                name: folderName,
            };
            await useNoteStore.getState().addNoteFolder(newFolder);

            const added = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === newFolder.id);
            if (added) {
                useSelectedItemsStore.getState().setSelectedItems([added as BaseItem]);
                eventBus.emit('sidebar:folder-select', { folderId: added.id });
            }
        }
    };

    const title = isEdit
        ? (isGroup ? t('editGroup') : t('editNotebook'))
        : (isGroup ? t('newGroupName') : t('newNotebookNameTitle'));

    return (
        <NameInputDialog
            title={title}
            initialName={editFolder?.name || ''}
            existingNames={existingNames}
            placeholder={isGroup ? t('groupNamePlaceholder') : t('notebookNamePlaceholder')}
            onConfirm={handleConfirm}
            onClose={handleClose}
            tips={!isEdit && !isGroup ? [t('dragToMove'), t('rightClickToEdit')] : undefined}
        />
    );
};

const NoteDeleteFolderDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['deleteFolder']?.show);
    const folder = useDialogStore(state => state.dialogs['deleteFolder']?.data?.folder);

    if (!showDialog || !folder || folder.itemType !== 'NOTE_FOLDER') return null;

    const hideDialog = () => useDialogStore.getState().close('deleteFolder');

    const handleConfirm = async () => {
        try {
            await useNoteStore.getState().deleteNoteFolder([folder.id]);
            useTempHintStore.getState().setTempHint(t('deletedNotebook', { name: folder.name }));
            hideDialog();
        } catch (error) {
            console.error('刪除失敗:', error);
            useTempHintStore.getState().setTempHint(t('deleteFailed'));
        }
    };

    return (
        <CustomDialog isOpen onClose={hideDialog} title={t('deleteNotebook')} onConfirm={handleConfirm}>
            <p className="custom-dialog-description">
                {t('deleteNotebookConfirm', { name: folder.name })}
            </p>
        </CustomDialog>
    );
};

// ⚠️ Sidebar item 規範：所有 item（items / prefixItems / suffixItems）的 itemType 必須以 _FOLDER 結尾，否則不會顯示
function useNoteSidebarData() {
    const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('./noteStore').NoteFolder[];
    const notes = useItemStore(s => s.byType['NOTE'] ?? []) as Note[];
    const myMemberID = React.useMemo(() => {
        try { return JSON.parse(localStorage.getItem('userData_local') || '{}').ID || ''; } catch { return ''; }
    }, []);

    const items = React.useMemo(
        () => noteFolders.filter(f => f.itemType === 'NOTE_FOLDER' && f.name !== 'inbox' && f.name !== 'trash'),
        [noteFolders],
    );
    const prefixItems = React.useMemo(() => {
        const inbox = noteFolders.find(f => f.name === 'inbox');
        return inbox ? [inbox] : undefined;
    }, [noteFolders]);

    const sharedNoteCount = React.useMemo(() => {
        const allNoteFolders = useItemStore.getState().getByType('NOTE_FOLDER');
        const folderIdSet = new Set(allNoteFolders.map(f => f.id));
        return notes.filter(n => {
            if (n.isDeleted) return false;
            if (n.parentID) {
              const parent = useItemStore.getState().itemMap.get(n.parentID);
              if (parent && parent.itemType === 'NOTE') return false;
            }
            // 有 parentID 且該資料夾存在於本地 → 不是游離筆記
            if (n.parentID && folderIdSet.has(n.parentID)) return false;
            const myPerm = (n as any)._permissions?.find((p: any) => p.user_id === myMemberID);
            return myPerm && myPerm.permission !== 'owner';
        }).length;
    }, [notes, myMemberID]);

    const trashFolder = React.useMemo(
        () => noteFolders.find(f => f.name === 'trash'),
        [noteFolders],
    );

    const suffixItems = React.useMemo(() => {
        const result: BaseItem[] = [];
        if (sharedNoteCount > 0) {
            result.push({ id: '__shared_notes__', name: 'sharedNotes', itemType: 'NOTE_SHARED_FOLDER' } as BaseItem);
        }
        if (trashFolder) {
            result.push(trashFolder);
        }
        return result;
    }, [sharedNoteCount, trashFolder]);

    const getCount = React.useCallback((item: BaseItem) => {
        if (trashFolder && item.id === trashFolder.id) {
            return { value: notes.filter(n => n.isDeleted === true).length };
        }
        if (item.id === '__shared_notes__') {
            return { value: sharedNoteCount, pinned: true };
        }
        const count = notes.filter(n => !n.isDeleted && n.parentID === item.id).length;
        return count != null ? { value: count } : null;
    }, [notes, sharedNoteCount, trashFolder]);

    const renderIcon = React.useCallback((item: BaseItem) => {
        if (item.name === 'inbox') return <InboxIcon className="folder-icon" />;
        if (item.name === 'trash') return <DeleteIcon className="folder-icon" style={{ color: 'var(--error)' }} />;
        if (item.id === '__shared_notes__') return <SharedFolderIcon className="folder-icon" />;
        return <NotebookFolderIcon className="folder-icon" />;
    }, []);

    const { t } = useTranslation();

    const getDisplayName = React.useCallback((item: BaseItem) => {
        if (item.name === 'trash') return <span className="trash-folder-name">{t(item.name)}</span>;
        if (item.name === 'inbox') return t(item.name);
        if (item.id === '__shared_notes__') return t('sharedNotes');
        return item.name;
    }, [t]);

    return { items, prefixItems, suffixItems, getCount, renderIcon, getDisplayName };
}

class NoteListView extends ReactView {
    getViewType() { return 'note-list'; }
    getDisplayText() { return '筆記列表'; }
    renderComponent() { return <NoteList />; }
}

export class NotePlugin extends Plugin {
    onload() {
        this.registerWindowView('NOTE', 'note-editor', {
            width: 1200, height: 900, minWidth: 600, minHeight: 500,
        }, (itemId) => useNoteStore.getState().clearNoteIsNew(itemId));

        // 註冊 Plugin 專屬 overlay

        this.registerOverlay('noteContextMenu', NoteContextMenu);
        this.registerOverlay('noteAddFolderDialog', NoteAddFolderDialog);
        this.registerOverlay('noteDeleteFolderDialog', NoteDeleteFolderDialog);
        this.registerOverlay('setReminderTimeDialog', SetReminderTimeDialog);
        this.registerOverlay('sharingDialog', SharingDialog);
        this.registerOverlay('contributorsDialog', ContributorsDialog);
        this.registerOverlay('editNoteTagDialog', EditNoteTagDialog);
        this.registerOverlay('audioTranscriptDialog', AudioTranscriptDialog);
        this.registerOverlay('editCategoryDialog', EditIndexCategoryDialog);
        this.registerOverlay('addSubCategoryDialog', AddSubCategoryDialog);
        this.registerOverlay('editSummaryDialog', EditFolderSummaryDialog);
        this.registerOverlay('editFolderNameDialog', EditFolderNameDialog);

        // 註冊嵌入式預覽渲染器（給 ItemEmbedExtension 用）
        useEmbedRendererRegistry.getState().register('NOTE', { component: NoteEmbedView });
        this.register(() => useEmbedRendererRegistry.getState().unregister('NOTE'));

        this.registerSidebarWithView({
            sidebar: {
                id: 'note',
                title: i18n.t('sidebarNotes'),
                orderAt: 300,
                useData: useNoteSidebarData,
                addFolder: {
                    actionText: i18n.t('addNoteFolder'),
                    icon: <FolderIcon />,
                    onClick: () => useDialogStore.getState().open('addFolder', { mode: 'note' }),
                },
            },
            views: [
                { type: 'note-list', creator: (leaf) => new NoteListView(leaf) },
            ],
            activateOnItemTypes: ['NOTE_FOLDER', 'NOTE', 'NOTE_TRASH_FOLDER', 'NOTE_SHARED_FOLDER'],
            isDefault: true,
            panes: {
                centerPane1: { leafId: 'leaf-notelist', viewType: 'note-list', size: 350, minSize: 240 },
                centerPane2: { leafId: 'leaf-noteeditor', viewType: 'note-editor', flex: 1, minSize: 360 },
            },
        });

        // 預註冊 command schemas（設定頁不依賴元件 mount；無 handler → 僅寫 schema）
        const cm = useCommandManager.getState();
        cm.register({ command: { id: 'note:create', name: i18n.t('cmd.createNote') }, hotkeys: [{ modifiers: [], key: 'Enter' }] });
        cm.register({ command: { id: 'note-list:select-all', name: i18n.t('cmd.selectAllNotes') }, hotkeys: [{ modifiers: ['Mod'], key: 'a' }] });
        cm.register({ command: { id: 'note-list:delete', name: i18n.t('cmd.deleteSelectedNotes') }, hotkeys: [{ modifiers: ['Mod'], key: 'Delete' }, { modifiers: ['Mod'], key: 'Backspace' }] });
        cm.register({ command: { id: 'note-list:escape', name: i18n.t('cmd.noteListBack') }, hotkeys: [{ modifiers: [], key: 'Escape' }] });
        cm.register({ command: { id: 'note-list:arrow-left', name: i18n.t('cmd.noteListLeft') }, hotkeys: [{ modifiers: [], key: 'ArrowLeft' }] });
        cm.register({ command: { id: 'note-list:arrow-right', name: i18n.t('cmd.noteListRight') }, hotkeys: [{ modifiers: [], key: 'ArrowRight' }] });
        cm.register({ command: { id: 'note-list:arrow-up', name: i18n.t('cmd.noteListUp') }, hotkeys: [{ modifiers: [], key: 'ArrowUp' }] });
        cm.register({ command: { id: 'note-list:arrow-down', name: i18n.t('cmd.noteListDown') }, hotkeys: [{ modifiers: [], key: 'ArrowDown' }] });
        cm.register({ command: { id: 'note-list:shift-arrow-up', name: i18n.t('cmd.noteListShiftUp') }, hotkeys: [{ modifiers: ['Shift'], key: 'ArrowUp' }] });
        cm.register({ command: { id: 'note-list:shift-arrow-down', name: i18n.t('cmd.noteListShiftDown') }, hotkeys: [{ modifiers: ['Shift'], key: 'ArrowDown' }] });

        // 註冊搜尋 provider
        this.registerSearchProvider('NOTE', {
            renderIcon: () => <NoteIcon />,
            search: (query) => {
                const notes = useItemStore.getState().getByType('NOTE');
                const q = query.toLowerCase();
                return notes.filter(n => {
                    if (!query) return true;
                    if (n.name?.toLowerCase().includes(q)
                        || (n as any).aiTitle?.toLowerCase().includes(q)
                        || processItemContent(n, true).toLowerCase().includes(q)) return true;
                    const tags = (n as any).tags;
                    if (!tags) return false;
                    try {
                        const parsed = typeof tags === 'string' ? JSON.parse(tags) : tags;
                        if (!Array.isArray(parsed)) return false;
                        return parsed.some((t: string) => t.toLowerCase().includes(q));
                    } catch { return false; }
                });
            },
        });
        this.registerSearchProvider('NOTE_FOLDER', {
            renderIcon: (item) => item.name === 'inbox' ? <InboxIcon /> : <FolderIcon />,
            search: (query) => {
                const noteFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
                const q = query.toLowerCase();
                return noteFolders.filter(f => {
                    if (f.name === 'inbox' || f.name === 'trash') return false;
                    return !query || f.name?.toLowerCase().includes(q);
                });
            },
        });



        // 鍵盤刪除資料夾（由 Sidebar 發 eventBus）
        this.registerEvent('sidebar:delete-folder', ({ folderId }: { folderId: string }) => {
            const folder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === folderId);
            if (!folder) return;
            if (folder.name === 'inbox' || folder.name === 'trash') return;
            useDialogStore.getState().open('deleteFolder', { folder });
        });

        // 右鍵選單
        this.registerEvent('contextMenu', ({ item, event }: { item: BaseItem; event: React.MouseEvent }) => {
            if (item.itemType !== 'NOTE_FOLDER') return;
            const name = (item as NoteFolder).name;
            if (name === 'inbox' || name === 'trash') return;
            const scale = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim()) || 1;
            const { getFolderType } = useNoteStore.getState();
            const folderType = getFolderType(item.id);
            useMenuStore.getState().openAt('sidebarFolder', event.clientX / scale, event.clientY / scale, {
                isGroup: folderType.isGroup, folder: item,
            });
        });

        // === 從 App.tsx 遷入的 IPC 監聽 ===

        // onOpenNote：從主進程接收 noteId → 導航到該筆記
        if (window.electronAPI?.onOpenNote) {
            const unsubscribe = window.electronAPI.onOpenNote(async (noteId: string) => {
                const note = await window.electronAPI.getItem(noteId);
                if (!note) {
                    console.error('找不到目標筆記:', noteId);
                    return;
                }

                useSelectedItemsStore.getState().setSelectedItems([note], {
                    scrollToFocusItem: true, highlightItemId: noteId,
                });
            });
            if (typeof unsubscribe === 'function') {
                this.register(unsubscribe as () => void);
            }
        }

        // onRefreshNotes：從主進程刷新筆記列表
        if (window.electronAPI?.onRefreshNotes) {
            window.electronAPI.onRefreshNotes(() => {
                useNoteStore.getState().loadNotes();
            });
        }

        // === 截圖處理（從 App.tsx 遷入） ===

        const handleAutoSaveScreenshot = async (imageData: string, destFolderId: string | null = null, showHint = true, customTime: number | null = null) => {
            try {
                const res = await fetch(imageData);
                const blob = await res.blob();
                const file = new File([blob], `screenshot-${generateObjectID()}.png`, { type: 'image/png', lastModified: Date.now() });

                const userData = JSON.parse(localStorage.getItem('userData_local') as string) || {};
                const memberID = userData.ID || 'unknown';

                let remoteUrl: string | null = null;
                let localImages: string[] | null = null;
                let themeText: string | null = null;

                const isConnected = useIsConnectedStore.getState().isConnected;
                if (isConnected) {
                    try {
                        const uploadResult = await uploadFile(file, memberID, 'images', {
                            maxWidth: 1920, maxHeight: 1080, quality: 0.8, maxSizeKB: 1024
                        });
                        if (uploadResult?.downloadURL) {
                            remoteUrl = uploadResult.downloadURL;
                            try {
                                const themeRes = await imgUrlToTheme(remoteUrl);
                                themeText = themeRes?.theme || null;
                            } catch (err) {
                                console.error('圖像主題辨識失敗', err);
                            }
                        }
                    } catch (err) {
                        console.error('圖片上傳失敗，改用本地儲存', err);
                        localImages = [imageData];
                    }
                } else {
                    localImages = [imageData];
                }

                if (!remoteUrl && !localImages) {
                    localImages = [imageData];
                }

                if (!destFolderId) {
                    const noteFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
                    const f = noteFolders.find(f => f.name === 'inbox');
                    destFolderId = f ? f.id : null;
                }

                const now = customTime || Date.now();
                const formattedDate = new Date(now).toLocaleString();

                let aiTitleForNote = themeText ? themeText : null;
                let reminderTimeForNote: number | null = null;

                if (aiTitleForNote) {
                    const timeRegex = /\s+(\d{4})\/(\d{1,2})\/(\d{1,2})\s+(\d{1,2}):(\d{2})$/;
                    const timeMatch = aiTitleForNote.match(timeRegex);
                    if (timeMatch) {
                        const [, year, month, day, hour, minute] = timeMatch;
                        aiTitleForNote = aiTitleForNote.replace(timeRegex, '').trim();
                        try {
                            const reminderDate = new Date(
                                parseInt(year), parseInt(month) - 1, parseInt(day),
                                parseInt(hour), parseInt(minute)
                            );
                            if (!isNaN(reminderDate.getTime())) {
                                reminderTimeForNote = reminderDate.getTime();
                            }
                        } catch (error) {
                            console.error('解析提醒時間失敗:', error);
                        }
                    }
                }

                const noteId = generateObjectID();
                const contentHtml = `<img src="${remoteUrl || localImages![0]}" alt="截圖 ${formattedDate}" />`;

                const note = {
                    id: noteId,
                    parentID: destFolderId,
                    name: '',
                    aiTitle: aiTitleForNote,
                    content: contentHtml,
                    createdAt: now,
                    updatedAt: now,
                    imgURLs: remoteUrl ? [remoteUrl] : null,
                    imgTexts: ['imgText'],
                    imageUrl_local: localImages,
                    reminderTime: reminderTimeForNote,
                };

                await useNoteStore.getState().addNote(note, true);

                if (destFolderId) {
                    const folder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === destFolderId);
                    if (folder) useSelectedItemsStore.getState().setSelectedItems([folder], { scrollToFocusItem: true });
                }
                setTimeout(() => {
                    const savedNote = (useItemStore.getState().getByType('NOTE') as Note[]).find(n => n.id === noteId);
                    if (savedNote) useSelectedItemsStore.getState().setSelectedItems([savedNote], { scrollToFocusItem: true, highlightItemId: noteId });
                }, 100);

                if (showHint) {
                    useTempHintStore.getState().setTempHint(i18n.t('screenshotSaved'));
                }
            } catch (error) {
                console.error('自動保存截圖失敗:', error);
            }
        };

        // 監聽主進程的截圖事件
        if (window.electronAPI?.onAutoSaveScreenshot) {
            window.electronAPI.onAutoSaveScreenshot((imageData: string) => {
                handleAutoSaveScreenshot(imageData);
            });
        }

        // 暴露到全域供工具列等元件使用
        (window as any).handleAutoSaveScreenshot = handleAutoSaveScreenshot;
        this.register(() => { delete (window as any).handleAutoSaveScreenshot; });

    }
}

registerWindowComponent('note-editor', NoteWindowContent);
registerPluginClass(NotePlugin, '筆記', {
    dependencies: ['SidebarPlugin', 'EditorPlugin'],
    descriptionKey: 'modulesNoteDesc',
    setupI18n: () => registerPluginLocales('NotePlugin', { 'en': noteEn, 'zh-Hant': noteZhHant, 'ja': noteJa }),
});
