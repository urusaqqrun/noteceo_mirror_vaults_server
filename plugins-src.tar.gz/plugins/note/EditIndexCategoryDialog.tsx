import React, { useState, useEffect, useRef } from 'react';
import './EditIndexCategoryDialog.css';
import { useTheme } from '../../setting/ThemeProvider';
import { useTranslation } from 'react-i18next';
import RefreshDark from '../../../assets/bk_refresh_dark.svg?react';
import RefreshLight from '../../../assets/bk_refresh_light.svg?react';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

interface EditIndexCategoryDialogData {
  initialName: string;
  existingNames: string[];
  isRefreshing?: boolean;
  onConfirm: (name: string) => void;
  onRefresh?: () => Promise<string | null>;
}

function EditIndexCategoryDialog() {
  const { t } = useTranslation();
  const isOpen = useDialogStore(state => state.dialogs['editCategory']?.show);
  const dialogData = useDialogStore(state => state.dialogs['editCategory']?.data) as EditIndexCategoryDialogData | null;
  const close = () => useDialogStore.getState().close('editCategory');

  const initialName = dialogData?.initialName ?? '';
  const existingNames = dialogData?.existingNames ?? [];
  const isRefreshing = dialogData?.isRefreshing ?? false;
  const onConfirm = dialogData?.onConfirm ?? null;
  const onRefresh = dialogData?.onRefresh ?? null;

  const [categoryName, setCategoryName] = useState(initialName);
  const [isComposing, setIsComposing] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const { mode } = useTheme();

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
    setCategoryName(initialName);
    setError('');
  }, [isOpen, initialName]);

  const handleSubmit = () => {
    const trimmedName = categoryName.trim();
    if (!trimmedName) {
      setError(t('subCategoryNameEmpty'));
      return;
    }

    // 檢查是否與其他板塊名稱重複（排除當前正在編輯的名稱）
    const isDuplicate = existingNames.some(
      name => name !== initialName && name === trimmedName
    );
    if (isDuplicate) {
      setError(t('subCategoryNameDuplicate'));
      return;
    }

    if (!isComposing) {
      onConfirm?.(trimmedName);
      close();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.nativeEvent.isComposing && !isComposing) {
      e.preventDefault();
      e.stopPropagation();
      handleSubmit();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      close();
    }
  };

  if (!isOpen) return null;

  return (
    <CustomDialog
      isOpen={isOpen}
      onClose={close}
      title={t('editSubCategoryName')}
      className="edit-index-dialog"
    >
      <div className="edit-index-dialog-input-row">
        <input
          ref={inputRef}
          type="text"
          className="custom-dialog-input"
          value={categoryName}
          onChange={(e) => setCategoryName(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={t('subCategoryNamePlaceholder')}
          onCompositionStart={() => setIsComposing(true)}
          onCompositionEnd={() => setIsComposing(false)}
        />
        <button
          className={`edit-index-dialog-refresh-button ${isRefreshing ? 'refreshing' : ''}`}
          onClick={async () => {
            if (onRefresh) {
              const newName = await onRefresh();
              if (newName) {
                setCategoryName(newName);
              }
            }
          }}
          disabled={isRefreshing}
          title={t('refreshSubCategoryName')}
        >
          {mode === 'dark' ? <RefreshDark /> : <RefreshLight />}
        </button>
      </div>

      {error && <div className="custom-dialog-error">{error}</div>}

      <div className="custom-dialog-buttons">
        <button
          className="custom-secondary-button"
          onClick={close}
        >
          {t('cancel')}
        </button>
        <button
          className="custom-primary-button"
          onClick={handleSubmit}
          disabled={!categoryName.trim() || isComposing}
        >
          {t('confirm')}
        </button>
      </div>
    </CustomDialog>
  );
}

export default EditIndexCategoryDialog;
