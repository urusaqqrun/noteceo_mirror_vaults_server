import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import useWhyDidYouUpdate from '../../../utils/useWhyDidYouUpdate';
import { useTimeout, useInterval } from '../../../hooks/useTimeout';
import './NoteList.css';
import { useCommandManager } from '../../../Store/commandManager';
import { useListKeyboardNav } from '../../../hooks/useListKeyboardNav';
import EditIcon from '../../../assets/icon_edit_24.svg?react';


import { formatTimestamp } from '../../Utils/dateFormat';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { useShallow } from 'zustand/react/shallow';

import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { useMaterialModeStore } from '../editor/editorStore';

import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { useNoteStore, type Note, type NoteFolder } from './noteStore';

import { useTempHintStore, useIsConnectedStore, useMergedNoteStore, usePressedKeyStore } from '../../../Store/uiStore';

import i18n from '../../../i18n/config';
import { eventBus } from '../../../Store/eventBus';
import { NoteRightClickMenu } from './NoteRightClickMenu';
import DragOverlay from '../../common/DragOverlay';
import CustomHint from '../../common/CustomHint';
import NoteItem from './NoteItem';
import { mergeNotes } from '../../../utils/mergeNotesUtil';
import NoteListTopbar from './NoteListTopbar';
import NoteListToolBar from './NoteListToolBar';
import CustomScrollbar from '../../common/CustomScrollbar';

import type { BaseItem } from '../../../types/item';

const { stripContent } = window.textUtils;

function NoteList() {
  const { t } = useTranslation();
  const { t: tSidebar } = useTranslation();

  const updateNote = useNoteStore(state => state.updateNote);
  const updateNoteWithoutUpdateAt = useNoteStore(state => state.updateNoteWithoutUpdateAt);
  const createNewNote = useNoteStore(state => state.createNewNote);

  const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as NoteFolder[];
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const noteItems = useItemStore(s => s.byType['NOTE'] ?? []);
  const notes = useMemo(() => {
    const state = useItemStore.getState();
    const trashFolder = (state.getByType('NOTE_FOLDER', true) as any[]).find(f => f.name === 'trash');
    const isTrash = !!(trashFolder && selectedFolderId === trashFolder.id);
    return isTrash
      ? (state.getByType('NOTE', true) as Note[]).filter(n => n.isDeleted === true)
      : (state.getByType('NOTE') as Note[]);
  }, [selectedFolderId, noteItems]);

  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
  const setTempHint = useTempHintStore(state => state.setTempHint);

  const removeItems = useItemStore(state => state.removeItems);
  const path = useSelectedItemsStore(state => state.path);
  const extraItems = useSelectedItemsStore(state => state.extraItems);
  const isMultiSelecting = extraItems.length > 0;
  const selectedItems = useSelectedItemsStore(useShallow(state => [state.path.at(-1), ...state.extraItems].filter(Boolean) as any[]));

  const filterVersion = useNoteStore(s => s.filterVersion);
  const filteredNotes = useMemo(() => useNoteStore.getState().getFilteredAndSortedItems(notes, selectedFolderId) as Note[], [notes, selectedFolderId, filterVersion]);
  const filteredNoteIds = useMemo(() => filteredNotes.map(n => n.id), [filteredNotes]);

  const isNoteSelected = useCallback(
    () => useSelectedItemsStore.getState().path.at(-1)?.itemType === 'NOTE',
    [],
  );

  useListKeyboardNav({
    prefix: 'note-list',
    sortedIds: filteredNoteIds,
    isActive: isNoteSelected,
    onNavigateLeft: () => useSelectedItemsStore.getState().navigateOut(),
    onNavigateRight: () => {
      const el = document.querySelector('.ProseMirror') as HTMLElement;
      el?.focus();
    },
    labels: {
      up: t('cmd.noteListUp'),
      down: t('cmd.noteListDown'),
      shiftUp: t('cmd.noteListShiftUp'),
      shiftDown: t('cmd.noteListShiftDown'),
      left: t('cmd.noteListLeft'),
      right: t('cmd.noteListRight'),
    },
  });

  const [isMerging, setIsMerging] = useState(false);
  const [mergingDots, setMergingDots] = useState('');
  const mergeAbortController = useRef(null);
  // 合併完成後的筆記 ID，用於顯示『是否滿意本次合併結果』提示
  const mergedNoteId = useMergedNoteStore(state => state.mergedNoteId);
  const isConnected = useIsConnectedStore(state => state.isConnected);

  const dragImageRef = useRef(null);
  const prevSelectedNoteIdsRef = useRef([]);
  const [currentTime, setCurrentTime] = useState(new Date());
  const noteListRef = useRef(null);
  const [isEditing, setIsEditing] = useState(false);
  const [dropTarget, setDropTarget] = useState(null);
  const [dropPosition, setDropPosition] = useState(null);
  const savedDropStateRef = useRef(null); // 儲存拖曳狀態，不觸發重新渲染
  const draggedNoteIdsRef = useRef<string[]>([]); // 當前被拖曳的 note IDs

  const titleInputRefs = useRef({});
  const noteUpdateRefs = useRef({}); // 用於存儲 NoteItem 的 setNote 函數

  const isShiftPressed = usePressedKeyStore(state => state.isShiftPressed);
  const isCommandPressed = usePressedKeyStore(state => state.isCommandPressed);
  const setIsShiftPressed = usePressedKeyStore(state => state.setIsShiftPressed);
  const setIsCommandPressed = usePressedKeyStore(state => state.setIsCommandPressed);
  const isMobileView = useIsMobileView();

  // 安全定時器 hooks - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();
  const { setInterval: safeSetInterval, clearInterval: safeClearInterval } = useInterval();

  // 添加臨時資料夾的輸入框相關狀態
  const [folderNameInput, setFolderNameInput] = useState('');
  const [noteDescriptionInput, setNoteDescriptionInput] = useState('');
  const [folderNameError, setFolderNameError] = useState('');
  const [isComposing, setIsComposing] = useState(false);

  const [autoUpdateSummary, setAutoUpdateSummary] = useState(true);
  const [autoUpdateTitle, setAutoUpdateTitle] = useState(true);


  // DragOverlay 純 UI：由拖曳方推送 overlay 的 icon/text/sourceType/metadata
  const [overlayProps, setOverlayProps] = useState<{ icon?: React.FC; text?: string; sourceType?: string; metadata?: any } | null>(null);
  useEffect(() => {
    const unsub = eventBus.on('drag:note-list-drag-overlay', (props: { icon?: React.FC; text?: string; sourceType?: string; metadata?: any } | null) => {
      setOverlayProps(props);
    });
    return unsub;
  }, []);


  // 判斷是否為臨時資料夾
  const isTempFolder = useMemo(() => {
    if (!selectedFolderId) return false;
    const currentFolder = noteFolders.find(f => f.id === selectedFolderId);
    return !!(currentFolder as any)?.isTemp;
  }, [selectedFolderId, noteFolders]);

  // EventBus: 筆記拖到 Sidebar 資料夾的 drop handler
  // Sidebar 只傳 targetFolderId，IDs 由 NoteList 的 draggedNoteIdsRef 讀取
  useEffect(() => {
    const unsub = eventBus.on('drop:sidebar-folder:notelist-noteitem', async (targetFolderId: string) => {
      if (!draggedNoteIdsRef.current.length) return;
      for (const nid of draggedNoteIdsRef.current) {
        await useNoteStore.getState().moveNoteToFolder(nid, targetFolderId);
      }
      draggedNoteIdsRef.current = [];
    });
    return unsub;
  }, []);

  // EventBus: 筆記拖到 AICommander 的 drop handler
  useEffect(() => {
    const unsub = eventBus.on('drop:ai-commander:notelist-noteitem', (e: any, addAttachment: any, attachedItems: any, inputAreaRef: any) => {
      const noteId = e.dataTransfer.getData('noteid');
      const selectedNotesStr = e.dataTransfer.getData('selectedNotes');
      if (!noteId) return;

      let noteIds: string[] = [];
      try {
        noteIds = selectedNotesStr ? JSON.parse(selectedNotesStr) : [noteId];
      } catch { noteIds = [noteId]; }

      const allNotes = (useItemStore.getState().getByType('NOTE') as Note[]);
      let hasAdded = false;
      noteIds.forEach((id: string) => {
        if (attachedItems.some((item: any) => item.id === id)) return;
        const note = allNotes.find((n: any) => n.id === id);
        if (note) {
          addAttachment(note);
          hasAdded = true;
        }
      });
      if (hasAdded && inputAreaRef.current?.closeSaveMode) {
        inputAreaRef.current.closeSaveMode();
      }
    });
    return unsub;
  }, []);

  // EventBus: 筆記拖到 NoteEditor 的 drop handler（普通筆記 → 插入連結）
  useEffect(() => {
    const unsub = eventBus.on('drop:markdown-editor', async (items, _metadata, editor, dropPos) => {
      const noteItems = items.filter((i: any) => i.itemType === 'NOTE');
      if (noteItems.length === 0 || !editor || dropPos == null) return;
      try {
        for (const item of noteItems) {
          const linkText = item.name || item.aiTitle || t('untitled');
          const noteLink = `cubelv://note/${item.id}`;
          editor.chain().insertContentAt(dropPos, {
            type: 'text',
            text: linkText,
            marks: [{ type: 'link', attrs: { href: noteLink, class: 'editor-link', target: '_blank' } }]
          }).run();
        }
      } catch (err) {
        console.error('筆記拖到MarkdownEditor失敗:', err);
      }
    });
    return unsub;
  }, [t]);

  // 自動刪除空白筆記 - 只針對當前資料夾的 prevNoteId
  useEffect(() => {
    // 取得上一個選中的筆記 ID
    const prevNoteId = prevSelectedNoteIdsRef.current[prevSelectedNoteIdsRef.current.length - 1];

    // 如果有上一個筆記且不在當前選中列表中
    if (prevNoteId && !selectedItems.some(i => i.id === prevNoteId)) {
      const prevNote = useItemStore.getState().getById(prevNoteId) as Note | undefined;

      // 確保筆記存在且屬於當前資料夾
      if (prevNote && prevNote.parentID === selectedFolderId) {
        const noTitle = !prevNote.name || prevNote.name.trim() === '';
        const noContent = !prevNote.content || prevNote.content.trim() === '' || prevNote.content === '<p></p>';
        const noAudio = (!prevNote.audioURLs || prevNote.audioURLs.length === 0) && (!prevNote.audioUrl_local || prevNote.audioUrl_local.length === 0);

        if (noTitle && noContent && noAudio) {
          // 先觸發壓扁動畫
          const noteElement = document.querySelector(`[data-id="${prevNote.id}"] .note-item`);
          if (noteElement) {
            noteElement.classList.add('notelist-collapsing');

            // 等待動畫完成後再刪除
            safeSetTimeout(() => {
              removeItems([prevNote.id], { needSync: true });
            }, 200); // 與 CSS 動畫時間一致
          } else {
            // 如果找不到元素，直接刪除
            removeItems([prevNote.id], { needSync: true });
          }
        }
      }
    }

    // 更新 ref
    prevSelectedNoteIdsRef.current = selectedItems.map(i => i.id);
  }, [selectedItems, selectedFolderId, removeItems]);




  // 當選中的資料夾改變時，更新 autoUpdateSummary 跟 autoUpdateTitle
  useEffect(() => {
    if (!selectedFolderId) return;
    const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
    const currentFolder = folders.find(f => f.id === selectedFolderId);
    if (!currentFolder) return;

    setAutoUpdateSummary(currentFolder.autoUpdateSummary ?? true);
    setAutoUpdateTitle((currentFolder as any).autoUpdateTitle ?? true);
  }, [selectedFolderId]);

  // 監聽源 isTemp 資料夾的更新事件






  useWhyDidYouUpdate('NoteList', {
    // 選擇狀態
    selectedItemIdsHash: selectedItems.map(i => i.id).join(','),
    selectedFolderId,

    // 資料夾相關
    isTempFolder,

    // 筆記相關
    filteredNoteIdsLength: filteredNoteIds.length,
    filteredNoteIdsHash: filteredNoteIds.slice(0, 10).join(','), // 只檢查前10個避免太長

    // 模式 / UI 狀態
    isEditing,

    // 同步 / 載入狀態
    isConnected,

    // 合併相關狀態
    isMerging,
    mergingDots,
    mergedNoteId,

    // 輸入狀態
    folderNameInput,
    noteDescriptionInput,
    folderNameError,

    // 設定狀態
    autoUpdateSummary,
    autoUpdateTitle,

    // 拖曳狀態
    dropTarget: dropTarget?.id,


    // 按鍵狀態
    isShiftPressed,
    isCommandPressed,

    // 時間相關
    currentTime: currentTime.getTime(),

    // 其他重要狀態
    isComposing,
  });

  useEffect(() => {
    // 監聽提醒觸發事件
    const unsubscribe = window.electronAPI.onReminderTriggered(() => {
      // 更新當前時間，這會觸發重新渲染
      setCurrentTime(new Date());
    });

    return () => {
      // 確保 unsubscribe 是一個函數才調用
      if (typeof unsubscribe === 'function') {
        (unsubscribe as () => void)();
      }
    };
  }, []);

  // Enter 新增筆記 — commandManager 統一管理（dialog 打開時自動不觸發）
  useEffect(() => {
    const isNoteListContext = () => {
      const last = useSelectedItemsStore.getState().path.at(-1);
      return !!(last && (last.itemType === 'NOTE_FOLDER' || last.itemType === 'NOTE'));
    };
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'note:create',
        name: t('cmd.createNote'),
        checkCallback: (checking: boolean) => {
          // dialog/menu 打開時不可執行
          if (document.querySelector('.custom-dialog-overlay, .custom-dialog-mobile-overlay')) return false;
          if (document.querySelector('.add-menu.active, .more-menu.active, .right-click-menu, .account-menu')) return false;
          // MaterialLibrary 打開時不可執行
          if (useMaterialModeStore.getState().showMaterialLibrary) return false;
          // 焦點在 input/textarea/contenteditable 時不可執行（讓 editor 自行處理 Enter）
          const ae = document.activeElement;
          if (ae instanceof HTMLInputElement || ae instanceof HTMLTextAreaElement || (ae as HTMLElement)?.isContentEditable) return false;
          // 沒有選中 folder 不可執行
          if (!selectedFolderId) return false;
          // 虛擬資料夾不可新增筆記
          if (selectedFolderId.startsWith('__')) return false;
          if (!checking) {
            createNewNote().then(() => {
              safeSetTimeout(() => {
                const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
                editorContent?.focus();
              }, 100);
            });
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Enter' }],
      enabled: isNoteListContext,
    });
    return unsub;
  }, [selectedFolderId, createNewNote, t]);

  // keydown/keyup — commandManager 統一管理（導航類命令已移至 useListKeyboardNav）
  useEffect(() => {
    const cm = useCommandManager.getState();

    const isNoteListContext = () => {
      const last = useSelectedItemsStore.getState().path.at(-1);
      return !!(last && (last.itemType === 'NOTE_FOLDER' || last.itemType === 'NOTE' || last.itemType === 'NOTE_TRASH_FOLDER' || last.itemType === 'NOTE_SHARED_FOLDER'));
    };

    const isNoteListActive = () => {
      if (document.activeElement !== document.body) return false;
      if (useMaterialModeStore.getState().showMaterialLibrary) return false;
      return true;
    };

    // 修飾鍵追蹤（旁路觀察，不消費事件）
    const unsubShift = cm.registerKeyObserver({
      id: 'note-list:shift',
      keys: ['Shift'],
      onDown: () => setIsShiftPressed(true),
      onUp: () => setIsShiftPressed(false),
    });
    const unsubMeta = cm.registerKeyObserver({
      id: 'note-list:meta',
      keys: ['Meta', 'Command'],
      onDown: () => setIsCommandPressed(true),
      onUp: () => setIsCommandPressed(false),
    });

    // Cmd+A 全選
    const unsubSelectAll = cm.register({
      command: {
        id: 'note-list:select-all',
        name: t('cmd.selectAllNotes'),
        checkCallback: (checking: boolean) => {
          if (!isNoteListActive() || isEditing || !selectedFolderId) return false;
          if (!checking) {
            const allIds = useNoteStore.getState().filteredNotes().map(note => note.id);
            const allItems = allIds.map(id => useItemStore.getState().getById(id)).filter(Boolean) as BaseItem[];
            setSelectedItems(allItems);
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: ['Mod'], key: 'a' }],
      enabled: isNoteListContext,
    });

    // Cmd+Delete 刪除筆記
    const unsubDelete = cm.register({
      command: {
        id: 'note-list:delete',
        name: t('cmd.deleteSelectedNotes'),
        checkCallback: (checking: boolean) => {
          if (!isNoteListActive()) return false;
          if (!selectedFolderId || !selectedItems.some(i => i.itemType === 'NOTE' || i.itemType === 'NOTE_FOLDER')) return false;
          if (!checking) {
            document.querySelectorAll('.tab-button').forEach(button => (button as HTMLElement).blur());
            handleMultipleDelete();
          }
          return true;
        },
      },
      hotkeys: [
        { modifiers: ['Mod'], key: 'Delete' },
        { modifiers: ['Mod'], key: 'Backspace' },
      ],
      enabled: isNoteListContext,
    });

    // Escape 取消選擇
    const unsubEscape = cm.register({
      command: {
        id: 'note-list:escape',
        name: t('cmd.noteListBack'),
        checkCallback: (checking: boolean) => {
          if (!isNoteListActive()) return false;
          if (!selectedFolderId || !selectedItems.some(i => i.itemType === 'NOTE')) return false;
          if (!checking) {
            document.querySelectorAll('.tab-button').forEach(button => (button as HTMLElement).blur());
            useSelectedItemsStore.getState().navigateOut();
          }
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
      enabled: isNoteListContext,
    });

    return () => {
      unsubShift();
      unsubMeta();
      unsubSelectAll();
      unsubDelete();
      unsubEscape();
    };
  }, [selectedItems, isEditing, selectedFolderId, isTempFolder, t]);


  const handleScroll = (targetId) => {
    // 如果目前為複選狀態，則不自動捲動
    if ([useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean).filter(i => i.itemType === 'NOTE').length > 1) {
      return;
    }
    // 使用 setTimeout 確保 DOM 已更新
    safeSetTimeout(() => {
      // 修改選擇器以同時支援筆記和待辦項目
      const selectedNoteElement = document.querySelector(`[data-id="${targetId}"]`);
      const listContainer = document.querySelector('.notes-list')?.parentElement;

      let scrollBehavior = 'smooth';

      if (selectedNoteElement && listContainer) {
        // 檢查是否為第一個或最後一個元素
        const isFirstElement = selectedNoteElement === listContainer.firstElementChild;
        const isLastElement = selectedNoteElement === listContainer.lastElementChild;

        if (isFirstElement) {
          // 如果是第一個元素，滾動到頂部
          listContainer.scrollTo({
            top: 0,
            behavior: scrollBehavior as ScrollBehavior
          });
        } else if (isLastElement) {
          // 如果是最後一個元素，滾動到底部
          listContainer.scrollTo({
            top: listContainer.scrollHeight,
            behavior: scrollBehavior as ScrollBehavior
          });
        } else {
          // 計算需要滾動的位置
          const containerRect = listContainer.getBoundingClientRect();
          const elementRect = selectedNoteElement.getBoundingClientRect();
          const relativeTop = elementRect.top - containerRect.top;

          // 計算容器的中心點
          const containerCenter = containerRect.height / 2;
          // 計算需要滾動的距離，使選中元素位於容器中心
          const scrollTop = listContainer.scrollTop + relativeTop - containerCenter + elementRect.height / 2;

          listContainer.scrollTo({
            top: scrollTop,
            behavior: scrollBehavior as ScrollBehavior
          });
        }
      }
    }, 50); // 添加50毫秒延遲
  };

  // 添加滑動監聽
  useEffect(() => {
    const noteItems = selectedItems.filter(i => i.itemType === 'NOTE');
    if (noteItems.length > 0) {
      // 獲取最後選擇的筆記 ID
      const lastSelectedId = noteItems.at(-1)?.id;
      const needScroll = useSelectedItemsStore.getState().navParams?.scrollToFocusItem;
      if (lastSelectedId && needScroll) {
        handleScroll(lastSelectedId);
      }
      if (isMultiSelecting) {
        safeSetTimeout(() => {
          (document.activeElement as HTMLElement)?.blur();
        }, 100);
      }
    }
  }, [selectedItems, isMultiSelecting]);

  // 添加監聽器來追蹤編輯器的焦點狀態
  useEffect(() => {
    const handleFocusChange = () => {
      const isEditorFocused = document.activeElement.classList.contains('ProseMirror');
      const isTitleFocused = document.activeElement.classList.contains('editor-title');
      setIsEditing(isEditorFocused || isTitleFocused);
    };

    document.addEventListener('focusin', handleFocusChange);
    document.addEventListener('focusout', handleFocusChange);

    return () => {
      document.removeEventListener('focusin', handleFocusChange);
      document.removeEventListener('focusout', handleFocusChange);
    };
  }, []);

  const handleDragStart = async (note, e) => {
    const noteItems = selectedItems.filter(i => i.itemType === 'NOTE');
    const filteredNotes = useNoteStore.getState().filteredNotes();
    var selectedNotes = isMultiSelecting ?
      filteredNotes.filter(n => noteItems.some(i => i.id === n.id)) :
      [note];
    // 创建拖拽预览
    const dragPreview = document.createElement('div');

    if (selectedNotes.length > 1) {
      // 多选拖拽预览（氣泡樣式，與 Sidebar 一致）
      const rootStyles = getComputedStyle(document.documentElement);
      const sidebarBgColor = rootStyles.getPropertyValue('--sidebarBackground').trim() || '#ffffff';
      const onColor = rootStyles.getPropertyValue('--on').trim() || '#000000';
      const isMobile = window.innerWidth <= 768;
      dragPreview.textContent = t('selectedItems', { count: selectedNotes.length });
      Object.assign(dragPreview.style, {
        position: 'absolute',
        top: '-9999px',
        left: '-9999px',
        padding: '6px 12px',
        borderRadius: '99px',
        background: isMobile ? 'transparent' : sidebarBgColor,
        border: isMobile ? 'none' : `1px solid color-mix(in srgb, ${onColor} 16%, transparent)`,
        color: isMobile ? 'gray' : `color-mix(in srgb, ${onColor} 60%, transparent)`,
        fontSize: '13px',
        fontFamily: 'inherit',
        whiteSpace: 'nowrap',
      });
      document.body.appendChild(dragPreview);
      const rect = e.currentTarget.getBoundingClientRect();
      e.dataTransfer.setDragImage(dragPreview, e.clientX - rect.left, e.clientY - rect.top);
      requestAnimationFrame(() => { document.body.removeChild(dragPreview); });
    } else {
      // 单个笔记拖拽预览
      const plainText = stripContent(note.content);

      // Note 拖曳預覽
      dragPreview.className = 'note-item note-drag-preview';
      dragPreview.innerHTML = `
          <div class="note-title">${note.name || t('untitled')}</div>
          <div class="note-preview">${plainText}</div>
          <div class="note-timestamp">${formatTimestamp(note.updatedAt)}</div>
        `;

      // 设置预览样式
      Object.assign(dragPreview.style, {
        position: 'absolute',
        top: '-9999px',
        left: '-9999px',
        width: '280px',
      });

      document.body.appendChild(dragPreview);

      // 计算拖拽图像的偏移量
      const rect = e.currentTarget.getBoundingClientRect();
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;

      e.dataTransfer.setDragImage(dragPreview, offsetX, offsetY);

      // 拖拽结束后移除预览元素
      requestAnimationFrame(() => {
        document.body.removeChild(dragPreview);
      });

    }

    // sourceType 供 Sidebar handleDragOver 識別，dragItems 供 MarkdownClipboard drop handler 讀取
    e.dataTransfer.setData('noteid', note.id);
    e.dataTransfer.setData('sourceType', 'notelist-noteitem');
    e.dataTransfer.setData('sidebardropsection:note', '');
    e.dataTransfer.setData('dragItems', JSON.stringify(selectedNotes));

    draggedNoteIdsRef.current = selectedNotes.map(n => n.id);

    eventBus.emit('drag:note-editor-drag-overlay', { icon: EditIcon, text: t('insertLink') });
    eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: t('dragToAttach', '拖曳放置後附加') });
  };

  // 處理拖曳經過事件
  const handleDragOver = (e, note) => {
    e.preventDefault();

    // 只在筆記內部拖曳時處理（來自 TodoList 時不顯示 drop zone）
    if (e.dataTransfer.types.includes('todoid')) return;

    const noteElement = e.currentTarget;
    const rect = noteElement.getBoundingClientRect();
    const y = e.clientY - rect.top;

    // 如果在上半部分，顯示上方指示器
    if (y < rect.height / 2) {
      if (dropPosition !== 'above' || dropTarget?.id !== note.id) {
        setDropPosition('above');
        // 儲存拖曳狀態
        savedDropStateRef.current = { target: note, position: 'above' };
      }
    } else {
      // 如果在下半部分，顯示下方指示器
      if (dropPosition !== 'below' || dropTarget?.id !== note.id) {
        setDropPosition('below');
        // 儲存拖曳狀態
        savedDropStateRef.current = { target: note, position: 'below' };

      }
    }

    setDropTarget(note);
  };

  // 處理拖曳結束事件
  const handleDrop = async (e, targetNote) => {
    e.preventDefault();

    const crossSourceType = e.dataTransfer.getData('sourceType');
    if (crossSourceType && crossSourceType !== 'notelist-noteitem') {
      // 跨區域 drop（非筆記來源）由 eventBus 處理
      return;
    }

    // 優先使用儲存的拖曳狀態
    const actualTargetNote = savedDropStateRef.current?.target || targetNote;
    const actualDropPosition = savedDropStateRef.current?.position || dropPosition;

    // NoteList 只做 Note 排序
    if (!actualTargetNote) return;
    // 複選模式不處理
    if (isMultiSelecting) return;

    const filteredNotes = useNoteStore.getState().filteredNotes();
    const draggedNoteId = e.dataTransfer.getData('noteid');
    const draggedNote = filteredNotes.find(note => note.id === draggedNoteId);

    if (!draggedNote || !actualTargetNote || draggedNote.id === actualTargetNote.id) {
      // 清除拖曳狀態
      setDropTarget(null);
      setDropPosition(null);
      savedDropStateRef.current = null;
      return;
    }

    // 獲取目標位置的前後筆記（按照 orderAt 降序排序），排除正在拖曳的項目
    const sortedNotes = filteredNotes
      .filter(note => note.id !== draggedNote.id)
      .sort((a, b) => (Number(b.orderAt) || 0) - (Number(a.orderAt) || 0));

    const targetIndex = sortedNotes.findIndex(note => note.id === actualTargetNote.id);

    let newOrderAt;

    if (actualDropPosition === 'above') {
      // 放在目標項目上方，需要與上一個項目的 orderAt 計算平均值
      const prevNote = sortedNotes[targetIndex - 1];

      if (!prevNote) {
        // 如果沒有上一個項目（放在最上面），找到當前最大的 orderAt 再加 1000
        const maxOrderAt = Math.max(...sortedNotes.map(n => Number(n.orderAt) || Date.now()));
        newOrderAt = maxOrderAt + 1000;
      } else {
        newOrderAt = ((Number(prevNote.orderAt) || Date.now()) + (Number(actualTargetNote.orderAt) || Date.now())) / 2;
      }
    } else {
      // 放在目標項目下方，需要與下一個項目的 orderAt 計算平均值
      const nextNote = sortedNotes[targetIndex + 1];

      if (!nextNote) {
        // 如果沒有下一個項目（放在最下面），找到當前最小的 orderAt 再減 1000
        const minOrderAt = Math.min(...sortedNotes.map(n => Number(n.orderAt) || Date.now()));
        newOrderAt = minOrderAt - 1000;
      } else {
        newOrderAt = ((Number(actualTargetNote.orderAt) || Date.now()) + (Number(nextNote.orderAt) || Date.now())) / 2;
      }
    }

    // 更新拖曳的筆記
    const updatedNote = {
      ...draggedNote,
      orderAt: newOrderAt
    };

    updateNote(updatedNote);

    // 清除拖曳狀態
    setDropTarget(null);
    setDropPosition(null);
    savedDropStateRef.current = null;
  };

  // 處理拖曳結束事件
  const handleDragEnd = (e) => {
    setDropTarget(null);
    setDropPosition(null);
    savedDropStateRef.current = null;
    draggedNoteIdsRef.current = [];

    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  };

  // 添加 handleDragLeave 函數
  const handleDragLeave = (e) => {
    // 複選模式不處理
    if (isMultiSelecting) return;

    // 檢查是否真的離開了整個列表區域
    const rect = noteListRef.current.parentElement.getBoundingClientRect();
    const x = e.clientX;
    const y = e.clientY;

    // 如果鼠標位置在列表區域外，清除提示線
    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
      setDropTarget(null);
      setDropPosition(null);
    }
  };

  // 添加右键菜单处理函数
  const handleContextMenu = (e, note) => {
    e.preventDefault();

    // 获取当前缩放比例
    const computedScale = getComputedStyle(document.documentElement)
      .getPropertyValue('--content-scale')
      .trim();
    const SCALE = parseFloat(computedScale) || 1;

    // 将点击位置转换为未缩放的坐标
    const unscaledX = e.clientX / SCALE;
    const unscaledY = e.clientY / SCALE;

    useMenuStore.getState().openAt('noteListMenu', unscaledX, unscaledY, { noteId: note.id });
  };

  // 修改 handleAdd 函數
  const handleAdd = async () => {
    await createNewNote();
    // 新增筆記後自動聚焦編輯器
    safeSetTimeout(() => {
      const editorContent = document.querySelector('.ProseMirror') as HTMLElement;
      editorContent?.focus();
    }, 100);
  };



  // 修改處理點擊的邏輯
  const handleNoteClick = (e, noteId) => {
    const clickedNote = useItemStore.getState().getById(noteId) as Note | undefined;

    const selectedItemIds = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean)
      .filter(i => i.itemType === 'NOTE').map(i => i.id);

    const isInputClicked = false;

    if ((e.metaKey || e.ctrlKey)) {
      // Command/Ctrl + 點擊，進行多選
      e.preventDefault();
      if (selectedItemIds.includes(noteId)) {
        useSelectedItemsStore.getState().removeExtraItem(noteId);
      } else {
        if (clickedNote) {
          useSelectedItemsStore.getState().addExtraItem(clickedNote);
        }
      }
    } else if (e.shiftKey && selectedItemIds.length > 0) {

      // Shift + 點擊，選擇範圍
      e.preventDefault();

      const filteredNoteIds = useNoteStore.getState().filteredNoteIds();

      const lastSelectedId = selectedItemIds[selectedItemIds.length - 1];
      const currentIndex = filteredNoteIds.indexOf(lastSelectedId);
      const clickedIndex = filteredNoteIds.indexOf(noteId);

      if (currentIndex !== -1 && clickedIndex !== -1) {
        const startIndex = Math.min(currentIndex, clickedIndex);
        const endIndex = Math.max(currentIndex, clickedIndex);
        const rangeIds = filteredNoteIds.slice(startIndex, endIndex + 1);

        // 將範圍內的所有筆記 ID 添加到選擇中
        const rangeItems = rangeIds.map(id => useItemStore.getState().getById(id)).filter(Boolean) as BaseItem[]; setSelectedItems(rangeItems);
      }
    } else {
      // 普通點擊，選擇單個筆記
      if (clickedNote) {
        setSelectedItems([clickedNote], { preservePath: true });
        // 清除 isNew 標記（消除呼吸紅點）
        useNoteStore.getState().clearNoteIsNew(noteId);
      }
    }
  };

  // 計算總選中數量
  const totalSelectedCount = selectedItems.filter(i => i.itemType === 'NOTE').length;

  // 修改處理列表點擊的邏輯
  const handleListClick = (e) => {
    if (e.target.className === 'notes-list') {
      setSelectedItems([]);
    }
  };

  // 修改處理輸入變化的函數
  const handleInputChange = (e, note, field) => {

    if (note && (e.key === 'Delete' || e.key === 'Backspace') &&
      (note.name.trim() === '' &&
        stripContent(note.content).trim() === '' &&
        (!note.audioURLs || note.audioURLs.length === 0) &&
        (!note.audioUrl_local || note.audioUrl_local.length === 0))) {
      return;
    }

    if (note) {
      const value = e.target.value;

      // 創建更新後的筆記對象
      const updatedNote = {
        ...note,
        [field]: value
      };

      //先更新NoteItem裡面暫存的note
      const setNoteFunc = noteUpdateRefs.current[note.id];
      if (setNoteFunc) {
        setNoteFunc(updatedNote);
      }

      //然後更新數據庫
      updateNote(updatedNote);
    };
  };

  // 修改處理輸入框按鍵的函數
  const handleInputKeyDown = async (e, note) => {
    // 若 MaterialLibrary 開啟，阻止 NoteList 的輸入快捷鍵
    if (useMaterialModeStore.getState().showMaterialLibrary) return;

    // 檢查是否在輸入法組字狀態
    if (e.isComposing || e.nativeEvent.isComposing) return;

    const filteredNoteIds = useNoteStore.getState().filteredNoteIds();

    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {

      // 處理上下箭頭鍵
      e.preventDefault();
      e.stopPropagation();

      const selectedItemIds = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean)
        .filter(i => i.itemType === 'NOTE').map(i => i.id);

      // 如果按住Shift鍵，進行多選
      if (e.shiftKey) {
        const selectedNoteId = selectedItemIds[selectedItemIds.length - 1];
        const selectedIndex = filteredNoteIds.indexOf(selectedNoteId);

        // 獲取最後一個多選的筆記索引，不包含主選中筆記
        let lastIndex = selectedIndex;
        let nextToLastIndex;

        if (selectedItemIds.length > 1) {
          // 找出除了主選中筆記外的最後一個筆記
          const otherSelectedIds = selectedItemIds.filter(id => id !== selectedNoteId);
          const lastSelectedId = otherSelectedIds[otherSelectedIds.length - 1];
          if (lastSelectedId) {
            nextToLastIndex = filteredNoteIds.indexOf(lastSelectedId);
          }
        }

        // 判斷當前移動方向
        const isMovingUp = e.key === 'ArrowUp';
        // 判斷之前的選擇方向（相對於selectedNoteId）
        const wasSelectingUp = nextToLastIndex > lastIndex;

        if ((wasSelectingUp === isMovingUp) || (selectedItemIds.length <= 1)) {
          // 方向一致，添加下一個未選擇的筆記
          const targetIndex = isMovingUp ?
            Math.max(0, lastIndex - 1) :
            Math.min(filteredNoteIds.length - 1, lastIndex + 1);

          const targetId = filteredNoteIds[targetIndex];
          if (targetId && targetId !== selectedNoteId && !selectedItemIds.includes(targetId)) {
            useSelectedItemsStore.setState({ navParams: { scrollToFocusItem: true } });
            const _n = useItemStore.getState().getById(targetId); if (_n) setSelectedItems([...[useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean) as any[], _n]);
          }
        } else {
          // 方向相反，刪除最後選擇的筆記
          if (selectedItemIds.length > 1) {
            const newSelected = [...selectedItemIds];
            newSelected.pop(); // 移除最後一個選擇的筆記
            useSelectedItemsStore.setState({ navParams: { scrollToFocusItem: true } });
            const _allSel = [useSelectedItemsStore.getState().path.at(-1), ...useSelectedItemsStore.getState().extraItems].filter(Boolean) as any[]; const _items = newSelected.map(id => _allSel.find(i => i.id === id) ?? useItemStore.getState().getById(id)).filter(Boolean) as BaseItem[]; setSelectedItems(_items);
          }
        }
      } else {
        // 獲取當前筆記在列表中的位置
        const currentIndex = filteredNoteIds.indexOf(note.id);

        // 計算目標索引（上箭頭移動到前一項，下箭頭移動到後一項）
        let targetIndex;
        if (e.key === 'ArrowUp') {
          targetIndex = currentIndex > 0 ? currentIndex - 1 : currentIndex;
        } else { // ArrowDown
          targetIndex = currentIndex < filteredNoteIds.length - 1 ? currentIndex + 1 : currentIndex;
        }

        // 如果目標索引有效且不等於當前索引
        if (targetIndex !== currentIndex) {
          const targetNoteId = filteredNoteIds[targetIndex];
          // 選中目標筆記
          useSelectedItemsStore.setState({ navParams: { scrollToFocusItem: true } });
          const _n = useItemStore.getState().getById(targetNoteId); if (_n) setSelectedItems([_n]);

          // 使用 setTimeout 確保在 DOM 更新後聚焦
          safeSetTimeout(() => {
            const targetInput = titleInputRefs.current[targetNoteId];
            if (targetInput) {
              targetInput.focus();
              // 將光標放在文本末尾
              targetInput.selectionStart = targetInput.selectionEnd = targetInput.value.length;
            }
          }, 0);
        }
      }

    } else if ((e.key === 'Delete' || e.key === 'Backspace') && (note.name.trim() === '' && stripContent(note.content).trim() === '' && (!note.audioURLs || note.audioURLs.length === 0) && (!note.audioUrl_local || note.audioUrl_local.length === 0))) {

      e.preventDefault();
      e.stopPropagation();

      // 獲取當前筆記在列表中的位置
      const currentIndex = filteredNoteIds.indexOf(note.id);

      //取消focus
      (document.activeElement as HTMLElement)?.blur()

        if (currentIndex > 0) {
        // 獲取上一個筆記的 ID
        const prevNoteId = filteredNoteIds[currentIndex - 1];
        // 刪除當前筆記
        removeItems([note.id], { needSync: true });

        // 使用 setTimeout 確保在刪除操作完成後聚焦
        safeSetTimeout(() => {
          const prevInput = titleInputRefs.current[prevNoteId];
          if (prevInput) {
            prevInput.focus();
          }
          //選擇此筆記
          const _n = useItemStore.getState().getById(prevNoteId); if (_n) setSelectedItems([_n]);
        }, 100);
      } else {
        // 刪除當前筆記
        removeItems([note.id], { needSync: true });
      }
    }
  };

  // 修改提醒點擊處理函數
  const handleReminderClick = (e, note, needFocus = false) => {
    e.stopPropagation(); // 防止觸發項目的點擊事件

    // 確保該筆記被選中
    if (!selectedItems.some(i => i.id === note.id)) {
      setSelectedItems([note]);
      // 如果是待辦項目，聚焦到輸入框
      if (needFocus) {
        // 使用 setTimeout 確保在 DOM 更新後執行
        safeSetTimeout(() => {
          const inputRef = titleInputRefs.current[note.id];
          if (inputRef) {
            inputRef.focus();
          }
        }, 0);
      }
    }

    // 顯示提醒對話框
    useDialogStore.getState().open('reminder', {
      item: note,
      onConfirm: async (itemId, reminderTime, offsetMinutes) => {
        const si = useItemStore.getState().getById(itemId);
        if (si) await useItemStore.getState().upsertItem({ ...si, reminderTime, offsetMinutes, updatedAt: Date.now() } as any, { needSync: true });
      },
      onCancel: async (itemId) => {
        const si = useItemStore.getState().getById(itemId);
        if (si) await useItemStore.getState().upsertItem({ ...si, reminderTime: null, offsetMinutes: null, updatedAt: Date.now() } as any, { needSync: true });
      },
    });
  };

  // 添加刪除提醒處理函數
  const handleDeleteReminder = (e, note) => {
    e.stopPropagation(); // 防止觸發項目的點擊事件

    // 移除提醒時間
    const updatedNote = {
      ...note,
      reminderTime: null
    };
    updateNote(updatedNote);
  };

  // 修改 handleMultipleDelete 函數
  const handleMultipleDelete = async () => {
    const noteIds = selectedItems.filter(i => i.itemType === 'NOTE').map(i => i.id);
    if (noteIds.length === 0) return;
    const firstItem = useItemStore.getState().getById(noteIds[0]) as Note | undefined;
    const isFirstInTrash = firstItem?.isDeleted === true;
    await useItemStore.getState().removeItems(noteIds, { needSync: true, softDelete: !isFirstInTrash, navigateOut: true });
  };

  // 修改 handleCheckboxClick 函數（僅保留 tempfolder checkbox 適用，NoteList 只顯示筆記無 checkbox）
  const handleCheckboxClick = (e, note) => {
    e.stopPropagation();
    if (!note) return;

    const willBeCompleted = note.completed === false;

    // 只有從未勾選變成已勾選時才觸發動畫
    if (willBeCompleted) {
      const checkbox = e.currentTarget;
      // tempfolder checkbox 動畫
      if (checkbox.classList.contains('tempfolder-noteitem-todocheckbox')) {
        checkbox.classList.add('tempfolder-checkbox-clicked');
        safeSetTimeout(() => {
          checkbox.classList.remove('tempfolder-checkbox-clicked');
        }, 250);
      }
    }

    safeSetTimeout(() => {
      const newCompleted = !note.completed;
      const updatedNote = {
        ...note,
        completed: newCompleted,
        finishedAt: newCompleted ? Date.now().toString() : null
      };
      updateNote(updatedNote);
    }, willBeCompleted ? 250 : 0);
  };



  const handleRestoreNote = async (note) => {
    try {
      const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
      const nonTrashFolders = folders.filter(f => f.name !== 'trash');
      const inboxFolder = folders.find(f => f.name === 'inbox');
      const inboxId = inboxFolder?.id;

      // 優先用 preFolderID 還原到原資料夾；若原 folder 已不存在則回 inbox
      let restoreTargetId = note.preFolderID;
      if (!restoreTargetId || !nonTrashFolders.find(f => f.id === restoreTargetId)) {
        restoreTargetId = inboxId;
      }

      const targetFolderName = folders.find(f => f.id === restoreTargetId)?.name || 'inbox';

      const updatedNote = {
        ...note,
        parentID: restoreTargetId,
        preFolderID: null,
        isDeleted: false,
        deletedAt: null,
        updatedAt: Date.now()
      };

      await updateNote(updatedNote);

      const noteTitle = note.name || t('untitled');
      const displayFolderName = (targetFolderName === 'inbox' || targetFolderName === 'trash' || targetFolderName === 'todoInbox') ? t(targetFolderName) : targetFolderName;
      setTempHint(`已將「${noteTitle}」還原至 ${displayFolderName} 筆記本`);

    } catch (error) {
      console.error('還原筆記失敗:', error);
      setTempHint('還原筆記失敗');
    }
  };

  // 當資料夾改變時，將列表滾動到頂部
  useEffect(() => {
    if (noteListRef.current) {
      noteListRef.current.parentElement.scrollTop = 0;
    }
  }, [selectedFolderId]);

  // 組件卸載時清理 AbortController
  useEffect(() => {
    return () => {
      if (mergeAbortController.current) {
        mergeAbortController.current.abort();
        mergeAbortController.current = null;
      }
    };
  }, []);


  useEffect(() => {
    // 監聯來自主進程的打開筆記請求（點擊通知打開筆記）
    const unsubscribe = window.electronAPI.onOpenNote(async (noteId) => {
      // NoteList 只處理筆記，找不到就不處理
      const targetNote = useItemStore.getState().getById(noteId) as Note | undefined;
      if (!targetNote) return;

      // 如果筆記在不同資料夾，切換資料夾
      if (targetNote.parentID !== selectedFolderId) {
        useSelectedItemsStore.getState().setSelectedItems([targetNote], { scrollToFocusItem: true, highlightItemId: noteId });
        return;
      }

      // 選中該筆記
      const _n = useItemStore.getState().getById(noteId); if (_n) setSelectedItems([_n]);
    });

    return () => {
      if (typeof unsubscribe === 'function') {
        (unsubscribe as () => void)();
      }
    };
  }, [selectedFolderId]);

  // 當進入臨時資料夾時初始化輸入框狀態
  useEffect(() => {
    if (isTempFolder) {
      const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
      const currentFolder = folders.find(f => f.id === selectedFolderId);
      if (currentFolder) {
        setFolderNameInput(currentFolder.name || '');
        setFolderNameError(''); // 清除錯誤訊息
        setNoteDescriptionInput(currentFolder.folderSummary || ''); // 初始化描述輸入框
      }
    }
  }, [isTempFolder, selectedFolderId]);

  // 當選中的筆記不再是合併筆記時，隱藏『是否滿意本次合併結果』提示
  useEffect(() => {
    if (mergedNoteId && !selectedItems.some(i => i.id === mergedNoteId)) {
      useMergedNoteStore.getState().setMergedNoteId(null);
    }
  }, [selectedItems, mergedNoteId]);

  // 檢查輸入長度
  const checkLength = (text, textLength = 12, above = false) => {
    const chineseLength = (text.match(/[\u4e00-\u9fa5]/g) || []).length;
    const englishLength = text.length - chineseLength;
    if (above) {
      return chineseLength * 2 + englishLength > textLength;
    } else {
      return chineseLength * 2 + englishLength <= textLength;
    }

  };

  // 處理資料夾名稱變更
  const handleFolderNameChange = (e) => {
    const value = e.target.value;
    // 清除錯誤訊息
    setFolderNameError('');
    // 檢查長度
    checkIsSaveFolderName(value);
    setFolderNameInput(value);
  };

  function checkIsSaveFolderName(value, currentFolderName = '') {
    var hasError = false;
    // if (checkLength(value)) {

    if (currentFolderName === value) {
      return;
    }
    // 檢查名稱是否重複
    if (value.trim()) {
      const isDuplicate = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).some(folder => folder.name.toLowerCase() === value.trim().toLowerCase() &&
        folder.id !== selectedFolderId
      );
      if (isDuplicate) {
        hasError = true;
        setFolderNameError('資料夾名稱已存在，請使用其他名稱');
      }
    }
    // } else {
    //   setFolderNameError('名稱超過限制，最多6個中文字或12個英文字');
    // }

  }

  // 處理資料夾名稱輸入時的鍵盤事件
  const handleFolderNameKeyDown = async (e) => {
    // 按下Enter鍵且不在輸入法組字狀態
    if (e.key === 'Enter' && !isComposing) {
      e.preventDefault();

      // 直接移除焦點，實際儲存交由 onBlur 處理
      e.target.blur();
    }
  };

  // 處理資料夾名稱輸入失去焦點
  const handleFolderNameBlur = async () => {
    if (isTempFolder && folderNameInput.trim() !== '' && !folderNameError) {
      const currentFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
      if (currentFolder && (currentFolder.name !== folderNameInput.trim())) {
        const updatedFolder = {
          ...currentFolder,
          name: folderNameInput.trim(),
        };
        await useItemStore.getState().upsertItem({ ...updatedFolder, itemType: 'NOTE_FOLDER' }, { needSync: true });
      }
      if (autoUpdateTitle) {
        toggleAutoUpdateTitle(false);
      }
    }
  };

  // 處理描述輸入變更
  const handleDescriptionChange = (e) => {
    setNoteDescriptionInput(e.target.value);
  };

  // 處理描述輸入失去焦點
  const handleDescriptionBlur = async () => {
    if (isTempFolder) {
      const currentFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
      if (currentFolder && currentFolder.folderSummary !== noteDescriptionInput) {
        const updatedFolder = {
          ...currentFolder,
          folderSummary: noteDescriptionInput,
        };
        await useItemStore.getState().upsertItem({ ...updatedFolder, itemType: 'NOTE_FOLDER' }, { needSync: true });
      }
      if (autoUpdateSummary) {
        toggleAutoUpdateSummary(false);
      }
    }
  };

  // 處理描述輸入時的鍵盤事件
  const handleDescriptionKeyDown = async (e) => {
    // 按下Enter+Shift鍵且不在輸入法組字狀態時，保存并繼續編輯
    if (e.key === 'Enter' && e.shiftKey && !isComposing) {
      e.preventDefault();

      if (isTempFolder) {
        const currentFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
        if (currentFolder && currentFolder.folderSummary !== noteDescriptionInput) {
          const updatedFolder = {
            ...currentFolder,
            folderSummary: noteDescriptionInput,
          };
          await useItemStore.getState().upsertItem({ ...updatedFolder, itemType: 'NOTE_FOLDER' }, { needSync: true });
        }
      }
    }
  };

  // 處理編輯摘要
  const handleEditSummary = () => {
    const currentFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
    if (!currentFolder) return;
    useDialogStore.getState().open('editSummary', {
      folderName: currentFolder.name || '',
      initialSummary: currentFolder.folderSummary || '',
      autoUpdateSummary: autoUpdateSummary,
      onConfirm: handleConfirmEditSummary,
      onToggleAutoUpdate: () => toggleAutoUpdateSummary(false),
    });
  };

  // 處理確認編輯摘要
  const handleConfirmEditSummary = async (summary) => {
    const currentFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
    if (currentFolder) {
      const updatedFolder = {
        ...currentFolder,
        folderSummary: summary
      };
      await useItemStore.getState().upsertItem({ ...updatedFolder, itemType: 'NOTE_FOLDER' }, { needSync: true });
      useDialogStore.getState().close('editSummary');
    }
  };

  //如果沒有selectedFolderId或選到群組資料夾
  if (!selectedFolderId) {
    return (
      <div className="select-folder-message">{t('selectFolderFirst')}</div>
    );
  } else if (selectedFolderId !== '__shared_notes__') {
    const allNoteFolders = useItemStore.getState().getByType('NOTE_FOLDER', true) as NoteFolder[];
    const currentFolder = allNoteFolders.find(f => f.id === selectedFolderId);
    if (!currentFolder) {
      return (
        <div className="select-folder-message">{t('selectFolderFirst')}</div>
      );
    }
    // 群組資料夾：如果有子資料夾，顯示「請先選擇一個資料夾」
    const hasChildFolders = allNoteFolders.some(f => f.parentID === selectedFolderId);
    if (hasChildFolders) {
      return (
        <div className="select-folder-message">{t('selectFolderFirst')}</div>
      );
    }
  }

  //邏輯為，主動觸發的要迴避掉當前名稱因為就是不想要才主動觸發，被動不用

  // 添加合併筆記的處理函數
  const handleMergeNotes = async () => {
    // 如果正在合併中，則中止操作
    if (isMerging) {
      if (mergeAbortController.current) {
        mergeAbortController.current.abort();
        mergeAbortController.current = null;
      }
      return;
    }

    let interval;
    try {
      setIsMerging(true);
      let dots = '';
      interval = safeSetInterval(() => {
        dots = dots.length >= 3 ? '' : dots + '.';
        setMergingDots(dots);
      }, 500);

      // 創建新的 AbortController
      mergeAbortController.current = new AbortController();

      // 從 store 中獲取完整的筆記內容
      const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
      const selectedNotes = notes.filter(note => selectedItems.some(i => i.id === note.id));

      // 使用共用的合併邏輯
      const { newNote, updatedOriginalNotes, selectedNoteIds: mergedNoteIds } = await mergeNotes(
        selectedNotes,
        selectedFolderId,
        mergeAbortController.current.signal
      );

      // 創建新筆記
      await createNewNote(newNote);

      // 批量更新原始筆記
      for (const updatedNote of updatedOriginalNotes) {
        await updateNote(updatedNote);
      }

      // 顯示提示
      setTempHint('已成功合併筆記');
      useMergedNoteStore.getState().setMergedNoteId(newNote.id);

    } catch (error) {
      if (error.name === 'AbortError') {
        setTempHint('已停止合併筆記')
      } else {
        console.error('合併筆記時發生錯誤:', error);
        setTempHint('合併筆記時發生錯誤');
      }
    } finally {
      if (interval) {
        safeClearInterval(interval);
      }
      mergeAbortController.current = null;
      setIsMerging(false);
      setMergingDots('');
    }
  };



  // 還原合併筆記
  const handleRestoreMergedNote = async () => {
    try {
      const mergedId = useMergedNoteStore.getState().mergedNoteId;
      if (!mergedId) return;

      // 取得所有筆記
      const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
      const mergedNote = notes.find(n => n.id === mergedId);
      if (!mergedNote) {
        useMergedNoteStore.getState().setMergedNoteId(null);
        return;
      }

      // 1. 找出素材筆記 ID
      const materialIds = Array.isArray(mergedNote.mergedMaterials) ? mergedNote.mergedMaterials : [];

      var selectedIdAfterRestore = null;
      // 2. 還原素材筆記的 parentID、清空 preFolderID
      for (const mid of materialIds) {
        const note = notes.find(n => n.id === mid);
        if (!note) continue;

        if (note.parentID !== mergedId) {
          continue;
        }
        selectedIdAfterRestore = note.id;

        const updatedNote = {
          ...note,
          parentID: note.preFolderID || mergedNote.parentID,
          preFolderID: null
        };
        await updateNote(updatedNote);
      }

      // 3. 先清空 mergedMaterials，然後刪除合併筆記本身，避免連鎖刪除
      await updateNoteWithoutUpdateAt({ ...mergedNote, mergedMaterials: [] }, false);
      await removeItems([mergedId], { needSync: true });
      // 關閉提示並選中第一個還原的筆記
      useMergedNoteStore.getState().setMergedNoteId(null);
      if (selectedIdAfterRestore) {
        const _n = useItemStore.getState().getById(selectedIdAfterRestore); if (_n) setSelectedItems([_n]);
      }

      setTempHint('已還原合併筆記');
    } catch (error) {
      console.error('還原合併筆記失敗:', error);
      setTempHint('還原合併筆記失敗');
    }
  };

  // 插入切換 autoUpdateSummary 函式
  const toggleAutoUpdateSummary = async (showHint = true) => {
    const newStatus = !autoUpdateSummary;
    setAutoUpdateSummary(newStatus);
    if (showHint) {
      setTempHint(newStatus ? '開啟自動更新敘述功能' : '關閉自動更新敘述功能');
    }
    if (selectedFolderId) {
      const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
      const currentFolder = folders.find(f => f.id === selectedFolderId);
      if (currentFolder) {
        const updatedFolder = { ...currentFolder, autoUpdateTitle: autoUpdateTitle ? 1 : 0, autoUpdateSummary: newStatus ? 1 : 0 };

        await useItemStore.getState().upsertItem({ ...updatedFolder, itemType: 'NOTE_FOLDER' }, { needSync: true });
      }
    }
  };

  // 插入切換 autoUpdateTitle 函式
  const toggleAutoUpdateTitle = async (showHint = true) => {
    const newStatus = !autoUpdateTitle;
    setAutoUpdateTitle(newStatus);
    if (showHint) {
      setTempHint(newStatus ? '開啟自動刷新筆記本名稱功能' : '關閉自動刷新筆記本名稱功能');
    }
    if (selectedFolderId) {
      const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
      const currentFolder = folders.find(f => f.id === selectedFolderId);
      if (currentFolder) {
        const updatedFolder = { ...currentFolder, autoUpdateTitle: newStatus ? 1 : 0, autoUpdateSummary: autoUpdateSummary ? 1 : 0 };

        await useItemStore.getState().upsertItem({ ...updatedFolder, itemType: 'NOTE_FOLDER' }, { needSync: true });
      }
    }
  };

  return (
    <div className="note-list-wrapper">


      {/* 隱藏的拖曳影像模板元素 */}
      <div
        ref={dragImageRef}
        className="drag-image"
        style={{ position: 'absolute', top: '-9999px', left: '-9999px' }}
      ></div>

      {/* 臨時資料夾的特殊輸入區域 */}
      {isTempFolder && (
        <div className="temp-folder-inputs-container">
          <div className="temp-folder-inputs">
            <div className="input-group">
              <div className="subtitle-container">
                <div className="input-subtitle">{t('newNotebookNameLabel')}</div>
              </div>
              <input
                type="text"
                className={`temp-folder-name-input ${folderNameError ? 'input-error' : ''}`}
                value={folderNameInput}
                onChange={handleFolderNameChange}
                onKeyDown={handleFolderNameKeyDown}
                onBlur={handleFolderNameBlur}
                placeholder={t('enterNotebookName')}
                onCompositionStart={() => setIsComposing(true)}
                onCompositionEnd={() => setIsComposing(false)}
              />
              {folderNameError && <div className="input-error-message">{folderNameError}</div>}
            </div>
            <div className="input-group">
              <div className="subtitle-container">
                <div className="input-subtitle">{t('description')}</div>
              </div>
              <textarea
                className="temp-folder-description-input"
                value={noteDescriptionInput}
                onChange={handleDescriptionChange}
                onBlur={handleDescriptionBlur}
                onKeyDown={handleDescriptionKeyDown}
                placeholder={t('descriptionOptional')}
                onCompositionStart={() => setIsComposing(true)}
                onCompositionEnd={() => setIsComposing(false)}
                rows={4}
              />
            </div>
          </div>
        </div>
      )}

      {!isTempFolder && (
        <NoteListTopbar />
      )}

      {!isTempFolder && !isMobileView && (() => {
        const _f = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
        return (_f?.name ?? 'inbox') !== 'trash';
      })() && (
          <>
            <div className="folder-summary-container">
              {(() => {
                const currentFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
                const folderSummary = currentFolder?.folderSummary;

                if (!folderSummary) return null;

                return (
                  <>
                    <div className="folder-summary-content">{folderSummary}</div>
                    {currentFolder?.name !== 'inbox' && (
                      <button
                        className="folder-summary-edit-button"
                        tabIndex={-1}
                        onClick={handleEditSummary}
                      >
                        <EditIcon />
                      </button>
                    )}
                  </>
                );
              })()}
            </div>

            {/* 資料夾任務標籤區域 — 由 AutoTaskPlugin 猴子補丁 Portal 注入 */}
          </>
        )}

      {!isTempFolder && !(useItemStore.getState().getByType('NOTE_FOLDER', true) as any[]).find(f => f.name === 'trash' && f.id === selectedFolderId) && selectedFolderId !== '__shared_notes__' && (
          <NoteListToolBar
            currentFolderName={(() => {
              const _f = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === selectedFolderId);
              return _f?.name ?? 'inbox';
            })()}
            handleAdd={handleAdd}
          />
        )}

      <CustomScrollbar offsetRight={4}>
          <div
            className="notes-list"
            ref={noteListRef}
            onDragLeave={handleDragLeave}
            onClick={handleListClick}
          >
            {filteredNoteIds.map(noteId => (
              <NoteItem
                key={noteId}
                noteId={noteId}
                isTempFolder={isTempFolder}
                selectedItems={selectedItems}
                isMultiSelecting={isMultiSelecting}
                dropTarget={dropTarget}
                dropPosition={dropPosition}
                isShiftPressed={isShiftPressed}
                isCommandPressed={isCommandPressed}
                currentTime={currentTime}
                titleInputRefs={titleInputRefs}
                noteUpdateRefs={noteUpdateRefs}
                handlers={{
                  handleDragStart,
                  handleDragOver,
                  handleDrop,
                  handleDragEnd,
                  handleDragLeave,
                  handleNoteClick,
                  handleContextMenu,
                  handleCheckboxClick,
                  handleReminderClick,
                  handleDeleteReminder
                }}
                onRestore={handleRestoreNote}
              />
            ))}

          </div>
        </CustomScrollbar>

      {/* Custom Hint */}
      <CustomHint
        show={isMerging || isMultiSelecting}
        buttons={isMerging ? [
          {
            text: '停止',
            type: 'error',
            onClick: handleMergeNotes
          }
        ] : [
          {
            text: totalSelectedCount > 20 ? '合併(超出20則)' : '合併',
            type: totalSelectedCount > 20 ? 'disabled' : 'primary',
            onClick: totalSelectedCount > 20 ? undefined : handleMergeNotes
          },
          {
            text: '刪除',
            type: 'error',
            onClick: async () => handleMultipleDelete()
          }
        ]}
      >
        {isMerging ? `CEO正在合併筆記${mergingDots}` : `已選取 ${totalSelectedCount} 則筆記`}
      </CustomHint>

      {/* 添加右键菜单 */}
      <NoteRightClickMenu />

      {/* EditFolderSummaryDialog 已改為 NotePlugin overlay 掛載 */}

      {/* 合併結果確認 Hint */}
      <CustomHint
        show={mergedNoteId && selectedItems.some(i => i.id === mergedNoteId)}
        buttons={[
          {
            text: '還原',
            type: 'error',
            onClick: handleRestoreMergedNote
          },
          {
            text: '確認',
            type: 'primary',
            onClick: () => {
              useMergedNoteStore.getState().setMergedNoteId(null);
            }
          }
        ]}
      >
        是否滿意本次合併結果？
      </CustomHint>

      {/* 統一拖曳遮罩 — 由拖曳方 eventBus 推送 overlay，drop 時直接轉發 eventBus 事件 */}
      {overlayProps && (
        <DragOverlay
          icon={overlayProps.icon}
          text={overlayProps.text}
          onDrop={(e) => {
            e.preventDefault();
            const { sourceType, metadata } = overlayProps || {};
            setOverlayProps(null);
            if (sourceType) {
              eventBus.emit(`drop:note-list:${sourceType}`, [], metadata);
            }
          }}
          onDragLeave={() => setOverlayProps(null)}
        />
      )}

      {/* AIAdminDialog — 由 AutoTaskPlugin 猴子補丁 Portal 注入 */}
    </div>
  );
}

export default NoteList;
