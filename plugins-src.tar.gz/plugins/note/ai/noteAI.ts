// Note plugin — AI functions

import { callPrompt, checkAndHandleCreditsError, getAILanguage } from '../../../../aiService/promptClient';
import {
  IMG_URL_TO_THEME_PROMPT,
  MERGE_TEXT_MULTI_PROMPT,
  TEXT_TO_TITLE_AND_CONTENT_PROMPT,
  MERGE_NOTES_JUDGER_PROMPT,
} from './prompts';

// ─── imgUrlToTheme ─────────────────────────────────────────────────────────

export const imgUrlToTheme = async (imageUrl: string, detail = 'low') => {
  try {
    const lang = getAILanguage();

    const response = await callPrompt({
      action: 'note_imgUrlToTheme',
      prompt: `${IMG_URL_TO_THEME_PROMPT}\n\nDetail level: ${detail}\nLanguage: ${lang}`,
      model: 'gpt-4o',
      images: [imageUrl],
    });

    try {
      const result = JSON.parse(response.content);
      const theme = result.theme || response.content;
      return { theme };
    } catch {
      // If the response is plain text (not JSON), use it directly as the theme
      return { theme: response.content };
    }
  } catch (error: any) {
    console.error('圖像主題辨識時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    // 被動功能：不跳 Dialog，靜默處理
    throw error;
  }
};

// ─── mergeTextMulti ────────────────────────────────────────────────────────

export const mergeTextMulti = async (contexts: any, user_demand: any, signal: AbortSignal | null = null) => {
  try {
    const lang = getAILanguage();

    // Build the contexts string: join array items with separator, or use as-is
    const contextsStr = Array.isArray(contexts)
      ? contexts.join('\n---\n')
      : String(contexts);

    const demandStr = user_demand ? `User demand: ${user_demand}` : '';

    const prompt = MERGE_TEXT_MULTI_PROMPT
      .replace('{user_demand}', demandStr)
      .replace('{contexts}', contextsStr);

    const response = await callPrompt({
      action: 'note_mergeTextMulti',
      prompt: `${prompt}\n\nLanguage: ${lang}`,
      model: 'gpt-4.1-nano',
      max_tokens: 9000,
    });

    return {
      content: response.content,
    };
  } catch (error: any) {
    if (error.name === 'AbortError') {
      throw error;
    }
    console.error('合併多筆筆記時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'mergeTextMulti');
    throw error;
  }
};

// ─── textToTitleAndContent ─────────────────────────────────────────────────

export const textToTitleAndContent = async (text: string, abortSignal?: AbortSignal) => {
  try {
    if (abortSignal?.aborted) {
      throw new DOMException('Operation was aborted', 'AbortError');
    }

    const lang = getAILanguage();

    const prompt = TEXT_TO_TITLE_AND_CONTENT_PROMPT
      .replace('{text}', text);

    const response = await callPrompt({
      action: 'note_textToTitleAndContent',
      prompt: `${prompt}\n\nLanguage: ${lang}`,
      model: 'gpt-4.1',
    });

    try {
      const result = typeof response.content === 'string'
        ? JSON.parse(response.content)
        : response.content;

      let title = '';
      let content = '';

      if (result && typeof result === 'object') {
        title = result.title || '';
        content = result.content || '';
      } else {
        content = response.content;
      }

      return {
        title: title,
        content: content,
      };
    } catch (parseError) {
      // If JSON parsing fails, return the raw content with no title
      return {
        title: '',
        content: response.content,
      };
    }
  } catch (error: any) {
    console.error('整理文字成筆記樣式時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'textToTitleAndContent');
    throw error;
  }
};

// ─── mergeNotesJudger ──────────────────────────────────────────────────────

export const mergeNotesJudger = async (baseNote: any, candidateNotes: any, signal: AbortSignal | null = null) => {
  try {
    const baseNoteStr = typeof baseNote === 'string' ? baseNote : JSON.stringify(baseNote);
    const candidateNotesStr = typeof candidateNotes === 'string' ? candidateNotes : JSON.stringify(candidateNotes);

    const prompt = MERGE_NOTES_JUDGER_PROMPT
      .replace('{baseNote}', baseNoteStr)
      .replace('{candidateNotes}', candidateNotesStr);

    const response = await callPrompt({
      action: 'note_mergeNotesJudger',
      prompt,
      model: 'gpt-4o-mini',
    });

    try {
      const jsonString = response.content.replace(/'/g, '"');
      const result = JSON.parse(jsonString);

      return {
        judgments: result,
      };
    } catch (parseError) {
      console.error('解析筆記合併判斷回應失敗:', parseError);
      throw parseError;
    }
  } catch (error: any) {
    if (error.name === 'AbortError') {
      throw error;
    }
    console.error('判斷筆記是否應合併時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'shouldMergeNotes');
    throw error;
  }
};
