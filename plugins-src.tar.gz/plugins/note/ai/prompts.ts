// Note plugin — AI prompt templates
// Used by noteAI.ts functions via callPrompt.

export const IMG_URL_TO_THEME_PROMPT = `Describe the main theme or subject of this image in a brief phrase.`;

export const MERGE_TEXT_MULTI_PROMPT = `Reformat the notes using Markdown and merge similar content while avoiding repetition. If there's a user demand, follow it.

{user_demand}

Notes:
---
{contexts}

Merged note:`;

export const TEXT_TO_TITLE_AND_CONTENT_PROMPT = `Given raw text, extract or generate an appropriate title and format the content as a well-structured note.

Text:
{text}

Respond in JSON format with two fields:
- "title": a concise title for the note
- "content": the formatted content`;

export const MERGE_NOTES_JUDGER_PROMPT = `Given a base note and candidate notes, judge which candidates should be merged with the base note based on content similarity and relevance.

Base note:
{baseNote}

Candidate notes:
{candidateNotes}

For each candidate, respond with a JSON array of objects containing:
- "noteId": the candidate note's identifier
- "shouldMerge": true or false
- "reason": brief explanation`;
