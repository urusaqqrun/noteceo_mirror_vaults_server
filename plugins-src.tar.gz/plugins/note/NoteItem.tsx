import React, { useCallback, useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './NoteItem.css';
import PinIcon from '../../../assets/icon_pin_24.svg?react';
import FolderIcon from '../../../assets/icon_folder_outline_24.svg?react';
import BellIconN from '../../../assets/icon_bell_24.svg?react';
import { formatTimestamp, formatReminderTime } from '../../Utils/dateFormat';

import type { Note } from './noteStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import type { BaseItem } from '../../../types/item';

import { getWorkspace } from '../../../workspace/Workspace';
import AudioPlayer from '../../common/AudioPlayer';

import RefreshIcon from '../../../assets/icon_refresh_24.svg?react';

import BreathingDot from '../../common/BreathingDot';
import { useIsMobileView } from '../../../hooks/useWindowSize';

// 使用 window.textUtils
const { stripContent } = window.textUtils;

function NoteItem({
  noteId,
  isTempFolder = false,
  isInChatRoom = false,
  selectedItems: selectedItemsProp,
  isMultiSelecting = false,
  dropTarget,
  dropPosition,
  isShiftPressed,
  isCommandPressed,
  currentTime,
  titleInputRefs,
  handlers,
  noteUpdateRefs,
  onRestore,
}) {
  const { t } = useTranslation();

  // 處理特殊資料夾名稱的翻譯
  const getDisplayName = (folderName) => {
    if (folderName === 'inbox') return t('inbox');
    if (folderName === 'todoInbox') return t('todoInbox');
    if (folderName === 'trash') return t('trash');
    return folderName;
  };

  const {
    handleDragStart,
    handleDragOver,
    handleDrop,
    handleDragEnd,
    handleDragLeave,
    handleNoteClick,
    handleContextMenu,
    handleCheckboxClick,
    handleReminderClick,
  } = handlers;

  // 透過 selector 取得最新 note 物件，只有當 noteId 對應的物件內容改變時才重新渲染
  const noteState = useItemStore(useCallback(state => (state.byType['NOTE'] ?? []).find((n: any) => n.id === noteId), [noteId])) as Note | undefined;
  const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('./noteStore').NoteFolder[];
  const path = useSelectedItemsStore(state => state.path);
  const lastSelected = useSelectedItemsStore(state => state.path.at(-1) ?? null);
  const isVirtualView = lastSelected?.itemType === 'AI_ADMIN_FOLDER' || (lastSelected?.itemType === 'TODO_FOLDER' && ['today', 'preview', 'completed'].includes(lastSelected?.id));
  const storeSelectedItemIds = path.map(i => i.id);
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const currentFolderName = (() => {
    const _folder = noteFolders.find(f => f.id === selectedFolderId);
    return _folder?.name ?? 'inbox';
  })();
  const isMobileView = useIsMobileView();

  const [note, setNote] = useState(noteState);



  const [isEditorActive, setIsEditorActive] = useState(false);

  // Mobile 長按顯示右鍵選單
  const longPressTimer = useRef(null);
  const touchStartPos = useRef({ x: 0, y: 0 });
  const longPressTriggered = useRef(false);



  // 添加監聯器來追蹤編輯器的焦點狀態
  useEffect(() => {
    const handleFocusChange = () => {
      const isEditorFocused = document.activeElement.classList.contains('ProseMirror');
      const isTitleFocused = document.activeElement.classList.contains('editor-title');
      setIsEditorActive(isEditorFocused || isTitleFocused);
    };
    document.addEventListener('focusin', handleFocusChange);
    document.addEventListener('focusout', handleFocusChange);
    return () => {
      document.removeEventListener('focusin', handleFocusChange);
      document.removeEventListener('focusout', handleFocusChange);
    };
  }, []);



  // 將 setNote 暴露給父組件
  useEffect(() => {
    if (noteUpdateRefs) {
      noteUpdateRefs.current[noteId] = setNote;
    }
  }, [noteId, setNote, noteUpdateRefs]);

  useEffect(() => {
    setNote(noteState);
  }, [noteState]);

  // Mobile 長按事件處理（Note 模式觸發右鍵選單）
  const handleTouchStart = useCallback((e) => {
    if (!isMobileView) return;
    if (!note) return;

    longPressTriggered.current = false;

    const touchX = e.touches[0].clientX;
    const touchY = e.touches[0].clientY;
    const touchTarget = e.target;

    touchStartPos.current = { x: touchX, y: touchY };

    longPressTimer.current = setTimeout(() => {
      longPressTriggered.current = true;
      const fakeEvent = {
        preventDefault: () => { },
        stopPropagation: () => { },
        clientX: touchX,
        clientY: touchY,
        target: touchTarget
      };
      handleContextMenu(fakeEvent, note);
      longPressTimer.current = null;
    }, 500);
  }, [isMobileView, note, handleContextMenu]);

  const handleTouchMove = useCallback((e) => {
    if (!longPressTimer.current) return;
    const moveX = Math.abs(e.touches[0].clientX - touchStartPos.current.x);
    const moveY = Math.abs(e.touches[0].clientY - touchStartPos.current.y);
    if (moveX > 10 || moveY > 10) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  }, []);

  const isSelected = selectedItemsProp ? selectedItemsProp.some(i => i.id === noteId) : false;
  const isMainSelected = isSelected && noteId === (selectedItemsProp?.filter(i => i.itemType === 'NOTE').at(-1)?.id);

  // 解析圖片URLs - 優先顯示遠端圖片
  const getFirstImageUrl = () => {
    if (!note) return null;

    if (note.imgURLs && Array.isArray(note.imgURLs) && note.imgURLs.length > 0) {
      for (const url of note.imgURLs) {
        if (note.content && note.content.includes(url)) return url;
      }
    }
    if (note.imageUrl_local && Array.isArray(note.imageUrl_local) && note.imageUrl_local.length > 0) {
      for (const url of note.imageUrl_local) {
        if (note.content && note.content.includes(url)) return url;
      }
    }
    if (note.websiteContent) {
      try {
        const websiteLinks = JSON.parse(note.websiteContent);
        if (Array.isArray(websiteLinks) && websiteLinks.length > 0) {
          for (const link of websiteLinks) {
            if (link.originUrl && link.imageUrl && note.content && note.content.includes(link.originUrl)) {
              return link.imageUrl;
            }
          }
        }
      } catch (error) {
        console.error('解析 websiteContent 失敗:', error);
      }
    }
    return null;
  };

  // 防護：如果 note 不存在，不渲染任何內容
  if (!note) return null;

  const firstImageUrl = getFirstImageUrl();

  // 取得筆記標題的優先順序：name > aiTitle > websiteContent 裡的 title
  const getNoteTitle = () => {
    if (note.name && note.name.trim()) return note.name;
    if (note.aiTitle && note.aiTitle.trim()) return note.aiTitle;
    if (note.websiteContent) {
      try {
        const websiteLinks = JSON.parse(note.websiteContent);
        if (Array.isArray(websiteLinks) && websiteLinks.length > 0) {
          for (const link of websiteLinks) {
            if (link.title && link.title.trim()) return link.title;
          }
        }
      } catch (error) {
        console.error('解析 websiteContent 失敗:', error);
      }
    }
    return t('untitled');
  };

  // 雙擊開啟獨立視窗
  const handleDoubleClick = (e) => {
    e.stopPropagation();
    getWorkspace()?.openWindow({ id: noteId, itemType: 'NOTE' });
  };

  // Note 模式可拖曳（Mobile 禁用拖曳，用長按右鍵選單代替）
  const canDragItem = !(lastSelected?.itemType === 'TODO_FOLDER' && lastSelected?.id === 'completed') && !isMobileView;

  // Mobile 長按事件 props
  const mobileLongPressProps = isMobileView ? {
    onTouchStart: handleTouchStart,
    onTouchMove: handleTouchMove,
    onTouchEnd: handleTouchEnd,
    onTouchCancel: handleTouchEnd,
  } : {};

  return (
    <div
      className="note-item-container"
      draggable={canDragItem}
      onDragStart={(e) => canDragItem && handleDragStart(note, e)}
      onDragOver={(e) => handleDragOver(e, note)}
      onDrop={(e) => handleDrop(e, note)}
      onDragEnd={(e) => handleDragEnd(e, note)}
      onDragLeave={(e) => handleDragLeave(e)}
      onClick={(e) => {
        if (longPressTriggered.current) {
          longPressTriggered.current = false;
          e.stopPropagation();
          return;
        }
        handleNoteClick(e, noteId);
      }}
      onDoubleClick={handleDoubleClick}
      onContextMenu={(e) => handleContextMenu(e, note)}
      {...mobileLongPressProps}
      data-id={noteId}
    >
      <div
        className={`note-item ${isSelected
          ? isEditorActive && isMainSelected
            ? 'selected'
            : 'selecting'
          : ''
          } ${dropTarget?.id === noteId ? `drop-${dropPosition}` : ''} ${isSelected && isMultiSelecting ? 'multi-selecting' : ''
          } ${(isShiftPressed || isCommandPressed) && !isMainSelected ? 'no-hover' : ''
          } ${''
          }`}
      >
        {/* 複選時覆蓋層，阻止所有互動但可拖曳 */}
        {isSelected && isMultiSelecting && (
          <div
            className="note-item-multi-select-overlay"
            draggable={true}
            onDragStart={(e) => handleDragStart(note, e)}
          />
        )}

        {/* isNew 紅點指示器 */}
        {!!note.isNew && (
          <BreathingDot className="note-item-new-indicator" />
        )}

        {/* 左容器 */}
        <div className="note-item-left-container">
          <>
            <div className="note-title-container">
              <div className="title-left-container">
                {note.pinnedAt && (
                  <div className="note-pin-icon">
                    <PinIcon />
                  </div>
                )}

                <div className="note-title">
                  {getNoteTitle()}
                </div>
              </div>

              {(note.audioURLs?.length > 0 || note.audioUrl_local?.length > 0) && (
                <AudioPlayer
                  audioURLs={note.audioURLs}
                  audioUrl_local={note.audioUrl_local}
                />
              )}

              {!isInChatRoom && currentFolderName === 'trash' && (
                <div className="note-restore-status show">
                  <div
                    className="status-touch-block"
                    onClick={(e) => {
                      e.stopPropagation();
                      onRestore?.(note);
                    }}
                  >
                    <div className="status-icon">
                      <RefreshIcon />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 筆記預覽 */}
            <div className="note-preview">{stripContent(note.content)}</div>
          </>

          {/* note-info：時間戳、提醒、標籤 */}
          <div className="note-info">
            {isInChatRoom ? (
              <div className="note-folder-name">
                <FolderIcon />
                {getDisplayName(noteFolders.find((f) => f.id === note.parentID)?.name) || t('temporary')}
              </div>
            ) : (
              <div className="note-timestamp">{formatTimestamp(note.updatedAt)}</div>
            )}

            {note.reminderTime && (
              <div
                className={`note-reminder ${new Date(note.reminderTime) < currentTime ? 'expired' : ''} ${(isShiftPressed || isCommandPressed) && !isMainSelected ? 'shift-pressed' : ''}`}
                onClick={(e) => {
                  e.stopPropagation();
                  if (!e.shiftKey) {
                    handleReminderClick(e, note, false);
                  }
                }}
              >
                <BellIconN />
                {formatReminderTime(note.reminderTime)}
              </div>
            )}

            {note.tags && note.tags.length > 0 && !(firstImageUrl && note.reminderTime) && (
              <div className="note-tags">
                {note.tags.map((tag, index) => (
                  <div key={`${tag}-${index}`} className="tag-item">
                    {tag}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 右容器 - 圖片縮略圖（僅 NORMAL 筆記） */}
        {firstImageUrl && !note.audioURLs?.length && !note.audioUrl_local?.length && (
          <div className="note-item-right-container">
            <div className="note-thumbnail">
              <img
                src={firstImageUrl}
                alt="筆記縮略圖"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default React.memo(NoteItem, (prev, next) => {
  const sameNoteId = prev.noteId === next.noteId;
  const selectedPrev = prev.selectedItems ? prev.selectedItems.some(i => i.id === prev.noteId) : false;
  const selectedNext = next.selectedItems ? next.selectedItems.some(i => i.id === next.noteId) : false;
  const multiSelectPrev = selectedPrev && prev.isMultiSelecting;
  const multiSelectNext = selectedNext && next.isMultiSelecting;

  return (
    sameNoteId &&
    selectedPrev === selectedNext &&
    multiSelectPrev === multiSelectNext &&
    prev.dropTarget === next.dropTarget &&
    prev.dropPosition === next.dropPosition &&
    prev.isInChatRoom === next.isInChatRoom &&
    prev.isShiftPressed === next.isShiftPressed &&
    prev.isCommandPressed === next.isCommandPressed &&
    prev.handlers === next.handlers
  );
});