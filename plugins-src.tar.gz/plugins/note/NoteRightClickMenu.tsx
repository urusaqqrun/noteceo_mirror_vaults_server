import React, { useEffect, useCallback, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import '../editor/NoteEditorMenu.css';
import LinkIcon from '../../../assets/icon_link_24.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';
import PinIcon from '../../../assets/icon_pin_24.svg?react';
import CopyNoteIcon from '../../../assets/copy_note.svg?react';

import { useMenuStore } from '../../../Store/menuStore';
import { useItemStore } from '../../../Store/itemStore';
import { useNoteStore, type NoteFolder } from './noteStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { useTheme } from '../../setting/ThemeProvider';
import { canEdit as canEditItem, canDelete as canDeleteItem } from '../../../utils/shareUtils';

export function NoteRightClickMenu({ deleteFunc = null }) {
  const { t } = useTranslation();
  const menuState = useMenuStore(state => state.menus['noteListMenu']);
  const showMenu = menuState?.show;
  const position = menuState?.position || { x: 0, y: 0 };
  const noteId = menuState?.data?.noteId;
  const hideRightClickMenu = () => useMenuStore.getState().close('noteListMenu');
  const theme = useTheme();
  const setTempHint = useTempHintStore(state => state.setTempHint);
  const updateNote = useNoteStore(state => state.updateNote);
  const createNewNote = useNoteStore(state => state.createNewNote);
  const allSelected = useSelectedItemsStore(state => [state.path.at(-1), ...state.extraItems].filter(Boolean) as any[]);
  const menuRef = useRef(null);
  const [note, setNote] = useState<any>(null);

  const handleEscKey = useCallback((event) => {
    if (event.detail.key === 'Escape' && showMenu) {
      hideRightClickMenu();
    }
  }, [showMenu, hideRightClickMenu]);

  const handleOutsideClick = useCallback((event) => {
    if (showMenu) {
      const menuElement = document.querySelector('.right-click-menu');
      if (menuElement && !menuElement.contains(event.target)) {
        hideRightClickMenu();
      }
    }
  }, [showMenu, hideRightClickMenu]);

  useEffect(() => {
    if (showMenu) {
      document.addEventListener('menu-key', handleEscKey);
      document.addEventListener('click', handleOutsideClick);

      if (menuRef.current) {
        const menuHeight = menuRef.current.offsetHeight;
        const screenHeight = window.innerHeight;
        const isBottomHalf = position.y > screenHeight / 2;

        if (isBottomHalf) {
          menuRef.current.style.top = `${position.y - menuHeight}px`;
        }
      }
    }

    return () => {
      document.removeEventListener('menu-key', handleEscKey);
      document.removeEventListener('click', handleOutsideClick);
    };
  }, [showMenu, handleEscKey, handleOutsideClick, position.y]);

  useEffect(() => {
    if (!noteId) { setNote(null); return; }
    (window as any).electronAPI.getItem(noteId).then((item: any) => setNote(item ?? null));
  }, [noteId]);

  const _folderIdMenu = useSelectedItemsStore.getState().selectedFolderId;
  const _noteFoldersMenu = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
  const _menuFolder = _noteFoldersMenu.find(f => f.id === _folderIdMenu);
  const currentFolderName = _menuFolder?.name ?? 'inbox';
  const isInTrash = note?.isDeleted === true || currentFolderName === 'trash';
  const isPinned = note?.pinnedAt;

  if (!showMenu || !noteId) return null;

  const handlePin = async () => {
    try {
      const updatedNote = {
        ...note,
        pinnedAt: note.pinnedAt ? null : Date.now()
      };
      await updateNote(updatedNote);
    } catch (error) {
      console.error('切換釘選狀態失敗:', error);
    }
    hideRightClickMenu();
  };

  const handleDelete = () => {
    if (deleteFunc) {
      deleteFunc();
      hideRightClickMenu();
      return;
    }

    const ids = allSelected.some(i => i.id === note.id)
      ? allSelected.filter(i => i.itemType === 'NOTE').map(i => i.id)
      : [note.id];
    useItemStore.getState().removeItems(ids, { needSync: true, softDelete: !isInTrash, navigateOut: true });
    hideRightClickMenu();
  };

  const handleCopyNote = async () => {
    try {
      const { generateObjectID } = await import('../../../../../services/utils/objectIDUtil.mjs');
      const newNoteId = generateObjectID();

      const newNote = {
        ...note,
        id: newNoteId,
        name: `${note.name || t('untitled')} ${t('copySuffix')}`,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };

      await createNewNote(newNote);
    } catch (error) {
      console.error('複製筆記失敗:', error);
    }
    hideRightClickMenu();
  };

  const handleCopyNoteLink = () => {
    if (noteId) {
      const link = `cubelv://note/${noteId}`;
      navigator.clipboard.writeText(link)
        .then(() => {
          setTempHint(t('noteLinkCopied'));
        })
        .catch(err => {
          console.error('複製連結失敗:', err);
        });
    } else {
      console.error('無法複製連結：筆記 ID 未定義');
    }

    hideRightClickMenu();
  };

  return (
    <>
      {showMenu && (
        <>
          <div
            className="right-click-menu-overlay"
            onClick={hideRightClickMenu}
          />
          <div
            ref={menuRef}
            className="right-click-menu"
            data-menu-id="noteListMenu"
            style={{
              position: 'fixed',
              top: position.y,
              left: position.x,
            }}
          >
                {(!note || canEditItem(note)) && (
                <button
                  className="right-click-menu-item"
                  onClick={handlePin}
                  onMouseDown={(e) => e.preventDefault()}
                >
                  <PinIcon className={isPinned ? 'pinned' : ''} />
                  <span>{isPinned ? t('unpin') : t('pinToTop')}</span>
                </button>
                )}

                <button
                  className="right-click-menu-item"
                  onClick={handleCopyNote}
                  onMouseDown={(e) => e.preventDefault()}
                >
                  <CopyNoteIcon />
                  <span>{t('copyNote')}</span>
                </button>

                <button
                  className="right-click-menu-item"
                  onClick={handleCopyNoteLink}
                  onMouseDown={(e) => e.preventDefault()}
                >
                  <LinkIcon />
                  <span>{t('copyNoteLink')}</span>
                </button>

                {(!note || canDeleteItem(note)) && (
                <button
                  className={`right-click-menu-item ${theme.mode === 'dark' ? 'error-dark' : 'error-light'}`}
                  onClick={handleDelete}
                  onMouseDown={(e) => e.preventDefault()}
                >
                  <DeleteIcon />
                  <span>{isInTrash ? t('deleteNote') : t('moveToTrash')}</span>
                </button>
                )}
          </div>
        </>
      )}
    </>
  );
}
