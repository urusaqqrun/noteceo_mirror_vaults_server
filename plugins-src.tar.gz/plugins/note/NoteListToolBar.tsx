import React, { useState } from 'react';
import AddNoteIcon from '../../../assets/icon_note_add_24.svg?react';
import AddPhotoIcon from '../../../assets/icon_photo_add_24.svg?react';
import AddAudioIcon from '../../../assets/icon_audio_add_24.svg?react';
import ShareCollabIcon from '../../../assets/icon_share_setting_24.svg?react';

import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { useNoteStore, type Note } from './noteStore';
import { updateItemShareSettings } from '../../../utils/shareAPI';

import { canAccessSharingDialog, canEdit } from '../../../utils/shareUtils';
import syncService from '../../../utils/syncService';
import type { BaseItem } from '../../../types/item';

import { useTranslation } from 'react-i18next';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { CustomToolbar, type ToolbarButton } from '../../common/CustomToolbar';
import '../sidebar/Sidebar.css';

function NoteListToolBar({
  currentFolderName,
  handleAdd,
}) {
  // 多語言支援
  const { t } = useTranslation();



  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);
  const noteFolders = useItemStore(s => s.byType['NOTE_FOLDER'] ?? []) as import('./noteStore').NoteFolder[];
  const notes = useItemStore(s => s.byType['NOTE'] ?? []) as Note[];

  const createNewNote = useNoteStore(state => state.createNewNote);
  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);

  const isMobileView = useIsMobileView();

  const [isUploading, setIsUploading] = useState(false);

  // 處理多選圖片
  const handleAddPhotos = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;

    input.onchange = async (event) => {
      let files = Array.from((event.target as HTMLInputElement).files || []);
      // 先反轉陣列，確保依選取順序插入（避免最先選的圖片最後插入）
      files = files.reverse();

      if (files.length === 0) return;

      setIsUploading(true);

      const readAsDataURL = (file) => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(file);
      });

      try {
        const baseTime = Date.now();
        const promises = files.map(async (file, idx) => {
          const dataUrl = await readAsDataURL(file);
          if (typeof window.handleAutoSaveScreenshot === 'function') {
            // 依序 +1ms，確保更新時間排序一致
            const customTime = baseTime + idx;
            await (window.handleAutoSaveScreenshot as any)(dataUrl, selectedFolderId, false, customTime);
          }
        });
        await Promise.all(promises);
      } catch (err) {
        console.error('上傳圖片失敗', err);
      } finally {
        setIsUploading(false);
      }
    };

    input.click();
  };

  // 處理新增錄音筆記
  const handleAddAudio = async () => {
    try {
      // 創建新筆記
      const newNote = await createNewNote({}, false);

      if (newNote && newNote.id) {
        // 選中新建的筆記
        setSelectedItems([newNote]);

        // 等待一小段時間確保筆記編輯器已渲染
        setTimeout(() => {
          // 觸發自定義事件來啟動錄音
          const event = new CustomEvent('startRecordingFromToolbar');
          document.dispatchEvent(event);
        }, 200);
      }
    } catch (error) {
      console.error('創建錄音筆記失敗:', error);
    }
  };

  const selectedFolder = useItemStore(s => {
    if (!selectedFolderId) return null;
    return s.itemMap.get(selectedFolderId) || null;
  }) as BaseItem | null;

  const isSpecialFolder = currentFolderName === 'trash' || currentFolderName === 'inbox';

  const handleOpenShareSettings = () => {
    if (!selectedFolder) return;
    useDialogStore.getState().open('sharing', {
      item: { id: selectedFolder.id, name: selectedFolder.name, isPublic: (selectedFolder as any).isPublic, itemType: selectedFolder.itemType },
      onSave: async (settings) => {
        await updateItemShareSettings({ ...settings, extra: {} });
        await syncService.syncChanges();
        useTempHintStore.getState().setTempHint(settings.isPublic ? t('shareEnabled') : t('shareDisabled'));
      },
    });
  };

  // 組裝右側按鈕
  const rightButtons: ToolbarButton[] = [];

  if (!isSpecialFolder && selectedFolder && canAccessSharingDialog(selectedFolder)) {
    rightButtons.push({
      icon: <ShareCollabIcon />,
      onClick: handleOpenShareSettings,
      title: t('shareSettings'),
    });
  }

  const isTempFolder = selectedFolderId?.startsWith('__');
  const folderEditable = !selectedFolder || canEdit(selectedFolder);
  if (!isTempFolder && currentFolderName !== 'trash' && folderEditable) {
    rightButtons.push({
      icon: <AddAudioIcon />,
      onClick: handleAddAudio,
      title: t('addAudio'),
    });
    rightButtons.push({
      icon: <AddPhotoIcon />,
      onClick: handleAddPhotos,
      title: t('addPhoto'),
    });
    rightButtons.push({
      icon: <AddNoteIcon />,
      onClick: () => {
        if (isMobileView && window.focusHiddenInput) {
          window.focusHiddenInput();
        }
        handleAdd('NORMAL');
      },
      title: t('addNote'),
    });
  }

  return (
    <>
      <CustomToolbar
        height={44}
        right={{ buttons: rightButtons }}
      />
      {isUploading && (
        <div
          className="notelist-toolbar-mask"
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.2)',
            cursor: 'wait',
            zIndex: 2000
          }}
        />
      )}
    </>
  );
}

export default NoteListToolBar; 