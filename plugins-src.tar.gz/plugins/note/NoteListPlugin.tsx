// ===== NoteListPlugin — NoteList 插件 =====

import React from 'react';
import { Plugin } from '../../../workspace/Plugin';
import { ReactView } from '../../../workspace/ReactView';
import NoteList from './NoteList';

class NoteListView extends ReactView {
    getViewType() { return 'note-list'; }
    getDisplayText() { return '筆記列表'; }
    renderComponent() { return <NoteList />; }
}

export class NoteListPlugin extends Plugin {
    onload() {
        this.registerView('note-list', (leaf) => new NoteListView(leaf));
    }
}
