import React, { useState, useEffect, useCallback } from 'react';
import './EditFolderSummaryDialog.css';
import RefreshDark from '../../../assets/bk_refresh_dark.svg?react';
import RefreshLight from '../../../assets/bk_refresh_light.svg?react';
import { useTheme } from '../../setting/ThemeProvider';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

interface EditFolderSummaryDialogData {
  folderName: string;
  initialSummary: string;
  autoUpdateSummary: boolean;
  onConfirm: (summary: string) => void;
  onToggleAutoUpdate: (enabled: boolean) => void;
  onRefresh: () => Promise<string | null>;
}

const EditFolderSummaryDialog = () => {
  const { t } = useTranslation();
  const isOpen = useDialogStore(state => state.dialogs['editSummary']?.show);
  const dialogData = useDialogStore(state => state.dialogs['editSummary']?.data) as EditFolderSummaryDialogData | null;
  const close = () => useDialogStore.getState().close('editSummary');

  const folderName = dialogData?.folderName ?? '';
  const initialSummary = dialogData?.initialSummary ?? '';
  const autoUpdateSummary = dialogData?.autoUpdateSummary ?? false;
  const onConfirm = dialogData?.onConfirm ?? null;
  const onToggleAutoUpdate = dialogData?.onToggleAutoUpdate ?? null;
  const onRefresh = dialogData?.onRefresh ?? null;

  const [summary, setSummary] = useState(initialSummary || '');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { mode } = useTheme();

  useEffect(() => {
    setSummary(initialSummary || '');
  }, [initialSummary, isOpen]);

  const handleSubmit = () => {
    onConfirm?.(summary);
  };

  const handleClear = () => {
    setSummary('');
  };

  const handleRefresh = async () => {
    if (!onRefresh) return;
    setIsRefreshing(true);
    try {
      const newSummary = await onRefresh();
      if (newSummary) {
        setSummary(newSummary);
      }
    } catch (error) {
      console.error(t('refreshFailed'), error);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Escape 由 CustomDialog 統一處理（已移除重複 keydown listener）

  if (!isOpen) return null;

  return (
    <CustomDialog
      isOpen={isOpen}
      onClose={close}
      title={t('editNotebookDescription')}
      className="edit-summary-dialog"
      onConfirm={handleSubmit}
      confirmLabel={t('save')}
    >
      <div className="edit-summary-dialog-content">
        <p className="edit-summary-dialog-description">
          {t('aiSummaryDescription')}
        </p>

        <div className="edit-summary-form-group">
          <textarea
            className="edit-summary-input"
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            placeholder={t('editDescriptionPlaceholder')}
            rows={8}
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                e.preventDefault();
                e.stopPropagation();
                close();
              }
            }}
          />
        </div>

        <div className="edit-summary-auto-refresh-container">
          <div className="edit-summary-auto-refresh-toggle">
            <label className="edit-summary-toggle-switch">
              <input
                type="checkbox"
                checked={autoUpdateSummary}
                onChange={() => onToggleAutoUpdate?.(false)}
              />
              <span className="edit-summary-toggle-slider"></span>
            </label>
            <span className="edit-summary-toggle-label">
              {t('autoRefreshDescription', { folderName })}
            </span>
          </div>

          <div className="edit-summary-refresh-buttons">
            <button
              type="button"
              className={`edit-summary-refresh-button ${isRefreshing ? 'refreshing' : ''}`}
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              {mode === 'dark' ? <RefreshDark /> : <RefreshLight />}
              <span>{t('refresh')}</span>
            </button>
          </div>
        </div>
      </div>
    </CustomDialog>
  );
};

export default EditFolderSummaryDialog;
