import { create } from 'zustand';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import i18n from '../../../i18n/config';
import { timerManager } from '../../../Store/uiStore';

import { useItemStore, registerOnDelete } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { getTrashFolderId } from '../../../utils/ensureDefaultFolders';


import { BaseItem, itemType } from '../../../types/item';
import { stripHtmlTags as _stripHtmlTags, processItemContent as _processItemContent, type ContentItem } from '../../../utils/textUtils';


export interface FolderTypeInfo {
  found: boolean;
  hasChildren: boolean;
  isGroup: boolean;
  isChild: boolean;
  isNormal: boolean;
  depth?: number;
  parentPath?: string[];
}

const getDisplayFolderName = (folderName: string): string => {
  if (folderName === 'inbox' || folderName === 'trash' || folderName === 'todoInbox') {
    return i18n.t(folderName);
  }
  return folderName;
};

@itemType('NOTE', '筆記，Markdown 內容')
export class Note extends BaseItem {
  content?: string = '';
  aiTitle?: string = '';
  aiContent?: string = '';
  pinnedAt?: number | string | null = null;
  tags?: string[] = [];
  aiTags?: string[] = [];
  audioURLs?: string[] = [];
  audioUrl_local?: string = '';
  audioTexts?: string[] = [];
  imgURLs?: string[] = [];
  imageUrl_local?: string = '';
  imgTexts?: string[] = [];
  websiteContent?: string = '';
  reminderTime?: string | number | null = null;
  offsetMinutes?: number = 0;
  mergedMaterials?: string[] = [];
  preFolderID?: string | null = null;
  isNew?: boolean = false;
  finishedAPIs?: string[] = [];
  priority?: string | number | null = null;
  group?: string | null = null;
  subGroup?: string | null = null;
  purpose?: string | null = null;
  finishedAt?: string | number | null = null;
}


@itemType('NOTE_FOLDER', '筆記資料夾')
export class NoteFolder extends BaseItem {
  folderSummary?: string = '';
  autoUpdateSummary?: boolean = false;
  noteNum?: number = 0;
}

interface NotesState {
  // ===== Note Folders =====
  addNoteFolder: (newFolder: any, needSync?: boolean) => Promise<void>;
  deleteNoteFolder: (folderIds: string | string[], needSync?: boolean, needDeleteNote?: boolean) => Promise<void>;
  getFolderType: (folderId: string) => FolderTypeInfo;
  isAncestorOf: (ancestorId: string, descendantId: string) => boolean;
  // ===== Notes =====
  filteredNotes: () => Note[];
  filteredNoteIds: () => string[];
  stripHtmlTags: (html: string, replaceImgSrc?: boolean) => string;
  processItemContent: (item: ContentItem | null | undefined, useForSearchDailog?: boolean, addTitle?: boolean) => string;
  getFilteredAndSortedItemsByFolderName: (allNotes: Note[], folderName: string) => Note[];
  getFilteredAndSortedItems: (allNotes: Note[], folderId: string | null) => Note[];
  loadNotes: () => Promise<void>;
  addNote: (note?: any, needSync?: boolean) => Promise<void>;
  createNewNote: (options?: any, autoSelect?: boolean, needSync?: boolean) => Promise<Note>;
  updateNote: (updatedNote: any, needSync?: boolean) => Promise<void>;
  updateNoteWithoutUpdateAt: (updatedNote: any, needSync?: boolean) => Promise<void>;
  moveNoteToFolder: (noteId: string, targetFolderId: string) => Promise<void>;
  resetDatabase: () => Promise<void>;
  clearNoteIsNew: (noteId: string) => void;
  filterVersion: number;
  bumpFilterVersion: () => void;
}

export const useNoteStore = create<NotesState>((set, get) => ({
  filterVersion: 0,
  bumpFilterVersion: () => set(s => ({ filterVersion: s.filterVersion + 1 })),
  addNoteFolder: async (newFolder, needSync = true) => {
    if (Array.isArray(newFolder)) {
      try {
        const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
        const currentUser = (window as any).auth?.currentUser;
        const foldersWithMeta = newFolder.map(f => ({
          ...f,
          id: f.id || generateObjectID(),
          itemType: 'NOTE_FOLDER',
        }));
        for (const f of foldersWithMeta) {
          await useItemStore.getState().upsertItem({ ...f, itemType: 'NOTE_FOLDER' }, { needSync });
        }
      } catch (error) {
        console.error('批次新增筆記資料夾錯誤：', error);
      }
      return;
    }
    try {
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const currentUser = (window as any).auth?.currentUser;
      const now = Date.now();

      // 計算 orderAt：新資料夾排在同層最後面（比現有最大 orderAt 更大）
      let orderAt = newFolder.orderAt;
      if (orderAt === undefined || orderAt === null) {
        const allFolders = useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[];
        const parentID = newFolder.parentID || null;
        const siblings = allFolders.filter(f =>
          f.name !== 'inbox' && f.name !== 'trash' &&
          ((f.parentID || null) === parentID)
        );
        const getOrder = (f: any) => {
          const o = Number(f.orderAt) || 0;
          return o !== 0 ? o : (Number(f.createdAt) || 0);
        };
        const maxOrder = siblings.length > 0
          ? Math.max(...siblings.map(getOrder))
          : now;
        orderAt = maxOrder + 1000;
      }

      const folderWithMeta = {
        ...newFolder,
        id: newFolder.id || generateObjectID(),
        itemType: 'NOTE_FOLDER',
        createdAt: newFolder.createdAt || now,
        updatedAt: newFolder.updatedAt || now,
        orderAt,
      };
      await useItemStore.getState().upsertItem({ ...folderWithMeta, itemType: 'NOTE_FOLDER' }, { needSync });
    } catch (error) {
      console.error('新增筆記資料夾錯誤：', error);
    }
  },
  deleteNoteFolder: async (folderIds, needSync = true, needDeleteNote = true) => {
    try {
      const ids = Array.isArray(folderIds) ? folderIds : [folderIds];
      const foldersNeedDelete: string[] = [];
      const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);

      const specialFolderIds = folders
        .filter(f => f.name === 'inbox' || f.name === 'trash')
        .map(f => f.id);
      const filteredIds = ids.filter(id => !specialFolderIds.includes(id));
      if (filteredIds.length === 0) return;

      const notes = useItemStore.getState().getByType('NOTE') as Note[];
      const now = Date.now();
      const trashId = getTrashFolderId();

      const collectDescendantIds = (parentId: string): string[] => {
        const childIds: string[] = [];
        folders.filter(f => f.parentID === parentId).forEach(child => {
          childIds.push(child.id);
          childIds.push(...collectDescendantIds(child.id));
        });
        return childIds;
      };

      filteredIds.forEach(fid => {
        const allIds = [fid, ...collectDescendantIds(fid)];
        allIds.forEach(id => { if (!foldersNeedDelete.includes(id)) foldersNeedDelete.push(id); });
        if (needDeleteNote && trashId) {
          const affectedFolderIds = new Set(allIds);
          notes.forEach(async (note: any) => {
            if (affectedFolderIds.has(note.parentID)) {
              await useItemStore.getState().upsertItem({
                ...note,
                isDeleted: true,
                deletedAt: now,
                updatedAt: now,
                pinnedAt: null,
                preFolderID: note.preFolderID || note.parentID,
                parentID: trashId,
                itemType: 'NOTE',
              }, { needSync });
            }
          });
        }
      });

      await useItemStore.getState().removeItems(foldersNeedDelete, { needSync });

      await get().loadNotes();

      const selectedId = useSelectedItemsStore.getState().selectedFolderId;
      if (selectedId && foldersNeedDelete.includes(selectedId)) {
        const updatedFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
        const inboxFolder = updatedFolders.find(f => f.name === 'inbox');
        if (inboxFolder) useSelectedItemsStore.getState().setSelectedItems([inboxFolder], { scrollToFocusItem: true });
      }
    } catch (error) {
      console.error('刪除筆記資料夾失敗:', error);
    }
  },
  getFolderType: (folderId) => {
    const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
    const folder = folders.find(f => f.id === folderId);
    if (!folder) return { found: false, hasChildren: false, isGroup: false, isChild: false, isNormal: true };
    const hasChildren = folders.some(f => f.parentID === folderId);
    const isChild = !!folder.parentID;
    return { found: true, hasChildren, isGroup: hasChildren, isChild, isNormal: !hasChildren && !isChild, depth: isChild ? 1 : 0, parentPath: isChild ? [folder.parentID!] : [] };
  },
  isAncestorOf: (ancestorId, descendantId) => {
    const folders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
    let currentId: string | null | undefined = descendantId;
    while (currentId) {
      const folder = folders.find(f => f.id === currentId);
      if (!folder || !folder.parentID) return false;
      if (folder.parentID === ancestorId) return true;
      currentId = folder.parentID;
    }
    return false;
  },
  resetDatabase: async () => {
    try {
      await window.electronAPI!.resetDatabase();
      localStorage.removeItem('createItemIds');
      localStorage.removeItem('updateItemIds');
      localStorage.removeItem('deletedItemIds');
      localStorage.removeItem('lastSyncedSeq');
      localStorage.removeItem('currentSessionID');
      await useItemStore.getState().reload();
    } catch (error) {
      console.error('Failed to reset database:', error);
    }
  },
  // ===== Notes 狀態和方法 =====
  filteredNotes: () => {
    const folderId = useSelectedItemsStore.getState().selectedFolderId;
    const trashId = getTrashFolderId();
    const includeDeleted = !!(trashId && folderId === trashId);
    return get().getFilteredAndSortedItems(useItemStore.getState().getByType('NOTE', includeDeleted) as Note[], folderId) as Note[];
  },
  filteredNoteIds: () => {
    return get().filteredNotes().map(n => n.id);
  },

  stripHtmlTags: _stripHtmlTags,
  processItemContent: _processItemContent,

  getFilteredAndSortedItems: (allNotes, folderId) => {

    if (!folderId) return [];

    const trashId = getTrashFolderId();

    // trash 實體資料夾：parentID 指向 trash folder 的筆記
    if (trashId && folderId === trashId) {
      const filtered = allNotes.filter((note: any) => {
        if (note.parentID !== trashId) return false;
        const parent = useItemStore.getState().getById(note.parentID);
        if (parent && parent.itemType === 'NOTE') return false;
        return true;
      });
      const compareNotes = (a: any, b: any) => {
        const aAt = (a.deletedAt ?? a.updatedAt) as number;
        const bAt = (b.deletedAt ?? b.updatedAt) as number;
        return bAt - aAt;
      };
      return filtered.sort(compareNotes);
    }

    // 虛擬共享筆記
    if (folderId === '__shared_notes__') {
      const myMemberID = (() => { try { return JSON.parse(localStorage.getItem('userData_local') || '{}').ID || ''; } catch { return ''; } })();
      const allNoteFolders = useItemStore.getState().getByType('NOTE_FOLDER');
      const folderIdSet = new Set(allNoteFolders.map(f => f.id));
      const filtered = allNotes.filter((note: any) => {
        if (note.isDeleted) return false;
        if (note.parentID) {
          const parent = useItemStore.getState().getById(note.parentID);
          if (parent && parent.itemType === 'NOTE') return false;
        }
        if (note.parentID && folderIdSet.has(note.parentID)) return false;
        const myPerm = note._permissions?.find((p: any) => p.user_id === myMemberID);
        return myPerm && myPerm.permission !== 'owner';
      });
      const compareNotes = (a: any, b: any) => (b.updatedAt as number) - (a.updatedAt as number);
      return filtered.sort(compareNotes);
    }

    let filtered = allNotes.filter((note: any) => note.parentID === folderId && !note.isDeleted);

    const compareNotes = (a: any, b: any) => {
      if (a.pinnedAt && b.pinnedAt) return b.pinnedAt - a.pinnedAt;
      if (a.pinnedAt) return -1;
      if (b.pinnedAt) return 1;
      return b.updatedAt - a.updatedAt;
    };

    return filtered.sort(compareNotes);
  },

  getFilteredAndSortedItemsByFolderName: (allNotes, folderName) => {
    const folders = useItemStore.getState().getByType('NOTE_FOLDER', true) as NoteFolder[];
    const folderId = folders.find(f => f.name === folderName)?.id;
    return get().getFilteredAndSortedItems(allNotes, folderId);
  },

  loadNotes: async () => {
    await useItemStore.getState().loadByType('NOTE');
  },

  addNote: async (note = {}, needSync = true) => {
    if (Array.isArray(note)) {
      for (const n of note) {
        await useItemStore.getState().upsertItem({ ...n, itemType: 'NOTE' }, { needSync });
      }
      return;
    }
    await useItemStore.getState().upsertItem({ ...note, itemType: 'NOTE' }, { needSync });
  },

  createNewNote: async (options = {}, autoSelect = true, needSync = true) => {

    const now = Date.now();
    // 取得後端用戶 ID，優先使用 localStorage 中的 userData.ID
    const userData = JSON.parse(localStorage.getItem('userData_local'));
    const currentUser = (window as Window & { auth?: { currentUser?: { uid: string } } }).auth?.currentUser;
    const myMemberID = userData?.ID || (currentUser ? currentUser.uid : 'DataProviderDefault');

    // 先過濾掉 options 中的 null 值
    const filteredOptions = {};
    Object.keys(options).forEach(key => {
      if (options[key] !== null && options[key] !== undefined) {
        filteredOptions[key] = options[key];
      }
    });

    const targetFolderID = options.parentID || useSelectedItemsStore.getState().selectedFolderId;
    const folder = useItemStore.getState().getById(targetFolderID);

    // 判斷是否為協作建立：folder 有 _permissions 且我不是 owner
    const folderMyPerm = folder?._permissions?.find((p: any) => p.user_id === myMemberID);
    const isCollaborativeCreate = folder && folderMyPerm && folderMyPerm.permission !== 'owner';

    const newNote: Note = {
      ...filteredOptions,
      id: options.id || generateObjectID(),
      itemType: 'NOTE',
      parentID: targetFolderID,
      version: options.version || 0,
      createdAt: options.createdAt || now,
      updatedAt: options.updatedAt || now,
      name: options.name || '',
      content: options.content || '',
      orderAt: options.orderAt || undefined,
    };

    // 協作建立時繼承 folder 的 _permissions
    if (isCollaborativeCreate && folder._permissions) {
      (newNote as any)._permissions = folder._permissions;
    }

    await useItemStore.getState().upsertItem(newNote, { needSync });
    if (autoSelect) {
      useSelectedItemsStore.getState().setSelectedItems([newNote], { scrollToFocusItem: true, highlightItemId: newNote.id });
    }
    return newNote;
  },

  updateNote: async (updatedNote, needSync = true) => {

    // 若傳入陣列，改以批次方式一次更新多筆筆記
    if (Array.isArray(updatedNote)) {
      try {
        const notesWithMeta = updatedNote.map(n => ({
          ...n,
          itemType: 'NOTE',
          updatedAt: Date.now(),
        }));

        for (const n of notesWithMeta) {
          await useItemStore.getState().upsertItem(n, { needSync });
        }
      } catch (error) {
        console.error('批次更新筆記失敗:', error);
      }
      return; // 批次處理完畢
    }
    try {
      const noteWithMeta = {
        ...updatedNote,
        itemType: 'NOTE',
        updatedAt: Date.now(),
      };
      await useItemStore.getState().upsertItem({ ...noteWithMeta, itemType: 'NOTE' }, { needSync });
    } catch (error) {
      console.error('更新筆記失敗:', error);
    }
  },

  updateNoteWithoutUpdateAt: async (updatedNote, needSync = true) => {

    // 若傳入陣列，改以批次方式一次更新多筆筆記（不更新時間戳）
    if (Array.isArray(updatedNote)) {
      try {
        for (const n of updatedNote) {
          const withType = { ...n, itemType: 'NOTE' };
          await useItemStore.getState().upsertItem(withType, { needSync });
        }

      } catch (error) {
        console.error('批次更新筆記失敗（不更新時間戳）:', error);
      }
      return; // 批次處理完畢
    }
    try {
      await useItemStore.getState().upsertItem({ ...updatedNote, itemType: 'NOTE' }, { needSync });

    } catch (error) {
      console.error('更新筆記失敗（不更新時間戳）:', error);
    }
  },

  moveNoteToFolder: async (noteId, targetFolderId) => {
    try {
      const notes = (useItemStore.getState().getByType('NOTE') as Note[]);
      const navState = useSelectedItemsStore.getState();
      const allSelected = [navState.path.at(-1), ...navState.extraItems].filter(Boolean) as BaseItem[];
      const selectedNoteSelections = allSelected.filter(i => i.itemType === 'NOTE');

      let noteIdsToProcess = selectedNoteSelections.length > 0 ? selectedNoteSelections.map(i => i.id) : [noteId];
      if (noteIdsToProcess.length > 1) {
        noteIdsToProcess = [...noteIdsToProcess].reverse();
      }

      const targetFolder = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]).find(f => f.id === targetFolderId);
      const targetFolderName = targetFolder?.name || '文件夾';
      const updatedNotes = [];
      const allFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
      const sourceFolderIds = new Set();

      noteIdsToProcess.forEach(idToMove => {
        const noteToMove = notes.find(n => n.id === idToMove);
        if (noteToMove?.parentID) sourceFolderIds.add(noteToMove.parentID);
      });

      for (const idToMove of noteIdsToProcess) {
        const noteToMove = notes.find(n => n.id === idToMove);
        if (noteToMove) {
          const updatedNote = {
            ...noteToMove,
            preFolderID: noteToMove.parentID,
            parentID: targetFolderId,
            updatedAt: Date.now(),
            pinnedAt: null,
          };

          await useItemStore.getState().upsertItem({ ...updatedNote, itemType: 'NOTE' }, { needSync: true });
          updatedNotes.push(updatedNote);
        }
      }


      useTempHintStore.getState().setTempHint(i18n.t('notesMovedToFolder', { count: noteIdsToProcess.length, folderName: getDisplayFolderName(targetFolderName) }));

      const lastSelectedNote = selectedNoteSelections.at(-1);
      const _lastItemId = lastSelectedNote?.id ?? null;
      const _noteFolders = (useItemStore.getState().getByType('NOTE_FOLDER') as NoteFolder[]);
      const _currentFolderId = _noteFolders.some(f => f.id === _lastItemId)
        ? _lastItemId
        : ((useItemStore.getState().getByType('NOTE') as Note[]).find((n: any) => n.id === _lastItemId)?.parentID ?? null);
      if (selectedNoteSelections.length > 0 && noteIdsToProcess.includes(_lastItemId) && _currentFolderId !== targetFolderId) {
        useSelectedItemsStore.getState().setSelectedItems([]);
      } else {
        if (lastSelectedNote) {
          const selectedNote = (useItemStore.getState().getByType('NOTE') as Note[]).find(n => n.id === _lastItemId);
          if (selectedNote) useSelectedItemsStore.getState().setSelectedItems([selectedNote]);
        }
      }

    } catch (error) {
      console.error('Failed to move notes:', error);
      useTempHintStore.getState().setTempHint(i18n.t('moveNotesFailed'));
    }
  },

  clearNoteIsNew: (noteId) => {
    const note = useItemStore.getState().getById(noteId) as Note | undefined;
    if (note?.isNew) {
      const updated = { ...note, isNew: false };
      void useItemStore.getState().upsertItem({ ...updated, itemType: 'NOTE' }, { needSync: true });
    }
  },

}));


export function registerNoteHandlers() {
  registerOnDelete('NOTE', async (ids, options) => {
    const { removeItems, upsertItem, getById, getByType } = useItemStore.getState();

    // 1. 收集 mergedMaterials
    const allIds = new Set(ids);
    for (const id of ids) {
      const note = getById(id) as Note | undefined;
      if (note?.mergedMaterials?.length) {
        const notes = getByType('NOTE', true);
        for (const mid of note.mergedMaterials) {
          if (notes.some((n: any) => n.id === mid) && !allIds.has(mid)) allIds.add(mid);
        }
      }
    }
    const allIdArr = Array.from(allIds);

    // 2. 快取選取狀態與 filteredNotes（刪除後需要用來計算下一則）
    const lastSelectedId = useSelectedItemsStore.getState().path.at(-1)?.id ?? null;
    const filteredNotes = useNoteStore.getState().filteredNotes();

    // 4. 判斷是否全部都是空白筆記（自動清理場景不顯示 hint）
    const isAllEmpty = ids.every(id => {
      const n = getById(id) as Note | undefined;
      if (!n) return true;
      const noTitle = !n.name || n.name.trim() === '';
      const noContent = !n.content || n.content.trim() === '' || n.content === '<p></p>';
      const noAudio = (!n.audioURLs || n.audioURLs.length === 0) && (!n.audioUrl_local || n.audioUrl_local.length === 0);
      return noTitle && noContent && noAudio;
    });

    if (options?.softDelete) {
      const now = Date.now();
      const trashId = getTrashFolderId();
      const idsOrdered = allIdArr.length > 1 ? [...allIdArr].reverse() : [...allIdArr];

      for (const id of idsOrdered) {
        const note = getById(id) as Note | undefined;
        if (note) {
          await upsertItem({
            ...note,
            isDeleted: true,
            deletedAt: now,
            updatedAt: now,
            pinnedAt: null,
            preFolderID: (note as any).preFolderID || (note as any).parentID,
            ...(trashId ? { parentID: trashId } : {}),
            itemType: 'NOTE',
          } as any, { needSync: options?.needSync ?? true });
        }
      }

      if (!isAllEmpty) {
        useTempHintStore.getState().setTempHint(
          i18n.t('notesMovedToTrash', { count: ids.length, trashName: getDisplayFolderName('trash') }),
        );
      }

      if (lastSelectedId && allIds.has(lastSelectedId)) {
        useSelectedItemsStore.getState().navigateOut();
      }
    } else {
      await removeItems(allIdArr, options);

      if (!isAllEmpty) {
        useTempHintStore.getState().setTempHint(i18n.t('notesDeleted', { count: ids.length }));
      }

      if (lastSelectedId && allIds.has(lastSelectedId)) {
        useSelectedItemsStore.getState().navigateOut();
      }
    }
  });

  registerOnDelete('NOTE_FOLDER', async (ids, options) => {
    const { removeItems, upsertItem, getByType } = useItemStore.getState();
    const trashId = getTrashFolderId();
    const now = Date.now();
    for (const folderId of ids) {
      for (const note of getByType('NOTE', true).filter((n: any) => n.parentID === folderId)) {
        await upsertItem({
          ...note,
          isDeleted: true,
          deletedAt: now,
          updatedAt: now,
          preFolderID: (note as any).preFolderID || (note as any).parentID,
          ...(trashId ? { parentID: trashId } : {}),
        } as any, { needSync: options?.needSync });
      }
    }
    await removeItems(ids, options);
  });
}


