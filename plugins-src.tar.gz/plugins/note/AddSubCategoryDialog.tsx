import React, { useState, useEffect } from 'react';

import '../../common/BasicComponents.css';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

interface AddSubCategoryDialogData {
  initialName?: string;
  onConfirm: (name: string) => void;
}

function AddSubCategoryDialog() {
  const { t } = useTranslation();
  const isOpen = useDialogStore(state => state.dialogs['addSubCategory']?.show);
  const dialogData = useDialogStore(state => state.dialogs['addSubCategory']?.data) as AddSubCategoryDialogData | null;
  const close = () => useDialogStore.getState().close('addSubCategory');

  const initialName = dialogData?.initialName ?? '';
  const onConfirm = dialogData?.onConfirm ?? null;

  const [categoryName, setCategoryName] = useState(initialName);
  const [errorMessage, setErrorMessage] = useState('');

  // 重置（dialog 開啟時）
  useEffect(() => {
    if (isOpen) {
      setCategoryName(initialName);
      setErrorMessage('');
    }
  }, [isOpen, initialName]);

  const handleSubmit = () => {
    if (!categoryName.trim()) return;

    // 檢查名稱是否為空
    if (!categoryName.trim()) {
      setErrorMessage(t('categoryNameEmpty'));
      return;
    }

    onConfirm?.(categoryName.trim());
    close();
  };

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setErrorMessage(''); // 清除錯誤訊息
    setCategoryName(value);
  };

  if (!isOpen) return null;

  return (
    <CustomDialog
      isOpen={true}
      onClose={close}
      title={t('addSubCategory')}
      className="add-subcategory-dialog"
      onConfirm={handleSubmit}
    >
      <input
        type="text"
        value={categoryName}
        onChange={handleInput}
        className="custom-dialog-input"
        placeholder={t('enterSubCategoryName')}
      />
      {errorMessage && <p className="dialog-error">{errorMessage}</p>}
    </CustomDialog>
  );
}

export default AddSubCategoryDialog;
