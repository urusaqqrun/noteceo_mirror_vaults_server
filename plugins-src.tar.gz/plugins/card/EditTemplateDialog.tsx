import React from 'react';
import { useDialogStore } from '../../../Store/dialogStore';
import AddCardTemplateDialog from './AddCardTemplateDialog';

const EditTemplateDialog: React.FC = () => {
    const show = useDialogStore(state => state.dialogs['editTemplate']?.show);
    const data = useDialogStore(state => state.dialogs['editTemplate']?.data);

    if (!show || !data?.cardType) return null;

    const handleClose = () => useDialogStore.getState().close('editTemplate');

    return (
        <AddCardTemplateDialog
            isEdit={true}
            initialData={data.cardType}
            onClose={handleClose}
            myPermission={data.myPermission ?? 50}
            onConfirm={async () => {
                await data.onConfirm?.();
            }}
        />
    );
};

export default EditTemplateDialog;
