// ===== CardPlugin — 卡片插件 =====
//
// 掛載條件：selectedItems 最後一項的 itemType 是 CARD_FOLDER 或 CARD
//
// 面板配置：
//   centerPane1 → （清空，不使用）
//   centerPane2 → leaf-cardgallery (card-gallery，flex:1，min:360)

import React from 'react';
import { registerPluginLocales } from '../../../i18n/registerPluginLocales';
import cardEn from './locales/en.json';
import cardZhHant from './locales/zh-Hant.json';
import cardJa from './locales/ja.json';
import { Plugin } from '../../../workspace/Plugin';
import { registerPluginClass } from '../../../workspace/pluginRegistry';
import { ReactView } from '../../../workspace/ReactView';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { CardLinkPreviewExtension } from './CardLinkPreviewExtension';
import { useCardsStore } from './cardStore';
import { useItemStore } from '../../../Store/itemStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import i18n from '../../../i18n/config';
import type { BaseItem } from '../../../types/item';
import CardFolderIcon from '../../../assets/icon_card_folder_24.svg?react';
import CardIcon from '../../../assets/icon_card_24.svg?react';
import CardRecognitionHint from '../../common/CardRecognitionHint';
import CardGallery from './CardGallery';
import { registerPublicItemType } from '../../../Store/publicItemTypeRegistry';
import AddCardDialog from './AddCardDialog';
import DeleteCardConfirmDialog from './DeleteCardConfirmDialog';
import ContributorsDialog from '../../common/share/ContributorsDialog';
import CardPreviewDialog from './CardPreviewDialog';
import NoEditPermissionDialog from './NoEditPermissionDialog';
import RequestPermissionDialog from './RequestPermissionDialog';
import SharingDialog from '../../common/share/SharingDialog';
import CardDeleteFolderDialog from './CardDeleteFolderDialog';
import CardContextMenu from './CardContextMenu';
import CardTemplateDialog from './CardTemplateDialog';
import EditTemplateDialog from './EditTemplateDialog';
import CardGroupDialog from './CardGroupDialog';
import { GalleryWriteReviewDialog, TemplateWriteReviewDialog } from './WriteReviewDialog';
import { ReviewsListModalDialog } from './ReviewsListDialog';
import { registerWindowComponent } from '../../../workspace/windowComponentRegistry';
import CardWindowContent from './CardWindowContent';
import { useNotificationStore } from '../../../Store/notificationStore';
import PermissionNotificationItem from './PermissionNotificationItem';

// ===== sidebar section 資料 hook：自己的卡片 =====

// ⚠️ Sidebar item 規範：所有 item（items / prefixItems / suffixItems）的 itemType 必須以 _FOLDER 結尾，否則不會顯示
function useCardSidebarData() {
    const cardFolders = useItemStore(s => s.byType['CARD_FOLDER'] ?? []);
    const cards = useItemStore(s => s.byType['CARD'] ?? []);

    const items = React.useMemo(
        () => cardFolders as BaseItem[],
        [cardFolders],
    );

    const getCount = React.useCallback((item: BaseItem) => {
        const count = cards.filter(c => (c as any).parentID === item.id).length;
        return { value: count };
    }, [cards]);

    const renderIcon = React.useCallback((_item: BaseItem) => {
        return <CardFolderIcon className="folder-icon" />;
    }, []);

    return { items, getCount, renderIcon };
}

// ===== CardGallery view =====

class CardGalleryView extends ReactView {
    getViewType() { return 'card-gallery'; }
    getDisplayText() { return '卡片畫廊'; }
    renderComponent() {
        return <CardGallery />;
    }
}

// ===== CardPlugin =====

export class CardPlugin extends Plugin {
    onload() {
        this.registerWindowView('CARD', 'card-gallery', {
            width: 600, height: 700, minWidth: 300, minHeight: 300,
        });

        // 註冊 overlay
        this.registerOverlay('cardRecognitionHint', CardRecognitionHint);
        this.registerOverlay('cardContextMenu', CardContextMenu);
        this.registerOverlay('cardTemplateDialog', CardTemplateDialog);
        this.registerOverlay('editTemplateDialog', EditTemplateDialog);
        this.registerOverlay('cardGroupDialog', CardGroupDialog);
        this.registerOverlay('cardDeleteFolderDialog', CardDeleteFolderDialog);
        this.registerOverlay('addCardDialog', AddCardDialog);
        this.registerOverlay('deleteCardConfirmDialog', DeleteCardConfirmDialog);
        this.registerOverlay('cardPreviewDialog', CardPreviewDialog);
        this.registerOverlay('noEditPermissionDialog', NoEditPermissionDialog);
        this.registerOverlay('requestPermissionDialog', RequestPermissionDialog);
        this.registerOverlay('sharingDialog', SharingDialog);
        this.registerOverlay('contributorsDialog', ContributorsDialog);
        this.registerOverlay('writeReviewDialog', GalleryWriteReviewDialog);
        this.registerOverlay('templateWriteReviewDialog', TemplateWriteReviewDialog);
        this.registerOverlay('reviewsListDialog', ReviewsListModalDialog);

        // 載入 REVIEW items
        useItemStore.getState().loadByType('REVIEW');

        // 註冊 editor 擴展：卡片連結預覽
        this.registerEditorExtension('card:cardLinkPreview', CardLinkPreviewExtension);

        // 卡片拖到 MarkdownEditor：插入卡片連結
        this.registerEvent('drop:markdown-editor', async (items: any[], _meta: any, editor: any, dropPos: number) => {
            const cardItems = items.filter(i => i.itemType === 'CARD');
            if (cardItems.length === 0 || !editor || dropPos == null) return;
            for (const item of cardItems) {
                const linkText = item.name || i18n.t('untitledCard');
                const cardLink = `cubelv://card/${item.id}`;
                editor.chain().insertContentAt(dropPos, {
                    type: 'text',
                    text: linkText,
                    marks: [{ type: 'link', attrs: { href: cardLink, class: 'editor-link', target: '_blank' } }]
                }).run();
            }
        });

        this.registerSidebarWithView({
            sidebar: {
                id: 'card',
                title: i18n.t('sidebarCards'),
                orderAt: 400,
                useData: useCardSidebarData,
                addFolder: {
                    actionText: i18n.t('addCardFolder'),
                    icon: <CardFolderIcon />,
                    onClick: () => useDialogStore.getState().open('addTemplate', { mode: 'card' }),
                },
            },
            views: [
                { type: 'card-gallery', creator: (leaf) => new CardGalleryView(leaf) },
            ],
            activateOnItemTypes: ['CARD_FOLDER', 'CARD'],
            panes: {
                centerPane1: 'clear',
                centerPane2: { leafId: 'leaf-cardgallery', viewType: 'card-gallery', flex: 1, minSize: 360 },
            },
        });

        // 註冊搜尋 provider
        this.registerSearchProvider('CARD', {
            renderIcon: () => <CardIcon />,
            search: (query) => {
                const cards = useItemStore.getState().getByType('CARD');
                const q = query.toLowerCase();
                return cards.filter(c => {
                    if (!query) return true;
                    return c.name?.toLowerCase().includes(q)
                        || JSON.stringify((c as any).cardFields || {}).toLowerCase().includes(q);
                });
            },
        });
        this.registerSearchProvider('CARD_FOLDER', {
            renderIcon: () => <CardFolderIcon />,
            search: (query) => {
                const cardFolders = useItemStore.getState().getByType('CARD_FOLDER');
                const q = query.toLowerCase();
                return cardFolders.filter(ct => !query || ct.name?.toLowerCase().includes(q));
            },
        });

        // 右鍵選單
        this.registerEvent('contextMenu', ({ item, event }: { item: BaseItem; event: React.MouseEvent }) => {
            const scale = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--content-scale').trim()) || 1;
            if (item.itemType === 'CARD_FOLDER') {
                useMenuStore.getState().openAt('sidebarCardFolder', event.clientX / scale, event.clientY / scale, {
                    folder: item, isGroup: false,
                });
            }
        });

        // onOpenCard：從主進程/Web 版雙擊卡片 → 導航到該卡片
        if (window.electronAPI?.onOpenCard) {
            const unsubscribe = window.electronAPI.onOpenCard(async (cardId: string) => {
                const card = await window.electronAPI.getItem(cardId);
                if (card) useSelectedItemsStore.getState().setSelectedItems([card]);
            });
            if (typeof unsubscribe === 'function') {
                this.register(unsubscribe as () => void);
            }
        }

        // 註冊權限請求通知的自訂渲染器
        this.register(
            useNotificationStore.getState().registerNotificationRenderer('permission_request', {
                Component: PermissionNotificationItem,
            })
        );

        // 註冊 AI Skill：卡片模板生成與調整
        this.registerAISkill({
            name: 'card_template',
            instruction: `# 卡片模板生成與調整

## 建立新模板

根據卡片類型定義生成 HTML + CSS 模板。

輸入：
- Card Type（資料夾名稱）
- Fields（欄位定義 JSON）
- Style Hint（用戶設計提示，可選）

## 調整現有模板

根據用戶指示修改現有模板的 HTML/CSS。

輸入：
- Current HTML + CSS
- Fields
- Adjustment（調整指示）

## 規則（建立和調整共用）

- ALL CSS class names MUST start with "card-template-" prefix to avoid conflicts
- NO emojis at all. If one emoji appears, output is invalid
- Use exact field names as placeholders: {{fieldName}}
- If CSS uses attribute selectors like [data-value="..."], the HTML element MUST also have that attribute with the placeholder
- Each placeholder appears once and only once
- IMAGE field → image placeholder; others → text only
- RATING field → DO NOT add star icons before the placeholder. The system will auto-render stars (★☆)
- TAGS field → System renders as multiple <span> elements. Use container selector for styling. Do NOT assume any class on span
- Fixed card width 280–400px, height auto
- Use modern CSS (flex/grid, rounded corners, shadow)
- Prevent overflow: word-wrap: break-word; overflow-wrap: break-word; overflow: hidden

## Colors

- Background: var(--surface)
- Text: var(--on)
- Link: var(--linkcolor)
- Use color-mix() for transparency

## Icons

- No emoji
- Icons inherit color and size
- No icon-specific CSS
- Use Google Material Symbols only: <span class="g-icon">icon_name</span>
- Icon and text must be vertically centered (use align-items: center)

## Output

- Return ONLY one JSON object
- Format: {"templateHtml":"...","templateCss":"..."}
- No text before or after JSON`,
        });

        // AI Hints
        this.registerAIHints('CARD_FOLDER', [
            '當使用者要求建立新的卡片畫廊、或調整現有畫廊的模板樣式時，先讀取 .skills/card_template.md 取得 templateHtml/templateCss 的生成規則',
            '建立畫廊時必須定義 cardFieldsDef（欄位名稱+類型），再依照 .skills/card_template.md 的規則生成 templateHtml 和 templateCss 寫入 JSON',
            'visual entities（餐廳/人物/書籍/電影/產品/地點）必須包含 IMAGE 欄位',
        ]);
        this.registerAIHints('CARD', [
            'IMAGE 欄位必須搜尋圖片 URL（用 web_search MCP 工具搜尋 + 取得直接圖片連結），不可留空',
            '收集卡片前先查現有卡片避免重複',
        ]);

    }
}

registerWindowComponent('card-gallery', CardWindowContent);
registerPublicItemType('CARD_FOLDER');
registerPluginClass(CardPlugin, '卡片', {
    dependencies: ['SidebarPlugin'],
    descriptionKey: 'modulesCardDesc',
    setupI18n: () => registerPluginLocales('CardPlugin', { 'en': cardEn, 'zh-Hant': cardZhHant, 'ja': cardJa }),
});
