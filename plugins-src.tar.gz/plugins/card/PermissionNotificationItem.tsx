import React, { useState } from 'react';
import type { NotificationItemProps } from '../../../Store/notificationStore';
import { addItemPermission } from '../../../utils/shareAPI';
import { useNotificationStore } from '../../../Store/notificationStore';
import { useTranslation } from 'react-i18next';
import '../../../components/common/Notification.css';

/**
 * 權限請求通知 — 自訂渲染器
 * 顯示「XXX 請求存取 YYY」+ 駁回 / 確認 按鈕
 */
function PermissionNotificationItem({ notification, onMarkRead, onDelete }: NotificationItemProps) {
    const { t } = useTranslation();
    const { data, isRead, createdAt } = notification;
    const [loading, setLoading] = useState(false);

    const text = t('notification.permission_request', {
        requesterName: data.requesterName || '未知用戶',
        itemName: data.itemName || '未知項目',
    });

    const handleApprove = async (e: React.MouseEvent) => {
        e.stopPropagation();
        if (loading) return;
        setLoading(true);
        try {
            await addItemPermission(data.itemId, data.requesterId, 'editor');
            onMarkRead();
        } catch (err) {
            console.error('[PermissionNotification] approve error:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleReject = (e: React.MouseEvent) => {
        e.stopPropagation();
        onDelete();
    };

    const handleClick = () => {
        if (!isRead) onMarkRead();
    };

    const diff = Date.now() - createdAt;
    const minutes = Math.floor(diff / 60000);
    let timeAgo = '剛剛';
    if (minutes >= 60 * 24) timeAgo = `${Math.floor(minutes / (60 * 24))} 天前`;
    else if (minutes >= 60) timeAgo = `${Math.floor(minutes / 60)} 小時前`;
    else if (minutes >= 1) timeAgo = `${minutes} 分鐘前`;

    return (
        <div
            className={`notification-item ${isRead ? '' : 'unread'}`}
            onClick={handleClick}
        >
            <div className={`notification-item-dot ${isRead ? 'read' : ''}`} />
            <div className="notification-item-content">
                <div className="notification-item-text">{text}</div>
                <div className="notification-item-time">{timeAgo}</div>
                {!isRead && (
                    <div className="notification-actions">
                        <button onClick={handleReject} disabled={loading}>
                            {t('reject')}
                        </button>
                        <button className="primary" onClick={handleApprove} disabled={loading}>
                            {loading ? '...' : t('approve')}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}

export default PermissionNotificationItem;
