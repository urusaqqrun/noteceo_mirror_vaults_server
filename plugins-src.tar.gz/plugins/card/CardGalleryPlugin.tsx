// ===== CardGalleryPlugin — CardGallery 插件 =====

import React from 'react';
import { Plugin } from '../../../workspace/Plugin';
import { ReactView } from '../../../workspace/ReactView';
import CardGallery from './CardGallery';

class CardGalleryView extends ReactView {
    getViewType() { return 'card-gallery'; }
    getDisplayText() { return '卡片画廊'; }
    renderComponent() { return <CardGallery />; }
}

export class CardGalleryPlugin extends Plugin {
    onload() {
        this.registerView('card-gallery', (leaf) => new CardGalleryView(leaf));
    }
}
