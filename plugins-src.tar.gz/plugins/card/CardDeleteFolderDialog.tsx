import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDialogStore } from '../../../Store/dialogStore';
import { useCardsStore } from './cardStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { CustomDialog } from '../../common/CustomDialog';

const CardDeleteFolderDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['deleteFolder']?.show);
    const folder = useDialogStore(state => state.dialogs['deleteFolder']?.data?.folder);

    if (!showDialog || !folder || (folder.itemType !== 'CARD_FOLDER' && !(folder as any).isCardFolder)) return null;

    const hideDialog = () => useDialogStore.getState().close('deleteFolder');

    const handleConfirm = async () => {
        try {
            await useCardsStore.getState().deleteCardFolder(folder.id);

            const cardFolders = useItemStore.getState().getByType('CARD_FOLDER');
            const remaining = cardFolders.filter(f => f.id !== folder.id);
            if (remaining.length > 0) {
                useSelectedItemsStore.getState().setSelectedItems([remaining[0]], { scrollToFocusItem: true });
            }
            useTempHintStore.getState().setTempHint(t('deletedCardStack', { name: folder.name }));
            hideDialog();
        } catch (error) {
            console.error('刪除失敗:', error);
            useTempHintStore.getState().setTempHint(t('deleteFailed'));
        }
    };

    return (
        <CustomDialog isOpen onClose={hideDialog} title={t('deleteCardStack')} onConfirm={handleConfirm}>
            <p className="custom-dialog-description">
                {t('deleteCardStackConfirm', { name: folder.name })}
            </p>
        </CustomDialog>
    );
};

export default CardDeleteFolderDialog;
