import React, { useState, useRef, useCallback, useMemo, useEffect } from 'react';
import { createPortal } from 'react-dom';
import './CardListView.css';
import { useTranslation } from 'react-i18next';
import { formatTimestamp } from '../../Utils/dateFormat';
import DragHandleIcon from '../../../assets/icon_drag_handle_blocks_24.svg?react';
import DateRangeDialog from '../../common/DateRangeDialog';

import { useDialogStore } from '../../../Store/dialogStore';
import { useItemStore } from '../../../Store/itemStore';
import { getCardRatingStats, getMyReview } from './reviewStore';

/**
 * 卡片列表視圖組件
 * 支援：
 * - 行拖曳排序（Editor 以上權限）
 * - 長按 Header 拖曳調整欄位順序（Editor 以上權限）
 * - 點擊單元格編輯（根據欄位類型顯示不同 UI）
 */
const CardListView = ({
  cards = [],
  cardType,
  canEdit = false, // Editor 以上權限
  canRate = false, // Contributor 以上權限（評分用）
  onCardClick, // 點擊卡片（打開 info panel）
  onCardUpdate, // 更新卡片欄位
  onRatingChange, // 評分變更回調（card, rating）→ 走 reviews 系統
  onCardReorder, // 更新卡片排序（傳入 movedCard, newOrderAt）
  onFieldsReorder, // 更新欄位順序（傳入新的 fields 陣列）
  onCardHover, // hover 卡片時的回調（用於預覽）
  onContextMenu, // 右鍵選單回調（傳入 event, card）
  isMobileView = false, // 是否為手機模式
  currentMemberID = null, // 當前用戶 ID（用於評分拆分）
}) => {
  const { t } = useTranslation();

  // cardType.cardFieldsDef 可能是 JSON 字串，統一解析（本地 Item 格式）
  const parsedFields = useMemo(() => {
    const raw = (cardType as any)?.cardFieldsDef ?? (cardType as any)?.fields;
    if (typeof raw === 'string') {
      try { return JSON.parse(raw); } catch { return []; }
    }
    return raw || [];
  }, [(cardType as any)?.cardFieldsDef, (cardType as any)?.fields]);

  // 可見欄位（排除 IMAGE 類型）
  const visibleFields = useMemo(() => {
    return parsedFields.filter(f => f.type !== 'IMAGE');
  }, [parsedFields]);

  // 訂閱 REVIEW items 變更以觸發 re-render
  const allReviewItems = useItemStore(s => s.byType['REVIEW'] ?? []);

  // 檢查是否有任何卡片有其他人的評分
  const hasOtherReviews = useMemo(() => {
    return cards.some(card => getCardRatingStats(card.id).ratingCount > 0);
  }, [cards, allReviewItems]);

  // 展開欄位：RATING 拆成「我的給分」+「平均評分」兩欄（僅當有其他人評分時才顯示平均評分）
  const displayFields = useMemo(() => {
    const result = [];
    visibleFields.forEach(field => {
      if (field.type === 'RATING') {
        result.push({ ...field, _ratingMode: 'personal', _colKey: `${field.name}__personal` });
        if (hasOtherReviews) {
          result.push({ ...field, _ratingMode: 'average', _colKey: `${field.name}__average` });
        }
      } else {
        result.push({ ...field, _colKey: field.name });
      }
    });
    return result;
  }, [visibleFields, hasOtherReviews]);

  // 計算卡片的平均評分（從 REVIEW items 取得）
  const getCardAvgRating = useCallback((card, fieldName) => {
    const stats = getCardRatingStats(card.id);
    return { avg: stats.avg, count: stats.ratingCount };
  }, [allReviewItems]);

  // 取得「我的給分」（從 REVIEW items 取得）
  const getMyRating = useCallback((card, fieldName) => {
    if (!currentMemberID) return 0;
    const myRev = getMyReview(card.id, currentMemberID);
    if (myRev?.rating) {
      return myRev.rating;
    }
    return 0;
  }, [currentMemberID, allReviewItems]);

  // 計算每個欄位的自適應寬度（使用 displayFields）
  const columnWidths = useMemo(() => {
    if (!displayFields.length || !cards.length) return {};

    // 計算文字寬度的輔助函數（估算：中文字約 14px，英文/數字約 8px）
    const estimateTextWidth = (text) => {
      if (!text) return 0;
      const str = String(text);
      let width = 0;
      for (let i = 0; i < str.length; i++) {
        // 中文字符範圍
        if (str.charCodeAt(i) > 127) {
          width += 14;
        } else {
          width += 8;
        }
      }
      return width;
    };

    // 根據欄位類型設定基礎寬度
    const getBaseWidth = (field) => {
      if (field._ratingMode === 'personal') return 120; // 5 顆星
      if (field._ratingMode === 'average') return 70; // 數字顯示
      switch (field.type) {
        case 'RATING': return 100;
        case 'BOOLEAN': return 50;
        case 'DATE': return 90;
        case 'DATE_RANGE': return 160;
        case 'NUMBER': return 70;
        case 'SELECT': return 80;
        case 'MULTISELECT': return 100;
        default: return 80;
      }
    };

    const widths = {};

    displayFields.forEach((field) => {
      // Header 文字
      let headerText = field.name;
      if (field._ratingMode === 'personal') headerText = t('myRating');
      if (field._ratingMode === 'average') headerText = t('avgRating');

      // 1. Header 文字寬度
      const headerWidth = estimateTextWidth(headerText) + 16;

      // 2. 根據欄位類型的基礎寬度
      const baseWidth = getBaseWidth(field);

      // 3. 計算該欄位所有值的最大寬度（取樣前 50 筆）
      let maxContentWidth = 0;
      const sampleCards = cards.slice(0, 50);
      sampleCards.forEach(card => {
        const val = card.cardFields?.[field.name];
        let displayText = '';

        if (field._ratingMode === 'personal') {
          displayText = '★★★★★';
        } else if (field._ratingMode === 'average') {
          displayText = '5.0(99)';
        } else if (field.type === 'DATE' && val) {
          displayText = 'YYYY/MM/DD';
        } else if (field.type === 'DATE_RANGE' && val) {
          displayText = 'YYYY/MM/DD - YYYY/MM/DD';
        } else if (Array.isArray(val)) {
          displayText = val.join(', ');
        } else if (val) {
          displayText = String(val);
        }

        const contentWidth = estimateTextWidth(displayText);
        if (contentWidth > maxContentWidth) {
          maxContentWidth = contentWidth;
        }
      });

      // 4. 取三者最大值，加上 padding
      const calculatedWidth = Math.max(headerWidth, baseWidth, maxContentWidth + 16);

      // 5. 設定最小/最大寬度限制
      const minWidth = 80;
      const maxWidth = isMobileView ? 100 : 400;
      widths[field._colKey] = Math.min(Math.max(calculatedWidth, minWidth), maxWidth);
    });

    return widths;
  }, [displayFields, cards, isMobileView, t]);

  // 行拖曳狀態
  const [draggedRowIndex, setDraggedRowIndex] = useState(null);
  const [dragOverRowIndex, setDragOverRowIndex] = useState(null);
  const [dragOverRowPosition, setDragOverRowPosition] = useState(null); // 'top' | 'bottom'

  // Header 拖曳狀態
  const [draggedColIndex, setDraggedColIndex] = useState(null);
  const [dragOverColIndex, setDragOverColIndex] = useState(null);
  const [dragOverColPosition, setDragOverColPosition] = useState(null); // 'left' | 'right'
  const [canDragHeader, setCanDragHeader] = useState(false);
  const headerLongPressTimer = useRef(null);
  const headerLongPressColRef = useRef(null);

  // 編輯狀態
  const [editingCell, setEditingCell] = useState(null); // { cardId, fieldName }
  const [editValue, setEditValue] = useState('');
  const [openSelect, setOpenSelect] = useState(null); // 展開的 SELECT/MULTISELECT { cardId, fieldName, fieldType, options, position }
  const [dateRangeDialog, setDateRangeDialog] = useState(null); // { card, fieldName }
  const selectMenuRef = useRef(null);
  const selectTriggerRef = useRef(null); // 用於記錄觸發元素
  const inputRef = useRef(null);

  // Hover 狀態
  const [hoveredRowIndex, setHoveredRowIndex] = useState(null);

  // 排序狀態：{ fieldName: string, direction: 'asc' | 'desc' } | null
  const [sortConfig, setSortConfig] = useState(null);

  // 根據排序配置排序卡片
  const sortedCards = useMemo(() => {
    if (!sortConfig) return cards;

    const { fieldName: sortKey, direction } = sortConfig;

    // 判斷是否為評分拆分欄位（colKey 格式：fieldName__personal 或 fieldName__average）
    const isPersonalRating = sortKey.endsWith('__personal');
    const isAverageRating = sortKey.endsWith('__average');
    const actualFieldName = (isPersonalRating || isAverageRating)
      ? sortKey.replace(/__personal$|__average$/, '')
      : sortKey;

    const field = visibleFields.find(f => f.name === actualFieldName);
    if (!field) return cards;

    return [...cards].sort((a, b) => {
      const aVal = a.cardFields?.[actualFieldName];
      const bVal = b.cardFields?.[actualFieldName];

      // 處理空值：NUMBER/RATING 視為 0，其他類型排最後
      const aEmpty = aVal === null || aVal === undefined;
      const bEmpty = bVal === null || bVal === undefined;

      if (field.type === 'NUMBER') {
        const aNum = aEmpty ? 0 : (Number(aVal) || 0);
        const bNum = bEmpty ? 0 : (Number(bVal) || 0);
        const comparison = aNum - bNum;
        return direction === 'asc' ? comparison : -comparison;
      }

      if (field.type === 'RATING') {
        let aRating, bRating;
        if (isPersonalRating) {
          // 按「我的給分」排序
          aRating = getMyRating(a, actualFieldName);
          bRating = getMyRating(b, actualFieldName);
        } else {
          // 按「平均評分」排序（預設）
          aRating = getCardAvgRating(a, actualFieldName);
          bRating = getCardAvgRating(b, actualFieldName);
        }
        const comparison = aRating - bRating;
        return direction === 'asc' ? comparison : -comparison;
      }

      // 其他類型：空值排最後
      if (aEmpty) return 1;
      if (bEmpty) return -1;

      let comparison = 0;

      if (field.type === 'DATE') {
        const aDate = typeof aVal === 'string' && isNaN(Number(aVal)) ? new Date(aVal) : new Date(Number(aVal));
        const bDate = typeof bVal === 'string' && isNaN(Number(bVal)) ? new Date(bVal) : new Date(Number(bVal));
        comparison = aDate.getTime() - bDate.getTime();
      } else {
        comparison = String(aVal).localeCompare(String(bVal), 'zh-Hant');
      }

      return direction === 'asc' ? comparison : -comparison;
    });
  }, [cards, sortConfig, visibleFields, getMyRating, getCardAvgRating]);

  // Header 點擊排序：未排序 → 升序 → 降序 → 未排序
  const handleHeaderSort = useCallback((fieldName) => {
    setSortConfig(prev => {
      if (!prev || prev.fieldName !== fieldName) {
        // 新欄位或之前沒有排序，設為升序
        return { fieldName, direction: 'asc' };
      } else if (prev.direction === 'asc') {
        // 升序 → 降序
        return { fieldName, direction: 'desc' };
      } else {
        // 降序 → 未排序
        return null;
      }
    });
  }, []);

  // 格式化欄位值顯示
  const formatFieldValue = useCallback((field, val) => {
    if (val === null || val === undefined) return '';
    if (field.type === 'RATING') return '★'.repeat(val || 0);
    if (field.type === 'DATE' && val) {
      // 如果是字符串（已格式化的日期），直接返回；否則當作時間戳處理
      if (typeof val === 'string' && isNaN(Number(val))) return val;
      return formatTimestamp(val);
    }
    if (field.type === 'DATE_RANGE' && val) {
      const start = val.start ? formatTimestamp(val.start) : '';
      const end = val.end ? formatTimestamp(val.end) : '';
      return start && end ? `${start} - ${end}` : start || end;
    }
    if (field.type === 'LOCATION' && val) return val;
    if (Array.isArray(val)) return val.join(', ');
    return String(val);
  }, []);

  // ==================== 行拖曳處理 ====================
  const handleRowDragStart = useCallback((e, index) => {
    if (!canEdit) return;
    setDraggedRowIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  }, [canEdit]);

  const handleRowDragOver = useCallback((e, index) => {
    if (!canEdit || draggedRowIndex === null) return;
    e.preventDefault();

    const rect = e.currentTarget.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const position = e.clientY < midY ? 'top' : 'bottom';

    setDragOverRowIndex(index);
    setDragOverRowPosition(position);
  }, [canEdit, draggedRowIndex]);

  const handleRowDragEnd = useCallback(() => {
    setDraggedRowIndex(null);
    setDragOverRowIndex(null);
    setDragOverRowPosition(null);
  }, []);

  const handleRowDrop = useCallback((e, dropIndex) => {
    if (!canEdit || draggedRowIndex === null) return;
    e.preventDefault();

    let insertIndex = dropIndex;
    if (dragOverRowPosition === 'bottom') {
      insertIndex = dropIndex + 1;
    }
    if (draggedRowIndex < insertIndex) {
      insertIndex -= 1;
    }

    if (draggedRowIndex !== insertIndex && onCardReorder) {
      const movedCard = cards[draggedRowIndex];
      const prevCard = insertIndex > 0 ? cards[insertIndex - 1] : null;
      const nextCard = insertIndex < cards.length - 1 ? cards[insertIndex + 1] : null;

      // 調整：如果是往下移動，需要用移動後的前後卡片
      let actualPrevCard = prevCard;
      let actualNextCard = nextCard;

      if (draggedRowIndex < insertIndex) {
        // 往下移動
        actualPrevCard = cards[insertIndex];
        actualNextCard = insertIndex + 1 < cards.length ? cards[insertIndex + 1] : null;
      } else {
        // 往上移動
        actualPrevCard = insertIndex > 0 ? cards[insertIndex - 1] : null;
        actualNextCard = cards[insertIndex];
      }

      onCardReorder(movedCard, actualPrevCard, actualNextCard);
    }

    handleRowDragEnd();
  }, [canEdit, draggedRowIndex, dragOverRowPosition, cards, onCardReorder, handleRowDragEnd]);

  // ==================== Header 拖曳處理（長按觸發）====================
  const handleHeaderMouseDown = useCallback((e, colIndex) => {
    if (!canEdit) return;
    headerLongPressColRef.current = colIndex;

    headerLongPressTimer.current = setTimeout(() => {
      setCanDragHeader(true);
      setDraggedColIndex(colIndex);
    }, 300); // 長按 300ms 觸發
  }, [canEdit]);

  const handleHeaderMouseUp = useCallback(() => {
    if (headerLongPressTimer.current) {
      clearTimeout(headerLongPressTimer.current);
      headerLongPressTimer.current = null;
    }
    headerLongPressColRef.current = null;
  }, []);

  const handleHeaderMouseLeave = useCallback(() => {
    if (headerLongPressTimer.current) {
      clearTimeout(headerLongPressTimer.current);
      headerLongPressTimer.current = null;
    }
  }, []);

  const handleHeaderDragStart = useCallback((e, colIndex) => {
    if (!canEdit || !canDragHeader) {
      e.preventDefault();
      return;
    }
    setDraggedColIndex(colIndex);
    e.dataTransfer.effectAllowed = 'move';
  }, [canEdit, canDragHeader]);

  const handleHeaderDragOver = useCallback((e, colIndex) => {
    if (!canEdit || draggedColIndex === null) return;
    e.preventDefault();

    // 判斷滑鼠在左半部分還是右半部分
    const rect = e.currentTarget.getBoundingClientRect();
    const midX = rect.left + rect.width / 2;
    const position = e.clientX < midX ? 'left' : 'right';

    setDragOverColIndex(colIndex);
    setDragOverColPosition(position);
  }, [canEdit, draggedColIndex]);

  const handleHeaderDragEnd = useCallback(() => {
    setDraggedColIndex(null);
    setDragOverColIndex(null);
    setDragOverColPosition(null);
    setCanDragHeader(false);
  }, []);

  const handleHeaderDrop = useCallback((e, dropIndex) => {
    if (!canEdit || draggedColIndex === null) return;
    e.preventDefault();

    // 根據放置位置計算插入點
    let insertIndex = dropIndex;
    if (dragOverColPosition === 'right') {
      insertIndex = dropIndex + 1;
    }
    if (draggedColIndex < insertIndex) {
      insertIndex -= 1;
    }

    if (draggedColIndex !== insertIndex && onFieldsReorder) {
      const newFields = [...visibleFields];
      const [draggedField] = newFields.splice(draggedColIndex, 1);
      newFields.splice(insertIndex, 0, draggedField);

      // 重建完整的 fields 陣列（包含 IMAGE 類型）
      const imageFields = parsedFields.filter(f => f.type === 'IMAGE');
      const fullFields = [...imageFields, ...newFields];

      onFieldsReorder(fullFields);
    }

    handleHeaderDragEnd();
  }, [canEdit, draggedColIndex, dragOverColPosition, visibleFields, parsedFields, onFieldsReorder, handleHeaderDragEnd]);

  // ==================== 單元格編輯處理 ====================
  const handleCellClick = useCallback((e, card, field, fieldIndex) => {
    e.stopPropagation();

    if (!canEdit) {
      // 沒有編輯權限，顯示權限不足 dialog
      useDialogStore.getState().open('noEditPermission');
      return;
    }

    const fieldType = field.type;
    const currentValue = card.cardFields?.[field.name];

    // 根據欄位類型處理編輯
    if (fieldType === 'SELECT' || fieldType === 'MULTISELECT') {
      // 展開選擇器，記錄位置用於 Portal 定位
      const rect = e.currentTarget.getBoundingClientRect();
      // 簡單判斷：螢幕下半部往上長，否則往下長
      const shouldOpenUpward = rect.top > window.innerHeight / 2;

      setOpenSelect({
        cardId: card.id,
        fieldName: field.name,
        fieldType,
        options: field.options || [],
        position: {
          bottom: shouldOpenUpward ? window.innerHeight - rect.top + 4 : undefined,
          top: shouldOpenUpward ? undefined : rect.bottom + 4,
          left: rect.left,
          width: rect.width,
          openUpward: shouldOpenUpward
        }
      });
      setEditingCell({ cardId: card.id, fieldName: field.name });
    } else if (fieldType === 'RATING') {
      // 評分不需要特殊處理，直接透過星星點擊
      return;
    } else if (fieldType === 'BOOLEAN') {
      // 布林值直接切換
      const newValue = !(currentValue === 'true' || currentValue === true);
      onCardUpdate?.(card, field.name, newValue ? 'true' : 'false');
    } else if (fieldType === 'DATE') {
      // DATE 類型：內聯編輯
      setEditingCell({ cardId: card.id, fieldName: field.name });
      setEditValue(currentValue || '');
    } else if (fieldType === 'DATE_RANGE') {
      // DATE_RANGE 類型：打開共用的 DateRangeDialog
      setDateRangeDialog({ card, fieldName: field.name });
    } else {
      // 文字類型：內聯編輯
      setEditingCell({ cardId: card.id, fieldName: field.name });
      setEditValue(currentValue || '');
    }
  }, [canEdit, onCardUpdate]);

  // 評分點擊處理（走 reviews 系統）
  const handleRatingClick = useCallback((e, card, field, rating) => {
    e.stopPropagation();
    if (!canRate) {
      useDialogStore.getState().open('noEditPermission');
      return;
    }

    onRatingChange?.(card, rating);
  }, [canRate, onRatingChange]);

  // SELECT 選擇處理
  const handleSelectChange = useCallback((card, fieldName, value) => {
    onCardUpdate?.(card, fieldName, value);
    // 即時更新預覽
    onCardHover?.({
      ...card,
      cardFields: { ...card.cardFields, [fieldName]: value }
    });
    setOpenSelect(null);
    setEditingCell(null);
  }, [onCardUpdate, onCardHover]);

  // MULTISELECT 選擇處理
  const handleMultiselectToggle = useCallback((card, fieldName, option, currentValues) => {
    const values = Array.isArray(currentValues)
      ? currentValues
      : (currentValues ? currentValues.split(/[,，、]/).map(s => s.trim()).filter(Boolean) : []);

    let newValues;
    if (values.includes(option)) {
      newValues = values.filter(v => v !== option);
    } else {
      newValues = [...values, option];
    }

    // 即時更新預覽
    const newValueStr = newValues.join(', ');
    onCardHover?.({
      ...card,
      cardFields: { ...card.cardFields, [fieldName]: newValueStr }
    });

    onCardUpdate?.(card, fieldName, newValues.join(', '));
  }, [onCardUpdate]);

  // 文字編輯完成
  const handleEditComplete = useCallback(() => {
    if (editingCell && editValue !== undefined) {
      const card = cards.find(c => c.id === editingCell.cardId);
      if (card) {
        const currentValue = card.cardFields?.[editingCell.fieldName] || '';
        if (editValue !== currentValue) {
          onCardUpdate?.(card, editingCell.fieldName, editValue);
        }
      }
    }
    setEditingCell(null);
    setEditValue('');
  }, [editingCell, editValue, cards, onCardUpdate]);

  // 按鍵處理
  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleEditComplete();
    } else if (e.key === 'Escape') {
      setEditingCell(null);
      setEditValue('');
    }
  }, [handleEditComplete]);

  // 點擊外部關閉編輯
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (openSelect && selectMenuRef.current && !selectMenuRef.current.contains(e.target)) {
        setOpenSelect(null);
        setEditingCell(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [openSelect]);

  // 自動 focus 輸入框
  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingCell]);

  // 渲染單元格內容
  const renderCellContent = useCallback((card, field, fieldIndex) => {
    const value = card.cardFields?.[field.name];
    const isEditing = editingCell?.cardId === card.id && editingCell?.fieldName === field.name;
    const isSelectOpen = openSelect?.cardId === card.id && openSelect?.fieldName === field.name;

    // 評分欄位 - 我的給分（星星可點擊）
    if (field.type === 'RATING' && field._ratingMode === 'personal') {
      const myRating = getMyRating(card, field.name);
      return (
        <div className="card-list-view-rating">
          {[1, 2, 3, 4, 5].map(star => (
            <span
              key={star}
              className={`card-list-view-star ${star <= myRating ? 'filled' : ''} ${canRate ? 'editable' : ''}`}
              onClick={(e) => handleRatingClick(e, card, field, star)}
            >
              ★
            </span>
          ))}
        </div>
      );
    }

    // 評分欄位 - 平均評分（數字顯示）
    if (field.type === 'RATING' && field._ratingMode === 'average') {
      const { avg, count } = getCardAvgRating(card, field.name);
      if (avg === 0) return <span className="card-list-view-placeholder">-</span>;
      return (
        <span className="card-list-view-avg-rating">{avg.toFixed(1)}({count})</span>
      );
    }

    // SELECT 欄位
    if (field.type === 'SELECT') {
      return (
        <div className="card-list-view-select-container">
          <span
            className={`card-list-view-select-value ${canEdit ? 'editable' : ''}`}
            onClick={(e) => handleCellClick(e, card, field, fieldIndex)}
          >
            {value || <span className="card-list-view-placeholder">{t('selectOption')}</span>}
          </span>
          {isSelectOpen && openSelect?.position && createPortal(
            <div
              className={`card-list-view-select-menu ${openSelect.position.openUpward ? 'open-upward' : ''}`}
              ref={selectMenuRef}
              style={{
                position: 'fixed',
                top: openSelect.position.top,
                bottom: openSelect.position.bottom,
                left: openSelect.position.left,
                minWidth: Math.max(150, openSelect.position.width),
              }}
            >
              {field.options?.map((opt, idx) => (
                <div
                  key={idx}
                  className={`card-list-view-select-option ${value === opt ? 'selected' : ''}`}
                  onClick={() => handleSelectChange(card, field.name, opt)}
                >
                  {opt}
                </div>
              ))}
            </div>,
            document.body
          )}
        </div>
      );
    }

    // MULTISELECT 欄位
    if (field.type === 'MULTISELECT') {
      const selectedValues = Array.isArray(value)
        ? value
        : (value ? value.split(/[,，、]/).map(s => s.trim()).filter(Boolean) : []);

      return (
        <div className="card-list-view-select-container">
          <span
            className={`card-list-view-select-value ${canEdit ? 'editable' : ''}`}
            onClick={(e) => handleCellClick(e, card, field, fieldIndex)}
          >
            {selectedValues.length > 0
              ? selectedValues.join(', ')
              : <span className="card-list-view-placeholder">{t('selectOptions')}</span>
            }
          </span>
          {isSelectOpen && openSelect?.position && createPortal(
            <div
              className={`card-list-view-select-menu ${openSelect.position.openUpward ? 'open-upward' : ''}`}
              ref={selectMenuRef}
              style={{
                position: 'fixed',
                top: openSelect.position.top,
                bottom: openSelect.position.bottom,
                left: openSelect.position.left,
                minWidth: Math.max(150, openSelect.position.width),
              }}
            >
              {field.options?.map((opt, idx) => (
                <label key={idx} className="card-list-view-multiselect-option">
                  <input
                    type="checkbox"
                    checked={selectedValues.includes(opt)}
                    onChange={() => handleMultiselectToggle(card, field.name, opt, value)}
                  />
                  <span>{opt}</span>
                </label>
              ))}
            </div>,
            document.body
          )}
        </div>
      );
    }

    // DATE 類型內聯編輯
    if (isEditing && field.type === 'DATE') {
      return (
        <input
          ref={inputRef}
          type="date"
          className="card-list-view-input"
          value={editValue ? editValue.replace(/\//g, '-') : ''}
          onChange={(e) => {
            const newValue = e.target.value.replace(/-/g, '/');
            setEditValue(newValue);
            onCardHover?.({
              ...card,
              cardFields: { ...card.cardFields, [field.name]: newValue }
            });
          }}
          onBlur={handleEditComplete}
          onKeyDown={handleKeyDown}
        />
      );
    }

    // 文字類型內聯編輯
    if (isEditing && field.type !== 'DATE_RANGE') {
      return (
        <input
          ref={inputRef}
          type={field.type === 'NUMBER' ? 'number' : 'text'}
          className="card-list-view-input"
          value={editValue}
          onChange={(e) => {
            const newValue = e.target.value;
            setEditValue(newValue);
            // 即時更新預覽：傳入帶有修改值的臨時卡片
            onCardHover?.({
              ...card,
              cardFields: { ...card.cardFields, [field.name]: newValue }
            });
          }}
          onBlur={handleEditComplete}
          onKeyDown={handleKeyDown}
        />
      );
    }

    // 一般顯示
    return (
      <span
        className={`card-list-view-text ${canEdit ? 'editable' : ''}`}
        onClick={(e) => handleCellClick(e, card, field, fieldIndex)}
      >
        {formatFieldValue(field, value) || <span className="card-list-view-placeholder">-</span>}
      </span>
    );
  }, [editingCell, editValue, openSelect, canEdit, canRate, t, handleCellClick, handleRatingClick, handleSelectChange, handleMultiselectToggle, handleEditComplete, handleKeyDown, formatFieldValue, getMyRating, getCardAvgRating]);

  if (!cardType || displayFields.length === 0) {
    return <div className="card-list-view-empty">{t('noFields')}</div>;
  }

  return (
    <div className="card-list-view">
      <div className="card-list-view-table">
        {/* 表頭 */}
        <div className="card-list-view-header-row">
          {/* 拖曳手柄佔位 */}
          {canEdit && <div className="card-list-view-handle-header"></div>}

          {displayFields.map((field, colIndex) => {
            // 表頭文字：評分欄位顯示「我的給分」/「平均評分」
            const headerText = field._ratingMode === 'personal'
              ? t('myRating')
              : field._ratingMode === 'average'
                ? t('avgRating')
                : field.name;

            return (
              <div
                key={field._colKey}
                className={`card-list-view-header-cell ${colIndex === 0 && canEdit ? 'first-col' : ''} ${draggedColIndex === colIndex ? 'dragging' : ''} ${dragOverColIndex === colIndex && dragOverColPosition === 'left' ? 'drag-over-left' : ''} ${dragOverColIndex === colIndex && dragOverColPosition === 'right' ? 'drag-over-right' : ''} ${canDragHeader && !field._ratingMode ? 'can-drag' : ''}`}
                style={{ width: columnWidths[field._colKey], minWidth: columnWidths[field._colKey], flexShrink: 0 }}
                draggable={canDragHeader && !field._ratingMode}
                onMouseDown={(e) => !field._ratingMode && handleHeaderMouseDown(e, colIndex)}
                onMouseUp={handleHeaderMouseUp}
                onMouseLeave={handleHeaderMouseLeave}
                onDragStart={(e) => !field._ratingMode && handleHeaderDragStart(e, colIndex)}
                onDragOver={(e) => !field._ratingMode && handleHeaderDragOver(e, colIndex)}
                onDragEnd={handleHeaderDragEnd}
                onDrop={(e) => !field._ratingMode && handleHeaderDrop(e, colIndex)}
                onClick={() => !canDragHeader && handleHeaderSort(field._colKey)}
              >
                <span className="card-list-view-header-text">{headerText}</span>
                {sortConfig?.fieldName === field._colKey && (
                  <span className="card-list-view-sort-indicator">
                    {sortConfig.direction === 'asc' ? '↑' : '↓'}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* 數據行 */}
        {sortedCards.map((card, rowIndex) => (
          <div
            key={card.id}
            className={`card-list-view-row ${draggedRowIndex === rowIndex ? 'dragging' : ''} ${dragOverRowIndex === rowIndex && dragOverRowPosition === 'top' ? 'drag-over-top' : ''} ${dragOverRowIndex === rowIndex && dragOverRowPosition === 'bottom' ? 'drag-over-bottom' : ''} ${hoveredRowIndex === rowIndex ? 'hovered' : ''}`}
            onDragOver={(e) => handleRowDragOver(e, rowIndex)}
            onDrop={(e) => handleRowDrop(e, rowIndex)}
            onMouseEnter={() => {
              setHoveredRowIndex(rowIndex);
              // 編輯狀態時不更新預覽
              if (!editingCell && !openSelect) {
                onCardHover?.(card);
              }
            }}
            onMouseLeave={() => { setHoveredRowIndex(null); }}
            onClick={() => onCardClick?.(card)}
            onContextMenu={(e) => {
              e.preventDefault();
              onContextMenu?.(e, card);
            }}
          >
            {/* 拖曳手柄 */}
            {canEdit && (
              <div
                className={`card-list-view-handle ${draggedRowIndex === rowIndex ? 'dragging' : ''}`}
                draggable
                onDragStart={(e) => handleRowDragStart(e, rowIndex)}
                onDragEnd={handleRowDragEnd}
                onClick={(e) => e.stopPropagation()}
              >
                <DragHandleIcon />
              </div>
            )}

            {/* 單元格 */}
            {displayFields.map((field, colIndex) => (
              <div
                key={field._colKey}
                className={`card-list-view-cell ${colIndex === 0 && canEdit ? 'first-col' : ''}`}
                style={{ width: columnWidths[field._colKey], minWidth: columnWidths[field._colKey], flexShrink: 0 }}
                onClick={(e) => e.stopPropagation()}
              >
                {renderCellContent(card, field, colIndex)}
              </div>
            ))}
          </div>
        ))}

        {/* 空狀態 */}
        {sortedCards.length === 0 && (
          <div className="card-list-view-empty-row">
            {t('noCards')}
          </div>
        )}
      </div>

      {/* DATE_RANGE 編輯 Dialog（使用共用組件） */}
      <DateRangeDialog
        isOpen={!!dateRangeDialog}
        onClose={() => setDateRangeDialog(null)}
        fieldName={dateRangeDialog?.fieldName}
        value={dateRangeDialog?.card?.cardFields?.[dateRangeDialog?.fieldName] || ''}
        onChange={(newValue) => {
          if (dateRangeDialog?.card && dateRangeDialog?.fieldName) {
            onCardUpdate?.(dateRangeDialog.card, dateRangeDialog.fieldName, newValue);
            // 即時更新預覽
            onCardHover?.({
              ...dateRangeDialog.card,
              cardFields: { ...dateRangeDialog.card.cardFields, [dateRangeDialog.fieldName]: newValue }
            });
          }
        }}
      />

    </div>
  );
};

export default CardListView;

