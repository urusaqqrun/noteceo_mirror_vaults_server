import React from 'react';
import { useDialogStore } from '../../../Store/dialogStore';
import AddCardTemplateDialog from './AddCardTemplateDialog';

const CardTemplateDialog: React.FC = () => {
    const showDialog = useDialogStore(state => state.dialogs['addTemplate']?.show);
    const dialogData = useDialogStore(state => state.dialogs['addTemplate']?.data);

    if (!showDialog || dialogData?.mode !== 'card') return null;

    const handleClose = () => useDialogStore.getState().close('addTemplate');

    return (
        <AddCardTemplateDialog
            onClose={handleClose}
            onConfirm={handleClose}
            isEdit={!!dialogData?.folder}
            initialData={dialogData?.folder || null}
            targetGroup={dialogData?.targetGroup || null}
        />
    );
};

export default CardTemplateDialog;
