import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './AddCardTemplateDialog.css';
import '../../common/BasicComponents.css';
import '../../common/CustomSelect.css';
import { CustomDialog } from '../../common/CustomDialog';
import { useCardsStore } from './cardStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import { getFirstTextFieldName } from '../../../utils/cardFieldUtils';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';
import AddIcon from '../../../assets/bk_icon_add_line_20_n.svg?react';
import HistoryIcon from '../../../assets/icon_history_outline_24.svg?react';
import {
  generateCardTemplate as generateCardTemplateAPI,
  generateCardFields as generateCardFieldsAPI,
  adjustCardTemplate as adjustCardTemplateAPI
} from './ai/cardAI';
import CardRenderer from '../../common/CardRenderer';
import { updateSharedCardType } from '../../../utils/shareAPI';

// 卡片欄位類型選項
const CARD_FIELD_TYPES = [
  { value: 'TEXT', label: '文字' },
  { value: 'TEXTAREA', label: '多行文字' },
  { value: 'NUMBER', label: '數字' },
  { value: 'DATE', label: '日期' },
  { value: 'DATETIME', label: '日期時間' },
  { value: 'DATERANGE', label: '日期範圍' },
  { value: 'URL', label: '網址' },
  { value: 'EMAIL', label: '電子郵件' },
  { value: 'PHONE', label: '電話' },
  { value: 'IMAGE', label: '圖片' },
  { value: 'SELECT', label: '單選' },
  { value: 'MULTISELECT', label: '多選' },
  { value: 'TAGS', label: '標籤' },
  { value: 'BOOLEAN', label: '是/否' },
  { value: 'RATING', label: '評分' },
  { value: 'LOCATION', label: '位置' },
];

function AddCardTemplateDialog({
  onClose,
  onConfirm,
  isEdit = false,
  initialData = null,
  targetGroup = null,
  myPermission = 50,
}) {
  const { t } = useTranslation();

  const cardFolders = useItemStore(state => state.getByType('CARD_FOLDER'));

  const types = cardFolders;
  const items = useItemStore(state => state.getByType('CARD'));
  const updateItem = useCardsStore(state => state.updateCard);

  const FIELD_TYPES = CARD_FIELD_TYPES;

  const typeIdKey = 'parentID';

  const [typeName, setTypeName] = useState(initialData?.name || '');

  const canEditName = myPermission >= 50;
  // 編輯模式時，保存原始欄位名稱用於追蹤變更
  const [fields, setFields] = useState(() => {
    const initialFields = initialData?.cardFieldsDef || [{ name: '', type: 'TEXT', options: [] }];
    // 為每個欄位添加 originalName 用於追蹤名稱變更
    return initialFields.map(f => ({
      ...f,
      originalName: f.name // 記錄原始名稱
    }));
  });
  const [uiPrompt, setUiPrompt] = useState(initialData?.uiPrompt || '');
  const [isComposing, setIsComposing] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // 卡片模板預覽
  const [templateHtml, setTemplateHtml] = useState(initialData?.templateHtml || '');
  const [templateCss, setTemplateCss] = useState(initialData?.templateCss || '');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGeneratingFields, setIsGeneratingFields] = useState(false);
  const [showAdjustDialog, setShowAdjustDialog] = useState(false);
  const [adjustDialogMode, setAdjustDialogMode] = useState('adjust'); // 'adjust' | 'regenerate'
  const [adjustInstruction, setAdjustInstruction] = useState('');
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [templateVersion, setTemplateVersion] = useState(0); // 用於強制刷新預覽
  const [dotCount, setDotCount] = useState(1); // 點數（1, 2, 3）
  const [showHistoryMenu, setShowHistoryMenu] = useState(false); // 版本歷史 menu
  const [historyMenuPosition, setHistoryMenuPosition] = useState({ top: 0, left: 0 }); // menu 位置
  const historyMenuRef = useRef(null);
  const historyBtnRef = useRef(null);

  // 點動畫效果
  useEffect(() => {
    if (isGenerating || isGeneratingFields || isAdjusting) {
      const interval = setInterval(() => {
        setDotCount(prev => prev >= 3 ? 1 : prev + 1);
      }, 400);
      return () => clearInterval(interval);
    } else {
      setDotCount(2);
    }
  }, [isGenerating, isGeneratingFields, isAdjusting]);

  // 點擊外部關閉 history menu
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (historyMenuRef.current && !historyMenuRef.current.contains(event.target)) {
        setShowHistoryMenu(false);
      }
    };
    if (showHistoryMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showHistoryMenu]);

  // 生成帶點動畫的文字
  const getGeneratingText = () => {
    const dots = '.'.repeat(dotCount);
    return `${t('generating')}${dots}`;
  };

  // 卡片樣式歷史記錄（從遠端同步的 CardType.templateHistory 讀取）
  const [styleHistory, setStyleHistory] = useState([]);
  const [selectedVersionIndex, setSelectedVersionIndex] = useState(0); // 當前選中的版本索引（0 = 最新版本）

  // 載入歷史記錄（僅在 dialog 打開時執行一次）
  useEffect(() => {
    if (isEdit && initialData?.templateHistory && Array.isArray(initialData.templateHistory)) {
      const formattedHistory = initialData.templateHistory.map((entry, index, arr) => {
        // 解析存儲的欄位定義
        let parsedFields = null;
        if (entry.cardFieldsDef) {
          try {
            parsedFields = typeof entry.cardFieldsDef === 'string' ? JSON.parse(entry.cardFieldsDef) : entry.cardFieldsDef;
          } catch (e) {

          }
        }
        return {
          templateHtml: entry.templateHtml || '',
          templateCss: entry.templateCss || '',
          prompt: entry.uiPrompt || '',
          version: entry.version || (arr.length - index),
          cardFieldsDef: parsedFields
        };
      });
      setStyleHistory(formattedHistory);

      // 找到與當前套用版本匹配的歷史記錄
      if (formattedHistory.length > 0) {
        const currentHtml = initialData.templateHtml || '';
        const currentCss = initialData.templateCss || '';
        const matchIndex = formattedHistory.findIndex(
          entry => entry.templateHtml === currentHtml && entry.templateCss === currentCss
        );
        // 如果找到匹配的版本，選中它；否則不選中任何版本（-1）
        setSelectedVersionIndex(matchIndex >= 0 ? matchIndex : -1);
      }
    } else {
      setStyleHistory([]);
      setSelectedVersionIndex(-1);
    }
  }, [initialData?.id]);

  // 添加新版本到歷史記錄（添加到最前面）並立即更新 CardType
  const addVersionToHistory = async (html, css, prompt) => {
    if (!html || !css) return;

    const now = Date.now();
    // 計算新版本號：現有歷史記錄中最大版本號 + 1
    const maxVersion = styleHistory.reduce((max, entry) => Math.max(max, entry.version || 0), 0);
    const newVersion = maxVersion + 1;

    // 清理當前 fields（移除 originalName）
    const cleanedCurrentFields = fields.map(f => {
      const { originalName, ...rest } = f;
      return rest;
    });

    const newEntry = {
      templateHtml: html,
      templateCss: css,
      prompt: prompt || '',
      version: newVersion,
      fields: cleanedCurrentFields // 新版本存當前的 fields
    };

    // 更新本地 state
    const newHistory = [newEntry, ...styleHistory].slice(0, 10);

    setStyleHistory(newHistory);
    setSelectedVersionIndex(0);

    // 如果是編輯模式，只儲存 templateHistory（不套用 templateHtml/templateCss）
    if (isEdit && initialData?.id) {
      const templateHistory = newHistory.map(entry => {
        // 每個版本存自己的 cardFieldsDef，不是當前的 cardFieldsDef
        const entryFields = entry.cardFieldsDef || cleanedCurrentFields;
        return {
          uiPrompt: entry.prompt || '',
          cardFieldsDef: JSON.stringify(entryFields),
          templateHtml: entry.templateHtml || '',
          templateCss: entry.templateCss || '',
          version: entry.version || 1
        };
      });

      // 只更新 templateHistory，不更新 templateHtml/templateCss
      const updatedCardType = {
        ...initialData,
        templateHistory: templateHistory,
        updatedAt: String(now)
      };

      await useCardsStore.getState().updateCardFolder(updatedCardType);

    }
  };

  // 選擇歷史版本（用於預覽，同時套用該版本的欄位定義）
  const selectVersion = (index) => {
    setSelectedVersionIndex(index);
    const entry = styleHistory[index];

    if (entry) {
      setTemplateHtml(entry.templateHtml);
      setTemplateCss(entry.templateCss);
      setTemplateVersion(v => v + 1);

      // 如果該版本有欄位定義，套用欄位定義
      if (entry.cardFieldsDef && Array.isArray(entry.cardFieldsDef)) {
        // 為每個欄位設置 originalName = name（就像初始化時一樣）
        const fieldsWithOriginalName = entry.cardFieldsDef.map(f => {
          // 移除可能存儲的 originalName（不應該從遠端讀取）
          const { originalName, ...cleanField } = f;
          return {
            ...cleanField,
            originalName: cleanField.name // 設為自己的 name，用於追蹤後續的重命名
          };
        });
        setFields(fieldsWithOriginalName);
      } else {

      }
    }
  };


  // 已在上方通過 mode 動態選擇 store

  // 替換模板中的欄位名稱引用（HTML 和 CSS）
  const replaceFieldNameInTemplate = (template, oldName, newName) => {
    if (!template || !oldName || !newName || oldName === newName) return template;

    let result = template;

    // 替換 HTML 中的 {{fieldName}} 和 {fieldName} 占位符
    const doubleBraceRegex = new RegExp(`\\{\\{${oldName}\\}\\}`, 'g');
    const singleBraceRegex = new RegExp(`\\{${oldName}\\}`, 'g');
    result = result.replace(doubleBraceRegex, `{{${newName}}}`);
    result = result.replace(singleBraceRegex, `{${newName}}`);

    // 替換 CSS 中的類名引用（如 .field-oldName）
    const cssClassRegex = new RegExp(`\\.field-${oldName}(?=[^a-zA-Z0-9_-]|$)`, 'g');
    result = result.replace(cssClassRegex, `.field-${newName}`);

    // 替換 HTML 中的類名引用
    const htmlClassRegex = new RegExp(`class="([^"]*\\bfield-${oldName}\\b[^"]*)"`, 'g');
    result = result.replace(htmlClassRegex, (match, classContent) => {
      const newClassContent = classContent.replace(new RegExp(`\\bfield-${oldName}\\b`, 'g'), `field-${newName}`);
      return `class="${newClassContent}"`;
    });

    // 替換 data-field-name 屬性
    const dataFieldRegex = new RegExp(`data-field-name="${oldName}"`, 'g');
    result = result.replace(dataFieldRegex, `data-field-name="${newName}"`);

    return result;
  };

  // 批次替換所有欄位名稱變更
  const applyFieldNameChangesToTemplate = (html, css, fieldChanges) => {
    let newHtml = html || '';
    let newCss = css || '';

    for (const change of fieldChanges) {
      if (change.oldName && change.newName && change.oldName !== change.newName) {
        newHtml = replaceFieldNameInTemplate(newHtml, change.oldName, change.newName);
        newCss = replaceFieldNameInTemplate(newCss, change.oldName, change.newName);
      }
    }

    return { html: newHtml, css: newCss };
  };

  // 計算欄位名稱變更列表
  const getFieldNameChanges = () => {
    return fields
      .filter(f => f.originalName && f.name && f.originalName !== f.name)
      .map(f => ({ oldName: f.originalName, newName: f.name }));
  };

  // 預覽用的調整後模板（暫存不儲存）
  const adjustedPreviewTemplate = useMemo(() => {
    const changes = getFieldNameChanges();
    if (changes.length === 0) {
      return { html: templateHtml, css: templateCss };
    }
    return applyFieldNameChangesToTemplate(templateHtml, templateCss, changes);
  }, [templateHtml, templateCss, fields]);

  // 自動生成欄位
  const handleGenerateFields = async () => {
    if (!typeName.trim()) {
      setErrorMessage(t('typeNameRequired'));
      return;
    }

    setIsGeneratingFields(true);
    setErrorMessage('');

    try {
      const result = await generateCardFieldsAPI(
        typeName.trim(),
        fields.filter(f => f.name.trim()) // 只傳有名稱的欄位
      );

      if (result.cardFieldsDef && result.cardFieldsDef.length > 0) {
        // 為 AI 生成的欄位添加 originalName（空字符串表示新欄位）
        const fieldsWithOriginalName = result.cardFieldsDef.map(f => ({
          ...f,
          originalName: '' // AI 生成的是新欄位，沒有原始名稱
        }));
        setFields(fieldsWithOriginalName);
      } else {
        setErrorMessage(t('generateFieldsFailed'));
      }
    } catch (error) {
      console.error('自動生成欄位失敗:', error);
      setErrorMessage(t('generateFieldsFailed'));
    } finally {
      setIsGeneratingFields(false);
    }
  };

  // 生成卡片模板
  const handleGenerateTemplate = async (promptText) => {
    if (!typeName.trim()) {
      setErrorMessage(t('typeNameRequired'));
      return;
    }

    // 檢查欄位是否都有名稱
    const hasEmptyName = fields.some(f => !f.name.trim());
    if (hasEmptyName) {
      setErrorMessage(t('fieldLabelRequired'));
      return;
    }

    setIsGenerating(true);
    setErrorMessage('');

    try {
      const fieldsData = fields.map(f => ({
        name: f.name,
        type: f.type,
        options: f.options || []
      }));

      const result = await generateCardTemplateAPI(
        typeName.trim(),
        fieldsData,
        promptText.trim()
      );

      if (result.templateHtml && result.templateCss) {
        setTemplateHtml(result.templateHtml);
        setTemplateCss(result.templateCss);
        setTemplateVersion(v => v + 1); // 強制刷新預覽
        // 保存新版本到歷史記錄
        addVersionToHistory(result.templateHtml, result.templateCss, promptText.trim() || t('generateCardStyle'));
        setShowAdjustDialog(false);
        setAdjustInstruction('');
      } else {
        setErrorMessage(t('generateFailed'));
      }
    } catch (error) {
      console.error('生成卡片模板失敗:', error);
      setErrorMessage(t('generateFailed'));
    } finally {
      setIsGenerating(false);
    }
  };

  // 調整卡片模板
  const handleAdjustTemplate = async () => {
    if (!adjustInstruction.trim()) {
      return;
    }

    setIsAdjusting(true);
    setErrorMessage('');

    try {
      const fieldsData = fields.map(f => ({
        name: f.name,
        type: f.type,
        options: f.options || []
      }));

      const result = await adjustCardTemplateAPI(
        templateHtml,
        templateCss,
        adjustInstruction.trim(),
        fieldsData
      );

      if (result.templateHtml && result.templateCss) {
        setTemplateHtml(result.templateHtml);
        setTemplateCss(result.templateCss);
        setTemplateVersion(v => v + 1); // 強制刷新預覽
        // 保存新版本到歷史記錄
        addVersionToHistory(result.templateHtml, result.templateCss, adjustInstruction.trim());
        setShowAdjustDialog(false);
        setAdjustInstruction('');
      } else {
        setErrorMessage(t('adjustFailed'));
      }
    } catch (error) {
      console.error('調整卡片模板失敗:', error);
      setErrorMessage(t('adjustFailed'));
    } finally {
      setIsAdjusting(false);
    }
  };

  // Dialog 提交處理（根據模式調用不同邏輯）
  const handleDialogSubmit = () => {
    if (adjustDialogMode === 'regenerate') {
      handleGenerateTemplate(adjustInstruction);
    } else {
      handleAdjustTemplate();
    }
  };

  // 打開重新生成 Dialog
  const openRegenerateDialog = () => {
    setAdjustDialogMode('regenerate');
    setAdjustInstruction('');
    setShowAdjustDialog(true);
  };

  // 打開調整樣式 Dialog
  const openAdjustDialog = () => {
    setAdjustDialogMode('adjust');
    setAdjustInstruction('');
    setShowAdjustDialog(true);
  };

  // 添加欄位
  const handleAddField = () => {
    const newField = {
      name: '',
      type: 'TEXT',
      options: [],
      originalName: '' // 新欄位沒有原始名稱
    };
    setFields([...fields, newField]);
  };

  // 更新欄位
  const handleUpdateField = (index, key, value) => {
    const newFields = [...fields];
    newFields[index] = { ...newFields[index], [key]: value };
    setFields(newFields);
  };

  // 刪除欄位
  const handleDeleteField = (index) => {
    if (fields.length <= 1) return; // 至少保留一個欄位
    const newFields = fields.filter((_, i) => i !== index);
    setFields(newFields);
  };

  // 拖拽排序
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [dragOverIndex, setDragOverIndex] = useState(null);
  const [dragOverPosition, setDragOverPosition] = useState(null); // 'top' | 'bottom'

  const handleDragStart = (e, index) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;

    // 計算滑鼠在元素中的位置，決定是上半部還是下半部
    const rect = e.currentTarget.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const position = e.clientY < midY ? 'top' : 'bottom';

    setDragOverIndex(index);
    setDragOverPosition(position);
  };

  const handleDragLeave = () => {
    setDragOverIndex(null);
    setDragOverPosition(null);
  };

  const handleDrop = (e, index) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;

    const newFields = [...fields];
    const [draggedItem] = newFields.splice(draggedIndex, 1);

    // 根據放置位置決定插入索引
    let insertIndex = index;
    if (dragOverPosition === 'bottom') {
      insertIndex = draggedIndex < index ? index : index + 1;
    } else {
      insertIndex = draggedIndex < index ? index - 1 : index;
    }
    insertIndex = Math.max(0, Math.min(insertIndex, newFields.length));

    newFields.splice(insertIndex, 0, draggedItem);

    setFields(newFields);
    setDraggedIndex(null);
    setDragOverIndex(null);
    setDragOverPosition(null);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
    setDragOverIndex(null);
    setDragOverPosition(null);
  };

  // 提交
  const handleSubmit = async () => {
    if (!typeName.trim()) {
      setErrorMessage(t('typeNameRequired'));
      return;
    }

    // 檢查欄位是否都有名稱
    const hasEmptyName = fields.some(f => !f.name.trim());
    if (hasEmptyName) {
      setErrorMessage(t('fieldLabelRequired'));
      return;
    }

    // 檢查欄位名稱是否重複
    const fieldNames = fields.map(f => f.name.trim().toLowerCase());
    const hasDuplicateFieldName = fieldNames.some((name, index) =>
      fieldNames.indexOf(name) !== index
    );
    if (hasDuplicateFieldName) {
      setErrorMessage(t('duplicateFieldName'));
      return;
    }

    // 檢查名稱是否重複（編輯時排除自己）
    const isDuplicate = types.some(ct => {
      const nameMatch = ct.name?.toLowerCase() === typeName.trim().toLowerCase();
      const isSelf = isEdit && String(ct.id) === String(initialData?.id);

      return nameMatch && !isSelf;
    });

    if (isDuplicate) {
      setErrorMessage(t('duplicateCardTypeName'));
      return;
    }

    const now = Date.now().toString();
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const myMemberID = userData?.ID || 'default';

    // ============ Card 模式完整處理 ============
    if (isEdit && initialData?.id) {
      // 計算欄位名稱變更
      const fieldChanges = getFieldNameChanges();
      const hasFieldNameChanges = fieldChanges.length > 0;

      // 如果有欄位名稱變更，調整所有模板
      let finalTemplateHtml = templateHtml || initialData?.templateHtml || null;
      let finalTemplateCss = templateCss || initialData?.templateCss || null;

      // 從當前 styleHistory 生成 finalTemplateHistory（包含用戶調整後的新版本）
      let finalTemplateHistory = styleHistory.map(entry => ({
        uiPrompt: entry.prompt || '',
        cardFieldsDef: JSON.stringify(entry.cardFieldsDef || fields.map(f => ({ name: f.name, type: f.type, options: f.options }))),
        templateHtml: entry.templateHtml || '',
        templateCss: entry.templateCss || '',
        version: entry.version || 1
      }));
      // 如果 styleHistory 為空，回退到 initialData
      if (finalTemplateHistory.length === 0) {
        finalTemplateHistory = initialData?.templateHistory || [];
      }

      if (hasFieldNameChanges) {
        // 1. 調整當前 CardType 的 templateHtml/templateCss
        const adjustedCurrent = applyFieldNameChangesToTemplate(finalTemplateHtml, finalTemplateCss, fieldChanges);
        finalTemplateHtml = adjustedCurrent.html;
        finalTemplateCss = adjustedCurrent.css;

        // 2. 只調整 templateHistory 中選中版本的模板
        if (selectedVersionIndex >= 0 && selectedVersionIndex < finalTemplateHistory.length) {
          finalTemplateHistory = finalTemplateHistory.map((entry, index) => {
            if (index === selectedVersionIndex) {
              const adjusted = applyFieldNameChangesToTemplate(entry.templateHtml, entry.templateCss, fieldChanges);
              return {
                ...entry,
                templateHtml: adjusted.html,
                templateCss: adjusted.css
              };
            }
            return entry;
          });
        }
      }

      // 清理 fields：移除 originalName（不需要儲存到遠端）
      const cleanedFields = fields.map(f => {
        const { originalName, ...rest } = f;
        return rest;
      });

      if (myPermission < 50) {
        await updateSharedCardType({
          folderId: initialData.id,
          templateHtml: finalTemplateHtml,
          templateCss: finalTemplateCss,
          uiPrompt: uiPrompt.trim() || null,
          fields: cleanedFields,
          templateHistory: finalTemplateHistory,
        });

        if (onConfirm) {
          await onConfirm();
        }
        onClose();
        return;
      }

      // 更新現有類型
      const updatedTypeData = {
        ...initialData,
        name: typeName.trim(),
        templateHtml: finalTemplateHtml,
        templateCss: finalTemplateCss,
        fields: cleanedFields,
        templateHistory: finalTemplateHistory,
        uiPrompt: uiPrompt.trim() || null,
        updatedAt: now
      };
      await useCardsStore.getState().updateCardFolder(updatedTypeData);

      // 檢查第一個 TEXT/TEXTAREA 欄位是否變動（用於更新 Card.name）
      const oldFirstFieldName = getFirstTextFieldName(initialData?.cardFieldsDef);
      const newFirstFieldName = getFirstTextFieldName(fields);
      const firstFieldChanged = oldFirstFieldName !== newFirstFieldName;

      // 4. 合併處理：欄位名稱變更 + 第一欄位變動
      // 需要一次性處理，避免重複更新同一張卡片
      if (hasFieldNameChanges || firstFieldChanged) {
        const relatedItems = items.filter(item => item.parentID === initialData.id);
        const itemUpdates = [];

        // Card 的欄位重命名處理
        for (const item of relatedItems) {
          const oldFields = (item as any)?.cardFields || {};
          let newFields = { ...oldFields };
          let itemNeedsUpdate = false;
          let newItemName = item.name;

          // 處理欄位名稱變更（移動 fields 的 key）
          if (hasFieldNameChanges) {
            for (const change of fieldChanges) {
              if (newFields.hasOwnProperty(change.oldName)) {
                newFields[change.newName] = newFields[change.oldName];
                delete newFields[change.oldName];
                itemNeedsUpdate = true;
              }
            }
          }

          // 處理第一欄位變動（更新 name）
          // 注意：如果第一欄位名稱也被改了，要用新名稱去取值
          if (firstFieldChanged && newFirstFieldName) {
            // 從 newFields 中取值（已經完成 key 重命名的）
            const valueFromNewField = newFields[newFirstFieldName];
            if (valueFromNewField && valueFromNewField !== item.name) {
              newItemName = valueFromNewField;
              itemNeedsUpdate = true;
            }
          }

          if (itemNeedsUpdate) {
            itemUpdates.push({ ...item, cardFields: newFields, name: newItemName });
          }
        }

        // 批次更新 Items
        if (itemUpdates.length > 0) {
          await updateItem(itemUpdates, true);
        }
      }
    } else {
      // 創建新卡片類型（包含 templateHistory）
      // 清理 fields：移除 originalName（不需要儲存到遠端）
      const cleanedFieldsForNew = fields.map(f => {
        const { originalName, ...rest } = f;
        return rest;
      });

      const templateHistory = styleHistory.map(entry => ({
        uiPrompt: entry.prompt || '',
        fields: JSON.stringify(cleanedFieldsForNew),
        templateHtml: entry.templateHtml || '',
        templateCss: entry.templateCss || '',
        version: entry.version || 1
      }));

      const newTypeData = {
        id: generateObjectID(),
        name: typeName.trim(),
        itemType: 'CARD',
        templateHtml: templateHtml || null,
        templateCss: templateCss || null,
        uiPrompt: uiPrompt.trim() || null,
        fields: cleanedFieldsForNew,
        templateHistory: templateHistory,
        parentID: targetGroup?.id || null,
        createdAt: now,
        updatedAt: now
      };

      await useCardsStore.getState().updateCardFolder(newTypeData);
      await useCardsStore.getState().loadCardFolders();

      const savedItem = useItemStore.getState().getById(newTypeData.id);
      if (savedItem) useSelectedItemsStore.getState().setSelectedItems([savedItem], { scrollToFocusItem: true });
    }

    if (onConfirm) {
      onConfirm();
    }
    onClose();
  };


  // ============ Card 模式完整 UI ============
  return (
    <CustomDialog
      isOpen={true}
      onClose={onClose}
      title={isEdit ? t('editCardType') : t('newCardType')}
      className="add-card-type-dialog"
      onEscapeOverride={() => {
        if (showHistoryMenu) {
          setShowHistoryMenu(false);
          return true;
        }
        if (showAdjustDialog && !(isAdjusting || isGenerating)) {
          setShowAdjustDialog(false);
          setAdjustInstruction('');
          return true;
        }
        if (!showAdjustDialog) {
          onClose();
          return true;
        }
        return false;
      }}
    >

      {/* 內容區：兩列佈局 */}
      <div className="add-card-type-dialog-body">
        {/* 第一列：模板名稱 + 欄位定義 */}
        <div className="add-card-type-column add-card-type-column-1">
          {/* 卡片類型名稱 */}
          <div className="card-type-form-section">
            <div className="section-header">
              <label className="form-label">{t('typeName')}</label>
            </div>
            <input
              type="text"
              value={typeName}
              onChange={(e) => {
                if (canEditName) {
                  setTypeName(e.target.value);
                  setErrorMessage('');
                }
              }}
              className="custom-dialog-input"
              placeholder={t('typeNamePlaceholder')}
              onCompositionStart={() => setIsComposing(true)}
              onCompositionEnd={() => setIsComposing(false)}
              disabled={!canEditName}
              style={!canEditName ? { opacity: 0.6, cursor: 'not-allowed' } : {}}
            />
          </div>


          {/* 欄位定義 */}
          <div className="card-type-form-section add-card-type-fields-section">
            <div className="section-header">
              <label className="form-label">{t('cardFields')}</label>
              <div className="section-header-buttons">
                <button
                  className="custom-outline-button"
                  onClick={handleGenerateFields}
                  disabled={isGeneratingFields || !typeName.trim()}
                  type="button"
                >
                  {isGeneratingFields ? getGeneratingText() : t('autoGenerateFields')}
                </button>
                <button
                  className="custom-outline-button"
                  onClick={handleAddField}
                  type="button"
                >
                  <AddIcon className="custom-outline-button-icon" />
                  {t('addField')}
                </button>
              </div>
            </div>

            <div className="fields-list">
              {fields.map((field, index) => (
                <div
                  key={index}
                  className={`field-item-wrapper ${draggedIndex === index ? 'dragging' : ''} ${dragOverIndex === index && dragOverPosition === 'top' ? 'drag-over-top' : ''} ${dragOverIndex === index && dragOverPosition === 'bottom' ? 'drag-over-bottom' : ''}`}
                  draggable
                  onDragStart={(e) => handleDragStart(e, index)}
                  onDragOver={(e) => handleDragOver(e, index)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, index)}
                  onDragEnd={handleDragEnd}
                >
                  <div className="field-item">
                    <input
                      type="text"
                      value={field.name}
                      onChange={(e) => handleUpdateField(index, 'name', e.target.value)}
                      className="field-label-input"
                      placeholder={t('fieldLabel')}
                    />
                    <select
                      value={field.type}
                      onChange={(e) => handleUpdateField(index, 'type', e.target.value)}
                      className="custom-select add-card-type-dialog__field-type-select"
                    >
                      {FIELD_TYPES.map(type => (
                        <option key={type.value} value={type.value}>{type.label}</option>
                      ))}
                    </select>
                    <button
                      className="delete-field-btn"
                      onClick={() => handleDeleteField(index)}
                      disabled={fields.length <= 1}
                      type="button"
                    >
                      <DeleteIcon className="delete-field-icon" />
                    </button>
                  </div>
                  {(field.type === 'SELECT' || field.type === 'MULTISELECT') && (
                    <div className="field-options-section">
                      {(field.options || []).map((option, optIndex) => (
                        <div key={optIndex} className="field-option-item">
                          <input
                            type="text"
                            value={option}
                            onChange={(e) => {
                              const newOptions = [...(field.options || [])];
                              newOptions[optIndex] = e.target.value;
                              handleUpdateField(index, 'options', newOptions);
                            }}
                            className="field-option-input"
                            placeholder={`${t('option')} ${optIndex + 1}`}
                          />
                          <button
                            className="delete-option-btn"
                            onClick={() => {
                              const newOptions = (field.options || []).filter((_, i) => i !== optIndex);
                              handleUpdateField(index, 'options', newOptions);
                            }}
                            type="button"
                          >
                            <DeleteIcon className="delete-option-icon" />
                          </button>
                        </div>
                      ))}
                      <button
                        className="add-option-btn"
                        onClick={() => {
                          const newOptions = [...(field.options || []), ''];
                          handleUpdateField(index, 'options', newOptions);
                        }}
                        type="button"
                      >
                        <AddIcon className="add-option-icon" />
                        {t('addOption')}
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 第二列：AI 設計提示 + 卡片預覽 + 版本紀錄 */}
        <div className="add-card-type-column add-card-type-column-2">
          {/* AI 設計提示 - 只在沒有版本時顯示 */}
          {styleHistory.length === 0 && (
            <div className="card-type-form-section add-card-type-prompt-section">
              <div className="section-header">
                <label className="form-label">{t('uiPrompt')}</label>
                <button
                  className="custom-outline-button"
                  onClick={() => handleGenerateTemplate(uiPrompt)}
                  disabled={isGenerating || !typeName.trim() || fields.every(f => !f.name.trim())}
                  type="button"
                >
                  {isGenerating ? getGeneratingText() : t('generateCardStyle')}
                </button>
              </div>
              <textarea
                value={uiPrompt}
                onChange={(e) => setUiPrompt(e.target.value)}
                className="dialog-textarea"
                placeholder={t('uiPromptPlaceholder')}
                rows={2}
              />
            </div>
          )}

          {/* 卡片預覽 */}
          <div className="card-type-form-section add-card-type-preview-section">
            <div className="section-header">
              <label className="form-label">{t('cardPreview')}</label>
              <div className="preview-header-buttons">
                {templateHtml && (
                  <>
                    {/* 版本歷史按鈕 */}
                    {styleHistory.length > 0 && (
                      <div className="add-card-type-history-wrapper" ref={historyMenuRef}>
                        <button
                          ref={historyBtnRef}
                          className="add-card-type-history-btn"
                          onClick={() => {
                            if (!showHistoryMenu && historyBtnRef.current) {
                              const rect = historyBtnRef.current.getBoundingClientRect();
                              setHistoryMenuPosition({
                                top: rect.bottom + 4,
                                left: rect.left
                              });
                            }
                            setShowHistoryMenu(!showHistoryMenu);
                          }}
                          type="button"
                          tabIndex={-1}
                        >
                          <HistoryIcon className="add-card-type-history-icon" />
                        </button>
                        {showHistoryMenu && (
                          <div
                            className="add-card-type-history-menu"
                            style={{
                              top: historyMenuPosition.top,
                              left: historyMenuPosition.left
                            }}
                          >
                            <div className="add-card-type-version-list">
                              {styleHistory.map((entry, index) => (
                                <div
                                  key={entry.version || index}
                                  className={`add-card-type-version-item ${selectedVersionIndex === index ? 'selected' : ''}`}
                                  onClick={() => {
                                    selectVersion(index);
                                    setShowHistoryMenu(false);
                                  }}
                                >
                                  <span className="add-card-type-version-prompt">
                                    {entry.prompt || t('generateCardStyle')}
                                  </span>
                                  <span className="add-card-type-version-number">
                                    {t('versionNumber', { number: styleHistory.length - index })}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                    <button
                      className="custom-outline-button"
                      onClick={openRegenerateDialog}
                      disabled={isGenerating || isAdjusting}
                      type="button"
                      tabIndex={-1}
                    >
                      {t('regenerateCardStyle')}
                    </button>
                    <button
                      className="custom-outline-button"
                      onClick={openAdjustDialog}
                      disabled={isGenerating || isAdjusting}
                      type="button"
                      tabIndex={-1}
                    >
                      {t('adjustStyle')}
                    </button>
                  </>
                )}
              </div>
            </div>

            <div className="card-preview-container">
              <CardRenderer
                templateHtml={adjustedPreviewTemplate.html}
                templateCss={adjustedPreviewTemplate.css}
                fields={fields}
                cardData={null}
                key={`preview-${templateVersion}`}
              />
            </div>
          </div>

          {errorMessage && <p className="dialog-error">{errorMessage}</p>}
        </div>
      </div>

      {/* 按鈕區 */}
      <div className="custom-dialog-buttons">
        <button className="custom-secondary-button" onClick={onClose}>
          {t('cancel')}
        </button>
        <button
          className="custom-primary-button"
          onClick={handleSubmit}
          disabled={!typeName.trim() || !templateHtml}
        >
          {t('confirm')}
        </button>
      </div>

      {/* 調整樣式 / 重新生成 Dialog */}
      {showAdjustDialog && (
        <div className="adjust-dialog-overlay" onClick={() => !(isAdjusting || isGenerating) && setShowAdjustDialog(false)}>
          <div className="adjust-dialog-content" onClick={e => e.stopPropagation()}>
            <h3 className="adjust-dialog-title">
              {adjustDialogMode === 'regenerate' ? t('regenerateStyleTitle') : t('adjustStyleTitle')}
            </h3>
            <textarea
              className="adjust-instruction-input"
              value={adjustInstruction}
              onChange={(e) => setAdjustInstruction(e.target.value)}
              placeholder={adjustDialogMode === 'regenerate' ? t('regenerateInstructionPlaceholder') : t('adjustInstructionPlaceholder')}
              rows={4}
              disabled={isAdjusting || isGenerating}
            />
            <div className="adjust-dialog-buttons">
              <button
                className="custom-secondary-button"
                onClick={() => {
                  setShowAdjustDialog(false);
                  setAdjustInstruction('');
                }}
                disabled={isAdjusting || isGenerating}
                tabIndex={-1}
              >
                {t('cancel')}
              </button>
              <button
                className="custom-primary-button"
                onClick={handleDialogSubmit}
                disabled={(isAdjusting || isGenerating) || (adjustDialogMode !== 'regenerate' && !adjustInstruction.trim())}
                tabIndex={-1}
              >
                {(isAdjusting || isGenerating)
                  ? getGeneratingText()
                  : adjustDialogMode === 'regenerate'
                    ? t('regenerate')
                    : t('adjust')
                }
              </button>
            </div>
          </div>
        </div>
      )}
    </CustomDialog>
  );
}

export default AddCardTemplateDialog;
