// ===== DeleteCardConfirmDialog — 刪除卡片確認對話框（純 UI） =====
//
// 自 dialogStore['deleteCardConfirm'].data 讀取：
//   - count: 選中卡片數量
//   - onConfirm: 確認刪除回調

import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDialogStore } from '../../../Store/dialogStore';
import { CustomDialog } from '../../common/CustomDialog';

export interface DeleteCardConfirmDialogData {
  count: number;
  onConfirm: () => void;
}

const DeleteCardConfirmDialog: React.FC = () => {
  const { t } = useTranslation();
  const show = useDialogStore(state => state.dialogs['deleteCardConfirm']?.show);
  const data = useDialogStore(state => state.dialogs['deleteCardConfirm']?.data) as DeleteCardConfirmDialogData | undefined;

  if (!show || !data) return null;

  const handleClose = () => useDialogStore.getState().close('deleteCardConfirm');

  const handleConfirm = () => {
    handleClose();
    data.onConfirm();
  };

  return (
    <CustomDialog
      isOpen
      onClose={handleClose}
      title={t('confirmDelete')}
    >
      <p className="custom-dialog-description">
        {t('confirmDeleteCards', { count: data.count }) || `確定要刪除這 ${data.count} 張卡片嗎？`}
      </p>
      <div className="custom-dialog-buttons">
        <button
          className="custom-secondary-button"
          onClick={handleClose}
        >
          {t('cancel')}
        </button>
        <button
          className="custom-primary-button error"
          onClick={handleConfirm}
        >
          {t('delete')}
        </button>
      </div>
    </CustomDialog>
  );
};

export default DeleteCardConfirmDialog;
