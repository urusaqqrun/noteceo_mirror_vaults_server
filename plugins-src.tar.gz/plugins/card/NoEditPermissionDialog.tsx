import React from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

/**
 * NoEditPermissionDialog 純 UI 化
 * 列表模式下，無編輯權限時顯示「無法編輯此卡片」提示
 * 從 dialogStore['noEditPermission'] 讀取 show
 */
const NoEditPermissionDialog: React.FC = () => {
  const { t } = useTranslation();
  const show = useDialogStore(state => state.dialogs['noEditPermission']?.show);

  if (!show) return null;

  const handleClose = () => useDialogStore.getState().close('noEditPermission');

  return (
    <CustomDialog isOpen onClose={handleClose}>
      <div className="card-list-view-permission-message">
        {t('cannotEditThisCard')}
      </div>
      <div className="custom-dialog-buttons">
        <button className="custom-primary-button" onClick={handleClose}>
          {t('confirm')}
        </button>
      </div>
    </CustomDialog>
  );
};

export default NoEditPermissionDialog;
