import { create } from 'zustand';

// ===== Types =====
interface MemberInfo {
  memberID: string;
  name: string;
  photo?: string;
  thumbnail?: string;
  profiling?: any;
}

interface MembersInfoState {
  membersInfoMap: Record<string, MemberInfo>;
  subscribers: Record<string, Set<(info: MemberInfo) => void>>;
  getMembersInfo: (memberIds: string[]) => Record<string, MemberInfo>;
  fetchMembersInfo: (memberIds: string | string[], getMembersInfoAPI: (ids: string[]) => Promise<MemberInfo[]>) => Promise<void>;
  subscribe: (memberId: string, callback: (info: MemberInfo) => void) => () => void;
  setMemberInfo: (memberId: string, info: MemberInfo) => void;
  setMembersInfo: (membersMap: Record<string, MemberInfo>) => void;
  clear: () => void;
}

// 全局去重機制：避免重複請求
const fetchedIds = new Set<string>();

/**
 * 批次請求成員資訊
 * 100ms 內的請求會合併成一次 API 調用
 */
let batchTimer: ReturnType<typeof setTimeout> | null = null;
let batchIds = new Set<string>();

const fetchMembersInfoBatch = async (getMembersInfoAPI: (ids: string[]) => Promise<MemberInfo[]>) => {
  if (batchIds.size === 0) return;

  const idsToFetch = Array.from(batchIds);
  batchIds.clear();

  try {
    const infos = await getMembersInfoAPI(idsToFetch);
    return infos;
  } catch (error) {
    console.error('[MembersInfoStore] 批次請求失敗:', error);
    // 失敗的 IDs 從 fetchedIds 中移除，允許重試
    idsToFetch.forEach(id => fetchedIds.delete(id));
    throw error;
  }
};

export const useMembersInfoStore = create<MembersInfoState>((set, get) => ({
  // 成員資訊 Map
  membersInfoMap: {},

  // 訂閱者 Map: { memberId: Set<callbackFn> }
  subscribers: {},

  /**
   * 獲取成員資訊（不會觸發 fetch）
   */
  getMembersInfo: (memberIds) => {
    const state = get();
    const result: Record<string, MemberInfo> = {};

    memberIds.forEach(id => {
      if (state.membersInfoMap[id]) {
        result[id] = state.membersInfoMap[id];
      }
    });

    return result;
  },

  /**
   * 請求成員資訊（如果還沒有的話）
   */
  fetchMembersInfo: async (memberIds, getMembersInfoAPI) => {
    const ids = Array.isArray(memberIds) ? memberIds : [memberIds];
    const state = get();

    // 過濾出需要請求的 IDs
    const needFetchIds = ids.filter(id => {
      // 已經有資料了
      if (state.membersInfoMap[id]) return false;
      // 已經請求過了
      if (fetchedIds.has(id)) return false;
      return true;
    });

    if (needFetchIds.length === 0) return;

    // 標記為已請求
    needFetchIds.forEach(id => fetchedIds.add(id));

    // 加入批次隊列
    needFetchIds.forEach(id => batchIds.add(id));

    // 清除舊的計時器
    if (batchTimer) {
      clearTimeout(batchTimer);
    }

    // 設置新的批次計時器
    batchTimer = setTimeout(async () => {
      try {
        const infos = await fetchMembersInfoBatch(getMembersInfoAPI);

        if (infos && infos.length > 0) {
          // 更新 store
          set(state => {
            const newMap = { ...state.membersInfoMap };

            infos.forEach(info => {
              newMap[info.memberID] = {
                memberID: info.memberID,
                name: info.name,
                photo: info.photo,
                thumbnail: info.thumbnail,
                profiling: info.profiling
              };
            });


            return { membersInfoMap: newMap };
          });

          // 通知訂閱者
          const currentState = get();
          infos.forEach(info => {
            const memberId = info.memberID;
            const callbacks = currentState.subscribers[memberId];
            if (callbacks && callbacks.size > 0) {

              callbacks.forEach(callback => {
                try {
                  callback(info);
                } catch (error) {
                  console.error('[MembersInfoStore] 訂閱者回調錯誤:', error);
                }
              });
            }
          });
        }
      } catch (error) {
        console.error('[MembersInfoStore] 批次請求失敗:', error);
      }
    }, 100); // 100ms 批次延遲
  },

  /**
   * 訂閱特定成員的資訊更新
   */
  subscribe: (memberId, callback) => {
    set(state => {
      const newSubscribers = { ...state.subscribers };
      if (!newSubscribers[memberId]) {
        newSubscribers[memberId] = new Set();
      }
      newSubscribers[memberId].add(callback);

      return { subscribers: newSubscribers };
    });

    // 返回取消訂閱函數
    return () => {
      set(state => {
        const newSubscribers = { ...state.subscribers };
        if (newSubscribers[memberId]) {
          newSubscribers[memberId].delete(callback);
          if (newSubscribers[memberId].size === 0) {
            delete newSubscribers[memberId];
          }
        }

        return { subscribers: newSubscribers };
      });
    };
  },

  /**
   * 直接設置成員資訊（用於初始化，如當前用戶）
   */
  setMemberInfo: (memberId, info) => {
    set(state => {
      // 標記為已 fetch，避免重複請求
      fetchedIds.add(memberId);

      return {
        membersInfoMap: {
          ...state.membersInfoMap,
          [memberId]: info
        }
      };
    });
  },

  /**
   * 批量設置成員資訊（用於初始化）
   */
  setMembersInfo: (membersMap) => {
    set(state => {
      // 標記為已 fetch
      Object.keys(membersMap).forEach(id => fetchedIds.add(id));

      return {
        membersInfoMap: {
          ...state.membersInfoMap,
          ...membersMap
        }
      };
    });
  },

  /**
   * 清空所有資料（用於登出）
   */
  clear: () => {
    fetchedIds.clear();
    batchIds.clear();
    if (batchTimer) {
      clearTimeout(batchTimer);
      batchTimer = null;
    }
    set({ membersInfoMap: {}, subscribers: {} });

  }
}));

// ===== EventBus 訂閱 =====
import { eventBus } from '../../../Store/eventBus';

eventBus.on('database:reset', () => {
  useMembersInfoStore.getState().clear();
});
