/**
 * CardLinkPreviewExtension
 * 
 * 從 TemplateLinkPreviewExtension 拆出的卡片連結預覽擴展。
 * 偵測 cubelv://card/xxx 連結，在連結後面插入展開預覽按鈕。
 * 歸屬 CardPlugin，由 CardPlugin.onload() 註冊到 editorExtensionRegistry。
 */
import { Extension } from '@tiptap/core';
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';
import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { useTranslation } from 'react-i18next';
import CardRenderer from '../../common/CardRenderer';
import { useCardsStore } from './cardStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { upsertReview, getMyReview } from './reviewStore';
import { useDialogStore } from '../../../Store/dialogStore';


// localStorage key 前綴
const COLLAPSED_TEMPLATES_KEY = 'cubelv_collapsed_templates';

const getCollapsedTemplates = () => {
    try {
        const stored = localStorage.getItem(COLLAPSED_TEMPLATES_KEY);
        return stored ? JSON.parse(stored) : [];
    } catch { return []; }
};

const saveCollapsedTemplates = (collapsedList) => {
    try {
        localStorage.setItem(COLLAPSED_TEMPLATES_KEY, JSON.stringify(collapsedList));
    } catch (e) {
        console.error('Failed to save collapsed templates to localStorage:', e);
    }
};

const isTemplateCollapsed = (noteId, templateId) => {
    const key = `${noteId}-card-${templateId}`;
    return getCollapsedTemplates().includes(key);
};

const setTemplateCollapsed = (noteId, templateId, collapsed) => {
    const key = `${noteId}-card-${templateId}`;
    const list = getCollapsedTemplates();
    if (collapsed) {
        if (!list.includes(key)) { list.push(key); saveCollapsedTemplates(list); }
    } else {
        const idx = list.indexOf(key);
        if (idx > -1) { list.splice(idx, 1); saveCollapsedTemplates(list); }
    }
};

// 卡片連結預覽元件
const CardLinkPreview = ({ cardId, noteId }) => {
    const { t } = useTranslation();
    const [isExpanded, setIsExpanded] = useState(() => !isTemplateCollapsed(noteId, cardId));
    const hasAnimatedRef = useRef(isExpanded);

    // Card stores
    const getCardById = useCardsStore(state => state.getCardById);
    const updateCard = useCardsStore(state => state.updateCard);

    // User info
    const currentMemberID = useMemo(() => {
        try {
            const userData = localStorage.getItem('userData_local');
            if (!userData) return null;
            return JSON.parse(userData)?.ID || null;
        } catch { return null; }
    }, []);
    const isLoggedIn = !!currentMemberID;

    const item = getCardById(cardId);
    const itemType = useMemo(() => {
        if (!item) return null;
        const raw = useItemStore.getState().getById(item.parentID) as any;
        if (!raw) return null;
        const def = raw.cardFieldsDef;
        return { ...raw, cardFieldsDef: typeof def === 'string' ? (() => { try { return JSON.parse(def); } catch { return def; } })() : def };
    }, [item]);

    const handleToggle = (e) => {
        e.preventDefault();
        e.stopPropagation();
        const newExpanded = !isExpanded;
        setIsExpanded(newExpanded);
        setTemplateCollapsed(noteId, cardId, !newExpanded);
    };

    useEffect(() => {
        if (isExpanded) {
            const timer = setTimeout(() => { hasAnimatedRef.current = true; }, 250);
            return () => clearTimeout(timer);
        }
    }, [isExpanded]);

    return (
        <>
            <button
                className={`template-link-expand-btn ${isExpanded ? 'expanded' : ''}`}
                onClick={handleToggle}
                onMouseDown={(e) => e.preventDefault()}
                title={isExpanded ? t('collapseCard') : t('expandCard')}
            >
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="template-link-expand-icon">
                    <path d="M2.5 4.5L6 8L9.5 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
            </button>
            {isExpanded && (
                <div className={`card-gallery-item template-link-preview-item ${!hasAnimatedRef.current ? 'animate' : ''}`}>
                    {item && itemType ? (
                        <CardRenderer
                            templateHtml={itemType.templateHtml}
                            templateCss={itemType.templateCss}
                            fields={itemType.cardFieldsDef}
                            cardData={item}
                            onClick={(e) => e.stopPropagation()}
                            onContextMenu={(e) => e.stopPropagation()}
                            onFieldChange={async (fieldName, newValue) => {
                                try {
                                    await updateCard({
                                        ...item,
                                        cardFields: { ...item.cardFields, [fieldName]: newValue }
                                    });
                                } catch (error) {
                                    console.error('更新卡片失敗:', error);
                                }
                            }}
                            onReviewChange={async (rating) => {
                                const myRev = getMyReview(item.id, currentMemberID);
                                const hasComment = myRev?.comment?.trim().length > 0;
                                if (!hasComment) {
                                    useDialogStore.getState().open('templateWriteReview', {
                                        cardName: item.name || '',
                                        initialRating: rating,
                                        initialComment: '',
                                        onSubmit: async ({ rating: r, comment }) => {
                                            try {
                                                await upsertReview(item.id, currentMemberID, r, comment);
                                            } catch (error) {
                                                console.error('更新評分失敗:', error);
                                            }
                                        },
                                    });
                                    return;
                                }
                                try {
                                    await upsertReview(item.id, currentMemberID, rating, myRev.comment);
                                } catch (error) {
                                    console.error('更新評分失敗:', error);
                                }
                            }}
                            canEditThisCard={undefined}
                            canRate={true}
                            isLoggedIn={isLoggedIn}
                            currentMemberID={currentMemberID}
                        />
                    ) : (
                        <div className="template-link-preview-not-found">{t('cardNotFound')}</div>
                    )}
                </div>
            )}
        </>
    );
};

// 建立展開按鈕 DOM
const createCardExpandButton = (cardId, noteId) => {
    const container = document.createElement('span');
    container.className = 'template-link-preview-root';
    container.setAttribute('data-template-id', cardId);
    container.setAttribute('data-mode', 'card');
    container.contentEditable = 'false';

    const root = ReactDOM.createRoot(container);
    root.render(<CardLinkPreview cardId={cardId} noteId={noteId} />);
    (container as any)._reactRoot = root;
    return container;
};

const isCardLink = (href) => href?.toLowerCase().startsWith('cubelv://card/');
const extractCardId = (href) => {
    const match = href.match(/cubelv:\/\/card\/([^?#]+)/i);
    return match ? match[1] : null;
};

export const CardLinkPreviewExtension = Extension.create({
    name: 'cardLinkPreview',

    addOptions() {
        return { getNoteId: () => null };
    },

    addProseMirrorPlugins() {
        const key = new PluginKey('cardLinkPreview');
        const { getNoteId } = this.options;

        const buildDecorations = (doc) => {
            const decos = [];
            const noteId = getNoteId();

            doc.descendants((node, pos) => {
                if (!node.isText) return true;
                const linkMark = node.marks.find(m => m.type.name === 'link');
                if (linkMark && isCardLink(linkMark.attrs.href)) {
                    const cardId = extractCardId(linkMark.attrs.href);
                    if (cardId && noteId) {
                        decos.push(Decoration.widget(
                            pos + node.nodeSize,
                            () => createCardExpandButton(cardId, noteId),
                            { side: 1, key: `template-preview-card-${cardId}-${noteId}` }
                        ));
                    }
                }
                return true;
            });

            return DecorationSet.create(doc, decos);
        };

        return [
            new Plugin({
                key,
                state: {
                    init: (_, editorState) => buildDecorations(editorState.doc),
                    apply: (tr, oldState, oldEditorState, newEditorState) => {
                        return buildDecorations(newEditorState.doc);
                    }
                },
                props: {
                    decorations(state) { return this.getState(state); },
                },
            }),
        ];
    },
});

export default CardLinkPreviewExtension;
