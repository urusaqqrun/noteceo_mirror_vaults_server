import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useCardRecognitionStore, useAutoCompletingCardsStore, useCardsStore } from './cardStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';
import { recognizeCardFromImage } from './ai/cardAI';
import { checkAndHandleCreditsError } from '../../../aiService/promptClient';
import { autoCompleteCardFields } from './ai/cardAI';
import syncService from '../../../utils/syncService';
import { getFirstTextFieldName } from '../../../utils/cardFieldUtils';
import './AddCardDialog.css';
import '../../common/CustomSelect.css';
import StarEmptyIcon from '../../../assets/icon_star_empty_24.svg?react';
import StarFullIcon from '../../../assets/icon_star_full_24.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_26_n2.svg?react';

/**
 * AddCardDialog 組件（純 UI 化）
 * 從 dialogStore['addCard'].data 讀取所有配置
 */
interface AddCardDialogData {
  cardType: any;
  editCard?: any;
  focusField?: string | null;
  initialImages?: { file: File | null; preview: string; base64: string }[] | null;
  autoStart?: boolean;
}

function AddCardDialog() {
  const dialogShow = useDialogStore(state => state.dialogs['addCard']?.show);
  const dialogData = useDialogStore(state => state.dialogs['addCard']?.data) as AddCardDialogData | null;
  const cardType = dialogData?.cardType ?? null;
  const editCard = dialogData?.editCard ?? null;
  const focusField = dialogData?.focusField ?? null;
  const initialImages = dialogData?.initialImages ?? null;
  const autoStart = dialogData?.autoStart ?? false;
  const onClose = () => useDialogStore.getState().close('addCard');

  const { t } = useTranslation();
  const addCard = useCardsStore(state => state.addCard);
  const updateCard = useCardsStore(state => state.updateCard);
  const deleteCard = useCardsStore(state => state.deleteCard);
  const setTempHint = useTempHintStore(state => state.setTempHint);

  // cardType.cardFieldsDef 可能是 JSON 字串，統一解析（本地 Item 格式）
  const cardTypeFields = useMemo(() => {
    const raw = (cardType as any)?.cardFieldsDef ?? (cardType as any)?.fields;
    if (typeof raw === 'string') {
      try { return JSON.parse(raw); } catch { return []; }
    }
    return raw || [];
  }, [(cardType as any)?.cardFieldsDef, (cardType as any)?.fields]);

  // 模式：'image' 圖片辨識 | 'manual' 手動填寫（編輯模式下預設手動）
  const [mode, setMode] = useState(editCard ? 'manual' : 'image');

  const [formData, setFormData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAutoCompleting, setIsAutoCompleting] = useState(false);
  const [openMultiselect, setOpenMultiselect] = useState(null); // 追蹤哪個多選菜單開啟
  const inputRefs = useRef({});
  const multiselectRef = useRef(null);

  // 圖片辨識相關 state
  const [images, setImages] = useState([]); // { file, preview, base64 }[]
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef(null);
  const autoStartTriggeredRef = useRef(false); // 防止 autoStart 重複觸發

  // 使用全局辨識狀態 store
  const {
    isRecognizing: globalIsRecognizing,
    startRecognition,
    updateProgress,
    incrementSuccess,
    incrementFailed,
    finishRecognition
  } = useCardRecognitionStore();

  // 使用全局自動補完狀態 store
  const addAutoCompletingCard = useAutoCompletingCardsStore(state => state.addAutoCompletingCard);
  const removeAutoCompletingCard = useAutoCompletingCardsStore(state => state.removeAutoCompletingCard);

  // 檢查是否已中斷（需要用 getState 獲取最新狀態，因為 dialog 關閉後組件會卸載）
  const checkIsAborted = () => useCardRecognitionStore.getState().isAborted();

  // 處理 initialImages 和 autoStart
  const processedBase64SetRef = useRef(new Set());
  useEffect(() => {
    if (initialImages && initialImages.length > 0) {
      // 過濾出尚未處理過的圖片（用 base64 作為唯一標識）
      const newImages = initialImages.filter(img => {
        if (processedBase64SetRef.current.has(img.base64)) {
          return false;
        }
        processedBase64SetRef.current.add(img.base64);
        return true;
      });

      if (newImages.length > 0) {
        setImages(prev => [...prev, ...newImages]);
      }
    }
  }, [initialImages]);

  // Focus 指定欄位
  useEffect(() => {
    if (focusField && inputRefs.current[focusField]) {
      const input = inputRefs.current[focusField];
      setTimeout(() => {
        input.focus();
        // 將 cursor 放到文字最後（僅支援 text/textarea 等類型，number/date 等不支援）
        const unsupportedTypes = ['number', 'date', 'datetime-local', 'time', 'month', 'week'];
        if (input.setSelectionRange && !unsupportedTypes.includes(input.type)) {
          const len = input.value?.length || 0;
          input.setSelectionRange(len, len);
        }
      }, 100);
    }
  }, [focusField]);

  // 初始化表單數據
  useEffect(() => {
    if (editCard) {
      setFormData(editCard.cardFields || {});
    } else {
      // 初始化空表單
      const initialData = {};
      cardTypeFields.forEach(field => {
        initialData[field.name] = '';
      });
      setFormData(initialData);
    }
  }, [cardType, editCard]);

  // 處理欄位變更
  const handleFieldChange = (label, value) => {
    setFormData(prev => ({
      ...prev,
      [label]: value
    }));
  };

  // 點擊外部關閉多選菜單
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (multiselectRef.current && !multiselectRef.current.contains(e.target)) {
        setOpenMultiselect(null);
      }
    };
    if (openMultiselect) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [openMultiselect]);

  // 處理刪除
  const handleDelete = async () => {
    if (!editCard) return;

    try {
      await deleteCard(editCard);
      setTempHint(t('cardDeleted'));
      onClose();
    } catch (error) {
      console.error('刪除卡片失敗:', error);
      setTempHint(t('deleteFailed'));
    }
  };

  // 檢查第一個 TEXT/TEXTAREA 欄位是否有值
  const hasFirstFieldValue = () => {
    const firstFieldName = getFirstTextFieldName(cardTypeFields);
    if (!firstFieldName) return false;
    const value = formData[firstFieldName];
    return value && value.trim() !== '';
  };

  // 自動補完並創建卡片
  const handleAutoCompleteAndCreate = async () => {
    setIsAutoCompleting(true);
    const newCardId = generateObjectID();
    try {
      // 取得第一個 TEXT/TEXTAREA 欄位的值作為 name
      const firstFieldName = getFirstTextFieldName(cardTypeFields);
      const cardName = firstFieldName ? (formData[firstFieldName] || t('newCard')) : t('newCard');

      // 先創建卡片
      await addCard({
        id: newCardId,
        parentID: cardType.id,
        name: cardName,
        cardFields: formData
      });

      addAutoCompletingCard(newCardId);
      onClose();

      const fieldsBasedOnCardType: Record<string, string> = {};
      for (const fieldDef of cardTypeFields) {
        fieldsBasedOnCardType[fieldDef.name] = formData[fieldDef.name] || '';
      }

      const updatedFields = await autoCompleteCardFields({
        cardId: newCardId,
        parentID: cardType.id,
        cardTypeName: cardType.name,
        currentFields: fieldsBasedOnCardType,
        fieldDefinitions: cardTypeFields,
      });

      const existingCard = useCardsStore.getState().getCardById(newCardId);
      if (existingCard) {
        updateCard({ ...existingCard, cardFields: updatedFields });
      } else {
        updateCard({ id: newCardId, parentID: cardType.id, name: cardName, cardFields: updatedFields });
      }
      await syncService.syncChanges();

      removeAutoCompletingCard(newCardId);
      setTempHint(t('autoCompleteSuccess'));

    } catch (error: any) {
      console.error('自動補完並創建失敗:', error);
      if (!checkAndHandleCreditsError(error, false, 'handleAutoCompleteAndCreate')) {
        setTempHint(t('autoCompleteFailed'));
      }
      removeAutoCompletingCard(newCardId);
    } finally {
      setIsAutoCompleting(false);
    }
  };

  // 處理提交
  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      // 取得第一個 TEXT/TEXTAREA 欄位的值作為 name
      const firstFieldName = getFirstTextFieldName(cardTypeFields);
      const cardName = firstFieldName ? (formData[firstFieldName] || t('newCard')) : t('newCard');

      if (editCard) {
        const oldName = editCard.name;
        const newName = cardName;

        await updateCard({
          ...editCard,
          name: newName,
          cardFields: formData
        });

      } else {
        const newCardId = generateObjectID();
        await addCard({
          id: newCardId,
          parentID: cardType.id,
          name: cardName,
          cardFields: formData
        });
      }
      onClose();
    } catch (error) {
      console.error('保存卡片失敗:', error);
      setTempHint(t('saveFailed'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // 處理圖片選擇
  const handleImageSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    await processImageFiles(files);
    // 清空 input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // 處理圖片拖曳
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files) as File[];
    const imageFiles = files.filter(file => {
      if (file.type && file.type.startsWith('image')) return true;
      const ext = file.name.split('.').pop().toLowerCase();
      return ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp', 'heic', 'heif'].includes(ext);
    });

    if (imageFiles.length === 0) {
      setTempHint(t('pleaseSelectImage'));
      return;
    }

    await processImageFiles(imageFiles);
  };

  // 處理圖片檔案（轉換為 base64）
  const processImageFiles = async (files) => {
    const newImages = [];

    for (const file of files) {
      // 檢查檔案大小（限制 10MB）
      if (file.size > 10 * 1024 * 1024) {
        setTempHint(t('imageTooLarge'));
        continue;
      }

      try {
        // 轉換為 base64
        const base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        newImages.push({
          file,
          preview: URL.createObjectURL(file),
          base64: base64.split(',')[1] // 移除 data:image/xxx;base64, 前綴
        });
      } catch (error) {
        console.error('讀取圖片失敗:', error);
      }
    }

    setImages(prev => [...prev, ...newImages]);
  };

  // 刪除圖片
  const handleRemoveImage = (index) => {
    setImages(prev => {
      const newImages = prev.filter((_, i) => i !== index);
      // 釋放預覽 URL
      URL.revokeObjectURL(prev[index].preview);
      return newImages;
    });
  };

  // 檢查欄位是否都已填滿（非空）
  const checkFieldsComplete = (fields, fieldDefinitions) => {
    if (!fields || !fieldDefinitions) return false;

    for (const fieldDef of fieldDefinitions) {
      const value = fields[fieldDef.name];
      // 空字串、null、undefined 都算未填滿
      if (value === '' || value === null || value === undefined) {
        return false;
      }
    }
    return true;
  };

  // 批量補全卡片欄位：逐卡呼叫 autoCompleteCardFields（與右鍵補完、手動補完共用同一套）
  const batchCompleteAndCreateCards = async (incompleteCards, folderId, name, fieldDefinitions) => {
    const traceId = `batch-${Date.now().toString(36)}`;
    console.log('[AddCardImage] batchComplete start', {
      traceId, name, total: incompleteCards.length, fields: fieldDefinitions?.length || 0
    });

    const completed = [];

    for (const card of incompleteCards) {
      try {
        const updatedFields = await autoCompleteCardFields({
          cardId: card.id,
          parentID: folderId,
          cardTypeName: name,
          currentFields: card.recognizedFields,
          fieldDefinitions,
        });

        completed.push({
          id: card.id,
          parentID: folderId,
          name: card.name,
          cardFields: updatedFields,
        });
      } catch (error) {
        console.error(`[AddCardImage] batchComplete card ${card.id} error:`, error);
        checkAndHandleCreditsError(error);
        // 補完失敗仍用辨識到的部分欄位建卡
        completed.push({
          id: card.id,
          parentID: folderId,
          name: card.name,
          cardFields: card.recognizedFields,
        });
      }
    }

    return completed;
  };

  // 批量辨識圖片並新增卡片（背景執行）
  const handleRecognizeSubmit = async () => {
    if (images.length === 0) {
      setTempHint(t('pleaseAddImages'));
      return;
    }

    const traceId = `recog-${Date.now().toString(36)}`;
    // 判斷是否為協作模式（從 _permissions 推導，store addCard 也用同樣邏輯）
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const myMemberID = userData?.ID || '';
    const myPerm = cardType?._permissions?.find((p: any) => p.user_id === myMemberID);
    const isCollaborativeMode = !!myPerm && myPerm.permission !== 'owner';

    console.log('[AddCardImage] recognize start', {
      traceId,
      total: images.length,
      folderId: cardType?.id,
      name: cardType?.name,
      isCollaborativeMode
    });

    // 複製需要的資料，因為 dialog 會關閉
    const imagesToProcess = [...images];
    const cardTypeData = { ...cardType };
    const total = imagesToProcess.length;

    // 啟動全局辨識狀態
    startRecognition(total);

    // 先關閉 dialog，讓用戶可以做其他事
    onClose();

    // 背景執行辨識
    try {
      const completeCards = [];      // 欄位都填滿的卡片
      const incompleteCards = [];    // 需要 AI 補全的卡片
      let failedCount = 0;           // 辨識失敗的數量
      let successCount = 0;          // 成功計數
      const firstFieldName = getFirstTextFieldName(cardTypeData?.cardFieldsDef ?? cardTypeData?.fields);
      console.log('[AddCardImage] recognize init', {
        traceId,
        firstFieldName,
        fields: (cardTypeData?.cardFieldsDef ?? cardTypeData?.fields)?.length || 0
      });

      // 第一階段：辨識所有圖片
      for (let i = 0; i < imagesToProcess.length; i++) {
        // 檢查是否被中斷
        if (checkIsAborted()) {

          // 釋放預覽 URL
          imagesToProcess.forEach(img => URL.revokeObjectURL(img.preview));
          return;
        }

        const image = imagesToProcess[i];

        try {
          updateProgress(((i + 1) / total) * 50, t('recognizingImage', { current: i + 1, total }), i + 1);

          // 呼叫 API 辨識
          console.log('[AddCardImage] recognize image start', {
            traceId,
            index: i + 1,
            total,
            size: image?.file?.size,
            type: image?.file?.type
          });
          const recognizedFields = await recognizeCardFromImage(
            image.base64,
            cardTypeData.name,
            cardTypeData.cardFieldsDef
          );
          console.log('[AddCardImage] recognize image done', {
            traceId,
            index: i + 1,
            keys: recognizedFields ? Object.keys(recognizedFields).length : 0
          });

          // 檢查第一個 TEXT/TEXTAREA 欄位是否有值，沒有則視為辨識失敗
          const firstFieldValue = firstFieldName ? recognizedFields[firstFieldName] : null;
          console.log('[AddCardImage] recognize first field', {
            traceId,
            index: i + 1,
            firstFieldName,
            firstFieldValue: firstFieldValue ?? null
          });
          if (!firstFieldValue || firstFieldValue === '') {

            failedCount++;
            incrementFailed();
            continue; // 跳過此圖片，不需要後續處理
          }

          // 檢查欄位是否都已填滿
          const isComplete = checkFieldsComplete(recognizedFields, cardTypeData.cardFieldsDef);
          console.log('[AddCardImage] recognize completeness', {
            traceId,
            index: i + 1,
            isComplete
          });

          if (isComplete) {
            // 欄位完整，直接加入結果
            completeCards.push({
              id: generateObjectID(),
              parentID: cardTypeData.id,
              name: firstFieldValue,
              cardFields: recognizedFields
            });
            successCount++;
            incrementSuccess();
          } else {
            // 欄位不完整，先建立卡片基本資料，後續交給 AI 補完
            incompleteCards.push({
              id: generateObjectID(),
              parentID: cardTypeData.id,
              name: firstFieldValue,
              recognizedFields,
              imageIndex: i
            });
          }
        } catch (error) {
          console.error(`圖片 ${i + 1} 辨識失敗:`, error);
          console.error('[AddCardImage] recognize image error detail', {
            traceId,
            index: i + 1,
            message: error?.message,
            name: error?.name,
            stack: error?.stack
          });
          failedCount++;
          incrementFailed();
        }
      }

      // 檢查是否被中斷
      if (checkIsAborted()) {

        imagesToProcess.forEach(img => URL.revokeObjectURL(img.preview));
        return;
      }

      // 第二階段：批量處理需要 AI 補全的卡片（每 3 張一批）
      const aiCreatedCards = [];
      if (incompleteCards.length > 0) {

        console.log('[AddCardImage] recognize incomplete cards', {
          traceId,
          count: incompleteCards.length
        });
        updateProgress(50, t('aiCompletingFields'), total);

        // 分批處理，每批最多 3 張
        const batchSize = 3;
        for (let batchStart = 0; batchStart < incompleteCards.length; batchStart += batchSize) {
          // 檢查是否被中斷
          if (checkIsAborted()) {

            imagesToProcess.forEach(img => URL.revokeObjectURL(img.preview));
            return;
          }

          const batch = incompleteCards.slice(batchStart, batchStart + batchSize);
          console.log('[AddCardImage] batch start', {
            traceId,
            batchStart,
            batchSize: batch.length
          });

          // 呼叫 AI 批量處理
          const createdCards = await batchCompleteAndCreateCards(
            batch,
            cardTypeData.id,
            cardTypeData.name,
            cardTypeData.cardFieldsDef
          );
          console.log('[AddCardImage] batch result', {
            traceId,
            batchStart,
            created: createdCards?.length || 0
          });

          if (createdCards && createdCards.length > 0) {
            aiCreatedCards.push(...createdCards);
            // 更新成功計數
            for (let j = 0; j < createdCards.length; j++) {
              incrementSuccess();
            }
          }
        }
      }

      // 檢查是否被中斷
      if (checkIsAborted()) {

        imagesToProcess.forEach(img => URL.revokeObjectURL(img.preview));
        return;
      }

      // 合併所有結果（辨識完整的 + AI 補完的，統一建卡）
      const allResults = [...completeCards, ...aiCreatedCards];

      updateProgress(90, t('savingCards'), total);

      if (allResults.length > 0) {
        console.log('[AddCardImage] saving local recognized cards', {
          traceId,
          count: allResults.length,
          isCollaborativeMode
        });
        await addCard(allResults);
      }

      // AI 創建的卡片已由後端更新 CardStack，需要從遠端同步（僅非協作模式）
      if (aiCreatedCards.length > 0 && !isCollaborativeMode) {
        console.log('[AddCardImage] syncing after ai-created cards', {
          traceId,
          count: aiCreatedCards.length
        });
        await syncService.syncChanges();
      }

      // 釋放預覽 URL
      imagesToProcess.forEach(img => URL.revokeObjectURL(img.preview));

      const totalCreated = allResults.length;
      console.log('[AddCardImage] recognize finished', {
        traceId,
        totalCreated,
        failedCount,
        completeLocal: completeCards.length,
        aiCompleted: aiCreatedCards.length
      });

      // 構建結果訊息
      let resultMessage = '';
      if (totalCreated > 0 && failedCount > 0) {
        resultMessage = t('recognitionPartialSuccess', { success: totalCreated, failed: failedCount }) ||
          `${totalCreated} 張成功，${failedCount} 張辨識失敗`;
      } else if (totalCreated > 0) {
        resultMessage = t('recognitionComplete', { count: totalCreated }) || `成功新增 ${totalCreated} 張卡片`;
      } else {
        resultMessage = t('recognitionAllFailed', { count: failedCount }) || `${failedCount} 張辨識失敗`;
      }

      // 結束辨識
      finishRecognition();

      // 發送系統通知，若不可用則使用 tempHint（用 getState 獲取，因為組件已卸載）
      const showHint = (msg) => useTempHintStore.getState().setTempHint(msg);

      // iOS Safari 不支援 Notification API，需先檢查是否存在
      if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        new Notification('CubeLV', {
          body: resultMessage,
          silent: false,
        });
      } else if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            new Notification('CubeLV', {
              body: resultMessage,
              silent: false,
            });
          } else {
            showHint(resultMessage);
          }
        });
      } else {
        showHint(resultMessage);
      }

    } catch (error) {
      console.error('批量辨識失敗:', error);
      finishRecognition();
      useTempHintStore.getState().setTempHint(t('recognitionFailed'));
    }
  };

  // 處理 autoStart：當圖片準備好且 autoStart=true 時自動開始辨識
  useEffect(() => {
    if (autoStart && images.length > 0 && !autoStartTriggeredRef.current && !globalIsRecognizing) {
      autoStartTriggeredRef.current = true;
      // 延遲一下確保 UI 已渲染
      setTimeout(() => {
        handleRecognizeSubmit();
      }, 100);
    }
  }, [autoStart, images, globalIsRecognizing]);

  // 複製文字到剪貼簿
  const handleCopy = async (text) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setTempHint(t('copied'));
    } catch (err) {
      console.error('複製失敗:', err);
    }
  };

  // 複製按鈕組件
  const CopyButton = ({ value }) => (
    <button
      type="button"
      className="add-card-copy-btn"
      onClick={() => handleCopy(value)}
      title={t('copy')}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
    </button>
  );

  // 渲染欄位輸入
  const renderField = (field) => {
    const value = formData[field.name] || '';

    switch (field.type) {
      case 'TEXT':
      case 'PHONE':
      case 'EMAIL':
      case 'URL':
        return (
          <div className="add-card-input-wrapper">
            <input
              ref={el => { inputRefs.current[field.name] = el; }}
              type={field.type === 'EMAIL' ? 'email' : field.type === 'URL' ? 'url' : 'text'}
              className="add-card-input"
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              placeholder={`${t('enter')} ${field.name}`}
            />
            <CopyButton value={value} />
          </div>
        );

      case 'TEXTAREA':
        return (
          <textarea
            ref={el => { inputRefs.current[field.name] = el; }}
            className="add-card-textarea"
            value={value}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            placeholder={`${t('enter')} ${field.name}`}
            rows={3}
          />
        );

      case 'NUMBER':
        return (
          <div className="add-card-input-wrapper">
            <input
              ref={el => { inputRefs.current[field.name] = el; }}
              type="number"
              className="add-card-input"
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              placeholder={`${t('enter')} ${field.name}`}
            />
            <CopyButton value={value} />
          </div>
        );

      case 'DATE':
        return (
          <div className="add-card-input-wrapper">
            <input
              ref={el => { inputRefs.current[field.name] = el; }}
              type="date"
              className="add-card-input"
              value={value ? value.replace(/\//g, '-') : ''}
              onChange={(e) => handleFieldChange(field.name, e.target.value.replace(/-/g, '/'))}
            />
            <CopyButton value={value} />
          </div>
        );

      case 'DATETIME':
        return (
          <div className="add-card-input-wrapper">
            <input
              ref={el => { inputRefs.current[field.name] = el; }}
              type="datetime-local"
              className="add-card-input"
              value={value ? value.replace(/\//g, '-').replace(' ', 'T') : ''}
              onChange={(e) => handleFieldChange(field.name, e.target.value.replace(/-/g, '/').replace('T', ' '))}
            />
            <CopyButton value={value} />
          </div>
        );

      case 'DATERANGE': {
        // 解析日期範圍格式：「YYYY/MM/DD ~ YYYY/MM/DD」
        const parseDateRange = (val) => {
          if (!val) return { start: '', end: '' };
          const parts = val.split(' ~ ');
          return {
            start: (parts[0]?.trim() || '').replace(/\//g, '-'),
            end: (parts[1]?.trim() || '').replace(/\//g, '-')
          };
        };
        const { start, end } = parseDateRange(value);
        return (
          <div className="add-card-daterange-wrapper">
            <input
              type="date"
              className="add-card-input add-card-daterange-input"
              value={start}
              onChange={(e) => {
                const newStart = e.target.value.replace(/-/g, '/');
                const currentEnd = end.replace(/-/g, '/');
                handleFieldChange(field.name, newStart && currentEnd ? `${newStart} ~ ${currentEnd}` : newStart || currentEnd);
              }}
              placeholder={t('startDate')}
            />
            <span className="add-card-daterange-separator">~</span>
            <input
              type="date"
              className="add-card-input add-card-daterange-input"
              value={end}
              onChange={(e) => {
                const currentStart = start.replace(/-/g, '/');
                const newEnd = e.target.value.replace(/-/g, '/');
                handleFieldChange(field.name, currentStart && newEnd ? `${currentStart} ~ ${newEnd}` : currentStart || newEnd);
              }}
              placeholder={t('endDate')}
            />
            <CopyButton value={value} />
          </div>
        );
      }

      case 'SELECT':
        return (
          <select
            className="custom-select"
            value={value}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
          >
            {field.options?.map((opt, idx) => (
              <option key={idx} value={opt}>{opt}</option>
            ))}
          </select>
        );

      case 'MULTISELECT': {
        const valueStr = Array.isArray(value) ? value.join(', ') : (value || '');
        // 支援英文逗號、中文逗號、中文頓號
        const selectedValues = valueStr.split(/[,，、]/).map(s => s.trim()).filter(Boolean);
        const isOpen = openMultiselect === field.name;
        return (
          <div
            className="add-card-multiselect-container"
            ref={isOpen ? multiselectRef : null}
          >
            <div
              className="add-card-multiselect-trigger custom-select"
              onClick={() => setOpenMultiselect(isOpen ? null : field.name)}
            >
              {selectedValues.length > 0
                ? selectedValues.join(', ')
                : <span className="multiselect-placeholder">{t('selectOptions')}</span>
              }
            </div>
            {isOpen && (
              <div className="add-card-multiselect-menu">
                {field.options?.map((opt, idx) => {
                  const selected = selectedValues.includes(opt);
                  return (
                    <label key={idx} className="multiselect-menu-option">
                      <input
                        type="checkbox"
                        checked={selected}
                        onChange={(e) => {
                          if (e.target.checked) {
                            handleFieldChange(field.name, [...selectedValues, opt].join(', '));
                          } else {
                            handleFieldChange(field.name, selectedValues.filter(v => v !== opt).join(', '));
                          }
                        }}
                      />
                      <span>{opt}</span>
                    </label>
                  );
                })}
              </div>
            )}
          </div>
        );
      }

      case 'BOOLEAN':
        return (
          <label className="add-card-checkbox">
            <input
              type="checkbox"
              checked={value === 'true' || value === true}
              onChange={(e) => handleFieldChange(field.name, e.target.checked ? 'true' : 'false')}
            />
            <span>{field.name}</span>
          </label>
        );

      case 'RATING':
        return (
          <div className="add-card-rating">
            {[1, 2, 3, 4, 5].map(star => (
              <button
                key={star}
                type="button"
                className="rating-star"
                onClick={() => handleFieldChange(field.name, star.toString())}
              >
                {parseInt(value) >= star ? <StarFullIcon /> : <StarEmptyIcon />}
              </button>
            ))}
          </div>
        );

      case 'TAGS':
        return (
          <div className="add-card-input-wrapper">
            <input
              ref={el => { inputRefs.current[field.name] = el; }}
              type="text"
              className="add-card-input"
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              placeholder={t('tagsPlaceholder')}
            />
            <CopyButton value={value} />
          </div>
        );

      case 'IMAGE':
        return (
          <div className="add-card-input-wrapper">
            <input
              type="text"
              className="add-card-input"
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              placeholder={t('imageUrlPlaceholder')}
            />
            <CopyButton value={value} />
          </div>
        );

      case 'LOCATION':
        return (
          <div className="add-card-input-wrapper">
            <input
              ref={el => { inputRefs.current[field.name] = el; }}
              type="text"
              className="add-card-input"
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              placeholder={t('locationPlaceholder')}
            />
            <CopyButton value={value} />
          </div>
        );

      default:
        return (
          <div className="add-card-input-wrapper">
            <input
              type="text"
              className="add-card-input"
              value={value}
              onChange={(e) => handleFieldChange(field.name, e.target.value)}
              placeholder={`${t('enter')} ${field.name}`}
            />
            <CopyButton value={value} />
          </div>
        );
    }
  };

  if (!dialogShow || !cardType) return null;

  return (
    <div className="add-card-dialog-overlay" onClick={onClose}>
      <div className="add-card-dialog" onClick={e => e.stopPropagation()}>
        <div className="add-card-dialog-header">
          <h3>{editCard ? t('editCard') : t('addCard')}</h3>
          <button className="add-card-close-btn" onClick={onClose}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        {/* 模式切換 Tab（僅新增模式顯示） */}
        {!editCard && (
          <div className="add-card-mode-tabs">
            <button
              className={`add-card-mode-tab ${mode === 'image' ? 'active' : ''}`}
              onClick={() => setMode('image')}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <circle cx="8.5" cy="8.5" r="1.5"></circle>
                <polyline points="21 15 16 10 5 21"></polyline>
              </svg>
              {t('imageRecognition')}
            </button>
            <button
              className={`add-card-mode-tab ${mode === 'manual' ? 'active' : ''}`}
              onClick={() => setMode('manual')}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
              {t('manualInput')}
            </button>
          </div>
        )}

        <div className="add-card-dialog-body">
          {/* 圖片辨識模式 */}
          {mode === 'image' && !editCard && (
            <div className="add-card-image-mode">
              {/* 拖曳區域 */}
              <div
                className={`add-card-dropzone ${isDragging ? 'dragging' : ''} ${images.length > 0 ? 'has-images' : ''}`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  style={{ display: 'none' }}
                  onChange={handleImageSelect}
                />

                {images.length === 0 ? (
                  <div className="add-card-dropzone-content">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                      <circle cx="8.5" cy="8.5" r="1.5"></circle>
                      <polyline points="21 15 16 10 5 21"></polyline>
                    </svg>
                    <p className="add-card-dropzone-text">
                      {window.innerWidth <= 768
                        ? t('clickToAddImages')
                        : t('dragOrAddImages')}
                    </p>
                  </div>
                ) : (
                  <div className="add-card-images-grid">
                    {images.map((image, index) => (
                      <div key={index} className="add-card-image-item">
                        <img src={image.preview} alt={`preview-${index}`} />
                        <button
                          className="add-card-image-remove"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveImage(index);
                          }}
                        >
                          <DeleteIcon />
                        </button>
                      </div>
                    ))}
                    {/* 新增更多圖片的按鈕 */}
                    <div
                      className="add-card-image-add"
                      onClick={(e) => {
                        e.stopPropagation();
                        fileInputRef.current?.click();
                      }}
                    >
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                      </svg>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 手動填寫模式 */}
          {(mode === 'manual' || editCard) && (
            <>
              {cardTypeFields.map((field, index) => (
                <div key={index} className="add-card-field">
                  <label className="add-card-label">{field.name}</label>
                  {renderField(field)}
                </div>
              ))}
            </>
          )}
        </div>

        <div className="add-card-dialog-footer">
          {editCard && (
            <button
              className="add-card-btn-delete"
              onClick={handleDelete}
              disabled={isSubmitting}
            >
              {t('deleteCard')}
            </button>
          )}
          <div className="add-card-footer-right">
            <button className="custom-secondary-button" onClick={onClose}>
              {t('cancel')}
            </button>
            {/* 自動補完欄位按鈕 - 只在手動填寫模式且非編輯模式時顯示 */}
            {mode === 'manual' && !editCard && (
              <button
                className="custom-secondary-button"
                onClick={handleAutoCompleteAndCreate}
                disabled={isAutoCompleting || isSubmitting || !hasFirstFieldValue()}
              >
                {isAutoCompleting ? t('autoCompleting') : t('autoCompleteAndCreate')}
              </button>
            )}
            {mode === 'image' && !editCard ? (
              <button
                className="custom-primary-button"
                onClick={handleRecognizeSubmit}
                disabled={globalIsRecognizing || images.length === 0}
              >
                {globalIsRecognizing ? t('recognizing') : t('confirm')}
              </button>
            ) : (
              <button
                className="custom-primary-button"
                onClick={handleSubmit}
                disabled={isSubmitting || isAutoCompleting || (!editCard && !hasFirstFieldValue())}
              >
                {isSubmitting ? t('saving') : t('confirm')}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddCardDialog;
