import React from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';

/**
 * RequestPermissionDialog 純 UI 化
 * 分享畫廊中請求編輯權限的對話框
 * 從 dialogStore['requestPermission'].data 讀取所有配置
 * 原本 inline 在 CardGallery.tsx 裡
 */
export interface RequestPermissionDialogData {
  /** 目前的權限文字（contributor / viewer 已由呼叫方翻譯好） */
  permissionLabel: string;
  /** 目前權限的說明文字 */
  permissionDesc: string;
  /** 是否已有待審核請求 */
  isPending: boolean;
  /** 確認送出請求的 callback */
  onRequest: () => Promise<void>;
}

const RequestPermissionDialog: React.FC = () => {
  const { t } = useTranslation();
  const show = useDialogStore(state => state.dialogs['requestPermission']?.show);
  const data = useDialogStore(state => state.dialogs['requestPermission']?.data) as RequestPermissionDialogData | null;

  if (!show || !data) return null;

  const { permissionLabel, permissionDesc, isPending, onRequest } = data;

  const handleClose = () => useDialogStore.getState().close('requestPermission');

  const handleRequest = async () => {
    if (isPending) return;
    await onRequest();
    handleClose();
  };

  return (
    <CustomDialog
      isOpen
      onClose={handleClose}
      title={t('requestEditPermission')}
    >
      <p className="custom-dialog-description" style={{ fontWeight: 500, color: 'var(--on)', marginBottom: 8 }}>
        {t('requestPermissionCurrentStatus', { permission: permissionLabel })}
      </p>
      <p className="custom-dialog-description">
        {permissionDesc}{'。'}{t('requestPermissionDescription')}
      </p>
      <div className="custom-dialog-buttons">
        <button className="custom-secondary-button" onClick={handleClose}>
          {t('cancel')}
        </button>
        <button
          className="custom-primary-button"
          disabled={isPending}
          style={isPending ? { opacity: 0.5, cursor: 'not-allowed' } : {}}
          onClick={handleRequest}
        >
          {isPending ? t('permissionPending') : t('sendRequest')}
        </button>
      </div>
    </CustomDialog>
  );
};

export default RequestPermissionDialog;
