import React from 'react';
import CardGallery from '../CardGallery';

export default function PublicGalleryView() {
  return (
    <div className="card-gallery-wrapper" style={{ marginLeft: 0 }}>
      <CardGallery isPublicShareMode={true} />
    </div>
  );
}
