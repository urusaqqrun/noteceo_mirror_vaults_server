import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { getEditHistory } from '../../../../utils/shareAPI';
import './EditHistoryPanel.css';
import '../../../common/CustomSelect.css';
import { PopupMenu, PopupMenuItem } from '../../../common/PopupMenu';
import EditHistoryList, { ChangeType } from '../../../common/share/EditHistoryList';

/**
 * EditHistoryPanel 組件
 * 顯示畫廊的編輯歷史記錄
 */
function EditHistoryPanel({ isOpen, onClose, folderId, existingCards, onCardClick, onActorClick }) {
  const { t } = useTranslation();
  const [histories, setHistories] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [filterType, setFilterType] = useState('ALL');
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const [filterMenuPosition, setFilterMenuPosition] = useState({ x: 0, y: 0 });
  const filterButtonRef = useRef(null);

  // 載入編輯歷史
  const loadHistory = useCallback(async () => {
    if (!folderId) return;

    setIsLoading(true);
    try {
      const input: { itemId: string; changeTypes?: string[] } = {
        itemId: folderId,
      };
      if (filterType !== 'ALL') {
        input.changeTypes = [filterType];
      }
      const result = await getEditHistory(input);
      setHistories(result || []);
    } catch (error) {
      console.error('載入編輯歷史失敗:', error);
      setHistories([]);
    } finally {
      setIsLoading(false);
    }
  }, [folderId, filterType]);

  // 當面板打開或篩選改變時載入
  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen, loadHistory]);

  const filterOptions = [
    { value: 'ALL', label: t('historyFilterAll') },
    { value: ChangeType.CREATED, label: t('historyFilterCreate') },
    { value: ChangeType.UPDATED, label: t('historyFilterUpdate') },
    { value: ChangeType.DELETED, label: t('historyFilterDelete') },
    { value: ChangeType.PERMISSION_GRANTED, label: t('historyFilterPermission') },
  ];


  if (!isOpen) return null;

  return (
    <div className="edit-history-panel">
      {/* 標題列 */}
      <div className="edit-history-header">
        <h3 className="edit-history-title">
          {t('editHistory')}
        </h3>
        <button
          className="edit-history-close-btn"
          onClick={onClose}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      {/* 篩選器 */}
      <button
        ref={filterButtonRef}
        className="custom-select edit-history-select"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          setFilterMenuPosition({ x: rect.left, y: rect.bottom + 4 });
          setShowFilterMenu(true);
        }}
      >
        {filterOptions.find(opt => opt.value === filterType)?.label || t('historyFilterAll')}
      </button>

      {/* 篩選選單 */}
      {showFilterMenu && (
        <PopupMenu
          x={filterMenuPosition.x}
          y={filterMenuPosition.y}
          onClose={() => setShowFilterMenu(false)}
        >
          {filterOptions.map(option => (
            <PopupMenuItem
              key={option.value}
              onClick={() => {
                setFilterType(option.value);
                setShowFilterMenu(false);
              }}
            >
              {option.label}
            </PopupMenuItem>
          ))}
        </PopupMenu>
      )}

      {/* 歷史列表 */}
      <EditHistoryList
        histories={histories}
        isLoading={isLoading}
        onActorClick={onActorClick}
        emptyText=""
      />
    </div>
  );
}

export default EditHistoryPanel;
