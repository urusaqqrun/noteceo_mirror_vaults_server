import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';

/**
 * LazyCard - 延遲渲染組件
 * 只在進入可視區域時才渲染子元素，之前顯示占位符
 * 使用一個 1px sentinel 元素來觀察，不影響布局
 */
const LazyCard = ({
  children,
  scrollContainer,
  placeholder
}) => {
  const [hasBeenVisible, setHasBeenVisible] = useState(false);
  const sentinelRef = useRef(null);

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel || hasBeenVisible) return; // 已經顯示過就不需要再觀察

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setHasBeenVisible(true);
            observer.disconnect(); // 一旦進入視圖就停止觀察
          }
        });
      },
      {
        root: scrollContainer || null,
        rootMargin: '200px', // 提前 200px 開始渲染
        threshold: 0
      }
    );

    observer.observe(sentinel);

    return () => observer.disconnect();
  }, [scrollContainer, hasBeenVisible]);

  // 已經顯示過就永遠渲染完整內容
  if (hasBeenVisible) {
    return <>{children}</>;
  }

  // 還沒顯示過：渲染占位符 + 一個小的 sentinel 用於觀察
  return (
    <>
      {placeholder}
      <div
        ref={sentinelRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '1px',
          height: '1px',
          pointerEvents: 'none'
        }}
      />
    </>
  );
};

export default LazyCard;
