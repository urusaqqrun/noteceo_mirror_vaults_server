import React from 'react';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';
import CardRenderer from '../../common/CardRenderer';
import AvatarWithBubble from '../../common/AvatarWithBubble';

/**
 * CardPreviewDialog 純 UI 化
 * 從 dialogStore['cardPreview'].data 讀取所有配置
 * 合併原 CardDetailDialog（地圖模式手機版）與 CardShowDialog（歷史紀錄 / 貢獻者時間線）
 */
export interface CardPreviewDialogData {
  card: any;
  cardType: any;
  theme: any;
  currentMemberID: string | null;
  canRate?: boolean;
  /** 以下來自舊 CardDetailDialog（地圖模式） */
  onFieldChange?: (card: any, fieldName: string, newValue: any) => void;
  onReviewChange?: (card: any, rating: number) => void;
  onBubbleClick?: (card: any) => void;
  onAvatarClick?: (card: any) => void;
  onCloseExtra?: () => void;
  /** 以下來自舊 CardShowDialog（歷史 / 貢獻者時間線） */
  canEditThisCard?: boolean;
  isLoggedIn?: boolean;
  onRequestLogin?: () => void;
  onRequestPermission?: () => void;
}

const CardPreviewDialog: React.FC = () => {
  const showDialog = useDialogStore(state => state.dialogs['cardPreview']?.show);
  const dialogData = useDialogStore(state => state.dialogs['cardPreview']?.data) as CardPreviewDialogData | null;
  const isMobileView = useIsMobileView();

  if (!showDialog || !dialogData?.card) return null;

  const {
    card,
    cardType,
    theme,
    currentMemberID,
    canRate = true,
    onFieldChange,
    onReviewChange,
    onBubbleClick,
    onAvatarClick,
    onCloseExtra,
    canEditThisCard,
    isLoggedIn,
    onRequestLogin,
    onRequestPermission,
  } = dialogData;

  const handleClose = () => {
    useDialogStore.getState().close('cardPreview');
    onCloseExtra?.();
  };

  const hasAvatarBubble = !!(onBubbleClick || onAvatarClick);

  return (
    <CustomDialog
      isOpen={showDialog}
      onClose={handleClose}
      title=""
      className="card-show-dialog"
      showCloseButton={!isMobileView}
    >
      <div style={{ position: 'relative' }}>
        <CardRenderer
          cardData={card}
          templateHtml={(cardType as any)?.templateHtml}
          templateCss={(cardType as any)?.templateCss}
          fields={(cardType as any)?.cardFieldsDef ?? (cardType as any)?.fields}
          theme={theme}
          currentMemberID={currentMemberID}
          onFieldChange={onFieldChange ? (fieldName, newValue) => {
            onFieldChange(card, fieldName, newValue);
          } : undefined}
          onReviewChange={onReviewChange ? (rating) => {
            onReviewChange(card, rating);
          } : undefined}
          canRate={canRate}
          canEditThisCard={canEditThisCard}
          isLoggedIn={isLoggedIn}
          onRequestLogin={onRequestLogin}
          onRequestPermission={onRequestPermission}
        />
        {hasAvatarBubble && (
          <AvatarWithBubble
            cardData={card}
            currentMemberID={currentMemberID}
            onAvatarClick={(clickedCard) => {
              onAvatarClick?.(clickedCard || card);
            }}
            onBubbleClick={() => {
              onBubbleClick?.(card);
            }}
          />
        )}
      </div>
    </CustomDialog>
  );
};

export default CardPreviewDialog;
