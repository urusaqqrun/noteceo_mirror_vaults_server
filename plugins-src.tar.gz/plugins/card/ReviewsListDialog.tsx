import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './ReviewsListDialog.css';
import { useDialogStore } from '../../../Store/dialogStore';
import { useItemStore } from '../../../Store/itemStore';
import { CustomDialog } from '../../common/CustomDialog';
import { getReviewsByCardId, getMyReview, upsertReview, deleteReview, reviewId } from './reviewStore';
import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import { formatTimestamp } from '../../Utils/dateFormat';

/**
 * ReviewItem 組件 - 單一留言項目
 */
export function ReviewItem({ memberId, review, membersInfoMap = {}, fetchMemberInfo, currentMemberID, canDeleteOthersReview, onEditReview, onDeleteReview, cardOwnerId, onActorClick }) {
  const { t } = useTranslation();
  const [showMenu, setShowMenu] = useState(false);
  const [menuPosition, setMenuPosition] = useState({ growUp: false });
  const menuBtnRef = useRef(null);

  useEffect(() => {
    if (!memberId || membersInfoMap?.[memberId] || !fetchMemberInfo) return;
    fetchMemberInfo([memberId]);
  }, [memberId, membersInfoMap, fetchMemberInfo]);

  useEffect(() => {
    if (!showMenu) return;
    const handleClickOutside = (e) => {
      if (menuBtnRef.current && !menuBtnRef.current.contains(e.target)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showMenu]);

  const memberInfo = membersInfoMap?.[memberId] || {};

  const rating = typeof review.rating === 'number' ? review.rating : (parseInt(review.rating) || 0);

  const isMyReview = memberId === currentMemberID;
  const shouldShowMenuBtn = isMyReview || canDeleteOthersReview;

  const handleMenuClick = (e) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const screenHeight = window.innerHeight;
    const growUp = rect.top > screenHeight * (2 / 3);
    setMenuPosition({ growUp });
    setShowMenu(prev => !prev);
  };

  const handleEdit = () => {
    setShowMenu(false);
    onEditReview?.(memberId, { ...review, rating });
  };

  const handleDelete = () => {
    setShowMenu(false);
    onDeleteReview?.(memberId);
  };

  const isCardOwner = memberId === cardOwnerId;

  const handleAvatarClick = (e) => {
    e.stopPropagation();
    if (onActorClick && memberId) {
      onActorClick(memberId);
    }
  };

  return (
    <div className="reviews-list-item">
      <div className="reviews-list-item-header">
        {memberInfo.photo ? (
          <div
            className={`reviews-list-avatar-wrapper ${isCardOwner ? 'owner' : ''}`}
            onClick={handleAvatarClick}
            style={{ cursor: onActorClick ? 'pointer' : 'default' }}
          >
            <img
              src={memberInfo.photo}
              alt=""
              className="reviews-list-avatar"
            />
          </div>
        ) : (
          <div
            className={`reviews-list-avatar-placeholder ${isCardOwner ? 'owner' : ''}`}
            onClick={handleAvatarClick}
            style={{ cursor: onActorClick ? 'pointer' : 'default' }}
          />
        )}
        <span className="reviews-list-name">
          {memberInfo.name || t('anonymous')}
        </span>
        {rating > 0 && (
          <span className="reviews-list-rating">
            {'★'.repeat(rating)}{'☆'.repeat(5 - rating)}
          </span>
        )}
      </div>
      <p className="reviews-list-comment">{review.comment}</p>
      <div className="reviews-list-footer">
        {review.updatedAt && (
          <span className="reviews-list-time">
            {formatTimestamp(review.updatedAt)}
          </span>
        )}
        {shouldShowMenuBtn && (
          <div className="reviews-list-menu-wrapper" ref={menuBtnRef}>
            <button
              className="reviews-list-menu-btn"
              onClick={handleMenuClick}
            >
              <MoreIcon />
            </button>
            {showMenu && (
              <div className={`reviews-list-menu ${menuPosition.growUp ? 'grow-up' : 'grow-down'}`}>
                {isMyReview && (
                  <button onClick={handleEdit}>
                    {t('editComment')}
                  </button>
                )}
                <button onClick={handleDelete}>
                  {t('deleteComment')}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

const PAGE_SIZE = 50;

/**
 * ReviewsListDialog 組件 - 留言列表（可複用於 info panel 和 dialog）
 */
export function ReviewsListDialog({
  card,
  membersInfoMap,
  fetchMemberInfo,
  currentMemberID,
  currentUserInfo,
  canReview,
  canDeleteOthersReview,
  onAddReview,
  onEditReview,
  onDeleteReview,
  onActorClick
}) {
  const { t } = useTranslation();
  const [displayCount, setDisplayCount] = useState(PAGE_SIZE);
  const listRef = useRef(null);
  const loadMoreRef = useRef(null);

  // 訂閱 REVIEW items 變更以觸發 re-render
  const allReviews = useItemStore(s => s.byType['REVIEW'] ?? []);

  useEffect(() => {
    setDisplayCount(PAGE_SIZE);
  }, [card?.id]);

  if (!card) return null;

  const reviews = getReviewsByCardId(card.id);
  const ownerEntry = card._permissions?.find((p: any) => p.permission === 'owner');
  const cardOwnerId = ownerEntry?.user_id;

  // 分類排序：owner → 自己 → 其他（按時間）
  let ownerReview = null;
  let myReview = null;
  let otherReviews = [];

  reviews
    .filter(r => r.comment?.trim().length > 0)
    .forEach(r => {
      const parts = r.id.split('_');
      const memberId = parts.slice(2).join('_');
      const entry = { memberId, review: r };
      if (memberId === cardOwnerId) {
        ownerReview = entry;
      } else if (memberId === currentMemberID) {
        myReview = entry;
      } else {
        otherReviews.push(entry);
      }
    });

  otherReviews.sort((a, b) => parseInt(b.review.updatedAt || '0') - parseInt(a.review.updatedAt || '0'));

  const reviewList = [];
  if (ownerReview) reviewList.push(ownerReview);
  if (myReview) reviewList.push(myReview);
  reviewList.push(...otherReviews);

  const hasMyComment = !!myReview;
  const displayList = reviewList.slice(0, displayCount);
  const hasMore = displayCount < reviewList.length;

  const loadMore = () => {
    setDisplayCount(prev => Math.min(prev + PAGE_SIZE, reviewList.length));
  };

  useEffect(() => {
    if (!hasMore || !loadMoreRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => { if (entries[0].isIntersecting) loadMore(); },
      { threshold: 0.1 }
    );
    observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [hasMore, displayCount]);

  const AddReviewInput = () => (
    <div
      className="reviews-list-add-input"
      onClick={() => onAddReview?.(card)}
    >
      {currentUserInfo?.photo ? (
        <img src={currentUserInfo.photo} alt="" className="reviews-list-add-avatar" />
      ) : (
        <div className="reviews-list-add-avatar-placeholder" />
      )}
      <span className="reviews-list-add-placeholder">
        {t('writeYourComment')}
      </span>
    </div>
  );

  if (reviewList.length === 0) {
    return (
      <div className="reviews-list-empty">
        {!hasMyComment && canReview && <AddReviewInput />}
      </div>
    );
  }

  return (
    <div className="reviews-list" ref={listRef}>
      {!hasMyComment && canReview && <AddReviewInput />}

      {displayList.map(({ memberId, review }) => (
        <ReviewItem
          key={memberId}
          memberId={memberId}
          review={review}
          membersInfoMap={membersInfoMap}
          fetchMemberInfo={fetchMemberInfo}
          currentMemberID={currentMemberID}
          canDeleteOthersReview={canDeleteOthersReview}
          cardOwnerId={cardOwnerId}
          onEditReview={onEditReview}
          onDeleteReview={onDeleteReview}
          onActorClick={onActorClick}
        />
      ))}

      {hasMore && (
        <div ref={loadMoreRef} className="reviews-list-load-more">
          <span>{t('loadingMore')}</span>
        </div>
      )}
    </div>
  );
}

export const ReviewsListModalDialog: React.FC = () => {
    const { t } = useTranslation();
    const show = useDialogStore(s => s.dialogs['reviewsList']?.show);
    const data = useDialogStore(s => s.dialogs['reviewsList']?.data) as any;

    if (!show || !data?.card) return null;

    const close = () => useDialogStore.getState().close('reviewsList');

    const handleAddReview = (card) => {
        if (!data.isLoggedIn) {
            close();
            useDialogStore.getState().open('login', { type: 'review' });
            return;
        }
        const myExisting = getMyReview(card.id, data.currentMemberID);
        close();
        useDialogStore.getState().open('writeReview', {
            cardName: card.name ?? '',
            initialRating: myExisting?.rating || 0,
            initialComment: myExisting?.comment || '',
            onSubmit: async ({ rating: r, comment }) => {
                try {
                    await upsertReview(card.id, data.currentMemberID, r, comment);
                } catch (error) {
                    console.error('新增留言失敗:', error);
                }
            },
        });
    };

    const handleEditReview = (_reviewMemberId, reviewData) => {
        close();
        useDialogStore.getState().open('writeReview', {
            cardName: data.card.name ?? '',
            initialRating: reviewData.rating || 0,
            initialComment: reviewData.comment || '',
            onSubmit: async ({ rating: r, comment }) => {
                try {
                    await upsertReview(data.card.id, _reviewMemberId, r, comment);
                } catch (error) {
                    console.error('更新留言失敗:', error);
                }
            },
        });
    };

    const handleDeleteReview = async (reviewMemberId) => {
        try {
            await deleteReview(data.card.id, reviewMemberId);
        } catch (error) {
            console.error('刪除留言失敗:', error);
        }
    };

    return (
        <CustomDialog
            isOpen
            onClose={close}
            title={data.card?.name ?? t('reviews')}
            className="card-gallery-reviews-dialog"
        >
            <ReviewsListDialog
                card={data.card}
                currentMemberID={data.currentMemberID}
                currentUserInfo={data.currentUserInfo}
                membersInfoMap={data.membersInfoMap}
                fetchMemberInfo={data.fetchMemberInfo}
                canReview={data.canReview}
                canDeleteOthersReview={data.canDeleteOthersReview}
                onActorClick={data.onActorClick}
                onAddReview={handleAddReview}
                onEditReview={handleEditReview}
                onDeleteReview={handleDeleteReview}
            />
        </CustomDialog>
    );
};

export default ReviewsListDialog;
