import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../../common/CustomDialog';
import { useDialogStore } from '../../../Store/dialogStore';
import './WriteReviewDialog.css';

interface WriteReviewDialogData {
  cardName?: string;
  initialRating?: number;
  initialComment?: string;
  onSubmit: (result: { rating: number; comment: string }) => void;
}

const WriteReviewDialog: React.FC<{ dialogKey: string }> = ({ dialogKey }) => {
  const { t } = useTranslation();
  const show = useDialogStore(s => s.dialogs[dialogKey]?.show);
  const data = useDialogStore(s => s.dialogs[dialogKey]?.data) as WriteReviewDialogData | undefined;

  const initialRating = data?.initialRating ?? 0;
  const initialComment = data?.initialComment ?? '';
  const cardName = data?.cardName ?? '';

  const [rating, setRating] = useState(initialRating);
  const [comment, setComment] = useState(initialComment);
  const [hoverRating, setHoverRating] = useState(0);

  useEffect(() => {
    if (show) {
      setRating(initialRating);
      setComment(initialComment);
      setHoverRating(0);
    }
  }, [show, initialRating, initialComment]);

  if (!show) return null;

  const close = () => useDialogStore.getState().close(dialogKey);

  const handleSubmit = () => {
    data?.onSubmit({ rating, comment: comment.trim() });
    close();
  };

  const charCount = comment.length;
  const maxChars = 50;

  return (
    <CustomDialog
      isOpen
      onClose={close}
      title={t('addReview')}
      className="review-dialog"
      disableBackdropClose={true}
    >
      {cardName && (
        <p className="review-dialog-card-name">{cardName}</p>
      )}

      <div className="review-dialog-rating-section">
        <label className="review-dialog-label">{t('yourRating')}</label>
        <div className="review-dialog-stars">
          {[1, 2, 3, 4, 5].map((star) => (
            <span
              key={star}
              className={`review-dialog-star ${(hoverRating || rating) >= star ? 'filled' : ''}`}
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
            >
              ★
            </span>
          ))}
        </div>
      </div>

      <div className="review-dialog-comment-section">
        <label className="review-dialog-label">{t('yourComment')}</label>
        <textarea
          className="review-dialog-textarea"
          value={comment}
          onChange={(e) => {
            if (e.target.value.length <= maxChars) {
              setComment(e.target.value);
            }
          }}
          placeholder={t('commentPlaceholder')}
          rows={3}
        />
        <div className="review-dialog-char-count">
          {charCount}/{maxChars}
        </div>
      </div>

      <div className="review-dialog-buttons">
        <button className="custom-secondary-button" onClick={close}>
          {t('cancel')}
        </button>
        <button
          className="custom-primary-button"
          onClick={handleSubmit}
          disabled={rating === 0}
        >
          {t('submit')}
        </button>
      </div>
    </CustomDialog>
  );
};

export const GalleryWriteReviewDialog: React.FC = () => (
    <WriteReviewDialog dialogKey="writeReview" />
);

export const TemplateWriteReviewDialog: React.FC = () => (
    <WriteReviewDialog dialogKey="templateWriteReview" />
);

export default WriteReviewDialog;
