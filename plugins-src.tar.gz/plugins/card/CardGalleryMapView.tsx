import React, { useState, useMemo, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { MapContainer, TileLayer, Marker, useMap } from 'react-leaflet';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import MarkerClusterGroup from 'react-leaflet-cluster';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './CardGalleryMapView.css';
import { useDialogStore } from '../../../Store/dialogStore';
import type { CardPreviewDialogData } from './CardPreviewDialog';

/**
 * 自訂圓角正方形標記圖標
 */
const createSquareMarkerIcon = (imageUrl, isSelected) => {
  return L.divIcon({
    className: 'card-map-marker-wrapper',
    html: `
      <div class="card-map-marker ${isSelected ? 'selected' : ''}">
        ${imageUrl
        ? `<div class="card-map-marker-content" style="background-image: url('${imageUrl}')"></div>`
        : `<div class="card-map-marker-icon">📍</div>`
      }
      </div>
    `,
    iconSize: [44, 52],
    iconAnchor: [22, 52],
    popupAnchor: [0, -52]
  });
};

/**
 * 自訂聚合圖標 - 顯示第一張卡片的圖片，外框依數量分層級
 */
const createClusterCustomIcon = (cluster) => {
  const count = cluster.getChildCount();
  // 取得第一個子標記的圖片
  const childMarkers = cluster.getAllChildMarkers();
  const firstMarker = childMarkers[0];
  const imageUrl = firstMarker?.options?.imageUrl;

  // 根據數量決定外框顏色層級：primary => accent => error
  let level = 'cluster-primary';
  if (count >= 10) level = 'cluster-accent';
  if (count >= 30) level = 'cluster-error';

  return L.divIcon({
    className: 'card-map-marker-wrapper',
    html: `
      <div class="card-map-marker card-map-cluster-marker ${level}">
        ${imageUrl
        ? `<div class="card-map-marker-content" style="background-image: url('${imageUrl}')"></div>`
        : `<div class="card-map-marker-icon">📍</div>`
      }
      </div>
    `,
    iconSize: [44, 52],
    iconAnchor: [22, 52]
  });
};

/**
 * 地圖自動適應所有標記範圍
 * 只在 markers 的位置資料真正變化時才觸發（避免評分/留言更新時重置地圖）
 */
function FitBounds({ markers }) {
  const map = useMap();
  const prevMarkersKeyRef = React.useRef('');

  // 生成 markers 位置的唯一 key（只包含 id 和座標）
  const markersKey = React.useMemo(() => {
    return markers
      .map(m => `${m.id}:${m.lat}:${m.lng}`)
      .sort()
      .join('|');
  }, [markers]);

  React.useEffect(() => {
    // 只有當位置資料真正變化時才調整地圖
    if (markersKey === prevMarkersKeyRef.current) {
      return;
    }
    prevMarkersKeyRef.current = markersKey;

    if (markers.length > 0 && map) {
      const timeoutId = setTimeout(() => {
        try {
          // 檢查地圖容器是否存在
          if (!map.getContainer()) return;
          const bounds = L.latLngBounds(markers.map(m => [m.lat, m.lng]));
          map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
        } catch (e) {
          // 忽略地圖卸載時的錯誤
        }
      }, 100);

      // 清理：停止動畫並清除 timeout
      return () => {
        clearTimeout(timeoutId);
        try {
          if (map && map.getContainer()) {
            map.stop(); // 停止所有正在進行的動畫
          }
        } catch (e) {
          // 忽略
        }
      };
    }
  }, [markers, map, markersKey]);

  return null;
}

/**
 * 地圖大小重算控制器 - 使用 ResizeObserver 即時監聽容器大小變化
 * 如果有 targetPosition，在 resize 期間平滑地保持標記在中心
 */
function MapResizeHandler({ targetPosition, isMobileView }) {
  const map = useMap();
  const targetPositionRef = React.useRef(targetPosition);
  targetPositionRef.current = targetPosition;

  React.useEffect(() => {
    if (!map) return;

    const container = map.getContainer();
    if (!container) return;

    const resizeObserver = new ResizeObserver(() => {
      try {
        map.invalidateSize({ animate: false });

        // 如果有目標位置且非手機版，平滑地保持標記在中心
        if (targetPositionRef.current && !isMobileView) {
          const currentZoom = map.getZoom();
          map.setView(targetPositionRef.current, currentZoom, {
            animate: true,
            duration: 0.15
          });
        }
      } catch (e) {
        // 忽略
      }
    });

    resizeObserver.observe(container);

    return () => {
      resizeObserver.disconnect();
    };
  }, [map, isMobileView]);

  return null;
}

/**
 * 地圖平移控制器
 * 手機版：將標記移到畫面上方，避免被彈窗遮擋
 * 桌面版：直接置中
 */
function MapPanController({ targetPosition, triggerKey, isMobileView }) {
  const map = useMap();

  React.useEffect(() => {
    if (!targetPosition || !map || !triggerKey) return;

    try {
      if (!map.getContainer()) return;

      if (isMobileView) {
        // 手機版：偏移到上方，避免彈窗遮擋
        const containerHeight = map.getSize().y;
        const offsetY = containerHeight * 0.25;
        const targetPoint = map.latLngToContainerPoint(targetPosition);
        const offsetPoint = L.point(targetPoint.x, targetPoint.y + offsetY);
        const offsetLatLng = map.containerPointToLatLng(offsetPoint);
        map.panTo(offsetLatLng, { animate: true, duration: 0.3 });
      } else {
        // 桌面版：直接置中
        map.panTo(targetPosition, { animate: true, duration: 0.3 });
      }
    } catch (e) {
      // 忽略
    }
  }, [triggerKey, targetPosition, map, isMobileView]);

  return null;
}

/**
 * CardGalleryMapView 組件
 * 以地圖方式展示卡片位置
 * 直接讀取 card.coordinates，不做任何編碼
 */
function CardGalleryMapView({
  cards,
  cardType,
  onCardClick,
  onCardHover,
  onContextMenu, // 右鍵選單回調（傳入 event, card）
  isInfoPanelOpen = false,
  theme,
  membersInfoMap = {},
  fetchMemberInfo,
  currentMemberID,
  // 評分相關 props
  onFieldChange,
  onReviewChange,
  canRate = true,
  // 氣泡點擊回調
  onBubbleClick,
  onAvatarClick
}) {
  const { t } = useTranslation();
  const isMobileView = useIsMobileView();
  const [targetMarkerPosition, setTargetMarkerPosition] = useState(null);
  const [panTriggerKey, setPanTriggerKey] = useState(0);
  const lastHoveredCardIdRef = useRef(null);

  // 取得卡片的第一張圖片欄位名稱
  const imageFieldName = useMemo(() => {
    let fields = (cardType as any)?.cardFieldsDef ?? (cardType as any)?.fields;
    if (typeof fields === 'string') {
      try { fields = JSON.parse(fields); } catch { fields = []; }
    }
    const imageField = Array.isArray(fields) ? fields.find(f => f.type === 'IMAGE') : null;
    return imageField?.name || null;
  }, [cardType]);

  // 篩選有 coordinates 的卡片，直接讀取
  const markersData = useMemo(() => {
    return cards
      .filter(card => {
        if (!card.coordinates) return false;
        try {
          const coords = JSON.parse(card.coordinates);
          return coords.lat && coords.lng;
        } catch {
          return false;
        }
      })
      .map(card => {
        const coords = JSON.parse(card.coordinates);
        return {
          card,
          lat: coords.lat,
          lng: coords.lng
        };
      });
  }, [cards]);

  // 使用 ref 保持最新的回調函數，避免 MarkerClusterGroup 緩存舊的 handler
  const onCardClickRef = useRef(onCardClick);
  const onCardHoverRef = useRef(onCardHover);
  const onContextMenuRef = useRef(onContextMenu);
  onCardClickRef.current = onCardClick;
  onCardHoverRef.current = onCardHover;
  onContextMenuRef.current = onContextMenu;

  // 記錄上次點擊的卡片 ID，用於判斷是否點擊同一張卡片
  const lastClickedCardIdRef = useRef(null);

  // 處理標記點擊
  const handleMarkerClick = useCallback((markerData) => {
    const cardId = markerData.card.id;
    const isSameCard = lastClickedCardIdRef.current === cardId;

    if (isMobileView) {
      // 手機版：打開彈窗
      setTargetMarkerPosition([markerData.lat, markerData.lng]);
      setPanTriggerKey(k => k + 1);
      useDialogStore.getState().open('cardPreview', {
        card: markerData.card,
        cardType,
        theme,
        currentMemberID,
        canRate,
        onFieldChange,
        onReviewChange,
        onBubbleClick,
        onAvatarClick,
        onCloseExtra: () => {
          setTargetMarkerPosition(null);
        },
      } as CardPreviewDialogData);
    } else {
      // 桌面版：使用 info panel
      if (isSameCard && isInfoPanelOpen) {
        // 點擊同一張卡片且 infoPanel 已開啟，關閉 infoPanel
        onCardClickRef.current?.(null); // 傳 null 表示關閉
        lastClickedCardIdRef.current = null;
      } else {
        // 點擊不同卡片或 infoPanel 未開啟
        setTargetMarkerPosition([markerData.lat, markerData.lng]);
        setPanTriggerKey(k => k + 1);
        onCardHoverRef.current?.(markerData.card);
        onCardClickRef.current?.(markerData.card);
        lastClickedCardIdRef.current = cardId;
      }
    }
  }, [isMobileView, isInfoPanelOpen]);

  // 預設中心點（台灣）
  const defaultCenter: [number, number] = [25.0330, 121.5654];
  const defaultZoom = 12;

  return (
    <div className="card-gallery-map-container">
      {/* 無標記提示 */}
      {markersData.length === 0 && (
        <div className="card-gallery-map-empty">
          <p>{t('noLocationData')}</p>
        </div>
      )}

      {/* 地圖 */}
      <MapContainer
        center={defaultCenter}
        zoom={defaultZoom}
        className="card-gallery-map"
        scrollWheelZoom={true}
      >
        {/* 使用 CartoDB Voyager 彩色簡潔風格底圖 */}
        <TileLayer
          attribution='&copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        />

        {markersData.length > 0 && <FitBounds markers={markersData} />}

        {/* 即時監聽容器大小變化，重新計算地圖大小，並在 resize 期間持續平移 */}
        <MapResizeHandler targetPosition={targetMarkerPosition} isMobileView={isMobileView} />

        {/* 點擊標記時平移地圖 */}
        <MapPanController
          targetPosition={targetMarkerPosition}
          triggerKey={panTriggerKey}
          isMobileView={isMobileView}
        />

        {/* 使用標記聚合群組 */}
        <MarkerClusterGroup
          chunkedLoading
          iconCreateFunction={createClusterCustomIcon}
          maxClusterRadius={50}
          spiderfyOnMaxZoom={true}
          showCoverageOnHover={false}
          zoomToBoundsOnClick={true}
          disableClusteringAtZoom={18}
        >
          {markersData.map((marker, index) => {
            // 取得卡片圖片
            const imageUrl = imageFieldName ? marker.card.cardFields?.[imageFieldName] : null;

            return (
              <Marker
                key={marker.card.id || index}
                position={[marker.lat, marker.lng]}
                icon={createSquareMarkerIcon(imageUrl, false)}
                {...({
                  imageUrl, eventHandlers: {
                    click: () => handleMarkerClick(marker),
                    mouseover: () => {
                      if (!isMobileView && lastHoveredCardIdRef.current !== marker.card.id) {
                        lastHoveredCardIdRef.current = marker.card.id;
                        onCardHoverRef.current?.(marker.card);
                      }
                    },
                    contextmenu: (e) => {
                      e.originalEvent.preventDefault();
                      onContextMenuRef.current?.(e.originalEvent, marker.card);
                    }
                  }
                } as any)}
              />
            );
          })}
        </MarkerClusterGroup>
      </MapContainer>


    </div>
  );
}

export default CardGalleryMapView;
