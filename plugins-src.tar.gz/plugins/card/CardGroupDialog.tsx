import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDialogStore } from '../../../Store/dialogStore';
import { useCardsStore } from './cardStore';
import NameInputDialog from '../../common/NameInputDialog';

const CardGroupDialog: React.FC = () => {
    const { t } = useTranslation();
    const showDialog = useDialogStore(state => state.dialogs['addFolder']?.show);
    const dialogData = useDialogStore(state => state.dialogs['addFolder']?.data);

    if (!showDialog || dialogData?.mode !== 'cardGroup') return null;

    const editFolder = dialogData?.folder;
    const isEdit = !!editFolder?.isGroup;

    const handleClose = () => useDialogStore.getState().close('addFolder');

    const handleConfirm = async (groupName: string) => {
        if (isEdit && editFolder) {
            await useCardsStore.getState().updateCardFolder({ ...editFolder, name: groupName });
        }
    };

    return (
        <NameInputDialog
            title={t('editGroup')}
            initialName={editFolder?.name || ''}
            placeholder={t('groupNamePlaceholder')}
            onConfirm={handleConfirm}
            onClose={handleClose}
        />
    );
};

export default CardGroupDialog;
