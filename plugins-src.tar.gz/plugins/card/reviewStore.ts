import { useItemStore } from '../../../Store/itemStore';

export interface Review {
  id: string;
  name: string;
  parentID: string;
  rating: number;
  comment: string;
  createdAt: string;
  updatedAt: string;
  itemType: 'REVIEW';
}

/** 產生確定性 REVIEW ID */
export function reviewId(cardId: string, memberId: string): string {
  return `review_${cardId}_${memberId}`;
}

/** 取得某卡片的所有 REVIEW items */
export function getReviewsByCardId(cardId: string): Review[] {
  return (useItemStore.getState().getByType('REVIEW') as Review[])
    .filter(r => r.parentID === cardId);
}

/** 直接用確定性 ID 取得自己在某卡片的留言 */
export function getMyReview(cardId: string, memberId: string): Review | undefined {
  return useItemStore.getState().itemMap.get(reviewId(cardId, memberId)) as Review | undefined;
}

/** 建立或更新留言（upsert） */
export async function upsertReview(cardId: string, memberId: string, rating: number, comment: string) {
  const id = reviewId(cardId, memberId);
  const existing = useItemStore.getState().itemMap.get(id) as Review | undefined;
  const now = Date.now().toString();
  const review: Review = {
    id,
    name: '',
    parentID: cardId,
    rating,
    comment,
    createdAt: (existing as any)?.createdAt ?? now,
    updatedAt: now,
    itemType: 'REVIEW',
  };
  await useItemStore.getState().upsertItem(review as any, { needSync: true });
}

/** 刪除留言 */
export async function deleteReview(cardId: string, memberId: string) {
  await useItemStore.getState().removeItems([reviewId(cardId, memberId)], { needSync: true });
}

/** 計算卡片的平均評分與留言數 */
export function getCardRatingStats(cardId: string) {
  const reviews = getReviewsByCardId(cardId);
  const rated = reviews.filter(r => r.rating > 0);
  const avg = rated.length > 0
    ? rated.reduce((sum, r) => sum + r.rating, 0) / rated.length
    : 0;
  const commentCount = reviews.filter(r => r.comment?.trim().length > 0).length;
  return { avg, ratingCount: rated.length, commentCount };
}
