import React from 'react';
import { useTranslation } from 'react-i18next';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';
import { PopupMenu, PopupMenuItem } from '../../common/PopupMenu';

const CardContextMenu: React.FC = () => {
    const menu = useMenuStore(state => state.menus['sidebarCardFolder']);
    const { t } = useTranslation();
    if (!menu?.show) return null;

    const close = () => useMenuStore.getState().close('sidebarCardFolder');
    const folder = menu.data?.folder;
    const isGroup = menu.data?.isGroup;

    const handleEdit = () => {
        if (isGroup) {
            useDialogStore.getState().open('addFolder', { folder: { ...folder, isGroup: true }, mode: 'cardGroup' });
        } else {
            useDialogStore.getState().open('addTemplate', { mode: 'card', folder });
        }
        close();
    };
    const handleDelete = () => {
        const isFolderGroup = Array.isArray(folder?.children) && folder.children.length > 0;
        if (isFolderGroup) {
            useDialogStore.getState().open('sidebar:deleteGroup', {
                folder: { ...folder, name: folder?.name, isCardFolder: true }
            });
        } else {
            useDialogStore.getState().open('deleteFolder', {
                folder: { ...folder, name: folder?.name, isCardFolder: true }
            });
        }
        close();
    };
    const handleCreateIn = () => {
        useDialogStore.getState().open('addTemplate', { mode: 'card', targetGroup: folder });
        close();
    };

    return (
        <PopupMenu x={menu.position.x} y={menu.position.y} onClose={close}>
            {isGroup && (
                <PopupMenuItem onClick={handleCreateIn}>
                    {t('createCardStackIn', { name: folder?.name || '' })}
                </PopupMenuItem>
            )}
            <PopupMenuItem onClick={handleEdit}>
                {isGroup ? t('editCardStackGroupName') : t('editCardStack')}
            </PopupMenuItem>
            <PopupMenuItem onClick={handleDelete}>
                {isGroup ? t('deleteCardStackGroup') : t('deleteCardStack')}
            </PopupMenuItem>
        </PopupMenu>
    );
};

export default CardContextMenu;
