import { create } from 'zustand';
import { generateObjectID } from '../../../../../services/utils/objectIDUtil.mjs';

import syncService from '../../../utils/syncService';
import { getFirstTextFieldValue } from '../../../utils/cardFieldUtils';
import { BaseItem, itemType } from '../../../types/item';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useItemStore } from '../../../Store/itemStore';

// ===== CardGalleryViewMode Store =====
interface CardGalleryViewModeState {
    viewMode: 'grid' | 'list' | 'map';
    setViewMode: (mode: 'grid' | 'list' | 'map') => void;
}

export const useCardGalleryViewModeStore = create<CardGalleryViewModeState>((set) => ({
    viewMode: 'grid',
    setViewMode: (mode) => set({ viewMode: mode })
}));

// ===== Types =====

@itemType('CARD_FOLDER', '卡片畫廊')
export class CardType extends BaseItem {
  cardFieldsDef?: any[] = [];
  templateHtml?: string = '';
  templateCss?: string = '';
  uiPrompt?: string = '';
  templateHistory?: any[] = [];
  isPublic?: boolean = false;
  searchable?: boolean = false;
  allowContribute?: boolean = false;
}

@itemType('CARD', '知識卡片，欄位由 CARD_FOLDER 的 cardFieldsDef 定義')
export class Card extends BaseItem {
  cardFields?: Record<string, any> = {};
  reviews?: any = null;
}

interface GeocodeResult {
  lat: number;
  lng: number;
}

interface SharedCardTypeInfo {
  folder: CardType;
  sharerName: string;
  allowContribute: boolean;
}

function tryParse(v: unknown) {
  if (typeof v !== 'string') return v;
  try { return JSON.parse(v); } catch { return v; }
}

const getCardFolders = (): CardType[] =>
  (useItemStore.getState().getByType('CARD_FOLDER') as any[]).map(item => ({
    ...item,
    cardFieldsDef: tryParse(item.cardFieldsDef),
  }));

const getCards = (): Card[] =>
  (useItemStore.getState().getByType('CARD') as any[]).map(item => ({
    ...item,
    cardFields: tryParse(item.cardFields),
  }));

interface CardsState {
  // ===== Card Folders（已遷移至 useItemStore）=====
  loadCardFolders: () => Promise<void>;
  updateCardFolder: (data: any) => Promise<void>;
  addCardFolder: (data: any) => Promise<void>;
  deleteCardFolder: (folderIds: string | string[], needSync?: boolean) => Promise<void>;
  // ===== Cards（已遷移至 useItemStore）=====
  loadCards: () => Promise<void>;
  getCardById: (id: string) => Card | null;
  getCardsByParentId: (parentID: string) => Card[];
  searchCardsByName: (query: string) => Card[];
  addCard: (newCard: any, needSync?: boolean) => Promise<void>;
  updateCard: (updatedCard: any, needSync?: boolean) => Promise<void>;
  deleteCard: (cardOrId: any, needSync?: boolean) => Promise<void>;
}

interface SharedCardTypeState {
  sharedCardTypes: Map<string, SharedCardTypeInfo>;
  setSharedCardType: (parentID: string, folder: CardType, sharerName?: string, allowContribute?: boolean) => void;
  getSharedCardType: (parentID: string) => SharedCardTypeInfo | undefined;
  hasSharedCardType: (parentID: string) => boolean;
  clearSharedCardType: (parentID?: string) => void;
}

interface SharedCardsState {
  sharedCards: Map<string, Card[]>;
  setSharedCards: (parentID: string, cards: Card[]) => void;
  getSharedCards: (parentID: string) => Card[];
  hasSharedCards: (parentID: string) => boolean;
  clearSharedCards: (parentID?: string) => void;
  updateSharedCard: (parentID: string, updatedCard: Card) => void;
}

// ==================== Card 相關 Store ====================

// 卡片坐標編碼輔助函數
const geocodeCardAddress = async (card: any, cardType: any) => {
  // 找到第一個 LOCATION 類型的欄位
  let fields = cardType?.cardFieldsDef;
  if (typeof fields === 'string') {
    try { fields = JSON.parse(fields); } catch { fields = null; }
  }
  const locationField = Array.isArray(fields) ? fields.find(f => f.type === 'LOCATION') : null;
  if (!locationField) return null;

  const fieldName = locationField.name;
  const address = card.cardFields?.[fieldName];
  if (!address) return null;

  // 檢查是否已有坐標且地址未變更
  if (card.coordinates) {
    try {
      const existingCoords = JSON.parse(card.coordinates);
      if (existingCoords[fieldName] === address) {
        // 地址未變更，直接返回現有坐標
        return card.coordinates;
      }
    } catch (e) {
      // 解析失敗，繼續編碼
    }
  }

  // 呼叫 geocoding API
  try {
    if (window.electronAPI?.geocodeAddress) {
      const result = await window.electronAPI.geocodeAddress(address) as GeocodeResult | null;
      if (result && result.lat && result.lng) {
        const coordinates = {
          lat: result.lat,
          lng: result.lng,
          [fieldName]: address
        };

        return JSON.stringify(coordinates);
      }
    }
  } catch (error) {
    console.error('[Geocode] 編碼失敗:', address, error);
  }

  return null;
};

// 卡片 Store
export const useCardsStore = create<CardsState>((set, get) => ({
  // ===== Card Folders 狀態和方法 =====
  loadCardFolders: async () => {
    await useItemStore.getState().loadByType('CARD_FOLDER');
  },
  updateCardFolder: async (data: any, needSync = true) => {
    try {
      const existing = getCardFolders().find(f => f.id === data.id);
      const merged = { ...existing, ...data, itemType: 'CARD_FOLDER' };
      await useItemStore.getState().upsertItem(merged, { needSync });
    } catch (error) {
      console.error('Failed to update card folder:', error);
    }
  },
  addCardFolder: async (data: any, needSync = true) => {
    try {
      const now = Date.now();

      // 計算 orderAt：新資料夾排在同層最後面（比現有最大 orderAt 更大）
      let orderAt = data.orderAt;
      if (orderAt === undefined || orderAt === null) {
        const allFolders = getCardFolders();
        const parentID = data.parentID || null;
        const siblings = allFolders.filter((f: any) =>
          ((f.parentID || null) === parentID)
        );
        const getOrder = (f: any) => {
          const o = Number(f.orderAt) || 0;
          return o !== 0 ? o : (Number(f.createdAt) || 0);
        };
        const maxOrder = siblings.length > 0
          ? Math.max(...siblings.map(getOrder))
          : now;
        orderAt = maxOrder + 1000;
      }

      const folder = {
        ...data,
        id: data.id || generateObjectID(),
        itemType: 'CARD_FOLDER',
        createdAt: data.createdAt || now,
        updatedAt: data.updatedAt || now,
        orderAt,
      };
      await useItemStore.getState().upsertItem(folder, { needSync });
    } catch (error) {
      console.error('Failed to add card folder:', error);
    }
  },
  deleteCardFolder: async (folderIds, needSync = true) => {
    try {
      const ids = Array.isArray(folderIds) ? folderIds : [folderIds];
      if (ids.length === 0) return;

      const folders = getCardFolders();
      const cards = getCards();

      // 遞迴收集子資料夾
      const collectDescendantIds = (parentId: string): string[] => {
        const childIds: string[] = [];
        folders.filter(f => f.parentID === parentId).forEach(child => {
          childIds.push(child.id);
          childIds.push(...collectDescendantIds(child.id));
        });
        return childIds;
      };

      const foldersNeedDelete: string[] = [];
      ids.forEach(fid => {
        const allIds = [fid, ...collectDescendantIds(fid)];
        allIds.forEach(id => { if (!foldersNeedDelete.includes(id)) foldersNeedDelete.push(id); });
      });

      // 刪除資料夾下的卡片
      const affectedFolderIds = new Set(foldersNeedDelete);
      const cardsToDelete = cards.filter(c => affectedFolderIds.has(c.parentID as string));
      if (cardsToDelete.length > 0) {
        await get().deleteCard(cardsToDelete.map(c => c.id), needSync);
      }

      await useItemStore.getState().removeItems(foldersNeedDelete, { needSync });

      await get().loadCardFolders();
      await get().loadCards();
    } catch (error) {
      console.error('刪除卡片資料夾失敗:', error);
    }
  },
  // ===== Cards 狀態和方法 =====
  loadCards: async () => {
    await useItemStore.getState().loadByType('CARD');
  },
  getCardById: (id) => {
    return getCards().find(c => c.id === id) || null;
  },
  getCardsByParentId: (parentID) => {
    return getCards().filter(c => c.parentID === parentID);
  },
  searchCardsByName: (query) => {
    if (!query) return getCards();
    const lowerQuery = query.toLowerCase();
    return getCards().filter(c =>
      c.name && c.name.toLowerCase().includes(lowerQuery)
    );
  },
  addCard: async (newCard, needSync = true) => {
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const myMemberID = userData?.ID || '';

    // 若傳入陣列，批次新增卡片
    if (Array.isArray(newCard)) {
      try {
        const cardsWithNewCoords: string[] = [];
        const cardsWithMeta = await Promise.all(newCard.map(async c => {
          const cardFolder = getCardFolders().find(f => f.id === c.parentID) || useItemStore.getState().getById(c.parentID);

          // 判斷是否為協作建立：folder 有 _permissions 且我不是 owner
          const folderMyPerm = cardFolder?._permissions?.find((p: any) => p.user_id === myMemberID);
          const isCollaborativeCreate = cardFolder && folderMyPerm && folderMyPerm.permission !== 'owner';

          const cardMeta: any = {
            ...c,
            id: c.id || generateObjectID(),
            orderAt: c.orderAt || Date.now().toString()
          };

          // 協作建立時繼承 folder 的 _permissions
          if (isCollaborativeCreate && cardFolder._permissions) {
            cardMeta._permissions = cardFolder._permissions;
          }

          const coordinates = await geocodeCardAddress(cardMeta, cardFolder);
          if (coordinates && !c.coordinates) {
            cardsWithNewCoords.push(cardMeta.id);
            cardMeta.coordinates = coordinates;
          } else if (coordinates) {
            cardMeta.coordinates = coordinates;
          }
          return cardMeta;
        }));

        const cardsWithNewCoordsSet = new Set(cardsWithNewCoords);
        for (const c of cardsWithMeta) {
          const card = { ...c, itemType: 'CARD' as const };
          await useItemStore.getState().upsertItem(card, { needSync: needSync || cardsWithNewCoordsSet.has(c.id) });
        }
      } catch (error) {
        console.error('批次新增卡片錯誤：', error);
      }
      return;
    }

    try {
      const cardFolder = getCardFolders().find(f => f.id === newCard.parentID) || useItemStore.getState().getById(newCard.parentID);

      // 判斷是否為協作建立：folder 有 _permissions 且我不是 owner
      const folderMyPerm = cardFolder?._permissions?.find((p: any) => p.user_id === myMemberID);
      const isCollaborativeCreate = cardFolder && folderMyPerm && folderMyPerm.permission !== 'owner';

      const cardWithMeta: any = {
        ...newCard,
        id: newCard.id || generateObjectID(),
        orderAt: newCard.orderAt || Date.now().toString()
      };

      // 協作建立時繼承 folder 的 _permissions
      if (isCollaborativeCreate && cardFolder._permissions) {
        cardWithMeta._permissions = cardFolder._permissions;
      }

      const coordinates = await geocodeCardAddress(cardWithMeta, cardFolder);
      const hasNewCoordinates = coordinates && !newCard.coordinates;
      if (coordinates) {
        cardWithMeta.coordinates = coordinates;
      }

      const card = { ...cardWithMeta, itemType: 'CARD' as const };
      await useItemStore.getState().upsertItem(card, { needSync: needSync || hasNewCoordinates });
    } catch (error) {
      console.error('新增卡片錯誤：', error);
    }
  },
  updateCard: async (updatedCard, needSync = true) => {
    // 若傳入陣列，批次更新卡片
    if (Array.isArray(updatedCard)) {
      try {
        const cardsWithNewCoords: string[] = [];
        const cardsWithCoords = await Promise.all(updatedCard.map(async c => {
          const cardFolder = getCardFolders().find(f => f.id === c.parentID);
          const coordinates = await geocodeCardAddress(c, cardFolder);
          if (coordinates && coordinates !== c.coordinates) {
            cardsWithNewCoords.push(c.id);
            return { ...c, coordinates };
          }
          return c;
        }));

        // 如果有新編碼的坐標，即使 needSync=false 也要標記需要同步
        if (cardsWithNewCoords.length > 0) {
          const existingUpdateItemIds = JSON.parse(localStorage.getItem('updateItemIds') || '[]');
          cardsWithNewCoords.forEach(id => {
            if (!existingUpdateItemIds.includes(id)) {
              existingUpdateItemIds.push(id);
            }
          });
          localStorage.setItem('updateItemIds', JSON.stringify(existingUpdateItemIds));
        }

        for (const c of cardsWithCoords) {
          const card = { ...c, itemType: 'CARD' as const };
          await useItemStore.getState().upsertItem(card, { needSync });
        }
      } catch (error) {
        console.error('批次更新卡片錯誤：', error);
      }
      return;
    }

    try {
      const cardFolder = getCardFolders().find(f => f.id === updatedCard.parentID);
      const coordinates = await geocodeCardAddress(updatedCard, cardFolder);
      const hasNewCoordinates = coordinates && coordinates !== updatedCard.coordinates;
      const cardToUpdate = coordinates
        ? { ...updatedCard, coordinates }
        : updatedCard;

      const card = { ...cardToUpdate, itemType: 'CARD' as const };
      await useItemStore.getState().upsertItem(card, { needSync: needSync || hasNewCoordinates });
    } catch (error) {
      console.error('更新卡片錯誤：', error);
    }
  },
  deleteCard: async (cardOrId, needSync = true) => {
    try {
      const isCardObject = (item: any) => item && typeof item === 'object' && item.id;
      const firstItem = Array.isArray(cardOrId) ? cardOrId[0] : cardOrId;
      const ids = isCardObject(firstItem)
        ? (Array.isArray(cardOrId) ? cardOrId : [cardOrId]).map((c: any) => c.id)
        : (Array.isArray(cardOrId) ? cardOrId : [cardOrId]);
      await useItemStore.getState().removeItems(ids, { needSync });
    } catch (error) {
      console.error('刪除卡片錯誤：', error);
    }
  }
}));

// ==================== Shared Card 相關 Store（純內存快取，不同步 DB）====================

// 分享的卡片類型 Store（純內存快取，key 為 parentID，即 type=CARD 的 Folder ID）
export const useSharedCardTypeStore = create<SharedCardTypeState>((set, get) => ({
  // Map<parentID, { cardType, sharerName, allowContribute }>
  sharedCardTypes: new Map(),

  setSharedCardType: (parentID, folder, sharerName = '', allowContribute = false) => {
    set(state => {
      const newMap = new Map(state.sharedCardTypes);
      newMap.set(parentID, { folder, sharerName, allowContribute });
      return { sharedCardTypes: newMap };
    });
  },

  getSharedCardType: (parentID) => {
    return get().sharedCardTypes.get(parentID);
  },

  hasSharedCardType: (parentID) => {
    return get().sharedCardTypes.has(parentID);
  },

  clearSharedCardType: (parentID) => {
    if (parentID) {
      set(state => {
        const newMap = new Map(state.sharedCardTypes);
        newMap.delete(parentID);
        return { sharedCardTypes: newMap };
      });
    } else {
      set({ sharedCardTypes: new Map() });
    }
  }
}));

// 分享的卡片 Store（純內存快取，key 為 parentID，即 type=CARD 的 Folder ID）
export const useSharedCardsStore = create<SharedCardsState>((set, get) => ({
  // Map<parentID, Card[]>
  sharedCards: new Map(),

  setSharedCards: (parentID, cards) => {
    set(state => {
      const newMap = new Map(state.sharedCards);
      newMap.set(parentID, cards);
      return { sharedCards: newMap };
    });
  },

  getSharedCards: (parentID) => {
    return get().sharedCards.get(parentID) || [];
  },

  hasSharedCards: (parentID) => {
    return get().sharedCards.has(parentID);
  },

  clearSharedCards: (parentID) => {
    if (parentID) {
      set(state => {
        const newMap = new Map(state.sharedCards);
        newMap.delete(parentID);
        return { sharedCards: newMap };
      });
    } else {
      set({ sharedCards: new Map() });
    }
  },

  updateSharedCard: (parentID, updatedCard) => {
    set(state => {
      const newMap = new Map(state.sharedCards);
      const cards = newMap.get(parentID) || [];
      const index = cards.findIndex(c => c.id === updatedCard.id);

      if (index >= 0) {
        const existingCard = cards[index];
        const newCards = [...cards];
        let cardFields = updatedCard.cardFields || existingCard.cardFields;
        if (typeof cardFields === 'string') {
          try { cardFields = JSON.parse(cardFields); } catch { /* keep as-is */ }
        }
        let cardReviews = (updatedCard as any).reviews || (existingCard as any).reviews;
        if (typeof cardReviews === 'string') {
          try { cardReviews = JSON.parse(cardReviews); } catch { /* keep as-is */ }
        }
        const parsedCard = {
          ...existingCard,
          ...updatedCard,
          cardFields,
          reviews: cardReviews,
        };

        newCards[index] = parsedCard;
        newMap.set(parentID, newCards);
      }
      return { sharedCards: newMap };
    });
  }
}));

// ===== 公開分享模式 Store =====

interface PublicShareData {
  name: string;
  sharerName: string;
  folderId: string;
  allowContribute: boolean;
}

interface PublicShareState {
  publicShareData: PublicShareData | null;
  setPublicShareData: (data: PublicShareData | null) => void;
}

export const usePublicShareStore = create<PublicShareState>((set) => ({
  publicShareData: null,
  setPublicShareData: (data) => set({ publicShareData: data }),
}));

// ===== Card Auto-Completing Store =====
// 卡片自動補完狀態（全局狀態，避免切換頁面時丟失）
// 原本在 ai-commander/aiStore，搬到此處歸 card 自管

interface AutoCompletingCardsState {
  autoCompletingCardIds: Set<string>;
  addAutoCompletingCard: (cardId: string) => void;
  removeAutoCompletingCard: (cardId: string) => void;
  isAutoCompleting: (cardId: string) => boolean;
}

export const useAutoCompletingCardsStore = create<AutoCompletingCardsState>((set) => ({
  autoCompletingCardIds: new Set(),
  addAutoCompletingCard: (cardId) => set((state) => {
    const newSet = new Set(state.autoCompletingCardIds);
    newSet.add(cardId);
    return { autoCompletingCardIds: newSet };
  }),
  removeAutoCompletingCard: (cardId) => set((state) => {
    const newSet = new Set(state.autoCompletingCardIds);
    newSet.delete(cardId);
    return { autoCompletingCardIds: newSet };
  }),
  isAutoCompleting: (cardId) => {
    return false; // 類型提示用，實際使用 has()
  }
}));

// ===== Card Recognition Store =====
// 卡片圖片辨識進度狀態
// 原本在 ai-commander/aiStore，搬到此處歸 card 自管

interface CardRecognitionState {
  isRecognizing: boolean;
  progress: number;
  statusMessage: string;
  totalImages: number;
  currentIndex: number;
  successCount: number;
  failedCount: number;
  abortController: AbortController | null;
  startRecognition: (totalImages: number) => void;
  updateProgress: (progress: number, statusMessage: string, currentIndex: number) => void;
  incrementSuccess: () => void;
  incrementFailed: () => void;
  finishRecognition: () => void;
  abortRecognition: () => void;
  isAborted: () => boolean;
}

export const useCardRecognitionStore = create<CardRecognitionState>((set, get) => ({
  isRecognizing: false,
  progress: 0,
  statusMessage: '',
  totalImages: 0,
  currentIndex: 0,
  successCount: 0,
  failedCount: 0,
  abortController: null,
  startRecognition: (totalImages) => set({
    isRecognizing: true,
    progress: 0,
    statusMessage: '',
    totalImages,
    currentIndex: 0,
    successCount: 0,
    failedCount: 0,
    abortController: new AbortController()
  }),
  updateProgress: (progress, statusMessage, currentIndex) => set({
    progress,
    statusMessage,
    currentIndex
  }),
  incrementSuccess: () => set((state) => ({ successCount: state.successCount + 1 })),
  incrementFailed: () => set((state) => ({ failedCount: state.failedCount + 1 })),
  finishRecognition: () => set({
    isRecognizing: false,
    progress: 100,
    statusMessage: '',
    abortController: null
  }),
  abortRecognition: () => {
    const { abortController } = get();
    if (abortController) {
      abortController.abort();
    }
    set({
      isRecognizing: false,
      progress: 0,
      statusMessage: '',
      abortController: null
    });
  },
  isAborted: () => {
    const { abortController } = get();
    return abortController?.signal?.aborted ?? false;
  }
}));
