// Card plugin — AI functions
// Refactored to use callPrompt from promptClient instead of dedicated API endpoints.

import {
  callPrompt,
  callCustomBot,
  checkAndHandleCreditsError,
  getAILanguage,
  getBaseUrl,
} from '../../../../aiService/promptClient';
import { apiRequest } from '../../../../aiService/apiClient';

// ─── Helper: parse JSON from LLM response (strips markdown fences) ─────────

function parseJsonResponse(raw: string): any {
  let cleaned = raw.trim();
  const codeBlockMatch = cleaned.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlockMatch) {
    cleaned = codeBlockMatch[1].trim();
  }
  return JSON.parse(cleaned);
}

// ─── Exported AI functions ──────────────────────────────────────────────────

export const generateCardTemplate = async (name: any, fields: any, uiPrompt = '') => {
  try {
    const lang = getAILanguage();
    const fieldsStr = typeof fields === 'string' ? fields : JSON.stringify(fields, null, 2);

    const prompt = [
      `Generate an HTML/CSS card template for a card named '${name}' with the following fields:`,
      fieldsStr,
      uiPrompt ? `\nAdditional instructions: ${uiPrompt}` : '',
      '',
      'Return a JSON object with two keys: "templateHtml" (the HTML string) and "templateCss" (the CSS string).',
      'Return ONLY the JSON object, no markdown fences, no extra text.',
      `\nLanguage: ${lang}`,
    ].filter(Boolean).join('\n');

    const response = await callPrompt({
      action: 'card_generateCardTemplate',
      prompt,
      model: 'claude-sonnet-4-5',
      max_tokens: 4096,
    });

    const result = parseJsonResponse(response.content);

    return {
      templateHtml: result.templateHtml || '',
      templateCss: result.templateCss || '',
    };
  } catch (error: any) {
    console.error('生成卡片模板時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'cardTemplateGen');
    throw error;
  }
};

export const generateCardFields = async (name: any, currentFields: any[] = []) => {
  try {
    const lang = getAILanguage();
    const currentFieldsStr = currentFields.length > 0
      ? `Current fields: ${JSON.stringify(currentFields, null, 2)}`
      : 'No existing fields.';

    const prompt = [
      `Given a card template named '${name}', suggest appropriate fields.`,
      currentFieldsStr,
      '',
      'Return a JSON object with a "fields" key containing an array of field definitions.',
      'Return ONLY the JSON object, no markdown fences, no extra text.',
      `\nLanguage: ${lang}`,
    ].join('\n');

    const response = await callPrompt({
      action: 'card_generateCardFields',
      prompt,
      model: 'claude-sonnet-4-5',
    });

    const result = parseJsonResponse(response.content);

    return {
      cardFieldsDef: result.fields || [],
    };
  } catch (error: any) {
    console.error('自動生成欄位時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'autoFieldGen');
    throw error;
  }
};

export const adjustCardTemplate = async (currentHtml: string, currentCss: string, adjustInstruction: string, fields: any[] = []) => {
  try {
    const lang = getAILanguage();
    const fieldsStr = fields.length > 0
      ? `\nFields: ${JSON.stringify(fields, null, 2)}`
      : '';

    const prompt = [
      'Adjust the following card template according to the instruction below.',
      '',
      `Current HTML:\n${currentHtml}`,
      '',
      `Current CSS:\n${currentCss}`,
      fieldsStr,
      '',
      `Adjustment instruction: ${adjustInstruction}`,
      '',
      'Return a JSON object with two keys: "templateHtml" (the updated HTML string) and "templateCss" (the updated CSS string).',
      'Return ONLY the JSON object, no markdown fences, no extra text.',
      `\nLanguage: ${lang}`,
    ].filter(Boolean).join('\n');

    const response = await callPrompt({
      action: 'card_adjustCardTemplate',
      prompt,
      model: 'claude-sonnet-4-5',
      max_tokens: 4096,
    });

    const result = parseJsonResponse(response.content);

    return {
      templateHtml: result.templateHtml || '',
      templateCss: result.templateCss || '',
    };
  } catch (error: any) {
    console.error('調整卡片模板時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'cardTemplateAdjust');
    throw error;
  }
};

export const recognizeCardFromImage = async (imageBase64: string, name: any, fields: any) => {
  try {
    const lang = getAILanguage();
    const fieldsStr = typeof fields === 'string' ? fields : JSON.stringify(fields, null, 2);

    const prompt = [
      `Examine this image and extract the field values for a card named '${name}'.`,
      '',
      `Field definitions:\n${fieldsStr}`,
      '',
      'Return a JSON object where keys are field names and values are the extracted data from the image.',
      'Return ONLY the JSON object, no markdown fences, no extra text.',
      `\nLanguage: ${lang}`,
    ].join('\n');

    const response = await callPrompt({
      action: 'card_recognizeCardFromImage',
      prompt,
      model: 'gpt-4o',
      images: [`data:image/jpeg;base64,${imageBase64}`],
    });

    const result = parseJsonResponse(response.content);

    return result.cardFields || result.fields || result;
  } catch (error: any) {
    console.error('圖片辨識填入卡片欄位時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'imageToCardFields');
    throw error;
  }
};

// ─── autoCompleteCardFields ──────────────────────────────────────────────────
// 單卡自動補完：呼叫 Custom Bot 搜尋並填入空白欄位，回傳更新後的 cardFields。
// CardGallery 右鍵補完、AddCardDialog 手動補完、圖片辨識批量補完共用此函數。

export async function autoCompleteCardFields(params: {
  cardId: string;
  parentID: string;
  cardTypeName: string;
  currentFields: Record<string, string>;
  fieldDefinitions: any[];
}): Promise<Record<string, string>> {
  const cardData = {
    id: params.cardId,
    parentID: params.parentID,
    name: params.cardTypeName,
    cardFields: params.currentFields,
    fieldDefinitions: params.fieldDefinitions,
  };

  const systemPrompt = `你是知識卡片欄位補完助手。
根據卡片標題和已有欄位，搜尋網路補完空白欄位。

規則：
1. 已填寫的欄位保持不變
2. IMAGE 欄位搜尋圖片（用 web_search type=images），回傳 imageUrl
3. 空白欄位上網搜尋補全，找不到則留空字串
4. 回傳完整的 cardFields JSON，格式與輸入相同
5. 只回傳 JSON，不要其他文字`;

  const result = await callCustomBot({
    system_prompt: systemPrompt,
    message: JSON.stringify(cardData, null, 2),
    action: 'cardAutoComplete',
  });

  let jsonStr = result.content;
  const codeBlockMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlockMatch) jsonStr = codeBlockMatch[1].trim();
  const parsed = JSON.parse(jsonStr);
  return parsed.cardFields ?? parsed;
}

// ─── searchCardImage ────────────────────────────────────────────────────────
// This is a server-side search API call (Serper), NOT an LLM call.
// It must keep calling the dedicated endpoint since callPrompt cannot do search.

export const searchCardImage = async (query: string, excludeUrls: string[] = []) => {
  try {
    const url = `${getBaseUrl()}/cubelv/search_image`;

    const response = await apiRequest({
      url,
      body: {
        query,
        excludeUrls,
        locale: localStorage.getItem('i18nextLng') || 'zh-Hant',
      },
    });

    if (!response.ok) {
      console.error('API 錯誤回應:', response.data);
      throw new Error(`圖片搜索請求失敗: ${response.status}, body: ${response.data}`);
    }

    const data = response.data;
    return typeof data === 'string' ? JSON.parse(data) : data;
  } catch (error: any) {
    console.error('搜尋卡片圖片時發生錯誤:', error);
    console.error('錯誤堆疊:', error.stack);
    checkAndHandleCreditsError(error, false, 'searchCardImage');
    throw error;
  }
};
