// Card plugin — AI prompt templates
//
// These document the prompt semantics used by each card AI function.
// The prompts are now built inline within cardAI.ts (using callPrompt),
// but kept here as a reference for the expected behaviour.

export const CARD_PROMPTS = {
  generateCardTemplate: `Given a card type name and its field definitions, generate an HTML template and CSS that renders a visually appealing card.`,
  generateCardFields: `Given a card type name and optionally existing fields, suggest a set of appropriate fields for this card type.`,
  adjustCardTemplate: `Given the current HTML/CSS of a card template and an adjustment instruction, modify the template accordingly.`,
  recognizeCardFromImage: `Given a base64-encoded image, a card type name, and its field definitions, extract the field values from the image.`,
  searchCardImage: `Search for relevant images for a card based on a text query.`,
};
