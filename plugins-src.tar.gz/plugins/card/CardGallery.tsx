import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useTimeout, useInterval } from '../../../hooks/useTimeout';
import FlipMove from 'react-flip-move';
import './CardGallery.css';
import { useCommandManager } from '../../../Store/commandManager';
import { useListKeyboardNav } from '../../../hooks/useListKeyboardNav';
import './AddCardTemplateDialog.css'; // 復用 card-preview-container 樣式
import { useAutoCompletingCardsStore, useCardsStore, CardType, useCardGalleryViewModeStore } from './cardStore';
import { useItemStore } from '../../../Store/itemStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useMenuStore } from '../../../Store/menuStore';

import { useMembersInfoStore } from '../../../Store/MembersInfoStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import { useTempHintStore, useMobileSidebarStore, useCardInfoPanelStore } from '../../../Store/uiStore';

import { eventBus } from '../../../Store/eventBus';
import { useIsMobileView } from '../../../hooks/useWindowSize';

import { useTheme } from '../../setting/ThemeProvider';

import AddCardTemplateDialog from './AddCardTemplateDialog';
import CustomHint from '../../common/CustomHint';
import { PopupMenu, PopupMenuItem, PopupMenuDivider } from '../../common/PopupMenu';

import { CustomDialog } from '../../common/CustomDialog';
import CubeLVLogoDark from '../../../assets/CubeLV_logo_dark.png';
import CubeLVLogoLight from '../../../assets/CubeLV_logo_light.png';
import InfoIcon from '../../../assets/icon_info_24.svg?react';
import EditIcon from '../../../assets/icon_edit_24.svg?react';
import SearchIcon from '../../../assets/icon_search_24.svg?react';
import PlusIcon from '../../../assets/icon_plus_24.svg?react';
import MenuIcon from '../../../assets/icon_menu_24.svg?react';
import MoreIcon from '../../../assets/bk_icon_more_20_n.svg?react';
import DeleteIcon from '../../../assets/bk_icon_delete_fill_20_n.svg?react';
import MobileTopbar from '../../common/MobileTopbar';
import CardRenderer from '../../common/CardRenderer';
import LazyCard from './LazyCard';
import AvatarWithBubble from '../../common/AvatarWithBubble';
import { checkAndHandleCreditsError } from '../../../aiService/promptClient';
import { autoCompleteCardFields } from './ai/cardAI';
import syncService from '../../../utils/syncService';
import { getFirstTextFieldIndex } from '../../../utils/cardFieldUtils';
import EditHistoryPanel from './shareGallery/EditHistoryPanel';
import { ShareMemberThumbnailList } from '../../common/share/ShareMemberThumbnailList';

import { updateItemShareSettings, generateShareUrl, getEditHistory, getMembersInfo, getItemCreators } from '../../../utils/shareAPI';
import ShareIcon from '../../../assets/icon_share_setting_24.svg?react';
import FileDownIcon from '../../../assets/icon_lucide_file_down_24.svg?react';
import GroupIcon from '../../../assets/icon_folder_group_outline_24.svg?react';
import HistoryIcon from '../../../assets/icon_history_outline_24.svg?react';
import CopyIcon from '../../../assets/icon_copy_16.svg?react';
import MapIcon from '../../../assets/icon_map_24.svg?react';
import ListIcon from '../../../assets/icon_list_24.svg?react';
import GridIcon from '../../../assets/icon_grid_24.svg?react';
import CardListView from './CardListView';
import { importFavorite } from '../../../utils/importFavorite';
import { Permission, getMyPermission } from '../../../utils/permissionLevel';
import CardGalleryMapView from './CardGalleryMapView';
import { ReviewsListDialog } from './ReviewsListDialog';
import { upsertReview, deleteReview, getMyReview, getCardRatingStats, getReviewsByCardId } from './reviewStore';

import type { BaseItem } from '../../../types/item';

/**
 * CardGallery 組件
 * 當用戶點擊卡片資料夾時，取代 NoteList 和 NoteEditor 顯示
 * 以網格方式展示所有卡片
 */
function CardGallery({ onFavorite = null }) {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobileView = useIsMobileView();

  // 安全定時器 hooks - 自動清理防止內存洩漏
  const { setTimeout: safeSetTimeout } = useTimeout();
  const setIsMobileSidebarOpen = useMobileSidebarStore(state => state.setIsMobileSidebarOpen);
  const rawCards = useItemStore(s => s.byType['CARD'] ?? []);
  const cards = useMemo(() => rawCards.map((item: any) => {
    let cf = item.cardFields;
    if (typeof cf === 'string') { try { cf = JSON.parse(cf); } catch {} }
    return cf !== item.cardFields ? { ...item, cardFields: cf } : item;
  }), [rawCards]);
  const cardFoldersRaw = useItemStore(s => s.byType['CARD_FOLDER'] ?? []);
  const updateCard = useCardsStore(state => state.updateCard);
  const deleteCard = useCardsStore(state => state.deleteCard);

  // 獲取當前用戶資訊（從 userData_local 讀取）
  const currentUserInfo = useMemo(() => {
    try {
      const userData = localStorage.getItem('userData_local');
      if (userData) {
        const parsed = JSON.parse(userData);
        const photoUrl = parsed?.photoUrl || null;
        return {
          memberID: parsed?.ID || null,
          name: parsed?.name || null,
          photo: photoUrl,
          thumbnail: parsed?.thumbnailUrl || photoUrl,
          profiling: parsed?.profiling || ''
        };
      }
    } catch (e) {
      console.error('Failed to parse userData_local:', e);
    }
    return { memberID: null, name: null, photo: null, thumbnail: null };
  }, []);

  const currentMemberID = currentUserInfo.memberID;

  // 判斷是否已登入（Guest 虛擬帳號視為未登入）
  const isLoggedIn = !!currentMemberID && localStorage.getItem('isGuest') !== 'true';

  // 初始化：將當前用戶資訊加入全局 Store
  const setMemberInfo = useMembersInfoStore(state => state.setMemberInfo);

  // EventBus: 卡片拖到 AICommander 的 drop handler
  useEffect(() => {
    const unsub = eventBus.on('drop:ai-commander:card', (e: any, addAttachment: any, attachedItems: any, inputAreaRef: any) => {
      // 多卡片
      const cardsData = e.dataTransfer.getData('application/cubelv-cards');
      if (cardsData) {
        try {
          const cards = JSON.parse(cardsData);
          let addedCount = 0;
          cards.forEach((card: any) => {
            if (!attachedItems.some((item: any) => item.id === card.id && item.type === 'card')) {
              addAttachment(card);
              addedCount++;
            }
          });
          if (addedCount > 0 && inputAreaRef.current?.closeSaveMode) {
            inputAreaRef.current.closeSaveMode();
          }
        } catch (error) { console.error('解析多卡片資料失敗:', error); }
        return;
      }
      // 單卡片
      const cardData = e.dataTransfer.getData('application/cubelv-card');
      if (cardData) {
        try {
          const card = JSON.parse(cardData);
          if (!attachedItems.some((item: any) => item.id === card.id && item.type === 'card')) {
            addAttachment(card);
            if (inputAreaRef.current?.closeSaveMode) inputAreaRef.current.closeSaveMode();
          }
        } catch (error) { console.error('解析卡片資料失敗:', error); }
      }
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (currentUserInfo.memberID) {

      setMemberInfo(currentUserInfo.memberID, {
        memberID: currentUserInfo.memberID,
        name: currentUserInfo.name,
        photo: currentUserInfo.photo,
        thumbnail: currentUserInfo.thumbnail,
        profiling: currentUserInfo.profiling
      });
    }
  }, [currentUserInfo.memberID, currentUserInfo.name, currentUserInfo.photo, currentUserInfo.thumbnail, currentUserInfo.profiling, setMemberInfo]);

  // 分享畫廊資料透過 sync/itemStore 推送，不需本地 shared store

  const setTempHint = useTempHintStore(state => state.setTempHint);
  const path = useSelectedItemsStore(state => state.path);
  const extraItems = useSelectedItemsStore(state => state.extraItems);
  const allSelected = useMemo(() => [path.at(-1), ...extraItems].filter(Boolean) as any[], [path, extraItems]);
  const setSelectedItems = useSelectedItemsStore(state => state.setSelectedItems);
  const selectedCardId = allSelected.find(i => i.itemType === 'CARD')?.id ?? null;
  const setSelectedCardId = (id: string | null) => {
    if (!id) {
      setSelectedItems([]);
      return;
    }
    const card = useItemStore.getState().getByType('CARD').find((c: any) => c.id === id);
    if (card) setSelectedItems([card]);
  };
  const isCardInfoPanelOpen = useCardInfoPanelStore(state => state.isCardInfoPanelOpen);
  const setIsCardInfoPanelOpen = useCardInfoPanelStore(state => state.setIsCardInfoPanelOpen);

  // 刪除卡片疊對話框


  const [showEditHistoryPanel, setShowEditHistoryPanel] = useState(false);
  const [mobileMenuPosition, setMobileMenuPosition] = useState(null); // 手機版選單位置


  const showMoreMenu = useMenuStore(state => state.menus['cardGalleryMore']?.show);
  const moreMenuPosition = useMenuStore(state => state.menus['cardGalleryMore']?.position) || { x: 0, y: 0 };
  const viewMode = useCardGalleryViewModeStore(state => state.viewMode); // 視圖模式：'grid' | 'list' | 'map'（全局狀態）
  const setViewMode = useCardGalleryViewModeStore(state => state.setViewMode);
  const [hoveredCard, setHoveredCard] = useState(null); // hover 中的卡片（用於列表視圖預覽）
  const [exportLoading, setExportLoading] = useState(false); // 匯出 CSV 中

  // 圖片拖曳相關狀態
  const [isImageDragOver, setIsImageDragOver] = useState(false);
  const [isDraggingImageOver, setIsDraggingImageOver] = useState(false);

  const dragCounterRef = useRef(0); // 用於追蹤拖曳進入/離開次數

  // FlipMove leaveAnimation 必須 useMemo 固定參考，否則每次 render 新物件會觸發 componentWillReceiveProps → setState → 無限重渲染
  const flipMoveLeaveAnimation = useMemo(() => ({
    from: { opacity: '1' },
    to: { opacity: '0' }
  }), []);

  // 搜尋狀態
  const [searchQuery, setSearchQuery] = useState('');
  const [searchInputValue, setSearchInputValue] = useState(''); // 輸入框即時值
  const searchInputRef = useRef(null);
  const mobileSearchInputRef = useRef(null); // 手機版搜尋輸入框
  const prevSearchQueryRef = useRef('');
  const isSearchComposingRef = useRef(false); // 中文組字狀態
  const [flipMoveKey, setFlipMoveKey] = useState(0);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false); // 手機版搜尋欄展開狀態

  // 拖曳排序狀態
  const [draggedCardId, setDraggedCardId] = useState(null);
  const [orderedCardIds, setOrderedCardIds] = useState([]); // 即時排序的卡片 ID 列表
  const [isDragging, setIsDragging] = useState(false);
  const [canDrag, setCanDrag] = useState(false); // 長按後才能拖曳
  const isDraggingRef = useRef(false);
  const longPressTimerRef = useRef(null);
  const longPressCardIdRef = useRef(null);
  const touchLongPressTimerRef = useRef(null); // mobile 長按觸發右鍵選單
  const touchStartPosRef = useRef(null); // 記錄觸摸起始位置
  const contentRef = useRef(null); // 滾動容器 ref（用於切換時重置滾動位置）

  // 右鍵選單狀態
  const [contextMenu, setContextMenu] = useState({
    visible: false,
    x: 0,
    y: 0,
    card: null,
    fieldName: null,
    fieldValue: null
  });

  // 自動補完狀態（使用全局 store，避免切換頁面時丟失）
  const autoCompletingCardIds = useAutoCompletingCardsStore(state => state.autoCompletingCardIds);
  const addAutoCompletingCard = useAutoCompletingCardsStore(state => state.addAutoCompletingCard);
  const removeAutoCompletingCard = useAutoCompletingCardsStore(state => state.removeAutoCompletingCard);

  // 多選狀態
  const [selectedCardIds, setSelectedCardIds] = useState([]);
  const [isShiftPressed, setIsShiftPressed] = useState(false);
  const [isCommandPressed, setIsCommandPressed] = useState(false);

  // 獲取卡片類型（從 folders 篩選 type === 'CARD'）
  const cardTypes = useItemStore(s => s.byType['CARD_FOLDER'] ?? []);
  const updateCardFolder = useCardsStore(state => state.updateCardFolder);

  // cardFolders 與 cardTypes 相同（都是 state.cardFolders）
  const cardFolders = cardTypes;

  // 統一使用 store 的 selectedFolderId
  const selectedFolderId = useSelectedItemsStore(state => state.selectedFolderId);

  useEffect(() => {
    const folderCardsInFolder = selectedFolderId ? cards.filter((c: any) => c.parentID === selectedFolderId) : [];
    const folder = cardFoldersRaw.find((f: any) => f.id === selectedFolderId);
    const c = folderCardsInFolder[0] as any;
    console.log('[RELOAD] CardGallery render:', {
      selectedFolderId,
      folderFound: !!folder,
      folderName: (folder as any)?.name,
      cardFieldsDefType: folder ? typeof (folder as any).cardFieldsDef : 'N/A',
      totalCards: cards.length,
      folderCardsLen: folderCardsInFolder.length,
      firstCard: c ? { id: c.id, name: c.name, cardFieldsType: typeof c.cardFields, cardFields: c.cardFields, image: c.image } : null,
    });
  }, [selectedFolderId, cards, cardFoldersRaw]);

  // 從 folders 取得當前選中的 cardFolder（selectedFolderId 即 folder id）
  const selectedCardFolder = useMemo(() => {
    if (!selectedFolderId) return null;
    return (cardFolders.find(f => f.id === selectedFolderId) || null) as CardType | null;
  }, [selectedFolderId, cardFolders]);

  const cardType = useMemo(() => {
    if (!selectedCardFolder?.id) return null;
    return (cardTypes.find(ct => ct.id === selectedCardFolder.id) || null) as CardType | null;
  }, [selectedCardFolder?.id, cardTypes]);

  const sharerName = (cardType as any)?.sharerName || '';

  // ===== 權限（純數字比對）=====
  const myPermission = getMyPermission(cardType);

  // cardType.cardFieldsDef 可能是 JSON 字串（從 SQLite 讀出），統一解析為陣列
  const cardTypeFields = useMemo(() => {
    if (!cardType) return [];
    const raw = (cardType as any).cardFieldsDef;
    if (typeof raw === 'string') {
      try { return JSON.parse(raw); } catch { return []; }
    }
    return raw || [];
  }, [cardType]);

  const canReorderCards = myPermission >= Permission.editor;
  const canReview = myPermission >= Permission.contributor;
  const canDeleteOthersReview = myPermission >= Permission.editor;

  const allReviewItems = useItemStore(s => s.byType['REVIEW'] ?? []);

  // 獲取當前卡片類型的所有卡片（使用 orderAt 排序）
  const baseCards = useMemo(() => {
    if (!cardType?.id) return [];

    // 統一排序函數：orderAt 優先，fallback 到 createdAt
    const getOrderValue = (card) => {
      const orderAt = card.orderAt;
      if (orderAt && !isNaN(parseFloat(orderAt))) {
        return parseFloat(orderAt);
      }
      // fallback 到 createdAt
      const createdAt = card.createdAt;
      return parseFloat(createdAt) || 0;
    };

    const sortByOrderAt = (a, b) => {
      const aOrder = getOrderValue(a);
      const bOrder = getOrderValue(b);
      if (bOrder !== aOrder) {
        return bOrder - aOrder;  // 值越大越靠前
      }
      // orderAt 相同時，用 createdAt 作為次要排序（新的在前）
      const aCreated = parseFloat(a.createdAt) || 0;
      const bCreated = parseFloat(b.createdAt) || 0;
      return bCreated - aCreated;
    };

    const typeCards = cards.filter(card => card.parentID === cardType.id);
    const sorted = typeCards.sort(sortByOrderAt);
    return sorted;
  }, [cards, cardType?.id]);

  // 當 baseCards 變化時，更新 orderedCardIds（非拖曳狀態下）
  useEffect(() => {
    if (!isDraggingRef.current) {
      setOrderedCardIds(baseCards.map(c => c.id));
    }
  }, [baseCards]);

  // 批次查詢 card 創建者（從 sync_changes 取得 actor_id）
  const [creatorsMap, setCreatorsMap] = useState<Record<string, { memberId: string; createdAt: number }>>({});
  useEffect(() => {
    if (baseCards.length === 0) return;
    const cardIds = baseCards.map(c => c.id);
    getItemCreators(cardIds).then(setCreatorsMap).catch(() => {});
  }, [baseCards]);

  const hasMultipleContributors = useMemo(() => {
    const creatorIds = new Set(
      baseCards.map(c => creatorsMap[c.id]?.memberId).filter(Boolean)
    );
    return creatorIds.size > 1;
  }, [baseCards, creatorsMap]);

  const contributorsRanking = useMemo(() => {
    if (baseCards.length === 0) return [];

    const contributionCount: Record<string, number> = {};
    baseCards.forEach(card => {
      const creatorId = creatorsMap[card.id]?.memberId;
      if (creatorId) {
        contributionCount[creatorId] = (contributionCount[creatorId] || 0) + 1;
      }
    });

    return Object.entries(contributionCount)
      .filter(([memberId]) => !!memberId)
      .map(([memberId, count]) => ({
        memberID: memberId,
        count
      }))
      .sort((a, b) => b.count - a.count);
  }, [baseCards, creatorsMap]);

  // 訂閱 Store 的 membersInfoMap，用於 contributors avatar 的實時更新
  const membersInfoMap = useMembersInfoStore(state => state.membersInfoMap);
  const fetchMemberInfo = useCallback((memberIds) => {
    const storeState = useMembersInfoStore.getState();
    storeState.fetchMembersInfo(memberIds, getMembersInfo);
  }, []);

  // 當貢獻者排名計算出來時，預先 fetch 成員資訊
  useEffect(() => {
    if (contributorsRanking.length === 0) return;

    const memberIds = contributorsRanking.map(c => c.memberID).filter(Boolean);
    if (memberIds.length === 0) return;

    // 使用 Store 的 fetchMembersInfo 方法
    const storeState = useMembersInfoStore.getState();
    storeState.fetchMembersInfo(memberIds, getMembersInfo);

  }, [contributorsRanking]);

  const handleOpenCardShowDialog = useCallback((cardId) => {
    if (!cardId) return;
    const target = baseCards.find(card => card.id === cardId);
    if (!target) return;
    useDialogStore.getState().open('cardPreview', {
      card: target,
      cardType,
      theme,
      currentMemberID,
      canRate: myPermission >= Permission.contributor,
      canEditThisCard: myPermission >= Permission.contributor,
      isLoggedIn,
      onRequestLogin: handleGoToLogin,
      onRequestPermission: () => setTempHint(t('permissionRequired')),
    });
  }, [baseCards, cardType, theme, currentMemberID, myPermission, isLoggedIn]);

  const handleOpenContributorsDialog = useCallback(() => {
    if (!cardType?.id) return;
    useDialogStore.getState().open('contributors', { itemId: cardType.id });
  }, [cardType?.id]);

  // requestEditPermission 已移除，Phase 9 通知系統上線後再啟用

  const openEditTemplateDialog = useCallback(() => {
    useDialogStore.getState().open('editTemplate', {
      cardType,
      myPermission,
    });
  }, [cardType, myPermission]);

  const openGalleryShareSettings = useCallback(() => {
    useDialogStore.getState().open('sharing', {
      item: { id: cardType?.id, name: selectedCardFolder?.name || (cardType as any)?.name || '', isPublic: cardType?.isPublic, itemType: 'CARD_FOLDER' },
      linkPermissionOptions: [
        { value: 'viewer', label: t('permissionViewer'), description: t('anyoneWithLinkDesc') },
        { value: 'contributor', label: t('permissionContributor'), description: t('anyoneWithLinkContributeDesc') },
      ],
      currentLinkPermission: (cardType as any)?.allowContribute ? 'contributor' : 'viewer',
      onSave: async (settings) => {
        try {
          await updateItemShareSettings({ ...settings, extra: { allowContribute: settings.linkPermission === 'contributor' } });
          await syncService.syncChanges();
          if (settings.isPublic) {
            const shareUrl = generateShareUrl(settings.folderId);
            await navigator.clipboard.writeText(shareUrl);
            setTempHint(t('shareLinkCopied'));
          } else {
            setTempHint(t('shareDisabled'));
          }
          useDialogStore.getState().close('sharing');
        } catch (error) {
          console.error('更新分享設定失敗:', error);
          setTempHint(t('shareUpdateFailed'));
        }
      },
    });
  }, [cardType, selectedCardFolder, setTempHint, t]);

  useEffect(() => {
    const cm = useCommandManager.getState();

    const unsubShift = cm.registerKeyObserver({
      id: 'card-gallery:shift',
      keys: ['Shift'],
      onDown: () => setIsShiftPressed(true),
      onUp: () => setIsShiftPressed(false),
    });
    const unsubMeta = cm.registerKeyObserver({
      id: 'card-gallery:meta',
      keys: ['Meta', 'Control'],
      onDown: () => setIsCommandPressed(true),
      onUp: () => setIsCommandPressed(false),
    });

    // 當窗口失去焦點時重置按鍵狀態
    const handleWindowBlur = () => {
      setIsShiftPressed(false);
      setIsCommandPressed(false);
    };
    window.addEventListener('blur', handleWindowBlur);

    return () => {
      unsubShift();
      unsubMeta();
      window.removeEventListener('blur', handleWindowBlur);
    };
  }, []);

  // 當 selectedFolderId 改變時，清除多選、重置排序、重置篩選 tag、重置滾動位置、並重置 FlipMove
  // 注意：viewMode 為全局狀態，不在此重置
  useEffect(() => {
    setSelectedCardIds([]);
    setSortMode('none'); // 重置排序狀態
    setSelectedTags([]); // 重置篩選 tag 狀態
    setFlipMoveKey(k => k + 1); // 強制重建 FlipMove，避免事件監聯器混亂
    // 重置滾動位置到頂部
    if (contentRef.current) {
      contentRef.current.scrollTop = 0;
    }
  }, [selectedFolderId]);

  // 手機版搜尋欄打開時自動聚焦
  useEffect(() => {
    if (isMobileSearchOpen && mobileSearchInputRef.current) {
      mobileSearchInputRef.current.focus();
    }
  }, [isMobileSearchOpen]);



  // 當搜尋框從有內容變成空時，重置 FlipMove 動畫狀態
  useEffect(() => {
    const prevHadQuery = prevSearchQueryRef.current.trim().length > 0;
    const currentHasQuery = searchQuery.trim().length > 0;

    if (prevHadQuery && !currentHasQuery) {
      // 從有搜尋變成空，重置 FlipMove
      setFlipMoveKey(k => k + 1);
    }

    prevSearchQueryRef.current = searchQuery;
  }, [searchQuery]);

  // 根據 orderedCardIds 排序的卡片列表
  const sortedCards = useMemo(() => {
    if (orderedCardIds.length === 0) return baseCards;
    const cardMap = new Map(baseCards.map(c => [c.id, c]));
    return orderedCardIds.map(id => cardMap.get(id)).filter(Boolean);
  }, [baseCards, orderedCardIds]);

  // 選中的 tag（用於篩選）
  const [selectedTags, setSelectedTags] = useState([]); // 改成陣列支援多選
  const [hasTagsOverflow, setHasTagsOverflow] = useState(false); // 是否有溢出
  const tagsContainerRef = useRef(null); // Tags 容器 ref

  // 排序狀態
  const [sortMode, setSortMode] = useState('none'); // 排序模式
  const [showSortDropdown, setShowSortDropdown] = useState(false); // 排序下拉選單顯示狀態
  const [sortMenuPosition, setSortMenuPosition] = useState({ x: 0, y: 0 }); // 排序選單位置
  const sortDropdownRef = useRef(null); // 下拉選單 ref

  // 找出所有日期和評分欄位（用於排序）
  const dateFields = useMemo(() => {
    if (cardTypeFields.length === 0) return [];
    return cardTypeFields.filter(f => f.type === 'DATE').map(f => f.name);
  }, [cardTypeFields]);

  // 找出所有日期區間欄位（用於排序）
  const dateRangeFields = useMemo(() => {
    if (cardTypeFields.length === 0) return [];
    return cardTypeFields.filter(f => f.type === 'DATERANGE').map(f => f.name);
  }, [cardTypeFields]);

  const ratingFields = useMemo(() => {
    if (cardTypeFields.length === 0) return [];
    return cardTypeFields.filter(f => f.type === 'RATING').map(f => f.name);
  }, [cardTypeFields]);

  // 檢測是否有 LOCATION 欄位（用於地圖視圖）
  const locationFieldInfo = useMemo(() => {
    const locationField = cardTypeFields.find(field => field.type === 'LOCATION');
    return locationField ? {
      hasLocation: true,
      fieldName: locationField.name
    } : {
      hasLocation: false,
      fieldName: null
    };
  }, [cardTypeFields]);

  // 當該類別沒有地圖時，自動從 map 模式切換到 grid 模式
  useEffect(() => {
    if (viewMode === 'map' && !locationFieldInfo.hasLocation) {
      setViewMode('grid');
    }
  }, [locationFieldInfo.hasLocation, viewMode, setViewMode]);

  // 切換畫廊時清除 hover 的卡片
  useEffect(() => {
    setHoveredCard(null);
  }, [selectedFolderId]);

  // 實際是否顯示 info panel（用戶偏好 + 列表/地圖模式 + 非手機版）
  const shouldShowInfoPanel = isCardInfoPanelOpen && (viewMode === 'list' || viewMode === 'map') && !isMobileView;

  // 解析 sortMode（格式：type_direction_fieldName）
  // 例如：date_desc_到期日, daterange_forward_活動期間
  const parsedSortMode = useMemo(() => {
    if (sortMode === 'none') return { type: 'none', direction: null, fieldName: null };
    const parts = sortMode.split('_');
    if (parts.length < 3) return { type: 'none', direction: null, fieldName: null };

    const type = parts[0]; // date, daterange, rating
    const direction = parts[1]; // desc, asc, notexpired, expired, forward, backward
    const fieldName = parts.slice(2).join('_'); // 欄位名稱（可能包含底線）
    return { type, direction, fieldName };
  }, [sortMode]);

  // 根據搜尋條件和選中的 tag 篩選卡片
  const folderCards = useMemo(() => {
    let filtered = sortedCards;

    // 根據多個 tag 篩選（AND 邏輯）
    if (selectedTags.length > 0) {
      filtered = filtered.filter(card => {
        return selectedTags.every(tag => {
          const cardFieldData = card.cardFields;
          const value = cardFieldData?.[tag.fieldName];
          // 跳過空值、空陣列、或 "[]" 字串
          if (!value || (Array.isArray(value) && value.length === 0) || value === '[]') return false;
          // 支援 MULTISELECT（可能是陣列或逗號分隔字串，支援英文逗號、中文逗號、中文頓號）
          let options = Array.isArray(value) ? value.filter(Boolean) : (typeof value === 'string' ? value.split(/[,，、]/).map(s => s.trim()).filter(Boolean) : []);
          // 過濾掉無效的選項值
          options = options.filter(opt => opt && opt !== '[]' && opt.trim() !== '');
          return options.includes(tag.value);
        });
      });
    }

    // 再根據搜尋條件篩選
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(card => {
        // 搜尋卡片名稱
        const cardName = card.name;
        if (cardName?.toLowerCase().includes(query)) return true;

        // 搜尋卡片欄位內容
        const cardFieldData = card.cardFields;
        if (cardFieldData) {
          const fieldValues = Object.values(cardFieldData);
          for (const value of fieldValues) {
            if (typeof value === 'string' && value.toLowerCase().includes(query)) {
              return true;
            }
          }
        }

        return false;
      });
    }

    // 排序與篩選邏輯
    if (sortMode !== 'none' && parsedSortMode.type !== 'none') {
      const { type, direction, fieldName } = parsedSortMode;
      const now = Date.now();

      // 輔助函數：從日期區間取得指定部分的日期
      const getDateRangeValue = (card, field, datePart) => {
        const cardFieldData = card.cardFields;
        const value = cardFieldData?.[field];
        if (!value) return 0;
        // DATERANGE 格式可能是：
        // 1. 物件格式：{ start: "...", end: "..." }
        // 2. 用 | 分隔：start|end
        // 3. 用 ~ 分隔：start ~ end
        if (typeof value === 'object') {
          return value[datePart] ? new Date(value[datePart]).getTime() : 0;
        } else if (typeof value === 'string') {
          let start = '', end = '';
          if (value.includes(' ~ ')) {
            [start, end] = value.split(' ~ ').map(s => s.trim());
          } else if (value.includes('~')) {
            [start, end] = value.split('~').map(s => s.trim());
          } else if (value.includes('|')) {
            [start, end] = value.split('|').map(s => s.trim());
          } else {
            return 0;
          }
          return datePart === 'start'
            ? (start ? new Date(start).getTime() : 0)
            : (end ? new Date(end).getTime() : 0);
        }
        return 0;
      };

      // 「未到」和「已到」是篩選功能，先過濾再排序
      if (direction === 'notexpired' || direction === 'expired') {
        filtered = filtered.filter(card => {
          const cardFieldData = card.cardFields;
          let dateValue = 0;
          if (type === 'date') {
            dateValue = cardFieldData?.[fieldName] ? new Date(cardFieldData[fieldName]).getTime() : 0;
          } else if (type === 'daterange') {
            // DATERANGE 用開始時間判斷
            dateValue = getDateRangeValue(card, fieldName, 'start');
          }

          // 沒有日期值的卡片不顯示
          if (dateValue === 0) return false;

          const isExpired = dateValue < now;
          return direction === 'notexpired' ? !isExpired : isExpired;
        });

        // 篩選後按開始日期排序（近到遠）
        filtered = [...filtered].sort((a, b) => {
          const aFieldData = a.cardFields;
          const bFieldData = b.cardFields;
          let dateA = 0, dateB = 0;
          if (type === 'date') {
            dateA = aFieldData?.[fieldName] ? new Date(aFieldData[fieldName]).getTime() : 0;
            dateB = bFieldData?.[fieldName] ? new Date(bFieldData[fieldName]).getTime() : 0;
          } else if (type === 'daterange') {
            dateA = getDateRangeValue(a, fieldName, 'start');
            dateB = getDateRangeValue(b, fieldName, 'start');
          }
          return dateA - dateB; // 日期近到遠
        });
      } else if (type === 'daterange' && (direction === 'forward' || direction === 'backward')) {
        // DATERANGE 特殊排序：forward 用開始時間，backward 用結束時間
        filtered = [...filtered].sort((a, b) => {
          const datePart = direction === 'forward' ? 'start' : 'end';
          const dateA = getDateRangeValue(a, fieldName, datePart);
          const dateB = getDateRangeValue(b, fieldName, datePart);
          // forward: 前到後（舊到新），backward: 後到前（新到舊）
          return direction === 'forward' ? (dateA - dateB) : (dateB - dateA);
        });
      } else {
        // 其他排序選項（date 和 rating）
        filtered = [...filtered].sort((a, b) => {
          if (type === 'date') {
            const aFieldData = a.cardFields;
            const bFieldData = b.cardFields;
            const dateA = aFieldData?.[fieldName] ? new Date(aFieldData[fieldName]).getTime() : 0;
            const dateB = bFieldData?.[fieldName] ? new Date(bFieldData[fieldName]).getTime() : 0;

            if (direction === 'desc') {
              return dateB - dateA;
            } else if (direction === 'asc') {
              return dateA - dateB;
            }
          } else if (type === 'rating') {
            if (direction === 'desc') {
              const statsA = getCardRatingStats(a.id);
              const statsB = getCardRatingStats(b.id);
              return statsB.avg - statsA.avg;
            } else if (direction === 'reviewcount') {
              const statsA = getCardRatingStats(a.id);
              const statsB = getCardRatingStats(b.id);
              return statsB.commentCount - statsA.commentCount;
            }
          }
          return 0;
        });
      }
    }

    return filtered;
  }, [sortedCards, searchQuery, selectedTags, sortMode, parsedSortMode]);

  // 統計 SELECT/MULTISELECT 欄位的選項出現次數（基於篩選後的卡片）
  const tagStats = useMemo(() => {
    if (cardTypeFields.length === 0 || folderCards.length === 0) return [];

    // 找出所有 SELECT/MULTISELECT 欄位
    const selectFields = cardTypeFields.filter(f => f.type === 'SELECT' || f.type === 'MULTISELECT');
    if (selectFields.length === 0) return [];

    // 統計每個選項的出現次數
    const stats = new Map<string, { count: number; fieldName: string; value: string }>(); // key: fieldName-value, value: { count, fieldName, value }

    folderCards.forEach(card => {
      selectFields.forEach(field => {
        const cardFieldData = card.cardFields;
        const value = cardFieldData?.[field.name];
        // 跳過空值、空陣列、或 "[]" 字串
        if (!value || (Array.isArray(value) && value.length === 0) || value === '[]') return;

        // MULTISELECT 的值可能是陣列或逗號分隔的字串（支援英文逗號、中文逗號、中文頓號）
        let options;
        if (field.type === 'MULTISELECT') {
          options = Array.isArray(value) ? value.filter(Boolean) : (typeof value === 'string' ? value.split(/[,，、]/).map(s => s.trim()).filter(Boolean) : []);
        } else {
          options = [value];
        }

        // 過濾掉無效的選項值（空字串、"[]" 等）
        options = options.filter(opt => opt && opt !== '[]' && opt.trim() !== '');

        options.forEach(opt => {
          const key = `${field.name}-${opt}`;
          const existing = stats.get(key);
          if (existing) {
            existing.count++;
          } else {
            stats.set(key, { count: 1, fieldName: field.name, value: opt });
          }
        });
      });
    });

    // 轉成陣列，按欄位順序分組，組內按 options 定義順序排列
    const fieldOrder = new Map<string, number>(selectFields.map((f, i) => [f.name as string, i]));
    const optionOrderMap = new Map<string, Map<string, number>>(); // fieldName -> Map(optionValue -> index)
    selectFields.forEach(field => {
      if (field.options && Array.isArray(field.options)) {
        optionOrderMap.set(field.name, new Map(field.options.map((opt, i) => [opt, i])));
      }
    });

    return Array.from(stats.values())
      .sort((a, b) => {
        // 先按欄位順序
        const fieldDiff = (fieldOrder.get(a.fieldName) || 0) - (fieldOrder.get(b.fieldName) || 0);
        if (fieldDiff !== 0) return fieldDiff;
        // 同欄位內按 options 定義順序
        const optOrder = optionOrderMap.get(a.fieldName);
        if (optOrder) {
          return (optOrder.get(a.value) ?? 999) - (optOrder.get(b.value) ?? 999);
        }
        return 0;
      });
  }, [cardTypeFields, folderCards]);

  // 監聽圖片拖曳事件（從 NoteEditor 拖曳圖片時顯示遮罩）
  useEffect(() => {
    const handleShowImageDrag = () => {
      setIsImageDragOver(true);
    };

    const handleClearImageDrag = () => {
      setIsImageDragOver(false);
      setIsDraggingImageOver(false);
      dragCounterRef.current = 0;
    };

    document.addEventListener('showImageDrag', handleShowImageDrag);
    document.addEventListener('clearImageDrag', handleClearImageDrag);

    return () => {
      document.removeEventListener('showImageDrag', handleShowImageDrag);
      document.removeEventListener('clearImageDrag', handleClearImageDrag);
    };
  }, []);

  // 處理從外部拖曳文件的檢測
  const handleFileDragEnter = (e) => {
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      // 檢查是否為圖片文件
      const hasImageFile = Array.from(e.dataTransfer.items as DataTransferItemList).some((item: DataTransferItem) => {
        return item.kind === 'file' && item.type.startsWith('image');
      });

      if (hasImageFile) {
        dragCounterRef.current++;
        setIsImageDragOver(true);
      }
    }
  };

  const handleFileDragLeave = (e) => {
    dragCounterRef.current--;
    if (dragCounterRef.current === 0) {
      setIsImageDragOver(false);
    }
  };

  // 處理圖片拖放到畫廊
  const handleImageDropToGallery = async (e) => {
    e.preventDefault();
    e.stopPropagation();

    setIsImageDragOver(false);
    setIsDraggingImageOver(false);
    dragCounterRef.current = 0;

    // 從全局變數讀取圖片 URL
    const imageUrl = window.__draggingImageUrl;

    // 檢查是否是圖片 URL（http/https URL 或 base64）
    const isImageUrl = imageUrl && (
      imageUrl.startsWith('http://') ||
      imageUrl.startsWith('https://') ||
      imageUrl.startsWith('data:image')
    );

    // 也檢查是否有拖曳的檔案
    const files = Array.from(e.dataTransfer.files || [] as any) as File[];
    const imageFiles = files.filter((file: File) => file.type?.startsWith('image'));

    if (isImageUrl) {
      // 從 URL 創建圖片物件
      try {
        let base64Data = '';

        if (imageUrl.startsWith('data:image')) {
          // 已經是 base64
          base64Data = imageUrl.split(',')[1];
          const mimeMatch = imageUrl.match(/data:(image\/[^;]+);/);
          const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';

          const imageObj = {
            file: null,
            preview: imageUrl,
            base64: base64Data
          };

          // 如果 Dialog 已打開，追加圖片；否則替換
          const currentData = useDialogStore.getState().dialogs['addCard'];
          if (currentData?.show) {
            // dialog 已開啟，追加圖片
            useDialogStore.getState().open('addCard', {
              ...currentData.data,
              initialImages: [...(currentData.data?.initialImages || []), imageObj],
            });
          } else {
            useDialogStore.getState().open('addCard', {
              cardType, initialImages: [imageObj],
            });
          }
        } else {
          // 是 URL，需要下載
          const response = await window.electronAPI?.fetchImage?.(imageUrl);
          if (response?.base64) {
            const imageObj = {
              file: null,
              preview: imageUrl,
              base64: response.base64
            };

            // 如果 Dialog 已打開，追加圖片；否則替換
            const currentData2 = useDialogStore.getState().dialogs['addCard'];
            if (currentData2?.show) {
              useDialogStore.getState().open('addCard', {
                ...currentData2.data,
                initialImages: [...(currentData2.data?.initialImages || []), imageObj],
              });
            } else {
              useDialogStore.getState().open('addCard', {
                cardType, initialImages: [imageObj],
              });
            }
          }
        }
      } catch (error) {
        console.error('處理圖片 URL 失敗:', error);
        setTempHint(t('imageProcessFailed'));
      }
    } else if (imageFiles.length > 0) {
      // 處理拖曳的檔案
      const newImages = [];

      for (const file of imageFiles) {
        if (file.size > 10 * 1024 * 1024) continue; // 跳過太大的檔案

        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });

          newImages.push({
            file,
            preview: URL.createObjectURL(file),
            base64: base64.split(',')[1]
          });
        } catch (error) {
          console.error('讀取圖片失敗:', error);
        }
      }

      if (newImages.length > 0) {
        const currentData3 = useDialogStore.getState().dialogs['addCard'];
        if (currentData3?.show) {
          useDialogStore.getState().open('addCard', {
            ...currentData3.data,
            initialImages: [...(currentData3.data?.initialImages || []), ...newImages],
          });
        } else {
          useDialogStore.getState().open('addCard', {
            cardType, initialImages: newImages,
          });
        }
      }
    }
  };

  // 關閉右鍵選單
  const closeContextMenu = useCallback(() => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0,
      card: null,
      fieldName: null,
      fieldValue: null
    });
  }, []);

  // 點擊其他地方關閉選單
  useEffect(() => {
    if (contextMenu.visible) {
      const handleClick = () => closeContextMenu();
      document.addEventListener('click', handleClick);
      return () => document.removeEventListener('click', handleClick);
    }
  }, [contextMenu.visible, closeContextMenu]);

  // 排序按鈕點擊處理（記錄位置並打開選單）
  const handleSortButtonClick = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setSortMenuPosition({ x: rect.left, y: rect.bottom + 4 });
    setShowSortDropdown(!showSortDropdown);
  };

  // 檢測 Tags 是否溢出
  useEffect(() => {
    const checkOverflow = () => {
      if (tagsContainerRef.current) {
        const { scrollWidth, clientWidth } = tagsContainerRef.current;
        setHasTagsOverflow(scrollWidth > clientWidth);
      }
    };
    checkOverflow();
    window.addEventListener('resize', checkOverflow);
    return () => window.removeEventListener('resize', checkOverflow);
  }, [tagStats, selectedTags]);

  // 右鍵點擊卡片
  const handleCardRightClick = (e, card, fieldName = null, fieldValue = null) => {
    e.preventDefault();
    e.stopPropagation();

    const computedScale = getComputedStyle(document.documentElement)
      .getPropertyValue('--content-scale')
      .trim();
    const scale = parseFloat(computedScale) || 1;

    setContextMenu({
      visible: true,
      x: e.clientX / scale,
      y: e.clientY / scale,
      card,
      fieldName,
      fieldValue
    });
  };



  // 取得 folderCards 的 ID 列表（用於範圍選擇）
  const folderCardIds = useMemo(() => folderCards.map(c => c.id), [folderCards]);

  const isCardSelected = useCallback(
    () => useSelectedItemsStore.getState().path.at(-1)?.itemType === 'CARD',
    [],
  );

  useListKeyboardNav({
    prefix: 'card-gallery',
    sortedIds: folderCardIds,
    isActive: isCardSelected,
    onNavigateLeft: () => useSelectedItemsStore.getState().navigateOut(),
    labels: {
      up: t('cmd.cardGalleryUp'),
      down: t('cmd.cardGalleryDown'),
      shiftUp: t('cmd.cardGalleryShiftUp'),
      shiftDown: t('cmd.cardGalleryShiftDown'),
      left: t('cmd.cardGalleryLeft'),
      right: t('cmd.cardGalleryRight'),
    },
  });

  // 多選點擊處理（遮罩專用）
  const handleMultiSelectClick = (e, card) => {
    e.stopPropagation();
    const isCtrlClick = e.metaKey || e.ctrlKey;
    const isShiftClick = e.shiftKey;

    if (isCtrlClick) {
      // Ctrl/Cmd + 點擊：切換選擇
      if (selectedCardIds.includes(card.id)) {
        setSelectedCardIds(selectedCardIds.filter(id => id !== card.id));
      } else {
        setSelectedCardIds([...selectedCardIds, card.id]);
      }
    } else if (isShiftClick) {
      // Shift + 點擊：範圍選擇
      if (selectedCardIds.length > 0) {
        const lastSelectedId = selectedCardIds[selectedCardIds.length - 1];
        const currentIndex = folderCardIds.indexOf(lastSelectedId);
        const clickedIndex = folderCardIds.indexOf(card.id);

        if (currentIndex !== -1 && clickedIndex !== -1) {
          const startIndex = Math.min(currentIndex, clickedIndex);
          const endIndex = Math.max(currentIndex, clickedIndex);
          const rangeIds = folderCardIds.slice(startIndex, endIndex + 1);
          setSelectedCardIds([...rangeIds]);
        }
      } else {
        // 第一次 Shift 點擊，選中該卡片
        setSelectedCardIds([card.id]);
      }
    }
  };

  // 點擊卡片 - 進入編輯模式
  const handleCardClick = (card, fieldName = null) => {

    closeContextMenu();
    useDialogStore.getState().open('addCard', {
      cardType, editCard: card, focusField: fieldName,
    });
  };

  // 右鍵選單 - 編輯卡片
  const handleContextMenuEdit = () => {
    const card = contextMenu.card;
    closeContextMenu();
    if (card) {
      handleCardClick(card);
    }
  };

  // 右鍵選單 - 刪除卡片
  const handleContextMenuDelete = async () => {
    if (contextMenu.card) {
      try {
        await deleteCard(contextMenu.card);
        setTempHint(t('cardDeleted'));
      } catch (error) {
        console.error('刪除卡片失敗:', error);
        setTempHint(t('deleteFailed'));
      }
    }
    closeContextMenu();
  };

  // 右鍵選單 - 複製欄位
  const handleContextMenuCopy = async () => {
    if (contextMenu.fieldValue) {
      try {
        await navigator.clipboard.writeText(contextMenu.fieldValue);
        setTempHint(t('copied'));
      } catch (error) {
        console.error('複製失敗:', error);
      }
    }
    closeContextMenu();
  };

  // 右鍵選單 - 複製卡片連結
  const handleContextMenuCopyLink = async () => {
    if (contextMenu.card) {
      const link = `cubelv://card/${contextMenu.card.id}`;
      try {
        await navigator.clipboard.writeText(link);
        setTempHint(t('cardLinkCopied'));
      } catch (error) {
        console.error('複製卡片連結失敗:', error);
      }
    }
    closeContextMenu();
  };

  // 右鍵選單 - 複製卡片資訊
  const handleContextMenuCopyCardInfo = async () => {
    const card = contextMenu.card;
    if (!card?.cardFields || cardTypeFields.length === 0) {
      closeContextMenu();
      return;
    }

    // 分類欄位
    let firstField = null;
    let ratingField = null;
    let locationField = null;
    let urlField = null;
    const otherFields = [];
    const firstTextFieldIndex = getFirstTextFieldIndex(cardTypeFields);

    cardTypeFields.forEach((field, index) => {
      const value = card.cardFields?.[field.name];
      if (value === undefined || value === null || value === '') return;

      // 跳過圖片欄位
      if (field.type === 'IMAGE') return;

      // 格式化值
      let displayValue = value;
      if (field.type === 'BOOLEAN') {
        displayValue = value === 'true' || value === true ? t('yes') : t('no');
      } else if (field.type === 'RATING') {
        displayValue = String.fromCharCode(9733).repeat(parseInt(value) || 0); // ★
      } else if (Array.isArray(value)) {
        displayValue = value.join(', ');
      }

      const fieldData = { field, displayValue: String(displayValue), value };

      if (index === firstTextFieldIndex && !firstField) {
        firstField = fieldData;
      } else if (field.type === 'RATING' && !ratingField) {
        ratingField = fieldData;
      } else if (field.type === 'LOCATION' && !locationField) {
        locationField = fieldData;
      } else if (field.type === 'URL' && !urlField) {
        urlField = fieldData;
      } else {
        otherFields.push(fieldData);
      }
    });

    // 組合輸出
    const lines = [];
    if (firstField) lines.push(firstField.displayValue);
    if (ratingField) lines.push(ratingField.displayValue);
    if (locationField) {
      lines.push(locationField.displayValue);
      lines.push(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(locationField.value)}`);
    }
    otherFields.forEach(({ field, displayValue }) => {
      lines.push(`${field.name}:${displayValue}`);
    });
    if (urlField) lines.push(urlField.displayValue);

    if (lines.length > 0) {
      try {
        await navigator.clipboard.writeText(lines.join('\n'));
        setTempHint(t('cardInfoCopied'));
      } catch (error) {
        console.error('複製卡片資訊失敗:', error);
      }
    }
    closeContextMenu();
  };

  // 新增卡片按鈕點擊處理
  const handleAddCardClick = () => {
    if (!isLoggedIn) {
      // 未登入：顯示登入對話框
      useDialogStore.getState().open('login', { message: t('loginDialogAddCardContent') });
      return;
    }
    // 已登入：打開新增卡片對話框
    useDialogStore.getState().open('addCard', { cardType });
  };

  const handleFavoriteClick = () => {
    if (myPermission === Permission.guest) {
      useDialogStore.getState().open('login', { message: t('loginDialogFavoriteContent') });
      return;
    }
    executeFavorite();
  };

  // 執行收藏邏輯
  const executeFavorite = async () => {
    if (!cardType || !folderCards) return;

    try {
      const localCardTypes = useItemStore.getState().getByType('CARD_FOLDER') || [];
      const localCards = useItemStore.getState().getByType('CARD') || [];
      const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
      const memberID = userData.ID;

      if (!memberID) {
        setTempHint(t('pleaseLogin'));
        return;
      }

      // 執行匯入
      const result = await importFavorite({
        cardType: cardType,
        cards: folderCards,
        sharerName: sharerName,
        localCardTypes,
        localCards,
        memberID,
        t
      });

      // 儲存新的 Card 資料夾（Folder type=CARD）
      if (result.newCardType) {
        const newFolder = {
          ...result.newCardType,
          name: result.newCardType.name,
          icon: result.newCardType.icon,
          itemType: 'CARD',
          parentID: result.newCardType.parentID ?? null
        };
        await useCardsStore.getState().addCardFolder(newFolder);
      }

      // 批次添加卡片
      if (result.newCards.length > 0) {
        await useCardsStore.getState().addCard(result.newCards);
      }

      // 同步到遠端
      await syncService.syncChanges();

      // 顯示成功提示
      if (result.merged) {
        setTempHint(t('favoriteSuccessWithMerge', {
          count: result.count,
          name: result.name
        }));
      } else {
        setTempHint(t('favoriteSuccessNewType', {
          count: result.count,
          name: result.name
        }));
      }

      // 導航到該畫廊（並滾動 Sidebar 到該項目）
      const targetFolder = useItemStore.getState().getByType('CARD_FOLDER').find((f: any) => f.id === result.parentID);
      if (targetFolder) {
        useSelectedItemsStore.getState().setSelectedItems([targetFolder], { scrollToFocusItem: true });
      }

    } catch (error) {
      console.error('[executeFavorite] 收藏失敗:', error);
      setTempHint(t('favoriteFailed'));
    }
  };

  // 前往登入頁
  const handleGoToLogin = () => {
    if (localStorage.getItem('isGuest') === 'true') {
      useDialogStore.getState().open('login', { message: t('loginDialogReviewContent') });
      return;
    }

    // 非 Guest：存 pendingPublicShare，登入後導回此頁（pathname 可能是 /share/xxx 或 /app/CARD_FOLDER/xxx）
    const pathname = window.location.pathname;
    const idMatch = pathname.match(/\/([a-f0-9]{24})(?:$|\/)/);
    if (pathname.includes('/share/')) {
      localStorage.setItem('pendingPublicShare', JSON.stringify({ pathname }));
    } else if (idMatch) {
      localStorage.setItem('pendingPublicShare', JSON.stringify({ pathname: '/share/' + idMatch[1] }));
    }
    window.location.href = '/app/';
  };

  // 檢查卡片是否有空白欄位
  const hasEmptyFields = useCallback((card) => {
    if (cardTypeFields.length === 0) return false;
    const cardFieldData = card?.cardFields ?? card?.fields;
    if (!cardFieldData) return false;

    for (const field of cardTypeFields) {
      const value = cardFieldData[field.name];
      if (value === undefined || value === null || value === '') {
        return true;
      }
    }
    return false;
  }, [cardTypeFields]);

  // 右鍵選單 - 自動補完空白欄位（使用 Custom Bot HTTP endpoint）
  const handleAutoComplete = async () => {
    const card = contextMenu.card;
    closeContextMenu();

    if (!card || !cardType) return;

    const cardId = card.id;
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const memberID = userData.ID;

    if (!memberID) {
      setTempHint(t('pleaseLogin'));
      return;
    }

    addAutoCompletingCard(cardId);

    try {
      const fieldsBasedOnCardType: Record<string, string> = {};
      for (const fieldDef of cardTypeFields) {
        fieldsBasedOnCardType[fieldDef.name] = card.cardFields?.[fieldDef.name] || '';
      }

      const updatedFields = await autoCompleteCardFields({
        cardId,
        parentID: card.parentID,
        cardTypeName: (cardType as any).name,
        currentFields: fieldsBasedOnCardType,
        fieldDefinitions: cardTypeFields,
      });

      const existingCard = useCardsStore.getState().getCardById(cardId);
      if (existingCard) {
        updateCard({ ...existingCard, cardFields: updatedFields });
      } else {
        updateCard({ id: cardId, parentID: card.parentID, name: card.name, cardFields: updatedFields });
      }
      await syncService.syncChanges();

      removeAutoCompletingCard(cardId);
      setTempHint(t('autoCompleteSuccess'));

    } catch (error: any) {
      console.error(`自動補完失敗 [${cardId}]:`, error);
      if (!checkAndHandleCreditsError(error, false, 'handleAutoComplete')) {
        setTempHint(t('autoCompleteFailed'));
      }
      removeAutoCompletingCard(cardId);
    }
  };

  // ==================== 匯出 CSV ====================

  // 匯出卡片資料為 CSV
  const exportCSV = useCallback(() => {
    if (!folderCards || folderCards.length === 0) return;

    setExportLoading(true);
    try {
      const allFields = cardTypeFields;
      const firstTextFieldIndex = getFirstTextFieldIndex(allFields);

      // 排序欄位：參考複製卡片資訊的順序
      // 1. 第一個文字欄位 2. RATING 3. LOCATION 4. URL 5. 其他欄位 6. IMAGE 放最後
      let firstField = null;
      let ratingFields = [];
      let locationFields = [];
      let urlFields = [];
      let otherFields = [];
      let imageFields = [];

      allFields.forEach((field, index) => {
        if (field.type === 'IMAGE') {
          imageFields.push(field);
        } else if (index === firstTextFieldIndex && !firstField) {
          firstField = field;
        } else if (field.type === 'RATING') {
          ratingFields.push(field);
        } else if (field.type === 'LOCATION') {
          locationFields.push(field);
        } else if (field.type === 'URL') {
          urlFields.push(field);
        } else {
          otherFields.push(field);
        }
      });

      // 組合排序後的欄位
      const sortedFields = [
        ...(firstField ? [firstField] : []),
        ...ratingFields,
        ...locationFields,
        ...urlFields,
        ...otherFields,
        ...imageFields
      ];

      // CSV 標頭
      const headers = sortedFields.map(f => f.name);

      // 產生資料行
      const rows = folderCards.map(card => {
        return sortedFields.map(field => {
          const cardFieldData = card.cardFields;
          let value = cardFieldData?.[field.name] ?? '';

          // 處理不同類型的值
          if (field.type === 'RATING') {
            value = String(parseInt(value) || 0);
          } else if (Array.isArray(value)) {
            value = value.join('; ');
          } else if (typeof value === 'object' && value !== null) {
            value = JSON.stringify(value);
          }

          // 轉換為字串
          value = String(value);

          // 處理 CSV 特殊字符（逗號、引號、換行）
          if (value.includes(',') || value.includes('"') || value.includes('\n')) {
            value = `"${value.replace(/"/g, '""')}"`;
          }

          return value;
        });
      });

      // 組合 CSV 內容
      const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');

      // 下載檔案
      const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' }); // 加 BOM 支援 Excel 開啟
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const csvName = selectedCardFolder?.name || (cardType as any)?.name || 'cards';
      link.download = `${csvName}-${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('匯出 CSV 失敗:', err);
    } finally {
      setExportLoading(false);
    }
  }, [folderCards, cardType, selectedCardFolder]);

  // ==================== 拖曳排序相關函數 ====================

  // 計算新的 orderAt 值（根據前後卡片的 orderAt）
  const calculateNewOrderAt = useCallback((prevCard, nextCard) => {
    // 取得卡片的排序值（優先使用 orderAt，沒有則用 createdAt）
    const getOrderValue = (card) => {
      const orderAt = card?.orderAt ?? card?.orderAt;
      if (orderAt && !isNaN(parseFloat(orderAt))) return parseFloat(orderAt);
      const createdAt = card?.createdAt ?? card?.createdAt;
      if (createdAt) return parseFloat(createdAt);
      return 0;
    };

    const prevOrder = getOrderValue(prevCard);
    const nextOrder = getOrderValue(nextCard);

    if (!prevCard && nextCard) {
      // 拖到最前面：比第一張卡片大 1000
      return (nextOrder + 1000).toString();
    }
    if (prevCard && !nextCard) {
      // 拖到最後面：比最後一張卡片小 1000
      return (prevOrder - 1000).toString();
    }
    if (prevCard && nextCard) {
      // 拖到中間：取兩張卡片的中間值
      return ((prevOrder + nextOrder) / 2).toString();
    }
    // 只有一張卡片或沒有卡片時，使用當前時間
    return Date.now().toString();
  }, []);

  // 長按開始 - 啟用拖曳模式
  const handleMouseDown = useCallback((e, card) => {
    // 多選時直接可拖曳，不需要長按動畫
    if (selectedCardIds.length > 1 && selectedCardIds.includes(card.id)) {
      setCanDrag(true);
      return;
    }

    // 清除之前的計時器
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
    }

    longPressCardIdRef.current = card.id;

    // 長按 200ms 後啟用拖曳
    longPressTimerRef.current = safeSetTimeout(() => {
      setCanDrag(true);
      // 添加視覺提示 - 輕微震動效果
      const element = e.currentTarget;
      if (element) {
        element.classList.add('can-drag');
      }
    }, 200);
  }, [selectedCardIds]);

  // 滑鼠放開 - 取消長按
  const handleMouseUp = useCallback(() => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    longPressCardIdRef.current = null;

    // 如果沒有在拖曳中，取消拖曳模式
    if (!isDraggingRef.current) {
      setCanDrag(false);
      // 移除所有 can-drag 類
      document.querySelectorAll('.can-drag').forEach(el => el.classList.remove('can-drag'));
    }
  }, []);

  // 滑鼠離開 - 取消長按
  const handleMouseLeave = useCallback(() => {
    if (longPressTimerRef.current && !isDraggingRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
      longPressCardIdRef.current = null;
      setCanDrag(false);
    }
  }, []);

  // mobile 長按開始 - 觸發右鍵選單
  const handleTouchStart = useCallback((e, card) => {
    // 記錄觸摸起始位置
    const touch = e.touches[0];
    touchStartPosRef.current = { x: touch.clientX, y: touch.clientY };

    // 清除之前的計時器
    if (touchLongPressTimerRef.current) {
      clearTimeout(touchLongPressTimerRef.current);
    }

    // 長按 500ms 後觸發右鍵選單
    touchLongPressTimerRef.current = safeSetTimeout(() => {
      // 觸發右鍵選單
      const computedScale = getComputedStyle(document.documentElement)
        .getPropertyValue('--scale')
        .trim();
      const scale = parseFloat(computedScale) || 1;

      setContextMenu({
        visible: true,
        x: touch.clientX / scale,
        y: touch.clientY / scale,
        card: card,
        fieldName: null,
        fieldValue: null
      });
      touchLongPressTimerRef.current = null;
    }, 500);
  }, []);

  // mobile 觸摸移動 - 如果移動超過閾值則取消長按
  const handleTouchMove = useCallback((e) => {
    if (!touchLongPressTimerRef.current || !touchStartPosRef.current) return;

    const touch = e.touches[0];
    const dx = Math.abs(touch.clientX - touchStartPosRef.current.x);
    const dy = Math.abs(touch.clientY - touchStartPosRef.current.y);

    // 移動超過 10px 取消長按
    if (dx > 10 || dy > 10) {
      clearTimeout(touchLongPressTimerRef.current);
      touchLongPressTimerRef.current = null;
    }
  }, []);

  // mobile 觸摸結束 - 取消長按
  const handleTouchEnd = useCallback(() => {
    if (touchLongPressTimerRef.current) {
      clearTimeout(touchLongPressTimerRef.current);
      touchLongPressTimerRef.current = null;
    }
    touchStartPosRef.current = null;
  }, []);

  // 拖曳開始
  const handleDragStart = useCallback((e, card) => {
    // 如果還沒長按夠久，阻止拖曳
    if (!canDrag) {
      e.preventDefault();
      return;
    }

    // 判斷是否為多選拖曳
    const isMultiSelecting = selectedCardIds.length > 1 && selectedCardIds.includes(card.id);
    const dragCardIds = isMultiSelecting ? selectedCardIds : [card.id];

    isDraggingRef.current = true;
    setIsDragging(true);
    setDraggedCardId(card.id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', card.id);

    // 設置多選卡片 ID 到全局變數（供 dragOver 判斷）
    window.currentDraggedCardIds = dragCardIds;
    window.isMultiCardDrag = isMultiSelecting;

    const currentCardType = cardTypes.find(ct => ct.id === card.parentID) || cardType;

    const dragCards = isMultiSelecting
      ? cards.filter(c => dragCardIds.includes(c.id)).map(c => {
        const ct = cardTypes.find(t => t.id === ((c as any)?.parentID)) || cardType;
        return {
          id: c.id,
          name: c.name,
          parentID: c.parentID,
          cardTypeName: (ct as any)?.name || '',
          cardFields: c.cardFields,
        };
      })
      : [{
        id: card.id,
        name: card.name,
        parentID: card.parentID,
        cardFields: card.cardFields,
      }];

    e.dataTransfer.setData('application/cubelv-card', JSON.stringify(
      isMultiSelecting ? dragCards : dragCards[0]
    ));
    e.dataTransfer.setData('application/cubelv-cards', JSON.stringify(dragCards));
    e.dataTransfer.setData('sourceType', 'card');
    e.dataTransfer.setData('dragItems', JSON.stringify(dragCards));



    eventBus.emit('drag:note-editor-drag-overlay', { icon: EditIcon, text: t('insertLink') });
    eventBus.emit('drag:ai-commander-drag-overlay', { icon: EditIcon, text: t('dragToAttach', '拖曳放置後附加') });

    // 多選時使用標籤樣式的拖曳預覽
    if (isMultiSelecting) {
      const dragPreview = document.createElement('div');
      dragPreview.textContent = t('selectedCards', { count: dragCardIds.length }) || `已選擇 ${dragCardIds.length} 張卡片`;

      // 從計算樣式中獲取實際顏色值（避免 setDragImage 時 CSS 變量未解析導致背景異常）
      const rootStyles = getComputedStyle(document.documentElement);
      const surfaceColor = rootStyles.getPropertyValue('--surface').trim() || '#ffffff';
      const onColor = rootStyles.getPropertyValue('--on').trim() || '#000000';

      Object.assign(dragPreview.style, {
        position: 'absolute',
        top: '-9999px',
        left: '-9999px',
        padding: '6px 12px',
        borderRadius: '99px',
        background: `color-mix(in srgb, ${surfaceColor} 90%, transparent)`,
        color: onColor,
        fontSize: '13px',
        fontFamily: 'inherit',
        whiteSpace: 'nowrap',
        boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
        backdropFilter: 'blur(8px)',
      });

      document.body.appendChild(dragPreview);

      const rect = e.currentTarget.getBoundingClientRect();
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;
      e.dataTransfer.setDragImage(dragPreview, offsetX, offsetY);

      requestAnimationFrame(() => {
        document.body.removeChild(dragPreview);
      });
    } else {
      // 單選時使用卡片本身作為拖曳預覽圖像
      const rect = e.currentTarget.getBoundingClientRect();
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;
      e.dataTransfer.setDragImage(e.currentTarget, offsetX, offsetY);
    }
  }, [canDrag, cardTypes, cards, selectedCardIds, t]);

  // 拖曳結束 - 保存排序結果（更新被拖曳卡片的 orderAt）
  const handleDragEnd = useCallback(async () => {
    // 多選拖曳時不保存排序（因為沒有重新排序）
    const isMultiDrag = window.isMultiCardDrag;

    // 權限檢查：分享模式下只有 Editor 以上可以拖曳排序
    if (isDraggingRef.current && orderedCardIds.length > 0 && !isMultiDrag && canReorderCards && draggedCardId) {
      // 找到被拖曳卡片在新順序中的位置
      const newIndex = orderedCardIds.indexOf(draggedCardId);
      if (newIndex !== -1) {
        // 找到前後卡片
        const prevCardId = newIndex > 0 ? orderedCardIds[newIndex - 1] : null;
        const nextCardId = newIndex < orderedCardIds.length - 1 ? orderedCardIds[newIndex + 1] : null;

        // 從 baseCards 中找到對應的卡片資料
        const cardMap = new Map(baseCards.map(c => [c.id, c]));
        const draggedCard = cardMap.get(draggedCardId);
        const prevCard = prevCardId ? cardMap.get(prevCardId) : null;
        const nextCard = nextCardId ? cardMap.get(nextCardId) : null;

        if (draggedCard) {
          // 計算新的 orderAt
          const newOrderAt = calculateNewOrderAt(prevCard, nextCard);

          // 更新卡片的 orderAt
          try {
            await updateCard({
              ...draggedCard,
              orderAt: newOrderAt
            });
          } catch (error) {
            console.error('更新卡片排序失敗:', error);
          }
        }
      }
    }

    isDraggingRef.current = false;
    setIsDragging(false);
    setDraggedCardId(null);
    setCanDrag(false);

    // 清除全局變數
    window.currentDraggedCardIds = null;
    window.isMultiCardDrag = false;

    // 移除所有 can-drag 類
    document.querySelectorAll('.can-drag').forEach(el => el.classList.remove('can-drag'));


    eventBus.emit('drag:note-editor-drag-overlay', null);
    eventBus.emit('drag:ai-commander-drag-overlay', null);
  }, [orderedCardIds, canReorderCards, draggedCardId, baseCards, calculateNewOrderAt, updateCard]);

  // 拖曳經過 - 即時重新排序（多選時不觸發）
  const handleDragOver = useCallback((e, targetCardId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';

    // 多選拖曳時不進行排序
    if (window.isMultiCardDrag) return;

    if (!draggedCardId || targetCardId === draggedCardId) return;

    // 計算滑鼠位置決定插入點
    const rect = e.currentTarget.getBoundingClientRect();
    const midX = rect.left + rect.width / 2;
    const insertBefore = e.clientX < midX;

    setOrderedCardIds(prevIds => {
      const draggedIndex = prevIds.indexOf(draggedCardId);
      const targetIndex = prevIds.indexOf(targetCardId);

      if (draggedIndex === -1 || targetIndex === -1) return prevIds;

      // 計算新的插入位置
      let newIndex = insertBefore ? targetIndex : targetIndex + 1;
      if (draggedIndex < targetIndex) {
        newIndex--;
      }

      // 如果位置沒變，不更新
      if (draggedIndex === newIndex) return prevIds;

      // 重新排序
      const newIds = [...prevIds];
      newIds.splice(draggedIndex, 1);
      newIds.splice(newIndex, 0, draggedCardId);

      return newIds;
    });
  }, [draggedCardId]);

  // 放置（實際上排序已在 dragOver 完成，這裡只需防止預設行為）
  const handleDrop = useCallback((e) => {
    e.preventDefault();
  }, []);

  // 渲染單張卡片
  const renderCard = (card, index) => {
    const isDraggingThis = draggedCardId === card.id;
    const isCanDrag = canDrag && longPressCardIdRef.current === card.id;
    const isAutoCompleting = autoCompletingCardIds.has(card.id);
    const isSelected = selectedCardIds.includes(card.id);

    // 拖曳相關的共用 props（需要有排序權限才能拖曳）
    const dragProps = canReorderCards ? {
      draggable: canDrag,
      onMouseDown: (e) => handleMouseDown(e, card),
      onMouseUp: handleMouseUp,
      onMouseLeave: handleMouseLeave,
      onDragStart: (e) => handleDragStart(e, card),
      onDragEnd: handleDragEnd,
      onDragOver: (e) => handleDragOver(e, card.id),
      onDrop: handleDrop,
      // mobile 長按觸發右鍵選單
      onTouchStart: (e) => handleTouchStart(e, card),
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
    } : {
      // 沒有排序權限時只保留觸摸事件（用於右鍵選單）
      onTouchStart: (e) => handleTouchStart(e, card),
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
    };

    // 自動補完 loader 組件
    const autoCompleteLoader = isAutoCompleting && (
      <div className="card-auto-complete-loader">
        <div className="card-auto-complete-spinner"></div>
      </div>
    );

    // 多選遮罩（Shift/Ctrl 按下時顯示）
    const isMultiSelectMode = isShiftPressed || isCommandPressed;
    const multiSelectMask = isMultiSelectMode && (
      <div
        className="card-gallery-multiselect-mask"
        onClick={(e) => handleMultiSelectClick(e, card)}
      />
    );

    if (!(cardType as any)?.templateHtml && !(cardType as any)?.templateHtml || !(cardType as any)?.templateCss && !(cardType as any)?.templateCss) {
      // 沒有模板時顯示簡單卡片
      return (
        <div
          key={card.id}
          data-card-id={card.id}
          className={`card-gallery-item card-gallery-item-simple ${isDraggingThis ? 'dragging' : ''} ${isCanDrag ? 'can-drag' : ''} ${isSelected ? 'selected' : ''}`}
          onClick={() => !isDraggingRef.current && handleCardClick(card)}
          onContextMenu={(e) => handleCardRightClick(e, card)}
          {...dragProps}
        >
          {multiSelectMask}
          {autoCompleteLoader}
          <div className="card-simple-content">
            {cardTypeFields.map((field, fieldIndex) => (
              <div key={field.id || field.name || `field-${fieldIndex}`} className="card-simple-field">
                <span className="card-simple-label">{field.name}:</span>
                <span className="card-simple-value">{card.cardFields?.[field.name] || '-'}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    // 判斷是否需要顯示 avatar
    const hasComments = getReviewsByCardId(card.id).some(r => r.comment?.trim().length > 0);
    const shouldShowAvatar = hasMultipleContributors || hasComments;

    // 使用 CardRenderer 渲染卡片
    return (
      <div
        key={card.id}
        data-card-id={card.id}
        className={`card-gallery-item ${isDraggingThis ? 'dragging' : ''} ${isCanDrag ? 'can-drag' : ''} ${isSelected ? 'selected' : ''}`}
        {...dragProps}
      >
        {multiSelectMask}
        {autoCompleteLoader}
        <LazyCard
          scrollContainer={contentRef.current}
          placeholder={<div className="card-gallery-placeholder" />}
        >
          <CardRenderer
            templateHtml={(cardType as any).templateHtml}
            templateCss={(cardType as any).templateCss}
            fields={(cardType as any).cardFieldsDef}
            cardData={card}
            onClick={(e, fieldName) => !isDraggingRef.current && handleCardClick(card, fieldName)}
            onContextMenu={(e, fieldName, fieldValue) => handleCardRightClick(e, card, fieldName, fieldValue)}
            onFieldChange={async (fieldName, newValue) => {
              try {
                await updateCard({
                  ...card,
                  cardFields: { ...card.cardFields, [fieldName]: newValue }
                });
              } catch (error) {
                console.error('更新卡片失敗:', error);
                setTempHint(t('updateFailed'));
              }
            }}
            onReviewChange={async (rating) => {
              const myRev = getMyReview(card.id, currentMemberID);
              const hasComment = myRev?.comment?.trim().length > 0;
              if (!hasComment) {
                useDialogStore.getState().open('writeReview', {
                  cardName: card.name ?? '',
                  initialRating: rating,
                  initialComment: '',
                  onSubmit: async ({ rating: r, comment }) => {
                    try {
                      await upsertReview(card.id, currentMemberID, r, comment);
                    } catch (error) {
                      console.error('更新評分失敗:', error);
                      setTempHint(t('updateFailed'));
                    }
                  },
                });
                return;
              }
              try {
                await upsertReview(card.id, currentMemberID, rating, myRev.comment);
              } catch (error) {
                console.error('更新評分失敗:', error);
                setTempHint(t('updateFailed'));
              }
            }}
            canEditThisCard={myPermission >= Permission.contributor}
            canRate={myPermission >= Permission.contributor}
            isLoggedIn={isLoggedIn}
            onRequestLogin={handleGoToLogin}
            onRequestPermission={() => setTempHint(t('permissionRequired'))}
            currentMemberID={currentMemberID}
          />
        </LazyCard>
        {shouldShowAvatar && (
          <LazyCard
            scrollContainer={contentRef.current}
            placeholder={null}
          >
            <AvatarWithBubble
              cardData={card}
              creatorId={creatorsMap[card.id]?.memberId}
              currentMemberID={currentMemberID}
              onAvatarClick={() => handleOpenContributorsDialog()}
              onBubbleClick={() => {
                useDialogStore.getState().open('reviewsList', {
                  card,
                  currentMemberID,
                  currentUserInfo,
                  membersInfoMap,
                  fetchMemberInfo,
                  canReview,
                  canDeleteOthersReview,
                  isLoggedIn,
                  onActorClick: handleOpenContributorsDialog,
                });
              }}
            />
          </LazyCard>
        )}
      </div>
    );
  };

  return (
    <div
      className="card-gallery-container"
      onDragEnter={handleFileDragEnter}
      onDragLeave={handleFileDragLeave}
      onDragOver={(e) => e.preventDefault()}
    >
      {/* 手機版頂部標題列 */}
      {isMobileView && (
        isMobileSearchOpen ? (
          // 搜尋模式：顯示搜尋框 + 關閉按鈕
          <div className="mobile-topbar card-gallery-mobile-search-topbar">
            <div className="card-gallery-mobile-search">
              <svg className="card-gallery-mobile-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              <input
                ref={mobileSearchInputRef}
                type="text"
                className="card-gallery-mobile-search-input"
                placeholder={t('searchCards')}
                value={searchInputValue}
                onChange={(e) => {
                  setSearchInputValue(e.target.value);
                  if (!isSearchComposingRef.current) {
                    setSearchQuery(e.target.value);
                  }
                }}
                onCompositionStart={() => {
                  isSearchComposingRef.current = true;
                }}
                onCompositionEnd={(e) => {
                  isSearchComposingRef.current = false;
                  setSearchQuery((e.target as HTMLInputElement).value);
                }}
              />
              {searchInputValue && (
                <button
                  className="card-gallery-mobile-search-clear"
                  onClick={() => {
                    setSearchInputValue('');
                    setSearchQuery('');
                    mobileSearchInputRef.current?.focus();
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                  </svg>
                </button>
              )}
            </div>
            <button
              className="mobile-topbar-button"
              onClick={() => {
                setIsMobileSearchOpen(false);
                setSearchInputValue('');
                setSearchQuery('');
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
        ) : (
          // 正常模式：使用 MobileTopbar
          <MobileTopbar
            leftIcon="menu"
            onLeftClick={() => setIsMobileSidebarOpen(true)}
            title={selectedCardFolder?.name || t('sidebarCards')}
            titleIcon={null}
            titleSuffix={cardType && (
              <ShareMemberThumbnailList
                itemId={cardType.id}
                permissions={cardType._permissions || []}
                size="small"
                maxDisplay={10}
              />
            )}
            rightContent={
              <>
                {myPermission >= Permission.contributor && (
                  <button
                    className="mobile-topbar-button"
                    tabIndex={-1}
                    onClick={handleAddCardClick}
                  >
                    <PlusIcon />
                  </button>
                )}
                <button
                  className="mobile-topbar-button"
                  tabIndex={-1}
                  onClick={() => setIsMobileSearchOpen(true)}
                >
                  <SearchIcon />
                </button>
                <button
                  className="mobile-topbar-button"
                  tabIndex={-1}
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    useMenuStore.getState().openAt('cardGalleryMore', rect.right, rect.bottom + 4);
                  }}
                >
                  <MoreIcon />
                </button>
                {myPermission === Permission.guest && (
                  <button
                    className="card-gallery-mobile-favorite-btn"
                    tabIndex={-1}
                    onClick={handleFavoriteClick}
                  >
                    {t('favorite')}
                  </button>
                )}
              </>
            }
          />
        )
      )}

      <div className={`card-gallery-header ${isMobileView ? 'mobile-hidden' : ''}`}>
        {/* 標題區域：名稱 */}
        <h2 className="card-gallery-title">
          {selectedCardFolder?.name || t('cardGallery')}
        </h2>

        {/* 貢獻者頭像區塊 */}
        {cardType && (
          <ShareMemberThumbnailList
            itemId={cardType.id}
            permissions={cardType._permissions || []}
            maxDisplay={30}
          />
        )}

        <div className="card-gallery-header-actions">
          {/* 搜尋欄 */}
          <div className="card-gallery-search">
            <svg className="card-gallery-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <input
              ref={searchInputRef}
              type="text"
              className="card-gallery-search-input"
              placeholder={t('searchCards')}
              value={searchInputValue}
              onChange={(e) => {
                setSearchInputValue(e.target.value);
                // 只在非組字狀態時更新搜尋
                if (!isSearchComposingRef.current) {
                  setSearchQuery(e.target.value);
                }
              }}
              onCompositionStart={() => {
                isSearchComposingRef.current = true;
              }}
              onCompositionEnd={(e) => {
                isSearchComposingRef.current = false;
                // 組字結束後更新搜尋
                setSearchQuery((e.target as HTMLInputElement).value);
              }}
            />
            {searchInputValue && (
              <button
                className="card-gallery-search-clear"
                onClick={() => {
                  setSearchInputValue('');
                  setSearchQuery('');
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>
            )}
          </div>

          <div className="card-gallery-header-buttons">
            {myPermission >= Permission.contributor && (
              <button
                className="custom-outline-button muted"
                tabIndex={-1}
                onClick={handleAddCardClick}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                {t('addCard')}
              </button>
            )}
            {myPermission === Permission.guest && (
              <button
                className="custom-outline-button muted"
                tabIndex={-1}
                onClick={handleFavoriteClick}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                </svg>
                {t('favoriteList')}
              </button>
            )}
            {myPermission >= Permission.contributor && (
              <div className="card-gallery-share-btn-wrapper">
                <button
                  className={`custom-outline-button muted ${(cardType as any)?.isPublic ? 'active' : ''}`}
                  tabIndex={-1}
                  onClick={() => {
                    openGalleryShareSettings();
                  }}
                >
                  <ShareIcon />
                  {t('share')}
                </button>
              </div>
            )}
            <button
              className="custom-outline-button muted"
              tabIndex={-1}
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                useMenuStore.getState().openAt('cardGalleryMore', rect.left, rect.bottom + 4);
              }}
            >
              <MoreIcon />
            </button>
          </div>

        </div>
      </div>
      <div className="card-gallery-body">
        <div
          ref={contentRef}
          className={`card-gallery-content ${viewMode === 'map' ? 'map-mode' : ''} ${viewMode === 'list' ? 'list-mode' : ''}`}
          onClick={(e) => {
            // 點擊空白區域取消多選（不是點到卡片或按鈕上）
            if (selectedCardIds.length > 0 && !(e.target as HTMLElement).closest('.card-gallery-item') && !(e.target as HTMLElement).closest('button')) {
              setSelectedCardIds([]);
            }
          }}
        >
          {/* Tag 篩選區 */}
          {(tagStats.length > 0 || selectedTags.length > 0 || dateFields.length > 0 || dateRangeFields.length > 0 || ratingFields.length > 0 || locationFieldInfo.hasLocation) && (
            <div className="card-gallery-tags-wrapper">
              <div className="card-gallery-tags custom-scrollbar-wrapper" ref={tagsContainerRef}>
                {/* 視圖模式切換按鈕 - 循環切換：地圖（有時）=> 列表 => 卡片 => 地圖（有時） */}
                <button
                  className="card-gallery-view-toggle-btn"
                  onClick={() => {
                    // 循環順序：map -> list -> grid -> map（如果有地圖）或 list -> grid -> list（沒有地圖）
                    if (viewMode === 'map') {
                      setViewMode('list');
                    } else if (viewMode === 'list') {
                      setViewMode('grid');
                    } else if (viewMode === 'grid') {
                      setViewMode(locationFieldInfo.hasLocation ? 'map' : 'list');
                    } else {
                      setViewMode('grid');
                    }
                  }}
                >
                  {/* 顯示下一個模式的圖標 */}
                  {viewMode === 'map' && <ListIcon />}
                  {viewMode === 'list' && <GridIcon />}
                  {viewMode === 'grid' && (locationFieldInfo.hasLocation ? <MapIcon /> : <ListIcon />)}
                  {/* 顯示下一個模式的文字 */}
                  {viewMode === 'map' && t('listView')}
                  {viewMode === 'list' && t('cardView')}
                  {viewMode === 'grid' && (locationFieldInfo.hasLocation ? t('mapView') : t('listView'))}
                </button>
                {/* 預覽按鈕 - 在列表或地圖模式且非手機版顯示 */}
                {(viewMode === 'list' || viewMode === 'map') && !isMobileView && (
                  <button
                    className={`card-gallery-view-toggle-btn ${isCardInfoPanelOpen ? 'active' : ''}`}
                    onClick={() => setIsCardInfoPanelOpen(!isCardInfoPanelOpen)}
                  >
                    <InfoIcon />
                    {t('preview')}
                  </button>
                )}
                {/* 排序選擇器 - 只在有日期、日期區間或評分欄位時顯示，地圖和列表模式下隱藏 */}
                {viewMode === 'grid' && (dateFields.length > 0 || dateRangeFields.length > 0 || ratingFields.length > 0) && (
                  <div className="card-gallery-sort-wrapper" ref={sortDropdownRef}>
                    <button
                      className={`card-gallery-sort-btn ${sortMode !== 'none' ? 'active' : ''}`}
                      onClick={handleSortButtonClick}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M3 6h18M6 12h12M9 18h6" />
                      </svg>
                      {sortMode === 'none' ? t('sort') : (() => {
                        const { type, direction, fieldName } = parsedSortMode;
                        if (type === 'date') {
                          if (direction === 'desc') return t('sortByFieldNewest', { field: fieldName });
                          if (direction === 'asc') return t('sortByFieldOldest', { field: fieldName });
                          if (direction === 'notexpired') return t('sortByFieldNotExpired', { field: fieldName });
                          if (direction === 'expired') return t('sortByFieldExpired', { field: fieldName });
                        } else if (type === 'daterange') {
                          if (direction === 'forward') return t('sortByFieldForward', { field: fieldName });
                          if (direction === 'backward') return t('sortByFieldBackward', { field: fieldName });
                          if (direction === 'notexpired') return t('sortByFieldNotExpired', { field: fieldName });
                          if (direction === 'expired') return t('sortByFieldExpired', { field: fieldName });
                        } else if (type === 'rating') {
                          if (direction === 'desc') return t('sortByAvgHighest', { field: fieldName });
                          if (direction === 'reviewcount') return t('sortByReviewCount', { field: fieldName });
                        }
                        return t('sort');
                      })()}
                      <svg className="card-gallery-sort-arrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="6 9 12 15 18 9"></polyline>
                      </svg>
                    </button>
                  </div>
                )}
                {/* 排序選單 - 使用 PopupMenu（手機版自動轉底部 panel） */}
                {showSortDropdown && (
                  <PopupMenu
                    x={sortMenuPosition.x}
                    y={sortMenuPosition.y}
                    onClose={() => setShowSortDropdown(false)}
                    className="card-gallery-sort-popup"
                    title={t('sort')}
                  >
                    <div
                      className={`card-gallery-sort-option ${sortMode === 'none' ? 'active' : ''}`}
                      onClick={() => { setSortMode('none'); setShowSortDropdown(false); }}
                    >
                      {t('noSort')}
                    </div>
                    {/* 為每個日期欄位生成排序選項 */}
                    {dateFields.map(fieldName => (
                      <React.Fragment key={`date-${fieldName}`}>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `date_desc_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`date_desc_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldNewest', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `date_asc_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`date_asc_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldOldest', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `date_notexpired_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`date_notexpired_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldNotExpired', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `date_expired_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`date_expired_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldExpired', { field: fieldName })}
                        </div>
                      </React.Fragment>
                    ))}
                    {/* 為每個日期區間欄位生成排序選項（簡化為 4 個） */}
                    {dateRangeFields.map(fieldName => (
                      <React.Fragment key={`daterange-${fieldName}`}>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `daterange_forward_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`daterange_forward_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldForward', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `daterange_backward_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`daterange_backward_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldBackward', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `daterange_notexpired_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`daterange_notexpired_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldNotExpired', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `daterange_expired_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`daterange_expired_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByFieldExpired', { field: fieldName })}
                        </div>
                      </React.Fragment>
                    ))}
                    {/* 為每個評分欄位生成排序選項（以平均評分排序） */}
                    {ratingFields.map(fieldName => (
                      <React.Fragment key={`rating-${fieldName}`}>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `rating_desc_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`rating_desc_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByAvgHighest', { field: fieldName })}
                        </div>
                        <div
                          className={`card-gallery-sort-option ${sortMode === `rating_reviewcount_${fieldName}` ? 'active' : ''}`}
                          onClick={() => { setSortMode(`rating_reviewcount_${fieldName}`); setShowSortDropdown(false); }}
                        >
                          {t('sortByReviewCount', { field: fieldName })}
                        </div>
                      </React.Fragment>
                    ))}
                  </PopupMenu>
                )}

                {/* 已選中的 tag（始終顯示在最前面） */}
                {selectedTags.map(tag => (
                  <button
                    key={`selected-${tag.fieldName}-${tag.value}`}
                    className="card-gallery-tag active"
                    onClick={() => {
                      setSelectedTags(prev => prev.filter(t => !(t.fieldName === tag.fieldName && t.value === tag.value)));
                    }}
                  >
                    {tag.value} ✕
                  </button>
                ))}
                {/* 未選中的 tag */}
                {tagStats
                  .filter(tag => !selectedTags.some(t => t.fieldName === tag.fieldName && t.value === tag.value))
                  .map(tag => (
                    <button
                      key={`${tag.fieldName}-${tag.value}`}
                      className="card-gallery-tag"
                      onClick={() => {
                        setSelectedTags(prev => [...prev, { fieldName: tag.fieldName, value: tag.value }]);
                      }}
                    >
                      {tag.value} <span className="card-gallery-tag-count">({tag.count})</span>
                    </button>
                  ))}
              </div>

              {/* 漸層遮罩 - 只在有溢出時顯示 */}
              {hasTagsOverflow && (
                <div className="card-gallery-tags-fade"></div>
              )}
            </div>
          )}

          {viewMode === 'map' && locationFieldInfo.hasLocation ? (
            /* 地圖視圖 */
            <CardGalleryMapView
              cards={folderCards}
              cardType={cardType}
              onCardClick={(card) => {

                if (card === null) {
                  // 傳 null 表示關閉 infoPanel

                  setIsCardInfoPanelOpen(false);
                } else if (!isCardInfoPanelOpen) {
                  // 點擊地標：如果預覽沒開則打開

                  setIsCardInfoPanelOpen(true);
                }
              }}
              onCardHover={(card) => {

                // hover 地標時更新預覽卡片
                if (card) {
                  setHoveredCard(card);
                }
              }}
              onContextMenu={(e, card) => handleCardRightClick(e, card)}
              isInfoPanelOpen={isCardInfoPanelOpen}
              theme={theme}
              onFieldChange={async (card, fieldName, newValue) => {
                try {
                  await updateCard({
                    ...card,
                    cardFields: { ...card.cardFields, [fieldName]: newValue }
                  });
                } catch (error) {
                  console.error('更新卡片失敗:', error);
                  setTempHint(t('updateFailed'));
                }
              }}
              onReviewChange={async (card, rating) => {
                const myRev = getMyReview(card.id, currentMemberID);
                const hasComment = myRev?.comment?.trim().length > 0;
                if (!hasComment) {
                  useDialogStore.getState().open('writeReview', {
                    cardName: card.name ?? '',
                    initialRating: rating,
                    initialComment: '',
                    onSubmit: async ({ rating: r, comment }) => {
                      try {
                        await upsertReview(card.id, currentMemberID, r, comment);
                      } catch (error) {
                        console.error('更新評分失敗:', error);
                        setTempHint(t('updateFailed'));
                      }
                    },
                  });
                  return;
                }
                try {
                  await upsertReview(card.id, currentMemberID, rating, myRev.comment);
                } catch (error) {
                  console.error('更新評分失敗:', error);
                  setTempHint(t('updateFailed'));
                }
              }}
              canRate={myPermission >= Permission.contributor}
              fetchMemberInfo={fetchMemberInfo}
              currentMemberID={currentMemberID}
              onBubbleClick={(card) => {
                useDialogStore.getState().open('reviewsList', {
                  card,
                  currentMemberID,
                  currentUserInfo,
                  membersInfoMap,
                  fetchMemberInfo,
                  canReview,
                  canDeleteOthersReview,
                  isLoggedIn,
                  onActorClick: handleOpenContributorsDialog,
                });
              }}
              onAvatarClick={() => handleOpenContributorsDialog()}
            />
          ) : viewMode === 'list' ? (
            /* 列表視圖 - wrapper 處理 padding，讓滾動容器無 padding 以確保 sticky 正常 */
            <div className="card-list-view-wrapper">
              <CardListView
                cards={folderCards}
                cardType={cardType}
                canEdit={canReorderCards}
                canRate={myPermission >= Permission.contributor}
                currentMemberID={currentMemberID}
                onCardClick={(card) => {
                  // 列表模式點擊行打開編輯對話框
                  useDialogStore.getState().open('addCard', {
                    cardType, editCard: card,
                  });
                }} onCardHover={(card) => {
                  // 列表模式 hover 時更新預覽卡片（只在有卡片時更新，離開時保持最後一張）
                  if (card) {
                    setHoveredCard(card);
                  }
                }}
                onContextMenu={(e, card) => handleCardRightClick(e, card)}
                onRatingChange={async (card, rating) => {
                  const myRev = getMyReview(card.id, currentMemberID);
                  const hasComment = myRev?.comment?.trim().length > 0;
                  if (!hasComment) {
                    useDialogStore.getState().open('writeReview', {
                      cardName: card.name ?? '',
                      initialRating: rating,
                      initialComment: '',
                      onSubmit: async ({ rating: r, comment }) => {
                        try {
                          await upsertReview(card.id, currentMemberID, r, comment);
                        } catch (error) {
                          console.error('更新評分失敗:', error);
                          setTempHint(t('updateFailed'));
                        }
                      },
                    });
                    return;
                  }
                  try {
                    await upsertReview(card.id, currentMemberID, rating, myRev.comment);
                  } catch (error) {
                    console.error('更新評分失敗:', error);
                    setTempHint(t('updateFailed'));
                  }
                }}
                onCardUpdate={async (card, fieldName, newValue) => {
                  try {
                    await updateCard({
                      ...card,
                      cardFields: { ...card.cardFields, [fieldName]: newValue }
                    });
                  } catch (error) {
                    console.error('更新卡片欄位失敗:', error);
                  }
                }}
                onCardReorder={async (movedCard, prevCard, nextCard) => {
                  const newOrderAt = calculateNewOrderAt(prevCard, nextCard);
                  try {
                    await updateCard({
                      ...movedCard,
                      orderAt: newOrderAt
                    });
                  } catch (error) {
                    console.error('更新卡片排序失敗:', error);
                  }
                }}
                onFieldsReorder={async (newFields) => {
                  // 更新 CardType 的 cardFieldsDef 順序
                  if (!cardType || myPermission < Permission.editor) return;
                  try {
                    await updateCardFolder({
                      ...cardType,
                      cardFieldsDef: newFields
                    });
                  } catch (error) {
                    console.error('更新欄位順序失敗:', error);
                  }
                }}
                isMobileView={isMobileView}
              />
            </div>
          ) : folderCards.length === 0 && (searchQuery || selectedTags.length > 0) ? (
            <div className="card-gallery-empty">
              <p>{t('noSearchResults')}</p>
            </div>
          ) : (
            <FlipMove
              key={flipMoveKey}
              className="card-gallery-grid"
              duration={isDragging ? 150 : 250}
              easing="cubic-bezier(0.25, 0.1, 0.25, 1)"
              enterAnimation={false}
              leaveAnimation={flipMoveLeaveAnimation}
            >
              {folderCards.map((card, index) => renderCard(card, index))}
              {/* 新增卡片按鈕 - 尺寸與卡片模板一致，手機版隱藏 */}
              {!isMobileView && (
                <div
                  key="add-card-button"
                  className="card-gallery-add-card-wrapper"
                  onClick={handleAddCardClick}
                >
                  {/* 隱藏的 CardRenderer 用於撐開尺寸 */}
                  <div className="card-gallery-add-card-sizer">
                    <CardRenderer
                      templateHtml={(cardType as any)?.templateHtml ?? (cardType as any)?.templateHtml}
                      templateCss={(cardType as any)?.templateCss ?? (cardType as any)?.templateCss}
                      fields={((cardType as any)?.cardFieldsDef ?? (cardType as any)?.fields) || []}
                      cardData={null}
                    />
                  </div>
                  {/* 新增按鈕覆蓋層 */}
                  <div className="card-gallery-add-card-overlay">
                    <div className="card-gallery-add-card-icon">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                      </svg>
                    </div>
                    <span className="card-gallery-add-card-text">{t('addCard')}</span>
                    <span className="card-gallery-add-card-hint">{t('galleryDragHint')}</span>
                  </div>
                </div>
              )}
            </FlipMove>
          )}
        </div>

        {/* Info Panel - 使用 class 控制顯示，實現平滑動畫 */}
        <div className={`card-gallery-info-panel ${shouldShowInfoPanel ? '' : 'closed'}`}>
          {cardType && (
            <div className="card-gallery-info-scroll-container">
              {/* 卡片預覽區 - 複用 card-preview-container 樣式 */}
              <div className="card-gallery-info-preview">
                <div className="card-preview-container">
                  <CardRenderer
                    templateHtml={(cardType as any).templateHtml}
                    templateCss={(cardType as any).templateCss}
                    fields={(cardType as any).cardFieldsDef || []}
                    cardData={(viewMode === 'list' || viewMode === 'map') && hoveredCard ? hoveredCard : null}
                    currentMemberID={currentMemberID}
                    onFieldChange={hoveredCard ? async (fieldName, newValue) => {
                      try {
                        await updateCard({
                          ...hoveredCard,
                          cardFields: { ...hoveredCard.cardFields, [fieldName]: newValue }
                        });
                      } catch (error) {
                        console.error('更新卡片失敗:', error);
                        setTempHint(t('updateFailed'));
                      }
                    } : undefined}
                    onReviewChange={hoveredCard ? async (rating) => {
                      const myRev = getMyReview(hoveredCard.id, currentMemberID);
                      const hasComment = myRev?.comment?.trim().length > 0;
                      if (!hasComment) {
                        useDialogStore.getState().open('writeReview', {
                          cardName: hoveredCard.name ?? '',
                          initialRating: rating,
                          initialComment: '',
                          onSubmit: async ({ rating: r, comment }) => {
                            const targetCardId = hoveredCard.id;
                            try {
                              await upsertReview(targetCardId, currentMemberID, r, comment);
                              const fresh = useItemStore.getState().byType['CARD']?.find((c: any) => c.id === targetCardId);
                              if (fresh) setHoveredCard(fresh);
                            } catch (error) {
                              console.error('更新評分失敗:', error);
                              setTempHint(t('updateFailed'));
                            }
                          },
                        });
                        return;
                      }
                      const targetCardId = hoveredCard.id;
                      try {
                        await upsertReview(targetCardId, currentMemberID, rating, myRev.comment);
                        const fresh = useItemStore.getState().byType['CARD']?.find((c: any) => c.id === targetCardId);
                        if (fresh) setHoveredCard(fresh);
                      } catch (error) {
                        console.error('更新評分失敗:', error);
                        setTempHint(t('updateFailed'));
                      }
                    } : undefined}
                    canRate={myPermission >= Permission.contributor}
                  />
                </div>
              </div>

              {/* 留言區域 - 有 hoveredCard 時顯示 */}
              {hoveredCard && (
                <div className="card-gallery-info-reviews">
                  <ReviewsListDialog
                    card={hoveredCard}
                    currentMemberID={currentMemberID}
                    currentUserInfo={currentUserInfo}
                    membersInfoMap={membersInfoMap}
                    fetchMemberInfo={fetchMemberInfo}
                    canReview={canReview}
                    canDeleteOthersReview={canDeleteOthersReview}
                    onActorClick={handleOpenContributorsDialog}
                    onAddReview={(card) => {
                      if (!isLoggedIn) {
                        setIsCardInfoPanelOpen(false);
                        useDialogStore.getState().open('login', { message: t('loginDialogReviewContent') });
                        return;
                      }
                      useDialogStore.getState().open('writeReview', {
                        cardName: card.name ?? '',
                        initialRating: 0,
                        initialComment: getMyReview(card.id, currentMemberID)?.comment || '',
                        onSubmit: async ({ rating: r, comment }) => {
                          try {
                            await upsertReview(card.id, currentMemberID, r, comment);
                            const fresh = useItemStore.getState().byType['CARD']?.find((c: any) => c.id === hoveredCard.id);
                            if (fresh) setHoveredCard(fresh);
                          } catch (error) {
                            console.error('更新評分失敗:', error);
                            setTempHint(t('updateFailed'));
                          }
                        },
                      });
                    }}
                    onEditReview={(reviewMemberId, reviewData) => {
                      useDialogStore.getState().open('writeReview', {
                        cardName: hoveredCard?.name ?? '',
                        initialRating: reviewData.rating || 0,
                        initialComment: reviewData.comment || '',
                        onSubmit: async ({ rating: r, comment }) => {
                          if (!hoveredCard) return;
                          try {
                            await upsertReview(hoveredCard.id, reviewMemberId, r, comment);
                            const fresh = useItemStore.getState().byType['CARD']?.find((c: any) => c.id === hoveredCard.id);
                            if (fresh) setHoveredCard(fresh);
                          } catch (error) {
                            console.error('更新評分失敗:', error);
                            setTempHint(t('updateFailed'));
                          }
                        },
                      });
                    }}
                    onDeleteReview={async (reviewMemberId) => {
                      try {
                        await deleteReview(hoveredCard.id, reviewMemberId);
                        const fresh = useItemStore.getState().byType['CARD']?.find((c: any) => c.id === hoveredCard.id);
                        if (fresh) setHoveredCard(fresh);
                      } catch (error) {
                        console.error('刪除留言失敗:', error);
                        setTempHint(t('deleteFailed'));
                      }
                    }}
                  />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Edit History Panel - 所有模式都可顯示 */}
        <EditHistoryPanel
          isOpen={showEditHistoryPanel}
          onClose={() => setShowEditHistoryPanel(false)}
          folderId={cardType?.id}
          existingCards={baseCards}
          onCardClick={handleOpenCardShowDialog}
          onActorClick={handleOpenContributorsDialog}
        />

        {/* Edit History Panel - 所有模式都可顯示 */}
      </div>

      {/* 手機版選單 */}
      {mobileMenuPosition && (
        <PopupMenu
          x={mobileMenuPosition.x}
          y={mobileMenuPosition.y}
          onClose={() => setMobileMenuPosition(null)}
        >
          <PopupMenuItem
            icon={SearchIcon}
            onClick={() => {
              // 移動端先打開鍵盤
              if (window.focusHiddenInput) {
                window.focusHiddenInput();
              }
              setMobileMenuPosition(null);
              setIsMobileSearchOpen(true);
              safeSetTimeout(() => mobileSearchInputRef.current?.focus(), 100);
            }}
          >
            {t('search')}
          </PopupMenuItem>
          <PopupMenuItem
            icon={EditIcon}
            onClick={() => {
              setMobileMenuPosition(null);
              openEditTemplateDialog();
            }}
          >
            {t('editTemplate')}
          </PopupMenuItem>
          <PopupMenuItem
            icon={DeleteIcon}
            danger
            onClick={() => {
              setMobileMenuPosition(null);
              // 調用 DeleteFolderDialog 顯示確認對話框
              if (selectedCardFolder) {
                useDialogStore.getState().open('deleteFolder', {
                  folder: {
                    ...selectedCardFolder,
                    name: selectedCardFolder.name,
                    isCardFolder: true,
                    isGroup: false
                  }
                });
              }
            }}
          >
            {t('deleteCardFolder')}
          </PopupMenuItem>
        </PopupMenu>
      )}




      {/* More 選單 - 分享模式且已登入時顯示 */}
      {showMoreMenu && (
        <PopupMenu
          x={moreMenuPosition.x}
          y={moreMenuPosition.y}
          onClose={() => useMenuStore.getState().close('cardGalleryMore')}
        >
          {isMobileView && myPermission >= Permission.contributor && (
            <div className="card-gallery-more-menu-share-wrapper">
              <PopupMenuItem
                icon={ShareIcon}
                onClick={() => {
                  useMenuStore.getState().close('cardGalleryMore');
                  openGalleryShareSettings();
                }}
              >
                {t('share')}
              </PopupMenuItem>
            </div>
          )}

          {myPermission >= Permission.editor && (
            <PopupMenuItem
              icon={EditIcon}
              onClick={() => {
                openEditTemplateDialog();
                useMenuStore.getState().close('cardGalleryMore');
              }}
            >
              {t('editTemplate')}
            </PopupMenuItem>
          )}

          {myPermission >= Permission.editor && (
            <PopupMenuItem
              icon={FileDownIcon}
              onClick={() => {
                if (exportLoading || folderCards.length === 0) return;
                exportCSV();
                useMenuStore.getState().close('cardGalleryMore');
              }}
            >
              {exportLoading ? t('exporting') : t('exportCSV')}
            </PopupMenuItem>
          )}

          <PopupMenuItem
            icon={HistoryIcon}
            onClick={() => {
              setShowEditHistoryPanel(true);
              useMenuStore.getState().close('cardGalleryMore');
            }}
          >
            {t('viewEditHistory')}
          </PopupMenuItem>

          {myPermission === Permission.guest && (
            <PopupMenuItem
              icon={CopyIcon}
              onClick={() => {
                useMenuStore.getState().close('cardGalleryMore');
                useDialogStore.getState().open('login', { message: t('loginDialogFavoriteContent') });
              }}
            >
              {t('copyToMyDatabase')}
            </PopupMenuItem>
          )}

          {myPermission === Permission.owner && (
            <>
              <PopupMenuDivider />
              <PopupMenuItem
                icon={DeleteIcon}
                onClick={() => {
                  if (selectedCardFolder) {
                    useDialogStore.getState().open('deleteFolder', {
                      folder: {
                        ...selectedCardFolder,
                        name: selectedCardFolder.name,
                        isCardFolder: true,
                        isGroup: false
                      }
                    });
                  }
                  useMenuStore.getState().close('cardGalleryMore');
                }}
                danger
              >
                {t('deleteCardFolder')}
              </PopupMenuItem>
            </>
          )}
        </PopupMenu>
      )}


      {/* 卡片右鍵選單（使用 PopupMenu，手機版自動轉底部 panel） */}
      {contextMenu.visible && (
        <PopupMenu
          x={contextMenu.x}
          y={contextMenu.y}
          onClose={closeContextMenu}
          className="card-context-popup-menu"
        >
          {/* 1. 自動補完空白欄位（有空白欄位時顯示，點擊後檢查權限） */}
          {contextMenu.card && hasEmptyFields(contextMenu.card) && (
            <div className="popup-menu-item" onClick={() => {
              if (myPermission < Permission.contributor) {
                closeContextMenu();
                setTempHint(t('permissionRequired'));
                return;
              }
              handleAutoComplete();
            }}>
              <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path>
              </svg>
              {t('autoCompleteFields')}
            </div>
          )}
          {/* 1.5. 新增留言（自己沒有留言時顯示） */}
          {contextMenu.card && !getMyReview(contextMenu.card.id, currentMemberID)?.comment?.trim() && (
            <div className="popup-menu-item" onClick={() => {
              const card = contextMenu.card;
              closeContextMenu();
              useDialogStore.getState().open('writeReview', {
                cardName: card.name ?? '',
                initialRating: 0,
                initialComment: '',
                onSubmit: async ({ rating: r, comment }) => {
                  try {
                    await upsertReview(card.id, currentMemberID, r, comment);
                  } catch (error) {
                    console.error('更新評分失敗:', error);
                    setTempHint(t('updateFailed'));
                  }
                },
              });
            }}>
              <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                <line x1="12" y1="8" x2="12" y2="14"></line>
                <line x1="9" y1="11" x2="15" y2="11"></line>
              </svg>
              {t('addComment')}
            </div>
          )}
          {/* 2. 複製欄位（僅在欄位上右鍵時顯示） */}
          {contextMenu.fieldName && (
            <div className="popup-menu-item" onClick={handleContextMenuCopy}>
              <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
              {t('copy')} {contextMenu.fieldName}
            </div>
          )}
          {/* 3. 複製卡片資訊（所有人都可使用） */}
          <div className="popup-menu-item" onClick={handleContextMenuCopyCardInfo}>
            <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
            {t('copyCardInfo')}
          </div>
          {/* 4. 編輯卡片（點擊後檢查權限）- 列表模式不顯示 */}
          {viewMode !== 'list' && (
            <div className="popup-menu-item" onClick={() => {
              // 檢查權限（後端會驗證是否為創建者）
              if (myPermission < Permission.contributor) {
                closeContextMenu();
                setTempHint(t('permissionRequired'));
                return;
              }
              handleContextMenuEdit();
            }}>
              <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
              {t('editCard')}
            </div>
          )}
          {/* 5. 複製連結 */}
          <div className="popup-menu-item" onClick={handleContextMenuCopyLink}>
            <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
            </svg>
            {t('copyCardLink')}
          </div>
          {/* 6. 刪除卡片（有權限時才顯示，後端會驗證是否為創建者） */}
          {myPermission >= Permission.contributor && (
            <div className="popup-menu-item popup-menu-item--danger" onClick={handleContextMenuDelete}>
              <svg className="popup-menu-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
              {t('deleteCard')}
            </div>
          )}
        </PopupMenu>
      )}

      {/* 圖片拖曳遮罩 */}
      {isImageDragOver && (
        <div
          className="card-gallery-drag-overlay"
          onDragOver={(e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
            setIsDraggingImageOver(true);
          }}
          onDragLeave={() => {
            setIsDraggingImageOver(false);
          }}
          onDrop={handleImageDropToGallery}
        >
          <div className={`card-gallery-drag-message ${isDraggingImageOver ? 'dragging-over' : ''}`}>
            <div className="card-gallery-drag-icon">📷</div>
            <div className="card-gallery-drag-text">
              {t('dragToRecognizeCard')}
            </div>
          </div>
        </div>
      )}

      {/* 複選操作提示 */}
      <CustomHint
        show={selectedCardIds.length > 1}
        buttons={[
          {
            text: t('delete'),
            type: 'error',
            onClick: () => useDialogStore.getState().open('deleteCardConfirm', {
              count: selectedCardIds.length,
              onConfirm: async () => {
                try {
                  const selectedCards = folderCards.filter(c => selectedCardIds.includes(c.id));
                  await deleteCard(selectedCards);
                  setTempHint(t('cardsDeleted', { count: selectedCardIds.length }) || `已刪除 ${selectedCardIds.length} 張卡片`);
                } catch (error) {
                  console.error('批量刪除失敗:', error);
                  setTempHint(t('deleteFailed'));
                }
                setSelectedCardIds([]);
              },
            })
          }
        ]}
      >
        {t('selectedCardsHint', { count: selectedCardIds.length }) || `已選取 ${selectedCardIds.length} 張卡片`}
      </CustomHint>


    </div>
  );
}

export default CardGallery;
