import React from 'react';
import CardRenderer from '../../common/CardRenderer';
import { useCardsStore } from './cardStore';
import { useItemStore } from '../../../Store/itemStore';
import type { WindowComponentProps } from '../../../workspace/windowComponentRegistry';
import '../../../CardWindowContent.css';

function CardWindowContent({ itemId }: WindowComponentProps) {
    const cards = useItemStore(state => state.getByType('CARD'));
    const cardFolders = useItemStore(state => state.getByType('CARD_FOLDER'));
    const updateCard = useCardsStore(state => state.updateCard);

    const card = cards.find(c => c.id === itemId);
    const cardType = card
        ? cardFolders.find(f => f.id === card.parentID)
        : null;

    if (!card || !cardType) {
        return <div className="card-window-error">找不到卡片</div>;
    }

    return (
        <div className="card-window-content">
            <div className="card-window-renderer-wrapper">
                <CardRenderer
                    templateHtml={(cardType as any).templateHtml}
                    templateCss={(cardType as any).templateCss}
                    fields={cardType.cardFieldsDef}
                    cardData={card}
                    onFieldChange={(fieldName: string, newValue: any) => {
                        updateCard({
                            ...card,
                            cardFields: {
                                ...card.cardFields,
                                [fieldName]: newValue,
                            },
                            updatedAt: Date.now(),
                        });
                    }}
                />
            </div>
        </div>
    );
}

export default CardWindowContent;
