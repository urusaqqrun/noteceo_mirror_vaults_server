# Backend Service 開發參考

本文件說明如何在插件目錄的 `backend/` 子目錄中建立後端服務。

## 目錄結構

```
plugins/<插件目錄>/
├── frontend/          ← 前端插件（見 REFERENCE_STANDALONE.md / REFERENCE_PATCH.md）
└── backend/
    ├── package.json
    ├── src/
    │   └── index.ts   ← 入口檔
    ├── manifest.json   ← 服務描述檔（必要）
    └── dist/
        └── index.js   ← esbuild 編譯產出
```

## 必須使用 @cubelv/service-sdk

```typescript
import { createService } from '@cubelv/service-sdk';

const { app, start } = createService({ name: 'my-service' });

app.post('/webhook/telegram', (req, res) => {
  res.json({ ok: true });
});

app.get('/api/status', (req, res) => {
  res.json({ status: 'running' });
});

start();
```

## 環境變數

| 變數 | 說明 |
|------|------|
| `PORT` | 服務監聽埠（系統指派，不要硬編碼） |
| `CUBELV_MEMBER_ID` | 會員 ID |
| `CUBELV_SERVICE_DIR` | 服務目錄名 |

## manifest.json（必要）

```json
{
  "name": "服務名稱",
  "version": "1.0.0",
  "endpoints": [
    {
      "path": "/webhook/telegram",
      "method": "POST",
      "public": true,
      "webhook_secret_header": "X-Telegram-Bot-Api-Secret-Token",
      "webhook_secret_value": "由用戶提供的 secret"
    },
    {
      "path": "/api/status",
      "method": "GET",
      "public": false
    }
  ]
}
```

- `public: true` — 不需登入即可存取（webhook 用），必須配 `webhook_secret_header` + `webhook_secret_value`
- `public: false` — 需要登入，只有服務擁有者可存取

## 服務 URL（重要 — 前端必須用此格式呼叫後端）

後端 service 由平台自動部署和管理，前端透過 `/svc/` 路徑呼叫。

**URL 格式**：`{apiBase}/svc/{memberID}/{插件目錄名}/{endpoint}`

前端呼叫範例（在 React 元件或 store 中使用）：

```typescript
/**
 * PLUGIN_DIR 必須是「用戶訊息第一行給你的完整目錄名」，
 * 例如 '匿名留言板-3f8fc9'（含 Unicode 和 hash）。
 * 不能用 codeStem、不能用縮寫、不能自己取名。
 * 錯誤範例：'msgboard'、'message-board'、'guestbook'
 * 正確範例：'匿名留言板-3f8fc9'（完整目錄名）
 */
const PLUGIN_DIR = '匿名留言板-3f8fc9';  // ← 替換為系統給你的完整目錄名

function getBackendBase(): string {
    const apiBase = (window as any).__NC_API_BASE__ || 'https://dev.cubelv.com';
    const token = localStorage.getItem('accessToken') || '';
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const memberID = payload.sub || payload.memberID;
        return `${apiBase}/svc/${memberID}/${PLUGIN_DIR}`;
    } catch {
        return `${apiBase}/svc/unknown/${PLUGIN_DIR}`;
    }
}

// 使用
const base = getBackendBase();
const resp = await fetch(`${base}/api/messages`);
```

**注意**：
- **必須**使用 `(window as any).__NC_API_BASE__ || 'https://dev.cubelv.com'` 作為 host
- **禁止**用相對路徑 `/svc/...`（Electron 桌面版沒有 proxy，會打到 localhost）
- **禁止**硬編碼 memberID
- **PLUGIN_DIR 必須是系統提供的完整目錄名**（如 `匿名留言板-3f8fc9`），不能用 codeStem 或英文縮寫（如 `msgboard`）

## 建置流程

```bash
npm install --production --no-audit --no-fund --prefix {WORK_DIR}/plugins/{目錄名}/backend/

npx --prefix {WORK_DIR}/plugins/{目錄名}/backend/ esbuild \
  {WORK_DIR}/plugins/{目錄名}/backend/src/index.ts \
  --bundle --platform=node --target=node20 \
  --outfile={WORK_DIR}/plugins/{目錄名}/backend/dist/index.js
```

## 限制

- 每個服務最大記憶體 128MB
- idle 5 分鐘自動關閉（有新請求時自動重啟）
- 不保證長駐，不要依賴 in-memory 狀態
- 需要持久化的資料用外部服務（資料庫、Redis、S3 等）
- Bash 命令一律使用絕對路徑
