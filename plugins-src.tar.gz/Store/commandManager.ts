// ===== CommandManager — 集中式快捷鍵管理（Obsidian addCommand 做法）=====
//
// 全局唯一 keydown listener，各 Plugin 用 register() 註冊 command + 快捷鍵。
// checkCallback(true) → 能否執行？ checkCallback(false) → 執行。
// 用戶可在設定頁覆蓋預設快捷鍵，持久化到 localStorage。

import { create } from 'zustand';

// ===== 型別 =====

export interface HotkeyDef {
    modifiers: ('Mod' | 'Shift' | 'Alt')[];
    key: string; // 'Enter', 'N', 'Backspace', 'ArrowUp', 'Escape', etc.
}

export interface Command {
    id: string;
    name: string;
    /** checking=true → 回傳能否執行；checking=false → 執行。二合一。 */
    checkCallback?: (checking: boolean) => boolean;
    /** 簡化版：無需 check，直接執行 */
    callback?: () => void;
}

export interface CommandBinding {
    command: Command;
    hotkeys: HotkeyDef[];
    /** 動態啟用條件：每次 keydown 先呼叫，回傳 false 則跳過此 command。
     *  用於 overlay/dialog 等永遠掛載的元件，避免搶佔其他 command 的快捷鍵。
     *  與 checkCallback 的差別：enabled 判斷「此 command 是否在當前情境下有意義」，
     *  checkCallback 判斷「能否立即執行（焦點、選取等細節）」。 */
    enabled?: () => boolean;
}

/** 永久保存的 command 定義（不隨元件 unmount 消失） */
export interface CommandSchema {
    id: string;
    name: string;
    hotkeys: HotkeyDef[];
}

/** 鍵盤觀察器：被動觀察 keydown/keyup，不消費事件。用於修飾鍵追蹤。 */
export interface KeyObserverBinding {
    id: string;
    keys: string[];
    onDown?: (key: string, event: KeyboardEvent) => void;
    onUp?: (key: string) => void;
}

// ===== Store =====

interface CommandManagerState {
    commands: Map<string, CommandBinding>;
    /** 永久 schema（register 時寫入，unregister 不刪） */
    commandSchemas: Map<string, CommandSchema>;
    /** 用戶自訂覆蓋（持久化到 localStorage） */
    userOverrides: Map<string, HotkeyDef[]>;
    /** 鍵盤觀察器（keydown/keyup 旁路，不消費事件） */
    keyObservers: Map<string, KeyObserverBinding>;
    /** 暫停快捷鍵攔截（錄製模式用） */
    paused: boolean;

    /** 註冊 command。有 handler（callback/checkCallback）→ 加入 commands + schema；無 handler → 僅寫 schema（Plugin onload 預註冊用）。 */
    register(binding: CommandBinding): () => void;
    /** 註冊鍵盤觀察器（keydown/keyup 旁路，不消費事件），返回 unsubscribe */
    registerKeyObserver(binding: KeyObserverBinding): () => void;
    execute(id: string): boolean;
    getAll(): CommandBinding[];
    /** 取得所有已知 command schema（含已 unmount 的） */
    getAllSchemas(): CommandSchema[];
    /** 用戶在設定裡改快捷鍵 */
    setHotkeys(commandId: string, hotkeys: HotkeyDef[]): void;
    /** 重置某 command 的快捷鍵為預設值 */
    resetHotkeys(commandId: string): void;
    /** 取得生效的快捷鍵（user override > default） */
    getHotkeys(commandId: string): HotkeyDef[];
    /** 暫停 / 恢復快捷鍵攔截 */
    setPaused(paused: boolean): void;
}

export const useCommandManager = create<CommandManagerState>((set, get) => ({
    commands: new Map(),
    commandSchemas: new Map(),
    userOverrides: loadOverrides(),
    keyObservers: new Map(),
    paused: false,

    register(binding) {
        const hasHandler = !!(binding.command.checkCallback || binding.command.callback);

        // 永遠寫入 schema
        set(s => {
            const nextSchemas = new Map(s.commandSchemas);
            nextSchemas.set(binding.command.id, {
                id: binding.command.id,
                name: binding.command.name,
                hotkeys: binding.hotkeys,
            });
            if (!hasHandler) return { commandSchemas: nextSchemas };
            const next = new Map(s.commands);
            next.set(binding.command.id, binding);
            return { commands: next, commandSchemas: nextSchemas };
        });

        if (!hasHandler) return () => {};
        return () => set(s => {
            const next = new Map(s.commands);
            next.delete(binding.command.id);
            return { commands: next };
        });
    },

    registerKeyObserver(binding) {
        set(s => {
            const next = new Map(s.keyObservers);
            next.set(binding.id, binding);
            return { keyObservers: next };
        });
        return () => set(s => {
            const next = new Map(s.keyObservers);
            next.delete(binding.id);
            return { keyObservers: next };
        });
    },

    execute(id) {
        const binding = get().commands.get(id);
        if (!binding) return false;
        if (binding.enabled && !binding.enabled()) return false;
        const { command } = binding;
        if (command.checkCallback) {
            if (!command.checkCallback(true)) return false;
            command.checkCallback(false);
            return true;
        }
        if (command.callback) {
            command.callback();
            return true;
        }
        return false;
    },

    getAll: () => [...get().commands.values()],

    getAllSchemas: () => [...get().commandSchemas.values()],

    setHotkeys(commandId, hotkeys) {
        set(s => {
            const next = new Map(s.userOverrides);
            next.set(commandId, hotkeys);
            saveOverrides(next);
            return { userOverrides: next };
        });
    },

    resetHotkeys(commandId) {
        set(s => {
            const next = new Map(s.userOverrides);
            next.delete(commandId);
            saveOverrides(next);
            return { userOverrides: next };
        });
    },

    getHotkeys(commandId) {
        const override = get().userOverrides.get(commandId);
        if (override) return override;
        return get().commands.get(commandId)?.hotkeys
            ?? get().commandSchemas.get(commandId)?.hotkeys
            ?? [];
    },

    setPaused(paused: boolean) {
        set({ paused });
    },
}));

// ===== 快捷鍵比對 =====

const isMac = typeof navigator !== 'undefined' && /Mac|iPod|iPhone|iPad/.test(navigator.platform);

function matchHotkey(e: KeyboardEvent, hk: HotkeyDef): boolean {
    const mod = isMac ? e.metaKey : e.ctrlKey;
    const needMod = hk.modifiers.includes('Mod');
    const needShift = hk.modifiers.includes('Shift');
    const needAlt = hk.modifiers.includes('Alt');

    if (needMod !== mod) return false;
    if (needShift !== e.shiftKey) return false;
    if (needAlt !== e.altKey) return false;
    // 沒要求 mod/shift/alt 但按了 → 不匹配（避免 Ctrl+Enter 觸發純 Enter）
    if (!needMod && mod) return false;
    if (!needShift && e.shiftKey) return false;
    if (!needAlt && e.altKey) return false;

    // key 比對：單字母忽略大小寫（Shift+E 按下時 e.key='E'，hotkey 定義可能是 'e'）
    const eKey = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    const hkKey = hk.key.length === 1 ? hk.key.toLowerCase() : hk.key;
    return eKey === hkKey;
}

// ===== 唯一 keydown + keyup listener =====

let _installed = false;

export function installKeydownListener(): void {
    if (_installed) return;
    _installed = true;

    window.addEventListener('keydown', (e) => {
        // 輸入法組字中 → 跳過
        if (e.isComposing) return;

        const state = useCommandManager.getState();

        // 先觸發旁路觀察器（不消費事件）
        for (const [, observer] of state.keyObservers) {
            if (observer.onDown && observer.keys.includes(e.key)) {
                observer.onDown(e.key, e);
            }
        }

        // 暫停模式（錄製快捷鍵時）→ 不攔截
        if (state.paused) return;

        // 安全保護：純字母/數字鍵（無 modifier）在 input/textarea/contenteditable 中不觸發
        const activeEl = document.activeElement;
        const isInInput = activeEl instanceof HTMLInputElement ||
            activeEl instanceof HTMLTextAreaElement ||
            (activeEl as HTMLElement)?.isContentEditable;
        const isPureChar = e.key.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey;
        const isInputSafe = isInInput && isPureChar;

        // 倒序遍歷：最後註冊的 command 優先（dialog > list > plugin）
        const entries = [...state.commands.entries()];
        const isEnter = e.key === 'Enter';
        if (isEnter) {
            console.log('[CM] Enter pressed | activeElement:', document.activeElement?.tagName, document.activeElement?.className, '| isInInput:', isInInput, '| commands:', entries.map(([id]) => id).join(', '));
        }
        for (let i = entries.length - 1; i >= 0; i--) {
            const [id, binding] = entries[i];
            const hotkeys = state.getHotkeys(id);
            for (const hk of hotkeys) {
                if (!matchHotkey(e, hk)) continue;

                // 輸入框中按純字母/數字 → 跳過（讓字元正常輸入）
                if (isInputSafe) continue;

                // enabled 守衛：情境不符 → 跳過（不消費事件）
                const enabledResult = binding.enabled ? binding.enabled() : true;
                if (isEnter) console.log(`[CM]   check ${id} | enabled:`, enabledResult);
                if (!enabledResult) continue;

                const { command } = binding;
                let canExecute = true;

                if (command.checkCallback) {
                    canExecute = command.checkCallback(true);
                    if (isEnter) console.log(`[CM]   check ${id} | checkCallback:`, canExecute);
                }

                if (canExecute) {
                    if (isEnter) console.log(`[CM]   >>> EXECUTE ${id}`);
                    e.preventDefault();
                    e.stopPropagation();
                    state.execute(id);
                    return;
                }
            }
        }
        if (isEnter) console.log('[CM] Enter: no command matched');
    }, true); // capture phase，比所有現有 listener 先攔截

    // keyup listener：用於通知修飾鍵釋放等追蹤
    window.addEventListener('keyup', (e) => {
        const state = useCommandManager.getState();
        for (const [, observer] of state.keyObservers) {
            if (observer.onUp && observer.keys.includes(e.key)) {
                observer.onUp(e.key);
            }
        }
    }, true);
}

// ===== 持久化 =====

function loadOverrides(): Map<string, HotkeyDef[]> {
    try {
        const raw = localStorage.getItem('hotkeyOverrides');
        if (raw) return new Map(JSON.parse(raw));
    } catch { /* ignore */ }
    return new Map();
}

function saveOverrides(map: Map<string, HotkeyDef[]>): void {
    localStorage.setItem('hotkeyOverrides', JSON.stringify([...map]));
}
