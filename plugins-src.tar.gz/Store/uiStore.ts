import { create } from 'zustand';
import { useAICommanderStore } from '../components/plugins/ai-commander/aiStore';

// ===== Types =====
interface TimerManager {
    ids: Record<string, ReturnType<typeof setTimeout> | null>;
    set: (key: string, callback: () => void, delay: number) => void;
    clear: (key: string) => void;
}

// 全局定時器管理（用於非 React 組件的 Zustand store）
export const timerManager: TimerManager = {
    ids: {},
    set(key, callback, delay) {
        if (this.ids[key]) clearTimeout(this.ids[key]!);
        this.ids[key] = setTimeout(() => {
            this.ids[key] = null;
            callback();
        }, delay);
    },
    clear(key) {
        if (this.ids[key]) {
            clearTimeout(this.ids[key]!);
            this.ids[key] = null;
        }
    }
};

// ===== LiveInput Store =====
interface LiveInputState {
    liveTitleInputs: Record<string, string>;
    setLiveTitleInput: (noteId: string, value: string) => void;
    clearLiveTitleInput: (noteId: string) => void;
}

export const useLiveInputStore = create<LiveInputState>((set) => ({
    liveTitleInputs: {},
    setLiveTitleInput: (noteId, value) => set((state) => ({
        liveTitleInputs: {
            ...state.liveTitleInputs,
            [noteId]: value
        }
    })),
    clearLiveTitleInput: (noteId) => set((state) => {
        const { [noteId]: removed, ...rest } = state.liveTitleInputs;
        return { liveTitleInputs: rest };
    }),
}));

// ===== MobileSidebar Store =====
interface MobileSidebarState {
    isMobileSidebarOpen: boolean;
    setIsMobileSidebarOpen: (isOpen: boolean) => void;
}

export const useMobileSidebarStore = create<MobileSidebarState>((set) => ({
    isMobileSidebarOpen: false,
    setIsMobileSidebarOpen: (isOpen) => set({ isMobileSidebarOpen: isOpen }),
}));

// ===== MobilePanel Store =====
interface MobilePanelState {
    panelType: 'note' | 'card' | 'chart' | null;
    itemId: string | null;
    /** 通用開啟面板（mobile 路徑，由 Workspace.openWindow 調用） */
    openPanel: (item: { id: string; itemType: string }) => void;
    openNotePanel: (noteId: string) => void;
    openCardPanel: (cardId: string) => void;
    closePanel: () => void;
}

const itemTypeToPanelType: Record<string, 'note' | 'card' | 'chart'> = {
    NOTE: 'note',
    CARD: 'card',
    CHART: 'chart',
};

export const useMobilePanelStore = create<MobilePanelState>((set) => ({
    panelType: null,
    itemId: null,
    openPanel: (item) => {
        const pt = itemTypeToPanelType[item.itemType];
        if (pt) set({ panelType: pt, itemId: item.id });
    },
    openNotePanel: (noteId) => set({ panelType: 'note', itemId: noteId }),
    openCardPanel: (cardId) => set({ panelType: 'card', itemId: cardId }),
    closePanel: () => set({ panelType: null, itemId: null }),
}));

// ===== ForceCheckUnsyncedContent Store =====
interface ForceCheckUnsyncedContentState {
    forceCheckUnsyncedContent: boolean;
    setForceCheckUnsyncedContent: (v: boolean | ((prev: boolean) => boolean)) => void;
}

export const useForceCheckUnsyncedContentStore = create<ForceCheckUnsyncedContentState>((set) => ({
    forceCheckUnsyncedContent: false,
    setForceCheckUnsyncedContent: (forceCheckUnsyncedContent) => {
        if (typeof forceCheckUnsyncedContent === 'function') {
            set((state) => ({ forceCheckUnsyncedContent: forceCheckUnsyncedContent(state.forceCheckUnsyncedContent) }));
        } else {
            set({ forceCheckUnsyncedContent });
        }
    }
}));


// ===== PressedKey Store =====
interface PressedKeyState {
    isShiftPressed: boolean;
    isCommandPressed: boolean;
    setIsShiftPressed: (v: boolean) => void;
    setIsCommandPressed: (v: boolean) => void;
}

export const usePressedKeyStore = create<PressedKeyState>((set) => ({
    isShiftPressed: false,
    isCommandPressed: false,
    setIsShiftPressed: (isShiftPressed) => set({ isShiftPressed }),
    setIsCommandPressed: (isCommandPressed) => set({ isCommandPressed })
}));

// ===== IsConnected Store =====
interface IsConnectedState {
    isConnected: boolean;
    isSyncing: boolean;
    isAuthing: boolean;
    setIsConnected: (v: boolean) => void;
    setIsSyncing: (v: boolean) => void;
    setIsAuthing: (v: boolean) => void;
}

export const useIsConnectedStore = create<IsConnectedState>((set) => ({
    isConnected: false,
    isSyncing: false,
    isAuthing: false,
    setIsConnected: (isConnected) => set({ isConnected }),
    setIsSyncing: (syncing) => set({ isSyncing: syncing }),
    setIsAuthing: (authing) => set({ isAuthing: authing })
}));

// ===== SyncStatus Store =====
interface SyncStatusState {
    status: string;
    setStatus: (status: string) => void;
}

export const useSyncStatusStore = create<SyncStatusState>((set) => ({
    status: '',
    setStatus: (status) => set({ status })
}));

// ===== MergedNote Store =====
interface MergedNoteState {
    mergedNoteId: string | null;
    setMergedNoteId: (id: string | null) => void;
}

export const useMergedNoteStore = create<MergedNoteState>((set) => ({
    mergedNoteId: null,
    setMergedNoteId: (id) => set({ mergedNoteId: id })
}));

// ===== TempHint Store =====
interface TempHintState {
    tempHint: string | null;
    tempHintPosition: 'top' | 'bottom';
    setTempHint: (message: string | null, position?: 'top' | 'bottom') => void;
    clearTempHint: () => void;
}

export const useTempHintStore = create<TempHintState>((set) => ({
    tempHint: null,
    tempHintPosition: 'top',
    setTempHint: (message, position = 'top') => set({ tempHint: message, tempHintPosition: position }),
    clearTempHint: () => set({ tempHint: null, tempHintPosition: 'top' })
}));

// ===== CollapsedGroups Store =====
interface CollapsedGroupsState {
    collapsedGroups: Set<string>;
    toggleGroup: (groupId: string) => void;
}

export const useCollapsedGroupsStore = create<CollapsedGroupsState>((set) => ({
    collapsedGroups: new Set(),
    toggleGroup: (groupId) => set((state) => {
        const newCollapsed = new Set(state.collapsedGroups);
        if (newCollapsed.has(groupId)) {
            newCollapsed.delete(groupId);
        } else {
            newCollapsed.add(groupId);
        }
        return { collapsedGroups: newCollapsed };
    })
}));


// ===== GuestMode Store =====
interface GuestModeState {
    isGuestMode: boolean;
    sharedItemId: string | null;
    setGuestMode: (isGuest: boolean, itemId?: string | null) => void;
}

export const useGuestModeStore = create<GuestModeState>((set) => ({
    isGuestMode: false,
    sharedItemId: null,
    setGuestMode: (isGuest, itemId = null) => set({ isGuestMode: isGuest, sharedItemId: itemId }),
}));

// ===== CardInfoPanel Store =====
interface CardInfoPanelState {
    isCardInfoPanelOpen: boolean;
    setIsCardInfoPanelOpen: (isOpen: boolean) => void;
}

export const useCardInfoPanelStore = create<CardInfoPanelState>((set) => ({
    isCardInfoPanelOpen: localStorage.getItem('listViewPreviewEnabled') !== 'false',
    setIsCardInfoPanelOpen: (isOpen) => {
        localStorage.setItem('listViewPreviewEnabled', isOpen ? 'true' : 'false');
        set({ isCardInfoPanelOpen: isOpen });
        if (isOpen) {
            useAICommanderStore.getState().setIsAICommanderOpen(false);
        }
    },
}));

