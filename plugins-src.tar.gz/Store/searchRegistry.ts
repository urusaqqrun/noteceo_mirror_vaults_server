import { create } from 'zustand';
import type { BaseItem } from '../types/item';

export interface SearchProvider {
  search: (query: string) => BaseItem[];
  renderIcon: (item: BaseItem) => React.ReactNode;
}

interface SearchRegistryState {
  providers: Map<string, SearchProvider>;
  register: (itemType: string, provider: SearchProvider) => void;
  unregister: (itemType: string) => void;
  getProvider: (itemType: string) => SearchProvider | undefined;
  search: (query: string) => BaseItem[];
}

export const useSearchRegistry = create<SearchRegistryState>((set, get) => ({
  providers: new Map(),

  register: (itemType, provider) => {
    set(state => {
      const next = new Map(state.providers);
      next.set(itemType, provider);
      return { providers: next };
    });
  },

  unregister: (itemType) => {
    set(state => {
      const next = new Map(state.providers);
      next.delete(itemType);
      return { providers: next };
    });
  },

  getProvider: (itemType) => get().providers.get(itemType),

  search: (query) => {
    const results: BaseItem[] = [];
    get().providers.forEach(provider => {
      results.push(...provider.search(query));
    });
    return results;
  },
}));
