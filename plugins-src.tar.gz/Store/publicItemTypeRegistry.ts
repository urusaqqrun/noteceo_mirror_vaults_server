const publicItemTypes = new Set<string>();

export function registerPublicItemType(itemType: string) {
  publicItemTypes.add(itemType);
}

export function supportsPublicShare(itemType: string): boolean {
  return publicItemTypes.has(itemType);
}
