// EmbedRendererRegistry — 各插件註冊「如何渲染嵌入式預覽」
//
// 使用方式：
//   NotePlugin.onload() → registerEmbedRenderer('NOTE', { component: NoteEmbedView })
//   TodoPlugin.onload() → registerEmbedRenderer('TODO', { component: TodoEmbedView })
//
// ItemEmbedExtension（editor 基礎設施）透過此 Registry 委派渲染。

import { create } from 'zustand';
import React from 'react';

export interface EmbedRendererProps {
  itemId: string;
  item: any;
}

export interface EmbedRenderer {
  /** React 組件，接收 { itemId, item } props */
  component: React.ComponentType<EmbedRendererProps>;
}

interface EmbedRendererRegistryState {
  renderers: Map<string, EmbedRenderer>;
  register: (itemType: string, renderer: EmbedRenderer) => void;
  unregister: (itemType: string) => void;
  getRenderer: (itemType: string) => EmbedRenderer | undefined;
}

export const useEmbedRendererRegistry = create<EmbedRendererRegistryState>((set, get) => ({
  renderers: new Map(),

  register: (itemType, renderer) => {
    set(state => {
      const next = new Map(state.renderers);
      next.set(itemType, renderer);
      return { renderers: next };
    });
  },

  unregister: (itemType) => {
    set(state => {
      const next = new Map(state.renderers);
      next.delete(itemType);
      return { renderers: next };
    });
  },

  getRenderer: (itemType) => get().renderers.get(itemType),
}));

/** 便捷函數：各插件用此註冊嵌入式渲染器 */
export const registerEmbedRenderer = (itemType: string, renderer: EmbedRenderer) => {
  useEmbedRendererRegistry.getState().register(itemType, renderer);
};
