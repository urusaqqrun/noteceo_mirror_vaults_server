/**
 * overlayStore — 全局 Overlay 註冊表
 *
 * Plugin 或 Bootstrap 在初始化時呼叫 register() 註冊 overlay 元件，
 * OverlayRenderer 讀取 store 並動態渲染所有已註冊的 overlay。
 *
 * 用法：
 *   // 註冊
 *   useOverlayStore.getState().register('aboutDialog', AboutDialog);
 *   // 反註冊（Plugin 卸載時）
 *   useOverlayStore.getState().unregister('aboutDialog');
 */
import { create } from 'zustand';
import type { ComponentType } from 'react';

interface OverlayState {
    overlays: Map<string, ComponentType>;
    refCounts: Map<string, number>;
    register: (id: string, Component: ComponentType) => void;
    unregister: (id: string) => void;
}

export const useOverlayStore = create<OverlayState>((set) => ({
    overlays: new Map(),
    refCounts: new Map(),
    register: (id, Component) => set(state => {
        const nextOverlays = new Map(state.overlays);
        const nextRefs = new Map(state.refCounts);
        nextOverlays.set(id, Component);
        nextRefs.set(id, (nextRefs.get(id) || 0) + 1);
        return { overlays: nextOverlays, refCounts: nextRefs };
    }),
    unregister: (id) => set(state => {
        const nextOverlays = new Map(state.overlays);
        const nextRefs = new Map(state.refCounts);
        const count = (nextRefs.get(id) || 0) - 1;
        if (count <= 0) {
            nextOverlays.delete(id);
            nextRefs.delete(id);
        } else {
            nextRefs.set(id, count);
        }
        return { overlays: nextOverlays, refCounts: nextRefs };
    }),
}));
