import { create } from 'zustand';
import type { BaseItem } from '../types/item';
import syncService, { markForSync, removeFromSync } from '../utils/syncService';
import { eventBus } from './eventBus';
import { getTrashFolderId } from '../utils/ensureDefaultFolders';

export interface UpsertOptions {
  needSync?: boolean;
}

export interface RemoveOptions {
  needSync?: boolean;
  /** true = 軟刪除（設 isDeleted），false/undefined = 硬刪除 */
  softDelete?: boolean;
  /** true = 刪除後若當前選中項被刪除，自動回退導航 */
  navigateOut?: boolean;
}

type OnDeleteHandler = (ids: string[], options?: RemoveOptions) => Promise<void>;
type OnUpsertHandler = (item: BaseItem) => Promise<void>;

const onDeleteHandlers = new Map<string, OnDeleteHandler>();
const onUpsertHandlers = new Map<string, OnUpsertHandler>();
let _inHandler = false;


export function registerOnDelete(itemType: string, fn: OnDeleteHandler): () => void {
  onDeleteHandlers.set(itemType, fn);
  return () => onDeleteHandlers.delete(itemType);
}

export function registerOnUpsert(itemType: string, fn: OnUpsertHandler): () => void {
  onUpsertHandlers.set(itemType, fn);
  return () => onUpsertHandlers.delete(itemType);
}

interface ItemStoreState {
  byType: Record<string, BaseItem[]>;
  itemMap: Map<string, BaseItem>;

  getById: (id: string) => BaseItem | undefined;
  getByType: (type: string, includeDeleted?: boolean) => BaseItem[];

  setItems: (items: BaseItem[]) => void;
  upsertItem: (item: BaseItem, options?: UpsertOptions) => Promise<void>;
  removeItems: (ids: string[], options?: RemoveOptions) => Promise<void>;
  softDeleteItems: (ids: string[], options?: RemoveOptions) => Promise<void>;

  applyRemoteUpsert: (item: BaseItem) => void;
  applyRemoteDelete: (ids: string[]) => void;

  loadByType: (type: string) => Promise<void>;
  reload: () => Promise<void>;
}

export const useItemStore = create<ItemStoreState>((set, get) => ({
  byType: {},
  itemMap: new Map(),

  getById: (id) => get().itemMap.get(id),

  getByType: (type, includeDeleted = false) => {
    const arr = get().byType[type] ?? [];
    return includeDeleted ? arr : arr.filter(i => i.isDeleted !== true);
  },

  setItems: (items) => {
    const itemMap = new Map<string, BaseItem>();
    const byType: Record<string, BaseItem[]> = {};
    for (const item of items) {
      itemMap.set(item.id, item);
      const type = item.itemType || 'UNKNOWN';
      (byType[type] ??= []).push(item);
    }
    set({ byType, itemMap });
  },

  upsertItem: async (item, options) => {
    const existing = get().itemMap.get(item.id);
    const isAdd = !existing;

    // Dedup: 根層 _FOLDER 同名不重複建（防止 ensureDefaultFolders race condition）
    if (isAdd && item.itemType?.endsWith('_FOLDER') && !item.parentID) {
      const sameNameFolder = (get().byType[item.itemType] ?? [])
        .find((f: any) => f.name === item.name && !f.parentID);
      if (sameNameFolder) {
        console.log(`[itemStore] dedup: skip creating duplicate root folder "${item.name}" (existing id=${sameNameFolder.id}, new id=${item.id})`);
        return;
      }
    }

    if (isAdd && !item._permissions) {
      if (item.parentID) {
        const parent = get().itemMap.get(item.parentID);
        if (parent?._permissions) {
          item = { ...item, _permissions: parent._permissions };
        }
      }
    }

    if (isAdd) {
      await (window.electronAPI as any).addItems([item]);
    } else {
      await (window.electronAPI as any).updateItems([item]);
    }

    set(state => {
      const itemMap = new Map(state.itemMap);
      itemMap.set(item.id, item);

      const type = item.itemType || 'UNKNOWN';
      const byType = { ...state.byType };
      const typeArr = byType[type] ?? [];
      const idx = typeArr.findIndex(i => i.id === item.id);
      if (idx >= 0) {
        byType[type] = [...typeArr];
        byType[type][idx] = item;
      } else {
        if (existing && existing.itemType !== type) {
          const oldType = existing.itemType || 'UNKNOWN';
          byType[oldType] = (byType[oldType] ?? []).filter(i => i.id !== item.id);
        }
        byType[type] = [...typeArr, item];
      }

      return { byType, itemMap };
    });

    if (options?.needSync) {
      markForSync(isAdd ? 'createItemIds' : 'updateItemIds', item.id);
    }
    syncService.checkUnsyncedContent();

    const upsertHandler = onUpsertHandlers.get(item.itemType);
    if (upsertHandler && !_inHandler) {
      _inHandler = true;
      try {
        await upsertHandler(item);
      } finally {
        _inHandler = false;
      }
      return;
    }
  },

  removeItems: async (ids, options) => {
    if (ids.length === 0) return;
    const firstItem = get().itemMap.get(ids[0]);
    const itemType = firstItem?.itemType;
    const handler = itemType ? onDeleteHandlers.get(itemType) : undefined;
    if (handler && !_inHandler) {
      _inHandler = true;
      try {
        await handler(ids, options);
      } finally {
        _inHandler = false;
      }
      syncService.checkUnsyncedContent();
      return;
    }

    if (options?.softDelete) {
      await get().softDeleteItems(ids, options);
    } else {
      await (window.electronAPI as any).deleteItems(ids);
      const idSet = new Set(ids);
      set(state => {
        const itemMap = new Map(state.itemMap);
        ids.forEach(id => itemMap.delete(id));
        const byType = { ...state.byType };
        for (const type of Object.keys(byType)) {
          const arr = byType[type];
          if (arr.some(i => idSet.has(i.id))) {
            byType[type] = arr.filter(i => !idSet.has(i.id));
          }
        }
        return { byType, itemMap };
      });
      if (options?.needSync) {
        markForSync('deletedItemIds', ids);
        removeFromSync(ids);
      }
    }
    syncService.checkUnsyncedContent();
  },

  softDeleteItems: async (ids, options) => {
    const now = Date.now();
    const trashFolderId = getTrashFolderId();
    for (const id of ids) {
      const item = get().itemMap.get(id) as any;
      if (!item) continue;
      await get().upsertItem(
        {
          ...item,
          isDeleted: true,
          deletedAt: now,
          updatedAt: now,
          preFolderID: item.preFolderID || item.parentID,
          ...(trashFolderId ? { parentID: trashFolderId } : {}),
        } as BaseItem,
        { needSync: options?.needSync ?? true }
      );
    }
    syncService.checkUnsyncedContent();
  },

  applyRemoteUpsert: (item) => {
    set(state => {
      const itemMap = new Map(state.itemMap);
      const existing = itemMap.get(item.id);
      itemMap.set(item.id, item);

      const type = item.itemType || 'UNKNOWN';
      const byType = { ...state.byType };
      const typeArr = byType[type] ?? [];
      const idx = typeArr.findIndex(i => i.id === item.id);
      if (idx >= 0) {
        byType[type] = [...typeArr];
        byType[type][idx] = item;
      } else {
        if (existing && existing.itemType !== type) {
          const oldType = existing.itemType || 'UNKNOWN';
          byType[oldType] = (byType[oldType] ?? []).filter(i => i.id !== item.id);
        }
        byType[type] = [...typeArr, item];
      }
      return { byType, itemMap };
    });
    eventBus.emit('item:remote-upsert', item);
  },

  applyRemoteDelete: (ids) => {
    if (ids.length === 0) return;
    const idSet = new Set(ids);
    set(state => {
      const itemMap = new Map(state.itemMap);
      ids.forEach(id => itemMap.delete(id));
      const byType = { ...state.byType };
      for (const type of Object.keys(byType)) {
        const arr = byType[type];
        if (arr.some(i => idSet.has(i.id))) {
          byType[type] = arr.filter(i => !idSet.has(i.id));
        }
      }
      return { byType, itemMap };
    });
  },

  loadByType: async (type) => {
    try {
      const items = await (window.electronAPI as any).getItemsByType?.(type) || [];
      const normalized = items.map((item: any) => ({
        ...item,
        itemType: item.itemType || type,
      }));
      set(state => {
        const itemMap = new Map(state.itemMap);
        for (const [id, item] of state.itemMap) {
          if ((item.itemType || 'UNKNOWN') === type) itemMap.delete(id);
        }
        normalized.forEach(item => itemMap.set(item.id, item));
        return { byType: { ...state.byType, [type]: normalized }, itemMap };
      });
    } catch (error) {
      console.error(`[itemStore] loadByType(${type}) failed:`, error);
    }
  },

  reload: async () => {
    try {
      const items = await (window.electronAPI as any).getItems?.() || [];
      get().setItems(items);
    } catch (error) {
      console.error('reload failed:', error);
    }
  },
}));

if ((window as any).electronAPI?.onItemChanged) {
  (window as any).electronAPI.onItemChanged((payload: { action: string; data: any }) => {
    const { action, data } = payload;
    if (action === 'upsert') {
      useItemStore.getState().applyRemoteUpsert(data);
    } else if (action === 'delete') {
      useItemStore.getState().applyRemoteDelete(Array.isArray(data) ? data : [data]);
    }
  });
}
