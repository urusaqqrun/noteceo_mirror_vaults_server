/**
 * editorExtensionRegistry.ts
 * 
 * Editor 擴展註冊中心 — 各插件在 onload() 時註冊自己的 Tiptap Extension，
 * Editor 和 AI Commander 從 registry 讀取，不直接 import 各插件的擴展。
 * 
 * 參考 Obsidian 的 registerEditorExtension() 模式，
 * 但使用 zustand store 實現（符合現有架構）。
 */
import { create } from 'zustand';
import type { Extension } from '@tiptap/core';

interface EditorExtensionRegistryState {
    /** 已註冊的擴展 Map<id, Extension | Extension[]> */
    extensions: Map<string, Extension | Extension[]>;

    /** 插件在 onload() 時調用 */
    register: (id: string, ext: Extension | Extension[]) => void;

    /** 插件在 unload() 時調用 */
    unregister: (id: string) => void;

    /** 取得所有已註冊擴展（展平為一維陣列） */
    getAll: () => Extension[];
}

export const useEditorExtensionRegistry = create<EditorExtensionRegistryState>((set, get) => ({
    extensions: new Map(),

    register: (id, ext) => {
        set(state => {
            const next = new Map(state.extensions);
            next.set(id, ext);
            return { extensions: next };
        });
    },

    unregister: (id) => {
        set(state => {
            const next = new Map(state.extensions);
            next.delete(id);
            return { extensions: next };
        });
    },

    getAll: () => {
        const result: Extension[] = [];
        get().extensions.forEach(ext => {
            if (Array.isArray(ext)) {
                result.push(...ext);
            } else {
                result.push(ext);
            }
        });
        return result;
    },
}));

// 註冊基礎設施擴展（不依賴任何插件）
import { ItemEmbedExtension } from '../components/plugins/editor/extensions/ItemEmbedExtension';
useEditorExtensionRegistry.getState().register('infra:itemEmbed', ItemEmbedExtension as any);

