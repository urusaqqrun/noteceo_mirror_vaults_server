import { create } from 'zustand';

// ==================== 統一 Menu Store ====================
// 所有 menu 共用一個 store，用字串 key 區分
// 新增 menu 只需用新 key，不用改這個文件

interface MenuEntry {
    show: boolean;
    position: { x: number; y: number };
    data: any;
}

interface MenuStoreState {
    menus: Record<string, MenuEntry>;
    openAt: (name: string, x: number, y: number, data?: any) => void;
    close: (name: string) => void;
}

export const useMenuStore = create<MenuStoreState>((set) => ({
    menus: {},
    openAt: (name, x, y, data) => set((state) => ({
        menus: { ...state.menus, [name]: { show: true, position: { x, y }, data: data ?? null } }
    })),
    close: (name) => set((state) => ({
        menus: { ...state.menus, [name]: { show: false, position: { x: 0, y: 0 }, data: null } }
    })),
}));
