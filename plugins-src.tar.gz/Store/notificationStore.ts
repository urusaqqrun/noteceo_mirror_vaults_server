import { create } from 'zustand';
import type { ComponentType } from 'react';
import * as notificationAPI from '../utils/notificationAPI';
import type { NotificationData } from '../utils/notificationAPI';

let _fetchDebounceTimer: ReturnType<typeof setTimeout> | null = null;

// ===== Types =====

export interface NotificationItemProps {
  notification: NotificationData;
  onMarkRead: () => void;
  onDelete: () => void;
}

export interface NotificationRenderer {
  Component: ComponentType<NotificationItemProps>;
}

// ===== Store =====

interface NotificationState {
  notifications: NotificationData[];
  unreadCount: number;
  isLoading: boolean;
  isPanelOpen: boolean;
  anchorRect: { top: number; left: number; bottom: number; right: number } | null;

  // 插件註冊的自訂渲染器
  renderers: Map<string, NotificationRenderer>;

  // Actions
  fetchNotifications: () => Promise<void>;
  markAsRead: (id: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  togglePanel: () => void;
  setPanelOpen: (open: boolean) => void;
  setAnchorRect: (rect: { top: number; left: number; bottom: number; right: number } | null) => void;

  // 插件 API
  registerNotificationRenderer: (type: string, renderer: NotificationRenderer) => () => void;

  // WebSocket 推播觸發
  handlePushNotification: (notification: { type: string; data: Record<string, any>; timestamp: number }) => void;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  isLoading: false,
  isPanelOpen: false,
  anchorRect: null,
  renderers: new Map(),

  fetchNotifications: async () => {
    set({ isLoading: true });
    try {
      const result = await notificationAPI.getNotifications(50);
      set({
        notifications: result.notifications,
        unreadCount: result.unreadCount,
        isLoading: false,
      });
    } catch (err) {
      console.error('[NotificationStore] fetchNotifications error:', err);
      set({ isLoading: false });
    }
  },

  markAsRead: async (id: string) => {
    try {
      await notificationAPI.markNotificationRead(id);
      set(state => ({
        notifications: state.notifications.map(n =>
          n.id === id ? { ...n, isRead: true } : n
        ),
        unreadCount: Math.max(0, state.unreadCount - 1),
      }));
    } catch (err) {
      console.error('[NotificationStore] markAsRead error:', err);
    }
  },

  markAllAsRead: async () => {
    try {
      await notificationAPI.markAllNotificationsRead();
      set(state => ({
        notifications: state.notifications.map(n => ({ ...n, isRead: true })),
        unreadCount: 0,
      }));
    } catch (err) {
      console.error('[NotificationStore] markAllAsRead error:', err);
    }
  },

  deleteNotification: async (id: string) => {
    try {
      await notificationAPI.deleteNotification(id);
      set(state => {
        const target = state.notifications.find(n => n.id === id);
        const wasUnread = target && !target.isRead;
        return {
          notifications: state.notifications.filter(n => n.id !== id),
          unreadCount: wasUnread ? Math.max(0, state.unreadCount - 1) : state.unreadCount,
        };
      });
    } catch (err) {
      console.error('[NotificationStore] deleteNotification error:', err);
    }
  },

  togglePanel: () => {
    const { isPanelOpen, fetchNotifications } = get();
    if (!isPanelOpen) {
      // 打開面板時重新拉資料
      fetchNotifications();
    }
    set({ isPanelOpen: !isPanelOpen });
  },

  setPanelOpen: (open: boolean) => {
    if (open) get().fetchNotifications();
    set({ isPanelOpen: open });
  },

  setAnchorRect: (rect) => set({ anchorRect: rect }),

  registerNotificationRenderer: (type: string, renderer: NotificationRenderer) => {
    set(state => {
      const newRenderers = new Map(state.renderers);
      newRenderers.set(type, renderer);
      return { renderers: newRenderers };
    });

    // 回傳 unsubscribe
    return () => {
      set(state => {
        const newRenderers = new Map(state.renderers);
        newRenderers.delete(type);
        return { renderers: newRenderers };
      });
    };
  },

  handlePushNotification: (_notification) => {
    // 收到 WebSocket 推播 → debounce 300ms 後拉通知列表
    if (_fetchDebounceTimer) clearTimeout(_fetchDebounceTimer);
    _fetchDebounceTimer = setTimeout(() => {
      _fetchDebounceTimer = null;
      get().fetchNotifications();
    }, 300);
  },
}));
