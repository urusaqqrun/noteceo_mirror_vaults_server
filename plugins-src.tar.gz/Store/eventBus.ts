// EventBus - 全局事件總線
// Store 之間通過字串事件通信，無需直接引用彼此
// 事件命名慣例：'模組名:動作'，例如 'sidebar:folder-select', 'editor:force-reload'

type Handler = (...args: any[]) => void | Promise<void>;

class StoreEventBus {
    private listeners = new Map<string, Set<Handler>>();

    /** 訂閱事件，返回取消訂閱函數 */
    on(event: string, handler: Handler): () => void {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, new Set());
        }
        this.listeners.get(event)!.add(handler);
        return () => this.listeners.get(event)?.delete(handler);
    }

    /** 發送事件（支援 async handler，調用端可選擇 await 或 fire-and-forget） */
    async emit(event: string, ...args: any[]): Promise<void> {
        const handlers = this.listeners.get(event);
        if (!handlers) return;
        for (const fn of handlers) {
            try {
                await fn(...args);
            } catch (error) {
                console.error(`[EventBus] Error in handler for '${event}':`, error);
            }
        }
    }

}

export const eventBus = new StoreEventBus();
