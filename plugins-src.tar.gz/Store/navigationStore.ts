import { create } from 'zustand';
import type { BaseItem } from '../types/item';

import i18n from '../i18n/config';
import { navigationHistory } from '../utils/NavigationHistory';
import { useItemStore } from './itemStore';

// sortedIds 全域 registry — useListKeyboardNav 寫入，navigateInto 讀取
const sortedIdsRegistry = new Map<string, string[]>();

export function registerSortedIds(folderId: string, ids: string[]) {
  sortedIdsRegistry.set(folderId, ids);
}

export function unregisterSortedIds(folderId: string) {
  sortedIdsRegistry.delete(folderId);
}

export function getSortedIdsForFolder(folderId: string): string[] | undefined {
  return sortedIdsRegistry.get(folderId);
}

// 通用導航參數，存放一次性副作用指令
export interface NavParams {
  [key: string]: unknown;
}

async function resolveAncestorChain(startId: string): Promise<BaseItem[]> {
  const chain: BaseItem[] = [];
  const visited = new Set<string>();
  let currentId: string | null = startId;

  while (currentId) {
    if (visited.has(currentId)) break;
    visited.add(currentId);

    const item = await window.electronAPI.getItem(currentId);
    if (!item) {
      console.warn('[navigationStore] resolveAncestorChain: 找不到 id =', currentId, '，返回已建立的部分祖先鏈');
      return chain;
    }

    chain.unshift(item);
    currentId = item.parentID ?? null;
  }

  return chain;
}

async function resolveFolderIdFromParentChain(item: BaseItem): Promise<string | null> {
  const visited = new Set<string>();
  let current: BaseItem | null = item;

  while (current) {
    if (visited.has(current.id)) break;
    visited.add(current.id);

    const aiFid = (current as any).aiFolderID;
    if (aiFid) return aiFid;

    if (!current.parentID) break;
    const parent = await window.electronAPI.getItem(current.parentID);
    if (!parent) break;
    if (parent.itemType.endsWith('_FOLDER')) return parent.id;
    current = parent;
  }

  return null;
}

interface NavigationState {
  /**
   * 完整路徑：從根到當前位置的線性鏈
   * 例：[noteFolder, note1] — 在 noteFolder 裡看 note1
   * 例：[todoFolder] — 選了一個 todo 資料夾
   * 例：[] — 什麼都沒選
   * navigateOut() = path.pop()，就像 cd ..
   * navigateInto() = 進入 folder 的第一個 child，就像 cd child/
   */
  path: BaseItem[];

  /**
   * 多選額外項目（同層的其他被選項目，平常是空的）
   * cmd+click note2 → extraItems = [note2]
   * path 的最後一段是「主選」，extraItems 是「副選」
   */
  extraItems: BaseItem[];


  /** 推導值：當前選中的資料夾 ID */
  selectedFolderId: string | null;
  navParams: NavParams;

  /** 導航歷史狀態（響應式，UI 直接讀取） */
  canGoBack: boolean;
  canGoForward: boolean;

  // === 對外 API ===
  setSelectedItems: (items: BaseItem[], params?: NavParams) => Promise<void>;
  /** cd .. — 回上一層 */
  navigateOut: () => void;
  /** cd child/ — 進入當前 folder 的第一個 child item */
  navigateInto: () => void;
  navigateHistoryBack: () => void;
  navigateHistoryForward: () => void;
  addExtraItem: (item: BaseItem) => void;
  removeExtraItem: (id: string) => Promise<void>;
  getAllSelectedIds: () => string[];
  clearNavParams: () => void;
  /** 完全清空導航（登出等場景） */
  resetNavigation: () => void;
}



/**
 * 從 path 推導 selectedFolderId
 * 往前找 path 中最後一個 FOLDER 類型的 item
 */
function resolveSelectedFolderIdFromPath(path: BaseItem[]): string | null {
  const last = path.at(-1);
  if (last?.itemType?.endsWith('_FOLDER')) return last.id;
  for (let i = path.length - 2; i >= 0; i--) {
    if (path[i]?.itemType?.endsWith('_FOLDER')) return path[i].id;
  }
  return null;
}



export const useSelectedItemsStore = create<NavigationState>((set, get) => ({
  path: [],
  extraItems: [],
  selectedFolderId: null,
  navParams: {},
  canGoBack: false,
  canGoForward: false,

  /**
   * 設定導航項目（唯一對外 API）
   * items[0] 為主選項目，自動計算其祖先鏈填入 path
   * items[1..] 為多選額外項目，直接存入 extraItems
   */
  setSelectedItems: async (items, params = {}) => {
    if (items.length === 0) {
      const { path } = get();
      const folderPath = path.filter(item => item.itemType.endsWith('_FOLDER'));
      set({
        path: folderPath,
        extraItems: [],
        selectedFolderId: resolveSelectedFolderIdFromPath(folderPath),
        navParams: params,
      });
      return;
    }

    const mainItem = items[0];

    let newPath: BaseItem[];
    if (params.preservePath) {
      // 保留當前 path 的 folder 層，不重建祖先鏈
      const { path: currentPath } = get();
      const folderItems = currentPath.filter(i => i.itemType.endsWith('_FOLDER'));
      newPath = [...folderItems, mainItem];
    } else {
      const resolvedParentID = await resolveFolderIdFromParentChain(mainItem);
      let ancestors: BaseItem[] = [];
      if (resolvedParentID !== null) {
        ancestors = await resolveAncestorChain(resolvedParentID);
      }
      newPath = [...ancestors, mainItem];
    }

    // path = folderItems/ancestors + mainItem
    const path = newPath;

    // 多選的額外項目（完整 item）
    const extraItems = items.slice(1);

    const selectedFolderId = resolveSelectedFolderIdFromPath(path);

    set({ path, extraItems, selectedFolderId, navParams: params });

    // 自動推送歷史記錄 + 存 localStorage
    const lastItem = path.at(-1);
    if (lastItem) {
      navigationHistory.push([lastItem]);
      set({
        canGoBack: navigationHistory.canGoBack(),
        canGoForward: navigationHistory.canGoForward(),
      });
    }
  },

  /**
   * cd .. — 砍掉 path 最後一段，清空多選
   */
  navigateOut: () => {
    const { path } = get();
    if (path.length <= 1) return;

    const newPath = path.slice(0, -1);
    const selectedFolderId = resolveSelectedFolderIdFromPath(newPath);

    set({
      path: newPath,
      extraItems: [],
      selectedFolderId,
      navParams: {},
    });
  },

  /**
   * cd child/ — 進入當前 folder 的第一個 child item
   * 優先查詢已掛載列表的 sortedIds（與畫面順序一致），
   * 找不到時 fallback 到 itemStore 按 orderAt || updatedAt || createdAt 排序。
   *
   * 注意：不呼叫 setSelectedItems()（會重建祖先鏈導致虛擬資料夾上下文遺失），
   * 而是直接 append child 到現有 path。
   */
  navigateInto: () => {
    const { path } = get();
    const current = path.at(-1);
    if (!current) return;

    let first: BaseItem | undefined;

    // 優先從已掛載列表的 sortedIds 取第一個（與畫面順序一致）
    const registeredIds = getSortedIdsForFolder(current.id);
    if (registeredIds && registeredIds.length > 0) {
      first = useItemStore.getState().getById(registeredIds[0]);
    }

    // fallback：從 itemStore 查 parentID === current.id 的子項
    if (!first) {
      const getOrder = (item: BaseItem) => {
        const order = Number(item.orderAt) || 0;
        if (order !== 0) return order;
        const updated = Number((item as any).updatedAt) || 0;
        if (updated !== 0) return updated;
        return Number(item.createdAt) || 0;
      };

      const allItems = [...useItemStore.getState().itemMap.values()];
      const children = allItems.filter(
        i => i.parentID === current.id && !i.isDeleted,
      );
      if (children.length > 0) {
        children.sort((a, b) => getOrder(a) - getOrder(b));
        first = children[0];
      }
    }

    if (!first) return;

    // 直接 append 到現有 path，保留虛擬資料夾上下文
    const newPath = [...path, first];
    const selectedFolderId = resolveSelectedFolderIdFromPath(newPath);
    set({
      path: newPath,
      extraItems: [],
      selectedFolderId,
      navParams: { scrollToFocusItem: true },
    });

    // 推送歷史記錄
    navigationHistory.push([first]);
    set({
      canGoBack: navigationHistory.canGoBack(),
      canGoForward: navigationHistory.canGoForward(),
    });
  },

  /**
   * cmd+click 新增一個多選項目
   */
  addExtraItem: (item) => {
    const { path, extraItems } = get();
    if (extraItems.some(i => i.id === item.id)) return; // 已存在

    const newExtraItems = [...extraItems, item];

    set({ extraItems: newExtraItems });
  },

  /**
   * cmd+click 取消一個多選項目
   */
  removeExtraItem: async (id) => {
    const { path, extraItems } = get();
    const newExtraItems = extraItems.filter(i => i.id !== id);

    // 如果移除的是 path 最後一段（主選），需要特殊處理
    if (path.at(-1)?.id === id) {
      // 如果還有 extraItems，把第一個 extra 提升為主選
      if (newExtraItems.length > 0) {
        const newMainItem = newExtraItems[0];
        const remainingExtraItems = newExtraItems.slice(1);
        const resolvedParentID = await resolveFolderIdFromParentChain(newMainItem);
        let ancestors: BaseItem[] = [];
        if (resolvedParentID !== null) {
          ancestors = await resolveAncestorChain(resolvedParentID);
        }
        const newPath = [...ancestors, newMainItem];
        const selectedFolderId = resolveSelectedFolderIdFromPath(newPath);
        set({ path: newPath, extraItems: remainingExtraItems, selectedFolderId });
        return;
      }
      // 沒有 extra 了，回到上一層
      get().navigateOut();
      return;
    }

    set({ extraItems: newExtraItems });
  },

  /**
   * 取得所有被選中的 ID（主選 + 額外選）
   */
  getAllSelectedIds: () => {
    const { path, extraItems } = get();
    const mainId = path.at(-1)?.id;
    if (!mainId) return [];
    return [mainId, ...extraItems.map(i => i.id)];
  },

  clearNavParams: () => {
    set({ navParams: {} });
  },

  resetNavigation: () => {
    set({ path: [], extraItems: [], selectedFolderId: null, navParams: {} });
  },

  navigateHistoryBack: () => {
    if (navigationHistory.back()) {
      set({
        canGoBack: navigationHistory.canGoBack(),
        canGoForward: navigationHistory.canGoForward(),
      });
    }
  },

  navigateHistoryForward: () => {
    if (navigationHistory.forward()) {
      set({
        canGoBack: navigationHistory.canGoBack(),
        canGoForward: navigationHistory.canGoForward(),
      });
    }
  },

}));

// ===== 啟動時位置初始化（由 WorkspaceBootstrap 調用） =====

/**
 * 從 localStorage 恢復上次導航位置，失敗時 fallback 到 sidebar 第一個 section 的第一個 folder。
 * 完全不認任何 itemType，只從 sidebarRegistry 取資料。
 */
export async function initializeLocation() {
    if ((window as any).skipInitializeLocation) return;

    // 先 blur，避免焦點干擾
    if (document.activeElement) {
        (document.activeElement as HTMLElement).blur();
    }

    const startupOption = localStorage.getItem('startupOption') || 'lastLocation';

    if (startupOption === 'lastLocation') {
        const restored = await navigationHistory.restoreLocation();
        if (restored) return;
    }

    // Fallback：從 sidebarRegistry 取第一個 section 的第一個 folder
    await fallbackToFirstFolder();
}

async function fallbackToFirstFolder() {
    const { useSidebarRegistry } = await import('../components/plugins/sidebar/sidebarStore');
    const sections = useSidebarRegistry.getState().getSections();
    const sectionDataCache = useSidebarRegistry.getState().sectionDataCache as Map<string, any>;

    for (const section of sections) {
        const data = sectionDataCache.get(section.id);
        if (!data) continue;
        // prefixItems（如 inbox）優先，再取 items（一般資料夾）
        const firstItem = data.prefixItems?.[0] ?? data.items?.[0];
        if (firstItem) {
            useSelectedItemsStore.getState().setSelectedItems([firstItem]);
            return;
        }
    }
}

// ===== Web 版瀏覽器分頁標題同步 =====

function deriveDocumentTitle(): string {
  const { path } = useSelectedItemsStore.getState();
  const last = path.at(-1);
  if (!last) return 'CubeLV';

  for (let i = path.length - 1; i >= 0; i--) {
    if (path[i]?.itemType?.endsWith('_FOLDER')) {
      const name = path[i].name;
      return i18n.t(name) || name;
    }
  }

  return i18n.t(last.name) || last.name;
}

/**
 * 啟動 document.title 同步（僅 Web 版需要）
 * 回傳 unsubscribe 函式
 */
export function initDocumentTitleSync(): () => void {
  const update = () => { document.title = deriveDocumentTitle(); };
  update();
  return useSelectedItemsStore.subscribe(update);
}
