import { create } from 'zustand';

// ==================== 統一 Dialog Store ====================
// 所有 dialog 共用一個 store，用字串 key 區分
// 新增 dialog 只需用新 key，不用改這個文件

interface DialogEntry {
    show: boolean;
    data: any;
}

interface DialogStoreState {
    dialogs: Record<string, DialogEntry>;
    open: (name: string, data?: any) => void;
    close: (name: string) => void;
}

export const useDialogStore = create<DialogStoreState>((set) => ({
    dialogs: {},
    open: (name, data) => set((state) => ({
        dialogs: { ...state.dialogs, [name]: { show: true, data: data ?? null } }
    })),
    close: (name) => set((state) => ({
        dialogs: { ...state.dialogs, [name]: { show: false, data: null } }
    })),
}));

// 掛到 window 供 Electron 主進程選單 executeJavaScript 直接調用
(window as any).__dialogStore = useDialogStore;
