// 統一 Item 模型型別定義

import { apiFireAndForget, isLoggedIn } from '../aiService/apiClient';

// ===== 前端記憶體中的扁平化基底欄位 =====
export type PermissionLevel = 'owner' | 'editor' | 'contributor' | 'viewer';

/** 後端注入的權限陣列項目（來自 item_permissions 表） */
export interface ItemPermissionEntry {
  user_id: string;
  permission: 'owner' | 'editor' | 'viewer' | 'contributor';
}

// Schema registry — 所有 item type 的 base schema（由 @itemType 裝飾器寫入）
export const _itemSchemaRegistry = new Map<string, ItemSchemaEntry>();

export interface ItemSchemaEntry {
  itemType: string;
  fields: Record<string, string>;  // fieldName → type string
  description?: string;
  aiHints?: string[];              // 給 AI 的提示（寫進 .schemas/，CLI 讀取）
}

export function getItemSchemaRegistry(): ReadonlyMap<string, ItemSchemaEntry> {
  return _itemSchemaRegistry;
}

// ===== Schema Extension — 插件動態擴展欄位 =====

export interface SchemaExtension {
  fields: Record<string, string>;
  defaults: Record<string, unknown>;
}

// Map<sourceId, Map<itemType, SchemaExtension>>
const _schemaExtensions = new Map<string, Map<string, SchemaExtension>>();

// 推送到 vault 時排除的欄位名（同 @itemType 裝飾器中 isPublic 的排除邏輯）
const _vaultExcludedFields = new Set<string>();

export function excludeFieldsFromVault(fields: string[]): void {
  fields.forEach(f => _vaultExcludedFields.add(f));
}

export function includeFieldsInVault(fields: string[]): void {
  fields.forEach(f => _vaultExcludedFields.delete(f));
}
// Map<sourceId, Map<itemType, string[]>>
const _aiHintsExtensions = new Map<string, Map<string, string[]>>();

/** 取得 base + 所有 extension 合併後的完整 schema */
export function getMergedSchema(itemType: string): ItemSchemaEntry | undefined {
  const base = _itemSchemaRegistry.get(itemType);
  if (!base) return undefined;

  const mergedFields = { ...base.fields };
  const mergedHints: string[] = base.aiHints ? [...base.aiHints] : [];

  for (const [, extMap] of _schemaExtensions) {
    const ext = extMap.get(itemType);
    if (ext) Object.assign(mergedFields, ext.fields);
  }
  for (const [, hintsMap] of _aiHintsExtensions) {
    const hints = hintsMap.get(itemType);
    if (hints) mergedHints.push(...hints);
  }

  return {
    ...base,
    fields: mergedFields,
    aiHints: mergedHints.length > 0 ? mergedHints : undefined,
  };
}

/** 重建並推送合併後的 schema 到 vault（過濾 _vaultExcludedFields） */
function pushMergedToVault(itemType: string) {
  const merged = getMergedSchema(itemType);
  if (!merged) return;

  if (_vaultExcludedFields.size > 0) {
    const filtered = { ...merged.fields };
    for (const key of _vaultExcludedFields) delete filtered[key];
    pushSchemaToVault(itemType, { ...merged, fields: filtered });
  } else {
    pushSchemaToVault(itemType, merged);
  }
}

/** 插件用：為已註冊的 itemType 追加欄位（掛載時呼叫） */
export function extendItemSchema(sourceId: string, itemType: string, ext: SchemaExtension): void {
  if (!_schemaExtensions.has(sourceId)) _schemaExtensions.set(sourceId, new Map());
  _schemaExtensions.get(sourceId)!.set(itemType, ext);
  pushMergedToVault(itemType);
}

/** 插件用：移除該插件的所有 schema 擴展（卸載時呼叫） */
export function removeItemSchemaExtension(sourceId: string): void {
  const extMap = _schemaExtensions.get(sourceId);
  if (!extMap) return;
  const affectedTypes = [...extMap.keys()];
  _schemaExtensions.delete(sourceId);
  affectedTypes.forEach(pushMergedToVault);
}

/** 插件用：為 itemType 追加 AI Hints（掛載時呼叫） */
export function addAIHints(sourceId: string, itemType: string, hints: string[]): void {
  if (!_aiHintsExtensions.has(sourceId)) _aiHintsExtensions.set(sourceId, new Map());
  _aiHintsExtensions.get(sourceId)!.set(itemType, hints);
  pushMergedToVault(itemType);
}

/** 插件用：移除該插件的所有 AI Hints（卸載時呼叫） */
export function removeAIHints(sourceId: string): void {
  const hintsMap = _aiHintsExtensions.get(sourceId);
  if (!hintsMap) return;
  const affectedTypes = [...hintsMap.keys()];
  _aiHintsExtensions.delete(sourceId);
  affectedTypes.forEach(pushMergedToVault);
}

/** 取得某 itemType 所有 extension 的預設值（給 hydration 用） */
export function getExtensionDefaults(itemType: string): Record<string, unknown> {
  const defaults: Record<string, unknown> = {};
  for (const [, extMap] of _schemaExtensions) {
    const ext = extMap.get(itemType);
    if (ext) Object.assign(defaults, ext.defaults);
  }
  return defaults;
}

// Decorator：標記 item type，自動註冊 base schema + 即時推送到 server
// aiHints / 擴展欄位由 Plugin 在 onload() 中透過 addAIHints / extendItemSchema 註冊
export function itemType(type: string, description?: string) {
  return function <T extends new (...args: any[]) => BaseItem>(constructor: T) {
    const instance = new constructor();
    const fields: Record<string, string> = {};

    for (const key of Object.keys(instance)) {
      if (['id', 'name', 'itemType', 'parentID', 'version',
           'createdAt', 'updatedAt', 'orderAt', 'isDeleted',
           'deletedAt', '_permissions', 'isPublic'].includes(key)) continue;

      const val = (instance as any)[key];
      fields[key] = Array.isArray(val) ? 'array' : typeof val;
    }

    const entry: ItemSchemaEntry = { itemType: type, fields, description };
    _itemSchemaRegistry.set(type, entry);

    pushMergedToVault(type);

    return constructor;
  };
}

export function pushSchemaToVault(type: string, schema: ItemSchemaEntry) {
  if (!isLoggedIn()) return;
  apiFireAndForget({
    url: 'https://dev.cubelv.com/api/vault/schemas',
    body: { schemas: { [type]: schema } },
  });
}

export class BaseItem {
  id: string = '';
  name: string = '';
  itemType: string = '';
  parentID: string | null = null;
  version: number = 0;
  createdAt: string | number = '';
  updatedAt: string | number = '';
  orderAt?: string | number | null = null;
  /** 軟刪除標記，true 表示已刪除 */
  isDeleted?: boolean = false;
  /** 軟刪除時間戳 */
  deletedAt?: string | number | null = null;
  /** 後端注入：item_permissions 表資料 */
  _permissions?: ItemPermissionEntry[];
  /** 是否已開啟公開連結分享 */
  isPublic?: boolean = false;
}

// ===== GraphQL wire 格式（Sync 層專用）=====
export interface RawItem {
  id: string;
  name: string;
  itemType: string;
  fields: string;   // JSON.stringify(fields)
}

export interface DeletedItem {
  deletedID: string;
  deletedAt: string;
  version: number;
}

export interface ItemsChangesResult {
  items: RawItem[];
  deletedItems: DeletedItem[];
  hasNextPage: boolean;
  nextVersion: number | null;
  lastItemId: string | null;
}

export interface OperationError {
  index: number;
  message: string;
  relatedID?: string;
}

export interface CreateItemsResult {
  itemIDs: string[];
  errors: OperationError[];
  nextSeq?: number;
  successCount: number;
  failureCount: number;
}

export interface UpdateItemsResult {
  updatedItemIDs: string[];
  errors: OperationError[];
  nextSeq?: number;
  successCount: number;
  failureCount: number;
}

export interface DeleteItemsResult {
  deletedItemIDs: string[];
  errors: OperationError[];
  nextSeq?: number;
  successCount: number;
  failureCount: number;
}

