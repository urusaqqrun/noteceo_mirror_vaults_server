/**
 * 統一 helper：由 plugin descriptor 的 setupI18n 呼叫
 * - 檢查是否已註冊，避免重複
 * - 呼叫 addResourceBundle
 * - 統一補 zh / zh-TW 映射
 */

import i18n from './config';

const NS = 'translation';
const _registered = new Set<string>();

export interface PluginLocaleBundles {
  'en': Record<string, unknown>;
  'zh-Hant': Record<string, unknown>;
  'ja': Record<string, unknown>;
}

/** 註冊 plugin 的 locale bundles，deep merge 到 translation namespace */
export function registerPluginLocales(pluginId: string, bundles: PluginLocaleBundles): void {
  if (_registered.has(pluginId)) return;
  _registered.add(pluginId);

  const zhHant = bundles['zh-Hant'];
  for (const [lng, res] of Object.entries(bundles)) {
    i18n.addResourceBundle(lng, NS, res, true, true);
  }
  if (zhHant) {
    i18n.addResourceBundle('zh', NS, zhHant, true, true);
    i18n.addResourceBundle('zh-TW', NS, zhHant, true, true);
  }
}
