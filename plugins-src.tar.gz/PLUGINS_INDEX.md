# 內建插件索引（自動生成）

> 由 generate-plugin-index.mjs 在部署時自動從原始碼生成
> 生成時間：2026-04-05

---

## 總覽

| 插件 | 顯示名稱 | 類型 | 依賴 | 檔案數 |
|------|---------|------|------|-------|
| AICommanderPlugin | AI 助理 | 基礎設施 | 無 | 23 |
| AutoTaskPlugin | 自動化中心 | 加強功能（猴子補丁） | SidebarPlugin | 23 |
| CardPlugin | 卡片 | 獨立功能 | SidebarPlugin | 38 |
| ChartPlugin | 圖表 | 獨立功能 | SidebarPlugin | 22 |
| ClassifyPlugin | 分類 | 加強功能（猴子補丁） | SidebarPlugin, (NotePlugin), (TodoPlugin) | 17 |
| EditorPlugin | 編輯器 | 基礎設施 | 無 | 63 |
| MaterialLibraryPlugin | 素材庫 | 基礎設施 | NotePlugin | 6 |
| NotePlugin | 筆記 | 獨立功能 | SidebarPlugin, EditorPlugin | 20 |
| SidebarPlugin | 側邊欄 | 基礎設施 | 無 | 21 |
| TodoPlugin | 待辦 | 獨立功能 | SidebarPlugin | 9 |

---

## AICommanderPlugin（AI 助理）

- **類型**：基礎設施
- **始終載入**：是
- **描述**：AICommander 插件

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| AICommander.css | 1644 | 樣式 |
| AICommander.tsx | 372 |  |
| AICommanderChatRoom.css | 283 | AICommanderChatRoom Topbar — 使用 CustomToolbar，僅覆寫 drag 與間距 |
| AICommanderChatRoom.tsx | 1430 |  |
| AICommanderChatRoomTopbarTitle.css | 15 | 樣式 |
| AICommanderChatRoomTopbarTitle.tsx | 129 | 工具條/頂欄 |
| AICommanderFab.tsx | 47 | AICommander 浮動按鈕 (FAB) |
| AICommanderHistory.css | 306 | 樣式 |
| AICommanderHistory.tsx | 374 |  |
| AICommanderHistorySection.tsx | 277 |  |
| AICommanderInputArea.tsx | 1005 |  |
| AICommanderPlugin.tsx | 99 | AICommander 插件 |
| AttachedableEditor.tsx | 1112 |  |
| ChatMessageAssistant.css | 263 | 樣式 |
| ChatMessageAssistant.tsx | 912 |  |
| MentionSuggestionList.css | 108 | 樣式 |
| MentionSuggestionList.tsx | 77 |  |
| SessionLimitDialog.tsx | 50 | 對話框元件 |
| TaskCollection.css | 137 | 樣式 |
| aiStore.ts | 272 | Zustand 狀態管理 |
| chatStore.ts | 1596 | Zustand 狀態管理 |
| mockTaskReportData.ts | 101 |  |
| toolIntentLabel.ts | 54 |  |

---

## AutoTaskPlugin（自動化中心）

- **類型**：加強功能（猴子補丁）
- **依賴**：SidebarPlugin
- **描述**：AI Agent 插件

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| AIAdminDialog.css | 64 | AIAdminDialog - Dialog 樣式 |
| AIAdminDialog.tsx | 27 | 對話框元件 |
| AddTaskTemplateDialog.css | 518 | Category Selection Dialog |
| AddTaskTemplateDialog.tsx | 745 | 對話框元件 |
| AgentBudgetTab.css | 148 | 樣式 |
| AgentBudgetTab.tsx | 88 |  |
| AgentDashboardTab.css | 87 | 樣式 |
| AgentDashboardTab.tsx | 65 |  |
| AgentDetailPanel.css | 101 | 樣式 |
| AgentDetailPanel.tsx | 100 |  |
| AutoTaskPlugin.tsx | 145 | AI Agent 插件 |
| AutoTaskRoom.css | 691 | AutoTaskRoom - 自動化中心 |
| AutoTaskRoom.tsx | 905 |  |
| CEOTaskNotificationList.css | 337 | CEO 任務報告列表 |
| CEOTaskNotificationList.tsx | 296 |  |
| TaskEditDialog.css | 62 | Task Edit Dialog |
| TaskEditDialog.tsx | 49 | 對話框元件 |
| TaskEditor.css | 572 | Task Editor Component Styles |
| TaskEditor.tsx | 580 |  |
| agentHookWatcher.ts | 57 |  |
| ai/agentAI.ts | 33 |  |
| autoTaskStore.ts | 201 | Zustand 狀態管理 |
| patches/NoteList_FolderTaskTags_patch.tsx | 109 |  |

---

## CardPlugin（卡片）

- **類型**：獨立功能
- **依賴**：SidebarPlugin
- **描述**：卡片插件

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| AddCardDialog.css | 499 | 樣式 |
| AddCardDialog.tsx | 1170 | 對話框元件 |
| AddCardTemplateDialog.css | 620 | 樣式 |
| AddCardTemplateDialog.tsx | 1112 | 對話框元件 |
| CardContextMenu.tsx | 60 | 功能表元件 |
| CardDeleteFolderDialog.tsx | 46 | 對話框元件 |
| CardGallery.css | 1406 | Google Material Symbols 圖標樣式 |
| CardGallery.tsx | 3132 |  |
| CardGalleryMapView.css | 216 | CardGalleryMapView 地圖視圖樣式 |
| CardGalleryMapView.tsx | 387 | 視圖元件 |
| CardGalleryPlugin.tsx | 19 | CardGallery 插件 |
| CardGroupDialog.tsx | 37 | 對話框元件 |
| CardLinkPreviewExtension.tsx | 242 |  |
| CardListView.css | 427 | CardListView 卡片列表視圖樣式 |
| CardListView.tsx | 899 | 視圖元件 |
| CardPlugin.tsx | 282 | 卡片插件 |
| CardPreviewDialog.tsx | 109 | 對話框元件 |
| CardTemplateDialog.tsx | 25 | 對話框元件 |
| CardWindowContent.tsx | 47 |  |
| DeleteCardConfirmDialog.tsx | 59 | 刪除卡片確認對話框（純 UI） |
| EditTemplateDialog.tsx | 27 | 對話框元件 |
| LazyCard.tsx | 66 |  |
| MembersInfoStore.ts | 234 | Zustand 狀態管理 |
| NoEditPermissionDialog.tsx | 34 | 對話框元件 |
| PermissionNotificationItem.tsx | 77 | 列表項元件 |
| RequestPermissionDialog.tsx | 70 | 對話框元件 |
| ReviewsListDialog.css | 263 | ReviewsList 組件樣式 |
| ReviewsListDialog.tsx | 350 | 對話框元件 |
| WriteReviewDialog.css | 99 | ReviewDialog 樣式 |
| WriteReviewDialog.tsx | 119 | 對話框元件 |
| ai/cardAI.ts | 246 | Card plugin — AI functions |
| ai/prompts.ts | 14 | Card plugin — AI prompt templates |
| cardStore.ts | 618 | Zustand 狀態管理 |
| reviewStore.ts | 63 | Zustand 狀態管理 |
| shareGallery/EditHistoryPanel.css | 182 | EditHistoryPanel 樣式 |
| shareGallery/EditHistoryPanel.tsx | 126 |  |
| shareGallery/PublicGalleryErrorPage.tsx | 41 |  |
| shareGallery/PublicGalleryView.tsx | 11 | 視圖元件 |

---

## ChartPlugin（圖表）

- **類型**：獨立功能
- **依賴**：SidebarPlugin
- **描述**：图表插件

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| AddChartDialog.css | 126 | 樣式 |
| AddChartDialog.tsx | 273 | 對話框元件 |
| AddChartTypeDialog.tsx | 140 | 對話框元件 |
| ChartDetailPanel.css | 90 | 樣式 |
| ChartDetailPanel.tsx | 133 |  |
| ChartDetailView.tsx | 196 | 自包含的圖表詳情 View |
| ChartEmbedView.tsx | 96 | ChartEmbedView — Chart 插件的嵌入式預覽渲染器 |
| ChartLinkPreviewExtension.tsx | 239 |  |
| ChartList.tsx | 425 |  |
| ChartListView.tsx | 163 | 自包含的圖表列表 View |
| ChartPlugin.tsx | 341 | 图表插件 |
| ChartRender.css | 87 | 樣式 |
| ChartRender.tsx | 513 |  |
| ChartReportPlugin.tsx | 19 | ChartReportView 插件 |
| ChartReportView.css | 389 | 樣式 |
| ChartReportView.tsx | 300 | 視圖元件 |
| ChartTable.tsx | 75 |  |
| ChartWindowContent.tsx | 49 |  |
| EditChartTypeDialog.tsx | 34 | 對話框元件 |
| NoteChartExtension.css | 130 | 樣式 |
| NoteChartExtension.tsx | 200 |  |
| chartStore.ts | 220 | Zustand 狀態管理 |

---

## ClassifyPlugin（分類）

- **類型**：加強功能（猴子補丁）
- **依賴**：SidebarPlugin
- **可選依賴**：NotePlugin, TodoPlugin

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| ClassificationService.ts | 368 | 服務引擎 |
| ClassifyHint.css | 77 | 樣式 |
| ClassifyHint.tsx | 164 |  |
| ClassifyPlugin.tsx | 163 | 插件主入口 |
| ai/classifyAI.ts | 292 | classify plugin — AI functions |
| ai/prompts.ts | 117 | classify plugin — prompt templates |
| classifyStore.ts | 173 | Zustand 狀態管理 |
| classifyUtils.ts | 256 |  |
| patches/ClassifyDecoration.css | 609 | ===== paused-notes-tag（還原暫停狀態按鈕） ===== |
| patches/NoteItem_ClassifyDecoration_patch.tsx | 302 | 列表項元件 |
| patches/TodoItem_ClassifyDecoration_patch.tsx | 252 | 列表項元件 |
| patches/noteStore_classify_patch.ts | 264 |  |
| patches/note_menu_classify_patch.tsx | 152 |  |
| patches/sidebar_classify_patch.tsx | 224 |  |
| patches/todoStore_classify_patch.ts | 193 |  |
| patches/todolist_temp_folder_patch.tsx | 192 |  |
| patches/toolbar_classify_patch.tsx | 489 |  |

---

## EditorPlugin（編輯器）

- **類型**：基礎設施
- **始終載入**：是
- **描述**：筆記編輯器插件（預載）

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| AddMenu.tsx | 112 | 功能表元件 |
| AddUrlDialog.css | 70 | 樣式 |
| AddUrlDialog.tsx | 264 | 對話框元件 |
| AudioContainer.tsx | 99 |  |
| AudioPlayer.css | 138 | 樣式 |
| AudioPlayer.tsx | 172 |  |
| AudioRecorder.css | 68 | 樣式 |
| AudioRecorder.tsx | 188 |  |
| AudioTranscriptDialog.css | 154 | 樣式 |
| AudioTranscriptDialog.tsx | 103 | 對話框元件 |
| CustomMetaBar.css | 77 | EditorMetaBar 樣式 |
| CustomMetaBar.tsx | 128 |  |
| EditNoteTagDialog.css | 135 | 樣式 |
| EditNoteTagDialog.tsx | 360 | 對話框元件 |
| EditorPlaceholder.css | 113 | 樣式 |
| EditorPlaceholder.tsx | 54 |  |
| EditorPlugin.tsx | 24 | 筆記編輯器插件（預載） |
| MarkdownEditor.tsx | 1519 |  |
| NoteEditor.css | 1554 | 樣式 |
| NoteEditor.tsx | 305 |  |
| NoteEditorMenu.css | 277 | 菜单容器通用样式 |
| NoteEditorMenu.tsx | 1183 | 功能表元件 |
| NoteEditorMetaBar.tsx | 186 |  |
| NoteEditorTable.css | 432 | 表格樣式 |
| NoteEditorTitle.tsx | 143 |  |
| NoteEditorToolbar.css | 471 | 列表選單容器 |
| NoteEditorToolbar.tsx | 1127 | 工具條/頂欄 |
| NoteEditorTopbar.tsx | 351 | 工具條/頂欄 |
| NoteLinkTag.css | 190 | NoteLinkTag.css |
| SearchReplaceDialog.css | 208 | 樣式 |
| SearchReplaceDialog.tsx | 488 | 對話框元件 |
| SetReminderTimeDialog.css | 365 | 樣式 |
| SetReminderTimeDialog.tsx | 285 | 對話框元件 |
| TableSizeSelector.tsx | 45 |  |
| TemplateLinkPreview.css | 285 | TemplateLinkPreview.css |
| TitleEditor.css | 204 | EditorTitle 樣式 |
| TitleEditor.tsx | 138 |  |
| UpdateNotification.css | 50 | 更新通知樣式 |
| UpdateNotification.tsx | 33 |  |
| WebPreviewCard.css | 75 | 樣式 |
| ai/editorAI.ts | 177 | editorAI.ts — AI functions for the editor plugin |
| ai/prompts.ts | 44 | prompts.ts — Prompt templates for editor plugin AI functions |
| editorStore.ts | 197 | Zustand 狀態管理 |
| extensions/CodeBlockCopy.ts | 96 |  |
| extensions/CustomKeyboardShortcuts.ts | 193 |  |
| extensions/DragHandleExtension.tsx | 1173 |  |
| extensions/HistoryManager.ts | 125 | 簡單的歷史管理器 |
| extensions/ImageExtension.ts | 433 |  |
| extensions/IndentExtension.ts | 126 |  |
| extensions/ItemEmbedExtension.tsx | 110 | ItemEmbedExtension — 通用嵌入式預覽（editor 基礎設施） |
| extensions/ListUtils.ts | 863 | 統一的列表按鈕處理函數 |
| extensions/MarkdownClipboard.ts | 893 |  |
| extensions/NoteEditorColorUtils.ts | 282 |  |
| extensions/RewriteHighlight.ts | 29 |  |
| extensions/TableDragHandleExtension.tsx | 1492 |  |
| extensions/WebPreviewDecoration.ts | 118 |  |
| hooks/useAIProcessing.ts | 362 |  |
| hooks/useAudioRecording.ts | 446 |  |
| hooks/useEditorKeyboard.ts | 403 |  |
| hooks/useImageUpload.ts | 506 |  |
| hooks/useLinkHandler.ts | 109 |  |
| hooks/useNoteActions.ts | 166 |  |
| hooks/useWebsitePreview.ts | 127 |  |

---

## MaterialLibraryPlugin（素材庫）

- **類型**：基礎設施
- **依賴**：NotePlugin
- **始終載入**：是
- **描述**：MaterialLibrary 插件

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| MaterialLibrary.css | 441 | 樣式 |
| MaterialLibrary.tsx | 1113 |  |
| MaterialLibraryHistoryItem.tsx | 34 | 列表項元件 |
| MaterialLibraryListItem.tsx | 204 | 列表項元件 |
| MaterialLibraryPlugin.tsx | 83 | MaterialLibrary 插件 |
| MiniEditor.tsx | 204 |  |

---

## NotePlugin（筆記）

- **類型**：獨立功能
- **依賴**：SidebarPlugin, EditorPlugin
- **描述**：筆記插件（含 NoteList + NoteEditor）

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| AddSubCategoryDialog.tsx | 75 | 對話框元件 |
| EditFolderSummaryDialog.css | 211 | 樣式 |
| EditFolderSummaryDialog.tsx | 131 | 對話框元件 |
| EditIndexCategoryDialog.css | 59 | 編輯板塊對話框特定樣式 |
| EditIndexCategoryDialog.tsx | 139 | 對話框元件 |
| NoteEmbedView.tsx | 74 | NoteEmbedView — Note 插件的嵌入式預覽渲染器 |
| NoteItem.css | 467 | NoteItem 組件樣式 |
| NoteItem.tsx | 403 | 列表項元件 |
| NoteList.css | 666 | NoteList 容器樣式 |
| NoteList.tsx | 1738 |  |
| NoteListPlugin.tsx | 19 | NoteList 插件 |
| NoteListToolBar.tsx | 188 |  |
| NoteListTopbar.tsx | 167 | 工具條/頂欄 |
| NotePlugin.tsx | 595 | 筆記插件（含 NoteList + NoteEditor） |
| NoteRightClickMenu.tsx | 210 | 功能表元件 |
| NoteSidebar.css | 17 | ===== Note Plugin Sidebar 專用樣式 ===== |
| NoteWindowContent.tsx | 25 |  |
| ai/noteAI.ts | 169 | Note plugin — AI functions |
| ai/prompts.ts | 37 | Note plugin — AI prompt templates |
| noteStore.ts | 603 | Zustand 狀態管理 |

---

## SidebarPlugin（側邊欄）

- **類型**：基礎設施
- **始終載入**：是
- **描述**：Sidebar 插件

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| ConnectionStatusDot.tsx | 31 |  |
| FolderList.css | 234 | 樣式 |
| FolderTree/DragContext.ts | 27 |  |
| FolderTree/FolderGroup.tsx | 226 | 可折疊 BaseItem 群組渲染 |
| FolderTree/FolderItem.tsx | 234 | 單個 BaseItem 節點渲染 |
| FolderTree/FolderTree.tsx | 60 | 通用資料夾樹容器 |
| FolderTree/FolderTreeGroup.tsx | 113 | 可折疊資料夾群組渲染 |
| FolderTree/FolderTreeItem.tsx | 84 | 單個資料夾節點渲染 |
| FolderTree/GenericFolderTreeSection.tsx | 114 | 通用 tree renderer |
| FolderTree/index.ts | 6 |  |
| GenericSidebarSection.tsx | 91 | 唯一的 section renderer |
| Sidebar.css | 546 | 樣式 |
| Sidebar.tsx | 627 |  |
| SidebarPlugin.tsx | 329 | Sidebar 插件 |
| SidebarTopbar.tsx | 173 | 工具條/頂欄 |
| SuggestionDialog.css | 268 | 建議對話框容器 |
| SuggestionDialog.tsx | 226 | 對話框元件 |
| UpdateDialog.css | 190 | 樣式 |
| UpdateDialog.tsx | 68 | 對話框元件 |
| UserAvatar.tsx | 39 |  |
| sidebarStore.ts | 191 | Sidebar 插件化註冊中心 |

---

## TodoPlugin（待辦）

- **類型**：獨立功能
- **依賴**：SidebarPlugin
- **描述**：待辦插件（含 TodoList + TodoEditor）

### 檔案

| 檔案 | 行數 | 說明 |
|------|------|------|
| DeleteIndexDialog.tsx | 43 | 對話框元件 |
| TodoEmbedView.tsx | 139 | TodoEmbedView — Todo 插件的嵌入式預覽渲染器 |
| TodoItem.css | 919 | TodoItem 組件樣式 |
| TodoItem.tsx | 607 | 列表項元件 |
| TodoList.css | 521 | TodoList 樣式 |
| TodoList.tsx | 2673 |  |
| TodoPlugin.tsx | 442 | 待辦插件（含 TodoList + TodoEditor） |
| TodoRightClickMenu.tsx | 189 | 功能表元件 |
| todoStore.ts | 419 | Zustand 狀態管理 |

