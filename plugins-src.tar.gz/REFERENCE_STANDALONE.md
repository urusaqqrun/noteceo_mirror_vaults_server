# 插件參考：新增功能型（Standalone）

> 建立有自己 Sidebar section + View + Store 的獨立插件時閱讀此文件。

---

## Plugin 基類 API

```typescript
abstract class Plugin {
    workspace: Workspace;

    // === 生命週期 ===
    onload(): void                          // 子類實現：註冊 View、Command、事件
    onunload(): void                        // 子類可選：卸載清理

    // === 清理管理 ===
    register(cleanup: () => void): void     // 註冊清理函數，卸載時自動呼叫
    registerEvent(event: string, handler: Function): void  // 訂閱 eventBus
    registerDomEvent(el, type, callback): void             // 訂閱 DOM 事件
    registerInterval(id: ReturnType<typeof setInterval>): void

    // === 高階 API（有畫面的插件必用）===
    registerSidebarWithView(config: SidebarWithViewConfig): void

    // === 低階 API（通常不直接用）===
    registerView(type: string, creator: (leaf) => IView): void
    registerOverlay(id: string, Component: React.FC): void
    registerWindowView(itemType, viewType, options, onOpen?): void
    registerEditorExtension(id: string, ext: Extension): void
    registerSidebarSection(desc: SidebarSectionDescriptor): void
    registerSearchProvider(itemType, provider): void
    registerAISkill({ name, instruction }): void
    registerItemFields(itemType, ext): void
    registerAIHints(itemType, hints: string[]): void
    addCommand({ id, name, hotkeys?, callback }): void

    // === Pane 操作（Protected）===
    protected clearPane(paneId: string): void
    protected ensureLeafInPane(paneId, leafId, viewType, sizing): void
}
```

---

## registerSidebarWithView 完整說明

**有自己畫面的插件必須用這個 API**，一次完成 sidebar + view + 導航訂閱 + pane 掛載。禁止手動拆開成 registerView + registerSidebarSection + subscribe + ensureMounted。

### Config 型別

```typescript
interface SidebarWithViewConfig {
    sidebar: SidebarSectionDescriptor;
    views: Array<{ type: string; creator: (leaf: WorkspaceLeaf) => IView }>;
    activateOnItemTypes: string[];   // path 末端 itemType 在此集合時觸發掛載
    isDefault?: boolean;             // path 為空時也掛載（僅預設插件為 true）
    panes: {
        centerPane1?: PaneConfig | 'clear';
        centerPane2?: PaneConfig | 'clear';
    };
}

interface PaneConfig {
    leafId: string;      // leaf 唯一 ID
    viewType: string;    // 對應 views 中註冊的 type
    size?: number;       // 固定寬度 (px)
    flex?: number;       // 彈性寬度
    minSize?: number;    // 最小寬度 (px)
}

interface SidebarSectionDescriptor {
    id: string;          // 穩定唯一 ID（不隨 i18n 變動）
    title: string;       // 顯示文字（已翻譯）
    orderAt: number;     // 排序權重，越小越靠上（TODO=200, NOTE=300, CARD=400, CHART=500）
    useData: () => SidebarSectionData;  // hook：回傳 sidebar 資料
    addFolder?: { actionText: string; icon?: React.ReactNode; onClick: () => void };
    hideHeader?: boolean;
}

interface SidebarSectionData {
    items: BaseItem[];              // 可拖曳的資料夾列表
    prefixItems?: BaseItem[];       // tree 前面的固定項目
    suffixItems?: BaseItem[];       // tree 後面的固定項目
    getCount?: (item: BaseItem) => { value: number; pinned?: boolean } | null;
    renderIcon?: (item: BaseItem) => React.ReactNode;
    displayName?: (item: BaseItem) => string;
}
```

**重要**：`items` 中每個 item 的 `itemType` 必須以 `_FOLDER` 結尾，否則不會在 sidebar 顯示。

### 自動行為

呼叫 `registerSidebarWithView` 後，系統自動：
1. 註冊所有 views 到 viewRegistry
2. 註冊 sidebar section
3. 訂閱 `useSelectedItemsStore`，當 `path` 末端的 `itemType` 在 `activateOnItemTypes` 中時，自動把 views 掛到指定 pane

不需要手動寫 `subscribe`、`ensureMounted`、`ensureLeafInPane`。

### 面板結構

```
┌─────────┬──────────────┬──────────────┬──────────┐
│ leftPane│ centerPane1  │ centerPane2  │ rightPane│
│ (sidebar)│ (列表)       │ (詳情/編輯器) │ (AI 面板) │
└─────────┴──────────────┴──────────────┴──────────┘
```

- **雙欄插件**（note, todo, chart）：centerPane1 放列表，centerPane2 放編輯器
- **單欄插件**（card）：centerPane1 設 'clear'，centerPane2 放主視圖

### 雙欄範例

```typescript
this.registerSidebarWithView({
    sidebar: {
        id: 'my-plugin',
        title: '我的插件',
        orderAt: 700,
        useData: useMyPluginSidebarData,
    },
    views: [
        { type: 'my-list', creator: (leaf) => new MyListView(leaf) },
        { type: 'my-detail', creator: (leaf) => new MyDetailView(leaf) },
    ],
    activateOnItemTypes: ['MY_PLUGIN_FOLDER'],
    panes: {
        centerPane1: { leafId: 'leaf-mylist', viewType: 'my-list', size: 350, minSize: 240 },
        centerPane2: { leafId: 'leaf-mydetail', viewType: 'my-detail', flex: 1, minSize: 360 },
    },
});
```

### 單欄範例

```typescript
this.registerSidebarWithView({
    sidebar: {
        id: 'timer',
        title: '計時器',
        orderAt: 700,
        useData: useTimerSidebarData,
    },
    views: [
        { type: 'timer-main', creator: (leaf) => new TimerView(leaf) },
    ],
    activateOnItemTypes: ['TIMER_FOLDER'],
    panes: {
        centerPane1: 'clear',
        centerPane2: { leafId: 'leaf-timer', viewType: 'timer-main', flex: 1, minSize: 300 },
    },
});
```

### useData hook 範例

```typescript
function useMyPluginSidebarData(): SidebarSectionData {
    // 從 itemStore 取得資料夾列表
    const folders = useItemStore(state => state.byType?.MY_PLUGIN_FOLDER || []);
    return {
        items: folders,
        prefixItems: [
            { id: 'my-plugin-root', itemType: 'MY_PLUGIN_FOLDER', name: '全部' },
        ],
        renderIcon: () => <MyIcon />,
    };
}
```

---

## 完整最小範例：計數器插件

### CounterPlugin.tsx（主入口）

```tsx
import { Plugin, ReactView, registerPluginClass, useItemStore } from '@cubelv/sdk';
import './counter.css';

// --- View ---
class CounterListView extends ReactView {
    getViewType() { return 'counter-list'; }
    getDisplayText() { return 'Counter'; }
    renderComponent() {
        return <CounterApp />;
    }
}

// --- React UI ---
function CounterApp() {
    const [count, setCount] = useState(0);
    return (
        <div className="counter-container">
            <div className="counter-label">COUNT</div>
            <div className="counter-value">{count}</div>
            <div className="counter-buttons">
                <button className="counter-btn counter-btn-primary" onClick={() => setCount(c => c + 1)}>+1</button>
                <button className="counter-btn" onClick={() => setCount(0)}>Reset</button>
            </div>
        </div>
    );
}

// --- Plugin ---
class CounterPlugin extends Plugin {
    onload() {
        this.registerSidebarWithView({
            sidebar: {
                id: 'counter',
                name: 'Counter',
                icon: () => <span>🔢</span>,
                useData: () => ({
                    items: [{ id: 'counter-root', itemType: 'COUNTER_FOLDER', name: 'Counter' }],
                    isLoading: false,
                }),
            },
            views: [
                { type: 'counter-list', creator: (leaf) => new CounterListView(leaf) },
            ],
            activateOnItemTypes: ['COUNTER_FOLDER'],
            panes: {
                centerPane1: 'clear',
                centerPane2: { leafId: 'leaf-counter', viewType: 'counter-list', flex: 1, minSize: 300 },
            },
        });
    }
}

registerPluginClass(CounterPlugin, '計數器');
```

### counter.css

```css
.counter-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    gap: 16px;
    background: var(--background);
    color: var(--on);
}
.counter-label {
    font-size: 14px;
    letter-spacing: 2px;
    opacity: 0.5;
}
.counter-value {
    font-size: 72px;
    font-weight: 700;
}
.counter-buttons {
    display: flex;
    gap: 12px;
}
.counter-btn {
    padding: 10px 24px;
    border-radius: 8px;
    border: 1px solid color-mix(in srgb, var(--on) 15%, transparent);
    background: var(--background);
    color: var(--on);
    font-size: 16px;
    cursor: pointer;
}
.counter-btn-primary {
    background: var(--accent);
    color: white;
    border: none;
}
```

---

## Store 模式（zustand）

需要持久化資料的插件用 zustand：

```typescript
import { create } from '@cubelv/sdk';  // zustand create

interface MyPluginState {
    data: MyItem[];
    setData: (data: MyItem[]) => void;
}

export const useMyPluginStore = create<MyPluginState>((set) => ({
    data: [],
    setData: (data) => set({ data }),
}));
```

從 itemStore 讀取資料：
```typescript
const items = useItemStore.getState().byType?.MY_TYPE || [];
```

---

## CSS 主題變數（必用，禁止寫死色碼）

### 核心色彩

| 變數 | 亮色模式 | 暗色模式 | 用途 |
|------|---------|---------|------|
| `--on` | #000000 | #FFFFFF | 文字色 |
| `--background` | #f6f6f6 | #222222 | 頁面背景 |
| `--surface` | 動態計算 | 動態計算 | 面板/卡片背景（比 background 略淺或略深） |
| `--accent` | #FA7500 | #FA7500 | 強調色（橙色） |
| `--primary` | 用戶自選 | 用戶自選 | 主題主色（可能和 accent 不同） |
| `--error` | #FA003A | #FA003A | 錯誤/危險色 |
| `--highlight` | #FFF59D | #665D00 | 高亮/搜尋標記 |
| `--linkcolor` | #3264E5 | #66B3FF | 連結色 |

### 其他

| 變數 | 用途 |
|------|------|
| `--rainbow` | 漸變色（裝飾用） |

### 半透明技巧

```css
/* 10% 不透明度的文字色（用於邊框、分隔線） */
color-mix(in srgb, var(--on) 10%, transparent)

/* 60% 不透明度（用於次要文字） */
color-mix(in srgb, var(--on) 60%, transparent)
```

### 圖表專用色（10 色）

`--chart-oceanBlue`, `--chart-mintGreen`, `--chart-tangerineOrange`, `--chart-cherryRed`, `--chart-lavenderPurple`, `--chart-slateGrey`, `--chart-turquoiseTeal`, `--chart-orchidMagenta`, `--chart-sunsetOrange`, `--chart-tropicalCyan`

---

## 檔案命名規則

- 入口：`{CodeStem}Plugin.tsx`（必須以 Plugin.tsx 結尾）
- Store：`{codeStem}Store.ts`
- CSS：`{codeStem}.css`
- 其他元件：PascalCase，如 `CounterView.tsx`
- CSS class prefix：`.{codeStem}-*`

---

## 後端 Service

如果插件需要後端功能（REST API、webhook、server-side），請參閱 **REFERENCE_BACKEND.md**。

---

## 交付前 Checklist

- [ ] 入口檔為 `*Plugin.tsx`
- [ ] 呼叫了 `registerPluginClass(MyPlugin, '顯示名稱')`
- [ ] CSS 只使用 `var(--*)` 主題變數
- [ ] 至少 3 個檔案（Plugin + View/UI + CSS）
- [ ] 第三方庫有寫在 package.json 的 dependencies 中
