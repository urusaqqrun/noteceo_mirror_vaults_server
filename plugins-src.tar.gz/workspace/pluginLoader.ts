// ===== pluginLoader — Runtime 插件動態載入器 =====
//
// 負責：
// 1. 呼叫主進程 esbuild 打包插件原始碼（本地開發用）
// 2. 從 server 下載已編譯的 bundle（線上插件鍛造用）
// 3. eval 執行打包後的 bundle
// 4. 從 bundle 導出的 Plugin 類進行註冊
// 5. 透過 PluginManager 掛載插件

import type { Workspace } from './Workspace';
import { useItemStore } from '../Store/itemStore';
import { useSelectedItemsStore } from '../Store/navigationStore';
import { loadDisabledSet, getAllPluginDescriptors } from './pluginRegistry';
import { getItemSchemaRegistry } from '../types/item';
import { useSidebarRegistry } from '../components/plugins/sidebar/sidebarStore';

// descriptor.id → PLUGIN item (動態載入時建立的對應關係)
const _dynamicPluginItems = new Map<string, any>();

// descriptor.id → 該插件透過 @itemType 註冊的 itemType 集合
const _dynamicPluginItemTypes = new Map<string, string[]>();

/** 取得該動態插件註冊的 itemType 列表 */
export function getCustomPluginItemTypes(descriptorId: string): string[] {
    return _dynamicPluginItemTypes.get(descriptorId) ?? [];
}

// pluginDir → <style> element（動態插件 CSS 注入追蹤）
const _pluginStyleElements = new Map<string, HTMLStyleElement>();

/** 取得 descriptor 對應的 PLUGIN item（僅自定義插件有） */
export function getCustomPluginItem(descriptorId: string): any | undefined {
    return _dynamicPluginItems.get(descriptorId);
}

/** 刪除 descriptor 對應的動態 PLUGIN item 關聯 */
export function forgetCustomPluginItem(descriptorId: string): void {
    _dynamicPluginItems.delete(descriptorId);
}

/**
 * 通用 require shim — esbuild IIFE bundle 裡的 require() 呼叫會走這裡
 * 從 window.__NC__ 動態解析模組，AI 不管 import 什麼都能處理
 */
function installRequireShim(): void {
    if ((window as any).__nc_require_installed__) return;

    // 建立 bare module name → window.__NC__ 的映射
    // 頂層 key (React, ReactDOM, zustand, i18next, reactI18next) 直接對應
    // sdk 下的 key 透過 @cubelv/sdk 存取
    const NC = (window as any).__NC__;
    if (!NC) return;

    // react/jsx-runtime: esbuild --jsx=automatic 產生的 JSX 呼叫需要這些
    const jsxRuntime = {
        jsx: NC.React.createElement,
        jsxs: NC.React.createElement,
        Fragment: NC.React.Fragment,
    };

    const moduleMap: Record<string, any> = {
        'react': NC.React,
        'react/jsx-runtime': jsxRuntime,
        'react/jsx-dev-runtime': jsxRuntime,
        'react-dom': NC.ReactDOM,
        'react-dom/client': NC.ReactDOM,
        'zustand': NC.zustand,
        'zustand/middleware': NC.zustand,
        'i18next': NC.i18next,
        'react-i18next': NC.reactI18next,
        '@cubelv/sdk': NC.sdk,
    };

    (window as any).require = (name: string) => {
        // 1. 精確匹配
        if (moduleMap[name] !== undefined) return moduleMap[name];

        // 2. 檢查 window.__NC__ 頂層（AI 可能 import 未預期的名稱）
        if (NC[name] !== undefined) return NC[name];

        // 3. 檢查 SDK 命名空間
        if (NC.sdk?.[name] !== undefined) return NC.sdk[name];

        console.error(`[pluginLoader] require("${name}") 未知模組。共享模組請從 window.__NC__ 取得，第三方庫應由 esbuild 打包進 bundle。`);
        return {};
    };

    // 把所有 React hooks 暴露到全域 — AI 生成的代碼經常忘記 import hooks，
    // esbuild 不會報錯（當成全域變數），但 eval 時會 ReferenceError。
    // 自動收集 React 上所有 use* 開頭的函數，不手動列舉。
    const React = NC.React;
    const hookVarParts: string[] = [];
    for (const key of Object.keys(React)) {
        if (key.startsWith('use') && typeof React[key] === 'function') {
            if (!(window as any)[key]) (window as any)[key] = React[key];
            hookVarParts.push(`${key}=window.${key}`);
        }
    }
    // 生成 eval 前注入的 var 宣告（讓 IIFE scope 內也能存取 hooks）
    (window as any).__nc_hook_shim__ = hookVarParts.length > 0 ? `var ${hookVarParts.join(',')};\n` : '';

    (window as any).__nc_require_installed__ = true;
    console.log('[pluginLoader] require shim 已安裝');
}


/**
 * 動態載入一個 runtime 插件
 *
 * @param pluginDir - 插件目錄的絕對路徑（內含 main.tsx）
 * @param workspace - Workspace 實例
 * @returns 成功與否
 */
export async function loadDynamicPlugin(
    pluginDir: string,
    workspace: Workspace,
): Promise<{ success: boolean; error?: string }> {
    try {
        const entryPath = `${pluginDir}/main.tsx`;

        // 1. 呼叫主進程 esbuild 打包
        const result = await (window as any).electronAPI.pluginBuild({ entryPath });

        if (!result.success) {
            console.error('[pluginLoader] 打包失敗:', result.error);
            return { success: false, error: result.error };
        }

        // 2. eval 執行 bundle（先確保 require shim 已安裝）
        installRequireShim();
        const prevPlugin = (window as any).__plugin__;
        try {
            const hookShim = (window as any).__nc_hook_shim__ || '';
            // eslint-disable-next-line no-eval
            (0, eval)(hookShim + result.code);
        } catch (evalErr: any) {
            console.error('[pluginLoader] eval 失敗:', evalErr);
            return { success: false, error: `eval failed: ${evalErr.message}` };
        }

        const pluginExports = (window as any).__plugin__;
        // 清理全域變數
        (window as any).__plugin__ = prevPlugin;

        if (!pluginExports) {
            return { success: false, error: 'Bundle did not export anything' };
        }

        // 3. bundle 的 default export 應該是 { default: PluginClass } 或直接就是 PluginClass
        //    也可能是 bundle 內部已經呼叫了 registerPluginClass()（推薦方式）
        //    如果是推薦方式，bundle eval 時就已經註冊了，不需額外操作

        console.log('[pluginLoader] 插件已載入:', pluginDir);
        return { success: true };

    } catch (err: any) {
        console.error('[pluginLoader] 載入失敗:', err);
        return { success: false, error: err.message };
    }
}

/**
 * 從 server 下載 bundle.css 並注入 <style> 到 DOM
 * 若 server 回 204（無 CSS），則不注入
 */
async function fetchAndInjectCSS(baseUrl: string, memberID: string, pluginDir: string): Promise<void> {
    try {
        const url = `${baseUrl}/api/vault/plugin/css?memberID=${encodeURIComponent(memberID)}&plugin=${encodeURIComponent(pluginDir)}`;
        const resp = await fetch(url, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('accessToken') || ''}` },
        });
        if (!resp.ok || resp.status === 204) return;
        const css = await resp.text();
        if (!css.trim()) return;

        removePluginCSS(pluginDir);

        const style = document.createElement('style');
        style.setAttribute('data-plugin', pluginDir);
        style.textContent = css;
        document.head.appendChild(style);
        console.log(`[pluginLoader] ${pluginDir}: CSS 已注入 (${css.length} bytes)`);
    } catch (err) {
        console.warn(`[pluginLoader] ${pluginDir}: CSS 載入失敗（非致命）:`, err);
    }
}

/** 移除指定插件的 <style> 標籤 */
export function removePluginCSS(pluginDir: string): void {
    const existing = _pluginStyleElements.get(pluginDir);
    if (existing) {
        existing.remove();
        _pluginStyleElements.delete(pluginDir);
    }
    document.querySelectorAll(`style[data-plugin="${pluginDir}"]`).forEach(el => el.remove());
}

// Bundle 快取 key prefix
const BUNDLE_CACHE_PREFIX = 'plugin-bundle-';

// 記錄 loadDynamicPlugins 開始前的 sidebar section IDs，用於偵測新插件
let _sectionsBefore = new Set<string>();

/**
 * 新插件掛載後，找出它新註冊的 sidebar section 並模擬導航
 * → 觸發插件的 useSelectedItemsStore 訂閱 → 插件自己的 ensureMounted() 處理佈局
 */
function autoNavigateToNewPlugin(): void {
    const currentSections = useSidebarRegistry.getState().getSections();
    const newSection = currentSections.find(s => !_sectionsBefore.has(s.id));
    if (!newSection) return;

    _sectionsBefore.add(newSection.id);

    // 取 section data 的第一個 item，模擬 sidebar 點擊
    try {
        const data = newSection.useData();
        const firstItem = data?.items?.[0];
        if (firstItem) {
            console.log(`[pluginLoader] 自動導航到 sidebar section: ${newSection.id}`);
            useSelectedItemsStore.getState().setSelectedItems([firstItem]);
        }
    } catch {
        // useData 是 hook，在非 React context 下可能失敗 → 靜默跳過
    }
}

/**
 * 從 itemStore 載入所有動態插件（PLUGIN items）
 * 在 app 啟動時，於內建插件載入後呼叫
 */
export async function loadDynamicPlugins(workspace: Workspace, _retries = 0): Promise<void> {
    // 記錄載入前已有的 sidebar sections
    _sectionsBefore = new Set(useSidebarRegistry.getState().getSections().map(s => s.id));

    const store = useItemStore.getState();
    const allTypes = Object.keys(store.byType || {});
    console.log(`[pluginLoader] loadDynamicPlugins called (retry=${_retries}), byType keys: [${allTypes.join(', ')}]`);
    const pluginItems: any[] = store.byType?.PLUGIN || [];
    console.log(`[pluginLoader] PLUGIN items count: ${pluginItems.length}`, pluginItems.map((p: any) => ({ id: p._id || p.id, status: p.status, pluginDir: p.pluginDir, bundleHash: p.bundleHash })));
    const disabledSet = loadDisabledSet();
    console.log(`[pluginLoader] disabledSet:`, [...disabledSet]);
    const plugins = pluginItems.filter((item) => {
        const pass = item.status === 'active' && !disabledSet.has(item.id) && !disabledSet.has(item.pluginDir);
        if (!pass) console.log(`[pluginLoader] filtered out: id=${item.id} status=${item.status} pluginDir=${item.pluginDir}`);
        return pass;
    });

    if (plugins.length === 0) {
        console.log(`[pluginLoader] no active plugins found (retry=${_retries}/3)`);
        // sync 可能還沒完成，等一下再試（最多重試 3 次，每次 3 秒）
        if (_retries < 3) {
            await new Promise(r => setTimeout(r, 3000));
            return loadDynamicPlugins(workspace, _retries + 1);
        }
        console.log(`[pluginLoader] gave up after 3 retries`);
        return;
    }

    console.log(`[pluginLoader] 載入 ${plugins.length} 個動態插件...`);

    const baseUrl = (window as any).__NC_API_BASE__ || 'https://dev.cubelv.com';
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    const memberID = userData.ID || localStorage.getItem('local_UID') || '';

    // 用 Git status 偵測哪些 plugin 有變更
    const changedDirs = await checkPluginGitUpdates(baseUrl);

    for (const plugin of plugins) {
        const pluginDir = plugin.pluginDir;
        if (!pluginDir) continue;

        try {
            const cacheKey = BUNDLE_CACHE_PREFIX + pluginDir;
            let code: string | null = localStorage.getItem(cacheKey);

            // 快取不存在 或 Git 偵測到有變更 → 重新下載
            if (!code || changedDirs.has(pluginDir)) {
                const url = `${baseUrl}/api/vault/plugin/bundle?memberID=${encodeURIComponent(memberID)}&plugin=${encodeURIComponent(pluginDir)}`;
                const resp = await fetch(url, {
                    headers: { 'Authorization': `Bearer ${localStorage.getItem('accessToken') || ''}` },
                });
                if (!resp.ok) {
                    console.error(`[pluginLoader] ${pluginDir}: fetch 失敗 (${resp.status})`);
                    if (resp.status === 404) {
                        const itemId = plugin.id || plugin._id;
                        console.warn(`[pluginLoader] ${pluginDir}: vault 不存在，清除孤兒 item ${itemId}`);
                        useItemStore.getState().removeItems([itemId], { needSync: true }).catch(() => {});
                        cleanupDeletedPlugin(pluginDir).catch(() => {});
                    }
                    continue;
                }
                code = await resp.text();

                try {
                    localStorage.setItem(cacheKey, code);
                } catch { /* storage full */ }

                console.log(`[pluginLoader] ${pluginDir}: 已下載 (git updated)`);
            } else {
                console.log(`[pluginLoader] ${pluginDir}: 使用快取`);
            }

            // 載入 CSS（bundle.css），不阻塞 JS eval
            fetchAndInjectCSS(baseUrl, memberID, pluginDir);

            // eval bundle（先確保 require shim 已安裝）
            installRequireShim();
            const beforeCount = getAllPluginDescriptors().length;
            const schemaKeysBefore = new Set(getItemSchemaRegistry().keys());
            const prevPlugin = (window as any).__plugin__;
            try {
                // 在 bundle 前注入 React hooks 宣告，解決 AI 生成代碼忘記 import hooks 的問題
                const hookShim = (window as any).__nc_hook_shim__ || '';
                (0, eval)(hookShim + code);
            } catch (evalErr: any) {
                console.error(`[pluginLoader] ${pluginDir}: eval 失敗:`, evalErr);
                continue;
            }
            (window as any).__plugin__ = prevPlugin;

            // 比對 eval 前後新增的 itemType（由 @itemType 裝飾器註冊）
            const newItemTypes: string[] = [];
            for (const key of getItemSchemaRegistry().keys()) {
                if (!schemaKeysBefore.has(key)) newItemTypes.push(key);
            }

            const afterDescs = getAllPluginDescriptors();
            const newDescs = afterDescs.slice(beforeCount);
            for (const desc of newDescs) {
                _dynamicPluginItems.set(desc.id, plugin);
                if (newItemTypes.length > 0) {
                    _dynamicPluginItemTypes.set(desc.id, newItemTypes);
                    console.log(`[pluginLoader] ${desc.id} 註冊的 itemTypes:`, newItemTypes);
                }
            }
            const pm = workspace.pluginManager;
            const loadedNames = new Set(pm.getAll().map((p: any) => p.constructor.name));
            for (const desc of newDescs) {
                if (loadedNames.has(desc.id)) {
                    continue;
                }
                try {
                    const instance = new desc.ctor(workspace);
                    pm.registerPlugin(instance);
                    console.log(`[pluginLoader] ✅ ${desc.id} (${desc.name}) 已掛載`);
                    // 透過 sidebar 導航觸發插件自己的佈局邏輯
                    autoNavigateToNewPlugin();
                } catch (regErr: any) {
                    console.error(`[pluginLoader] ${pluginDir}: ${desc.id} 掛載失敗:`, regErr);
                }
            }

        } catch (err: any) {
            console.error(`[pluginLoader] ${pluginDir}: 載入失敗:`, err);
        }
    }

    // 摘要
    const allLoaded = workspace.pluginManager.getAll().map((p: any) => p.constructor.name);
    const dynamicDescs = getAllPluginDescriptors().slice(allLoaded.length > 0 ? 0 : 0);
    console.log(`[pluginLoader] 完成 — pluginManager 共 ${allLoaded.length} 個插件:`, allLoaded.join(', '));
}

// ===== Plugin Deletion Cleanup =====

/**
 * 刪除插件後的本地清理：移除 localStorage 快取 + 本地 vault sync 目錄
 */
/** 用 Git status API 偵測哪些 plugin 有變更 */
async function checkPluginGitUpdates(baseUrl: string): Promise<Set<string>> {
    const lastCommit = localStorage.getItem('plugin-git-last-commit') || '';
    try {
        const resp = await fetch(`${baseUrl}/api/vault/plugins/git/status?since=${encodeURIComponent(lastCommit)}`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('accessToken') || ''}` },
        });
        if (!resp.ok) return new Set();
        const { headCommit, files } = await resp.json();

        const changed = new Set<string>();
        for (const f of (files || [])) {
            const dir = (f.path || '').split('/')[0];
            if (dir) changed.add(dir);
        }

        if (headCommit) {
            localStorage.setItem('plugin-git-last-commit', headCommit);
        }

        if (changed.size > 0) {
            console.log(`[pluginLoader] git: ${changed.size} plugins changed since ${lastCommit?.substring(0, 8) || 'start'}`);
        }
        return changed;
    } catch (e) {
        console.warn('[pluginLoader] git status check failed:', e);
        return new Set();
    }
}

export async function cleanupDeletedPlugin(pluginDir: string): Promise<void> {
    removePluginCSS(pluginDir);

    const cacheKey = BUNDLE_CACHE_PREFIX + pluginDir;
    localStorage.removeItem(cacheKey);
    console.log(`[pluginCleanup] ${pluginDir}: 已清除 bundle 快取`);

    const syncDir = localStorage.getItem('vaultSyncDir');
    const electronAPI = (window as any).electronAPI;
    if (syncDir && electronAPI?.deletePluginSyncDir) {
        try {
            await electronAPI.deletePluginSyncDir({ syncDir, pluginDir: 'plugins/' + pluginDir });
            console.log(`[pluginCleanup] ${pluginDir}: 已刪除本地 sync 目錄`);
        } catch (err: any) {
            console.error(`[pluginCleanup] ${pluginDir}: 刪除本地 sync 目錄失敗:`, err);
        }
    }
}
