// ===== PluginManager — 插件生命週期管理 =====

import type { Workspace } from './Workspace';
import type { Plugin } from './Plugin';

/**
 * PluginManager — 管理所有插件的載入和卸載
 *
 * - registerPlugin(plugin) — 註冊並載入插件
 * - unregisterPlugin(plugin) — 卸載並移除插件
 * - unloadAll() — 卸載全部插件
 *
 * 新增插件只需 new XxxPlugin(workspace) + manager.registerPlugin(plugin)，
 * 不修改任何現有文件。
 */
export class PluginManager {
    workspace: Workspace;
    private plugins: Set<Plugin> = new Set();

    constructor(workspace: Workspace) {
        this.workspace = workspace;
    }

    /** 註冊並載入插件 */
    registerPlugin(plugin: Plugin): void {
        if (this.plugins.has(plugin)) return;
        this.plugins.add(plugin);
        try {
            plugin.onload();
        } catch (e) {
            console.error(`[PluginManager] Plugin onload error:`, e);
        }
    }

    /** 卸載並移除插件 */
    unregisterPlugin(plugin: Plugin): void {
        if (!this.plugins.has(plugin)) return;
        plugin._destroy();
        this.plugins.delete(plugin);
    }

    /** 卸載全部插件 */
    unloadAll(): void {
        for (const plugin of this.plugins) {
            plugin._destroy();
        }
        this.plugins.clear();
    }

    /** 取得所有已載入的插件 */
    getAll(): Plugin[] {
        return [...this.plugins];
    }
}
