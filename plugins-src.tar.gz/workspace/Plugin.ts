// ===== Plugin — 插件基類（參考 Obsidian Component 生命週期）=====

import { apiFireAndForget, isLoggedIn } from '../aiService/apiClient';
import type { Workspace } from './Workspace';
import type { ViewCreator, WindowOptions } from './types';
import { WorkspaceLeaf } from './WorkspaceLeaf';
import { EmptyView } from './View';
import { useOverlayStore } from '../Store/overlayStore';
import { eventBus } from '../Store/eventBus';
import type { ComponentType } from 'react';
import type { Extension } from '@tiptap/core';
import { useEditorExtensionRegistry } from '../Store/editorExtensionRegistry';
import { useSidebarRegistry } from '../components/plugins/sidebar/sidebarStore';
import type { SidebarSectionDescriptor } from '../components/plugins/sidebar/sidebarStore';
import { useSearchRegistry } from '../Store/searchRegistry';
import type { SearchProvider } from '../Store/searchRegistry';
import { useCommandManager } from '../Store/commandManager';
import type { HotkeyDef } from '../Store/commandManager';
import {
    extendItemSchema, removeItemSchemaExtension,
    addAIHints, removeAIHints,
    type SchemaExtension,
} from '../types/item';
import { useSelectedItemsStore } from '../Store/navigationStore';

// ========== 高階 API 型別 ==========

export interface PaneConfig {
    leafId: string;
    viewType: string;
    size?: number;
    flex?: number;
    minSize?: number;
}

export interface SidebarWithViewConfig {
    sidebar: SidebarSectionDescriptor;
    views: Array<{ type: string; creator: ViewCreator }>;
    /** 當 path 末端的 itemType 在此集合時，觸發掛載 */
    activateOnItemTypes: string[];
    /** path 為空時也掛載（預設 false，僅預設插件為 true） */
    isDefault?: boolean;
    /** 面板配置；'clear' = 清空該 pane，不帶 = 不動 */
    panes: {
        centerPane1?: PaneConfig | 'clear';
        centerPane2?: PaneConfig | 'clear';
    };
}

/**
 * Plugin — 應用功能模組的基類
 *
 * 每個插件在 onload() 中自行註冊 View、Command 等，
 * onunload() 時自動清理。
 *
 * 用法：
 *   class NotePlugin extends Plugin {
 *     onload() {
 *       this.registerView('note-editor', (leaf) => new NoteEditorView(leaf));
 *       this.registerOverlay('classifyHint', ClassifyHint);
 *       this.registerEvent('contextMenu', (data) => { ... });
 *       this.registerDomEvent(window, 'keydown', (e) => { ... });
 *     }
 *   }
 */
export abstract class Plugin {
    workspace: Workspace;
    private _cleanups: (() => void)[] = [];

    constructor(workspace: Workspace) {
        this.workspace = workspace;
    }

    /** 子類覆寫：載入插件，註冊 View / Command 等 */
    abstract onload(): void;

    /** 子類可覆寫：卸載插件，清理資源 */
    onunload(): void { }

    // ========== 生命週期管理 ==========

    /** 註冊清理函式，卸載時自動調用（對應 Obsidian Component.register） */
    register(cleanup: () => void): void {
        this._cleanups.push(cleanup);
    }

    /** 訂閱 eventBus 事件，卸載時自動取消（對應 Obsidian Component.registerEvent） */
    registerEvent(event: string, handler: (...args: any[]) => void | Promise<void>): void {
        const unsub = eventBus.on(event, handler);
        this._cleanups.push(unsub);
    }

    /** 訂閱 DOM 事件，卸載時自動取消（對應 Obsidian Component.registerDomEvent） */
    registerDomEvent<K extends keyof WindowEventMap>(
        el: Window, type: K,
        callback: (ev: WindowEventMap[K]) => any,
        options?: boolean | AddEventListenerOptions,
    ): void;
    registerDomEvent<K extends keyof DocumentEventMap>(
        el: Document, type: K,
        callback: (ev: DocumentEventMap[K]) => any,
        options?: boolean | AddEventListenerOptions,
    ): void;
    registerDomEvent<K extends keyof HTMLElementEventMap>(
        el: HTMLElement, type: K,
        callback: (ev: HTMLElementEventMap[K]) => any,
        options?: boolean | AddEventListenerOptions,
    ): void;
    registerDomEvent(el: any, type: string, callback: (ev: any) => any, options?: any): void {
        el.addEventListener(type, callback, options);
        this._cleanups.push(() => el.removeEventListener(type, callback, options));
    }

    /** 註冊 setInterval，卸載時自動清除（對應 Obsidian Component.registerInterval） */
    registerInterval(id: ReturnType<typeof setInterval>): void {
        this._cleanups.push(() => clearInterval(id));
    }

    // ========== View / Overlay 註冊 ==========

    /** 註冊 View 類型（卸載時自動取消註冊） */
    registerView(type: string, creator: ViewCreator): void {
        this.workspace.viewRegistry.register(type, creator);
        this._cleanups.push(() => {
            this.workspace.viewRegistry.unregister(type);
        });
    }

    /** 註冊全局 Overlay（卸載時自動取消註冊） */
    registerOverlay(id: string, Component: ComponentType): void {
        useOverlayStore.getState().register(id, Component);
        this._cleanups.push(() => useOverlayStore.getState().unregister(id));
    }

    /** 宣告 itemType 可開獨立視窗，Workspace.openWindow() 會查詢此註冊表 */
    registerWindowView(
        itemType: string,
        viewType: string,
        windowOptions: WindowOptions,
        onOpen?: (itemId: string) => void,
    ): void {
        this.workspace.windowViewRegistry.set(itemType, { viewType, windowOptions, onOpen });
        this._cleanups.push(() => this.workspace.windowViewRegistry.delete(itemType));
    }

    /** 註冊 Editor 擴展（卸載時自動取消註冊） */
    registerEditorExtension(id: string, ext: Extension | Extension[]): void {
        useEditorExtensionRegistry.getState().register(id, ext);
        this._cleanups.push(() => useEditorExtensionRegistry.getState().unregister(id));
    }

    /** 註冊 Sidebar section（卸載時自動取消註冊） */
    registerSidebarSection(desc: SidebarSectionDescriptor): void {
        useSidebarRegistry.getState().registerSection(desc);
        this._cleanups.push(() => useSidebarRegistry.getState().unregisterSection(desc.id));
    }

    /**
     * 一次完成 sidebar + view + 導航訂閱 + pane 掛載。
     * 取代手動串接 registerView → registerSidebarSection → subscribe → ensureMounted。
     */
    registerSidebarWithView(config: SidebarWithViewConfig): void {
        for (const v of config.views) {
            this.registerView(v.type, v.creator);
        }
        this.registerSidebarSection(config.sidebar);

        const typeSet = new Set(config.activateOnItemTypes);
        this.register(useSelectedItemsStore.subscribe((state) => {
            const last = state.path.at(-1);
            const shouldShow = config.isDefault
                ? (!last || typeSet.has(last.itemType))
                : (last != null && typeSet.has(last.itemType));
            if (shouldShow) this._mountPanes(config.panes);
        }));
    }

    private _mountPanes(panes: SidebarWithViewConfig['panes']): void {
        if (panes.centerPane1 === 'clear') {
            this.clearPane('centerPane1');
        } else if (panes.centerPane1) {
            const p = panes.centerPane1;
            this.ensureLeafInPane('centerPane1', p.leafId, p.viewType, {
                size: p.size, flex: p.flex, minSize: p.minSize,
            });
        }
        if (panes.centerPane2 === 'clear') {
            this.clearPane('centerPane2');
        } else if (panes.centerPane2) {
            const p = panes.centerPane2;
            this.ensureLeafInPane('centerPane2', p.leafId, p.viewType, {
                size: p.size, flex: p.flex, minSize: p.minSize,
            });
        }
    }

    /** 註冊 Search provider（卸載時自動取消註冊） */
    registerSearchProvider(itemType: string, provider: SearchProvider): void {
        useSearchRegistry.getState().register(itemType, provider);
        this._cleanups.push(() => useSearchRegistry.getState().unregister(itemType));
    }

    /** 註冊 AI Skill（推送 .skills/{name}.md 到 vault，卸載時自動取消註冊） */
    registerAISkill({ name, instruction }: { name: string; instruction: string }): void {
        pushSkillToVault(name, instruction);
        this._cleanups.push(() => {
            // 推送空內容以移除 skill
            pushSkillToVault(name, '');
        });
    }

    /** 為已註冊的 itemType 追加欄位（卸載時自動移除並重新推送 schema） */
    registerItemFields(itemType: string, ext: SchemaExtension): void {
        const sourceId = this.constructor.name;
        extendItemSchema(sourceId, itemType, ext);
        this._cleanups.push(() => removeItemSchemaExtension(sourceId));
    }

    /** 註冊 AI Hints（附加 aiHints 到 itemType schema 並推送到 vault，卸載時自動移除） */
    registerAIHints(itemType: string, hints: string[]): void {
        const sourceId = this.constructor.name;
        addAIHints(sourceId, itemType, hints);
        this._cleanups.push(() => removeAIHints(sourceId));
    }

    /** 註冊 Command + 預設快捷鍵（Obsidian addCommand 做法，卸載時自動取消註冊） */
    addCommand(config: {
        id: string;
        name: string;
        hotkeys?: HotkeyDef[];
        checkCallback?: (checking: boolean) => boolean;
        callback?: () => void;
    }): void {
        const unsub = useCommandManager.getState().register({
            command: {
                id: config.id,
                name: config.name,
                checkCallback: config.checkCallback,
                callback: config.callback,
            },
            hotkeys: config.hotkeys ?? [],
        });
        this._cleanups.push(unsub);
    }

    // ========== Pane 操作輔助方法 ==========

    /**
     * 清空 pane 內的所有子節點（銷毀 leaf 及其 view）
     * 注意：不使用 leaf.detach()，因為 removeChild 的空容器自動清理會銷毀 pane 本身。
     */
    protected clearPane(paneId: string): void {
        const pane = this.workspace.getParentById(paneId);
        if (!pane) return;
        // 手動關閉所有 leaf 的 view，然後直接清空 children
        for (const child of pane.children) {
            if (child instanceof WorkspaceLeaf && child.view) {
                child.view.onClose();
                child.view = null;
            }
            child.parent = null;
        }
        pane.children = [];
    }

    /**
     * 確保指定 pane 中有且僅有一個指定 ID 和 viewType 的 leaf。
     * 如果該 leaf 已存在於該 pane 中則跳過，否則清空 pane 再插入新 leaf。
     *
     * @param paneId   - pane 容器的 ID（如 'centerPane1'）
     * @param leafId   - leaf 的唯一 ID（如 'leaf-notelist'）
     * @param viewType - view 類型（如 'note-list'）
     * @param sizing   - 尺寸配置（size/flex/minSize）
     */
    protected ensureLeafInPane(
        paneId: string,
        leafId: string,
        viewType: string,
        sizing: { size?: number; flex?: number; minSize?: number },
    ): void {
        const ws = this.workspace;

        const existingLeaf = ws.getLeafById(leafId);
        if (existingLeaf && existingLeaf.view?.getViewType() === viewType) {
            return;
        }

        // 佈局還原時 ViewCreator 尚未註冊，leaf 會持有 EmptyView（missingType 記錄原始型別）。
        // 此時 leaf 上的 sizeValue 是用戶上次拖曳的結果，不應覆蓋。
        if (existingLeaf && existingLeaf.view instanceof EmptyView && existingLeaf.view.missingType === viewType) {
            const pendingState = existingLeaf.view.getPendingState();
            const creator = ws.viewRegistry.get(viewType);
            if (creator) {
                existingLeaf.view.onClose();
                (existingLeaf as WorkspaceLeaf).view = creator(existingLeaf as WorkspaceLeaf);
                (existingLeaf as WorkspaceLeaf).view!.onOpen();
                if (Object.keys(pendingState).length > 0) {
                    void (existingLeaf as WorkspaceLeaf).view!.setState(pendingState, { history: false });
                }
            }
            return;
        }

        this.clearPane(paneId);
        const pane = ws.getParentById(paneId);
        if (!pane) return;

        // 創建新 leaf
        const leaf = new WorkspaceLeaf(ws, leafId);
        leaf.sizeValue = sizing.size;
        leaf.flexValue = sizing.flex;
        leaf.minSizeValue = sizing.minSize;

        // 插入 pane
        pane.children.push(leaf);
        leaf.parent = pane;

        // 設置 view（這會觸發 view 創建）
        leaf.setViewState({ type: viewType });

        ws.trigger('layout-change');
    }

    /** 內部：執行清理 */
    _destroy(): void {
        for (const cleanup of this._cleanups) {
            try { cleanup(); } catch (e) { console.error('[Plugin] cleanup error:', e); }
        }
        this._cleanups = [];
        this.onunload();
    }
}

function pushSkillToVault(name: string, instruction: string) {
    if (!isLoggedIn()) return;
    apiFireAndForget({
        url: 'https://dev.cubelv.com/api/vault/skills',
        body: { skills: { [name]: instruction } },
    });
}
