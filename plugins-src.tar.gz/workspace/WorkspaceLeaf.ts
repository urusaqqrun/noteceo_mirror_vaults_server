// ===== WorkspaceLeaf — 葉節點 =====

import { WorkspaceItem } from './WorkspaceItem';
import { EmptyView } from './View';
import type {
    IWorkspaceLeaf,
    IWorkspaceParent,
    IWorkspace,
    IView,
    ViewState,
    LeafNodeJSON,
} from './types';

/**
 * WorkspaceLeaf — 樹的終端節點
 *
 * - 持有一個 View，View 負責實際的內容渲染
 * - 支持 ViewState 序列化/反序列化
 * - 支持 pinned（釘選）和 group（群組聯動）
 */
export class WorkspaceLeaf extends WorkspaceItem implements IWorkspaceLeaf {
    view: IView | null = null;
    pinned: boolean = false;
    group: string | null = null;
    declare parent: IWorkspaceParent | null;

    constructor(workspace: IWorkspace, id?: string) {
        super(workspace, id);
    }

    // ========== View 狀態管理 ==========

    /** 取得當前 ViewState */
    getViewState(): ViewState {
        if (!this.view) {
            return { type: 'empty', state: {} };
        }
        return {
            type: this.view.getViewType(),
            state: this.view.getState(),
            active: this === this.workspace.activeLeaf,
            pinned: this.pinned,
            group: this.group,
        };
    }

    /** 設置 ViewState（可能觸發 View 替換） */
    async setViewState(viewState: ViewState): Promise<void> {
        const needReplaceView =
            !this.view || this.view.getViewType() !== viewState.type;

        if (needReplaceView) {
            // 關閉舊 View
            if (this.view) {
                await this.view.onClose();
            }

            // 從 Registry 創建新 View
            // 注意：這裡需要通過 workspace 取得 viewRegistry
            const workspaceWithRegistry = this.workspace as IWorkspace & { viewRegistry?: Map<string, (leaf: typeof this) => IView> };
            const creator = workspaceWithRegistry.viewRegistry?.get(viewState.type);

            if (creator) {
                this.view = creator(this);
                await this.view.onOpen();
            } else {
                this.view = new EmptyView(this, viewState.type);
                await this.view.onOpen();
            }

            this.trigger('view-change', this.view);
        }

        // 恢復狀態
        if (this.view && viewState.state) {
            await this.view.setState(viewState.state, { history: false });
        }

        // 更新屬性
        if (viewState.pinned !== undefined) this.pinned = viewState.pinned;
        if (viewState.group !== undefined) this.group = viewState.group ?? null;

        this.workspace.trigger('layout-change');
    }

    // ========== Pin 機制 ==========

    togglePinned(): void {
        this.setPinned(!this.pinned);
    }

    setPinned(pinned: boolean): void {
        this.pinned = pinned;
        this.trigger('pinned-change', pinned);
        this.workspace.trigger('layout-change');
    }

    // ========== 群組 ==========

    setGroup(group: string): void {
        this.group = group;
        this.trigger('group-change', group);
    }

    // ========== 移除 ==========

    /** 從樹中移除自己 */
    detach(): void {
        if (this.view) {
            this.view.onClose();
        }
        if (this.parent) {
            this.parent.removeChild(this);
        }
        this.workspace.trigger('leaf-removed', this);
        this.workspace.trigger('layout-change');
    }

    // ========== 序列化 ==========

    serialize(): LeafNodeJSON {
        return {
            id: this.id,
            type: 'leaf',
            state: {
                type: this.view?.getViewType() ?? 'empty',
                state: this.view?.getState() ?? {},
            },
            pinned: this.pinned,
            group: this.group,
            size: this.sizeValue,
            flex: this.flexValue,
            minSize: this.minSizeValue,
        };
    }

    destroy(): void {
        if (this.view) {
            this.view.onClose();
            this.view = null;
        }
    }
}
