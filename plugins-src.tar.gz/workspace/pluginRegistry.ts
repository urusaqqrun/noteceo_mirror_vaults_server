// ===== pluginRegistry — Plugin 自動發現 + 啟用控制 + 依賴排序 =====

import type { Plugin } from './Plugin';
import type { Workspace } from './Workspace';
import { generateObjectID } from '../../../services/utils/objectIDUtil.mjs';

type PluginConstructor = new (ws: Workspace) => Plugin;

export interface PluginOptions {
    dependencies?: string[];          // 硬依賴：缺一個就不掛載
    optionalDependencies?: string[];  // 可選依賴：有就排後面，沒有也能掛
    alwaysLoaded?: boolean;           // 預載插件：永遠載入，不顯示在管理面板
    descriptionKey?: string;          // i18n key：說明該模組功能
    setupI18n?: () => void;           // i18n 註冊，由 registerPluginLocales 統一處理
}

export interface PluginDescriptor {
    id: string;             // = ctor.name（自動取類別名）
    name: string;           // UI 顯示名稱
    ctor: PluginConstructor;
    dependencies: string[];
    optionalDependencies: string[];
    alwaysLoaded: boolean;
    descriptionKey?: string;
}

// ===== 發現層 =====

const _discovered: PluginDescriptor[] = [];

/** 由各 Plugin 檔案在模組層級呼叫，id 自動取 ctor.name */
export function registerPluginClass(ctor: PluginConstructor, name: string, options?: PluginOptions): void {
    const id = ctor.name;
    if (_discovered.some(d => d.id === id)) return;
    options?.setupI18n?.();
    _discovered.push({
        id,
        name,
        ctor,
        dependencies: options?.dependencies ?? [],
        optionalDependencies: options?.optionalDependencies ?? [],
        alwaysLoaded: options?.alwaysLoaded ?? false,
        descriptionKey: options?.descriptionKey,
    });
}

/** 從已發現列表中移除指定 id 的 descriptor */
export function unregisterPluginClass(id: string): void {
    const idx = _discovered.findIndex(d => d.id === id);
    if (idx !== -1) _discovered.splice(idx, 1);
}

/** 取得所有已發現的插件描述（給 UI 用） */
export function getAllPluginDescriptors(): readonly PluginDescriptor[] {
    return _discovered;
}

// ===== 啟用層（PLUGIN_PREFS item 持久化，跨裝置同步）=====

const LEGACY_STORAGE_KEY = 'enabled-plugins';

/**
 * 從 itemStore 的 PLUGIN_PREFS item 讀取被關閉的插件 ID 集合
 * fallback: 舊版 localStorage migration
 */
export function loadDisabledSet(): Set<string> {
    try {
        // 動態 import 避免循環依賴（pluginRegistry 在 itemStore 之前初始化）
        const itemStore = (window as any).__NC__?.sdk?.useItemStore;
        if (itemStore) {
            const store = itemStore.getState();
            const prefsItems = store.byType?.PLUGIN_PREFS || [];
            const prefs = prefsItems[0];
            if (prefs) {
                const disabled = prefs.disabled || prefs.fields?.disabled || [];
                return new Set(disabled);
            }
        }
    } catch { /* store not ready yet */ }

    // migration: 舊版 localStorage → 轉換為 disabled 格式
    try {
        const raw = localStorage.getItem(LEGACY_STORAGE_KEY);
        if (raw) {
            const enabled = new Set(JSON.parse(raw) as string[]);
            const all = _discovered.map(d => d.id);
            return new Set(all.filter(id => !enabled.has(id)));
        }
    } catch { /* ignore */ }

    return new Set(); // 全部啟用
}

/** 更新 PLUGIN_PREFS item 的 disabled 列表 */
export async function saveDisabledPlugins(disabled: string[]): Promise<void> {
    const itemStore = (window as any).__NC__?.sdk?.useItemStore;
    if (!itemStore) return;

    const store = itemStore.getState();
    const prefsItems = store.byType?.PLUGIN_PREFS || [];
    const existing = prefsItems[0];

    await store.upsertItem({
        id: existing?.id || generateObjectID(),
        itemType: 'PLUGIN_PREFS',
        name: '插件偏好設定',
        disabled,
    }, { needSync: true });

    // 清除舊 localStorage
    localStorage.removeItem(LEGACY_STORAGE_KEY);
}

/** 取得應該載入的 Plugin（未設定偏好 → 全部啟用），已按依賴拓撲排序 */
export function getEnabledPlugins(): PluginDescriptor[] {
    const disabledSet = loadDisabledSet();
    const candidates = _discovered.filter(d => d.alwaysLoaded || !disabledSet.has(d.id));
    return topoSort(candidates);
}

// ===== 拓撲排序 =====

/**
 * 依 dependencies + optionalDependencies 做拓撲排序（Kahn's algorithm）
 * 1. dependencies 不滿足 → 插件被排除
 * 2. dependencies + optionalDependencies（已啟用的）都當邊
 */
function topoSort(plugins: PluginDescriptor[]): PluginDescriptor[] {
    const enabledIds = new Set(plugins.map(p => p.id));

    // 過濾掉 dependencies 不滿足的插件
    const valid: PluginDescriptor[] = [];
    const removed = new Set<string>();
    let changed = true;
    const remaining = [...plugins];
    while (changed) {
        changed = false;
        for (let i = remaining.length - 1; i >= 0; i--) {
            const p = remaining[i];
            const missingDep = p.dependencies.find(dep => !enabledIds.has(dep) || removed.has(dep));
            if (missingDep) {
                console.warn(`[pluginRegistry] ${p.id} 跳過：硬依賴 ${missingDep} 未啟用`);
                removed.add(p.id);
                enabledIds.delete(p.id);
                remaining.splice(i, 1);
                changed = true;
            }
        }
    }

    // 建圖：dependencies + optionalDependencies（已啟用的）都當邊
    const inDegree = new Map<string, number>();
    const adj = new Map<string, string[]>();
    const descMap = new Map<string, PluginDescriptor>();

    for (const p of remaining) {
        descMap.set(p.id, p);
        inDegree.set(p.id, 0);
        adj.set(p.id, []);
    }

    for (const p of remaining) {
        const allEdges = [
            ...p.dependencies,
            ...p.optionalDependencies.filter(id => enabledIds.has(id)),
        ];
        for (const dep of allEdges) {
            if (enabledIds.has(dep)) {
                adj.get(dep)!.push(p.id);
                inDegree.set(p.id, (inDegree.get(p.id) ?? 0) + 1);
            }
        }
    }

    // Kahn's algorithm
    const queue: string[] = [];
    for (const [id, deg] of inDegree) {
        if (deg === 0) queue.push(id);
    }

    const result: PluginDescriptor[] = [];
    while (queue.length > 0) {
        const id = queue.shift()!;
        result.push(descMap.get(id)!);
        for (const next of adj.get(id) ?? []) {
            const newDeg = (inDegree.get(next) ?? 1) - 1;
            inDegree.set(next, newDeg);
            if (newDeg === 0) queue.push(next);
        }
    }

    // 如果有環（不應該發生），把剩餘的也加進去
    if (result.length < remaining.length) {
        const sorted = new Set(result.map(r => r.id));
        for (const p of remaining) {
            if (!sorted.has(p.id)) {
                console.warn(`[pluginRegistry] ${p.id} 可能有循環依賴，強制加入`);
                result.push(p);
            }
        }
    }

    console.log('[pluginRegistry] 掛載順序:', result.map(r => r.id).join(' → '));
    return result;
}
