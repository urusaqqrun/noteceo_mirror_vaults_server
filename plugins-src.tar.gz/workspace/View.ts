// ===== View — 內容渲染器抽象基類 =====

import type { IView, IWorkspaceLeaf, ViewStateResult } from './types';
import i18n from '../i18n/config';

/**
 * View — Leaf 中顯示的實際內容
 *
 * 子類需要覆寫：
 * - getViewType() — 視圖類型標識
 * - getDisplayText() — 顯示標題
 * - onOpen() — 掛載時渲染 UI
 * - onClose() — 卸載時清理資源
 */
export abstract class View implements IView {
    leaf: IWorkspaceLeaf;
    containerEl: HTMLElement;
    icon: string = 'file';
    navigation: boolean = true;
    /** 設為 true 時，與此 View 相鄰的分隔線會渲染為透明 */
    transparentSeparator: boolean = false;

    constructor(leaf: IWorkspaceLeaf) {
        this.leaf = leaf;
        this.containerEl = document.createElement('div');
        this.containerEl.className = 'workspace-leaf-content';
        this.containerEl.dataset.viewType = this.getViewType();
    }

    // ========== 必須覆寫 ==========

    abstract getViewType(): string;
    abstract getDisplayText(): string;

    // ========== 生命週期 ==========

    async onOpen(): Promise<void> { }
    async onClose(): Promise<void> { }

    // ========== 狀態序列化 ==========

    getState(): Record<string, unknown> {
        return {};
    }

    async setState(_state: unknown, _result: ViewStateResult): Promise<void> { }

    // ========== 瞬態（不持久化） ==========

    getEphemeralState(): Record<string, unknown> {
        return {};
    }

    setEphemeralState(_state: unknown): void { }

    // ========== UI 輔助 ==========

    onResize(): void { }
}

/**
 * EmptyView — 找不到對應 ViewCreator 時的佔位 View
 */
export class EmptyView extends View {
    readonly missingType: string;
    private pendingState: Record<string, unknown>;

    constructor(leaf: IWorkspaceLeaf, missingType: string, pendingState: Record<string, unknown> = {}) {
        super(leaf);
        this.missingType = missingType;
        this.pendingState = pendingState;
        this.icon = 'alert-circle';
        this.navigation = false;
    }

    getViewType(): string {
        return 'empty';
    }

    getDisplayText(): string {
        return i18n.t('emptyViewTitle', { type: this.missingType });
    }

    async onOpen(): Promise<void> {
        this.containerEl.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--on-surface-variant,#666);font-size:14px;">
        <div style="text-align:center;">
          <p>${i18n.t('emptyViewMessage', { type: this.missingType })}</p>
          <p style="opacity:0.6;font-size:12px;">${i18n.t('emptyViewHint')}</p>
        </div>
      </div>
    `;
    }

    getState(): Record<string, unknown> {
        return { _missingType: this.missingType };
    }

    getPendingState(): Record<string, unknown> {
        return this.pendingState;
    }
}
