// ===== ReactView — React 元件的 View 橋接基類 =====

import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { View } from './View';
import { ThemeProvider } from '../components/setting/ThemeProvider';
import type { IWorkspaceLeaf, ViewStateResult } from './types';

/**
 * ReactView — 讓 View 可以渲染 React 元件
 *
 * 子類只需覆寫：
 * - getViewType()
 * - getDisplayText()
 * - renderComponent() — 返回 React.ReactNode
 *
 * 橋接邏輯：
 * - onOpen() 時用 createRoot 掛載 React 元件到 containerEl
 * - onClose() 時 unmount 清理
 * - rerender() 用於 state 變更時重新渲染
 *
 * 每個 ReactView 都是獨立的 React root，需要自行包裹全域 Provider
 */
export abstract class ReactView extends View {
    protected reactRoot: Root | null = null;

    private wrapWithProviders(node: React.ReactNode): React.ReactNode {
        return (
            <ThemeProvider>
                <React.Suspense fallback={null}>
                    {node}
                </React.Suspense>
            </ThemeProvider>
        );
    }

    async onOpen(): Promise<void> {
        this.reactRoot = createRoot(this.containerEl);
        this.reactRoot.render(this.wrapWithProviders(this.renderComponent()));
    }

    async onClose(): Promise<void> {
        // 延遲 unmount 避免 React 在 commit 階段被打斷
        const root = this.reactRoot;
        this.reactRoot = null;
        if (root) {
            setTimeout(() => root.unmount(), 0);
        }
    }

    /**
     * 子類覆寫：返回要渲染的 React 元件
     */
    abstract renderComponent(): React.ReactNode;

    /**
     * state 變更時重新渲染
     * 子類在 setState 中調用
     */
    protected rerender(): void {
        if (this.reactRoot) {
            this.reactRoot.render(this.wrapWithProviders(this.renderComponent()));
        }
    }

    /**
     * 覆寫 setState，自動觸發重新渲染
     */
    async setState(state: unknown, result: ViewStateResult): Promise<void> {
        await super.setState(state, result);
        this.rerender();
    }
}
