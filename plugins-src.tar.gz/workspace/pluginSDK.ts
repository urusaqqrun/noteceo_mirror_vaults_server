/// <reference types="vite/client" />
// ===== pluginSDK — 宿主 SDK 暴露（類似 Obsidian 的 require('obsidian')）=====
//
// 把 CubeLV 核心 API 掛到 window.__NC__，
// esbuild 打包的外部插件透過 window.__NC__ 取用這些模組。
//
// workspace/、Store/ 下的所有 named export 透過 import.meta.glob 自動收集，
// 新增檔案或 export 時不需要手動維護此檔案。

import React from 'react';
import ReactDOM from 'react-dom';
import * as zustand from 'zustand';
import i18next from 'i18next';
import * as reactI18next from 'react-i18next';

// 自動收集 CubeLV 核心 export — 必須與 deploy-web.sh 打包範圍完全對齊
// CLI 看得到的就要包，看不到的就不包
const sdkModules = import.meta.glob<Record<string, any>>([
    './*.ts',
    './*.tsx',
    '!./pluginSDK.ts',
    '../Store/*.ts',
    '../Store/*.tsx',
    '../types/item.ts',
    '../i18n/registerPluginLocales.ts',
    '../components/plugins/**/*.ts',
    '../components/plugins/**/*.tsx',
    '../components/common/*.ts',
    '../components/common/*.tsx',
    '../components/setting/ThemeProvider.tsx',
], { eager: true });

/**
 * 初始化宿主 SDK：把 CubeLV API 掛到 window.__NC__
 * 應在 WorkspaceBootstrap 初始化時呼叫一次
 */
export function initPluginSDK(): void {
    const coreSdk: Record<string, any> = {};
    for (const mod of Object.values(sdkModules)) {
        Object.assign(coreSdk, mod);
    }
    // 讓 forge 插件可以 import { i18next } from '@cubelv/sdk'
    coreSdk.i18next = i18next;

    const NC: Record<string, any> = {
        React, ReactDOM, zustand, i18next, reactI18next,
    };

    // Proxy：import { anything } from '@cubelv/sdk' 時
    // 先查 coreSdk（CubeLV 核心），找不到就自動遍歷 __NC__ 頂層命名空間
    // 注意：fallback 查詢的對象在 Proxy 建立前快照，避免 NC.sdk 造成無限遞迴
    const fallbackNamespaces = Object.values(NC).filter(v => v && typeof v === 'object');

    const sdk = new Proxy(coreSdk, {
        get(target, prop) {
            if (typeof prop === 'symbol') return target[prop as any];
            if (prop in target) return target[prop];
            for (const ns of fallbackNamespaces) {
                if (prop in ns) return ns[prop];
            }
            return undefined;
        },
        has(target, prop) {
            if (typeof prop === 'symbol') return prop in target;
            if (prop in target) return true;
            for (const ns of fallbackNamespaces) {
                if (prop in ns) return true;
            }
            return false;
        },
    });

    NC.sdk = sdk;
    (window as any).__NC__ = NC;

    console.log('[pluginSDK] 宿主 SDK 已掛載到 window.__NC__');
}
