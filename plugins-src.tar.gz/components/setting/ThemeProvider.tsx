import React, { createContext, useContext, useState, useEffect } from 'react';

// 顏色計算工具函數
function calculateSurface(primary, background, isDarkMode) {
  // 如果是亮色主題，直接返回白色
  if (!isDarkMode) {
    return '#FFFFFF';
  }

  function rgbToHsv(hex) {
    const r = parseInt(hex.slice(1, 3), 16) / 255;
    const g = parseInt(hex.slice(3, 5), 16) / 255;
    const b = parseInt(hex.slice(5, 7), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const d = max - min;

    let h;
    const s = max === 0 ? 0 : d / max;
    const v = max;

    if (max === min) {
      h = 0;
    } else {
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return [h * 360, s, v];
  }

  function hsvToHex(h, s, v) {
    h = h / 360;
    let r, g, b;
    const i = Math.floor(h * 6);
    const f = h * 6 - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);

    switch (i % 6) {
      case 0: r = v; g = t; b = p; break;
      case 1: r = q; g = v; b = p; break;
      case 2: r = p; g = v; b = t; break;
      case 3: r = p; g = q; b = v; break;
      case 4: r = t; g = p; b = v; break;
      case 5: r = v; g = p; b = q; break;
    }

    const toHex = x => {
      const hex = Math.round(x * 255).toString(16);
      return hex.length === 1 ? '0' + hex : hex;
    };

    return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
  }

  const primaryHsv = rgbToHsv(primary);      // 獲取 primary 的 HSV
  const backgroundHsv = rgbToHsv(background);

  // 使用 primary 的色相
  const surfaceH = primaryHsv[0];
  const surfaceS = 0.02;
  const surfaceV = backgroundHsv[2] + 0.06;

  return hsvToHex(surfaceH, surfaceS, surfaceV);
}

// 添加計算標籤背景的函數
function calculateTagBackground(isDarkMode, on) {
  const opacity = isDarkMode ? '8%' : '6%';
  return `color-mix(in srgb, ${on} ${opacity}, transparent)`;
}

// 所有顏色都使用 CSS 變數
export const colors = {
  variables: {
    light: {
      // 主色系的值
      primary: {
        'blue': '#0091FF',
        'apple-green': '#40B850',
        'pink': '#E03682',
        'purple': '#5665D6',
        'sea-blue': '#00B2D6'
      },

      // 基礎顏色
      '--accent': '#FA7500',
      '--error': '#FA003A',
      '--on': '#000000',
      '--background': '#f6f6f6',
      '--highlight': '#FFF59D',  // 淺色主題的螢光筆顏色
      '--linkcolor': '#3264E5',  // 淺色主題的連結顏色 (c12)

      // 彩色文字漸變
      '--rainbow': 'linear-gradient(to right, #7000FF, #FF00D6, #FF7A00)',

      // Chart 專用配色（10 色）
      '--chart-oceanBlue': '#008FFB',
      '--chart-mintGreen': '#00E396',
      '--chart-tangerineOrange': '#FEB019',
      '--chart-cherryRed': '#FF4560',
      '--chart-lavenderPurple': '#775DD0',
      '--chart-slateGrey': '#546E7A',
      '--chart-turquoiseTeal': '#26a69a',
      '--chart-orchidMagenta': '#D10CE8',
      '--chart-sunsetOrange': '#F86624',
      '--chart-tropicalCyan': '#00D9E9'
    },
    dark: {
      // 主色系的值
      primary: {
        'blue': '#24adf6',
        'apple-green': '#40B850',
        'pink': '#E0679D',
        'purple': '#BE82FF',
        'sea-blue': '#00BFE0'
      },

      // 基礎顏色
      '--accent': '#FA7500',
      '--error': '#FA003A',
      '--on': '#FFFFFF',
      '--background': '#222222',
      '--highlight': '#665D00',  // 深色主題的螢光筆顏色
      '--linkcolor': '#66B3FF',

      // 彩色文字漸變
      '--rainbow': 'linear-gradient(to right, #C687FE, #FF8DCC, #FFCA57)',

      // Chart 專用配色（10 色）
      '--chart-oceanBlue': '#008FFB',
      '--chart-mintGreen': '#00E396',
      '--chart-tangerineOrange': '#FEB019',
      '--chart-cherryRed': '#FF4560',
      '--chart-lavenderPurple': '#775DD0',
      '--chart-slateGrey': '#546E7A',
      '--chart-turquoiseTeal': '#26a69a',
      '--chart-orchidMagenta': '#D10CE8',
      '--chart-sunsetOrange': '#F86624',
      '--chart-tropicalCyan': '#00D9E9'
    }
  }
};

// 導出可用的顏色列表
export const PrimaryColors = ['blue', 'apple-green', 'pink', 'purple', 'sea-blue'];

// 深色主題的編輯器顏色
export const DarkEditorColors = [
  { id: 'c1', color: 'var(--on)' },
  { id: 'c2', color: 'color-mix(in srgb, var(--on) 75%, transparent)' },
  { id: 'c3', color: 'color-mix(in srgb, var(--on) 50%, transparent)' },
  { id: 'c4', color: '#FF5E00' },
  { id: 'c5', color: '#C45833' },
  { id: 'c6', color: '#FF8B63' },
  { id: 'c7', color: '#DDBF0F' },
  { id: 'c8', color: '#F8E67A' },
  { id: 'c9', color: '#91D696' },
  { id: 'c10', color: '#4EA354' },
  { id: 'c11', color: '#3D9900' },
  { id: 'c12', color: '#66B3FF' },
  { id: 'c13', color: '#2FAEED' },
  { id: 'c14', color: '#00FBFF' },
  { id: 'c15', color: '#84DFF2' },
  { id: 'c16', color: '#85A7FF' },
  { id: 'c17', color: '#8750E5' },
  { id: 'c18', color: '#BF94E4' },
  { id: 'c19', color: '#EA6B8D' },
  { id: 'c20', color: '#FF4275' },
  { id: 'c21', color: '#E53D2E' },
];

// 淺色主題的編輯器顏色
export const LightEditorColors = [
  { id: 'c1', color: 'var(--on)' },
  { id: 'c2', color: 'color-mix(in srgb, var(--on) 75%, transparent)' },
  { id: 'c3', color: 'color-mix(in srgb, var(--on) 50%, transparent)' },
  { id: 'c4', color: '#D1562C' },
  { id: 'c5', color: '#FF5E00' },
  { id: 'c6', color: '#FF8B63' },
  { id: 'c7', color: '#E8A405' },
  { id: 'c8', color: '#F2C705' },
  { id: 'c9', color: '#8FB236' },
  { id: 'c10', color: '#4EA354' },
  { id: 'c11', color: '#3D9900' },
  { id: 'c12', color: '#3264E5' },
  { id: 'c13', color: '#008DD4' },
  { id: 'c14', color: '#00CFE5' },
  { id: 'c15', color: '#17ABC2' },
  { id: 'c16', color: '#5975FF' },
  { id: 'c17', color: '#7218CC' },
  { id: 'c18', color: '#A04EF2' },
  { id: 'c19', color: '#EA547C' },
  { id: 'c20', color: '#D33E70' },
  { id: 'c21', color: '#E53D2E' },
];

// 文字透明度層級
const textAlpha = {
  primary: 1,
  secondary: 0.7,
  disabled: 0.5,
  hint: 0.3
};

interface ThemeContextType {
  mode: string;
  primaryColor: string;
  displaySize: string;
  themePreference: string;
  setMode: (newMode: string) => void;
  setPrimaryColor: (color: string) => void;
  setDisplaySize: (size: string) => void;
  [key: string]: any;
}

const ThemeContext = createContext<ThemeContextType | null>(null);

// 同步讀取初始主題值（避免頁面載入時閃爍）
const getInitialDarkMode = () => {
  const saved = localStorage.getItem('themeMode');
  if (saved && saved !== 'system') {
    return saved === 'dark';
  }
  // 預設使用白色模式，不跟隨系統
  return false;
};

const getInitialThemePreference = () => {
  // 預設使用白色模式，不跟隨系統
  return localStorage.getItem('themeMode') || 'light';
};

export function ThemeProvider({ children }) {
  const [isDarkMode, setIsDarkMode] = useState(getInitialDarkMode);
  const [primaryColor, setPrimaryColor] = useState('purple');
  const [displaySize, setDisplaySize] = useState('normal');
  const [themePreference, setThemePreference] = useState(getInitialThemePreference);

  const mode = isDarkMode ? 'dark' : 'light';

  // 設置顯示大小
  useEffect(() => {
    const root = document.documentElement;
    const zoomLevels = {
      normal: 1,
      medium: 1.09375,
      large: 1.1875,
      xlarge: 1.28125,
      xxlarge: 1.375
    };

    // 檢測平台並調整縮放比例
    const isPC = window.electron?.platform === 'win32' || window.electron?.platform === 'linux';
    const baseScale = zoomLevels[displaySize];
    const adjustedScale = isPC ? baseScale * 0.9 : baseScale; // PC平台減少20%

    // 只设置 CSS 变量，不直接修改样式
    root.style.setProperty('--content-scale', adjustedScale);
  }, [displaySize]);

  // 設置所有 CSS 變數
  useEffect(() => {
    const root = document.documentElement;
    const variables = colors.variables[mode];

    // 設置主題屬性
    root.dataset.theme = mode;

    // 設置基礎變數
    Object.entries(variables).forEach(([key, value]) => {
      if (key !== 'primary') {
        root.style.setProperty(key, value as string);
      }
    });

    // 設置主色
    root.style.setProperty('--primary', variables.primary[primaryColor]);

    // 設置 surface 顏色
    const surfaceColor = calculateSurface(
      variables.primary[primaryColor],
      variables['--background'],
      isDarkMode
    );
    root.style.setProperty('--surface', surfaceColor);

    // 設置 sidebar 和 editor 的背景顏色
    if (isDarkMode) {
      root.style.setProperty('--sidebarBackground', 'var(--surface)');
      root.style.setProperty('--editorBackground', 'var(--background)');
    } else {
      root.style.setProperty('--sidebarBackground', 'var(--background)');
      root.style.setProperty('--editorBackground', 'var(--surface)');
    }

    // 設置混合顏色
    root.style.setProperty(
      '--background-overlay',
      `color-mix(in srgb, var(--on) 4%, var(--background))`
    );

    // 設置所有主色系的顏色變數（供卡片模板使用）
    Object.entries(variables.primary).forEach(([color, value]) => {
      root.style.setProperty(`--${color}`, value);
    });

    // 設置標籤背景顏色
    const tagBg = calculateTagBackground(isDarkMode, variables['--on']);
    root.style.setProperty('--tagBackground', tagBg);

  }, [mode, primaryColor]);

  // 根據系統偏好更新主題
  const updateThemeFromSystem = () => {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(prefersDark);
    // 同步系統主題（如果 electronAPI 存在）
    window.electronAPI?.setNativeTheme?.(prefersDark ? 'dark' : 'light');
  };

  // 監聽系統主題變化
  useEffect(() => {
    if (themePreference !== 'system') return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => updateThemeFromSystem();

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [themePreference]);

  // 加载保存的设置（显示大小、主题模式和主色）
  useEffect(() => {
    const loadSavedSettings = async () => {
      try {
        // 加载显示大小设置
        const savedSize = localStorage.getItem('displaySize');
        if (savedSize) {

          setDisplaySize(savedSize);
        }

        // 加载主题模式设置
        const savedMode = localStorage.getItem('themeMode');
        if (savedMode === 'system') {
          // 用戶明確選擇跟隨系統

          setThemePreference('system');
          updateThemeFromSystem();
        } else if (savedMode) {
          // 用戶明確選擇了 dark 或 light

          setThemePreference(savedMode);
          setIsDarkMode(savedMode === 'dark');
          // 同步系統主題
          window.electronAPI?.setNativeTheme?.(savedMode);
        } else {
          // 沒選過，預設使用白色模式

          setThemePreference('light');
          setIsDarkMode(false);
          window.electronAPI?.setNativeTheme?.('light');
        }

        // 加载主色设置
        const savedColor = localStorage.getItem('primaryColor');
        if (savedColor) {

          setPrimaryColor(savedColor);
        }
      } catch (error) {
        console.error('加载设置失败:', error);
      }
    };

    loadSavedSettings();
  }, []); // 仅在组件挂载时执行一次

  const theme = React.useMemo(() => ({
    mode: isDarkMode ? 'dark' : 'light',
    primaryColor,
    displaySize,
    themePreference, // 'system' | 'dark' | 'light'
    setMode: (newMode) => {
      setThemePreference(newMode);
      // 保存主题模式設置
      localStorage.setItem('themeMode', newMode);

      if (newMode === 'system') {
        // 跟隨系統
        updateThemeFromSystem();
      } else {
        // 用戶明確選擇
        setIsDarkMode(newMode === 'dark');
        // 同步系統主題
        window.electronAPI?.setNativeTheme?.(newMode);
      }
    },
    setPrimaryColor: (color) => {
      setPrimaryColor(color);
      // 保存主色设置
      localStorage.setItem('primaryColor', color);

    },
    setDisplaySize: (size) => {
      setDisplaySize(size);
      // 保存显示大小设置
      localStorage.setItem('displaySize', size);

    }
  }), [mode, primaryColor, displaySize, themePreference]);

  return (
    <ThemeContext.Provider value={theme}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme(): ThemeContextType {
  const theme = useContext(ThemeContext);
  // 如果沒有 ThemeProvider（例如在獨立的 React root 中），返回從 localStorage 讀取的預設值
  if (!theme) {
    const savedMode = localStorage.getItem('themeMode') || 'light';
    const savedPrimaryColor = localStorage.getItem('primaryColor') || 'blue';
    return {
      mode: savedMode,
      primaryColor: savedPrimaryColor,
      displaySize: 'normal',
      themePreference: savedMode,
      setMode: () => { },
      setDisplaySize: () => { },
      setPrimaryColor: () => { },
    };
  }
  return theme;
} 