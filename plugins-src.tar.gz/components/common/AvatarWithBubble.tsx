import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useMembersInfoStore } from '../../Store/MembersInfoStore';
import { useItemStore } from '../../Store/itemStore';
import { getMembersInfo } from '../../utils/shareAPI';
import { getReviewsByCardId } from '../plugins/card/reviewStore';
import './AvatarWithBubble.css';

/**
 * AvatarWithBubble - 獨立的頭像與留言氣泡組件
 * 完全獨立於 CardRenderer，有自己的生命週期
 * 
 * @param {Object} cardData - 卡片資料
 * @param {string} currentMemberID - 當前用戶 ID
 * @param {Function} onAvatarClick - 點擊頭像的回調
 * @param {Function} onBubbleClick - 點擊氣泡的回調
 * @param {string} position - 位置 'left' | 'right'（預設 'left'）
 */
function AvatarWithBubble({
  cardData,
  creatorId,
  currentMemberID,
  onAvatarClick,
  onBubbleClick,
  position = 'left'
}) {
  const containerRef = useRef(null);
  const avatarRef = useRef(null);
  const bubbleRef = useRef(null);
  const avatarUrlRef = useRef(null);
  const currentDisplayMemberIdRef = useRef(null);
  const [avatarUrl, setAvatarUrl] = useState(null);
  const [isVisible, setIsVisible] = useState(false);
  const [resolvedPosition, setResolvedPosition] = useState(position);

  // 偵測卡片內容中左上角是否有 absolute 元素，決定頭像放左或右
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const cardItem = el.closest('.card-gallery-item');
    if (!cardItem) return;

    // 找卡片渲染區域中的第一張圖片的父容器
    const img = cardItem.querySelector('img');
    const parent = img?.parentElement;
    if (!parent) return;

    let hasElementAtTopLeft = false;
    for (const sibling of parent.children) {
      const style = window.getComputedStyle(sibling);
      if (style.position === 'absolute') {
        const top = parseInt(style.top) || 0;
        const left = parseInt(style.left) || 0;
        if (top < 20 && left < 20 && style.top !== 'auto' && style.left !== 'auto') {
          hasElementAtTopLeft = true;
          break;
        }
      }
    }

    setResolvedPosition(hasElementAtTopLeft ? 'right' : 'left');
  }, [cardData?.id]);

  // 從 REVIEW items 取得留言列表
  const allReviews = useItemStore(s => s.byType['REVIEW'] ?? []);
  const commentsList = useMemo(() => {
    if (!cardData?.id) return [];

    const reviews = getReviewsByCardId(cardData.id);
    const getMembersInfoFromStore = useMembersInfoStore.getState().getMembersInfo;

    const comments = reviews
      .filter(r => r.comment?.trim().length > 0)
      .map(r => {
        // 從確定性 ID 解析出 memberId: review_{cardId}_{memberId}
        const parts = r.id.split('_');
        const memberID = parts.slice(2).join('_');
        const memberInfo = getMembersInfoFromStore([memberID])[memberID];
        return {
          memberID,
          comment: r.comment.trim(),
          isContributor: memberID === creatorId,
          isCurrentUser: memberID === currentMemberID,
          avatar: memberInfo?.thumbnail,
          name: memberInfo?.name,
          updatedAt: r.updatedAt,
        };
      });

    comments.sort((a, b) => {
      if (a.isContributor && !b.isContributor) return -1;
      if (!a.isContributor && b.isContributor) return 1;
      if (a.isCurrentUser && !b.isCurrentUser) return -1;
      if (!a.isCurrentUser && b.isCurrentUser) return 1;
      return parseInt(b.updatedAt || '0') - parseInt(a.updatedAt || '0');
    });

    return comments.slice(0, 10);
  }, [allReviews, cardData?.id, creatorId, currentMemberID]);

  // 訂閱貢獻者頭像
  useEffect(() => {
    if (!creatorId) return;

    const getMembersInfoFromStore = useMembersInfoStore.getState().getMembersInfo;
    const fetchMembersInfo = useMembersInfoStore.getState().fetchMembersInfo;
    const subscribe = useMembersInfoStore.getState().subscribe;

    // 檢查是否已有資料
    const existingInfo = getMembersInfoFromStore([creatorId])[creatorId];
    if (existingInfo?.thumbnail) {
      avatarUrlRef.current = existingInfo.thumbnail;
      setAvatarUrl(existingInfo.thumbnail);
    }
    // 不管有沒有頭像都要顯示（沒頭像就顯示灰色圓球）
    setIsVisible(true);

    if (!existingInfo?.thumbnail) {
      // 訂閱更新
      const unsubscribe = subscribe(creatorId, (info) => {
        if (info?.thumbnail) {
          avatarUrlRef.current = info.thumbnail;
          setAvatarUrl(info.thumbnail);
        }
      });

      // 發起請求
      fetchMembersInfo(creatorId, getMembersInfo);

      return unsubscribe;
    }
  }, [creatorId, cardData?.id]);

  // 訂閱留言者頭像
  useEffect(() => {
    if (commentsList.length === 0) return;

    const getMembersInfoFromStore = useMembersInfoStore.getState().getMembersInfo;
    const fetchMembersInfo = useMembersInfoStore.getState().fetchMembersInfo;
    const subscribe = useMembersInfoStore.getState().subscribe;

    const unsubscribes = [];
    const memberIds = commentsList.map(c => c.memberID).filter(id => !commentsList.find(c => c.memberID === id && c.avatar));

    memberIds.forEach(memberID => {
      const existingInfo = getMembersInfoFromStore([memberID])[memberID];
      if (!existingInfo) {
        const unsubscribe = subscribe(memberID, (info) => {

          // 觸發重新計算（通過依賴 cardData.reviews）
        });
        unsubscribes.push(unsubscribe);
        fetchMembersInfo(memberID, getMembersInfo);
      }
    });

    return () => {
      unsubscribes.forEach(fn => fn());
    };
  }, [commentsList]);

  // 氣泡輪播效果
  useEffect(() => {
    if (!avatarRef.current || !bubbleRef.current) return;

    const avatarEl = avatarRef.current;
    const bubbleEl = bubbleRef.current;

    // 確保氣泡預設隱藏
    bubbleEl.style.display = 'none';

    // 建立輪播項目：貢獻者永遠是第一項（不管有沒有留言），其他留言者接在後面
    const items = [];

    // 貢獻者永遠算一項
    const contributorComment = commentsList.find(c => c.isContributor);
    items.push({
      memberID: creatorId,
      comment: contributorComment?.comment || null, // 沒留言就是 null
      isContributor: true,
    });

    // 加入非貢獻者的留言
    commentsList.filter(c => !c.isContributor).forEach(c => {
      items.push({
        memberID: c.memberID,
        comment: c.comment,
        isContributor: false,
      });
    });

    // 只有一項（只有貢獻者）：播一次就停；兩項以上：循環
    const shouldLoop = items.length >= 2;

    let currentIndex = 0;
    let typingTimer = null;
    let carouselTimer = null;
    let isPlaying = false;

    // 打字機效果
    const typeText = (text, callback) => {
      if (!isPlaying) return;
      bubbleEl.textContent = '';
      bubbleEl.style.display = 'block';
      let charIndex = 0;

      const type = () => {
        if (!isPlaying) return;
        if (charIndex < text.length) {
          bubbleEl.textContent += text[charIndex];
          charIndex++;
          typingTimer = setTimeout(type, 50);
        } else if (callback) {
          callback();
        }
      };

      type();
    };

    // 開始輪播
    const startCarousel = () => {
      if (isPlaying || items.length === 0) return;
      isPlaying = true;
      currentIndex = 0;

      const showItem = () => {
        if (!isPlaying) return;
        if (currentIndex >= items.length) {
          if (shouldLoop) {
            currentIndex = 0;
          } else {
            // 只有一項，播完恢復貢獻者頭像並停止
            currentDisplayMemberIdRef.current = null;
            bubbleEl.style.display = 'none';
            bubbleEl.textContent = '';
            if (avatarUrlRef.current) {
              avatarEl.style.backgroundImage = `url(${avatarUrlRef.current})`;
            }
            avatarEl.classList.add('avatar-with-bubble-owner');
            isPlaying = false;
            return;
          }
        }

        const item = items[currentIndex];
        currentDisplayMemberIdRef.current = item.memberID;

        // 即時從 store 取最新頭像
        const getMembersInfoFromStore = useMembersInfoStore.getState().getMembersInfo;
        const latestInfo = getMembersInfoFromStore([item.memberID])[item.memberID];
        const latestAvatar = latestInfo?.thumbnail;

        if (latestAvatar) {
          avatarEl.style.backgroundImage = `url(${latestAvatar})`;
        }
        if (item.isContributor) {
          avatarEl.classList.add('avatar-with-bubble-owner');
        } else {
          avatarEl.classList.remove('avatar-with-bubble-owner');
        }

        if (item.comment) {
          // 有留言：打字機顯示
          typeText(item.comment, () => {
            if (!isPlaying) return;
            if (!shouldLoop) {
              // 只有一項且有留言：播完停在留言狀態，不要隱藏氣泡
              isPlaying = false;
              return;
            }
            carouselTimer = setTimeout(() => {
              currentIndex++;
              showItem();
            }, 1000);
          });
        } else {
          // 沒留言（貢獻者無留言）：只顯示頭像，停 1 秒後下一個
          bubbleEl.style.display = 'none';
          bubbleEl.textContent = '';
          carouselTimer = setTimeout(() => {
            currentIndex++;
            showItem();
          }, 1000);
        }
      };

      showItem();
    };

    // 停止輪播
    const stopCarousel = () => {
      isPlaying = false;
      if (typingTimer) {
        clearTimeout(typingTimer);
        typingTimer = null;
      }
      if (carouselTimer) {
        clearTimeout(carouselTimer);
        carouselTimer = null;
      }

      // 恢復貢獻者頭像，隱藏氣泡
      currentDisplayMemberIdRef.current = null;
      bubbleEl.style.display = 'none';
      bubbleEl.textContent = '';
      if (avatarUrlRef.current) {
        avatarEl.style.backgroundImage = `url(${avatarUrlRef.current})`;
        avatarEl.classList.add('avatar-with-bubble-owner');
      }
    };

    // 判斷是否為手機版
    const isMobile = window.innerWidth <= 768;

    if (isMobile) {
      // 手機版：使用 IntersectionObserver
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              startCarousel();
            } else {
              stopCarousel();
            }
          });
        },
        { threshold: 0.5 }
      );

      observer.observe(avatarEl);

      return () => {
        observer.disconnect();
        stopCarousel();
      };
    } else {
      // 桌面版：綁定 hover 事件到父容器
      const container = avatarEl.closest('.card-gallery-item');
      if (container) {
        container.addEventListener('mouseenter', startCarousel);
        container.addEventListener('mouseleave', stopCarousel);

        return () => {
          container.removeEventListener('mouseenter', startCarousel);
          container.removeEventListener('mouseleave', stopCarousel);
          stopCarousel();
        };
      }
    }
  }, [commentsList]);

  // 如果沒有貢獻者 ID，不渲染
  if (!creatorId) return null;

  return (
    <div
      ref={containerRef}
      className={`avatar-with-bubble-container avatar-with-bubble-${resolvedPosition}`}
      style={{ position: 'absolute', pointerEvents: 'none' }}
    >
      <div
        ref={avatarRef}
        className={`avatar-with-bubble ${isVisible ? 'visible' : ''} avatar-with-bubble-owner`}
        style={{
          backgroundImage: avatarUrl ? `url(${avatarUrl})` : undefined
        }}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          // 輪播中點擊顯示當前留言者，否則顯示貢獻者
          const displayMemberId = currentDisplayMemberIdRef.current || creatorId;
          onAvatarClick?.({ ...cardData, creatorId: displayMemberId });
        }}
      />
      <div
        ref={bubbleRef}
        className="avatar-comment-bubble"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          onBubbleClick?.();
        }}
      />
    </div>
  );
}

export default AvatarWithBubble;

