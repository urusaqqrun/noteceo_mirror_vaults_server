import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './IconPicker.css';
import { iconRegistry, getIconByName } from './IconRegistry';

interface IconPickerProps {
  value: string | null | undefined;
  onChange: (iconName: string) => void;
  className?: string;
}

const iconNames = Object.keys(iconRegistry).filter(k => !k.match(/^[A-Z]/));

export const IconPicker = ({ value, onChange, className = '' }: IconPickerProps) => {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  const SelectedIcon = value ? getIconByName(value) : null;

  return (
    <div className={`icon-picker ${className}`} ref={containerRef}>
      <div
        className="icon-picker-display"
        onClick={() => setOpen(!open)}
      >
        {SelectedIcon ? (
          <SelectedIcon className="icon-picker-selected" />
        ) : (
          <span className="icon-picker-placeholder">?</span>
        )}
      </div>

      {open && (
        <div className="icon-picker-dropdown">
          <div className="icon-picker-grid">
            {iconNames.map(name => {
              const Icon = getIconByName(name);
              return (
                <div
                  key={name}
                  className={`icon-picker-option ${value === name ? 'selected' : ''}`}
                  onClick={() => { onChange(name); setOpen(false); }}
                  title={name}
                >
                  {Icon && <Icon />}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
