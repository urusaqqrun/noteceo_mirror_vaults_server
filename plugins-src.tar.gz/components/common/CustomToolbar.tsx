import React from 'react';
import './CustomToolbar.css';

/**
 * CustomToolbar — 通用三欄工具列
 *
 * 佈局：left | center | right，任何高度都 Y 軸置中。
 * left / right 各自支援 prefix + buttons + suffix，可靈活組合。
 *
 * ─────────────────────────────────────────────────────────
 *  使用方式
 * ─────────────────────────────────────────────────────────
 *
 *  1) 最簡用法 — 左邊按鈕 + 右邊按鈕：
 *
 *     <CustomToolbar
 *       left={{ buttons: [{ icon: <PinIcon />, onClick: fn, active: true }] }}
 *       right={{ buttons: [undoBtn, redoBtn, { node: <MoreMenu /> }] }}
 *     />
 *
 *  2) 標題 + 按鈕：
 *
 *     <CustomToolbar
 *       left={{ prefix: <span className="my-title">{title}</span> }}
 *       right={{ buttons: [closeBtn] }}
 *     />
 *
 *  3) 中間標題：
 *
 *     <CustomToolbar
 *       center={t('materialLibrary')}
 *       right={{ buttons: [closeBtn] }}
 *     />
 *
 *  4) prefix + buttons + suffix 混用：
 *
 *     <CustomToolbar
 *       left={{
 *         prefix: <span className="title">{title}</span>,
 *         buttons: [sortBtn],
 *         suffix: <MonthPicker />,
 *       }}
 *       right={{
 *         prefix: <ConfirmBanner />,
 *         buttons: [refreshBtn, moreBtn],
 *       }}
 *     />
 *
 *  5) 自訂高度 + 有底線：
 *
 *     <CustomToolbar height={36} borderBottom left={{ ... }} />
 *
 * ─────────────────────────────────────────────────────────
 *  ToolbarButton 說明
 * ─────────────────────────────────────────────────────────
 *
 *  StandardButton:
 *    icon        — SVG 圖標（ReactNode）
 *    onClick     — 點擊回調
 *    title?      — tooltip 文字
 *    active?     — 啟用高亮（accent 色，搭配 variant 可變色）
 *    disabled?   — 禁用（半透明）
 *    badge?      — 右下角數字徽章
 *    variant?    — 'default' | 'delete'（紅色）| 'primary'（主色）
 *
 *  CustomNodeButton:
 *    node        — 任意 ReactNode（escape hatch，如 TopbarMoreMenu）
 */

// ─── 按鈕型別 ───

interface StandardButton {
    icon: React.ReactNode;
    onClick: () => void;
    title?: string;
    active?: boolean;
    disabled?: boolean;
    badge?: number;
    variant?: 'default' | 'delete' | 'primary';
}

interface CustomNodeButton {
    node: React.ReactNode;
}

export type ToolbarButton = StandardButton | CustomNodeButton;

// ─── 區域配置 ───

export interface ToolbarSection {
    prefix?: React.ReactNode;
    buttons?: ToolbarButton[];
    suffix?: React.ReactNode;
}

// ─── Props ───

interface CustomToolbarProps {
    left?: ToolbarSection;
    center?: React.ReactNode;
    right?: ToolbarSection;
    height?: number;
    borderBottom?: boolean;
    className?: string;
}

// ─── 內部工具 ───

function isCustomNode(btn: ToolbarButton): btn is CustomNodeButton {
    return 'node' in btn;
}

function renderButton(btn: ToolbarButton, index: number) {
    if (isCustomNode(btn)) {
        return <React.Fragment key={index}>{btn.node}</React.Fragment>;
    }

    const classNames = ['custom-toolbar-button'];
    if (btn.active) classNames.push('active');
    if (btn.variant && btn.variant !== 'default') classNames.push(btn.variant);

    return (
        <button
            key={index}
            className={classNames.join(' ')}
            title={btn.title}
            onClick={btn.onClick}
            onMouseDown={(e) => e.preventDefault()}
            style={btn.disabled ? { opacity: 0.5 } : undefined}
            tabIndex={-1}
        >
            {btn.icon}
            {btn.badge != null && btn.badge > 0 && (
                <span className="custom-toolbar-badge">{btn.badge}</span>
            )}
        </button>
    );
}

function renderSection(section: ToolbarSection | undefined) {
    if (!section) return null;
    const { prefix, buttons, suffix } = section;
    const hasContent = prefix != null || (buttons && buttons.length > 0) || suffix != null;
    if (!hasContent) return null;
    return (
        <>
            {prefix}
            {buttons?.map(renderButton)}
            {suffix}
        </>
    );
}

// ─── 元件 ───

export function CustomToolbar({
    left,
    center,
    right,
    height = 50,
    borderBottom = false,
    className: extraClassName,
}: CustomToolbarProps) {
    const className = ['custom-toolbar', borderBottom && 'has-border', extraClassName]
        .filter(Boolean)
        .join(' ');

    return (
        <div className={className} style={{ height }}>
            <div className="custom-toolbar-left">
                {renderSection(left)}
            </div>
            {center != null && (
                <div className="custom-toolbar-center">{center}</div>
            )}
            <div className="custom-toolbar-right">
                {renderSection(right)}
            </div>
        </div>
    );
}

export default CustomToolbar;
