/**
 * FolderTreeSelect - 資料夾選擇器（selector 模式）
 *
 * 直接使用 Sidebar 已註冊的 sections，不重複拉 store。
 * types: ['TODO','NOTE','CARD','CHART'] → 對應 section id: todo, note, card, chart
 */
import React from 'react';
import '../plugins/sidebar/FolderList.css';
import './FolderTreeSelect.css';
import { useSidebarRegistry, type SidebarSectionDescriptor } from '../plugins/sidebar/sidebarStore';
import { GenericFolderTreeSection } from '../plugins/sidebar/FolderTree';

const TYPE_TO_SECTION: Record<string, string> = {
  TODO: 'todo',
  NOTE: 'note',
  CARD: 'card',
  CHART: 'chart',
  SHARE: 'share',
};

function SectionSelector({
  descriptor,
  value,
  onChange,
  showSectionHeader,
}: {
  descriptor: SidebarSectionDescriptor;
  value: string;
  onChange: (id: string) => void;
  showSectionHeader: boolean;
}) {
  const data = descriptor.useData();
  const hasItems =
    data.items.length > 0 ||
    (data.prefixItems?.length ?? 0) > 0 ||
    (data.suffixItems?.length ?? 0) > 0;
  if (!hasItems) return null;

  return (
    <div className="folder-tree-select-section">
      {showSectionHeader && (
        <div className="folder-tree-select-section-title">{descriptor.title}</div>
      )}
      <GenericFolderTreeSection
        data={data}
        sectionId={descriptor.id}
        onItemSelect={onChange}
        selectedId={value}
      />
    </div>
  );
}

interface FolderTreeSelectProps {
  mode?: 'selector';
  types?: string[];
  value?: string;
  onChange?: (id: string) => void;
  showCount?: boolean;
  showInbox?: boolean;
  showTrash?: boolean;
  className?: string;
}

const FolderTreeSelect = ({
  mode = 'selector',
  types = ['NOTE'],
  value = '',
  onChange = () => {},
  showCount = true,
  showInbox = true,
  showTrash = false,
  className = '',
}: FolderTreeSelectProps) => {
  const sectionIds = types.map((t) => TYPE_TO_SECTION[t]).filter(Boolean);
  const sections = useSidebarRegistry((s) =>
    sectionIds
      .map((id) => s.sections.get(id))
      .filter((x): x is SidebarSectionDescriptor => !!x)
  );

  const showSectionHeader = sections.length > 1;

  return (
    <div className={`folder-tree-select folder-tree-select-selector ${className}`.trim()}>
      {sections.map((descriptor) => (
        <SectionSelector
          key={descriptor.id}
          descriptor={descriptor}
          value={value}
          onChange={onChange}
          showSectionHeader={showSectionHeader}
        />
      ))}
    </div>
  );
};

export default FolderTreeSelect;
