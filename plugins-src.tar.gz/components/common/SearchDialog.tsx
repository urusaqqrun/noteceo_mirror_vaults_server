import React, { useState, useEffect, useRef } from 'react';
import './SearchDialog.css';
import { SearchBar, SegmentControl } from './BasicComponents';
import './BasicComponents.css';
import { formatTimestamp } from '../Utils/dateFormat';
import { CustomDialog } from './CustomDialog';
import { useSelectedItemsStore } from '../../Store/navigationStore';
import { useSearchRegistry } from '../../Store/searchRegistry';
import { processItemContent } from '../../utils/textUtils';
import { useDialogStore } from '../../Store/dialogStore';
import ClassificationIcon from '../../assets/icon_classification_24.svg?react';
import DeleteFillIcon from '../../assets/bk_icon_delete_fill_20_n.svg?react';
import FolderIcon from '../../assets/icon_folder_outline_24.svg?react';
import { useTranslation } from 'react-i18next';

const SEARCH_HISTORY_KEY = 'cubelv_search_history';
const MAX_HISTORY = 20;

function localGetSearchHistory(): string[] {
  try {
    const data = localStorage.getItem(SEARCH_HISTORY_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function localAddSearchHistory(text: string): void {
  const history = localGetSearchHistory();
  const filtered = history.filter(h => h !== text);
  const newHistory = [text, ...filtered].slice(0, MAX_HISTORY);
  localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(newHistory));
}

function localDeleteSearchHistory(text: string): void {
  const history = localGetSearchHistory();
  const newHistory = history.filter(h => h !== text);
  localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(newHistory));
}

// 在組件外部定義全域變數和修改函數
let lastSearchText = '';

export const getLastSearchText = () => lastSearchText;
export const setLastSearchText = (text) => {
  lastSearchText = text;
};

// 使用 window.textUtils
const { stripContent } = window.textUtils;

// 添加高亮顯示組件
const HighlightText = ({ text, highlight }) => {
  if (!highlight.trim()) return text;

  // 修改正则表达式的使用方式，并确保没有额外空格
  const regex = new RegExp(`(${highlight})`, 'gi');
  const parts = text.split(regex);

  return (
    <span className="highlight-container">
      {parts.map((part, i) =>
        part.toLowerCase() === highlight.toLowerCase() ? (
          <span key={i} className="highlight-text">{part}</span>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </span>
  );
};

function SearchDialog({ onSearch = null, isFromAddUrlDialog = false, onNoteSelect = null }) {
  // 多語言支援
  const { t } = useTranslation();

  // 從 store 讀取（自包含化 — 不需外部傳入 props）
  const showSearchDialog = useDialogStore(s => s.dialogs['search']?.show);
  const searchDialogData = useDialogStore(s => s.dialogs['search']?.data);
  const isFromTag = searchDialogData?.isFromTag || false;
  const onClose = () => useDialogStore.getState().close('search');

  // currentFolderId: 從 navigation store 取得
  const lastSelection = useSelectedItemsStore(s => s.path.at(-1));
  const currentFolderId = lastSelection?.itemType?.endsWith('_FOLDER') ? lastSelection.id : lastSelection?.parentID || null;

  // 從 SearchRegistry 取得全部項目（tags 和 segment 用）
  const [allItems, setAllItems] = useState<any[]>([]);
  // folder cache（顯示資料夾名稱用）
  const [folderCache, setFolderCache] = useState<Map<string, any>>(new Map());

  // 初始化 state，從 localStorage 讀取初始搜尋文字
  const initialSearchText = isFromTag ? window.localStorage.getItem('searchInitialText') || '' : getLastSearchText();
  const [searchText, setSearchText] = useState(initialSearchText);
  const [searchHistory, setSearchHistory] = useState([]);
  const [activeSegment, setActiveSegment] = useState(0);
  const [folderName, setFolderName] = useState('');
  const [hasValidFolder, setHasValidFolder] = useState(false);
  const [suggestedTags, setSuggestedTags] = useState([]);
  const [filteredItems, setFilteredItems] = useState([]);
  const [searchResults, setSearchResults] = useState([]);

  const searchBarRef = useRef(null);

  // 自動聚焦搜尋框
  useEffect(() => {
    requestAnimationFrame(() => {
      searchBarRef.current?.focus();
    });
  }, []);

  // 在組件卸載時清除 localStorage
  useEffect(() => {
    return () => {
      if (isFromTag) {
        window.localStorage.removeItem('searchInitialText');
      }
    };
  }, [isFromTag]);

  // 開啟時從 SearchRegistry 載入全部項目（供 tags 和 segment 使用）
  useEffect(() => {
    if (!showSearchDialog) return;
    setAllItems(useSearchRegistry.getState().search(''));
  }, [showSearchDialog]);

  // 根據 segment 過濾 + 更新 hasValidFolder / folderName
  useEffect(() => {
    const isValid = !!lastSelection?.itemType?.endsWith('_FOLDER');
    setHasValidFolder(isValid);

    if (isValid && currentFolderId) {
      window.electronAPI!.getItem(currentFolderId).then(folder => {
        if (!folder) return;
        const n = folder.name;
        const displayName = n === 'inbox' ? t('inbox') :
          n === 'trash' ? t('trash') :
            n === 'todoInbox' ? t('todoInbox') :
              n || t('unknownFolder');
        setFolderName(displayName);
      });
    }

    if (activeSegment === 1 && currentFolderId) {
      setFilteredItems(allItems.filter(n => n.parentID === currentFolderId));
    } else {
      setFilteredItems(allItems);
    }
  }, [activeSegment, currentFolderId, allItems, lastSelection]);

  useEffect(() => {
    updateTags();
  }, [filteredItems, activeSegment]);

  // 當 segment 切換時更新標籤
  const updateTags = async () => {
    try {
      // 從所有筆記中收集標籤
      const tagMap = new Map(); // 用於統計標籤出現次數和相關筆記

      filteredItems.forEach(note => {
        if (!note) return;

        const noteTags = note.tags ? (
          typeof note.tags === 'string'
            ? JSON.parse(note.tags)
            : note.tags
        ) : [];

        if (Array.isArray(noteTags)) {
          noteTags.forEach(tagName => {
            if (!tagName) return;

            const existingTag = tagMap.get(tagName) || { tag: tagName, count: 0, noteIds: [] };
            existingTag.count += 1;
            if (!existingTag.noteIds.includes(note.id)) {
              existingTag.noteIds.push(note.id);
            }
            tagMap.set(tagName, existingTag);
          });
        }
      });

      const tagsList = Array.from(tagMap.values());

      if (activeSegment === 1) {
        // 如果是在當前資料夾模式，過濾掉不在當前筆記集合中的標籤
        const filteredTags = tagsList.filter(({ noteIds = [] }) =>
          noteIds.some(noteId => filteredItems.some(item => item && item.id === noteId))
        );
        setSuggestedTags(filteredTags.map(tag => tag));
      } else {
        // 如果是所有筆記模式，顯示所有標籤
        setSuggestedTags(tagsList.map(tag => tag));
      }

    } catch (error) {
      console.error('獲取標籤失敗:', error);
      setSuggestedTags([]);
    }
  };

  // 當 segment 改變時更新標籤
  useEffect(() => {
    updateTags();
  }, [activeSegment]);


  // 從 localStorage 獲取歷史記錄
  useEffect(() => {
    const history = localGetSearchHistory();
    setSearchHistory(history);
  }, []);

  // 當搜尋文字改變時，透過 SearchRegistry 搜尋所有類型
  useEffect(() => {
    const updateSearchResults = async () => {
      const trimmedText = searchText.trim();
      if (!trimmedText) {
        setSearchResults([]);
        return;
      }
      try {
        let results = useSearchRegistry.getState().search(trimmedText);

        // segment 過濾：只保留 parentID 為當前資料夾的項目
        if (activeSegment === 1 && currentFolderId) {
          results = results.filter(item => item.parentID === currentFolderId);
        }

        // 預載結果中的 folder（getFolderName 用）
        const missingFolderIds = [...new Set(results.map(r => r.parentID).filter(Boolean))]
          .filter(fid => !folderCache.has(fid));
        if (missingFolderIds.length > 0) {
          const newCache = new Map(folderCache);
          await Promise.all(missingFolderIds.map(async fid => {
            try {
              const folder = await window.electronAPI!.getItem(fid);
              if (folder) newCache.set(fid, folder);
            } catch {}
          }));
          setFolderCache(newCache);
        }

        // 排序：name 命中優先，再按更新時間
        const q = trimmedText.toLowerCase();
        const sorted = [...results].sort((a, b) => {
          const aPri = (a.name?.toLowerCase().includes(q) || (a as any).aiTitle?.toLowerCase().includes(q)) ? 2 : 3;
          const bPri = (b.name?.toLowerCase().includes(q) || (b as any).aiTitle?.toLowerCase().includes(q)) ? 2 : 3;
          if (aPri !== bPri) return aPri - bPri;
          return (b.updatedAt || 0) - (a.updatedAt || 0);
        });

        setSearchResults(sorted);
      } catch (error) {
        console.error('搜尋結果處理失敗:', error);
        setSearchResults([]);
      }
    };
    updateSearchResults();
  }, [searchText, activeSegment, currentFolderId]);

  // 當搜尋字串改變時，更新全域變數
  useEffect(() => {
    setLastSearchText(searchText);
  }, [searchText]);

  // 當對話框關閉時，更新全域變數
  const handleClose = () => {
    // 如果是從標籤進來，清空 lastSearchText
    if (isFromTag) {
      setLastSearchText('');
    } else {
      setLastSearchText(searchText);
    }
    onClose();
  };

  const handleSearch = async (text) => {
    const trimmedText = text.trim();
    if (!trimmedText) return;  // 如果是空字串就直接返回

    // 使用 localStorage 保存搜尋歷史
    localAddSearchHistory(trimmedText);
    // 更新本地狀態
    setSearchHistory(prev => [trimmedText, ...prev.filter(item => item !== trimmedText)].slice(0, 50));
    // 只關閉對話框，不執行外部搜尋
    handleClose();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      const trimmedText = searchText.trim();
      if (trimmedText) {  // 只有在有內容時才執行搜尋
        handleSearch(trimmedText);
      }
    }
  };

  const handleTagClick = async (tag) => {
    setSearchText(tag);
    // 新增到搜尋歷史
    localAddSearchHistory(tag);
    // 更新本地狀態
    setSearchHistory(prev => [tag, ...prev.filter(item => item !== tag)].slice(0, 50));
    // 聚焦搜尋框
    searchBarRef.current?.focus();
  };

  const handleHistoryClick = (text) => {
    setSearchText(text);
    // 直接使用 ref.current
    searchBarRef.current?.focus();
  };

  const handleHistoryDelete = async (e, text) => {
    e.stopPropagation();
    try {
      // 從 localStorage 中刪除
      localDeleteSearchHistory(text);
      // 更新本地狀態
      setSearchHistory(prev => prev.filter(item => item !== text));
    } catch (error) {
      console.error('刪除搜尋歷史失敗:', error);
    }
  };

  const getItemTags = (item) => {
    if (!item?.tags) return [];
    try {
      const parsed = typeof item.tags === 'string' ? JSON.parse(item.tags) : item.tags;
      if (!Array.isArray(parsed)) return [];
      return parsed.filter(Boolean);
    } catch {
      return [];
    }
  };

  const getFolderName = (folderId) => {
    const fallback = { name: t('materialLibrary'), isTrash: false, isUnclassified: false };
    if (!folderId) return fallback;
    const folder = folderCache.get(folderId);
    if (!folder || folder.parentID) return fallback;
    const n = folder.name;
    if (n === 'inbox') return { name: t('inbox'), isTrash: false, isUnclassified: true };
    if (n === 'todoInbox') return { name: t('todoInbox'), isTrash: false, isUnclassified: true };
    if (n === 'trash') return { name: t('trash'), isTrash: true, isUnclassified: false };
    return { name: n || t('materialLibrary'), isTrash: false, isUnclassified: false };
  };

  const handleResultClick = async (item) => {
    const trimmedText = searchText.trim();
    if (trimmedText) {
      localAddSearchHistory(trimmedText);
      setSearchHistory(prev => [trimmedText, ...prev.filter(i => i !== trimmedText)].slice(0, 50));
    }

    if (isFromAddUrlDialog && onNoteSelect) {
      onNoteSelect(item.id, item.name || t('untitled'));
    } else {
      useSelectedItemsStore.getState().setSelectedItems([item], { scrollToFocusItem: true, highlightItemId: item.id });
    }

    handleClose();
  };

  // 輔助函數：獲取包含搜尋文字的上下文
  const getContentContext = (content, searchText) => {
    if (!content || !searchText.trim()) return stripContent(content);

    const trimmedSearchText = searchText.trim().toLowerCase();
    const lowerContent = content.toLowerCase();
    const index = lowerContent.indexOf(trimmedSearchText);

    if (index === -1) return stripContent(content);

    // 獲取搜尋文字前後的上下文
    const contextLength = 50; // 前後各顯示的字元數
    const start = Math.max(0, index - contextLength);
    const end = Math.min(content.length, index + trimmedSearchText.length + contextLength);

    let contextText = content.slice(start, end);

    // 如果不是從開頭開始，加上 ...
    if (start > 0) {
      contextText = '...' + contextText;
    }

    // 如果不是到結尾結束，加上 ...
    if (end < content.length) {
      contextText = contextText + '...';
    }

    return contextText;
  };

  const getFirstImageUrl = (note) => {
    if (note.imgURLs && Array.isArray(note.imgURLs) && note.imgURLs.length > 0) {
      for (const url of note.imgURLs) {
        if (note.content && note.content.includes(url)) {
          return url;
        }
      }
    }

    if (note.imageUrl_local && Array.isArray(note.imageUrl_local) && note.imageUrl_local.length > 0) {
      for (const url of note.imageUrl_local) {
        if (note.content && note.content.includes(url)) {
          return url;
        }
      }
    }

    if (note.websiteContent) {
      try {
        const websiteLinks = JSON.parse(note.websiteContent);
        if (websiteLinks.length > 0 && websiteLinks[0].imageUrl) {
          return websiteLinks[0].imageUrl;
        }
      } catch (error) {
        console.error('解析 websiteContent 失敗:', error);
      }
    }

    return null;
  };

  // 內容區塊
  const dialogContent = (
    <>
      <div className="search-header">
        <SearchBar
          ref={searchBarRef}
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        {/* 只有在筆記或待辦資料夾時才顯示 SegmentControl */}
        {hasValidFolder && (
          <SegmentControl
            segments={[t('allNotes'), folderName]}
            activeIndex={activeSegment}
            onChange={setActiveSegment}
          />
        )}
      </div>

      {searchText.trim() ? (
        // 搜尋結果視圖
        <div className="search-section">
          <h3 className="section-subtitle">{t('searchResults')}</h3>
          <div className="search-results">
            {searchResults.map(item => {
              const typeClass = item.itemType.toLowerCase().replace('_folder', '');
              const typeLabel = item.itemType.charAt(0) + item.itemType.slice(1).toLowerCase().replace('_folder', '');
              const title = item.name || t('untitled');
              const content = getContentContext(processItemContent(item, true), searchText.trim());
              const imageUrl = getFirstImageUrl(item);
              const folderInfo = getFolderName(item.parentID);
              const tags = getItemTags(item);
              const provider = useSearchRegistry.getState().getProvider(item.itemType);

              return (
                <div
                  key={`${item.itemType}-${item.id}`}
                  className="search-result-item"
                  onClick={() => handleResultClick(item)}
                >
                  <div className="result-left-container">
                    <div className="result-title">
                      <span className={`type-tag ${typeClass}`}>
                        {typeLabel}
                      </span>
                      <HighlightText text={title} highlight={searchText.trim()} />
                    </div>
                    {content && (
                      <div className="result-content">
                        <HighlightText text={content} highlight={searchText.trim()} />
                      </div>
                    )}
                    <div className="result-footer">
                      <div className="result-timestamp">
                        {folderInfo.name && (
                          <>
                            <span className={`notebook-name${folderInfo.isTrash ? ' trash' : ''}`}>
                              {folderInfo.isTrash ? (
                                <DeleteFillIcon className="folder-icon error" />
                              ) : folderInfo.isUnclassified ? (
                                <ClassificationIcon className="folder-icon" />
                              ) : (
                                <FolderIcon className="folder-icon" />
                              )}
                              {folderInfo.name}
                            </span>
                            {' · '}
                          </>
                        )}
                        {formatTimestamp(item.updatedAt)}
                      </div>
                      {tags.length > 0 && (
                        <div className="result-tags">
                          {tags.map(tag => (
                            <span key={tag} className="tag-item">
                              <HighlightText text={tag} highlight={searchText.trim()} />
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {imageUrl && (
                    <div className="result-right-container">
                      <div className="result-thumbnail">
                        <img
                          src={imageUrl}
                          onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            {searchResults.length === 0 && (
              <div className="no-results">{t('noResultsFound')}</div>
            )}
          </div>
        </div>
      ) : (
        // 原有的標籤和歷史記錄視圖
        <>
          <div className="search-tag-section">
            <h3 className="section-subtitle-tag">{t('searchTags')}</h3>
            <div className="suggestion-tag-container">
              {suggestedTags.map(tagObj => (
                <div
                  key={tagObj.tag}
                  className="tag-item"
                  onClick={() => handleTagClick(tagObj.tag)}
                >
                  {tagObj.tag}
                </div>
              ))}
            </div>
          </div>

          {searchHistory.length > 0 && (
            <div className="history-section">
              <h3 className="section-subtitle">{t('searchHistory')}</h3>
              <div className="history-list">
                {searchHistory.map((text, index) => (
                  <div
                    key={index}
                    className="history-item"
                    onClick={() => handleHistoryClick(text)}
                  >
                    <span className="history-text">{text}</span>
                    <button
                      className="history-delete"
                      onClick={(e) => handleHistoryDelete(e, text)}
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </>
  );

  if (!showSearchDialog) return null;

  return (
    <CustomDialog
      isOpen={showSearchDialog}
      onClose={handleClose}
      title={t('searchDialogTitle')}
      className="search-dialog"
      onEscapeOverride={() => {
        if (searchText.trim()) {
          setSearchText('');
          return true;
        }
        return false;
      }}
    >
      {dialogContent}
    </CustomDialog>
  );
}

export default SearchDialog; 
