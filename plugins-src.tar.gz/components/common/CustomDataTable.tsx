import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './CustomDataTable.css';

// 拖曳手柄 SVG
const DragHandleIcon = () => (
  <svg width="20" height="20" viewBox="0 0 20 20">
    <path d="M7 2h2v2H7V2zM7 6h2v2H7V6zM7 10h2v2H7v-2zM7 14h2v2H7v-2zM11 2h2v2h-2V2zM11 6h2v2h-2V6zM11 10h2v2h-2v-2zM11 14h2v2h-2v-2z" fill="currentColor" />
  </svg>
);

// 不支援多欄位的圖表類型
const SINGLE_SERIES_CHARTS = ['PieChart', 'DoughnutChart', 'RadialBarChart'];

// 固定欄位的圖表類型（不能新增或刪除欄位）
const FIXED_COLUMNS_CHARTS = ['ScatterChart'];

/**
 * CustomDataTable 組件
 * 通用可編輯數據表格，支援新增、編輯、刪除行和欄位
 * 
 * 三種使用模式：
 * 1. 自動保存模式（用於 ChartReportView）：傳入 chart + onUpdateChart + chartType
 * 2. 受控模式（用於 AddChartDialog）：傳入 chartData + xKey + yKeys + onChange
 * 3. 唯讀模式（用於 CardGallery 列表視圖）：傳入 chartData + xKey + yKeys + readOnly
 */
function CustomDataTable({
  // 自動保存模式的 props
  chart,
  onUpdateChart,
  chartType,
  // 受控模式的 props
  chartData: externalChartData,
  xKey: externalXKey,
  yKeys: externalYKeys,
  valueIsNumber: externalValueIsNumber,
  onChange,
  // 顯示選項
  showHeader = true,
  // 新增 Props（為卡片畫廊準備）
  readOnly = false,
  disableDrag = false,
  hideActions = false,
  emptyMessage,
  onRowClick
}) {
  const { t } = useTranslation();

  // 判斷是否為受控模式
  const isControlled = externalChartData !== undefined;

  // 是否支援多欄位
  const allowMultipleColumns = useMemo(() => {
    const kind = chartType?.kind || '';
    return !SINGLE_SERIES_CHARTS.includes(kind);
  }, [chartType]);

  // 是否為固定欄位圖表（如散點圖）
  const isFixedColumnsChart = useMemo(() => {
    const kind = chartType?.kind || '';
    return FIXED_COLUMNS_CHARTS.includes(kind);
  }, [chartType]);

  // 散點圖固定欄位配置（name 固定，x/y 可改名）
  const scatterChartConfig = useMemo(() => ({
    xKey: t('name'),  // 名稱欄位使用多語言
    yKeys: ['x', 'y']
  }), [t]);

  // 內部狀態（自動保存模式使用）
  // chartData 格式：[{ key: 'A', values: [10, 20] }, { key: 'B', values: [15, 25] }]
  const [internalChartData, setInternalChartData] = useState([]);
  const [internalXKey, setInternalXKey] = useState('name');
  const [internalYKeys, setInternalYKeys] = useState(['value']);
  const [internalValueIsNumber, setInternalValueIsNumber] = useState(true);

  // 拖曳狀態
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [dragOverIndex, setDragOverIndex] = useState(null);
  const [dragOverPosition, setDragOverPosition] = useState(null);

  // Hover 狀態
  const [hoveredIndex, setHoveredIndex] = useState(null);

  // 使用的數據（根據模式選擇）
  const chartData = isControlled ? externalChartData : internalChartData;
  const xKey = isControlled ? externalXKey : internalXKey;
  const yKeys = isControlled ? (externalYKeys || ['value']) : internalYKeys;
  const valueIsNumber = isControlled ? externalValueIsNumber : internalValueIsNumber;

  // 記錄上次初始化的 chart id 和 chartType kind，避免重複初始化
  const lastInitializedRef = React.useRef({ chartId: null, chartTypeKind: null });

  // 自動保存模式：初始化數據（當 chart.id 或 chartType.kind 改變時執行）
  useEffect(() => {
    if (isControlled) return;

    const currentChartId = chart?.id;
    const currentChartTypeKind = chartType?.kind;

    if (lastInitializedRef.current.chartId === currentChartId &&
      lastInitializedRef.current.chartTypeKind === currentChartTypeKind) return;
    lastInitializedRef.current = { chartId: currentChartId, chartTypeKind: currentChartTypeKind };

    // 散點圖使用固定欄位
    if (isFixedColumnsChart) {
      if (!chart?.data) {
        setInternalXKey(scatterChartConfig.xKey);
        setInternalYKeys(scatterChartConfig.yKeys);
        setInternalValueIsNumber(true);
        setInternalChartData([{ key: '', values: ['', ''] }]);
        return;
      }

      let parsedData = [];
      try {
        parsedData = typeof chart.data === 'string'
          ? JSON.parse(chart.data || '[]')
          : (chart.data || []);
      } catch (e) {
        parsedData = [];
      }

      // 從資料中推斷欄位名稱
      const firstRow = Array.isArray(parsedData) && parsedData.length > 0 ? parsedData[0] : null;
      if (firstRow && typeof firstRow === 'object') {
        const keys = Object.keys(firstRow);
        // 找出字串欄位作為 name
        const nameKey = keys.find(k => typeof firstRow[k] === 'string') || keys[0] || scatterChartConfig.xKey;
        // 找出數值欄位作為 x, y
        const numericKeys = keys.filter(k => typeof firstRow[k] === 'number');
        const xKey = numericKeys[0] || 'x';
        const yKey = numericKeys[1] || 'y';

        setInternalXKey(nameKey);
        setInternalYKeys([xKey, yKey]);
        setInternalValueIsNumber(true);

        setInternalChartData(
          (parsedData || []).map(row => ({
            key: row?.[nameKey] ?? '',
            values: [row?.[xKey] ?? '', row?.[yKey] ?? '']
          }))
        );
      } else {
        setInternalXKey(scatterChartConfig.xKey);
        setInternalYKeys(scatterChartConfig.yKeys);
        setInternalValueIsNumber(true);
        setInternalChartData([{ key: '', values: ['', ''] }]);
      }
      return;
    }

    if (!chart?.data) {
      setInternalChartData([{ key: '', values: [''] }]);
      setInternalYKeys(['value']);
      return;
    }

    let parsedData = [];
    try {
      parsedData = typeof chart.data === 'string'
        ? JSON.parse(chart.data || '[]')
        : (chart.data || []);
    } catch (e) {
      console.error('解析圖表數據失敗:', e);
      parsedData = [];
    }

    const firstRow = Array.isArray(parsedData) && parsedData.length > 0 ? parsedData[0] : null;
    if (firstRow && typeof firstRow === 'object' && !Array.isArray(firstRow)) {
      const keys = Object.keys(firstRow);
      // X 軸是第一個 string 類型的欄位
      const inferredX = keys.find(k => typeof firstRow[k] === 'string') || keys[0] || 'name';
      // Y 軸是所有 number 類型的欄位
      const numericKeys = keys.filter(k => typeof firstRow[k] === 'number' && k !== inferredX);
      const inferredYKeys = numericKeys.length > 0 ? numericKeys : keys.filter(k => k !== inferredX).slice(0, 1);
      if (inferredYKeys.length === 0) inferredYKeys.push('value');

      const inferredValueIsNumber = typeof firstRow[inferredYKeys[0]] === 'number' || numericKeys.length > 0;

      setInternalXKey(inferredX);
      setInternalYKeys(inferredYKeys);
      setInternalValueIsNumber(inferredValueIsNumber);

      setInternalChartData(
        (parsedData || []).map(row => ({
          key: row?.[inferredX] ?? '',
          values: inferredYKeys.map(yk => row?.[yk] ?? '')
        }))
      );
    } else {
      setInternalXKey(t('key'));
      setInternalYKeys(['value']);
      setInternalValueIsNumber(true);
      setInternalChartData([{ key: '', values: [''] }]);
    }
  }, [chart?.id, chart?.data, chartType?.kind, t, isControlled, isFixedColumnsChart, scatterChartConfig]);

  // 把表格格式轉換成 chart.data 格式（直接傳入參數，不依賴 state）
  const convertAndUpdateChart = useCallback((newData, newXKey, newYKeys, newValueIsNumber) => {
    if (isControlled || !chart || !onUpdateChart || readOnly) return;

    // 正規化欄位名稱
    const normalizedXKey = (newXKey || '').trim() || t('key');
    const normalizedYKeys = newYKeys.map((yk, i) => {
      let normalized = (yk || '').trim() || `value${i + 1}`;
      if (normalized === normalizedXKey) {
        normalized = `${normalized}_${i + 1}`;
      }
      return normalized;
    });

    // 過濾空行
    const filteredData = newData.filter(row => {
      const k = (row.key ?? '').toString().trim();
      const hasValue = (row.values || []).some(v => {
        const vStr = v === null || v === undefined ? '' : v.toString().trim();
        return vStr !== '';
      });
      return k || hasValue;
    });

    // 轉換成 chart.data 格式
    const convertedData = filteredData.map(row => {
      const out = {};
      out[normalizedXKey] = (row.key ?? '').toString();

      normalizedYKeys.forEach((yk, i) => {
        const v = row.values?.[i];
        if (newValueIsNumber) {
          const n = typeof v === 'number' ? v : parseFloat((v ?? '').toString());
          out[yk] = Number.isFinite(n) ? n : 0;
        } else {
          out[yk] = v ?? '';
        }
      });

      return out;
    });

    onUpdateChart({
      ...chart,
      data: convertedData
    });
  }, [chart, onUpdateChart, t, isControlled, readOnly]);

  // 新增一行數據
  const handleAddRow = useCallback(() => {
    if (readOnly) return;
    const newRow = { key: '', values: yKeys.map(() => '') };
    const newData = [...chartData, newRow];
    if (isControlled) {
      onChange?.({ chartData: newData, xKey, yKeys, valueIsNumber });
    } else {
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, yKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 刪除一行數據
  const handleRemoveRow = useCallback((index) => {
    if (readOnly) return;
    let newData = chartData.filter((_, i) => i !== index);
    if (newData.length === 0) newData = [{ key: '', values: yKeys.map(() => '') }];
    if (isControlled) {
      onChange?.({ chartData: newData, xKey, yKeys, valueIsNumber });
    } else {
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, yKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 更新數據行的 key
  const handleKeyChange = useCallback((index, value) => {
    if (readOnly) return;
    const newData = [...chartData];
    newData[index] = { ...newData[index], key: value };
    if (isControlled) {
      onChange?.({ chartData: newData, xKey, yKeys, valueIsNumber });
    } else {
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, yKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 更新數據行的 value（指定欄位索引）
  const handleValueChange = useCallback((rowIndex, colIndex, value) => {
    if (readOnly) return;
    const newData = [...chartData];
    const newValues = [...(newData[rowIndex].values || [])];
    newValues[colIndex] = value;
    newData[rowIndex] = { ...newData[rowIndex], values: newValues };
    if (isControlled) {
      onChange?.({ chartData: newData, xKey, yKeys, valueIsNumber });
    } else {
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, yKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 更新 X 軸表頭
  const handleXKeyChange = useCallback((value) => {
    if (readOnly) return;
    if (isControlled) {
      onChange?.({ chartData, xKey: value, yKeys, valueIsNumber });
    } else {
      setInternalXKey(value);
      convertAndUpdateChart(chartData, value, yKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 更新 Y 軸表頭（指定欄位索引）
  const handleYKeyChange = useCallback((colIndex, value) => {
    if (readOnly) return;
    const newYKeys = [...yKeys];
    newYKeys[colIndex] = value;
    if (isControlled) {
      onChange?.({ chartData, xKey, yKeys: newYKeys, valueIsNumber });
    } else {
      setInternalYKeys(newYKeys);
      convertAndUpdateChart(chartData, xKey, newYKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 新增欄位
  const handleAddColumn = useCallback(() => {
    if (readOnly) return;
    const newYKeys = [...yKeys, `value${yKeys.length + 1}`];
    const newData = chartData.map(row => ({
      ...row,
      values: [...(row.values || []), '']
    }));
    if (isControlled) {
      onChange?.({ chartData: newData, xKey, yKeys: newYKeys, valueIsNumber });
    } else {
      setInternalYKeys(newYKeys);
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, newYKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 刪除欄位
  const handleRemoveColumn = useCallback((colIndex) => {
    if (readOnly) return;
    if (yKeys.length <= 1) return;
    const newYKeys = yKeys.filter((_, i) => i !== colIndex);
    const newData = chartData.map(row => ({
      ...row,
      values: (row.values || []).filter((_, i) => i !== colIndex)
    }));
    if (isControlled) {
      onChange?.({ chartData: newData, xKey, yKeys: newYKeys, valueIsNumber });
    } else {
      setInternalYKeys(newYKeys);
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, newYKeys, valueIsNumber);
    }
  }, [chartData, isControlled, onChange, xKey, yKeys, valueIsNumber, convertAndUpdateChart, readOnly]);

  // 拖曳開始
  const handleDragStart = useCallback((e, index) => {
    if (disableDrag) return;
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
  }, [disableDrag]);

  // 拖曳經過（判斷上下半部）
  const handleDragOver = useCallback((e, index) => {
    if (disableDrag) return;
    e.preventDefault();
    if (draggedIndex === null) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const midY = rect.top + rect.height / 2;
    const position = e.clientY < midY ? 'top' : 'bottom';

    setDragOverIndex(index);
    setDragOverPosition(position);
  }, [draggedIndex, disableDrag]);

  // 拖曳結束
  const handleDragEnd = useCallback(() => {
    setDraggedIndex(null);
    setDragOverIndex(null);
    setDragOverPosition(null);
  }, []);

  // 放下（根據上下位置決定插入點）
  const handleDrop = useCallback((e, dropIndex) => {
    if (disableDrag) return;
    e.preventDefault();
    if (draggedIndex === null) {
      handleDragEnd();
      return;
    }

    let insertIndex = dropIndex;
    if (dragOverPosition === 'bottom') {
      insertIndex = dropIndex + 1;
    }

    if (draggedIndex < insertIndex) {
      insertIndex -= 1;
    }

    if (draggedIndex === insertIndex) {
      handleDragEnd();
      return;
    }

    const newData = [...chartData];
    const [draggedItem] = newData.splice(draggedIndex, 1);
    newData.splice(insertIndex, 0, draggedItem);

    if (isControlled) {
      // 傳遞拖曳信息：從哪個索引移動到哪個索引
      onChange?.({ chartData: newData, xKey, yKeys, valueIsNumber, movedFromIndex: draggedIndex, movedToIndex: insertIndex });
    } else {
      setInternalChartData(newData);
      convertAndUpdateChart(newData, xKey, yKeys, valueIsNumber);
    }

    handleDragEnd();
  }, [chartData, draggedIndex, dragOverPosition, isControlled, onChange, xKey, yKeys, valueIsNumber, handleDragEnd, convertAndUpdateChart, disableDrag]);

  // 行點擊處理
  const handleRowClick = useCallback((row, index) => {
    if (onRowClick) {
      onRowClick(row, index);
    }
  }, [onRowClick]);

  // 空狀態
  if (!isControlled && !chart) {
    return (
      <div className="custom-data-table-empty">
        <p>{emptyMessage || t('noChartData')}</p>
      </div>
    );
  }

  // 計算是否顯示拖曳手柄（只受 disableDrag 控制，readOnly 不影響拖曳）
  const showDragHandles = !disableDrag;
  // 計算是否顯示操作按鈕
  const showActions = !readOnly && !hideActions;
  // 計算是否顯示第一列（key 列）- 當 xKey 為空時隱藏
  const showKeyColumn = xKey !== '';

  const tableContent = (
    <div className={`custom-data-table-container ${readOnly ? 'custom-data-table-readonly' : ''}`}>
      {/* 表格區域：拖曳手柄欄 + 表格本體 */}
      <div className="custom-data-table-layout">
        {/* 拖曳手柄欄（在表格外） */}
        {showDragHandles && (
          <div className="custom-data-table-handles-column">
            {/* 表頭佔位 */}
            <div className="custom-data-table-handle-spacer"></div>
            {/* 數據行的拖曳手柄 */}
            {chartData.map((_, index) => (
              <div
                key={index}
                className={`custom-data-table-handle-cell ${draggedIndex === index ? 'custom-data-table-handle-cell-dragging' : ''} ${hoveredIndex === index ? 'custom-data-table-handle-cell-hover' : ''}`}
                draggable
                onDragStart={(e) => handleDragStart(e, index)}
                onDragOver={(e) => handleDragOver(e, index)}
                onDragEnd={handleDragEnd}
                onDrop={(e) => handleDrop(e, index)}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className="custom-data-table-drag-icon">
                  <DragHandleIcon />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 表格本體 */}
        <div className="custom-data-table">
          {/* 表頭 */}
          <div className="custom-data-table-row custom-data-table-header-row">
            {showKeyColumn && (
              <div className="custom-data-table-cell custom-data-table-key">
                {readOnly ? (
                  <span className="custom-data-table-header-text">{xKey}</span>
                ) : (
                  <input
                    type="text"
                    className="custom-data-table-header-input"
                    value={xKey}
                    onChange={(e) => handleXKeyChange(e.target.value)}
                    placeholder={t('key')}
                  />
                )}
              </div>
            )}
            {yKeys.map((yk, colIndex) => (
              <div key={colIndex} className="custom-data-table-cell custom-data-table-value">
                {readOnly ? (
                  <span className="custom-data-table-header-text">{yk}</span>
                ) : (
                  <input
                    type="text"
                    className="custom-data-table-header-input"
                    value={yk}
                    onChange={(e) => handleYKeyChange(colIndex, e.target.value)}
                    placeholder={t('value')}
                  />
                )}
                {/* 刪除欄位按鈕（固定欄位圖表不顯示，且至少保留一個） */}
                {showActions && !isFixedColumnsChart && yKeys.length > 1 && (
                  <button
                    className="custom-data-table-remove-col-btn"
                    onClick={() => handleRemoveColumn(colIndex)}
                    title={t('removeColumn')}
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </button>
                )}
              </div>
            ))}
            {showActions && (
              <div className="custom-data-table-cell custom-data-table-action">
                {/* 新增欄位按鈕（固定欄位圖表不顯示） */}
                {allowMultipleColumns && !isFixedColumnsChart && (
                  <button
                    className="custom-data-table-add-col-btn"
                    onClick={handleAddColumn}
                    title={t('addColumn')}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="12" y1="5" x2="12" y2="19"></line>
                      <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* 數據行 */}
          {chartData.map((row, index) => (
            <div
              key={index}
              className={`custom-data-table-row ${draggedIndex === index ? 'custom-data-table-row-dragging' : ''} ${dragOverIndex === index && dragOverPosition === 'top' ? 'custom-data-table-drag-over-top' : ''} ${dragOverIndex === index && dragOverPosition === 'bottom' ? 'custom-data-table-drag-over-bottom' : ''} ${hoveredIndex === index ? 'custom-data-table-row-hover' : ''} ${onRowClick ? 'custom-data-table-row-clickable' : ''}`}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={(e) => handleDrop(e, index)}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
              onClick={() => handleRowClick(row, index)}
            >
              {showKeyColumn && (
                <div className="custom-data-table-cell custom-data-table-key">
                  {readOnly ? (
                    <span className="custom-data-table-text">{row.key || ''}</span>
                  ) : (
                    <input
                      type="text"
                      className="custom-data-table-input"
                      value={row.key || ''}
                      onChange={(e) => handleKeyChange(index, e.target.value)}
                      placeholder={t('enterKey')}
                    />
                  )}
                </div>
              )}
              {yKeys.map((_, colIndex) => (
                <div key={colIndex} className="custom-data-table-cell custom-data-table-value">
                  {readOnly ? (
                    <span className="custom-data-table-text">{row.values?.[colIndex] || ''}</span>
                  ) : (
                    <input
                      type="text"
                      className="custom-data-table-input"
                      value={row.values?.[colIndex] || ''}
                      onChange={(e) => handleValueChange(index, colIndex, e.target.value)}
                      placeholder={t('enterValue')}
                    />
                  )}
                </div>
              ))}
              {showActions && (
                <div className="custom-data-table-cell custom-data-table-action">
                  <button
                    className="custom-data-table-remove-btn"
                    onClick={() => handleRemoveRow(index)}
                    disabled={chartData.length <= 1}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                  </button>
                </div>
              )}
            </div>
          ))}

          {/* 空狀態 */}
          {chartData.length === 0 && (
            <div className="custom-data-table-empty-row">
              <p>{emptyMessage || t('noDataYet')}</p>
            </div>
          )}
        </div>
      </div>

      {/* 新增行按鈕 */}
      {showActions && (
        <button className={`custom-data-table-add-row-btn ${showDragHandles ? '' : 'custom-data-table-add-row-btn-full'}`} onClick={handleAddRow}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <line x1="5" y1="12" x2="19" y2="12"></line>
          </svg>
        </button>
      )}
    </div>
  );

  if (!showHeader) {
    return tableContent;
  }

  return (
    <div className="custom-data-table-wrapper">
      {tableContent}
    </div>
  );
}

export default CustomDataTable;

