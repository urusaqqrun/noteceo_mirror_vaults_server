import React from 'react';
import './MobileTopbar.css';
import MenuIcon from '../../assets/icon_menu_24.svg?react';
import ArrowLeftIcon from '../../assets/icon_arrow_left_24.svg?react';

/**
 * MobileTopbar 統一組件
 * 用於手機版的頂部標題列
 * 
 * @param {string} leftIcon - 左側按鈕類型：'menu'（漢堡選單）| 'back'（返回）| 'none'（無）
 * @param {function} onLeftClick - 左側按鈕點擊事件
 * @param {string} title - 標題文字
 * @param {React.ReactNode} titleIcon - 標題前的圖標（可選）
 * @param {React.ReactNode} titleSuffix - 標題後的額外內容（可選）
 * @param {React.ReactNode} rightContent - 右側內容區域
 * @param {string} className - 額外的 class name
 */
function MobileTopbar({
  leftIcon = 'menu',
  onLeftClick,
  title,
  titleIcon = null,
  titleSuffix = null,
  rightContent,
  className = ''
}) {
  const renderLeftButton = () => {
    if (leftIcon === 'none') return null;

    return (
      <button
        className="mobile-topbar-button"
        onClick={onLeftClick}
      >
        {leftIcon === 'back' ? <ArrowLeftIcon /> : <MenuIcon />}
      </button>
    );
  };

  return (
    <div className={`mobile-topbar ${className}`}>
      <div className="mobile-topbar-left">
        {renderLeftButton()}
        {titleIcon && <span className="mobile-topbar-title-icon">{titleIcon}</span>}
        <span className="mobile-topbar-title">{title}</span>
        {titleSuffix}
      </div>
      {rightContent && (
        <div className="mobile-topbar-right">
          {rightContent}
        </div>
      )}
    </div>
  );
}

export default MobileTopbar;

