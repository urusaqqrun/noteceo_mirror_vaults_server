import React, { useRef, useEffect, useCallback, forwardRef } from 'react';
import './CustomScrollbar.css';

interface CustomScrollbarProps {
  children?: React.ReactNode;
  offsetRight?: number;
  onScroll?: (e: Event) => void;
  [key: string]: any;
}

const CustomScrollbar = forwardRef<HTMLDivElement, CustomScrollbarProps>(function CustomScrollbar(
  { children, offsetRight = 4, onScroll, ...props }, forwardedRef
) {
  const contentRef = useRef(null);
  const thumbRef = useRef(null);
  const trackRef = useRef(null);

  // 更新 thumb 尺寸與位置
  const updateThumb = useCallback(() => {
    const content = contentRef.current;
    const thumb = thumbRef.current;
    if (!content || !thumb) return;

    const { scrollTop, scrollHeight, clientHeight } = content;

    if (scrollHeight <= clientHeight) {
      thumb.style.display = 'none';
      // 避免下一次顯示仍保留舊位移
      thumb.style.transform = 'translateY(0)';
      return;
    }
    thumb.style.display = 'block';

    const thumbHeight = Math.max((clientHeight / scrollHeight) * clientHeight, 20);
    const top = (scrollTop / scrollHeight) * clientHeight;
    thumb.style.height = `${thumbHeight}px`;
    thumb.style.transform = `translateY(${top}px)`;
  }, []);

  // 綁定 scroll / resize / 內容尺寸變化
  useEffect(() => {
    const content = contentRef.current;
    if (!content) return;

    // 初始一次
    updateThumb();

    // scroll 與視窗 resize
    const handleScroll = (e) => {
      updateThumb();
      onScroll?.(e);
    };
    content.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', updateThumb);

    // 內容尺寸變動 (新增 / 移除筆記)
    let ro;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => updateThumb());
      ro.observe(content);
    }

    // DOM 結構變化（如 React 重新渲染筆記）
    const mo = new MutationObserver(() => updateThumb());
    mo.observe(content, { childList: true, subtree: true });

    return () => {
      content.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', updateThumb);
      if (ro) ro.disconnect();
      mo.disconnect();
    };
  }, [updateThumb, onScroll]);

  // 拖曳
  useEffect(() => {
    const content = contentRef.current;
    const thumb = thumbRef.current;
    if (!content || !thumb) return;

    let startY = 0;
    let startScrollTop = 0;

    const onMouseMove = (e) => {
      const delta = e.clientY - startY;
      const { scrollHeight, clientHeight } = content;
      content.scrollTop = startScrollTop + (delta * scrollHeight) / clientHeight;
    };
    const onMouseUp = () => {
      thumb.classList.remove('dragging');
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    const onMouseDown = (e) => {
      e.preventDefault();
      startY = e.clientY;
      startScrollTop = content.scrollTop;
      thumb.classList.add('dragging');
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    };

    thumb.addEventListener('mousedown', onMouseDown);
    return () => thumb.removeEventListener('mousedown', onMouseDown);
  }, []);

  // track click 跳捲
  useEffect(() => {
    const track = trackRef.current;
    const content = contentRef.current;
    if (!track || !content) return;
    const onTrackMouseDown = (e) => {
      if (e.button !== 0) return;
      const rect = track.getBoundingClientRect();
      const percent = (e.clientY - rect.top) / rect.height;
      content.scrollTop = percent * content.scrollHeight;
    };
    track.addEventListener('mousedown', onTrackMouseDown);
    return () => track.removeEventListener('mousedown', onTrackMouseDown);
  }, []);

  return (
    <div className={`custom-scrollbar-wrapper`} {...props}>
      <div
        className="custom-scrollbar-content"
        ref={(node) => {
          contentRef.current = node;
          if (typeof forwardedRef === 'function') forwardedRef(node);
          else if (forwardedRef) forwardedRef.current = node;
        }}
      >
        {children}
      </div>
      <div className="custom-scrollbar-track" ref={trackRef} style={{ right: `${offsetRight}px` }}>
        <div className="custom-scrollbar-thumb" ref={thumbRef} />
      </div>
    </div>
  );
});

export default CustomScrollbar;