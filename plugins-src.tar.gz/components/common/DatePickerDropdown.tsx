import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import './DatePickerDropdown.css';
import ClockIcon from '../../assets/category/clock.svg?react';
import RepeatIcon from '../../assets/icon_repeat_arrow_16_n.svg?react';
import CalNoDate from '../../assets/calendar/no-date.calendar.svg?react';
import TimePickerDialog from './TimePickerDialog';
// Note: timePicker 和 repeatMenu 使用本地 useState 控制，不佔用 dialogStore key

// 導入所有日曆 icons (01-31)
import Cal01 from '../../assets/calendar/01.calendar.svg?react';
import Cal02 from '../../assets/calendar/02.calendar.svg?react';
import Cal03 from '../../assets/calendar/03.calendar.svg?react';
import Cal04 from '../../assets/calendar/04.calendar.svg?react';
import Cal05 from '../../assets/calendar/05.calendar.svg?react';
import Cal06 from '../../assets/calendar/06.calendar.svg?react';
import Cal07 from '../../assets/calendar/07.calendar.svg?react';
import Cal08 from '../../assets/calendar/08.calendar.svg?react';
import Cal09 from '../../assets/calendar/09.calendar.svg?react';
import Cal10 from '../../assets/calendar/10.calendar.svg?react';
import Cal11 from '../../assets/calendar/11.calendar.svg?react';
import Cal12 from '../../assets/calendar/12.calendar.svg?react';
import Cal13 from '../../assets/calendar/13.calendar.svg?react';
import Cal14 from '../../assets/calendar/14.calendar.svg?react';
import Cal15 from '../../assets/calendar/15.calendar.svg?react';
import Cal16 from '../../assets/calendar/16.calendar.svg?react';
import Cal17 from '../../assets/calendar/17.calendar.svg?react';
import Cal18 from '../../assets/calendar/18.calendar.svg?react';
import Cal19 from '../../assets/calendar/19.calendar.svg?react';
import Cal20 from '../../assets/calendar/20.calendar.svg?react';
import Cal21 from '../../assets/calendar/21.calendar.svg?react';
import Cal22 from '../../assets/calendar/22.calendar.svg?react';
import Cal23 from '../../assets/calendar/23.calendar.svg?react';
import Cal24 from '../../assets/calendar/24.calendar.svg?react';
import Cal25 from '../../assets/calendar/25.calendar.svg?react';
import Cal26 from '../../assets/calendar/26.calendar.svg?react';
import Cal27 from '../../assets/calendar/27.calendar.svg?react';
import Cal28 from '../../assets/calendar/28.calendar.svg?react';
import Cal29 from '../../assets/calendar/29.calendar.svg?react';
import Cal30 from '../../assets/calendar/30.calendar.svg?react';
import Cal31 from '../../assets/calendar/31.calendar.svg?react';


// 日曆 icon map
const calendarIcons = {
  1: Cal01, 2: Cal02, 3: Cal03, 4: Cal04, 5: Cal05, 6: Cal06, 7: Cal07,
  8: Cal08, 9: Cal09, 10: Cal10, 11: Cal11, 12: Cal12, 13: Cal13, 14: Cal14,
  15: Cal15, 16: Cal16, 17: Cal17, 18: Cal18, 19: Cal19, 20: Cal20, 21: Cal21,
  22: Cal22, 23: Cal23, 24: Cal24, 25: Cal25, 26: Cal26, 27: Cal27, 28: Cal28,
  29: Cal29, 30: Cal30, 31: Cal31
};

/**
 * DatePickerDropdown - 日期選擇下拉組件
 * 
 * @param {string} value - 當前日期值 (YYYY-MM-DD 格式)
 * @param {string} timeValue - 當前時間值 (HH:mm 格式)
 * @param {object} repeatValue - 當前重複值 { type: 'daily'|'weekly'|'weekdays'|'monthly', dayOfWeek?: number, dayOfMonth?: number }
 * @param {Function} onChange - 日期變更回調 (dateStr) => void，dateStr 為 null 表示清除日期
 * @param {Function} onTimeChange - 時間變更回調 (timeStr) => void
 * @param {Function} onRepeatChange - 重複變更回調 (repeatObj) => void
 * @param {React.ReactNode} trigger - 觸發元素
 * @param {string} className - 額外的 class
 */
const DatePickerDropdown = ({
  value: externalValue,
  timeValue: externalTimeValue = null,
  repeatValue: externalRepeatValue = null,
  onChange,
  onTimeChange = null,
  onRepeatChange = null,
  trigger,
  className = '',
  closeOnSelect = false // 選擇日期後是否關閉（用於只需要日曆的場景）
}) => {
  const { t } = useTranslation();
  const [showDropdown, setShowDropdown] = useState(false);
  const [showTimeDialog, setShowTimeDialog] = useState(false);
  const [showRepeatMenu, setShowRepeatMenu] = useState(false);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, direction: 'down' });
  const [repeatMenuPosition, setRepeatMenuPosition] = useState<{ top?: number; bottom?: number; left: number }>({ top: 0, left: 0 });
  const [internalTimeValue, setInternalTimeValue] = useState(externalTimeValue || null);
  const [internalDateValue, setInternalDateValue] = useState(externalValue || null);
  const [internalRepeatValue, setInternalRepeatValue] = useState(externalRepeatValue || null);
  const [searchInputValue, setSearchInputValue] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const dropdownRef = useRef(null);
  const triggerRef = useRef(null);
  const repeatButtonRef = useRef(null);

  // 使用外部值或內部值
  const timeValue = externalTimeValue !== undefined ? externalTimeValue : internalTimeValue;
  const value = externalValue !== undefined ? externalValue : internalDateValue;
  const repeatValue = externalRepeatValue !== undefined ? externalRepeatValue : internalRepeatValue;

  // 格式化日期時間顯示
  const formatDisplayDateTime = () => {
    if (!value) return '';
    const [year, month, day] = value.split('-');
    const dateStr = `${year}/${month}/${day}`;
    return timeValue ? `${dateStr} ${timeValue}` : dateStr;
  };

  // 獲取今日日期字串
  const getTodayDateStr = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // 解析輸入的日期時間
  const parseInputDateTime = (input) => {
    if (!input || !input.trim()) return null;

    const trimmed = input.trim();
    let datePart = '';
    let timePart = null;

    // 檢查是否包含時間（空格分隔）
    const parts = trimmed.split(/\s+/);
    if (parts.length >= 2) {
      datePart = parts[0];
      timePart = parts.slice(1).join(' ');
    } else {
      datePart = trimmed;
    }

    // 解析日期部分（支持 M/D 或 YYYY/M/D 或 M-D 或 YYYY-M-D）
    let year, month, day;
    const dateMatch = datePart.match(/^(\d{1,4})[\/\-](\d{1,2})(?:[\/\-](\d{1,2}))?$/);
    if (!dateMatch) return null;

    if (dateMatch[3]) {
      // YYYY/M/D 或 M/D/Y 格式
      if (dateMatch[1].length === 4) {
        year = parseInt(dateMatch[1]);
        month = parseInt(dateMatch[2]);
        day = parseInt(dateMatch[3]);
      } else {
        month = parseInt(dateMatch[1]);
        day = parseInt(dateMatch[2]);
        year = parseInt(dateMatch[3]);
        if (year < 100) year += 2000;
      }
    } else {
      // M/D 格式，自動判斷年份
      month = parseInt(dateMatch[1]);
      day = parseInt(dateMatch[2]);
      const now = new Date();
      year = now.getFullYear();
      // 如果日期已過，使用下一年
      const inputDate = new Date(year, month - 1, day);
      if (inputDate < now) {
        year += 1;
      }
    }

    // 驗證日期有效性
    if (month < 1 || month > 12 || day < 1 || day > 31) return null;
    const testDate = new Date(year, month - 1, day);
    if (testDate.getMonth() !== month - 1) return null; // 無效日期（如 2/30）

    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

    // 解析時間部分
    let timeStr = null;
    if (timePart) {
      const timeMatch = timePart.match(/^(\d{1,2}):(\d{2})$/);
      if (timeMatch) {
        const hours = parseInt(timeMatch[1]);
        const minutes = parseInt(timeMatch[2]);
        if (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59) {
          timeStr = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
        }
      }
    }

    return { dateStr, timeStr };
  };

  // 處理搜尋輸入 focus
  const handleSearchFocus = () => {
    setIsSearchFocused(true);
    setSearchInputValue(formatDisplayDateTime());
  };

  // 處理搜尋輸入 blur
  const handleSearchBlur = () => {
    setIsSearchFocused(false);
    setSearchInputValue('');
  };

  // 處理搜尋輸入 enter
  const handleSearchKeyDown = (e) => {
    if (e.key === 'Enter') {
      const result = parseInputDateTime(searchInputValue);
      if (result) {
        // 更新日期
        setInternalDateValue(result.dateStr);
        if (onChange) onChange(result.dateStr);

        // 更新時間（如果有）
        if (result.timeStr !== null) {
          setInternalTimeValue(result.timeStr);
          if (onTimeChange) onTimeChange(result.timeStr);
        }

        setSearchInputValue(formatDisplayDateTime());

        // closeOnSelect 模式：選擇後關閉
        if (closeOnSelect) {
          setShowDropdown(false);
        }
      } else {
        // 無效輸入，恢復原本狀態
        setSearchInputValue(formatDisplayDateTime());
      }
      e.target.blur();
    } else if (e.key === 'Escape') {
      setSearchInputValue(formatDisplayDateTime());
      e.target.blur();
    }
  };


  // 處理觸發點擊
  const handleTriggerClick = (e) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const screenHeight = window.innerHeight;
    const oneThird = screenHeight / 3;
    const twoThird = (screenHeight * 2) / 3;
    const dropdownHeight = 420; // 預估 dropdown 高度

    let direction, top, left;

    // 前三分之一往下，中間三分之一往右，下三分之一往上
    if (rect.top < oneThird) {
      direction = 'down';
      top = rect.bottom + 4;
      left = rect.left;
    } else if (rect.top < twoThird) {
      direction = 'right';
      // 垂直置中，並確保不超出螢幕
      const centerY = rect.top + rect.height / 2 - dropdownHeight / 2;
      top = Math.max(8, Math.min(centerY, screenHeight - dropdownHeight - 8));
      left = rect.right + 4;
    } else {
      direction = 'up';
      top = rect.top;
      left = rect.left;
    }

    setDropdownPosition({ top, left, direction });
    setShowDropdown(!showDropdown);
  };

  // 處理日期選擇（關閉 dropdown）
  const handleDateSelect = (dateStr) => {
    setInternalDateValue(dateStr);
    if (onChange) {
      onChange(dateStr);
    }
    setShowDropdown(false);
  };

  // 處理日曆選擇（closeOnSelect 模式會關閉 dropdown）
  const handleCalendarChange = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;
    setInternalDateValue(dateStr);
    if (onChange) {
      onChange(dateStr);
    }
    if (closeOnSelect) {
      setShowDropdown(false);
    }
  };

  // 獲取建議日期
  const getSuggestedDates = () => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // 計算週末（週六）
    const dayOfWeek = today.getDay();
    const daysUntilSaturday = dayOfWeek === 6 ? 7 : (6 - dayOfWeek);
    const weekend = new Date(today);
    weekend.setDate(weekend.getDate() + daysUntilSaturday);

    const weekdays = [t('sunday'), t('monday'), t('tuesday'), t('wednesday'), t('thursday'), t('friday'), t('saturday')];

    const formatSuggestedDate = (date) => {
      const d = date.getDay();
      // 如果是下週，顯示完整日期
      if (date > tomorrow) {
        const y = date.getFullYear();
        const m = date.getMonth() + 1;
        const dayNum = date.getDate();
        return `${weekdays[d]} ${y}年${m}月${dayNum}日`;
      }
      return weekdays[d];
    };

    const toDateStr = (date) => {
      const y = date.getFullYear();
      const m = String(date.getMonth() + 1).padStart(2, '0');
      const d = String(date.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    };

    return [
      { label: t('today'), hint: weekdays[today.getDay()].slice(-1), dateStr: toDateStr(today), day: today.getDate(), colorClass: 'green' },
      { label: t('tomorrow'), hint: weekdays[tomorrow.getDay()].slice(-1), dateStr: toDateStr(tomorrow), day: tomorrow.getDate(), colorClass: 'orange' },
      { label: daysUntilSaturday <= 6 ? t('weekend') : t('nextWeekend'), hint: formatSuggestedDate(weekend), dateStr: toDateStr(weekend), day: weekend.getDate(), colorClass: 'purple' },
      { label: t('noDate'), hint: '', dateStr: null, day: null, colorClass: 'gray' }
    ];
  };

  // 獲取當前日期的星期幾和日期
  const getCurrentDayInfo = () => {
    const date = value ? new Date(value + 'T00:00:00') : new Date();
    const dayOfWeek = date.getDay();
    const dayOfMonth = date.getDate();
    const weekdays = [t('sunday'), t('monday'), t('tuesday'), t('wednesday'), t('thursday'), t('friday'), t('saturday')];
    return { dayOfWeek, dayOfMonth, weekdayName: weekdays[dayOfWeek] };
  };

  // 獲取重複選項
  const getRepeatOptions = () => {
    const { dayOfWeek, dayOfMonth, weekdayName } = getCurrentDayInfo();
    return [
      { frequency: 'DAILY', label: t('repeatDaily'), hint: timeValue || '' },
      { frequency: 'WEEKLY', label: t('repeatWeekly'), hint: weekdayName, daysOfWeek: [dayOfWeek] },
      { frequency: 'WEEKLY', label: t('repeatWeekdays'), hint: t('repeatWeekdaysHint'), daysOfWeek: [1, 2, 3, 4, 5], isWeekdays: true },
      { frequency: 'MONTHLY', label: t('repeatMonthly'), hint: t('repeatMonthlyHint', { day: dayOfMonth }), daysOfMonth: [dayOfMonth] }
    ];
  };

  // 獲取重複值的顯示文字
  const getRepeatDisplayText = () => {
    if (!repeatValue) return null;
    const { dayOfWeek, dayOfMonth, weekdayName } = getCurrentDayInfo();
    const weekdays = [t('sunday'), t('monday'), t('tuesday'), t('wednesday'), t('thursday'), t('friday'), t('saturday')];
    const timeStr = repeatValue.timeOfDay ? ` ${repeatValue.timeOfDay}` : '';

    // 檢查是否為工作日（週一到週五）
    const isWeekdays = repeatValue.frequency === 'WEEKLY' &&
      repeatValue.daysOfWeek &&
      repeatValue.daysOfWeek.length === 5 &&
      [1, 2, 3, 4, 5].every(d => repeatValue.daysOfWeek.includes(d));

    switch (repeatValue.frequency) {
      case 'DAILY':
        return t('repeatDaily') + timeStr;
      case 'WEEKLY':
        if (isWeekdays) {
          return t('repeatWeekdaysHint') + timeStr;
        }
        const weekdayIdx = repeatValue.daysOfWeek?.[0] ?? dayOfWeek;
        const weekday = weekdays[weekdayIdx];
        return t('repeatEveryWeekday', { weekday }) + timeStr;
      case 'MONTHLY':
        const day = repeatValue.daysOfMonth?.[0] || dayOfMonth;
        return t('repeatEveryMonthDay', { day }) + timeStr;
      default:
        return null;
    }
  };

  // 處理重複按鈕點擊
  const handleRepeatButtonClick = (e) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    setRepeatMenuPosition({
      bottom: window.innerHeight - rect.top + 4,
      left: rect.left
    });
    setShowRepeatMenu(true);
  };

  // 處理重複選項選擇
  const handleRepeatSelect = (option) => {
    const newValue = {
      frequency: option.frequency,
      ...(option.daysOfWeek && { daysOfWeek: option.daysOfWeek }),
      ...(option.daysOfMonth && { daysOfMonth: option.daysOfMonth }),
      ...(timeValue && { timeOfDay: timeValue })
    };
    setInternalRepeatValue(newValue);
    if (onRepeatChange) {
      onRepeatChange(newValue);
    }
    setShowRepeatMenu(false);
  };

  // 清除重複值
  const handleRepeatClear = (e) => {
    e.stopPropagation();
    setInternalRepeatValue(null);
    if (onRepeatChange) {
      onRepeatChange(null);
    }
  };

  // 解析當前日期（防護 Invalid Date）
  const currentDate = (() => {
    if (!value) return null;
    const d = new Date(value + 'T00:00:00');
    return isNaN(d.getTime()) ? null : d;
  })();

  return (
    <div className={`date-picker-dropdown-wrapper ${className} ${showDropdown ? 'active' : ''}`} ref={dropdownRef}>
      <div onClick={handleTriggerClick} ref={triggerRef}>
        {trigger}
      </div>
      {showDropdown && (
        <>
          {/* 全螢幕透明 overlay */}
          <div
            className="date-picker-overlay"
            onClick={(e) => {
              e.stopPropagation();
              setShowDropdown(false);
            }}
          />
          <div
            className={`date-picker-dropdown ${dropdownPosition.direction}`}
            style={{
              position: 'fixed',
              top: dropdownPosition.direction === 'up' ? 'auto' : dropdownPosition.top,
              bottom: dropdownPosition.direction === 'up' ? `calc(100vh - ${dropdownPosition.top}px + 4px)` : 'auto',
              left: dropdownPosition.left
            }}
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
          >
            {/* 搜尋欄位 */}
            <div className="date-picker-search">
              <input
                type="text"
                value={isSearchFocused ? searchInputValue : formatDisplayDateTime()}
                placeholder={t('enterDate')}
                onChange={(e) => setSearchInputValue(e.target.value)}
                onFocus={handleSearchFocus}
                onBlur={handleSearchBlur}
                onKeyDown={handleSearchKeyDown}
                onMouseDown={(e) => e.stopPropagation()}
              />
            </div>

            {/* 建議時間 */}
            <div className="date-picker-suggestions">
              {getSuggestedDates().map((item, index) => {
                const IconComponent = item.day ? calendarIcons[item.day] : CalNoDate;
                return (
                  <div
                    key={index}
                    className="date-picker-suggestion-item"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDateSelect(item.dateStr);
                    }}
                  >
                    <div className="suggestion-left">
                      <IconComponent className={`suggestion-icon suggestion-icon-${item.colorClass}`} />
                      <span className="suggestion-label">{item.label}</span>
                    </div>
                    <span className="suggestion-hint">{item.hint}</span>
                  </div>
                );
              })}
            </div>

            {/* 日曆 */}
            <div className="date-picker-calendar">
              <Calendar
                value={currentDate}
                onChange={handleCalendarChange}
                locale={t('calendarLocale')}
                formatDay={(locale, date) => String(date.getDate())}
                showNeighboringMonth={false}
                maxDate={new Date(Date.now() + 730 * 24 * 60 * 60 * 1000)}
                tileDisabled={({ date }) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  return date < today;
                }}
              />
            </div>

            {/* 時間和重複按鈕 */}
            <div className="date-picker-options">
              <button
                className={`date-picker-option ${timeValue ? 'has-value' : ''}`}
                onClick={(e) => {
                  e.stopPropagation();
                  // 如果沒有選擇日期，自動設為今日
                  if (!value) {
                    const todayStr = getTodayDateStr();
                    setInternalDateValue(todayStr);
                    if (onChange) {
                      onChange(todayStr);
                    }
                  }
                  setShowTimeDialog(true);
                }}
              >
                <ClockIcon className="date-picker-option-icon" />
                <span>{timeValue || t('time')}</span>
                {timeValue && (
                  <div
                    className="date-picker-option-clear"
                    onClick={(e) => {
                      e.stopPropagation();
                      setInternalTimeValue(null);
                      if (onTimeChange) {
                        onTimeChange(null);
                      }
                    }}
                  >
                    ✕
                  </div>
                )}
              </button>
              <button
                ref={repeatButtonRef}
                className={`date-picker-option ${repeatValue ? 'has-value' : ''}`}
                onClick={handleRepeatButtonClick}
              >
                <RepeatIcon className="date-picker-option-icon" />
                <span>{getRepeatDisplayText() || t('repeat')}</span>
                {repeatValue && (
                  <div
                    className="date-picker-option-clear"
                    onClick={handleRepeatClear}
                  >
                    ✕
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* 重複選項菜單 */}
          {showRepeatMenu && (
            <>
              <div
                className="date-picker-repeat-overlay"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowRepeatMenu(false);
                }}
              />
              <div
                className="date-picker-repeat-menu"
                style={{
                  position: 'fixed',
                  bottom: repeatMenuPosition.bottom,
                  left: repeatMenuPosition.left
                }}
                onClick={(e) => e.stopPropagation()}
              >
                {getRepeatOptions().map((option, index) => (
                  <div
                    key={index}
                    className="date-picker-repeat-item"
                    onClick={() => handleRepeatSelect(option)}
                  >
                    <span className="repeat-item-label">{option.label}</span>
                    {option.hint && <span className="repeat-item-hint">{option.hint}</span>}
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}

      {/* 時間選擇對話框 */}
      <TimePickerDialog
        isOpen={showTimeDialog}
        onClose={() => setShowTimeDialog(false)}
        value={timeValue}
        onChange={(time) => {
          setInternalTimeValue(time);
          if (onTimeChange) {
            onTimeChange(time);
          }
          // 同步更新 repeat 中的時間
          if (repeatValue) {
            const updatedRepeat = { ...repeatValue, timeOfDay: time || undefined };
            if (!time) delete updatedRepeat.timeOfDay;
            setInternalRepeatValue(updatedRepeat);
            if (onRepeatChange) {
              onRepeatChange(updatedRepeat);
            }
          }
        }}
      />
    </div>
  );
};

export default DatePickerDropdown;

