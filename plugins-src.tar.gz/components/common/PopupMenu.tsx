import React, { useEffect, useRef, useLayoutEffect } from 'react';
import { createPortal } from 'react-dom';
import { useIsMobileView } from '../../hooks/useWindowSize';
import './PopupMenu.css';
import { useCommandManager } from '../../Store/commandManager';
import i18n from '../../i18n/config';

interface PopupMenuProps {
  x: number;
  y: number;
  onClose: () => void;
  className?: string;
  children?: React.ReactNode;
  title?: string;
}

function PopupMenu({ x, y, onClose, className = '', children, title = '' }: PopupMenuProps) {
  const menuRef = useRef(null);
  const isMobileView = useIsMobileView();

  // 桌面版：螢幕下 1/3 往上展開
  useLayoutEffect(() => {
    if (!menuRef.current || isMobileView) return;

    const menu = menuRef.current;
    const menuRect = menu.getBoundingClientRect();
    const screenHeight = window.innerHeight;
    const screenWidth = window.innerWidth;

    let finalY = y;
    if (y > screenHeight * 2 / 3) {
      finalY = y - menuRect.height;
    }
    finalY = Math.max(8, Math.min(finalY, screenHeight - menuRect.height - 8));

    let finalX = x;
    if (x + menuRect.width > screenWidth) {
      finalX = screenWidth - menuRect.width - 8;
    }
    finalX = Math.max(8, finalX);

    menu.style.top = `${finalY}px`;
    menu.style.left = `${finalX}px`;
  }, [x, y, isMobileView]);

  // ESC 關閉 — commandManager 統一管理
  useEffect(() => {
    const unsub = useCommandManager.getState().register({
      command: {
        id: `popupmenu-escape-${Date.now()}`,
        name: i18n.t('cmd.closeMenu'),
        callback: () => onClose(),
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [onClose]);

  // 手機版：底部 panel 形式
  if (isMobileView) {
    return createPortal(
      <>
        <div className="popup-menu-mobile-overlay" onClick={onClose} />
        <div className="popup-menu-mobile-panel">
          {title && <div className="popup-menu-mobile-title">{title}</div>}
          <div className="popup-menu-mobile-content custom-scrollbar-wrapper">
            {children}
          </div>
          <div className="popup-menu-mobile-safe-area" />
        </div>
      </>,
      document.body
    );
  }

  // 桌面版：浮動選單
  return createPortal(
    <>
      <div className="popup-menu-overlay" onClick={onClose} />
      <div
        ref={menuRef}
        className={`popup-menu ${className}`}
        style={{ left: x, top: y }}
      >
        {children}
      </div>
    </>,
    document.body
  );
}

/**
 * PopupMenuItem - 選單項目
 */
function PopupMenuItem({ icon = null, children, onClick, danger = false }) {
  const renderIcon = () => {
    if (!icon) return null;
    if (React.isValidElement(icon)) return <span className="popup-menu-icon">{icon}</span>;
    const Icon = icon as React.ComponentType<{ className?: string }>;
    return <Icon className="popup-menu-icon" />;
  };

  return (
    <div
      className={`popup-menu-item ${danger ? 'popup-menu-item--danger' : ''}`}
      onClick={onClick}
    >
      {renderIcon()}
      {children}
    </div>
  );
}

/**
 * PopupMenuDivider - 分隔線
 */
function PopupMenuDivider() {
  return <div className="popup-menu-divider" />;
}

export { PopupMenu, PopupMenuItem, PopupMenuDivider };
export default PopupMenu;

