import React from 'react';
import './BreathingDot.css';

/**
 * 呼吸紅點組件 - 用於顯示未讀/新項目指示器
 * @param {string} className - 額外的 CSS class（用於定位）
 */
const BreathingDot = ({ className = '' }) => {
  return (
    <div className={`breathing-dot ${className}`} />
  );
};

export default BreathingDot;

