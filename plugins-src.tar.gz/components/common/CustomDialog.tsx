import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useIsMobileView } from '../../hooks/useWindowSize';
import './CustomDialog.css';
import ArrowLeftIcon from '../../assets/icon_arrow_left_24.svg?react';
import CloseIcon from '../../assets/icon_close_24.svg?react';
import { useCommandManager } from '../../Store/commandManager';

interface CustomDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  className?: string;
  showCloseButton?: boolean;
  onBack?: (() => void) | null;
  headerActions?: React.ReactNode;
  disableBackdropClose?: boolean;
  children?: React.ReactNode;

  /** Enter 確認回呼。傳入後自動註冊 Enter 快捷鍵 + 渲染確認按鈕 */
  onConfirm?: () => void;
  /** 確認按鈕文字（預設 t('confirm')） */
  confirmLabel?: string;
  /** 是否顯示取消按鈕（預設 true，只在 onConfirm 存在時生效） */
  showCancel?: boolean;
  /**
   * 覆蓋 Escape 預設行為。
   * 回傳 true = 已處理（不呼叫 onClose）；回傳 false = 未處理（交給 onClose）。
   */
  onEscapeOverride?: () => boolean;
  /** 是否自動聚焦第一個 input/textarea（預設 true） */
  autoFocus?: boolean;
}

export const CustomDialog = ({
  isOpen,
  onClose,
  title = '',
  className = '',
  showCloseButton = true,
  onBack = null,
  headerActions = null,
  disableBackdropClose = false,
  children,
  onConfirm,
  confirmLabel,
  showCancel = true,
  onEscapeOverride,
  autoFocus = true,
}: CustomDialogProps) => {
  const { t } = useTranslation();
  const isMobileView = useIsMobileView();
  const dialogRef = useRef(null);

  // ESC 關閉 — 用 commandManager 統一管理（支援 onEscapeOverride）
  const dialogIdRef = useRef(`customdialog-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`);
  useEffect(() => {
    if (!isOpen) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: `${dialogIdRef.current}:escape`,
        name: 'Close Dialog',
        callback: () => {
          if (onEscapeOverride) {
            if (onEscapeOverride()) return;
          }
          onClose();
        },
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [isOpen, onClose, onEscapeOverride]);

  // Enter 確認 — 僅在 onConfirm 存在時註冊（textarea 內不攔截）
  useEffect(() => {
    if (!isOpen || !onConfirm) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: `${dialogIdRef.current}:confirm`,
        name: 'Confirm Dialog',
        checkCallback: (checking: boolean) => {
          if (document.activeElement instanceof HTMLTextAreaElement) return false;
          if (!checking) onConfirm();
          return true;
        },
      },
      hotkeys: [{ modifiers: [], key: 'Enter' }],
    });
    return unsub;
  }, [isOpen, onConfirm]);

  // 自動聚焦第一個 input/textarea
  // 移動端需要在打開 Dialog 的按鈕點擊處先調用 window.focusHiddenInput() 打開鍵盤
  useEffect(() => {
    if (!isOpen || !autoFocus) return;

    // 使用 setTimeout 確保 DOM 完全渲染
    const timer = setTimeout(() => {
      if (dialogRef.current) {
        const focusableEl = dialogRef.current.querySelector('input:not([type="hidden"]), textarea');
        if (focusableEl) {
          focusableEl.focus();
        }
      }
    }, 50);

    return () => clearTimeout(timer);
  }, [isOpen, autoFocus]);

  if (!isOpen) return null;

  // 處理遮罩點擊
  const handleBackdropClick = () => {
    if (!disableBackdropClose) {
      onClose();
    }
  };

  // onConfirm 存在時自動渲染 actions
  const actionsNode = onConfirm ? (
    <div className="custom-dialog-buttons">
      {showCancel && (
        <button className="custom-secondary-button" onClick={onClose}>
          {t('cancel')}
        </button>
      )}
      <button className="custom-primary-button" onClick={onConfirm}>
        {confirmLabel || t('confirm')}
      </button>
    </div>
  ) : null;

  // 手機版：底部 panel 形式
  if (isMobileView) {
    return createPortal(
      <>
        <div className="custom-dialog-mobile-overlay" onClick={handleBackdropClick} />
        <div ref={dialogRef} className={`custom-dialog-mobile-panel ${className}`}>
          {/* 關閉按鈕獨立絕對定位 */}
          {showCloseButton && (
            <button className="custom-dialog-mobile-close" onClick={onClose}>
              <CloseIcon />
            </button>
          )}
          {/* Header 只在有 title / headerActions / onBack 時顯示 */}
          {(title || headerActions || onBack) && (
            <div className={`custom-dialog-mobile-header ${onBack ? 'has-back' : ''}`}>
              {onBack && (
                <button className="custom-dialog-mobile-back" onClick={onBack}>
                  <ArrowLeftIcon />
                </button>
              )}
              {title && <div className="custom-dialog-mobile-title">{title}</div>}
              {headerActions && (
                <div className="custom-dialog-mobile-header-actions">
                  {headerActions}
                </div>
              )}
            </div>
          )}
          <div className="custom-dialog-mobile-content custom-scrollbar-wrapper">
            {children}
            {actionsNode}
          </div>
          <div className="custom-dialog-mobile-safe-area" />
        </div>
      </>,
      document.body
    );
  }

  // 桌面版：居中對話框
  return createPortal(
    <div className="custom-dialog-overlay" onClick={handleBackdropClick}>
      <div
        ref={dialogRef}
        className={`custom-dialog-content ${className}`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* 關閉按鈕獨立絕對定位 */}
        {showCloseButton && (
          <button className="custom-dialog-close" onClick={onClose}>
            ×
          </button>
        )}
        {/* Header 只處理 title 和 headerActions */}
        {(title || headerActions) && (
          <div className="custom-dialog-header">
            {title && <h3 className="custom-dialog-title">{title}</h3>}
            {headerActions && (
              <div className="custom-dialog-header-actions">
                {headerActions}
              </div>
            )}
          </div>
        )}
        {children}
        {actionsNode}
      </div>
    </div>,
    document.body
  );
};

export default CustomDialog;
