import React, { useEffect, useRef } from 'react';
import { useNotificationStore } from '../../Store/notificationStore';
import BreathingDot from './BreathingDot';
import BellIcon from '../../assets/icon_bell_24.svg?react';
import './Notification.css';

/**
 * 通知鈴鐺按鈕（純觸發器）
 * 面板由 overlayStore 的 notificationPanel 統一渲染，這裡只負責按鈕 + 定位資訊
 */
const NotificationBell = () => {
  const unreadCount = useNotificationStore(s => s.unreadCount);
  const togglePanel = useNotificationStore(s => s.togglePanel);
  const setAnchorRect = useNotificationStore(s => s.setAnchorRect);
  const fetchNotifications = useNotificationStore(s => s.fetchNotifications);
  const btnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    fetchNotifications();
  }, []);

  useEffect(() => {
    if (window.electronAPI?.onPushNotificationReceived) {
      const unsubscribe = window.electronAPI.onPushNotificationReceived((notification: any) => {
        useNotificationStore.getState().handlePushNotification(notification);
      });
      return typeof unsubscribe === 'function' ? unsubscribe : undefined;
    }
  }, []);

  const handleClick = () => {
    if (btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setAnchorRect({ top: rect.top, left: rect.left, bottom: rect.bottom, right: rect.right });
    }
    togglePanel();
  };

  return (
    <div className="notification-bell-wrapper">
      <button
        ref={btnRef}
        className="custom-toolbar-button"
        onClick={handleClick}
        title="通知"
        tabIndex={-1}
      >
        <BellIcon />
      </button>
      {unreadCount > 0 && <BreathingDot />}
    </div>
  );
};

export default NotificationBell;
