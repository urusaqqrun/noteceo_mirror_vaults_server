import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import './BasicComponents.css';
import SearchIcon from '../../assets/icon_search_24.svg?react';
import FolderTreeSelect from './FolderTreeSelect';
import { CustomDialog } from './CustomDialog';

// 重新導出 CustomDialog 方便使用
export { CustomDialog } from './CustomDialog';

interface SegmentControlProps {
  segments: string[];
  activeIndex: number;
  onChange: (index: number) => void;
}

export const SegmentControl = ({ segments, activeIndex, onChange }: SegmentControlProps) => {
  return (
    <div className="base-segment-control">
      {segments.map((segment, index) => (
        <button
          key={index}
          className={`base-segment-button ${activeIndex === index ? 'active' : ''}`}
          onClick={() => onChange(index)}
        >
          {segment}
        </button>
      ))}
    </div>
  );
};

interface SearchBarProps {
  placeholder?: string;
  value?: string;
  onChange?: (e: any) => void;
  onKeyDown?: (e: any) => void;
  onCompositionStart?: (e: React.CompositionEvent) => void;
  onCompositionEnd?: (e: React.CompositionEvent) => void;
  className?: string;
  readOnly?: boolean;
  autoFocus?: boolean;
}

export const SearchBar = React.forwardRef<any, SearchBarProps>(({
  placeholder,
  value = "",
  onChange,
  onCompositionStart,
  onCompositionEnd,
  className = "",
  readOnly = false,
  autoFocus = false
}, ref) => {
  const { t } = useTranslation();
  const inputRef = useRef(null);

  // 將 ref 暴露給父組件
  React.useImperativeHandle(ref, () => ({
    focus: () => inputRef.current?.focus()
  }));

  const handleClear = (e) => {
    e.stopPropagation();
    const event = {
      target: { value: '' }
    };
    onChange(event);
  };

  return (
    <div className={`search-bar ${className}`}>
      <SearchIcon className="search-icon" />
      <input
        ref={inputRef}
        type="text"
        placeholder={placeholder || t('searchPlaceholder')}
        value={value}
        onChange={onChange}
        onCompositionStart={onCompositionStart}
        onCompositionEnd={onCompositionEnd}
        className="search-input"
        readOnly={readOnly}
        autoFocus={autoFocus}
      />
      {value && (
        <button
          className="search-clear-button"
          onClick={handleClear}
          type="button"
        >
          ×
        </button>
      )}
    </div>
  );
});

export interface TabItem {
  key: string;
  label: string;
  icon?: React.ReactNode;
}

interface TabsProps {
  tabs: TabItem[];
  activeKey: string;
  onChange: (key: string) => void;
  className?: string;
}

export const Tabs = ({ tabs, activeKey, onChange, className = '' }: TabsProps) => {
  return (
    <div className={`base-tabs ${className}`}>
      {tabs.map((tab) => (
        <button
          key={tab.key}
          className={`base-tab ${activeKey === tab.key ? 'active' : ''}`}
          onClick={() => onChange(tab.key)}
        >
          {tab.icon && <span className="base-tab-icon">{tab.icon}</span>}
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

interface FolderSelectDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (folderId: string) => void;
  title?: string;
  types?: string[];
  showInbox?: boolean;
}

// 資料夾選擇 Dialog
export const FolderSelectDialog = ({
  isOpen,
  onClose,
  onSelect,
  title,
  types = ['NOTE'],
  showInbox = true
}: FolderSelectDialogProps) => {
  const { t } = useTranslation();

  const handleSelect = (folderId) => {
    onSelect(folderId);
    onClose();
  };

  return (
    <CustomDialog
      isOpen={isOpen}
      onClose={onClose}
      title={title || t('saveNoteTo')}
      className="folder-select-dialog"
    >
      <div className="folder-select-dialog-list">
        <FolderTreeSelect
          mode="selector"
          types={types}
          onChange={handleSelect}
          showCount={false}
          showInbox={showInbox}
          showTrash={false}
        />
      </div>
      <div className="custom-dialog-buttons">
        <button className="custom-secondary-button" onClick={onClose}>
          {t('cancel')}
        </button>
      </div>
    </CustomDialog>
  );
}; 