import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import './TimePickerDialog.css';
import ClockIcon from '../../assets/category/clock.svg?react';

/**
 * TimePickerDialog - 時間選擇對話框
 * 
 * @param {boolean} isOpen - 是否開啟
 * @param {Function} onClose - 關閉回調
 * @param {string} value - 當前時間值 (HH:mm 格式)
 * @param {Function} onChange - 時間變更回調 (timeStr) => void
 */
const TimePickerDialog = ({
  isOpen,
  onClose,
  value,
  onChange
}) => {
  const { t } = useTranslation();
  const [inputValue, setInputValue] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [dropdownPosition, setDropdownPosition] = useState({ top: 0, left: 0, width: 0 });
  const [hasEdited, setHasEdited] = useState(false); // 追蹤是否已開始輸入修改
  const inputRef = useRef(null);
  const inputWrapperRef = useRef(null);

  // 計算第一個時間選項（下一個 15 分鐘）
  const getDefaultTime = () => {
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();
    const nextSlot = Math.ceil((currentMinutes + 1) / 15) * 15;
    const totalMinutes = nextSlot % (24 * 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
  };

  // 生成所有 15 分鐘間隔的時間選項，從當前時間的下一個開始
  const timeOptions = useMemo(() => {
    const options = [];
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    // 計算下一個 15 分鐘的時間點
    const nextSlot = Math.ceil((currentMinutes + 1) / 15) * 15;

    // 生成 24 小時的時間選項（從下一個時間點開始，循環回來）
    for (let i = 0; i < 96; i++) {
      const totalMinutes = (nextSlot + i * 15) % (24 * 60);
      const hours = Math.floor(totalMinutes / 60);
      const minutes = totalMinutes % 60;
      const timeStr = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
      options.push(timeStr);
    }

    return options;
  }, []);

  // 過濾時間選項（只有開始輸入修改後才過濾）
  const filteredOptions = useMemo(() => {
    if (!hasEdited) return timeOptions;
    if (!inputValue) return timeOptions;
    const searchValue = inputValue.replace(':', '');
    return timeOptions.filter(time => {
      const timeWithoutColon = time.replace(':', '');
      return timeWithoutColon.startsWith(searchValue) || time.startsWith(inputValue);
    });
  }, [inputValue, timeOptions, hasEdited]);

  // 當 dialog 開啟時，設定預設值
  useEffect(() => {
    if (isOpen) {
      const defaultTime = value || getDefaultTime();
      setInputValue(defaultTime);
      setShowDropdown(false);
      setHasEdited(false);
    }
  }, [isOpen, value]);

  // 處理輸入變更
  const handleInputChange = (e) => {
    let val = e.target.value;
    // 自動格式化：如果輸入 4 個數字，自動加入冒號
    if (val.length === 4 && !val.includes(':')) {
      val = val.slice(0, 2) + ':' + val.slice(2);
    }
    setInputValue(val);
    setHasEdited(true); // 開始輸入修改
  };

  // 處理 focus
  const handleFocus = () => {
    if (inputWrapperRef.current) {
      const rect = inputWrapperRef.current.getBoundingClientRect();
      setDropdownPosition({
        top: rect.bottom + 4,
        left: rect.left,
        width: rect.width
      });
    }
    setShowDropdown(true);
  };

  // 處理 blur（延遲關閉以允許點擊選項）
  const handleBlur = () => {
    setTimeout(() => {
      setShowDropdown(false);
    }, 150);
  };

  // 處理選擇時間
  const handleSelectTime = (time) => {
    setInputValue(time);
    onChange(time);
    setShowDropdown(false);
    onClose();
  };

  // 處理確認
  const handleConfirm = () => {
    if (filteredOptions.length > 0) {
      handleSelectTime(filteredOptions[0]);
    } else {
      // 沒有符合的選項，恢復為預設值
      const defaultTime = getDefaultTime();
      handleSelectTime(defaultTime);
    }
  };

  // 處理按下 Enter
  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleConfirm();
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="time-picker-dialog-overlay" onClick={onClose}>
        <div className="time-picker-dialog" onClick={(e) => e.stopPropagation()}>
          <div className="time-picker-dialog-header">
            <ClockIcon className="time-picker-dialog-icon" />
            <span>{t('time')}</span>
          </div>

          <div className="time-picker-dialog-content">
            <div className="time-picker-input-wrapper" ref={inputWrapperRef}>
              <input
                ref={inputRef}
                type="text"
                className="time-picker-input"
                placeholder="HH:mm"
                value={inputValue}
                onChange={handleInputChange}
                onFocus={handleFocus}
                onBlur={handleBlur}
                onKeyDown={handleKeyDown}
              />
            </div>
          </div>

          <div className="time-picker-dialog-footer">
            <button className="time-picker-btn-cancel" onClick={onClose}>
              {t('cancel')}
            </button>
            <button className="time-picker-btn-confirm" onClick={handleConfirm}>
              {t('confirm')}
            </button>
          </div>
        </div>
      </div>

      {/* 獨立的下拉選單 */}
      {showDropdown && (
        <div
          className="time-picker-dropdown"
          style={{
            position: 'fixed',
            top: dropdownPosition.top,
            left: dropdownPosition.left,
            width: dropdownPosition.width,
            zIndex: 1001
          }}
        >
          {filteredOptions.length > 0 ? (
            filteredOptions.map((time) => (
              <div
                key={time}
                className={`time-picker-option ${time === inputValue ? 'selected' : ''}`}
                onMouseDown={(e) => {
                  e.preventDefault();
                  handleSelectTime(time);
                }}
              >
                {time}
              </div>
            ))
          ) : (
            <div className="time-picker-no-options">
              {t('noMatchingTime')}
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default TimePickerDialog;
