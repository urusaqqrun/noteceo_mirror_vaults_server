import React from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from './CustomDialog';
import { useDialogStore } from '../../Store/dialogStore';

const LoginDialog: React.FC = () => {
    const { t } = useTranslation();
    const show = useDialogStore(s => s.dialogs['login']?.show);
    const data = useDialogStore(s => s.dialogs['login']?.data);

    if (!show) return null;

    const message = data?.message;

    const goToLogin = () => {
        useDialogStore.getState().close('login');

        // 存 pendingPublicShare，登入後導回（pathname 可能是 /share/xxx、/app/share/xxx 或 /app/CARD_FOLDER/xxx）
        const pathname = window.location.pathname;
        if (pathname.includes('/share/')) {
            localStorage.setItem('pendingPublicShare', JSON.stringify({ pathname }));
        } else {
            const match = pathname.match(/\/([a-f0-9]{24})(?:$|\/)/);
            if (match) {
                localStorage.setItem('pendingPublicShare', JSON.stringify({ pathname: '/share/' + match[1] }));
            }
        }

        if (localStorage.getItem('isGuest') === 'true') {
            localStorage.removeItem('accessToken');
            localStorage.removeItem('refreshToken');
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('isGuest');
            localStorage.removeItem('local_UID');
            localStorage.removeItem('userData_local');
        }
        window.location.href = '/app/';
    };

    return (
        <CustomDialog
            isOpen={true}
            onClose={() => useDialogStore.getState().close('login')}
            title={t('loginDialogTitle')}
        >
            <div className="card-gallery-favorite-login-content">
                <p>{message}</p>
                <div className="card-gallery-favorite-login-buttons">
                    <button
                        className="custom-secondary-button"
                        onClick={() => useDialogStore.getState().close('login')}
                    >
                        {t('cancel')}
                    </button>
                    <button
                        className="custom-primary-button"
                        onClick={goToLogin}
                    >
                        {t('goToLogin')}
                    </button>
                </div>
            </div>
        </CustomDialog>
    );
};

export default LoginDialog;
