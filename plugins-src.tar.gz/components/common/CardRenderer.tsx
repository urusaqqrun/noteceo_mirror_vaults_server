import React, { useMemo, useRef, useEffect, useState, useCallback } from 'react';
import ReactDOM from 'react-dom';
import { useTranslation } from 'react-i18next';
import { useTempHintStore } from '../../Store/uiStore';
import { uploadFile } from '../../utils/fileUpload';
import { searchCardImage } from '../plugins/card/ai/cardAI';
import { getFirstTextFieldIndex } from '../../utils/cardFieldUtils';
import { CustomDialog } from './CustomDialog';
import DateRangeDialog from './DateRangeDialog';
import DateDialog from './DateDialog';
import './CardRenderer.css';

/**
 * 格式化欄位值（根據欄位類型）
 */
// 圖片佔位圖（保持尺寸，灰色背景且置中的相機 SVG，base64 內嵌）
const IMAGE_PLACEHOLDER = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNDAiIGhlaWdodD0iMjQwIiB2aWV3Qm94PSIwIDAgMjQwIDI0MCI+CiAgPHJlY3Qgd2lkdGg9IjI0MCIgaGVpZ2h0PSIyNDAiIHJ4PSIyNCIgZmlsbD0iI0U4RThFOCIvPgogIDxnIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzU1NSIgc3Ryb2tlLXdpZHRoPSI2IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiCiAgICAgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTIwIDEyMCkgc2NhbGUoMC43KSB0cmFuc2xhdGUoLTQwIC00NSkiPgogICAgPHJlY3QgeD0iMCIgeT0iMjAiIHdpZHRoPSI4MCIgaGVpZ2h0PSI1MCIgcng9IjYiLz4KICAgIDxyZWN0IHg9IjI0IiB5PSI1IiB3aWR0aD0iMzIiIGhlaWdodD0iMTIiIHJ4PSI0Ii8+CiAgICA8Y2lyY2xlIGN4PSI0MCIgY3k9IjQ1IiByPSIxOCIvPgogICAgPGNpcmNsZSBjeD0iNDAiIGN5PSI0NSIgcj0iNSIgZmlsbD0iIzU1NSIvPgogIDwvZz4KPC9zdmc+Cg==';

// 四捨五入到 0.5
const roundToHalf = (rating) => {
  return Math.round(rating * 2) / 2;
};

// 計算星星顯示狀態
// isAverage: true 時顯示平均評分（不加 personal class，opacity 0.7）
// isAverage: false 時顯示自己的評分（加 personal class，opacity 1）
const getStarClass = (rating, starIndex, isAverage) => {
  const personalClass = isAverage ? '' : 'personal';
  if (rating >= starIndex) return `filled ${personalClass}`.trim();
  if (rating >= starIndex - 0.5) return `half ${personalClass}`.trim();
  return personalClass; // 空星
};

interface FormatFieldValueOptions {
  isPreview?: boolean;
  fieldName?: string;
  fieldOptions?: any[];
  reviews?: Record<string, { rating?: any; comment?: string }> | null;
  currentMemberID?: string | null;
  ownerMemberID?: string | null;
}

export const formatFieldValue = (value: any, fieldType: string, options: FormatFieldValueOptions = {}) => {
  const {
    isPreview = false,
    fieldName = '',
    fieldOptions = [],
    // 評分系統新增參數
    reviews = null,           // 所有評分記錄 { memberID: { rating, comment } }
    currentMemberID = null,   // 當前用戶 ID
    ownerMemberID = null,     // 擁有者 ID
  } = options;

  switch (fieldType) {
    case 'RATING':
      // 解析評分值（處理 MongoDB Extended JSON 格式 {"$numberInt": "5"} 或普通數字/字串）
      const parseRating = (val) => {
        if (val == null) return 0;
        if (typeof val === 'number') return val;
        if (typeof val === 'string') return parseInt(val) || 0;
        if (typeof val === 'object' && val.$numberInt) return parseInt(val.$numberInt) || 0;
        return 0;
      };

      // 統一從 reviews 取得自己的評分
      let myRating = 0;
      if (reviews && currentMemberID && reviews[currentMemberID]?.rating) {
        myRating = parseRating(reviews[currentMemberID].rating);
      }

      // 統一從 reviews 計算平均評分
      const allRatings = [];
      if (reviews) {
        Object.values(reviews).forEach(r => {
          const ratingVal = parseRating(r?.rating);
          if (ratingVal > 0) allRatings.push(ratingVal);
        });
      }
      const averageRating = allRatings.length > 0
        ? allRatings.reduce((a, b) => a + b, 0) / allRatings.length
        : 0;
      const reviewCount = allRatings.length;

      // 決定顯示哪個評分
      // 新邏輯：有平均評分時預設顯示平均評分，hover 時才顯示自己的評分
      let displayRating;
      let isShowingAverage;

      if (isPreview) {
        displayRating = 4;
        isShowingAverage = false;
      } else if (averageRating > 0) {
        // 有評分時，預設顯示平均評分樣式（不加 personal class）
        displayRating = roundToHalf(averageRating);
        isShowingAverage = true;
      } else {
        // 沒有任何評分
        displayRating = 0;
        isShowingAverage = false;
      }

      // 生成可互動的星星 HTML
      let starsHtml = `<span class="card-rating-stars" 
        data-field-name="${fieldName}" 
        data-current-rating="${myRating}"
        data-average-rating="${averageRating.toFixed(2)}"
        data-review-count="${reviewCount}"
        data-is-average="${isShowingAverage}">`;

      for (let i = 1; i <= 5; i++) {
        const starClass = getStarClass(displayRating, i, isShowingAverage);
        const isFilled = starClass.includes('filled');
        const isHalf = starClass.includes('half');
        // 半星底層用空星 ☆，CSS ::after 會疊加半個實心星
        starsHtml += `<span class="card-rating-star ${starClass}" data-star-value="${i}">${isFilled ? '★' : '☆'}</span>`;
      }
      starsHtml += '</span>';
      return starsHtml;

    case 'BOOLEAN':
      return value === 'true' || value === true ? '是' : '否';

    case 'IMAGE':
      return value || IMAGE_PLACEHOLDER;

    case 'TAGS':
      // 將逗號分隔的標籤轉成多個 <span>
      if (!value) return isPreview ? '<span>標籤1</span><span>標籤2</span>' : '';
      const strValue = Array.isArray(value) ? value.join(', ') : String(value);
      const tags = strValue.split(/[,，、]\s*/).filter(t => t.trim());
      if (tags.length === 0) return '';
      return tags.map(tag => `<span>${tag.trim()}</span>`).join('');

    case 'TEXTAREA':
      // 將換行符轉為 <br>，並轉義 HTML 特殊字符
      if (!value) return '';
      return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br>');

    case 'DATE':
    case 'DATETIME':
      // 直接返回，格式為 YYYY/MM/DD 或 YYYY/MM/DD HH:MM
      return value || '';

    case 'DATERANGE':
      // 格式為 "YYYY/MM/DD ~ YYYY/MM/DD"
      // 如果開始和結束日期相同，只顯示一個
      if (!value) return '';
      const dates = String(value).split(' ~ ').map(d => d.trim());
      if (dates.length === 2 && dates[0] === dates[1]) {
        return dates[0];
      }
      return value;

    default:
      return value || '';
  }
};

/**
 * 生成範例數據（用於預覽）
 */
export const getSampleValue = (field) => {
  switch (field.type) {
    case 'TEXT':
      return `範例${field.name}`;
    case 'TEXTAREA':
      return `這是${field.name}的範例內容，可以包含多行文字。`;
    case 'NUMBER':
      return '123';
    case 'DATE':
      return '2024/01/15';
    case 'DATETIME':
      return '2024/01/15 14:30';
    case 'DATERANGE':
      return '2024/01/15 ~ 2024/01/20';
    case 'URL':
      return 'https://example.com';
    case 'EMAIL':
      return 'example@email.com';
    case 'PHONE':
      return '0912-345-678';
    case 'IMAGE':
      return IMAGE_PLACEHOLDER;
    case 'SELECT':
    case 'MULTISELECT':
      return field.options?.[0] || '選項1';
    case 'TAGS':
      return '標籤1, 標籤2';
    case 'BOOLEAN':
      return 'true';
    case 'RATING':
      return '4';
    case 'LOCATION':
      return '台北市信義區';
    default:
      return field.name;
  }
};

/**
 * 渲染卡片 HTML
 */
export const renderCardHtml = (templateHtml: any, fields: any, cardData: any, options: { isPreview?: boolean; currentMemberID?: string | null } = {}) => {
  const { isPreview = false, currentMemberID = null } = options;

  if (!templateHtml) return '';

  // fields 可能是 JSON 字串（從 SQLite 讀出），需要解析
  let parsedFields = fields;
  if (typeof fields === 'string') {
    try { parsedFields = JSON.parse(fields); } catch { parsedFields = []; }
  }

  // 解析 reviews（JSON 字串）
  let reviews = null;
  if (cardData?.reviews) {
    try {
      const rawReviews = cardData.reviews;
      reviews = typeof rawReviews === 'string'
        ? JSON.parse(rawReviews)
        : rawReviews;
    } catch (e) {

    }
  }

  let html = templateHtml;

  parsedFields?.forEach(field => {
    // 取得原始值
    let rawValue = isPreview
      ? getSampleValue(field)
      : (cardData?.cardFields?.[field.name] || '');

    // 格式化值（評分欄位需要額外參數）
    const formatOptions = {
      isPreview,
      fieldName: field.name,
      fieldOptions: field.options,
      // 評分系統參數
      reviews,
      currentMemberID,
      ownerMemberID: cardData?._permissions?.find((p: any) => p.permission === 'owner')?.user_id,
    };
    const formattedValue = formatFieldValue(rawValue, field.type, formatOptions);

    // 替換佔位符（用函數避免 $ 特殊字符問題）
    const doubleBraceRegex = new RegExp(`\\{\\{${field.name}\\}\\}`, 'g');
    const singleBraceRegex = new RegExp(`\\{${field.name}\\}`, 'g');
    html = html.replace(doubleBraceRegex, () => formattedValue);
    html = html.replace(singleBraceRegex, () => formattedValue);
  });

  return html;
};

/**
 * CardRenderer 組件
 * 統一渲染卡片模板，支援預覽模式和真實數據模式
 */
interface CardRendererProps {
  templateHtml?: any;
  templateCss?: any;
  fields?: any;
  cardData?: any;
  className?: string;
  onClick?: any;
  onContextMenu?: any;
  onFieldChange?: any;
  onReviewChange?: any;
  canEditThisCard?: any;
  canRate?: boolean;
  isLoggedIn?: boolean;
  onRequestLogin?: any;
  onRequestPermission?: any;
  currentMemberID?: string | null;
  children?: any;
  [key: string]: any;
}

function CardRenderer({
  templateHtml,
  templateCss,
  fields: fieldsProp,
  cardData = null,   // 真實卡片數據，null 表示預覽模式
  className = '',
  onClick,
  onContextMenu,
  onFieldChange,     // 欄位值改變時的 callback (fieldName, newValue)
  onReviewChange,    // 可選：共享者評分變更的 callback (rating) => void
  canEditThisCard,   // 可選：明確指定是否可以編輯此卡片（用於權限系統）
  canRate = false,   // 可選：是否可以評分（CONTRIBUTOR 以上）
  isLoggedIn = true, // 可選：是否已登入（未登入時「要求權限」變「登入」）
  onRequestLogin,    // 可選：點擊登入按鈕的 callback
  onRequestPermission, // 可選：點擊要求權限按鈕的 callback
  currentMemberID,   // 可選：當前用戶 ID，用於評分
  // 注意：avatarUrl, onAvatarClick, onBubbleClick 已移至 AvatarWithBubble 組件
  children,
  ...props
}: CardRendererProps) {
  const { t } = useTranslation();
  const setTempHint = useTempHintStore(state => state.setTempHint);

  // fields 可能是 JSON 字串（從 SQLite 讀出），統一解析為陣列
  const fields = useMemo(() => {
    if (typeof fieldsProp === 'string') {
      try { return JSON.parse(fieldsProp); } catch { return []; }
    }
    return fieldsProp || [];
  }, [fieldsProp]);

  const isPreview = !cardData;

  // 生成唯一的 scope class，避免不同卡片類型的 CSS 互相覆蓋
  const scopeId = useMemo(() => {
    if (cardData?.id) return `crs-${cardData.id}`;
    return `crs-${Math.random().toString(36).substr(2, 8)}`;
  }, [cardData?.id]);

  // 將 templateCss 的選擇器加上 scope 前綴
  const scopedCss = useMemo(() => {
    if (!templateCss) return '';

    let result = '';
    let remaining = templateCss;

    while (remaining.length > 0) {
      const openBrace = remaining.indexOf('{');
      if (openBrace === -1) break;

      const selector = remaining.substring(0, openBrace);
      const closeBrace = remaining.indexOf('}', openBrace);
      if (closeBrace === -1) break;

      const body = remaining.substring(openBrace, closeBrace + 1);
      remaining = remaining.substring(closeBrace + 1);

      // @ 規則（@media, @keyframes 等）保持原樣
      if (selector.trim().startsWith('@')) {
        result += selector + body;
        continue;
      }

      // 為逗號分隔的選擇器各加上 scope
      const scopedSelector = selector.split(',').map(s => {
        const t = s.trim();
        if (!t) return s;
        return `.${scopeId} ${t}`;
      }).join(', ');

      result += scopedSelector + body;
    }

    return result;
  }, [templateCss, scopeId]);

  // 判斷是否為他人的卡片（檢查 _permissions）
  // 優先使用 prop 傳入的 currentMemberID，否則從 localStorage 取得
  const resolvedCurrentMemberID = useMemo(() => {
    if (currentMemberID) return currentMemberID;
    const userData = JSON.parse(localStorage.getItem('userData_local') || '{}');
    return userData.ID || null;
  }, [currentMemberID]);

  // 注意：成員資訊的 fetch 已移至 AvatarWithBubble 組件

  // 如果明確傳入 canEditThisCard，使用它；否則使用 _permissions 比對邏輯
  const isOtherUserCard = useMemo(() => {
    if (canEditThisCard !== undefined) return !canEditThisCard;
    const myPerm = cardData?._permissions?.find((p: any) => p.user_id === resolvedCurrentMemberID);
    return myPerm && myPerm.permission !== 'owner';
  }, [canEditThisCard, cardData?._permissions, resolvedCurrentMemberID]);

  // 用 useMemo 避免不必要的 html 重新計算
  // 穩定化 cardData 的關鍵屬性，避免物件引用變化導致不必要的重新計算
  const cardDataFieldsJson = useMemo(() => JSON.stringify(cardData?.cardFields), [cardData?.cardFields]);
  const cardDataReviewsJson = useMemo(() => JSON.stringify(cardData?.reviews), [cardData?.reviews]);

  const html = useMemo(() => {
    return renderCardHtml(templateHtml, fields, cardData, { isPreview, currentMemberID: resolvedCurrentMemberID });
  }, [templateHtml, fields, cardDataFieldsJson, cardData?.id, cardDataReviewsJson, isPreview, resolvedCurrentMemberID]);

  const contentRef = useRef(null);

  // 建立可互動 field 值的映射（URL/EMAIL/PHONE/LOCATION 會開啟外部連結）
  const interactiveFields = useMemo(() => {
    if (isPreview || !cardData?.cardFields || !fields) return {};
    const map = {};
    fields.forEach(field => {
      if (['URL', 'EMAIL', 'PHONE', 'LOCATION'].includes(field.type)) {
        const value = cardData.cardFields?.[field.name];
        if (value) {
          map[value] = field.type;
        }
      }
    });
    return map;
  }, [isPreview, cardData, fields]);

  // 建立所有 field 值到 field 資訊的映射（用於點擊定位和下拉選單）
  const allFieldsMap = useMemo(() => {
    if (isPreview || !cardData?.cardFields || !fields) return {};
    const map = {};
    fields.forEach(field => {
      const value = cardData.cardFields?.[field.name];
      if (value) {
        // RATING 會被格式化成星星，需要特殊處理
        if (field.type === 'RATING') {
          const rating = parseInt(value) || 0;
          const formatted = '★'.repeat(rating) + '☆'.repeat(5 - rating);
          map[formatted] = { name: field.name, type: field.type, options: field.options };
        } else if (field.type === 'TAGS') {
          // TAGS 會被切成多個 span，需要把每個標籤都加入映射
          const strValue = Array.isArray(value) ? value.join(', ') : String(value);
          const tags = strValue.split(/[,，、]\s*/).filter(t => t.trim());
          tags.forEach(tag => {
            map[tag.trim()] = { name: field.name, type: field.type, options: field.options };
          });
        } else if (field.type === 'DATERANGE') {
          // DATERANGE 會被格式化，用格式化後的值作為 key
          const formatted = formatFieldValue(value, 'DATERANGE');
          map[formatted] = { name: field.name, type: field.type, options: field.options };
        } else {
          map[value] = { name: field.name, type: field.type, options: field.options };
        }
      }
    });
    return map;
  }, [isPreview, cardData, fields, html]);

  // SELECT 下拉選單狀態
  const [selectDropdown, setSelectDropdown] = useState(null); // { fieldName, options, x, y, currentValue }
  // MULTISELECT 下拉選單狀態
  const [multiselectDropdown, setMultiselectDropdown] = useState(null); // { fieldName, options, x, y, currentValues }
  // TEXT 編輯 dialog 狀態
  const [textEditDialog, setTextEditDialog] = useState(null); // { fieldName, currentValue }
  // 地址填寫提示 dialog 狀態
  const [addressPromptDialog, setAddressPromptDialog] = useState(null); // { destinationAddress }
  // DATE picker 開啟狀態
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);
  // DATE input 類型
  const [dateInputType, setDateInputType] = useState('date');
  // DATERANGE dialog 狀態
  const [dateRangeDialog, setDateRangeDialog] = useState(null); // { fieldName, startDate, endDate }
  // DATE/DATETIME dialog 狀態（手機版使用）
  const [dateDialog, setDateDialog] = useState(null); // { fieldName, fieldType, value }
  // IMAGE 上傳 dialog 狀態
  const [imageDialog, setImageDialog] = useState(null); // { fieldName, currentUrl, previewUrl, isUploading }
  // 要求權限 dialog 狀態
  const [permissionDialog, setPermissionDialog] = useState(null); // { message, onRequestPermission }

  // 隱藏的日期 input ref（用於直接觸發原生選擇器）
  const dateInputRef = useRef(null);
  const dateFieldRef = useRef(null); // 記錄當前操作的 field 資訊

  // 複製卡片資訊函數（用於分享模式）
  const copyCardInfo = useCallback(() => {
    if (!cardData?.cardFields || !fields) return;

    // 分類欄位
    let firstField = null;      // 第一個 TEXT/TEXTAREA 欄位（名稱）
    let ratingField = null;     // 評分欄位
    let locationField = null;   // 地址欄位
    let urlField = null;        // 連結欄位
    const otherFields = [];     // 其他欄位
    const firstTextFieldIndex = getFirstTextFieldIndex(fields);

    fields.forEach((field, index) => {
      const value = cardData.cardFields?.[field.name];
      if (value === undefined || value === null || value === '') return;

      // 跳過圖片欄位
      if (field.type === 'IMAGE') return;

      // 格式化值（處理特殊類型）
      let displayValue = value;
      if (field.type === 'BOOLEAN') {
        displayValue = value === 'true' || value === true ? t('yes') : t('no');
      } else if (field.type === 'RATING') {
        displayValue = '★'.repeat(parseInt(value) || 0);
      } else if (Array.isArray(value)) {
        displayValue = value.join(', ');
      }

      const fieldData = { field, displayValue: String(displayValue), value };

      if (index === firstTextFieldIndex && !firstField) {
        firstField = fieldData;
      } else if (field.type === 'RATING' && !ratingField) {
        ratingField = fieldData;
      } else if (field.type === 'LOCATION' && !locationField) {
        locationField = fieldData;
      } else if (field.type === 'URL' && !urlField) {
        urlField = fieldData;
      } else {
        otherFields.push(fieldData);
      }
    });

    // 組合輸出
    const lines = [];

    // 1. 第一個欄位（名稱）- 不帶前綴
    if (firstField) {
      lines.push(firstField.displayValue);
    }

    // 2. 評分 - 不帶前綴
    if (ratingField) {
      lines.push(ratingField.displayValue);
    }

    // 3. 地址 - 不帶前綴，後面加 Google Maps 連結
    if (locationField) {
      lines.push(locationField.displayValue);
      lines.push(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(locationField.value)}`);
    }

    // 4. 其他欄位 - 帶前綴
    otherFields.forEach(({ field, displayValue }) => {
      lines.push(`${field.name}:${displayValue}`);
    });

    // 5. 連結 - 放最後，不帶前綴
    if (urlField) {
      lines.push(urlField.displayValue);
    }

    if (lines.length > 0) {
      navigator.clipboard.writeText(lines.join('\n'));
      setTempHint(t('cardInfoCopied'));
    }
  }, [cardData, fields, setTempHint, t]);

  // 渲染後，遍歷 DOM 找到匹配 field 值的元素並添加點擊事件
  useEffect(() => {
    if (!contentRef.current || isPreview) return;

    // 處理可互動 field 的點擊（URL/EMAIL/PHONE/LOCATION）
    // 所有角色都保持原邏輯，無需權限檢查
    const handleInteractiveClick = (fieldType, fieldValue) => (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (fieldType === 'URL') {
        window.electronAPI?.openExternalLink(fieldValue);
      } else if (fieldType === 'EMAIL') {
        window.electronAPI?.openExternalLink(`mailto:${fieldValue}`);
      } else if (fieldType === 'PHONE') {
        window.electronAPI?.openExternalLink(`tel:${fieldValue}`);
      } else if (fieldType === 'LOCATION') {
        // 所有角色都直接打開 Google Maps
        // 檢查用戶是否設定了地址，用於導航起點
        const userDataLocal = localStorage.getItem('userData_local');
        const userData = userDataLocal ? JSON.parse(userDataLocal) : {};
        const userAddress = userData.address;

        if (userAddress) {
          // 有起點地址，使用導航模式（不編碼，直接使用中文地址）
          window.electronAPI?.openExternalLink(
            `https://www.google.com/maps/dir/${userAddress}/${fieldValue}`
          );
        } else {
          // 沒有起點地址，檢查是否已經提示過
          const hasPrompted = localStorage.getItem('hideAddressPrompt');

          if (!hasPrompted) {
            // 尚未提示過，顯示 dialog
            setAddressPromptDialog({ destinationAddress: fieldValue });
          } else {
            // 已經提示過，直接使用搜尋模式
            window.electronAPI?.openExternalLink(
              `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(fieldValue)}`
            );
          }
        }
      }
    };

    // 處理一般 field 的點擊（打開編輯 dialog 或下拉選單）
    // 所有角色都能打開 dialog，差別在於無權限時操作會被攔截
    const handleFieldClick = (fieldInfo, fieldValue) => (e) => {
      e.preventDefault();
      e.stopPropagation();

      // SELECT 類型：顯示下拉選單
      if (fieldInfo.type === 'SELECT' && fieldInfo.options?.length > 0) {
        const rect = e.target.getBoundingClientRect();
        // 簡單判斷：螢幕下半部往上長，否則往下長
        const shouldOpenUpward = rect.top > window.innerHeight / 2;

        setSelectDropdown({
          fieldName: fieldInfo.name,
          options: fieldInfo.options,
          x: rect.left,
          y: shouldOpenUpward ? undefined : rect.bottom + 4,
          bottom: shouldOpenUpward ? window.innerHeight - rect.top + 4 : undefined,
          currentValue: fieldValue,
          openUpward: shouldOpenUpward
        });
        return;
      }

      // MULTISELECT 類型：顯示多選選單
      if (fieldInfo.type === 'MULTISELECT' && fieldInfo.options?.length > 0) {
        const rect = e.target.getBoundingClientRect();
        // 支援英文逗號、中文逗號、中文頓號
        const currentValues = fieldValue ? fieldValue.split(/[,，、]/).map(s => s.trim()).filter(Boolean) : [];
        // 簡單判斷：螢幕下半部往上長，否則往下長
        const shouldOpenUpward = rect.top > window.innerHeight / 2;

        setMultiselectDropdown({
          fieldName: fieldInfo.name,
          options: fieldInfo.options,
          x: rect.left,
          y: shouldOpenUpward ? undefined : rect.bottom + 4,
          bottom: shouldOpenUpward ? window.innerHeight - rect.top + 4 : undefined,
          currentValues: currentValues,
          openUpward: shouldOpenUpward
        });
        return;
      }

      // DATERANGE 類型：打開日期範圍 dialog
      if (fieldInfo.type === 'DATERANGE') {
        // 解析現有值，格式為 "YYYY/MM/DD ~ YYYY/MM/DD"
        let startDate = '';
        let endDate = '';
        const rawValue = cardData?.cardFields?.[fieldInfo.name] || '';
        if (rawValue) {
          const parts = rawValue.split(' ~ ').map(s => s.trim());
          // date input 需要 YYYY-MM-DD 格式
          startDate = (parts[0] || '').replace(/\//g, '-');
          endDate = (parts[1] || '').replace(/\//g, '-');
        }
        setDateRangeDialog({
          fieldName: fieldInfo.name,
          startDate,
          endDate
        });
        return;
      }

      // DATE/DATETIME 類型：手機版使用 Dialog，桌面版使用原生選擇器
      if (fieldInfo.type === 'DATE' || fieldInfo.type === 'DATETIME') {
        const isMobile = window.innerWidth <= 768;

        if (isMobile) {
          // 手機版：使用 Dialog
          setDateDialog({
            fieldName: fieldInfo.name,
            fieldType: fieldInfo.type,
            value: fieldValue
          });
        } else {
          // 桌面版：使用原生日期選擇器
          const rect = e.target.getBoundingClientRect();
          dateFieldRef.current = {
            name: fieldInfo.name,
            type: fieldInfo.type,
            value: fieldValue,
            rect
          };
          const newType = fieldInfo.type === 'DATE' ? 'date' : 'datetime-local';
          setDateInputType(newType);
          setIsDatePickerOpen(true);
        }
        return;
      }

      onClick?.(e, fieldInfo.name);
    };

    const addedListeners = [];

    // 檢測是否為裝飾性覆蓋層（position: absolute 且覆蓋整個父容器，沒有實際內容）
    const isDecorativeOverlay = (node) => {
      if (node.tagName === 'IMG' || node.tagName === 'A' || node.tagName === 'BUTTON' || node.tagName === 'INPUT') {
        return false; // 可互動元素不是裝飾層
      }

      const style = window.getComputedStyle(node);
      if (style.position !== 'absolute') return false;

      // 檢查是否覆蓋整個父容器（top/left/right/bottom 都是 0 或接近 0）
      const top = parseInt(style.top) || 0;
      const left = parseInt(style.left) || 0;
      const right = parseInt(style.right) || 0;
      const bottom = parseInt(style.bottom) || 0;

      const isFullCover = (
        style.top !== 'auto' && style.left !== 'auto' &&
        style.right !== 'auto' && style.bottom !== 'auto' &&
        top === 0 && left === 0 && right === 0 && bottom === 0
      );

      if (!isFullCover) return false;

      // 檢查是否沒有實際內容（沒有可互動子元素）
      const hasInteractiveChild = node.querySelector('img, a, button, input, textarea, select, [onclick]');
      if (hasInteractiveChild) return false;

      // 檢查是否只有空白文字
      const textContent = node.textContent?.trim() || '';
      if (textContent.length > 0) return false;

      return true;
    };

    // 遍歷所有元素
    const walkDOM = (node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        // 檢測裝飾性覆蓋層，設置 pointer-events: none 讓點擊穿透
        if (isDecorativeOverlay(node)) {
          node.style.pointerEvents = 'none';
        }

        // 處理評分星星容器：添加統計文字和事件
        if (node.classList?.contains('card-rating-stars')) {
          const reviewCount = parseInt(node.dataset.reviewCount) || 0;
          const averageRating = parseFloat(node.dataset.averageRating) || 0;

          // 設置星星樣式
          const stars = node.querySelectorAll('.card-rating-star');
          stars.forEach(star => {
            star.style.cursor = 'pointer';
            star.style.pointerEvents = 'auto';
          });
          node.style.pointerEvents = 'auto';

          // 添加統計文字
          if (reviewCount >= 2 && averageRating > 0) {
            // 計算統計文字應該放在哪邊
            requestAnimationFrame(() => {
              const containerRect = node.getBoundingClientRect();
              const parent = node.closest('.card-renderer') || node.parentElement;
              if (!parent) return;

              const parentRect = parent.getBoundingClientRect();
              const rightSpace = parentRect.right - containerRect.right;
              const leftSpace = containerRect.left - parentRect.left;
              const minSpace = 45;

              let position = null;
              if (rightSpace >= minSpace) {
                position = 'right';
              } else if (leftSpace >= minSpace) {
                position = 'left';
              }

              if (position) {
                // 檢查是否已經有統計文字
                const existingStats = position === 'right'
                  ? node.nextElementSibling
                  : node.previousElementSibling;

                if (existingStats?.classList?.contains('card-rating-stats')) {
                  // 已存在，只更新內容
                  existingStats.textContent = `${averageRating.toFixed(1)}(${reviewCount})`;

                } else {
                  // 創建新的統計文字
                  const statsEl = document.createElement('span');
                  statsEl.className = `card-rating-stats position-${position}`;
                  statsEl.textContent = `${averageRating.toFixed(1)}(${reviewCount})`;

                  if (position === 'right') {
                    node.after(statsEl);
                  } else {
                    node.before(statsEl);
                  }

                }
              }
            });
          }
        }

        // 檢查 href 屬性（可互動）
        const href = node.getAttribute?.('href');
        if (href && interactiveFields[href]) {
          const handler = handleInteractiveClick(interactiveFields[href], href);
          node.addEventListener('click', handler);
          node.classList.add('card-interactive-field');
          addedListeners.push({ node, handler });
        }

        // 檢查 <img> 元素（IMAGE 類型欄位）
        if (node.tagName === 'IMG') {
          node.referrerPolicy = 'no-referrer';
          const imgSrc = node.getAttribute('src');

          // 圖片加載失敗時，顯示預設佔位圖
          const errorHandler = () => {
            if (node.src !== IMAGE_PLACEHOLDER) {
              node.src = IMAGE_PLACEHOLDER;
            }
          };
          node.addEventListener('error', errorHandler);
          addedListeners.push({ node, handler: errorHandler, eventType: 'error' });

          // 找到對應的 IMAGE 類型欄位
          // 1. 如果 imgSrc 匹配欄位值，使用該欄位
          // 2. 如果 imgSrc 是佔位圖，找沒有值的 IMAGE 欄位
          let imageField = fields?.find(f => f.type === 'IMAGE' && cardData?.cardFields?.[f.name] === imgSrc);
          if (!imageField && imgSrc === IMAGE_PLACEHOLDER) {
            imageField = fields?.find(f => f.type === 'IMAGE' && !cardData?.cardFields?.[f.name]);
          }
          if (imageField) {
            const currentUrl = cardData?.cardFields?.[imageField.name] || '';
            const imageClickHandler = (e) => {
              e.preventDefault();
              e.stopPropagation();
              // 所有角色都能打開 dialog，無權限時按鈕會被替換
              setImageDialog({
                fieldName: imageField.name,
                currentUrl: currentUrl,
                previewUrl: imgSrc,
                isUploading: false,
                isReadOnly: isOtherUserCard  // 無權限時標記為只讀
              });
            };
            node.addEventListener('click', imageClickHandler);
            node.classList.add('card-image-field');
            addedListeners.push({ node, handler: imageClickHandler });
          }

          // 注意：Avatar 顯示已移至獨立的 AvatarWithBubble 組件
          // CardRenderer 不再負責創建 avatar DOM
        }

        // 檢查是否為葉節點（只包含文字和 br）
        const isLeafNode = () => {
          if (node.childNodes.length === 0) return false;
          for (const child of node.childNodes) {
            if (child.nodeType === Node.TEXT_NODE) continue;
            if (child.nodeType === Node.ELEMENT_NODE && child.tagName === 'BR') continue;
            return false;
          }
          return true;
        };

        if (isLeafNode()) {
          // 取得原始文字（將 <br> 還原為 \n）
          const text = node.innerHTML
            ?.replace(/<br\s*\/?>/gi, '\n')
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>')
            .replace(/&amp;/g, '&')
            .trim();

          // 可互動 field
          if (text && interactiveFields[text]) {
            const handler = handleInteractiveClick(interactiveFields[text], text);
            node.addEventListener('click', handler);
            node.classList.add('card-interactive-field');
            addedListeners.push({ node, handler });
          }
          // 一般 field（打開編輯或下拉選單）
          else if (text && allFieldsMap[text]) {
            const fieldInfo = allFieldsMap[text];
            const handler = handleFieldClick(fieldInfo, text);

            // 根據類型添加不同樣式和行為
            if (fieldInfo.type === 'SELECT' || fieldInfo.type === 'MULTISELECT' || fieldInfo.type === 'DATE' || fieldInfo.type === 'DATETIME' || fieldInfo.type === 'DATERANGE') {
              node.addEventListener('click', handler);
              node.classList.add('card-select-field');
              addedListeners.push({ node, handler });
            } else if (fieldInfo.type === 'TEXT') {
              // 單行文字：整個區域可點擊
              node.classList.add('card-editable-field');
              const textEditHandler = (e) => {
                e.preventDefault();
                e.stopPropagation();
                // 所有角色都能打開 dialog，無權限時輸入框灰掉
                setTextEditDialog({
                  fieldName: fieldInfo.name,
                  currentValue: text,
                  isReadOnly: isOtherUserCard
                });
              };
              node.addEventListener('click', textEditHandler);
              addedListeners.push({ node, handler: textEditHandler });
            } else if (fieldInfo.type === 'TEXTAREA') {
              // 多行文字：整個區域可點擊，hover 顯示編輯 icon
              node.classList.add('card-editable-field');
              const textEditHandler = (e) => {
                e.preventDefault();
                e.stopPropagation();
                // 所有角色都能打開 dialog，無權限時輸入框灰掉
                setTextEditDialog({
                  fieldName: fieldInfo.name,
                  currentValue: text,
                  isTextarea: true,
                  isReadOnly: isOtherUserCard
                });
              };
              node.addEventListener('click', textEditHandler);
              // 桌面版才顯示編輯 icon（手機版不需要 hover 效果）
              if (window.innerWidth > 768) {
                const editIcon = document.createElement('span');
                editIcon.className = 'card-edit-icon';
                node.appendChild(editIcon);
              }
              addedListeners.push({ node, handler: textEditHandler });
            } else {
              // 其他類型：整個區域可點擊
              node.addEventListener('click', handler);
              node.classList.add('card-clickable-field');
              addedListeners.push({ node, handler });
            }
          }
        }
      }

      // 遞迴遍歷子節點
      for (const child of node.childNodes) {
        walkDOM(child);
      }
    };

    walkDOM(contentRef.current);

    // 清理函數
    return () => {
      addedListeners.forEach(({ node, handler, eventType }) => {
        node.removeEventListener(eventType || 'click', handler);
        node.classList.remove('card-interactive-field', 'card-editable-field', 'card-select-field', 'card-clickable-field', 'card-image-field');
      });
      // 移除所有編輯 icon
      contentRef.current?.querySelectorAll('.card-edit-icon').forEach(icon => icon.remove());
    };
  }, [interactiveFields, allFieldsMap, html, isPreview, onClick, selectDropdown, multiselectDropdown, textEditDialog, isDatePickerOpen, dateRangeDialog, imageDialog, addressPromptDialog, onFieldChange, fields, cardData, isOtherUserCard, copyCardInfo]);

  // 判斷當前用戶是否為擁有者
  const isOwner = useMemo(() => {
    const myPerm = cardData?._permissions?.find((p: any) => p.user_id === resolvedCurrentMemberID);
    return myPerm?.permission === 'owner';
  }, [resolvedCurrentMemberID, cardData?._permissions]);

  // 星星評分的 hover 和 click 事件（使用事件委託）
  useEffect(() => {
    if (!contentRef.current || isPreview) return;

    const cardElement = contentRef.current;
    const ratingContainers = cardElement.querySelectorAll('.card-rating-stars');
    const cleanupFns = [];

    // 卡片 hover 時顯示自己的評分
    const handleCardMouseEnter = () => {
      ratingContainers.forEach(container => {
        const myRating = parseInt(container.dataset.currentRating) || 0;
        const stars = container.querySelectorAll('.card-rating-star');

        // 只有有自己的評分時才切換顯示
        if (myRating > 0) {
          stars.forEach((star, i) => {
            star.classList.remove('half');
            const starIndex = i + 1;

            if (starIndex <= myRating) {
              star.textContent = '★';
              star.classList.add('filled', 'personal');
            } else {
              star.textContent = '☆';
              star.classList.remove('filled', 'personal');
            }
          });
        }
      });
    };

    const handleCardMouseLeave = () => {
      ratingContainers.forEach(container => {
        const myRating = parseInt(container.dataset.currentRating) || 0;
        const averageRating = parseFloat(container.dataset.averageRating) || 0;
        const stars = container.querySelectorAll('.card-rating-star');

        // 有評分時恢復顯示平均評分樣式（不加 personal class）
        const showAverage = averageRating > 0;
        const displayRating = showAverage ? Math.round(averageRating * 2) / 2 : myRating;

        stars.forEach((star, i) => {
          const starIndex = i + 1;

          if (displayRating >= starIndex) {
            star.textContent = '★';
            star.classList.add('filled');
            star.classList.remove('half');
            if (showAverage) star.classList.remove('personal');
            else star.classList.add('personal');
          } else if (displayRating >= starIndex - 0.5) {
            // 半星：底層用空星，CSS ::after 疊加半個實心星
            star.textContent = '☆';
            star.classList.add('half');
            star.classList.remove('filled');
            if (showAverage) star.classList.remove('personal');
            else star.classList.add('personal');
          } else {
            star.textContent = '☆';
            star.classList.remove('filled', 'half', 'personal');
          }
        });
      });
    };

    // 綁定卡片 hover 事件（僅限支援 hover 的裝置，避免手機自動觸發）
    const canHover = window.matchMedia
      ? window.matchMedia('(hover: hover) and (pointer: fine)').matches
      : window.innerWidth > 768;
    if (canHover) {
      cardElement.addEventListener('mouseenter', handleCardMouseEnter);
      cardElement.addEventListener('mouseleave', handleCardMouseLeave);
      cleanupFns.push(() => {
        cardElement.removeEventListener('mouseenter', handleCardMouseEnter);
        cardElement.removeEventListener('mouseleave', handleCardMouseLeave);
      });
    }

    // 使用事件委託：把點擊事件綁定到 contentRef.current 上
    const handleStarClick = (e) => {
      const star = e.target.closest('.card-rating-star');
      if (!star) return;

      e.preventDefault();
      e.stopPropagation();

      const container = star.closest('.card-rating-stars');
      if (!container) return;

      const fieldName = container.dataset.fieldName;
      const clickIndex = parseInt(star.dataset.starValue) || 0;
      const newRating = clickIndex;
      const stars = container.querySelectorAll('.card-rating-star');

      // 更新統計文字的輔助函數
      const updateStatsText = (newAvg, newCount) => {
        // 查找統計文字元素（在星星容器的前面或後面）
        const nextEl = container.nextElementSibling;
        const prevEl = container.previousElementSibling;
        let statsEl = null;

        if (nextEl?.classList?.contains('card-rating-stats')) {
          statsEl = nextEl;
        } else if (prevEl?.classList?.contains('card-rating-stats')) {
          statsEl = prevEl;
        }


        if (newCount >= 2 && newAvg > 0) {
          if (statsEl) {
            statsEl.textContent = `${newAvg.toFixed(1)}(${newCount})`;
          }
        } else {
          if (statsEl) {
            statsEl.remove();
          }
        }

        container.dataset.averageRating = newAvg.toFixed(2);
        container.dataset.reviewCount = newCount;
      };

      // 檢查權限
      if (!canRate) {
        setPermissionDialog({
          message: t('cannotRateThisCard')
        });
        return;
      }

      const oldRating = parseInt(container.dataset.currentRating) || 0;
      container.dataset.currentRating = newRating;

      stars.forEach((star, i) => {
        star.classList.remove('half');
        if (i < newRating) {
          star.textContent = '★';
          star.classList.add('filled', 'personal');
        } else {
          star.textContent = '☆';
          star.classList.remove('filled', 'personal');
        }
      });

      const currentAvg = parseFloat(container.dataset.averageRating) || 0;
      let currentCount = parseInt(container.dataset.reviewCount) || 0;
      if (oldRating === 0) {
        currentCount += 1;
        const newAvg = (currentAvg * (currentCount - 1) + newRating) / currentCount;
        updateStatsText(newAvg, currentCount);
      } else if (currentCount > 0) {
        const oldSum = currentAvg * currentCount;
        const newSum = oldSum - oldRating + newRating;
        const newAvg = newSum / currentCount;
        updateStatsText(newAvg, currentCount);
      }

      if (onReviewChange) {
        onReviewChange(newRating);
      }
    };

    // 綁定事件委託到 contentRef.current
    cardElement.addEventListener('click', handleStarClick);
    cleanupFns.push(() => {
      cardElement.removeEventListener('click', handleStarClick);
    });

    return () => {
      cleanupFns.forEach(fn => fn());
    };
  }, [html, isPreview, canRate, t, onReviewChange, setPermissionDialog]);

  // 注意：頭像和留言氣泡已移至獨立的 AvatarWithBubble 組件
  // CardRenderer 不再負責這些功能

  // 當日期選擇器狀態改變時，打開原生選擇器
  useEffect(() => {
    if (!isDatePickerOpen || !dateInputRef.current || !dateFieldRef.current) return;

    const { type, value, rect } = dateFieldRef.current;

    // 定位到點擊元素附近
    if (rect) {
      dateInputRef.current.style.left = `${rect.left}px`;
      dateInputRef.current.style.top = `${rect.bottom}px`;
    }

    // 設定當前值
    if (value) {
      if (type === 'DATE') {
        dateInputRef.current.value = value.replace(/\//g, '-');
      } else {
        dateInputRef.current.value = value.replace(/\//g, '-').replace(' ', 'T');
      }
    } else {
      dateInputRef.current.value = '';
    }

    // 打開選擇器
    requestAnimationFrame(() => {
      dateInputRef.current?.showPicker();
    });
  }, [isDatePickerOpen, dateInputType]);

  if (!templateHtml) {
    return (
      <div className={`card-renderer card-renderer-placeholder ${className}`.trim()}>
        尚未生成模板預覽
      </div>
    );
  }

  // 處理右鍵選單 - 檢測是否在 field 上
  const handleContextMenu = (e) => {
    let fieldName = null;
    let fieldValue = null;

    // 檢查點擊的元素
    const target = e.target;

    // 檢查 href
    const href = target.getAttribute?.('href');
    if (href) {
      // 找到對應的 field name
      fields?.forEach(field => {
        if (cardData?.cardFields?.[field.name] === href) {
          fieldName = field.name;
          fieldValue = href;
        }
      });
    }

    // 檢查是否為葉節點（只包含文字和 br）
    const isLeafNode = (node) => {
      if (!node.childNodes?.length) return false;
      for (const child of node.childNodes) {
        if (child.nodeType === Node.TEXT_NODE) continue;
        if (child.nodeType === Node.ELEMENT_NODE && child.tagName === 'BR') continue;
        return false;
      }
      return true;
    };

    if (!fieldName && isLeafNode(target)) {
      // 取得原始文字（將 <br> 還原為 \n）
      const text = target.innerHTML
        ?.replace(/<br\s*\/?>/gi, '\n')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&amp;/g, '&')
        .trim();
      if (text && allFieldsMap[text]) {
        // 排除星星評分（不需要複製）
        const isRating = text.includes('★') || text.includes('☆');
        if (!isRating) {
          fieldName = allFieldsMap[text].name;
          fieldValue = text;
        }
      }
    }

    // 傳遞 fieldName 和 fieldValue 給外層
    onContextMenu?.(e, fieldName, fieldValue);
  };

  // 處理單選選項選擇
  const handleSelectOption = (option) => {
    // 無權限時：顯示權限 dialog
    if (isOtherUserCard) {
      setSelectDropdown(null);
      setPermissionDialog({
        message: t('cannotEditThisCard')
      });
      return;
    }
    if (onFieldChange && selectDropdown?.fieldName) {
      onFieldChange(selectDropdown.fieldName, option);
    }
    setSelectDropdown(null);
  };

  // 處理多選選項切換
  const handleMultiselectToggle = (option) => {
    if (!multiselectDropdown) return;
    // 無權限時：顯示權限 dialog
    if (isOtherUserCard) {
      setMultiselectDropdown(null);
      setPermissionDialog({
        message: t('cannotEditThisCard')
      });
      return;
    }
    const currentValues = [...multiselectDropdown.currentValues];
    const idx = currentValues.indexOf(option);
    if (idx >= 0) {
      currentValues.splice(idx, 1);
    } else {
      currentValues.push(option);
    }
    setMultiselectDropdown(prev => ({ ...prev, currentValues }));
    if (onFieldChange) {
      onFieldChange(multiselectDropdown.fieldName, currentValues.join(', '));
    }
  };

  // 處理隱藏 input 的日期選擇
  const handleHiddenDateChange = (e) => {
    const value = e.target.value;
    setIsDatePickerOpen(false);
    if (!value || !dateFieldRef.current) return;

    // 無權限時：顯示權限 dialog
    if (isOtherUserCard) {
      setPermissionDialog({
        message: t('cannotEditThisCard')
      });
      return;
    }

    let formattedValue = '';
    if (dateFieldRef.current.type === 'DATE') {
      formattedValue = value.replace(/-/g, '/');
    } else {
      formattedValue = value.replace(/-/g, '/').replace('T', ' ');
    }

    if (onFieldChange && dateFieldRef.current.name) {
      onFieldChange(dateFieldRef.current.name, formattedValue);
    }
  };

  // 處理日期選擇器關閉（用戶取消）
  const handleDatePickerBlur = () => {
    setIsDatePickerOpen(false);
  };

  // 處理 TEXT 編輯 dialog 確認
  const handleTextEditConfirm = () => {
    if (!textEditDialog) return;
    const input = document.querySelector('.card-text-edit-dialog input, .card-text-edit-dialog textarea') as HTMLInputElement;
    if (input && onFieldChange) {
      onFieldChange(textEditDialog.fieldName, input.value);
    }
    setTextEditDialog(null);
  };

  // 觸發圖片選擇並上傳
  const triggerImageSelect = () => {
    if (!imageDialog) return;

    // 動態創建 input 元素
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';

    // 當用戶選擇檔案時
    input.onchange = async (event) => {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (!file) return;

      // 檢查檔案類型
      if (!file.type.startsWith('image/')) {
        setTempHint(t('invalidImageType'));
        return;
      }

      // 建立本地預覽
      const previewUrl = URL.createObjectURL(file);
      setImageDialog(prev => ({
        ...prev,
        previewUrl,
        isUploading: true
      }));

      try {
        // 獲取用戶資料
        const userData = JSON.parse(localStorage.getItem('userData_local'));
        if (!userData?.ID) {
          throw new Error('無法獲取用戶資料');
        }

        // 圖片壓縮選項（uploadFile 會自動壓縮）
        const imageCompressOptions = {
          maxWidth: 1920,
          maxHeight: 1920,
          quality: 0.8,
          maxSizeKB: 2048,
          outputFormat: 'image/jpeg'
        };

        const uploadResult = await uploadFile(file, userData.ID, 'images', imageCompressOptions);

        if (uploadResult?.downloadURL) {
          // 上傳成功，更新欄位值
          if (onFieldChange && imageDialog.fieldName) {
            onFieldChange(imageDialog.fieldName, uploadResult.downloadURL);
          }
          setTempHint(t('imageUploadSuccess'));
          setImageDialog(null);
        } else {
          throw new Error('上傳失敗');
        }
      } catch (error) {
        console.error('圖片上傳失敗:', error);
        setTempHint(t('imageUploadFailed'));
        setImageDialog(prev => ({
          ...prev,
          previewUrl: prev.currentUrl,
          isUploading: false
        }));
      } finally {
        // 釋放預覽 URL
        URL.revokeObjectURL(previewUrl);
      }
    };

    // 觸發檔案選擇對話框
    input.click();
  };

  // 處理卡片背景點擊（不再自動複製，改用右鍵選單）
  const handleCardBackgroundClick = (e) => {
    // 保留空函數，避免點擊時觸發其他事件
  };

  return (
    <div
      className={`card-renderer ${scopeId} ${className}`.trim()}
      onClick={handleCardBackgroundClick}
      onContextMenu={handleContextMenu}
      {...props}
    >
      <style>{`
        .card-renderer *, 
        .card-renderer *::before, 
        .card-renderer *::after { 
          box-sizing: border-box !important; 
        }
        .card-renderer *::before, 
        .card-renderer *::after { 
          pointer-events: none !important; 
        }
        ${scopedCss}
      `}</style>
      <div ref={contentRef} dangerouslySetInnerHTML={{ __html: html }} />
      {children}

      {/* SELECT 下拉選單 - 使用 Portal 渲染到 body */}
      {selectDropdown && ReactDOM.createPortal(
        <>
          <div
            className="card-interaction-mask"
            style={{ position: 'fixed', inset: 0, zIndex: 9998 }}
            onClick={() => setSelectDropdown(null)}
          />
          <div
            className={`card-select-dropdown ${selectDropdown.openUpward ? 'open-upward' : ''}`}
            style={{
              position: 'fixed',
              left: selectDropdown.x,
              top: selectDropdown.y,
              bottom: selectDropdown.bottom,
              zIndex: 9999
            }}
          >
            {selectDropdown.options.map((option, idx) => (
              <div
                key={idx}
                className={`card-select-option ${option === selectDropdown.currentValue ? 'selected' : ''}`}
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectOption(option);
                }}
              >
                {option}
              </div>
            ))}
          </div>
        </>,
        document.body
      )}

      {/* MULTISELECT 多選選單 - 使用 Portal 渲染到 body */}
      {multiselectDropdown && ReactDOM.createPortal(
        <>
          <div
            className="card-interaction-mask"
            style={{ position: 'fixed', inset: 0, zIndex: 9998 }}
            onClick={() => setMultiselectDropdown(null)}
          />
          <div
            className={`card-select-dropdown ${multiselectDropdown.openUpward ? 'open-upward' : ''}`}
            style={{
              position: 'fixed',
              left: multiselectDropdown.x,
              top: multiselectDropdown.y,
              bottom: multiselectDropdown.bottom,
              zIndex: 9999
            }}
          >
            {multiselectDropdown.options.map((option, idx) => (
              <label
                key={idx}
                className={`card-select-option card-multiselect-option ${multiselectDropdown.currentValues.includes(option) ? 'selected' : ''}`}
                onClick={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={multiselectDropdown.currentValues.includes(option)}
                  onChange={() => handleMultiselectToggle(option)}
                />
                <span>{option}</span>
              </label>
            ))}
          </div>
        </>,
        document.body
      )}

      {/* 日期選擇器開啟時的透明 mask */}
      {isDatePickerOpen && ReactDOM.createPortal(
        <div
          className="card-interaction-mask"
          style={{ position: 'fixed', inset: 0, zIndex: 9998 }}
          onClick={() => setIsDatePickerOpen(false)}
        />,
        document.body
      )}

      {/* 隱藏的日期 input - 用於直接觸發原生選擇器（Portal 到 body） */}
      {ReactDOM.createPortal(
        <input
          ref={dateInputRef}
          type={dateInputType}
          onChange={handleHiddenDateChange}
          onBlur={handleDatePickerBlur}
          style={{ position: 'fixed', opacity: 0, pointerEvents: 'none', width: 0, height: 0, zIndex: 9999 }}
        />,
        document.body
      )}

      {/* TEXT/TEXTAREA 編輯 dialog */}
      <CustomDialog
        isOpen={!!textEditDialog}
        onClose={() => setTextEditDialog(null)}
        title={textEditDialog?.fieldName}
        className="card-text-edit-dialog"
      >
        <div className="card-text-edit-input-row">
          {textEditDialog?.isTextarea ? (
            <textarea
              defaultValue={textEditDialog?.currentValue}
              disabled={textEditDialog?.isReadOnly}
              ref={(el) => {
                if (el && !textEditDialog?.isReadOnly) {
                  el.setSelectionRange(el.value.length, el.value.length);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Escape') setTextEditDialog(null);
              }}
            />
          ) : (
            <input
              type="text"
              defaultValue={textEditDialog?.currentValue}
              disabled={textEditDialog?.isReadOnly}
              ref={(el) => {
                if (el && !textEditDialog?.isReadOnly) {
                  el.setSelectionRange(el.value.length, el.value.length);
                }
              }}
              onKeyDown={(e) => {
                // 檢查是否正在輸入法組字中，避免選字時誤觸發
                if (e.key === 'Enter' && !e.nativeEvent.isComposing && !textEditDialog?.isReadOnly) handleTextEditConfirm();
                if (e.key === 'Escape') setTextEditDialog(null);
              }}
            />
          )}
          <button
            type="button"
            className="add-card-copy-btn"
            onClick={() => {
              const input = document.querySelector('.card-text-edit-dialog input, .card-text-edit-dialog textarea') as HTMLInputElement;
              if (input) {
                navigator.clipboard.writeText(input.value);
                setTempHint(t('copied'));
              }
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
            </svg>
          </button>
        </div>
        {/* 無權限時顯示提示 */}
        {textEditDialog?.isReadOnly && (
          <div className="card-permission-hint">{t('cannotEditThisCard')}</div>
        )}
        <div className="custom-dialog-buttons">
          {textEditDialog?.isReadOnly ? (
            <button className="custom-primary-button" onClick={() => {
              setTextEditDialog(null);
              if (!isLoggedIn && onRequestLogin) {
                onRequestLogin();
              } else if (onRequestPermission) {
                onRequestPermission();
              }
            }}>{isLoggedIn ? t('requestPermission') : t('goToLogin')}</button>
          ) : (
            <>
              <button className="custom-secondary-button" onClick={() => setTextEditDialog(null)}>取消</button>
              <button className="custom-primary-button" onClick={handleTextEditConfirm}>確定</button>
            </>
          )}
        </div>
      </CustomDialog>

      {/* DATERANGE 編輯 dialog（使用共用組件） */}
      <DateRangeDialog
        isOpen={!!dateRangeDialog}
        onClose={() => setDateRangeDialog(null)}
        fieldName={dateRangeDialog?.fieldName}
        value={cardData?.cardFields?.[dateRangeDialog?.fieldName] || ''}
        onChange={(newValue) => {
          if (isOtherUserCard) {
            setDateRangeDialog(null);
            setPermissionDialog({
              message: t('cannotEditThisCard')
            });
            return;
          }
          if (onFieldChange && dateRangeDialog?.fieldName) {
            onFieldChange(dateRangeDialog.fieldName, newValue);
          }
        }}
      />

      {/* DATE/DATETIME 編輯 dialog（手機版使用） */}
      <DateDialog
        isOpen={!!dateDialog}
        onClose={() => setDateDialog(null)}
        fieldName={dateDialog?.fieldName}
        fieldType={dateDialog?.fieldType}
        value={dateDialog?.value || ''}
        onChange={(newValue) => {
          if (isOtherUserCard) {
            setDateDialog(null);
            setPermissionDialog({
              message: t('cannotEditThisCard')
            });
            return;
          }
          if (onFieldChange && dateDialog?.fieldName) {
            onFieldChange(dateDialog.fieldName, newValue);
          }
        }}
      />

      {/* IMAGE 上傳 dialog */}
      <CustomDialog
        isOpen={!!imageDialog}
        onClose={() => setImageDialog(null)}
        className="card-image-dialog"
        title={imageDialog?.isReadOnly ? t('viewImage') : t('selectImage')}
      >
        <div className="card-image-preview-container">
          {/* 圖片載入錯誤時顯示錯誤提示 */}
          {imageDialog?.imageError ? (
            <div className="card-image-error-container">
              <img src={IMAGE_PLACEHOLDER} alt="" className="card-image-error-icon" />
              <span className="card-image-error-text">{t('imageLoadError')}</span>
            </div>
          ) : imageDialog?.previewUrl && (
            <img
              src={imageDialog.previewUrl}
              alt="preview"
              className="card-image-preview"
              referrerPolicy="no-referrer"
              onError={() => {
                // 圖片載入失敗時設置錯誤狀態
                setImageDialog(prev => ({
                  ...prev,
                  imageError: true
                }));
              }}
            />
          )}
          {imageDialog?.isUploading && (
            <div className="card-image-uploading-overlay">
              <div className="card-image-uploading-spinner" />
              <span>{t('uploading')}</span>
            </div>
          )}
          {imageDialog?.isSearching && (
            <div className="card-image-uploading-overlay">
              <div className="card-image-uploading-spinner" />
              <span>{t('searchingImage')}</span>
            </div>
          )}
        </div>
        {/* 無權限時顯示提示 */}
        {imageDialog?.isReadOnly && (
          <div className="card-permission-hint">{t('cannotEditThisCard')}</div>
        )}
        <div className="custom-dialog-buttons">
          {/* 無權限時：只顯示要求權限/登入按鈕 */}
          {imageDialog?.isReadOnly ? (
            <button className="custom-primary-button" onClick={() => {
              setImageDialog(null);
              if (!isLoggedIn && onRequestLogin) {
                onRequestLogin();
              } else if (onRequestPermission) {
                onRequestPermission();
              }
            }}>
              {isLoggedIn ? t('requestPermission') : t('goToLogin')}
            </button>
          ) : (
            <>
              <button className="custom-secondary-button" onClick={() => setImageDialog(null)}>
                {t('cancel')}
              </button>
              {/* 上網找另一張按鈕 */}
              <button
                className="custom-secondary-button"
                onClick={async () => {
                  // 使用卡片資料中的值作為搜索關鍵詞
                  // 優先使用卡片中有值的欄位（如名稱、標題等），否則使用欄位名稱
                  let searchQuery = imageDialog?.fieldName || '圖片';
                  if (cardData?.cardFields) {
                    // 嘗試從卡片數據中找到有意義的關鍵詞（標題、名稱等文字欄位）
                    const textFields = fields?.filter(f => ['TEXT', 'TEXTAREA'].includes(f.type)) || [];
                    for (const field of textFields) {
                      const value = cardData.cardFields?.[field.name];
                      if (value && typeof value === 'string' && value.trim()) {
                        searchQuery = value.trim();
                        break;
                      }
                    }
                  }

                  setImageDialog(prev => ({
                    ...prev,
                    isSearching: true
                  }));

                  try {
                    // 把當前圖片 URL 加入排除列表
                    const excludeUrls = imageDialog?.currentUrl ? [imageDialog.currentUrl] : [];
                    const result = await searchCardImage(searchQuery, excludeUrls);

                    if (result?.imageUrl) {
                      // 更新欄位值
                      if (onFieldChange && imageDialog?.fieldName) {
                        onFieldChange(imageDialog.fieldName, result.imageUrl);
                      }
                      setTempHint(t('imageSearchSuccess'));
                      // 關閉 dialog
                      setImageDialog(null);
                    } else {
                      setTempHint(t('imageSearchNoResult'));
                      setImageDialog(prev => ({
                        ...prev,
                        isSearching: false
                      }));
                    }
                  } catch (error) {
                    console.error('搜索圖片失敗:', error);
                    setTempHint(t('imageSearchFailed'));
                    setImageDialog(prev => ({
                      ...prev,
                      isSearching: false
                    }));
                  }
                }}
                disabled={imageDialog?.isSearching}
              >
                {t('searchImageOnline')}
              </button>
              <button
                className="custom-primary-button"
                onClick={triggerImageSelect}
                disabled={imageDialog?.isUploading || imageDialog?.isSearching}
              >
                {t('selectImage')}
              </button>
            </>
          )}
        </div>
      </CustomDialog>

      {/* 地址填寫提示 dialog */}
      <CustomDialog
        isOpen={!!addressPromptDialog}
        onClose={() => {
          // 關閉時直接打開搜尋模式（不記錄，下次還會出現）
          window.electronAPI?.openExternalLink(
            `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressPromptDialog?.destinationAddress || '')}`
          );
          setAddressPromptDialog(null);
        }}
        title={t('setHomeAddress')}
        className="card-address-dialog"
      >
        <p className="custom-dialog-description">
          {t('setHomeAddressDescription')}
        </p>
        <input
          type="text"
          className="card-address-input"
          placeholder={t('homeAddressPlaceholder')}
          onKeyDown={(e) => {
            // 檢查是否正在輸入法組字中，避免選字時誤觸發
            if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
              const value = (e.target as HTMLInputElement).value.trim();
              const dontShowAgain = (document.querySelector('.card-address-dont-show-checkbox') as HTMLInputElement)?.checked;
              if (dontShowAgain) {
                localStorage.setItem('hideAddressPrompt', 'true');
              }
              if (value) {
                // 儲存地址到 userData 並同步到伺服器
                try {
                  const userDataLocal = localStorage.getItem('userData_local');
                  const parsedUserData = userDataLocal ? JSON.parse(userDataLocal) : {};

                  // 合併新的欄位到本地
                  const updatedUserData = { ...parsedUserData, address: value };
                  localStorage.setItem('userData_local', JSON.stringify(updatedUserData));

                  // 同步到服務器（只傳 address 欄位，實現部分更新）
                  const accessToken = localStorage.getItem('accessToken');
                  if (accessToken) {
                    window.electronAPI.graphqlRequest({
                      url: 'https://dev.cubelv.com/membercenter/graphql',
                      accessToken: accessToken,
                      query: `
                            mutation UpdateUserProfile($input: UpdateUserProfileInput!) {
                              updateUserProfile(input: $input) {
                                ID
                                address
                              }
                            }
                          `,
                      variables: {
                        input: {
                          address: value
                        }
                      },
                      operationName: 'UpdateUserProfile'
                    });

                  }
                } catch (error) {
                  console.error('[AddressNav] 保存地址失敗:', error);
                }

                // 使用導航模式打開（不編碼，直接使用中文地址）
                window.electronAPI?.openExternalLink(
                  `https://www.google.com/maps/dir/${value}/${addressPromptDialog?.destinationAddress}`
                );
              } else {
                // 沒填地址，直接使用搜尋模式
                window.electronAPI?.openExternalLink(
                  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressPromptDialog?.destinationAddress || '')}`
                );
              }
              setAddressPromptDialog(null);
            }
            if (e.key === 'Escape') {
              window.electronAPI?.openExternalLink(
                `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressPromptDialog?.destinationAddress || '')}`
              );
              setAddressPromptDialog(null);
            }
          }}
        />
        <label className="card-address-dont-show">
          <input type="checkbox" className="card-address-dont-show-checkbox" />
          <span>{t('dontShowAgain')}</span>
        </label>
        <div className="custom-dialog-buttons">
          <button
            className="custom-secondary-button"
            onClick={() => {
              // 跳過，檢查是否勾選不再顯示
              const dontShowAgain = (document.querySelector('.card-address-dont-show-checkbox') as HTMLInputElement)?.checked;
              if (dontShowAgain) {
                localStorage.setItem('hideAddressPrompt', 'true');
              }
              window.electronAPI?.openExternalLink(
                `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressPromptDialog?.destinationAddress || '')}`
              );
              setAddressPromptDialog(null);
            }}
          >
            {t('skip')}
          </button>
          <button
            className="custom-primary-button"
            onClick={() => {
              const input = document.querySelector('.card-address-input') as HTMLInputElement;
              const value = input?.value?.trim();
              const dontShowAgain = (document.querySelector('.card-address-dont-show-checkbox') as HTMLInputElement)?.checked;
              if (dontShowAgain) {
                localStorage.setItem('hideAddressPrompt', 'true');
              }
              if (value) {
                // 儲存地址到 userData 並同步到伺服器
                try {
                  const userDataLocal = localStorage.getItem('userData_local');
                  const parsedUserData = userDataLocal ? JSON.parse(userDataLocal) : {};

                  // 合併新的欄位到本地
                  const updatedUserData = { ...parsedUserData, address: value };
                  localStorage.setItem('userData_local', JSON.stringify(updatedUserData));

                  // 同步到服務器（只傳 address 欄位，實現部分更新）
                  const accessToken = localStorage.getItem('accessToken');
                  if (accessToken) {
                    window.electronAPI.graphqlRequest({
                      url: 'https://dev.cubelv.com/membercenter/graphql',
                      accessToken: accessToken,
                      query: `
                            mutation UpdateUserProfile($input: UpdateUserProfileInput!) {
                              updateUserProfile(input: $input) {
                                ID
                                address
                              }
                            }
                          `,
                      variables: {
                        input: {
                          address: value
                        }
                      },
                      operationName: 'UpdateUserProfile'
                    });

                  }
                } catch (error) {
                  console.error('[AddressNav] 保存地址失敗:', error);
                }

                // 使用導航模式打開（不編碼，直接使用中文地址）
                window.electronAPI?.openExternalLink(
                  `https://www.google.com/maps/dir/${value}/${addressPromptDialog?.destinationAddress}`
                );
              } else {
                // 沒填地址，直接使用搜尋模式
                window.electronAPI?.openExternalLink(
                  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addressPromptDialog?.destinationAddress || '')}`
                );
              }
              setAddressPromptDialog(null);
            }}
          >
            {t('confirm')}
          </button>
        </div>
      </CustomDialog>

      {/* 要求權限 dialog */}
      <CustomDialog
        isOpen={!!permissionDialog}
        onClose={() => setPermissionDialog(null)}
        className="card-permission-dialog"
      >
        <div className="card-permission-message">{permissionDialog?.message}</div>
        <div className="custom-dialog-buttons">
          <button className="custom-secondary-button" onClick={() => setPermissionDialog(null)}>
            {t('cancel')}
          </button>
          <button className="custom-primary-button" onClick={() => {
            setPermissionDialog(null);
            if (!isLoggedIn && onRequestLogin) {
              onRequestLogin();
            } else if (onRequestPermission) {
              onRequestPermission();
            }
          }}>
            {isLoggedIn ? t('requestPermission') : t('goToLogin')}
          </button>
        </div>
      </CustomDialog>
    </div>
  );
}

// 使用 React.memo 避免不必要的重新渲染
export default React.memo(CardRenderer, (prevProps, nextProps) => {
  // 只有當這些 props 變化時才重新渲染
  return (
    prevProps.templateHtml === nextProps.templateHtml &&
    prevProps.templateCss === nextProps.templateCss &&
    prevProps.cardData?.id === nextProps.cardData?.id &&
    JSON.stringify(prevProps.cardData?.cardFields) === JSON.stringify(nextProps.cardData?.cardFields) &&
    JSON.stringify(prevProps.cardData?.reviews) === JSON.stringify(nextProps.cardData?.reviews) &&
    JSON.stringify(prevProps.fields) === JSON.stringify(nextProps.fields) &&
    prevProps.className === nextProps.className
  );
});
