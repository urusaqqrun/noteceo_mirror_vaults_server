import React from 'react';
import { useTranslation } from 'react-i18next';
import './CustomHint.css';

interface HintButton {
  text: string;
  type?: string;
  onClick?: (e: React.MouseEvent) => void;
}

interface CustomHintProps {
  show: boolean;
  children?: React.ReactNode;
  buttons?: HintButton[];
}

const CustomHint = ({ show, children, buttons = [] }: CustomHintProps) => {
  const { t } = useTranslation();
  if (!show) return null;

  // 根据是否有按钮决定使用哪种样式类
  const positionClass = buttons.length > 0 ? 'custom-hint-bottom' : 'custom-hint-top';

  return (
    <div
      className={`custom-hint ${positionClass}`}
      onClick={(e) => e.stopPropagation()}
    >
      <span className="custom-hint-text">{children || <span>{t('setText')}</span>}</span>
      {buttons.length > 0 && (
        <div className="custom-hint-buttons">
          {buttons.map((button, index) => (
            <button
              key={index}
              className={`custom-hint-button ${button.type || ''}`}
              onClick={(e) => {
                e.stopPropagation();
                e.preventDefault();
                if (typeof button.onClick === 'function') {
                  button.onClick(e);
                }
              }}
            >
              {button.text}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomHint; 