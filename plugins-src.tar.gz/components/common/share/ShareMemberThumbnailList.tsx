import React, { useMemo, useEffect, useState, useCallback } from 'react';
import { getMembersInfo } from '../../../utils/shareAPI';
import { getMyMemberID } from '../../../utils/shareUtils';
import { useDialogStore } from '../../../Store/dialogStore';
import type { ItemPermissionEntry } from '../../../types/item';
import './ShareMemberThumbnailList.css';

interface ShareMemberThumbnailListProps {
  itemId: string;
  permissions: ItemPermissionEntry[];
  maxDisplay?: number;
  size?: 'small' | 'normal';
  clickable?: boolean;
}

const VISIBLE_PERMISSIONS = new Set(['owner', 'editor', 'contributor']);

export function ShareMemberThumbnailList({
  itemId,
  permissions,
  maxDisplay = 10,
  size = 'normal',
  clickable = true,
}: ShareMemberThumbnailListProps) {
  const [membersInfoMap, setMembersInfoMap] = useState<Record<string, { name?: string; thumbnail?: string }>>({});

  const displayMembers = useMemo(() => {
    const myId = getMyMemberID();
    const visible = permissions.filter(m => VISIBLE_PERMISSIONS.has(m.permission) && m.permission !== 'guest');
    const owner: typeof visible = [];
    const me: typeof visible = [];
    const editors: typeof visible = [];
    const contributors: typeof visible = [];
    for (const m of visible) {
      if (m.permission === 'owner') { owner.push(m); }
      else if (m.user_id === myId) { me.push(m); }
      else if (m.permission === 'editor') { editors.push(m); }
      else { contributors.push(m); }
    }
    return [...owner, ...me, ...editors, ...contributors].slice(0, maxDisplay);
  }, [permissions, maxDisplay]);

  const memberIdsKey = useMemo(() => displayMembers.map(m => m.user_id).join(','), [displayMembers]);

  useEffect(() => {
    if (!memberIdsKey) return;
    let cancelled = false;
    getMembersInfo(memberIdsKey.split(',')).then(infos => {
      if (cancelled) return;
      const infoMap: Record<string, { name?: string; thumbnail?: string }> = {};
      infos.forEach((info: any) => {
        infoMap[info.memberID] = { name: info.name, thumbnail: info.photo || info.thumbnail };
      });
      setMembersInfoMap(infoMap);
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [memberIdsKey]);

  const handleClick = useCallback(() => {
    if (!clickable) return;
    useDialogStore.getState().open('contributors', { itemId });
  }, [itemId, clickable]);

  const hasMore = permissions.filter(m => VISIBLE_PERMISSIONS.has(m.permission)).length > maxDisplay;

  if (displayMembers.length <= 1) return null;

  const sizeClass = size === 'small' ? 'share-member-thumbnail-list--small' : '';

  return (
    <div
      className={`share-member-thumbnail-list ${sizeClass} ${clickable ? 'is-clickable' : ''}`}
      {...(clickable ? {
        role: 'button',
        tabIndex: 0,
        onClick: handleClick,
        onKeyDown: (e: React.KeyboardEvent) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleClick();
          }
        },
      } : {})}
    >
      {displayMembers.map((member, index) => {
        const info = membersInfoMap[member.user_id];
        const avatar = info?.thumbnail;
        return (
          <div
            key={member.user_id}
            className="share-member-avatar"
            style={{
              zIndex: maxDisplay - index,
              backgroundImage: avatar ? `url(${avatar})` : undefined,
              opacity: hasMore && index === maxDisplay - 1 ? 0.3 : hasMore && index === maxDisplay - 2 ? 0.6 : 1,
            }}
            title={info?.name || member.user_id.slice(-6)}
          />
        );
      })}
    </div>
  );
}
