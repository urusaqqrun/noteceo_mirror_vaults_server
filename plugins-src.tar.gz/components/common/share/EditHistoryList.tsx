import React from 'react';
import { useTranslation } from 'react-i18next';
import { formatTimestamp } from '../../Utils/dateFormat';
import { useMembersInfoStore } from '../../../Store/MembersInfoStore';
import { getMembersInfo } from '../../../utils/shareAPI';
import HistoryIcon from '../../../assets/icon_history_outline_24.svg?react';
import '../../../components/plugins/card/shareGallery/EditHistoryPanel.css';

function MemberName({ memberId, className, style, onClick }: {
  memberId?: string | null;
  className?: string;
  style?: React.CSSProperties;
  onClick?: (e: React.MouseEvent) => void;
}) {
  const info = useMembersInfoStore(state => memberId ? state.membersInfoMap[memberId] : undefined);

  React.useEffect(() => {
    if (memberId && !info) {
      useMembersInfoStore.getState().fetchMembersInfo(memberId, getMembersInfo);
    }
  }, [memberId, info]);

  if (!memberId) return null;
  const name = info?.name || memberId.slice(-6);
  return <span className={className} style={style} onClick={onClick}>{name}</span>;
}

function TargetName({ targetId }: { targetId?: string | null }) {
  return <MemberName memberId={targetId} className="history-target" />;
}

export const ChangeType = {
  CREATED: 'created',
  UPDATED: 'updated',
  DELETED: 'deleted',
  PERMISSION_GRANTED: 'permission_granted',
  PERMISSION_UPDATED: 'permission_updated',
  PERMISSION_REVOKED: 'permission_revoked',
};

function EditHistoryList({ histories = [], isLoading = false, onActorClick, onItemClick, emptyText }) {
  const { t } = useTranslation();

  const getActionDescription = (history) => {
    const { changeType, itemName, actorId, itemId, targetId, changedFields, details } = history;

    const actorElement = actorId ? (
      <MemberName
        memberId={actorId}
        className="history-actor"
        onClick={onActorClick ? (e) => {
          e.preventDefault();
          e.stopPropagation();
          onActorClick(String(actorId));
        } : undefined}
        style={onActorClick ? { cursor: 'pointer' } : {}}
      />
    ) : (
      <span className="history-actor">{t('unknownUser')}</span>
    );

    const isFolder = history.itemType?.includes('_FOLDER');
    const itemTypeLabel = isFolder ? t('folder', '資料夾') : '';
    const displayName = itemName || t('unknownTarget');
    const clickable = !isFolder && onItemClick && itemId;

    const nameElement = (
      <span
        className={`history-target${changeType === ChangeType.DELETED ? ' deleted' : ''}${clickable ? ' clickable' : ''}`}
        onClick={clickable ? (e) => { e.preventDefault(); e.stopPropagation(); onItemClick(itemId); } : undefined}
        style={clickable ? { cursor: 'pointer' } : undefined}
      >
        {displayName}
      </span>
    );

    switch (changeType) {
      case ChangeType.CREATED:
        return (
          <>
            {actorElement}
            {t('historyActionCreated')}{itemTypeLabel && ` ${itemTypeLabel}`} {nameElement}
          </>
        );
      case ChangeType.UPDATED: {
        const fields = changedFields || [];
        return (
          <>
            {actorElement}
            {t('historyActionUpdated')}{itemTypeLabel && ` ${itemTypeLabel}`} {nameElement}
            {fields.length > 0 && (
              <span> {t('of', '的')} {fields.join('、')}</span>
            )}
          </>
        );
      }
      case ChangeType.DELETED:
        return (
          <>
            {actorElement}
            {t('historyActionDeleted')}{itemTypeLabel && ` ${itemTypeLabel}`} {nameElement}
          </>
        );
      case ChangeType.PERMISSION_GRANTED: {
        const permLabel = details ? String(t(details.toLowerCase(), { defaultValue: details })) : '';
        return (
          <>
            {actorElement}
            {t('historyActionPermissionGranted')} <TargetName targetId={targetId} /> {permLabel && <span className="history-permission-badge">{permLabel}</span>}
          </>
        );
      }
      case ChangeType.PERMISSION_UPDATED: {
        const permLabel = details ? String(t(details.toLowerCase(), { defaultValue: details })) : '';
        return (
          <>
            {actorElement}
            {t('historyActionPermissionUpdated')} <TargetName targetId={targetId} /> {permLabel && <span className="history-permission-badge">{permLabel}</span>}
          </>
        );
      }
      case ChangeType.PERMISSION_REVOKED:
        return (
          <>
            {actorElement}
            {t('historyActionPermissionRevoked')} <TargetName targetId={targetId} />
          </>
        );
      default:
        return (
          <>
            {actorElement}
            {t('historyActionUpdated')}
          </>
        );
    }
  };

  if (isLoading) {
    return (
      <div className="edit-history-list">
        <div className="edit-history-loading">
          <span className="edit-history-loading-spinner"></span>
          {t('loading')}
        </div>
      </div>
    );
  }

  if (!histories || histories.length === 0) {
    return (
      <div className="edit-history-list">
        <div className="edit-history-empty">
          <HistoryIcon className="edit-history-empty-icon" />
          <span className="edit-history-empty-text">
            {emptyText || t('noEditHistory')}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="edit-history-list">
      {histories.map((history) => (
        <div key={history.seq} className="edit-history-item">
          <div className="edit-history-content">
            <div className="edit-history-description">
              {getActionDescription(history)}
            </div>
            <div className="edit-history-time">
              {formatTimestamp(history.createdAt)}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default EditHistoryList;
