import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../CustomDialog';
import { PopupMenu } from '../PopupMenu';
import { Permission } from '../../../hooks/useItemPermission';
import { generateShareUrl, getMembersInfo, getItemMembersAndPending, patchItemPermission, deleteItemPermission, inviteMember, inviteMemberByUserId, cancelInvitation, getItemPermissions, addItemPermission } from '../../../utils/shareAPI';
import { useDialogStore } from '../../../Store/dialogStore';
import { useTempHintStore } from '../../../Store/uiStore';
import { getMyMemberID, canManageMembers, getEffectivePermission } from '../../../utils/shareUtils';
import { useItemStore } from '../../../Store/itemStore';
import { supportsPublicShare } from '../../../Store/publicItemTypeRegistry';
import './SharingDialog.css';

export interface LinkPermissionOption {
  value: string;
  label: string;
  description: string;
}

export interface SharingDialogData {
  item: {
    id: string;
    name?: string;
    isPublic?: boolean;
    itemType: string;
  };
  linkPermissionOptions?: LinkPermissionOption[];
  currentLinkPermission?: string;
  onSave: (settings: {
    folderId: string;
    isPublic: boolean;
    searchable: boolean;
    linkPermission: string;
  }) => Promise<void>;
}

const DEFAULT_LINK_OPTIONS: LinkPermissionOption[] = [
  { value: 'viewer', label: '', description: '' },
];

function SharingDialog() {
  const { t } = useTranslation();
  const show = useDialogStore(state => state.dialogs['sharing']?.show);
  const data = useDialogStore(state => state.dialogs['sharing']?.data) as SharingDialogData | null;

  const [isPublic, setIsPublic] = useState(false);
  const [linkPermission, setLinkPermission] = useState('viewer');
  const [isSaving, setIsSaving] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const [members, setMembers] = useState<Array<{ userId: string; permission: string }>>([]);
  const [membersInfoMap, setMembersInfoMap] = useState<Record<string, { name?: string; avatar?: string }>>({});
  const [expandedMemberId, setExpandedMemberId] = useState<string | null>(null);
  const [menuPosition, setMenuPosition] = useState({ x: 0, y: 0 });

  const [pendingInvites, setPendingInvites] = useState<Array<{ email: string; permission: string }>>([]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [invitePermission, setInvitePermission] = useState('editor');
  const [isInviting, setIsInviting] = useState(false);
  const [inviteError, setInviteError] = useState('');

  const [accessDropdownOpen, setAccessDropdownOpen] = useState(false);
  const [linkPermDropdownOpen, setLinkPermDropdownOpen] = useState(false);
  const accessDropdownRef = useRef<HTMLDivElement>(null);
  const linkPermDropdownRef = useRef<HTMLDivElement>(null);

  // 全域共享者 autocomplete
  const [knownCollaborators, setKnownCollaborators] = useState<Array<{ userId: string; name?: string; avatar?: string }>>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inviteRowRef = useRef<HTMLDivElement>(null);

  const itemId = data?.item?.id;
  const itemName = data?.item?.name || '';
  const myMemberID = getMyMemberID();
  const linkOptions = data?.linkPermissionOptions || DEFAULT_LINK_OPTIONS;
  const hasMultipleLinkOptions = linkOptions.length > 1;
  const selectedLinkOption = linkOptions.find(o => o.value === linkPermission) || linkOptions[0];

  const initialIsPublicRef = useRef(false);
  const initialLinkPermRef = useRef('viewer');

  // 角色判斷
  const storeItem = useItemStore(s => itemId ? s.itemMap.get(itemId) : undefined);
  const isOwner = storeItem ? canManageMembers(storeItem) : true;
  const myPermission = storeItem ? getEffectivePermission(storeItem) : 'owner';
  const canInvite = isOwner || myPermission === 'editor' || myPermission === 'contributor';
  const itemType = data?.item?.itemType || '';
  const canBePublic = supportsPublicShare(itemType);

  const [isLeaving, setIsLeaving] = useState(false);

  const handleLeaveShare = async () => {
    if (!itemId) return;
    setIsLeaving(true);
    try {
      await deleteItemPermission(itemId, myMemberID);
      // BFS 刪除本地 item + 後代
      const allItems = Array.from(useItemStore.getState().itemMap.values());
      const idsToDelete: string[] = [itemId];
      const queue = [itemId];
      while (queue.length > 0) {
        const pid = queue.shift()!;
        for (const item of allItems) {
          if (item.parentID === pid) {
            if (!idsToDelete.includes(item.id)) {
              idsToDelete.push(item.id);
              queue.push(item.id);
            }
          }
        }
      }
      await (window as any).electronAPI.deleteItems(idsToDelete);
      useItemStore.getState().applyRemoteDelete(idsToDelete);
      useTempHintStore.getState().setTempHint(t('leaveShareSuccess'));
      handleClose();
    } catch (error) {
      console.error('退出共享失敗:', error);
    } finally {
      setIsLeaving(false);
    }
  };

  useEffect(() => {
    if (show && data?.item) {
      const initial = data.item.isPublic === true;
      setIsPublic(initial);
      initialIsPublicRef.current = initial;
      const initialPerm = data.currentLinkPermission || 'viewer';
      setLinkPermission(initialPerm);
      initialLinkPermRef.current = initialPerm;
      setLinkCopied(false);
      setExpandedMemberId(null);
      setAccessDropdownOpen(false);
      setLinkPermDropdownOpen(false);
      setInviteEmail('');
      setInviteError('');
      loadMembers(data.item.id);
    }
  }, [show, data?.item]);

  // Dialog 開啟時收集所有 item 的 _permissions 成員（排除自己），查詢名稱
  useEffect(() => {
    if (!show) return;
    const allItems = Array.from(useItemStore.getState().itemMap.values());
    const idSet = new Set<string>();
    for (const item of allItems) {
      if (!item._permissions) continue;
      for (const p of item._permissions) {
        if (p.user_id && p.user_id !== myMemberID) idSet.add(p.user_id);
      }
    }
    if (idSet.size === 0) { setKnownCollaborators([]); return; }
    getMembersInfo(Array.from(idSet)).then((infos: Array<{ memberID: string; name?: string; photo?: string }>) => {
      setKnownCollaborators(infos.map(i => ({ userId: i.memberID, name: i.name, avatar: i.photo })));
    }).catch(() => setKnownCollaborators([]));
  }, [show, myMemberID]);

  const loadMembers = useCallback(async (folderId: string) => {
    try {
      const result = await getItemMembersAndPending(folderId);
      const allMembers = (result.members || []).filter((m: any) => m.permission !== 'guest');
      setMembers(allMembers);
      setPendingInvites(result.pending || []);
      if (allMembers.length > 0) {
        const memberIDs = allMembers.map((e: any) => e.userId);
        const infos = await getMembersInfo(memberIDs);
        const infoMap: Record<string, { name?: string; avatar?: string }> = {};
        infos.forEach((info: { memberID: string; name?: string; photo?: string }) => {
          infoMap[info.memberID] = { name: info.name, avatar: info.photo };
        });
        setMembersInfoMap(infoMap);
      }
    } catch (error) {
      console.error('載入成員列表失敗:', error);
    }
  }, []);

  const refreshStorePermissions = useCallback(async (id: string) => {
    try {
      const perms = await getItemPermissions(id);
      const mapped = perms.map((p: any) => ({ user_id: p.userId, permission: p.permission }));
      const item = useItemStore.getState().itemMap.get(id);
      if (item) {
        useItemStore.getState().upsertItem({ ...item, _permissions: mapped });
      }
    } catch {}
  }, []);

  const handleClose = useCallback(() => {
    useDialogStore.getState().close('sharing');
  }, []);

  const handleDone = useCallback(async () => {
    if (!itemId) { handleClose(); return; }
    if (data?.onSave && (isPublic !== initialIsPublicRef.current || linkPermission !== initialLinkPermRef.current)) {
      setIsSaving(true);
      try {
        await data.onSave({
          folderId: itemId,
          isPublic,
          searchable: isPublic,
          linkPermission,
        });
      } finally {
        setIsSaving(false);
      }
    }
    handleClose();
  }, [itemId, data, isPublic, linkPermission, handleClose]);

  const handleCopyLink = useCallback(async () => {
    if (!itemId) return;
    const url = generateShareUrl(itemId);
    await navigator.clipboard.writeText(url);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  }, [itemId, itemName]);

  const handleUpdatePermission = async (userId: string, newPermission: string) => {
    if (!itemId) return;
    try {
      await patchItemPermission(itemId, userId, newPermission);
      setMembers(prev => prev.map(m => m.userId === userId ? { ...m, permission: newPermission } : m));
      setExpandedMemberId(null);
      await refreshStorePermissions(itemId);
    } catch (error) {
      console.error('更新權限失敗:', error);
    }
  };

  const handleRemoveMember = async (userId: string) => {
    if (!itemId) return;
    try {
      await deleteItemPermission(itemId, userId);
      setMembers(prev => prev.filter(m => m.userId !== userId));
      setExpandedMemberId(null);
      await refreshStorePermissions(itemId);
    } catch (error) {
      console.error('移除成員失敗:', error);
    }
  };

  const handleInvite = async () => {
    if (!itemId || !inviteEmail.trim()) return;
    setIsInviting(true);
    setInviteError('');
    try {
      await inviteMember(itemId, inviteEmail.trim(), invitePermission);
      setInviteEmail('');
      await loadMembers(itemId);
      await refreshStorePermissions(itemId);
    } catch (error: any) {
      setInviteError(error?.message || t('inviteFailed'));
    } finally {
      setIsInviting(false);
    }
  };

  // 過濾建議：排除已在當前 item 的成員和 pending
  const currentMemberIds = new Set(members.map(m => m.userId));
  const filteredSuggestions = knownCollaborators.filter(c => {
    if (currentMemberIds.has(c.userId)) return false;
    if (!inviteEmail.trim()) return true;
    const q = inviteEmail.trim().toLowerCase();
    return (c.name?.toLowerCase().includes(q) || c.userId.toLowerCase().includes(q));
  });

  const handleSelectCollaborator = async (userId: string) => {
    if (!itemId) return;
    setShowSuggestions(false);
    setInviteEmail('');
    setIsInviting(true);
    setInviteError('');
    try {
      await inviteMemberByUserId(itemId, userId, invitePermission);
      await loadMembers(itemId);
      await refreshStorePermissions(itemId);
    } catch (error: any) {
      setInviteError(error?.message || t('inviteFailed'));
    } finally {
      setIsInviting(false);
    }
  };

  // 點擊 invite row 外部時關閉建議
  useEffect(() => {
    if (!showSuggestions) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (inviteRowRef.current && !inviteRowRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showSuggestions]);

  const handleCancelInvite = async (email: string) => {
    if (!itemId) return;
    try {
      await cancelInvitation(itemId, email);
      setPendingInvites(prev => prev.filter(p => p.email !== email));
    } catch (error) {
      console.error('取消邀請失敗:', error);
    }
  };

  const getMemberDisplayName = (memberID: string) => membersInfoMap[memberID]?.name || memberID.slice(-8);
  const getMemberAvatar = (memberID: string) => membersInfoMap[memberID]?.avatar || null;

  const getPermissionLabel = (permission: string) => {
    switch (permission) {
      case Permission.OWNER: return t('ownerLabel');
      case Permission.EDITOR: return t('permissionEditor');
      case Permission.CONTRIBUTOR: return t('permissionContributor');
      case Permission.VIEWER: return t('permissionViewer');
      case Permission.BLOCKED: return t('permissionBlocked');
      default: return permission;
    }
  };

  const memberPermissionOptions = [
    { value: Permission.EDITOR, label: t('permissionEditor') },
    { value: Permission.CONTRIBUTOR, label: t('permissionContributor') },
    { value: Permission.VIEWER, label: t('permissionViewer') },
    { value: Permission.BLOCKED, label: t('permissionBlocked') },
  ];

  if (!show || !itemId) return null;

  return (
    <CustomDialog
      isOpen
      onClose={handleClose}
      title={t('sharingDialogTitle', { name: itemName })}
      className="sharing-dialog"
      autoFocus={false}
    >
      <div className="sharing-content">
        {/* 邀請輸入（owner 或 contributor 以上可邀請） */}
        {canInvite && (
          <>
            <div className="sharing-invite-row" ref={inviteRowRef}>
              <div className="sharing-invite-input-wrapper">
                <input
                  className="sharing-invite-input"
                  type="email"
                  placeholder={t('inviteByEmail')}
                  value={inviteEmail}
                  onChange={(e) => { setInviteEmail(e.target.value); setInviteError(''); setShowSuggestions(true); }}
                  onFocus={() => setShowSuggestions(true)}
                  onKeyDown={(e) => {
                    if (e.nativeEvent.isComposing) return;
                    if (e.key === 'Enter') { setShowSuggestions(false); handleInvite(); }
                    if (e.key === 'Escape') setShowSuggestions(false);
                  }}
                />
                {showSuggestions && filteredSuggestions.length > 0 && (
                  <div className="sharing-suggestions-dropdown">
                    {filteredSuggestions.map(c => (
                      <div
                        key={c.userId}
                        className="sharing-suggestion-item"
                        onMouseDown={(e) => { e.preventDefault(); handleSelectCollaborator(c.userId); }}
                      >
                        {c.avatar ? (
                          <img className="sharing-suggestion-avatar" src={c.avatar} alt="" />
                        ) : (
                          <div className="sharing-suggestion-avatar-placeholder" />
                        )}
                        <span className="sharing-suggestion-name">{c.name || c.userId.slice(-8)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <button
                className="sharing-invite-btn"
                onClick={() => { setShowSuggestions(false); handleInvite(); }}
                disabled={isInviting || !inviteEmail.trim()}
              >
                {isInviting ? '...' : t('invite')}
              </button>
            </div>
            {inviteError && <div className="sharing-invite-error">{inviteError}</div>}
          </>
        )}

        {/* 具有存取權的使用者 */}
        <div className="sharing-section">
          <div className="sharing-section-title">{t('accessUsers')}</div>
          <div className="sharing-member-list">
            {/* 自己 */}
            <div className="sharing-member-item">
              <div className="sharing-member-info">
                <div className="sharing-member-avatar-wrapper">
                  {getMemberAvatar(myMemberID) ? (
                    <img className="sharing-member-avatar" src={getMemberAvatar(myMemberID)!} alt="" />
                  ) : (
                    <div className="sharing-member-avatar-placeholder" />
                  )}
                </div>
                <div className="sharing-member-details">
                  <span className="sharing-member-name">{t('you')}</span>
                </div>
              </div>
              <div className="sharing-permission-dropdown-btn sharing-permission-dropdown-btn--static">
                {getPermissionLabel(myPermission)}
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                  <polyline points="6 9 12 15 18 9" />
                </svg>
              </div>
            </div>
            {/* Members（排除自己，已在上方顯示為「你」） */}
            {members.filter(m => m.userId !== myMemberID).map(member => (
              <div key={member.userId} className="sharing-member-item">
                <div className="sharing-member-info">
                  <div className="sharing-member-avatar-wrapper">
                    {getMemberAvatar(member.userId) ? (
                      <img className="sharing-member-avatar" src={getMemberAvatar(member.userId)!} alt="" />
                    ) : (
                      <div className="sharing-member-avatar-placeholder" />
                    )}
                  </div>
                  <div className="sharing-member-details">
                    <span className="sharing-member-name">{getMemberDisplayName(member.userId)}</span>
                  </div>
                </div>
                {isOwner ? (
                  <button
                    className="sharing-permission-dropdown-btn"
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setMenuPosition({ x: rect.right, y: rect.bottom + 4 });
                      setExpandedMemberId(expandedMemberId === member.userId ? null : member.userId);
                    }}
                  >
                    {getPermissionLabel(member.permission)}
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </button>
                ) : (
                  <div className="sharing-permission-dropdown-btn sharing-permission-dropdown-btn--static">
                    {getPermissionLabel(member.permission)}
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
            {/* Pending invites（只有 owner 能看到和取消） */}
            {isOwner && pendingInvites.map(pending => (
              <div key={pending.email} className="sharing-member-item pending">
                <div className="sharing-member-info">
                  <div className="sharing-member-avatar-placeholder pending-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.5">
                      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                      <polyline points="22,6 12,13 2,6" />
                    </svg>
                  </div>
                  <div className="sharing-member-details">
                    <span className="sharing-member-name pending-text">{pending.email}</span>
                    <span className="sharing-member-email">{t('pendingInvite')}</span>
                  </div>
                </div>
                <button
                  className="sharing-cancel-invite-btn"
                  onClick={() => handleCancelInvite(pending.email)}
                  title={t('cancelInvite')}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* 一般存取權（只有支援公開分享的 type + owner 才顯示） */}
        {isOwner && canBePublic && (
          <div className="sharing-section">
            <div className="sharing-section-title">{t('generalAccess')}</div>
            <div className="sharing-general-access">
              <div className="sharing-access-icon">
                {isPublic ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="2" y1="12" x2="22" y2="12" />
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                  </svg>
                ) : (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                )}
              </div>
              <div className="sharing-access-body">
                <div className="sharing-access-row">
                  <div className="sharing-access-dropdown" ref={accessDropdownRef}>
                    <button
                      className="sharing-access-dropdown-btn"
                      onClick={() => setAccessDropdownOpen(!accessDropdownOpen)}
                    >
                      {isPublic ? t('anyoneWithLink') : t('restrictedAccess')}
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="6 9 12 15 18 9" />
                      </svg>
                    </button>
                    {accessDropdownOpen && (
                      <div className="sharing-dropdown-menu">
                        <div
                          className={`sharing-dropdown-option ${!isPublic ? 'active' : ''}`}
                          onClick={() => { setIsPublic(false); setAccessDropdownOpen(false); }}
                        >
                          {!isPublic && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>}
                          <span>{t('restrictedAccess')}</span>
                        </div>
                        <div
                          className={`sharing-dropdown-option ${isPublic ? 'active' : ''}`}
                          onClick={() => { setIsPublic(true); setAccessDropdownOpen(false); }}
                        >
                          {isPublic && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>}
                          <span>{t('anyoneWithLink')}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {isPublic && (
                    <div className="sharing-link-perm" ref={linkPermDropdownRef}>
                      {hasMultipleLinkOptions ? (
                        <>
                          <button
                            className="sharing-permission-dropdown-btn"
                            onClick={() => setLinkPermDropdownOpen(!linkPermDropdownOpen)}
                          >
                            {selectedLinkOption.label || getPermissionLabel(selectedLinkOption.value)}
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <polyline points="6 9 12 15 18 9" />
                            </svg>
                          </button>
                          {linkPermDropdownOpen && (
                            <div className="sharing-dropdown-menu right">
                              {linkOptions.map(opt => (
                                <div
                                  key={opt.value}
                                  className={`sharing-dropdown-option ${linkPermission === opt.value ? 'active' : ''}`}
                                  onClick={() => { setLinkPermission(opt.value); setLinkPermDropdownOpen(false); }}
                                >
                                  {linkPermission === opt.value && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>}
                                  <span>{opt.label || getPermissionLabel(opt.value)}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </>
                      ) : (
                        <span className="sharing-link-perm-fixed">
                          {selectedLinkOption.label || getPermissionLabel(selectedLinkOption.value) || t('permissionViewer')}
                        </span>
                      )}
                    </div>
                  )}
                </div>
                <div className="sharing-access-desc">
                  {isPublic
                    ? (selectedLinkOption.description || t('anyoneWithLinkDesc'))
                    : t('restrictedAccessDesc')
                  }
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 底部 */}
        <div className="sharing-footer">
          {/* 非 owner 的退出共享按鈕 */}
          {!isOwner && (
            <button
              className="sharing-leave-btn"
              onClick={handleLeaveShare}
              disabled={isLeaving}
            >
              {isLeaving ? '...' : t('leaveShare')}
            </button>
          )}
          {isOwner && (
            <button className="sharing-copy-link-btn" onClick={handleCopyLink}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
              </svg>
              {linkCopied ? t('copied') : t('copyLink')}
            </button>
          )}
          <button
            className="sharing-done-btn"
            onClick={handleDone}
            disabled={isSaving}
          >
            {isSaving ? '...' : t('done')}
          </button>
        </div>
      </div>

      {/* 成員權限彈出選單 */}
      {expandedMemberId && (
        <PopupMenu
          x={menuPosition.x}
          y={menuPosition.y}
          onClose={() => setExpandedMemberId(null)}
          className="sharing-permission-popup"
        >
          {memberPermissionOptions.map(option => {
            const member = members.find(m => m.userId === expandedMemberId);
            return (
              <div
                key={option.value}
                className={`sharing-popup-option ${member?.permission === option.value ? 'active' : ''}`}
                onClick={() => handleUpdatePermission(expandedMemberId, option.value)}
              >
                {option.label}
                {member?.permission === option.value && (
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                )}
              </div>
            );
          })}
          <div className="sharing-popup-divider" />
          <div
            className="sharing-popup-option remove"
            onClick={() => handleRemoveMember(expandedMemberId)}
          >
            {t('removeMember')}
          </div>
        </PopupMenu>
      )}
    </CustomDialog>
  );
}

export default SharingDialog;
