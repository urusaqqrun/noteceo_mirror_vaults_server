import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from '../CustomDialog';
import { getEditHistory, getMembersInfo } from '../../../utils/shareAPI';
import EditHistoryList, { ChangeType } from './EditHistoryList';
import { useIsMobileView } from '../../../hooks/useWindowSize';
import { useMembersInfoStore } from '../../../Store/MembersInfoStore';
import { useDialogStore } from '../../../Store/dialogStore';
import { useItemStore } from '../../../Store/itemStore';
import { useSelectedItemsStore } from '../../../Store/navigationStore';
import type { ItemPermissionEntry } from '../../../types/item';
import './ContributorsDialog.css';

const VISIBLE_PERMISSIONS = new Set(['owner', 'editor', 'contributor']);

function ContributorsDialog() {
  const { t } = useTranslation();
  const isOpen = useDialogStore(state => state.dialogs['contributors']?.show);
  const dialogData = useDialogStore(state => state.dialogs['contributors']?.data);

  const itemId = dialogData?.itemId as string | undefined;

  const item = useItemStore(state => itemId ? state.itemMap.get(itemId) : undefined);
  const permissions: ItemPermissionEntry[] = item?._permissions || [];
  const membersInfoMap = useMembersInfoStore(state => state.membersInfoMap);

  const ownerMemberId = useMemo(() => {
    return permissions.find(p => p.permission === 'owner')?.user_id;
  }, [permissions]);

  const members = useMemo(() => {
    return permissions.filter(p => VISIBLE_PERMISSIONS.has(p.permission) && p.permission !== 'guest');
  }, [permissions]);

  const [histories, setHistories] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);
  const [previewAvatarUrl, setPreviewAvatarUrl] = useState<string | null>(null);
  const isMobileView = useIsMobileView();
  const [mobileShowContent, setMobileShowContent] = useState(false);

  const handleClose = () => {
    useDialogStore.getState().close('contributors');
  };

  const handleItemClick = useCallback((clickedItemId: string) => {
    const clickedItem = useItemStore.getState().getById(clickedItemId);
    if (!clickedItem) return;
    useSelectedItemsStore.getState().setSelectedItems([clickedItem], { scrollToFocusItem: true });
    handleClose();
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    if (ownerMemberId) {
      setSelectedMemberId(ownerMemberId);
    } else if (members.length > 0) {
      setSelectedMemberId(members[0].user_id);
    } else {
      setSelectedMemberId(null);
    }
  }, [isOpen, ownerMemberId, members]);

  useEffect(() => {
    if (!isOpen) {
      setPreviewAvatarUrl(null);
      setMobileShowContent(false);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || !itemId) return;
    let cancelled = false;
    setIsLoading(true);
    getEditHistory({ itemId }).then(result => {
      if (!cancelled) setHistories(result || []);
    }).catch(() => {
      if (!cancelled) setHistories([]);
    }).finally(() => {
      if (!cancelled) setIsLoading(false);
    });
    return () => { cancelled = true; };
  }, [isOpen, itemId]);

  useEffect(() => {
    if (!isOpen || members.length === 0) return;
    const memberIds = members.map(m => m.user_id).filter(Boolean);
    if (memberIds.length === 0) return;
    useMembersInfoStore.getState().fetchMembersInfo(memberIds, getMembersInfo);
  }, [isOpen, members]);

  const statsByMember = useMemo(() => {
    const stats: Record<string, { create: number; update: number; comment: number }> = {};
    histories.forEach((h: any) => {
      const mid = h.actorId;
      if (!mid) return;
      if (!stats[mid]) stats[mid] = { create: 0, update: 0, comment: 0 };
      if (h.changeType === ChangeType.CREATED) stats[mid].create += 1;
      if (h.changeType === ChangeType.UPDATED) stats[mid].update += 1;
    });
    return stats;
  }, [histories]);

  // 用實際統計數字排序：新增數優先、編輯數次要
  const sortedMembers = useMemo(() => {
    return [...members].sort((a, b) => {
      const sa = statsByMember[a.user_id] || { create: 0, update: 0 };
      const sb = statsByMember[b.user_id] || { create: 0, update: 0 };
      const totalA = sa.create + sa.update;
      const totalB = sb.create + sb.update;
      if (totalB !== totalA) return totalB - totalA;
      if (sb.create !== sa.create) return sb.create - sa.create;
      return sb.update - sa.update;
    });
  }, [members, statsByMember]);


  const selectedMemberInfo = useMemo(() => {
    if (!selectedMemberId) return null;
    const info = (membersInfoMap[selectedMemberId] || {}) as any;
    return {
      memberId: selectedMemberId,
      name: info.name || String(selectedMemberId).slice(-6),
      photo: info.photo || null,
      intro: info.profiling || info.intro || info.bio || '',
      isOwner: ownerMemberId === selectedMemberId,
    };
  }, [ownerMemberId, selectedMemberId, membersInfoMap]);

  const renderIntro = (text: string) => {
    const parts = text.split(/(https?:\/\/[^\s]+)/g);
    return parts.map((part, i) => {
      if (/^https?:\/\/[^\s]+$/.test(part)) {
        return (
          <a key={i} href="#" onClick={(e) => {
            e.preventDefault();
            window.electronAPI?.openExternalLink?.(part);
          }}>{part}</a>
        );
      }
      return <span key={i}>{part}</span>;
    });
  };

  const timelineItems = useMemo(() => {
    if (!selectedMemberId) return [];
    return histories
      .filter((h: any) => h.actorId === selectedMemberId)
      .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [histories, selectedMemberId]);

  const renderContributorItem = (member: ItemPermissionEntry) => {
    const mid = member.user_id;
    const info = (membersInfoMap[mid] || {}) as any;
    const displayName = info.name || String(mid).slice(-6);
    const avatarUrl = info.thumbnail || info.photo || null;
    const stats = statsByMember[mid] || { create: 0, update: 0, comment: 0 };
    const isActive = !isMobileView && selectedMemberId === mid;

    return (
      <button
        key={mid}
        className={`contributors-dialog-item ${isActive ? 'active' : ''}`}
        onClick={() => isMobileView ? (() => { setSelectedMemberId(mid); setMobileShowContent(true); })() : setSelectedMemberId(mid)}
        type="button"
      >
        <div className="contributors-dialog-avatar" style={{ backgroundImage: avatarUrl ? `url(${avatarUrl})` : undefined }} />
        <div className="contributors-dialog-info">
          <div className="contributors-dialog-name">{displayName}</div>
          <div className="contributors-dialog-stats">
            <span>{t('historyFilterCreate', '新增')} {stats.create}</span>
            <span>{t('historyFilterUpdate', '編輯')} {stats.update}</span>
          </div>
        </div>
      </button>
    );
  };

  const renderContributorDetail = () => {
    if (!selectedMemberInfo) {
      return <div className="contributors-dialog-placeholder">{t('selectContributor', '選擇貢獻者以查看詳細資訊')}</div>;
    }
    return (
      <>
        <div className="contributors-dialog-profile">
          <button
            type="button"
            className="contributors-dialog-profile-avatar"
            style={{ backgroundImage: selectedMemberInfo.photo ? `url(${selectedMemberInfo.photo})` : undefined }}
            onClick={() => { if (selectedMemberInfo.photo) setPreviewAvatarUrl(selectedMemberInfo.photo); }}
          />
          <div className="contributors-dialog-profile-info">
            <div className="contributors-dialog-profile-name">
              <span>{selectedMemberInfo.name}</span>
              {selectedMemberInfo.isOwner && (
                <span className="contributors-dialog-owner-badge">{t('owner', '擁有者')}</span>
              )}
            </div>
            <div className="contributors-dialog-profile-intro">
              {selectedMemberInfo.intro ? renderIntro(selectedMemberInfo.intro) : t('noIntro', '尚無自我介紹')}
            </div>
          </div>
        </div>
        <EditHistoryList
          histories={timelineItems}
          isLoading={isLoading}
          emptyText={t('noEditHistory', '尚無歷史紀錄')}
          onActorClick={setSelectedMemberId}
          onItemClick={handleItemClick}
        />
      </>
    );
  };

  if (!isOpen) return null;

  return (
    <>
      <CustomDialog
        isOpen={isOpen}
        onClose={handleClose}
        title={isMobileView && mobileShowContent ? selectedMemberInfo?.name || t('contributorDetail', '貢獻者詳情') : t('contributors', '貢獻者')}
        className="contributors-dialog"
        onBack={isMobileView && mobileShowContent ? () => setMobileShowContent(false) : null}
      >
        {isMobileView && !mobileShowContent ? (
          <div className="contributors-dialog-mobile-list">
            {members.length === 0 && <div className="contributors-dialog-empty">{t('noContributors', '目前沒有貢獻者資料')}</div>}
            {sortedMembers.map(renderContributorItem)}
          </div>
        ) : isMobileView && mobileShowContent ? (
          <div className="contributors-dialog-mobile-detail">
            {renderContributorDetail()}
          </div>
        ) : (
          <div className="contributors-dialog-body">
            <div className="contributors-dialog-list">
              {members.length === 0 && <div className="contributors-dialog-empty">{t('noContributors', '目前沒有貢獻者資料')}</div>}
              {sortedMembers.map(renderContributorItem)}
            </div>
            <div className="contributors-dialog-detail">
              {renderContributorDetail()}
            </div>
          </div>
        )}
      </CustomDialog>
      <CustomDialog
        isOpen={!!previewAvatarUrl}
        onClose={() => setPreviewAvatarUrl(null)}
        title={t('photoPreview', '照片預覽')}
        className="contributors-dialog-avatar-preview"
      >
        <div className="contributors-dialog-avatar-preview-body">
          {previewAvatarUrl && <img src={previewAvatarUrl} alt="avatar preview" />}
        </div>
      </CustomDialog>
    </>
  );
}

export default ContributorsDialog;
