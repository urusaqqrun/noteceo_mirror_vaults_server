import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNotificationStore, type NotificationItemProps } from '../../../Store/notificationStore';
import { acceptInvitation, rejectInvitation, approveInvitation, rejectInvitationByOwner } from '../../../utils/shareAPI';
import './sharingNotifications.css';

function SharingInvitedNotificationItem({ notification, onMarkRead, onDelete }: NotificationItemProps) {
  const { t } = useTranslation();
  const { data, isRead, createdAt } = notification;
  const [loading, setLoading] = useState(false);
  const [responded, setResponded] = useState(false);

  const text = t('notification.sharing_invited', {
    ownerName: data?.ownerName || '',
    itemName: data?.itemName || '',
  });

  const timeAgo = formatTimeAgo(createdAt);
  const invitationId = data?.invitationId;

  const handleAccept = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!invitationId || loading) return;
    setLoading(true);
    try {
      const result = await acceptInvitation(invitationId);
      console.log('[SHARE-SYNC] notification accept done, itemId:', result?.itemId);
      setResponded(true);
      if (!isRead) onMarkRead();
      setTimeout(() => onDelete(), 1500);
      const syncModule = await import('../../../utils/syncService');
      console.log('[SHARE-SYNC] notification accept triggering syncChanges');
      await syncModule.default.syncChanges();
    } catch (err: any) {
      const msg = err?.message || '';
      if (msg.includes('404') || msg.includes('not found') || msg.includes('expired')) {
        setResponded(true);
        if (!isRead) onMarkRead();
        setTimeout(() => onDelete(), 1500);
      } else {
        console.error('Accept invitation failed:', err);
        setLoading(false);
      }
    }
  };

  const handleReject = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!invitationId || loading) return;
    setLoading(true);
    try {
      await rejectInvitation(invitationId);
      setResponded(true);
      if (!isRead) onMarkRead();
      setTimeout(() => onDelete(), 1500);
    } catch (err: any) {
      const msg = err?.message || '';
      if (msg.includes('404') || msg.includes('not found') || msg.includes('expired')) {
        setResponded(true);
        if (!isRead) onMarkRead();
        setTimeout(() => onDelete(), 1500);
      } else {
        console.error('Reject invitation failed:', err);
        setLoading(false);
      }
    }
  };

  const handleClick = () => {
    if (!isRead) onMarkRead();
  };

  return (
    <div className={`notification-item ${isRead ? '' : 'unread'}`} onClick={handleClick}>
      <div className={`notification-item-dot ${isRead ? 'read' : ''}`} />
      <div className="notification-item-content">
        <div className="notification-item-text">{text}</div>
        <div className="notification-item-time">{timeAgo}</div>
        {invitationId && !responded && (
          <div className="sharing-notification-actions">
            <button
              className="sharing-notification-accept-btn"
              onClick={handleAccept}
              disabled={loading}
            >
              {t('accept')}
            </button>
            <button
              className="sharing-notification-reject-btn"
              onClick={handleReject}
              disabled={loading}
            >
              {t('reject')}
            </button>
          </div>
        )}
        {responded && (
          <div className="sharing-notification-responded">
            {t('responded')}
          </div>
        )}
      </div>
      <button
        className="notification-item-delete"
        onClick={(e) => { e.stopPropagation(); onDelete(); }}
        title={t('delete')}
      >
        ×
      </button>
    </div>
  );
}

function AccessRequestNotificationItem({ notification, onMarkRead, onDelete }: NotificationItemProps) {
  const { t } = useTranslation();
  const { data, isRead, createdAt } = notification;
  const [loading, setLoading] = useState(false);
  const [responded, setResponded] = useState(false);

  const text = t('notification.sharing_access_requested', {
    requesterName: data?.requesterName || '',
    itemName: data?.itemName || '',
  });

  const timeAgo = formatTimeAgo(createdAt);
  const invitationId = data?.invitationId;

  const handleApprove = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!invitationId || loading) return;
    setLoading(true);
    try {
      await approveInvitation(invitationId);
      setResponded(true);
      if (!isRead) onMarkRead();
      setTimeout(() => onDelete(), 1500);
    } catch (err: any) {
      const msg = err?.message || '';
      if (msg.includes('404') || msg.includes('not found') || msg.includes('expired')) {
        setResponded(true);
        if (!isRead) onMarkRead();
        setTimeout(() => onDelete(), 1500);
      } else {
        console.error('Approve access request failed:', err);
        setLoading(false);
      }
    }
  };

  const handleReject = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!invitationId || loading) return;
    setLoading(true);
    try {
      await rejectInvitationByOwner(invitationId);
      setResponded(true);
      if (!isRead) onMarkRead();
      setTimeout(() => onDelete(), 1500);
    } catch (err: any) {
      const msg = err?.message || '';
      if (msg.includes('404') || msg.includes('not found') || msg.includes('expired')) {
        setResponded(true);
        if (!isRead) onMarkRead();
        setTimeout(() => onDelete(), 1500);
      } else {
        console.error('Reject access request failed:', err);
        setLoading(false);
      }
    }
  };

  const handleClick = () => {
    if (!isRead) onMarkRead();
  };

  return (
    <div className={`notification-item ${isRead ? '' : 'unread'}`} onClick={handleClick}>
      <div className={`notification-item-dot ${isRead ? 'read' : ''}`} />
      <div className="notification-item-content">
        <div className="notification-item-text">{text}</div>
        <div className="notification-item-time">{timeAgo}</div>
        {invitationId && !responded && (
          <div className="sharing-notification-actions">
            <button
              className="sharing-notification-accept-btn"
              onClick={handleApprove}
              disabled={loading}
            >
              {t('approve')}
            </button>
            <button
              className="sharing-notification-reject-btn"
              onClick={handleReject}
              disabled={loading}
            >
              {t('reject')}
            </button>
          </div>
        )}
        {responded && (
          <div className="sharing-notification-responded">
            {t('responded')}
          </div>
        )}
      </div>
      <button
        className="notification-item-delete"
        onClick={(e) => { e.stopPropagation(); onDelete(); }}
        title={t('delete')}
      >
        ×
      </button>
    </div>
  );
}

function formatTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '剛剛';
  if (minutes < 60) return `${minutes} 分鐘前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} 小時前`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} 天前`;
  return new Date(timestamp).toLocaleDateString();
}

export function registerSharingNotifications() {
  useNotificationStore.getState().registerNotificationRenderer('sharing_invited', {
    Component: SharingInvitedNotificationItem,
  });
  useNotificationStore.getState().registerNotificationRenderer('sharing_access_requested', {
    Component: AccessRequestNotificationItem,
  });
}
