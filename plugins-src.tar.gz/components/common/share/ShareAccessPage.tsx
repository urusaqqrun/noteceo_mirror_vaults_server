import React from 'react';
import CubeLVLogoLight from '../../../assets/CubeLV_logo_light.png';
import CubeLVLogoDark from '../../../assets/CubeLV_logo_dark.png';
import { useTheme } from '../../Setting/ThemeProvider';
import './ShareAccessPage.css';

interface ShareAccessPageProps {
  title: string;
  description: string;
  hint?: string;
  ownerName?: string;
  ownerAvatar?: string;
  primaryButton?: {
    label: string;
    onClick: () => void;
    disabled?: boolean;
  };
  secondaryButton?: {
    label: string;
    onClick: () => void;
  };
}

export default function ShareAccessPage({
  title,
  description,
  hint,
  ownerName,
  ownerAvatar,
  primaryButton,
  secondaryButton,
}: ShareAccessPageProps) {
  const { mode } = useTheme();

  return (
    <div className="share-access-container">
      <div className="share-access-card">
        <img
          src={mode === 'dark' ? CubeLVLogoLight : CubeLVLogoDark}
          alt="CubeLV"
          className="share-access-logo"
        />
        <h2 className="share-access-title">{title}</h2>
        <p className="share-access-description">{description}</p>
        {hint && <p className="share-access-hint">{hint}</p>}

        {ownerName && (
          <div className="share-access-owner">
            {ownerAvatar && (
              <img
                src={ownerAvatar}
                alt=""
                className="share-access-owner-avatar"
              />
            )}
            <span>{ownerName}</span>
          </div>
        )}

        <div className="share-access-buttons">
          {primaryButton && (
            <button
              className="share-access-primary-btn"
              onClick={primaryButton.onClick}
              disabled={primaryButton.disabled}
            >
              {primaryButton.label}
            </button>
          )}
          {secondaryButton && (
            <button
              className="share-access-secondary-btn"
              onClick={secondaryButton.onClick}
            >
              {secondaryButton.label}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
