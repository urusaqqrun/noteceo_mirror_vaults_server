import React from 'react';
import { useTranslation } from 'react-i18next';
import ShareAccessPage from './ShareAccessPage';

export default function ShareNotFoundPage() {
  const { t } = useTranslation();

  return (
    <ShareAccessPage
      title={t('shareNotFoundTitle')}
      description={t('shareNotFoundDescription')}
      hint={t('shareNotFoundHint')}
      primaryButton={{
        label: t('goToHomepage'),
        onClick: () => { window.location.href = '/app'; },
      }}
    />
  );
}
