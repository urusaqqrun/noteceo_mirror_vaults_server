import React from 'react';
import { useTranslation } from 'react-i18next';

export default function PublicShareErrorPage() {
  const { t } = useTranslation();

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      height: '100vh', color: 'var(--on)', background: 'var(--background)',
      gap: '16px', padding: '20px', textAlign: 'center',
    }}>
      <h2 style={{ margin: 0, fontSize: '24px' }}>{t('shareNotFoundTitle')}</h2>
      <p style={{ margin: 0, opacity: 0.7 }}>{t('shareNotFoundDescription')}</p>
      <button
        onClick={() => { window.location.href = '/app'; }}
        style={{
          marginTop: '16px', padding: '12px 32px', fontSize: '16px',
          background: 'var(--primary)', color: 'white',
          border: 'none', borderRadius: '8px', cursor: 'pointer',
        }}
      >
        {t('goToHomepage')}
      </button>
    </div>
  );
}
