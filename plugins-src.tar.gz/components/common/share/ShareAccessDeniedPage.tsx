import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import ShareAccessPage from './ShareAccessPage';
import { requestAccess } from '../../../utils/shareAPI';

interface ShareAccessDeniedPageProps {
  itemId: string;
  ownerName?: string;
  ownerAvatar?: string;
}

export default function ShareAccessDeniedPage({ itemId, ownerName, ownerAvatar }: ShareAccessDeniedPageProps) {
  const { t } = useTranslation();
  const [requested, setRequested] = useState(false);

  // Guest / 未登入不能要求存取權
  const canRequestAccess = localStorage.getItem('isLoggedIn') === 'true' && localStorage.getItem('isGuest') !== 'true';

  const handleRequestAccess = async () => {
    try {
      await requestAccess(itemId);
      setRequested(true);
    } catch {
      setRequested(true);
    }
  };

  return (
    <ShareAccessPage
      title={t('shareAccessDenied')}
      description={t('shareAccessDeniedDesc')}
      ownerName={ownerName ? t('shareOwnerInfo', { ownerName }) : undefined}
      ownerAvatar={ownerAvatar}
      primaryButton={canRequestAccess ? {
        label: requested ? t('accessRequested') : t('requestAccess'),
        onClick: handleRequestAccess,
        disabled: requested,
      } : undefined}
      secondaryButton={{
        label: t('goToHomepage'),
        onClick: () => { window.location.href = '/app'; },
      }}
    />
  );
}
