// 圖標統一映射（資料夾分類 + 圖表類型）
import FolderIcon from '../../assets/icon_folder_outline_24.svg?react';
import AlertCircleIcon from '../../assets/category/alert-circle.svg?react';
import AwardIcon from '../../assets/category/award.svg?react';
import BellIcon from '../../assets/category/bell.svg?react';
import BikeIcon from '../../assets/category/bike.svg?react';
import BookOpenIcon from '../../assets/category/book-open.svg?react';
import BookmarkIcon from '../../assets/category/bookmark.svg?react';
import BrainIcon from '../../assets/category/brain.svg?react';
import BriefcaseIcon from '../../assets/category/briefcase.svg?react';
import BrushIcon from '../../assets/category/brush.svg?react';
import CalculatorIcon from '../../assets/category/calculator.svg?react';
import CalendarIcon from '../../assets/category/calendar.svg?react';
import CameraIcon from '../../assets/category/camera.svg?react';
import CarIcon from '../../assets/category/car.svg?react';
import CheckCircleIcon from '../../assets/category/check-circle.svg?react';
import ChefHatIcon from '../../assets/category/chef-hat.svg?react';
import ClipboardCheckIcon from '../../assets/category/clipboard-check.svg?react';
import ClockIcon from '../../assets/category/clock.svg?react';
import CloudIcon from '../../assets/category/cloud.svg?react';
import CodeIcon from '../../assets/category/code.svg?react';
import CoffeeIcon from '../../assets/category/coffee.svg?react';
import CoinsIcon from '../../assets/category/coins.svg?react';
import CompassIcon from '../../assets/category/compass.svg?react';
import CpuIcon from '../../assets/category/cpu.svg?react';
import CreditCardIcon from '../../assets/category/credit-card.svg?react';
import DatabaseIcon from '../../assets/category/database.svg?react';
import DogIcon from '../../assets/category/dog.svg?react';
import DollarSignIcon from '../../assets/category/dollar-sign.svg?react';
import DumbbellIcon from '../../assets/category/dumbbell.svg?react';
import FileTextIcon from '../../assets/category/file-text.svg?react';
import FileIcon from '../../assets/category/file.svg?react';
import FilmIcon from '../../assets/category/film.svg?react';
import FlagIcon from '../../assets/category/flag.svg?react';
import GamepadIcon from '../../assets/category/gamepad.svg?react';
import GiftIcon from '../../assets/category/gift.svg?react';
import GlobeIcon from '../../assets/category/globe.svg?react';
import GraduationCapIcon from '../../assets/category/graduation-cap.svg?react';
import HammerIcon from '../../assets/category/hammer.svg?react';
import HardDriveIcon from '../../assets/category/hard-drive.svg?react';
import HeadphonesIcon from '../../assets/category/headphones.svg?react';
import HeartIcon from '../../assets/category/heart.svg?react';
import HomeIcon from '../../assets/category/home.svg?react';
import ImageIcon from '../../assets/category/image.svg?react';
import LanguagesIcon from '../../assets/category/languages.svg?react';
import LaptopIcon from '../../assets/category/laptop.svg?react';
import LightbulbIcon from '../../assets/category/lightbulb.svg?react';
import LinkIcon from '../../assets/category/link.svg?react';
import MailIcon from '../../assets/category/mail.svg?react';
import MapPinIcon from '../../assets/category/map-pin.svg?react';
import MessageSquareIcon from '../../assets/category/message-square.svg?react';
import MonitorIcon from '../../assets/category/monitor.svg?react';
import MoonIcon from '../../assets/category/moon.svg?react';
import MusicIcon from '../../assets/category/music.svg?react';
import NavigationIcon from '../../assets/category/navigation.svg?react';
import PackageIcon from '../../assets/category/package.svg?react';
import PaletteIcon from '../../assets/category/palette.svg?react';
import PaperclipIcon from '../../assets/category/paperclip.svg?react';
import PenToolIcon from '../../assets/category/pen-tool.svg?react';
import PhoneIcon from '../../assets/category/phone.svg?react';
import PiggyBankIcon from '../../assets/category/piggy-bank.svg?react';
import PillIcon from '../../assets/category/pill.svg?react';
import PlaneIcon from '../../assets/category/plane.svg?react';
import PrinterIcon from '../../assets/category/printer.svg?react';
import RocketIcon from '../../assets/category/rocket.svg?react';
import ScissorsIcon from '../../assets/category/scissors.svg?react';
import SearchIcon from '../../assets/category/search.svg?react';
import ServerIcon from '../../assets/category/server.svg?react';
import ShieldIcon from '../../assets/category/shield.svg?react';
import ShoppingBagIcon from '../../assets/category/shopping-bag.svg?react';
import SmartphoneIcon from '../../assets/category/smartphone.svg?react';
import SparklesIcon from '../../assets/category/sparkles.svg?react';
import StarIcon from '../../assets/category/star.svg?react';
import StickyNoteIcon from '../../assets/category/sticky-note.svg?react';
import SunIcon from '../../assets/category/sun.svg?react';
import TagIcon from '../../assets/category/tag.svg?react';
import TargetIcon from '../../assets/category/target.svg?react';
import TreeIcon from '../../assets/category/tree.svg?react';
import TrendingUpIcon from '../../assets/category/trending-up.svg?react';
import UmbrellaIcon from '../../assets/category/umbrella.svg?react';
import UsersIcon from '../../assets/category/users.svg?react';
import UtensilsIcon from '../../assets/category/utensils.svg?react';
import VideoIcon from '../../assets/category/video.svg?react';
import WifiIcon from '../../assets/category/wifi.svg?react';
import WrenchIcon from '../../assets/category/wrench.svg?react';
import ZapIcon from '../../assets/category/zap.svg?react';

// 圖表類型圖標
import AreaChartIcon from '../../assets/chart/icon_chart_areachart.svg?react';
import BarChartIcon from '../../assets/chart/icon_chart_barchart.svg?react';
import ComposedChartIcon from '../../assets/chart/icon_chart_composed.svg?react';
import FunnelChartIcon from '../../assets/chart/icon_chart_funnel.svg?react';
import LineChartIcon from '../../assets/chart/icon_chart_linechart.svg?react';
import PieChartIcon from '../../assets/chart/icon_chart_piechart.svg?react';
import RadarChartIcon from '../../assets/chart/icon_chart_radar.svg?react';
import RadialBarChartIcon from '../../assets/chart/icon_chart_radarbar.svg?react';
import ScatterChartIcon from '../../assets/chart/icon_chart_scartterchart.svg?react';
import TreemapIcon from '../../assets/chart/icon_chart_treemap.svg?react';

// 創建圖標映射對象
export const iconRegistry = {
  'folder': FolderIcon,
  'alert-circle': AlertCircleIcon,
  'award': AwardIcon,
  'bell': BellIcon,
  'bike': BikeIcon,
  'book-open': BookOpenIcon,
  'bookmark': BookmarkIcon,
  'brain': BrainIcon,
  'briefcase': BriefcaseIcon,
  'brush': BrushIcon,
  'calculator': CalculatorIcon,
  'calendar': CalendarIcon,
  'camera': CameraIcon,
  'car': CarIcon,
  'check-circle': CheckCircleIcon,
  'chef-hat': ChefHatIcon,
  'clipboard-check': ClipboardCheckIcon,
  'clock': ClockIcon,
  'cloud': CloudIcon,
  'code': CodeIcon,
  'coffee': CoffeeIcon,
  'coins': CoinsIcon,
  'compass': CompassIcon,
  'cpu': CpuIcon,
  'credit-card': CreditCardIcon,
  'database': DatabaseIcon,
  'dog': DogIcon,
  'dollar-sign': DollarSignIcon,
  'dumbbell': DumbbellIcon,
  'file-text': FileTextIcon,
  'file': FileIcon,
  'film': FilmIcon,
  'flag': FlagIcon,
  'gamepad': GamepadIcon,
  'gift': GiftIcon,
  'globe': GlobeIcon,
  'graduation-cap': GraduationCapIcon,
  'hammer': HammerIcon,
  'hard-drive': HardDriveIcon,
  'headphones': HeadphonesIcon,
  'heart': HeartIcon,
  'home': HomeIcon,
  'image': ImageIcon,
  'languages': LanguagesIcon,
  'laptop': LaptopIcon,
  'lightbulb': LightbulbIcon,
  'link': LinkIcon,
  'mail': MailIcon,
  'map-pin': MapPinIcon,
  'message-square': MessageSquareIcon,
  'monitor': MonitorIcon,
  'moon': MoonIcon,
  'music': MusicIcon,
  'navigation': NavigationIcon,
  'package': PackageIcon,
  'palette': PaletteIcon,
  'paperclip': PaperclipIcon,
  'pen-tool': PenToolIcon,
  'phone': PhoneIcon,
  'piggy-bank': PiggyBankIcon,
  'pill': PillIcon,
  'plane': PlaneIcon,
  'printer': PrinterIcon,
  'rocket': RocketIcon,
  'scissors': ScissorsIcon,
  'search': SearchIcon,
  'server': ServerIcon,
  'shield': ShieldIcon,
  'shopping-bag': ShoppingBagIcon,
  'smartphone': SmartphoneIcon,
  'sparkles': SparklesIcon,
  'star': StarIcon,
  'sticky-note': StickyNoteIcon,
  'sun': SunIcon,
  'tag': TagIcon,
  'target': TargetIcon,
  'tree': TreeIcon,
  'trending-up': TrendingUpIcon,
  'umbrella': UmbrellaIcon,
  'users': UsersIcon,
  'utensils': UtensilsIcon,
  'video': VideoIcon,
  'wifi': WifiIcon,
  'wrench': WrenchIcon,
  'zap': ZapIcon,

  // 圖表類型
  'LineChart': LineChartIcon,
  'AreaChart': AreaChartIcon,
  'BarChart': BarChartIcon,
  'PieChart': PieChartIcon,
  'ScatterChart': ScatterChartIcon,
  'RadarChart': RadarChartIcon,
  'RadialBarChart': RadialBarChartIcon,
  'Treemap': TreemapIcon,
  'FunnelChart': FunnelChartIcon,
  'ComposedChart': ComposedChartIcon,
};

// 輔助函數：根據圖標名稱獲取對應的圖標組件
export const getIconByName = (iconName) => {
  return iconRegistry[iconName] || null;
};

