import React from 'react';
import type { NotificationItemProps } from '../../Store/notificationStore';
import { useTranslation } from 'react-i18next';

/**
 * 通用通知項渲染（無自訂渲染器時的 fallback）
 * 顯示 i18n 翻譯的標題 + 時間 + 已讀標記
 */
function DefaultNotificationItem({ notification, onMarkRead, onDelete }: NotificationItemProps) {
  const { t } = useTranslation();
  const { type, data, isRead, createdAt } = notification;

  // i18n：嘗試翻譯 notification.<type>，fallback 到 type 本身
  const text = t(`notification.${type}`, { ...data, defaultValue: type });

  const timeAgo = formatTimeAgo(createdAt);

  const handleClick = () => {
    if (!isRead) onMarkRead();
  };

  return (
    <div
      className={`notification-item ${isRead ? '' : 'unread'}`}
      onClick={handleClick}
    >
      <div className={`notification-item-dot ${isRead ? 'read' : ''}`} />
      <div className="notification-item-content">
        <div className="notification-item-text">{text}</div>
        <div className="notification-item-time">{timeAgo}</div>
      </div>
      <button
        className="notification-item-delete"
        onClick={(e) => { e.stopPropagation(); onDelete(); }}
        title={t('delete')}
      >
        ×
      </button>
    </div>
  );
}

function formatTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '剛剛';
  if (minutes < 60) return `${minutes} 分鐘前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} 小時前`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} 天前`;
  return new Date(timestamp).toLocaleDateString();
}

export default DefaultNotificationItem;
