import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from './CustomDialog';

/**
 * 日期範圍選擇 Dialog（共用組件）
 * 用於 CardRenderer 和 CardListView 的 DATERANGE 欄位編輯
 * 
 * @param {boolean} isOpen - 是否開啟
 * @param {Function} onClose - 關閉回調
 * @param {string} fieldName - 欄位名稱
 * @param {string} value - 當前值（格式：YYYY/MM/DD ~ YYYY/MM/DD）
 * @param {Function} onChange - 值變更回調 (newValue) => void
 */
const DateRangeDialog = ({
  isOpen,
  onClose,
  fieldName,
  value,
  onChange
}) => {
  const { t } = useTranslation();

  // 解析日期範圍格式：「YYYY/MM/DD ~ YYYY/MM/DD」
  const parseDateRange = (val) => {
    if (!val) return { start: '', end: '' };
    const parts = val.split(' ~ ');
    return {
      start: (parts[0]?.trim() || '').replace(/\//g, '-'),
      end: (parts[1]?.trim() || '').replace(/\//g, '-')
    };
  };

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // 當 value 變化時更新內部狀態
  useEffect(() => {
    if (isOpen) {
      const { start, end } = parseDateRange(value);
      setStartDate(start);
      setEndDate(end);
    }
  }, [isOpen, value]);

  const handleConfirm = () => {
    // 轉換回 YYYY/MM/DD 格式
    const formattedStart = startDate.replace(/-/g, '/');
    const formattedEnd = endDate.replace(/-/g, '/');
    const newValue = formattedStart && formattedEnd
      ? `${formattedStart} ~ ${formattedEnd}`
      : formattedStart || formattedEnd || '';
    onChange?.(newValue);
    onClose?.();
  };

  return (
    <CustomDialog
      isOpen={isOpen}
      onClose={onClose}
      className="card-daterange-dialog"
    >
      <div className="card-daterange-row">
        <label>{t('startDate')}</label>
        <input
          type="date"
          name="startDate"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />
      </div>
      <div className="card-daterange-row">
        <label>{t('endDate')}</label>
        <input
          type="date"
          name="endDate"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
      </div>
      <div className="custom-dialog-buttons">
        <button className="custom-secondary-button" onClick={onClose}>
          {t('cancel')}
        </button>
        <button className="custom-primary-button" onClick={handleConfirm}>
          {t('confirm')}
        </button>
      </div>
    </CustomDialog>
  );
};

export default DateRangeDialog;

