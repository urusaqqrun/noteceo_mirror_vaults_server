import React from 'react';
import './DragOverlay.css';

interface DragOverlayProps {
    icon?: React.FC;
    text?: string;
    onDrop?: (e: React.DragEvent) => void;
    onDragOver?: (e: React.DragEvent) => void;
    onDragLeave?: (e: React.DragEvent) => void;
}

const DragOverlay: React.FC<DragOverlayProps> = ({ icon: Icon, text, onDrop, onDragOver, onDragLeave }) => {
    return (
        <div
            className="drag-overlay"
            style={onDrop ? { pointerEvents: 'auto' } : undefined}
            onDrop={onDrop}
            onDragOver={onDragOver || ((e) => { e.preventDefault(); })}
            onDragLeave={onDragLeave}
        >
            <div className="drag-overlay-message">
                {Icon && (
                    <div className="drag-overlay-icon">
                        <Icon />
                    </div>
                )}
                {text && (
                    <div className="drag-overlay-text">{text}</div>
                )}
            </div>
        </div>
    );
};

export default DragOverlay;
