import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import './ImagePreviewWindow.css';
import CopyIcon from '../../assets/icon_copy_16.svg?react';
import { useSelectedItemsStore } from '../../Store/navigationStore';
import { useTempHintStore } from '../../Store/uiStore';
import { useCommandManager } from '../../Store/commandManager';

// 檔案名稱暫存
let lastFileName = '';
let fileCounter = 1;

const ImagePreviewWindow = ({ isOpen, src, onClose }) => {
  const { t } = useTranslation();

  // 處理複製圖片
  const handleCopyImage = async () => {
    try {
      let base64Image = src;

      // 如果是 URL，先下載轉成 base64
      if (!src.startsWith('data:image')) {
        const response = await window.electronAPI.fetchImage({ url: src });
        if (!response.ok) {
          throw new Error('Failed to fetch image');
        }
        base64Image = `data:${response.contentType};base64,${response.data}`;
      }

      // 先寫入 HTML
      await window.electronClipboard.writeContent(`<img src="${src}">`, '');

      // 取得當前筆記標題作為檔案名稱
      let fileName = `clipboard-${Date.now()}.png`; // 預設名稱
      try {
        const currentNoteId = useSelectedItemsStore.getState().path.at(-1)?.id;
        if (currentNoteId) {
          const note = await window.electronAPI.getItem(currentNoteId);
          if (note) {
            const noteTitle = note.name || note.aiTitle || t('untitledNote');
            // 清理檔案名稱中的非法字符
            const cleanTitle = noteTitle.replace(/[<>:"/\\|?*]/g, '').slice(0, 50);
            const baseName = cleanTitle === t('untitledNote') ? `${cleanTitle}-${Date.now()}` : cleanTitle;
            if (lastFileName === baseName) fileCounter++; else { lastFileName = baseName; fileCounter = 1; }
            fileName = fileCounter === 1 ? `${baseName}.png` : `${baseName}${fileCounter}.png`;
          }
        }
      } catch (error) {

      }

      // 根據平台寫入圖片或檔案 URL
      await (window.electron?.platform === 'darwin' && window.electronClipboard.writeImageFile
        ? window.electronClipboard.writeImageFile(base64Image, fileName)
        : window.electronClipboard.writeImage(base64Image));

      useTempHintStore.getState().setTempHint(t('copied'));
    } catch (error) {
      console.error('複製圖片失敗:', error);
      useTempHintStore.getState().setTempHint(t('error'));
    }
  };

  // Escape 關閉 — commandManager 統一管理
  useEffect(() => {
    if (!isOpen) return;
    const unsub = useCommandManager.getState().register({
      command: {
        id: 'image-preview:escape',
        name: t('cmd.closePreview'),
        callback: () => onClose(),
      },
      hotkeys: [{ modifiers: [], key: 'Escape' }],
    });
    return unsub;
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="image-preview-overlay" onClick={onClose}>
      <div className="image-preview-container" onClick={e => e.stopPropagation()}>
        <div className="image-preview-header">
          <button
            className="image-preview-copy-btn"
            onClick={handleCopyImage}
            title={t('copyImage')}
          >
            <CopyIcon />
          </button>
          <button className="image-preview-close-btn" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
        <div className="image-preview-content">
          <img src={src} alt={t('zoomPreview')} />
        </div>
      </div>
    </div>
  );
};

export default ImagePreviewWindow; 