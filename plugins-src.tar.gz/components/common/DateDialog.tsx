import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from './CustomDialog';

/**
 * 日期選擇 Dialog（共用組件）
 * 用於手機版的 DATE/DATETIME 欄位編輯
 * 
 * @param {boolean} isOpen - 是否開啟
 * @param {Function} onClose - 關閉回調
 * @param {string} fieldName - 欄位名稱
 * @param {string} fieldType - 欄位類型（DATE 或 DATETIME）
 * @param {string} value - 當前值（格式：YYYY/MM/DD 或 YYYY/MM/DD HH:MM）
 * @param {Function} onChange - 值變更回調 (newValue) => void
 */
const DateDialog = ({
  isOpen,
  onClose,
  fieldName,
  fieldType = 'DATE',
  value,
  onChange
}) => {
  const { t } = useTranslation();

  const [dateValue, setDateValue] = useState('');
  const [timeValue, setTimeValue] = useState('');

  // 當 value 變化時更新內部狀態
  useEffect(() => {
    if (isOpen) {
      if (fieldType === 'DATETIME' && value) {
        // 格式：YYYY/MM/DD HH:MM
        const parts = value.split(' ');
        setDateValue((parts[0] || '').replace(/\//g, '-'));
        setTimeValue(parts[1] || '');
      } else if (value) {
        // 格式：YYYY/MM/DD
        setDateValue(value.replace(/\//g, '-'));
        setTimeValue('');
      } else {
        setDateValue('');
        setTimeValue('');
      }
    }
  }, [isOpen, value, fieldType]);

  const handleConfirm = () => {
    // 轉換回 YYYY/MM/DD 格式
    const formattedDate = dateValue.replace(/-/g, '/');
    let newValue = formattedDate;

    if (fieldType === 'DATETIME' && formattedDate && timeValue) {
      newValue = `${formattedDate} ${timeValue}`;
    }

    onChange?.(newValue);
    onClose?.();
  };

  return (
    <CustomDialog
      isOpen={isOpen}
      onClose={onClose}
      className="card-date-dialog"
    >
      <div className="card-daterange-row">
        <label>{fieldName || t('date')}</label>
        <input
          type="date"
          name="date"
          value={dateValue}
          onChange={(e) => setDateValue(e.target.value)}
        />
      </div>
      {fieldType === 'DATETIME' && (
        <div className="card-daterange-row">
          <label>{t('time')}</label>
          <input
            type="time"
            name="time"
            value={timeValue}
            onChange={(e) => setTimeValue(e.target.value)}
          />
        </div>
      )}
      <div className="custom-dialog-buttons">
        <button className="custom-secondary-button" onClick={onClose}>
          {t('cancel')}
        </button>
        <button className="custom-primary-button" onClick={handleConfirm}>
          {t('confirm')}
        </button>
      </div>
    </CustomDialog>
  );
};

export default DateDialog;

