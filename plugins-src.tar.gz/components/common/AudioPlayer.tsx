import React, { useState, useRef, useEffect } from 'react';
import './AudioPlayer.css';

const AudioPlayer = ({ audioURLs, audioUrl_local }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef(null);

  // 獲取實際要播放的音頻URL
  const getAudioSource = () => {
    if (audioUrl_local && audioUrl_local.length > 0) {
      return audioUrl_local[0];  // 使用本地base64音頻
    }
    if (audioURLs && audioURLs.length > 0) {
      return audioURLs[0];  // 使用遠端音頻
    }
    return '';
  };

  // 格式化時間
  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // 處理播放/停止
  const handlePlayPause = (e) => {
    e.stopPropagation();
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  // 監聽音頻事件
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
    };

    const handleEnded = () => {
      audio.currentTime = 0;
      setIsPlaying(false);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  // 當切換筆記時，暫停音頻播放
  useEffect(() => {
    const audio = audioRef.current;
    if (audio) {
      audio.pause();
      setIsPlaying(false);
      setCurrentTime(0);
    }
  }, [audioURLs, audioUrl_local]);

  const hasAudio = (audioURLs && audioURLs.length > 0) || (audioUrl_local && audioUrl_local.length > 0);
  const audioSource = getAudioSource();

  return (
    <div
      className={`note-item-audio-player ${!hasAudio ? 'hidden' : ''}`}
    //   onClick={handlePlayPause}
    >
      <button className="play-button" onClick={handlePlayPause}>
        <div className={`play-icon ${isPlaying ? 'playing' : ''}`} />
      </button>
      <div className="time-display">
        <span className="current-time">{formatTime(currentTime)}</span>
        <span className="time-separator">/</span>
        <span className="total-time">{formatTime(duration)}</span>
      </div>
      <audio
        ref={audioRef}
        src={audioSource}
        style={{ display: 'none' }}
      />
    </div>
  );
};

export default AudioPlayer;