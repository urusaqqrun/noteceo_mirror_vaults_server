import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from 'react-i18next';
import './CardRecognitionHint.css';
import { useCardRecognitionStore } from '../plugins/card/cardStore';
import StopIcon from '../../assets/icon_stop_round_26.svg?react';

const CardRecognitionHint = () => {
  const { t } = useTranslation();
  const [isVisible, setIsVisible] = useState(false);
  const [dotCount, setDotCount] = useState(2);

  const {
    isRecognizing,
    progress,
    statusMessage,
    totalImages,
    currentIndex,
    successCount,
    failedCount,
    abortRecognition
  } = useCardRecognitionStore();

  // 顯示/隱藏動畫
  useEffect(() => {
    if (isRecognizing) {
      setIsVisible(true);
    } else {
      // 延遲隱藏，讓動畫完成
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isRecognizing]);

  // 文字動畫效果（翻譯已包含 ..，所以額外加 0/2/4 個點）
  useEffect(() => {
    if (!isRecognizing) {
      setDotCount(2);
      return;
    }

    const interval = setInterval(() => {
      setDotCount((prev) => {
        if (prev === 2) return 4;
        if (prev === 4) return 6;
        return 2;
      });
    }, 500);

    return () => clearInterval(interval);
  }, [isRecognizing]);

  // 處理停止按鈕
  const handleStop = () => {
    abortRecognition();
  };

  // 獲取顯示文字
  const getHintText = () => {
    // 主要狀態訊息 + 動態點點
    if (statusMessage) {
      return `${statusMessage}${'.'.repeat(dotCount)}`;
    }
    return `${t('recognizing')}${'.'.repeat(dotCount)}`;
  };

  if (!isVisible && !isRecognizing) {
    return null;
  }

  return createPortal(
    <div className={`card-recognition-hint ${isRecognizing ? 'card-recognition-hint-visible' : 'card-recognition-hint-hidden'}`}>
      <div className="card-recognition-hint-content">
        <div className="card-recognition-hint-info">
          <span className="card-recognition-hint-text">
            {getHintText()}
          </span>
          <div className="card-recognition-hint-progress-bar">
            <div
              className="card-recognition-hint-progress-fill"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        <div className="card-recognition-hint-buttons">
          <button
            className="card-recognition-hint-button"
            onClick={handleStop}
            title={t('stop')}
          >
            <StopIcon />
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
};

export default CardRecognitionHint;

