import React from 'react';
import NameInputDialog from './NameInputDialog';
import { useDialogStore } from '../../Store/dialogStore';

/**
 * EditFolderNameDialog — 繼承 NameInputDialog 的 editFolder overlay
 * 
 * 透過 dialogStore.open('editFolder', data) 開啟
 * NoteListTopbar / TodoList 共用此 overlay
 */

interface EditFolderNameDialogData {
    title: string;
    initialName?: string;
    existingNames?: string[];
    placeholder?: string;
    onConfirm: (name: string) => void;
    tips?: string[];
}

function EditFolderNameDialog() {
    const isOpen = useDialogStore(s => s.dialogs['editFolder']?.show);
    const data = useDialogStore(s => s.dialogs['editFolder']?.data) as EditFolderNameDialogData | null;
    const close = () => useDialogStore.getState().close('editFolder');

    if (!isOpen || !data) return null;

    return (
        <NameInputDialog
            title={data.title}
            initialName={data.initialName}
            existingNames={data.existingNames}
            placeholder={data.placeholder}
            onConfirm={(name) => {
                data.onConfirm(name);
                close();
            }}
            onClose={close}
            tips={data.tips}
        />
    );
}

export default EditFolderNameDialog;
