import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { CustomDialog } from './CustomDialog';
import './BasicComponents.css';

/**
 * NameInputDialog — 通用名稱輸入 Dialog（零 Store 依賴）
 * 
 * props:
 *   title          — Dialog 標題
 *   initialName    — 初始名稱（編輯模式）
 *   existingNames  — 已存在的名稱列表（用於重名檢查，不含當前名稱）
 *   placeholder    — 輸入框 placeholder
 *   onConfirm      — (name: string) => void
 *   onClose        — () => void
 *   tips           — 可選的提示文字陣列
 */

interface NameInputDialogProps {
    title: string;
    initialName?: string;
    existingNames?: string[];
    placeholder?: string;
    onConfirm: (name: string) => void;
    onClose: () => void;
    tips?: string[];
}

function NameInputDialog({ title, initialName = '', existingNames = [], placeholder = '', onConfirm, onClose, tips }: NameInputDialogProps) {
    const { t } = useTranslation();
    const [name, setName] = useState(initialName);
    const [errorMessage, setErrorMessage] = useState('');

    const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setErrorMessage('');
        setName(value);

        if (value.trim()) {
            const isDuplicate = existingNames.some(
                n => n.toLowerCase() === value.trim().toLowerCase()
            );
            if (isDuplicate) {
                setErrorMessage(t('duplicateName'));
            }
        }
    };

    const handleSubmit = () => {
        if (!name.trim() || errorMessage) return;
        onConfirm(name.trim());
        onClose();
    };

    return (
        <CustomDialog isOpen={true} onClose={onClose} title={title} className="add-folder-dialog" onConfirm={handleSubmit}>
            <input
                type="text"
                value={name}
                onChange={handleInput}
                className="custom-dialog-input"
                placeholder={placeholder}
            />
            {errorMessage && <p className="dialog-error">{errorMessage}</p>}

            {tips && tips.length > 0 && (
                <div className="dialog-tips">
                    <p className="tips-title">{t('folderOperationsTips')}</p>
                    <ul className="tips-list">
                        {tips.map((tip, i) => <li key={i}>{tip}</li>)}
                    </ul>
                </div>
            )}
        </CustomDialog>
    );
}

export default NameInputDialog;
