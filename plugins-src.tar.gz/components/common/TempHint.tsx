import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import './TempHint.css';
import { useTempHintStore } from '../../Store/uiStore';

const TempHint = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const tempHint = useTempHintStore(state => state.tempHint);
  const tempHintPosition = useTempHintStore(state => state.tempHintPosition);
  const clearTempHint = useTempHintStore(state => state.clearTempHint);

  // 監聽視窗大小變化
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!tempHint) {
      setIsVisible(false);
      return;
    }

    // 入場動畫
    setIsVisible(true);

    // 設置退場時間
    const hideTimer = setTimeout(() => {
      setIsVisible(false);
    }, 1500);

    // 設置關閉時間（比退場晚一些，讓動畫有時間完成）
    const closeTimer = setTimeout(() => {
      clearTempHint();
    }, 1800);

    return () => {
      clearTimeout(hideTimer);
      clearTimeout(closeTimer);
    };
  }, [tempHint, clearTempHint]);

  if (!tempHint) {
    return null;
  }

  // Mobile 時強制從下方出現
  const position = isMobile ? 'bottom' : tempHintPosition;

  return createPortal(
    <div className={`temp-hint ${isVisible ? 'visible' : 'hidden'} ${position === 'bottom' ? 'temp-hint-bottom' : ''}`}>
      <div className="temp-hint-content">
        {tempHint}
      </div>
    </div>,
    document.body
  );
};

export default TempHint; 