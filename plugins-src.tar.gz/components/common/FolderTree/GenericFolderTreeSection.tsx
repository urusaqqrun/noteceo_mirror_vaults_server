// ===== GenericFolderTreeSection — 通用 tree renderer =====
//
// 從 SidebarSectionData 的 items 用 parentID 自動建樹。
// prefixItems / suffixItems 用 FolderItem 渲染（不可拖曳）。
// 管理拖曳狀態，透過 DragContext 共享給子元件。

import React, { useMemo, useState, useCallback } from 'react';
import FolderItem from '../../plugins/sidebar/FolderTree/FolderItem';
import FolderGroup from '../../plugins/sidebar/FolderTree/FolderGroup';
import { DragContext, type DragState, type DropPosition } from '../../plugins/sidebar/FolderTree/DragContext';
import type { BaseItem } from '../../../types/item';
import type { SidebarSectionData } from '../../plugins/sidebar/sidebarStore';

interface GenericFolderTreeSectionProps {
  data: SidebarSectionData;
  sectionId: string;
}

const GenericFolderTreeSection: React.FC<GenericFolderTreeSectionProps> = ({ data, sectionId }) => {
  const { items, prefixItems, suffixItems, separatePrefix, separateSuffix, ...adapters } = data;

  const { rootItems, getChildren } = useMemo(() => {
    const itemMap = new Map(items.map(i => [i.id, i]));
    const roots = items.filter(i => !i.parentID || !itemMap.has(i.parentID));
    const children = (parent: BaseItem) => items.filter(i => i.parentID === parent.id);
    return { rootItems: roots, getChildren: children };
  }, [items]);

  const [dragState, setDragState] = useState<DragState>({
    draggedItem: null,
    dropTarget: null,
    dropPosition: null,
    sectionId,
    items,
  });

  React.useEffect(() => {
    setDragState(prev => ({ ...prev, items }));
  }, [items]);

  const setDraggedItem = useCallback((item: BaseItem | null) => {
    setDragState(prev => ({ ...prev, draggedItem: item }));
  }, []);

  const setDrop = useCallback((target: BaseItem | null, position: DropPosition | null) => {
    setDragState(prev => ({ ...prev, dropTarget: target, dropPosition: position }));
  }, []);

  const clearDrag = useCallback(() => {
    setDragState(prev => ({ ...prev, draggedItem: null, dropTarget: null, dropPosition: null }));
  }, [sectionId]);

  const ctxValue = useMemo(() => ({
    ...dragState,
    setDraggedItem,
    setDrop,
    clearDrag,
  }), [dragState, setDraggedItem, setDrop, clearDrag]);

  return (
    <DragContext.Provider value={ctxValue}>
      <div className="folders-container">
        {prefixItems?.map(item => (
          <FolderItem key={item.id} item={item} adapters={adapters} draggable={false} />
        ))}
        {separatePrefix && <div className="sidebar-separator" />}
        {rootItems.map(item => {
          const children = getChildren(item);
          if (children.length > 0) {
            return (
              <FolderGroup
                key={item.id}
                item={item}
                children={children}
                getChildren={getChildren}
                adapters={adapters}
                sectionId={sectionId}
              />
            );
          }
          return <FolderItem key={item.id} item={item} adapters={adapters} />;
        })}
        {separateSuffix && <div className="sidebar-separator" />}
        {suffixItems?.map(item => (
          <FolderItem key={item.id} item={item} adapters={adapters} draggable={false} />
        ))}
      </div>
    </DragContext.Provider>
  );
};

export default GenericFolderTreeSection;
