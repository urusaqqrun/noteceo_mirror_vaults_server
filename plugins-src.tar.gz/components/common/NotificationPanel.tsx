import React from 'react';
import { useNotificationStore } from '../../Store/notificationStore';
import DefaultNotificationItem from './DefaultNotificationItem';
import { useTranslation } from 'react-i18next';
import './Notification.css';

/**
 * 通知面板 — 透過 overlayStore.register('notificationPanel') 掛載
 * 由 OverlayRenderer 統一渲染，全域只有一個實例
 */
const NotificationPanel = () => {
  const { t } = useTranslation();
  const isPanelOpen = useNotificationStore(s => s.isPanelOpen);
  const anchorRect = useNotificationStore(s => s.anchorRect);
  const notifications = useNotificationStore(s => s.notifications);
  const isLoading = useNotificationStore(s => s.isLoading);
  const renderers = useNotificationStore(s => s.renderers);
  const markAsRead = useNotificationStore(s => s.markAsRead);
  const markAllAsRead = useNotificationStore(s => s.markAllAsRead);
  const deleteNotification = useNotificationStore(s => s.deleteNotification);
  const setPanelOpen = useNotificationStore(s => s.setPanelOpen);
  const unreadCount = useNotificationStore(s => s.unreadCount);

  if (!isPanelOpen) return null;

  const panelStyle: React.CSSProperties = anchorRect
    ? { top: anchorRect.bottom + 8, left: anchorRect.left }
    : {};

  return (
    <>
      <div className="notification-panel-overlay" onClick={() => setPanelOpen(false)} />
      <div className="notification-panel" style={panelStyle} onClick={e => e.stopPropagation()}>
        <div className="notification-panel-header">
          <h3>{t('notifications', '通知')}</h3>
          <div className="notification-panel-header-actions">
            {unreadCount > 0 && (
              <button onClick={markAllAsRead}>
                {t('markAllRead', '全部已讀')}
              </button>
            )}
          </div>
        </div>

        <div className="notification-panel-list">
          {isLoading && notifications.length === 0 ? (
            <div className="notification-panel-empty">Loading...</div>
          ) : notifications.length === 0 ? (
            <div className="notification-panel-empty">
              {t('noNotifications', '沒有通知')}
            </div>
          ) : (
            notifications.map(n => {
              const customRenderer = renderers.get(n.type);
              const Component = customRenderer?.Component || DefaultNotificationItem;
              return (
                <Component
                  key={n.id}
                  notification={n}
                  onMarkRead={() => markAsRead(n.id)}
                  onDelete={() => deleteNotification(n.id)}
                />
              );
            })
          )}
        </div>
      </div>
    </>
  );
};

export default NotificationPanel;
